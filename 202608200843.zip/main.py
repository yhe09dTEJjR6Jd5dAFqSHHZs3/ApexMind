import base64
import copy
import ctypes
from ctypes import wintypes
import hashlib
import json
import math
import os
import random
import sys
import threading
import time


FEATURE_W = 12
FEATURE_H = 8
FEATURE_COUNT = FEATURE_W * FEATURE_H
HIDDEN_COUNT = 16
MAX_MEMORY = 600
AWAKE_STEPS = 24
MIN_SLEEP_SECONDS = 2.0


def build_actions():
    actions = []
    for y in (0.10, 0.25, 0.40, 0.55, 0.70, 0.85):
        for x in (0.10, 0.30, 0.50, 0.70, 0.90):
            actions.append((0, x, y, x, y))
    for x in (0.30, 0.50, 0.70):
        actions.append((1, x, 0.72, x, 0.28))
        actions.append((1, x, 0.28, x, 0.72))
    for y in (0.35, 0.65):
        actions.append((1, 0.75, y, 0.25, y))
        actions.append((1, 0.25, y, 0.75, y))
    return actions


ACTIONS = build_actions()


def action_vector(action):
    kind, x1, y1, x2, y2 = action
    return [
        x1 * 2.0 - 1.0,
        y1 * 2.0 - 1.0,
        (x2 - x1) * 2.0,
        (y2 - y1) * 2.0,
        1.0 if kind == 0 else -1.0,
        1.0 if kind == 1 else -1.0,
    ]


ACTION_VECTORS = [action_vector(action) for action in ACTIONS]


class TinyModel:
    def __init__(self, rng=None):
        rng = rng or random.Random()
        self.input_count = FEATURE_COUNT + len(ACTION_VECTORS[0])
        scale = 0.18 / math.sqrt(self.input_count)
        self.w1 = [
            [rng.uniform(-scale, scale) for _ in range(self.input_count)]
            for _ in range(HIDDEN_COUNT)
        ]
        self.b1 = [0.0] * HIDDEN_COUNT
        self.w2 = [rng.uniform(-0.04, 0.04) for _ in range(HIDDEN_COUNT)]
        self.b2 = 0.15

    @staticmethod
    def make_input(features, action_index):
        return [value * 2.0 - 1.0 for value in features] + ACTION_VECTORS[action_index]

    def forward_input(self, values):
        hidden = []
        for row, bias in zip(self.w1, self.b1):
            total = bias
            for weight, value in zip(row, values):
                total += weight * value
            hidden.append(math.tanh(total))
        output = self.b2
        for weight, value in zip(self.w2, hidden):
            output += weight * value
        return output, hidden

    def predict(self, features, action_index):
        return self.forward_input(self.make_input(features, action_index))[0]

    def loss(self, samples):
        if not samples:
            return float("inf")
        total = 0.0
        for features, action_index, target in samples:
            error = self.predict(features, action_index) - target
            total += error * error
        return total / len(samples)

    def train_epoch(self, samples, learning_rate, rng, stopped):
        order = list(range(len(samples)))
        rng.shuffle(order)
        for position, sample_index in enumerate(order):
            if position % 16 == 0 and stopped():
                return False
            features, action_index, target = samples[sample_index]
            values = self.make_input(features, action_index)
            prediction, hidden = self.forward_input(values)
            gradient = max(-2.0, min(2.0, 2.0 * (prediction - target)))
            old_w2 = self.w2[:]
            for hidden_index in range(HIDDEN_COUNT):
                self.w2[hidden_index] -= learning_rate * gradient * hidden[hidden_index]
            self.b2 -= learning_rate * gradient
            for hidden_index in range(HIDDEN_COUNT):
                delta = gradient * old_w2[hidden_index] * (1.0 - hidden[hidden_index] ** 2)
                delta = max(-1.0, min(1.0, delta))
                row = self.w1[hidden_index]
                for input_index, value in enumerate(values):
                    row[input_index] -= learning_rate * delta * value
                self.b1[hidden_index] -= learning_rate * delta
        return True

    def to_dict(self):
        return {"w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2}

    @classmethod
    def from_dict(cls, data):
        model = cls(random.Random(0))
        w1 = data["w1"]
        b1 = data["b1"]
        w2 = data["w2"]
        b2 = data["b2"]
        if (
            len(w1) != HIDDEN_COUNT
            or any(len(row) != model.input_count for row in w1)
            or len(b1) != HIDDEN_COUNT
            or len(w2) != HIDDEN_COUNT
        ):
            raise ValueError("模型尺寸不匹配")
        model.w1 = [[float(value) for value in row] for row in w1]
        model.b1 = [float(value) for value in b1]
        model.w2 = [float(value) for value in w2]
        model.b2 = float(b2)
        return model


def encode_features(features):
    raw = bytes(max(0, min(255, round(value * 255.0))) for value in features)
    return base64.b64encode(raw).decode("ascii")


def decode_features(encoded):
    raw = base64.b64decode(encoded.encode("ascii"), validate=True)
    if len(raw) != FEATURE_COUNT:
        raise ValueError("画面特征尺寸不匹配")
    return [value / 255.0 for value in raw]


class Brain:
    def __init__(self, state_path):
        self.state_path = state_path
        self.rng = random.Random()
        self.model = TinyModel(self.rng)
        self.generation = 0
        self.memory = []
        self.action_counts = [0] * len(ACTIONS)
        self.seen = {}
        self.load()

    def load(self):
        if not os.path.isfile(self.state_path):
            return
        try:
            with open(self.state_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            if int(data.get("version", 0)) != 1:
                raise ValueError("状态文件版本不匹配")
            model = TinyModel.from_dict(data["model"])
            counts = [int(value) for value in data.get("action_counts", [])]
            if len(counts) != len(ACTIONS):
                raise ValueError("动作统计尺寸不匹配")
            memory = []
            for item in data.get("memory", [])[-MAX_MEMORY:]:
                features = decode_features(item[0])
                action_index = int(item[1])
                reward = float(item[2])
                if 0 <= action_index < len(ACTIONS) and math.isfinite(reward):
                    memory.append((features, action_index, max(0.0, min(1.0, reward))))
            seen = {
                str(key): max(1, int(value))
                for key, value in data.get("seen", {}).items()
                if isinstance(key, str)
            }
            self.model = model
            self.generation = max(0, int(data.get("generation", 0)))
            self.action_counts = counts
            self.memory = memory
            self.seen = seen
            print(f"已载入睡眠记忆：第 {self.generation} 代，{len(self.memory)} 条经验。")
        except Exception as error:
            print(f"状态文件无法读取，将从新大脑开始：{error}")

    def save(self):
        if len(self.seen) > 2000:
            keep = sorted(self.seen.items(), key=lambda item: item[1], reverse=True)[:1600]
            self.seen = dict(keep)
        data = {
            "version": 1,
            "generation": self.generation,
            "model": self.model.to_dict(),
            "action_counts": self.action_counts,
            "seen": self.seen,
            "memory": [
                [encode_features(features), action_index, round(reward, 6)]
                for features, action_index, reward in self.memory[-MAX_MEMORY:]
            ],
        }
        temporary_path = self.state_path + ".tmp"
        with open(temporary_path, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, self.state_path)

    def signature(self, features):
        quantized = bytes(max(0, min(15, int(value * 15.999))) for value in features)
        return hashlib.blake2b(quantized, digest_size=8).hexdigest()

    def choose_action(self, features):
        exploration = max(0.10, 0.42 * (0.965 ** self.generation))
        if self.rng.random() < exploration:
            least_used = min(self.action_counts)
            pool = [
                index
                for index, count in enumerate(self.action_counts)
                if count <= least_used + 1
            ]
            return self.rng.choice(pool)
        best_index = 0
        best_score = -float("inf")
        for index, count in enumerate(self.action_counts):
            prediction = self.model.predict(features, index)
            uncertainty = 0.14 / math.sqrt(count + 1.0)
            score = prediction + uncertainty + self.rng.random() * 0.01
            if score > best_score:
                best_index = index
                best_score = score
        return best_index

    def observe(self, before, action_index, after):
        change = sum(abs(left - right) for left, right in zip(before, after)) / len(before)
        signature = self.signature(after)
        visits = self.seen.get(signature, 0)
        novelty = 1.0 / math.sqrt(visits + 1.0)
        effect = min(1.0, change * 6.0)
        reward = min(1.0, effect * 0.84 + novelty * 0.16)
        if change < 0.002:
            reward *= 0.35
        self.seen[signature] = visits + 1
        self.action_counts[action_index] += 1
        self.memory.append((before, action_index, reward))
        if len(self.memory) > MAX_MEMORY:
            del self.memory[: len(self.memory) - MAX_MEMORY]
        return reward, change

    @staticmethod
    def iq_from_loss(loss):
        if not math.isfinite(loss):
            return 0.0
        return 100.0 / (1.0 + loss * 12.0)

    def sleep_and_learn(self, stopped):
        started = time.monotonic()
        if len(self.memory) < 12:
            return None
        validation = [sample for index, sample in enumerate(self.memory) if index % 5 == 0]
        training = [sample for index, sample in enumerate(self.memory) if index % 5 != 0]
        if not training or not validation:
            return None
        old_loss = self.model.loss(validation)
        best_model = self.model
        best_loss = old_loss
        seed = self.generation * 1009 + len(self.memory) * 17
        for learning_rate in (0.012, 0.006, 0.0025):
            candidate = copy.deepcopy(self.model)
            candidate_rng = random.Random(seed + int(learning_rate * 100000))
            for _ in range(5):
                if not candidate.train_epoch(training, learning_rate, candidate_rng, stopped):
                    return False
            candidate_loss = candidate.loss(validation)
            if candidate_loss < best_loss:
                best_model = candidate
                best_loss = candidate_loss
        improved = best_loss + 1e-10 < old_loss
        if improved:
            self.model = best_model
            self.generation += 1
        elapsed = time.monotonic() - started
        return {
            "improved": improved,
            "before": self.iq_from_loss(old_loss),
            "after": self.iq_from_loss(best_loss),
            "remaining": max(0.0, MIN_SLEEP_SECONDS - elapsed),
        }


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", ctypes.c_long),
        ("biHeight", ctypes.c_long),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", ctypes.c_long),
        ("biYPelsPerMeter", ctypes.c_long),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", POINT),
        ("lPrivate", wintypes.DWORD),
    ]


CALLBACK = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)
ENUMPROC = CALLBACK(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
HOOKPROC = CALLBACK(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)


if os.name == "nt":
    USER32 = ctypes.WinDLL("user32", use_last_error=True)
    GDI32 = ctypes.WinDLL("gdi32", use_last_error=True)
    KERNEL32 = ctypes.WinDLL("kernel32", use_last_error=True)
else:
    USER32 = GDI32 = KERNEL32 = None


def configure_windows_api():
    USER32.EnumWindows.argtypes = [ENUMPROC, wintypes.LPARAM]
    USER32.EnumWindows.restype = wintypes.BOOL
    USER32.EnumChildWindows.argtypes = [wintypes.HWND, ENUMPROC, wintypes.LPARAM]
    USER32.EnumChildWindows.restype = wintypes.BOOL
    USER32.IsWindow.argtypes = [wintypes.HWND]
    USER32.IsWindow.restype = wintypes.BOOL
    USER32.IsWindowVisible.argtypes = [wintypes.HWND]
    USER32.IsWindowVisible.restype = wintypes.BOOL
    USER32.IsIconic.argtypes = [wintypes.HWND]
    USER32.IsIconic.restype = wintypes.BOOL
    USER32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    USER32.GetClientRect.restype = wintypes.BOOL
    USER32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    USER32.ClientToScreen.restype = wintypes.BOOL
    USER32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    USER32.GetWindowTextLengthW.restype = ctypes.c_int
    USER32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    USER32.GetWindowTextW.restype = ctypes.c_int
    USER32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    USER32.GetClassNameW.restype = ctypes.c_int
    USER32.GetDC.argtypes = [wintypes.HWND]
    USER32.GetDC.restype = wintypes.HDC
    USER32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
    USER32.ReleaseDC.restype = ctypes.c_int
    USER32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    USER32.GetAncestor.restype = wintypes.HWND
    USER32.WindowFromPoint.argtypes = [POINT]
    USER32.WindowFromPoint.restype = wintypes.HWND
    USER32.SetForegroundWindow.argtypes = [wintypes.HWND]
    USER32.SetForegroundWindow.restype = wintypes.BOOL
    USER32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    USER32.SetCursorPos.restype = wintypes.BOOL
    USER32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    USER32.GetAsyncKeyState.restype = ctypes.c_short
    USER32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    USER32.SetWindowsHookExW.restype = wintypes.HHOOK
    USER32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    USER32.CallNextHookEx.restype = ctypes.c_ssize_t
    USER32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
    USER32.GetMessageW.argtypes = [ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    USER32.GetMessageW.restype = wintypes.BOOL
    USER32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    USER32.TranslateMessage.argtypes = [ctypes.POINTER(MSG)]
    USER32.TranslateMessage.restype = wintypes.BOOL
    USER32.DispatchMessageW.argtypes = [ctypes.POINTER(MSG)]
    USER32.DispatchMessageW.restype = ctypes.c_ssize_t
    USER32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
    GDI32.CreateCompatibleDC.argtypes = [wintypes.HDC]
    GDI32.CreateCompatibleDC.restype = wintypes.HDC
    GDI32.CreateDIBSection.argtypes = [
        wintypes.HDC,
        ctypes.POINTER(BITMAPINFO),
        wintypes.UINT,
        ctypes.POINTER(ctypes.c_void_p),
        wintypes.HANDLE,
        wintypes.DWORD,
    ]
    GDI32.CreateDIBSection.restype = wintypes.HBITMAP
    GDI32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
    GDI32.SelectObject.restype = wintypes.HGDIOBJ
    GDI32.BitBlt.argtypes = [
        wintypes.HDC,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        wintypes.HDC,
        ctypes.c_int,
        ctypes.c_int,
        wintypes.DWORD,
    ]
    GDI32.BitBlt.restype = wintypes.BOOL
    GDI32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
    GDI32.DeleteDC.argtypes = [wintypes.HDC]
    KERNEL32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    KERNEL32.GetModuleHandleW.restype = wintypes.HMODULE
    KERNEL32.GetCurrentThreadId.restype = wintypes.DWORD


def set_dpi_awareness():
    try:
        USER32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)
        except Exception:
            pass


def window_text(hwnd):
    length = USER32.GetWindowTextLengthW(hwnd)
    buffer = ctypes.create_unicode_buffer(max(1, length + 1))
    USER32.GetWindowTextW(hwnd, buffer, len(buffer))
    return buffer.value


def window_class(hwnd):
    buffer = ctypes.create_unicode_buffer(256)
    USER32.GetClassNameW(hwnd, buffer, len(buffer))
    return buffer.value


def client_rect_on_screen(hwnd):
    if not hwnd or not USER32.IsWindow(hwnd) or not USER32.IsWindowVisible(hwnd):
        return None
    root = USER32.GetAncestor(hwnd, 2) or hwnd
    if USER32.IsIconic(root):
        return None
    rectangle = RECT()
    if not USER32.GetClientRect(hwnd, ctypes.byref(rectangle)):
        return None
    origin = POINT(0, 0)
    if not USER32.ClientToScreen(hwnd, ctypes.byref(origin)):
        return None
    width = rectangle.right - rectangle.left
    height = rectangle.bottom - rectangle.top
    if width < 64 or height < 64:
        return None
    return origin.x, origin.y, origin.x + width, origin.y + height


def emulator_score(title, class_name):
    value = (title + " " + class_name).lower()
    score = 0
    for term in ("雷电", "ldplayer", "dnplayer", "leidian", "therender", "android emulator"):
        if term in value:
            score += 10
    return score


def enumerate_top_windows():
    records = []

    @ENUMPROC
    def callback(hwnd, _):
        if not USER32.IsWindowVisible(hwnd):
            return True
        title = window_text(hwnd).strip()
        if not title:
            return True
        rectangle = client_rect_on_screen(hwnd)
        if not rectangle:
            return True
        left, top, right, bottom = rectangle
        width, height = right - left, bottom - top
        if width < 300 or height < 220:
            return True
        class_name = window_class(hwnd)
        records.append(
            {
                "hwnd": int(hwnd),
                "title": title,
                "class": class_name,
                "width": width,
                "height": height,
                "score": emulator_score(title, class_name),
            }
        )
        return True

    USER32.EnumWindows(callback, 0)
    records.sort(key=lambda item: (item["score"], item["width"] * item["height"]), reverse=True)
    return records


def resolve_render_window(outer_hwnd):
    outer_rectangle = client_rect_on_screen(outer_hwnd)
    if not outer_rectangle:
        return None
    outer_area = (outer_rectangle[2] - outer_rectangle[0]) * (outer_rectangle[3] - outer_rectangle[1])
    candidates = []

    @ENUMPROC
    def callback(hwnd, _):
        rectangle = client_rect_on_screen(hwnd)
        if not rectangle:
            return True
        area = (rectangle[2] - rectangle[0]) * (rectangle[3] - rectangle[1])
        value = (window_text(hwnd) + " " + window_class(hwnd)).lower()
        render_score = sum(term in value for term in ("render", "android", "subwin"))
        if render_score and area >= outer_area * 0.20:
            candidates.append((render_score, area, int(hwnd)))
        return True

    USER32.EnumChildWindows(outer_hwnd, callback, 0)
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][2]
    return int(outer_hwnd)


def select_window_and_directory(default_directory):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    result = {"hwnd": None, "directory": None}
    root = tk.Tk()
    root.title("睡眠学习鼠标 AI")
    root.geometry("760x500")
    root.minsize(680, 430)
    root.columnconfigure(0, weight=1)
    root.rowconfigure(2, weight=1)

    ttk.Label(
        root,
        text="选择并确认雷电模拟器窗口。开启后，按键盘上的任意按键即可停止。",
        padding=(12, 12, 12, 8),
    ).grid(row=0, column=0, sticky="ew")

    directory_frame = ttk.Frame(root, padding=(12, 0, 12, 8))
    directory_frame.grid(row=1, column=0, sticky="ew")
    directory_frame.columnconfigure(1, weight=1)
    ttk.Label(directory_frame, text="数据文件夹：").grid(row=0, column=0, sticky="w")
    directory_value = tk.StringVar(value=default_directory)
    ttk.Entry(directory_frame, textvariable=directory_value).grid(row=0, column=1, sticky="ew", padx=6)

    def browse():
        selected = filedialog.askdirectory(initialdir=directory_value.get() or default_directory)
        if selected:
            directory_value.set(selected)

    ttk.Button(directory_frame, text="浏览…", command=browse).grid(row=0, column=2)

    list_frame = ttk.Frame(root, padding=(12, 0, 12, 8))
    list_frame.grid(row=2, column=0, sticky="nsew")
    list_frame.columnconfigure(0, weight=1)
    list_frame.rowconfigure(0, weight=1)
    window_list = tk.Listbox(list_frame, activestyle="dotbox", exportselection=False)
    scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=window_list.yview)
    window_list.configure(yscrollcommand=scrollbar.set)
    window_list.grid(row=0, column=0, sticky="nsew")
    scrollbar.grid(row=0, column=1, sticky="ns")
    records = []

    def refresh():
        nonlocal records
        records = enumerate_top_windows()
        window_list.delete(0, tk.END)
        preferred = None
        for index, item in enumerate(records):
            marker = "[雷电候选] " if item["score"] else ""
            window_list.insert(
                tk.END,
                f'{marker}{item["title"]}  |  {item["class"]}  |  {item["width"]}×{item["height"]}',
            )
            if preferred is None and item["score"]:
                preferred = index
        if records:
            selected_index = preferred if preferred is not None else 0
            window_list.selection_set(selected_index)
            window_list.see(selected_index)

    def confirm():
        selection = window_list.curselection()
        if not selection:
            messagebox.showerror("无法开启", "请先选择一个模拟器窗口。")
            return
        item = records[selection[0]]
        hwnd = item["hwnd"]
        if not client_rect_on_screen(hwnd):
            messagebox.showerror("无法开启", "该窗口已关闭、最小化或不可用，请刷新后重试。")
            return
        raw_directory = directory_value.get().strip()
        if not raw_directory:
            messagebox.showerror("无法开启", "请指定数据文件夹。")
            return
        directory = os.path.abspath(os.path.expandvars(os.path.expanduser(raw_directory)))
        try:
            os.makedirs(directory, exist_ok=True)
            test_path = os.path.join(directory, f".mouse_ai_write_test_{os.getpid()}")
            with open(test_path, "wb") as file:
                file.write(b"ok")
            os.remove(test_path)
        except Exception as error:
            messagebox.showerror("无法开启", f"数据文件夹不可写：\n{error}")
            return
        result["hwnd"] = hwnd
        result["directory"] = directory
        USER32.SetForegroundWindow(hwnd)
        root.destroy()

    button_frame = ttk.Frame(root, padding=(12, 0, 12, 12))
    button_frame.grid(row=3, column=0, sticky="ew")
    ttk.Button(button_frame, text="刷新窗口列表", command=refresh).pack(side="left")
    ttk.Button(button_frame, text="确认窗口并开启 AI", command=confirm).pack(side="right")
    window_list.bind("<Double-Button-1>", lambda _event: confirm())
    refresh()
    root.mainloop()
    return result["hwnd"], result["directory"]


class KeyboardStopper:
    def __init__(self):
        self.event = threading.Event()
        self.ready = threading.Event()
        self.failed = False
        self.thread_id = 0
        self.hook = None
        self.callback = None
        self.thread = None

    @staticmethod
    def any_key_down():
        return any(USER32.GetAsyncKeyState(key) & 0x8000 for key in range(8, 256))

    def start(self):
        while self.any_key_down():
            time.sleep(0.02)
        for key in range(8, 256):
            USER32.GetAsyncKeyState(key)
        self.thread = threading.Thread(target=self._hook_loop, name="keyboard-stop", daemon=True)
        self.thread.start()
        self.ready.wait(2.0)

    def _hook_loop(self):
        self.thread_id = int(KERNEL32.GetCurrentThreadId())

        @HOOKPROC
        def callback(code, message, data):
            if code >= 0:
                if int(message) in (0x0100, 0x0104):
                    self.event.set()
                return 1
            return USER32.CallNextHookEx(self.hook, code, message, data)

        self.callback = callback
        module = KERNEL32.GetModuleHandleW(None)
        self.hook = USER32.SetWindowsHookExW(13, self.callback, module, 0)
        if not self.hook:
            self.failed = True
            self.ready.set()
            return
        self.ready.set()
        message = MSG()
        while USER32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
            USER32.TranslateMessage(ctypes.byref(message))
            USER32.DispatchMessageW(ctypes.byref(message))
        USER32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def stopped(self):
        if self.event.is_set():
            return True
        if self.failed and self.any_key_down():
            self.event.set()
            return True
        return False

    def close(self):
        if self.thread_id and self.hook:
            USER32.PostThreadMessageW(self.thread_id, 0x0012, 0, 0)
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)


def wait_interruptibly(seconds, stopper):
    deadline = time.monotonic() + max(0.0, seconds)
    while time.monotonic() < deadline:
        if stopper.stopped():
            return False
        time.sleep(min(0.02, max(0.0, deadline - time.monotonic())))
    return not stopper.stopped()


def features_from_bgra(pixels, width, height):
    features = [0.0] * FEATURE_COUNT
    for grid_y in range(FEATURE_H):
        for y_fraction in (0.25, 0.50, 0.75):
            y = min(height - 1, int((grid_y + y_fraction) * height / FEATURE_H))
            for grid_x in range(FEATURE_W):
                cell_total = 0.0
                for x_fraction in (0.25, 0.50, 0.75):
                    x = min(width - 1, int((grid_x + x_fraction) * width / FEATURE_W))
                    offset = (y * width + x) * 4
                    blue, green, red = pixels[offset], pixels[offset + 1], pixels[offset + 2]
                    cell_total += (red * 0.299 + green * 0.587 + blue * 0.114) / 255.0
                features[grid_y * FEATURE_W + grid_x] += cell_total / 9.0
    return features


def capture_features(hwnd):
    rectangle = client_rect_on_screen(hwnd)
    if not rectangle:
        return None
    left, top, right, bottom = rectangle
    width, height = right - left, bottom - top
    screen_dc = USER32.GetDC(None)
    if not screen_dc:
        return None
    memory_dc = GDI32.CreateCompatibleDC(screen_dc)
    if not memory_dc:
        USER32.ReleaseDC(None, screen_dc)
        return None
    bitmap = None
    old_object = None
    try:
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        bits = ctypes.c_void_p()
        bitmap = GDI32.CreateDIBSection(screen_dc, ctypes.byref(info), 0, ctypes.byref(bits), None, 0)
        if not bitmap or not bits:
            return None
        old_object = GDI32.SelectObject(memory_dc, bitmap)
        if not GDI32.BitBlt(memory_dc, 0, 0, width, height, screen_dc, left, top, 0x40CC0020):
            return None
        pixels = ctypes.string_at(bits, width * height * 4)
        return features_from_bgra(pixels, width, height)
    finally:
        if old_object:
            GDI32.SelectObject(memory_dc, old_object)
        if bitmap:
            GDI32.DeleteObject(bitmap)
        if memory_dc:
            GDI32.DeleteDC(memory_dc)
        if screen_dc:
            USER32.ReleaseDC(None, screen_dc)


def point_belongs_to_window(x, y, outer_hwnd):
    hit = USER32.WindowFromPoint(POINT(int(x), int(y)))
    if not hit:
        return False
    hit_root = USER32.GetAncestor(hit, 2) or hit
    outer_root = USER32.GetAncestor(outer_hwnd, 2) or outer_hwnd
    return int(hit_root) == int(outer_root)


def normalized_point(target_hwnd, x, y):
    rectangle = client_rect_on_screen(target_hwnd)
    if not rectangle:
        return None
    left, top, right, bottom = rectangle
    margin_x = max(2, int((right - left) * 0.01))
    margin_y = max(2, int((bottom - top) * 0.01))
    screen_x = round(left + margin_x + x * max(1, right - left - margin_x * 2 - 1))
    screen_y = round(top + margin_y + y * max(1, bottom - top - margin_y * 2 - 1))
    return screen_x, screen_y


def execute_action(outer_hwnd, target_hwnd, action_index, stopper):
    kind, x1, y1, x2, y2 = ACTIONS[action_index]
    start = normalized_point(target_hwnd, x1, y1)
    if not start or not point_belongs_to_window(start[0], start[1], outer_hwnd):
        return False
    USER32.SetCursorPos(start[0], start[1])
    if not wait_interruptibly(0.06, stopper):
        return False
    if not point_belongs_to_window(start[0], start[1], outer_hwnd):
        return False
    USER32.mouse_event(0x0002, 0, 0, 0, 0)
    completed = False
    try:
        if kind == 0:
            completed = wait_interruptibly(0.07, stopper)
        else:
            completed = True
            for step in range(1, 13):
                ratio = step / 12.0
                point = normalized_point(
                    target_hwnd,
                    x1 + (x2 - x1) * ratio,
                    y1 + (y2 - y1) * ratio,
                )
                if (
                    not point
                    or not point_belongs_to_window(point[0], point[1], outer_hwnd)
                    or not USER32.SetCursorPos(point[0], point[1])
                    or not wait_interruptibly(0.025, stopper)
                ):
                    completed = False
                    break
    finally:
        USER32.mouse_event(0x0004, 0, 0, 0, 0)
    return completed and not stopper.stopped()


def run_ai(outer_hwnd, data_directory):
    state_path = os.path.join(data_directory, "mouse_ai_state.json")
    brain = Brain(state_path)
    USER32.SetForegroundWindow(outer_hwnd)
    time.sleep(0.20)
    stopper = KeyboardStopper()
    stopper.start()
    print("AI 已开启。按键盘上的任意按键停止。")
    print("控制边界：仅限已确认模拟器的安卓渲染客户区；输入方式仅为鼠标。")
    awake_round = 0
    try:
        while not stopper.stopped():
            if not USER32.IsWindow(outer_hwnd):
                print("模拟器窗口已关闭，AI 停止。")
                break
            target_hwnd = resolve_render_window(outer_hwnd)
            if not target_hwnd:
                if not wait_interruptibly(0.5, stopper):
                    break
                continue
            awake_round += 1
            print(f"[清醒 {awake_round}] 正在观察并仅用鼠标探索。")
            completed_steps = 0
            while completed_steps < AWAKE_STEPS and not stopper.stopped():
                target_hwnd = resolve_render_window(outer_hwnd)
                if not target_hwnd:
                    if not wait_interruptibly(0.4, stopper):
                        break
                    continue
                before = capture_features(target_hwnd)
                if before is None:
                    if not wait_interruptibly(0.4, stopper):
                        break
                    continue
                action_index = brain.choose_action(before)
                if not execute_action(outer_hwnd, target_hwnd, action_index, stopper):
                    if not wait_interruptibly(0.25, stopper):
                        break
                    continue
                if not wait_interruptibly(0.62, stopper):
                    break
                after = capture_features(target_hwnd)
                if after is None:
                    continue
                reward, change = brain.observe(before, action_index, after)
                completed_steps += 1
                if completed_steps % 8 == 0:
                    print(
                        f"  经验 {completed_steps}/{AWAKE_STEPS}，反馈 {reward:.3f}，画面变化 {change:.3f}"
                    )
            if stopper.stopped():
                break
            print("[意识] 经验已达到本轮容量，意识到该睡觉了。")
            print("[睡觉] 正在回放经验并验证新模型；睡眠期间不控制鼠标。")
            report = brain.sleep_and_learn(stopper.stopped)
            if report is False or stopper.stopped():
                break
            if report is None:
                if not wait_interruptibly(MIN_SLEEP_SECONDS, stopper):
                    break
                print("[睡觉] 经验尚少，已整理记忆。")
            else:
                if not wait_interruptibly(report["remaining"], stopper):
                    break
                if report["improved"]:
                    print(
                        f'[睡觉] 验证智力 {report["before"]:.2f} → {report["after"]:.2f}；'
                        f"已接受第 {brain.generation} 代模型。"
                    )
                else:
                    print(
                        f'[睡觉] 候选模型未超过当前验证智力 {report["before"]:.2f}，'
                        "已拒绝退步，能力保持不降。"
                    )
            brain.save()
            print("[清醒] 睡醒，开始下一轮。")
    finally:
        try:
            brain.save()
        except Exception as error:
            print(f"记忆保存失败：{error}")
        stopper.close()
    print("AI 已关闭。")


def main():
    if os.name != "nt":
        raise SystemExit("此程序仅支持 Windows 11。")
    configure_windows_api()
    set_dpi_awareness()
    script_directory = os.path.dirname(os.path.abspath(sys.argv[0]))
    default_directory = os.path.join(script_directory, "AI_Data")
    outer_hwnd, data_directory = select_window_and_directory(default_directory)
    if not outer_hwnd:
        return
    run_ai(outer_hwnd, data_directory)


if __name__ == "__main__":
    main()
