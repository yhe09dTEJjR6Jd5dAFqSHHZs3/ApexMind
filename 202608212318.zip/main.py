import ctypes
import difflib
import hashlib
import importlib
import json
import math
import os
import platform
import queue
import random
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import unicodedata
from ctypes import wintypes
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

APP_NAME = "屏幕数值 AI"
DATA_DIR_NAME = "屏幕数值AI数据"
RAPIDOCR_VERSION = "3.9.2"
AUTOTUNE_SCHEMA = 6

MSS_SPEC = "mss==10.2.0"
DXCAM_SPEC = "dxcam==0.3.0"
COMTYPES_SPEC = "comtypes==1.4.16"
ONNXRUNTIME_CPU_SPEC = "onnxruntime==1.23.0"
ONNXRUNTIME_DML_SPEC = "onnxruntime-directml==1.23.0"
RUNTIME_LOCK = (
    "pyclipper==1.3.0.post6", "opencv-python==4.12.0.88", "numpy==2.2.6",
    "six==1.17.0", "Shapely==2.1.1", "PyYAML==6.0.2", "Pillow==11.3.0",
    "tqdm==4.67.1", "omegaconf==2.3.0", "requests==2.32.4", "colorlog==6.9.0",
    "antlr4-python3-runtime==4.9.3", "charset-normalizer==3.4.2", "idna==3.10",
    "urllib3==2.5.0", "certifi==2025.6.15", "coloredlogs==15.0.1",
    "flatbuffers==25.2.10", "packaging==25.0", "protobuf==6.31.1",
    "sympy==1.14.0", "humanfriendly==10.0", "mpmath==1.3.0", "colorama==0.4.6",
)

def _runtime_fingerprint():
    payload = {
        "python_abi": getattr(sys.implementation, "cache_tag", ""),
        # Wheels are selected by ABI/minor version.  A compatible Python micro
        # update must not force a complete runtime reinstall.
        "python": f"{sys.version_info.major}.{sys.version_info.minor}",
        "rapidocr": RAPIDOCR_VERSION,
        "mss": MSS_SPEC, "dxcam": DXCAM_SPEC, "comtypes": COMTYPES_SPEC,
        "onnx_cpu": ONNXRUNTIME_CPU_SPEC, "onnx_dml": ONNXRUNTIME_DML_SPEC,
        "lock": RUNTIME_LOCK,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

RUNTIME_FINGERPRINT = _runtime_fingerprint()
VK_ESCAPE = 0x1B
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WH_KEYBOARD_LL = 13
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_SCANCODE = 0x0008
MAPVK_VK_TO_VSC = 0
MAPVK_VK_TO_VSC_EX = 4
INPUT_KEYBOARD = 1
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_XDOWN = 0x0080
MOUSEEVENTF_XUP = 0x0100
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x1000
XBUTTON1 = 0x0001
XBUTTON2 = 0x0002
WHEEL_DELTA = 120
SM_REMOTESESSION = 0x1000

@dataclass(frozen=True)
class LearningConfig:
    discount_gamma: float = 0.93
    eligibility_lambda: float = 0.82
    exploration_initial: float = 0.24
    exploration_min: float = 0.03
    exploration_decay_steps: float = 1450.0
    stagnation_medium: int = 15
    stagnation_high: int = 32
    stagnation_extreme: int = 54
    exploration_medium: float = 0.20
    exploration_high: float = 0.36
    exploration_extreme: float = 0.54
    model_discount: float = 0.36
    beam_depth: int = 4
    beam_width: int = 8
    transition_branches: int = 5
    uncertainty_penalty: float = 0.055
    semantic_refresh_steps: int = 5
    semantic_refresh_seconds: float = 2.8

LEARNING_CONFIG = LearningConfig()

@dataclass(frozen=True)
class VisionConfig:
    profile_rows: int = 4
    profile_cols: int = 4
    context_number_limit: int = 10
    context_control_limit: int = 10
    context_semantic_limit: int = 12
    nearby_radius_fraction: float = 0.34

@dataclass(frozen=True)
class DecisionConfig:
    refresh_stagnation: int = 18
    passive_interval_high: int = 22
    passive_interval_balanced: int = 28
    passive_interval_low: int = 36
    decision_log_interval: int = 32
    causal_probe_quality: float = 0.20
    causal_probe_min_passive_rate: float = 0.035
    causal_probe_min_seconds: float = 0.11
    causal_probe_max_seconds: float = 0.32

@dataclass(frozen=True)
class ExplorationConfig:
    key_probe_base: int = 14
    key_probe_stagnation_bonus: int = 24
    key_probe_max: int = 42
    learned_atomic_limit: int = 24
    keyboard_candidate_base: int = 54
    keyboard_candidate_max: int = 84
    mouse_candidate_base: int = 120
    mouse_candidate_max: int = 180
    leaf_rank_limit: int = 20
    leaf_expand_max: int = 6
    inert_miss_weight: float = 0.055
    information_value_weight: float = 0.22
    uncertainty_value_weight: float = 0.30
    desktop_depth: int = 2
    desktop_cold_prior: float = 0.20
    desktop_stagnation_prior_bonus: float = 0.18
    desktop_cold_action_limit: int = 28

@dataclass(frozen=True)
class RelationConfig:
    promotion_evidence: float = 2.35
    target_promotion_evidence: float = 1.35
    promotion_covariance: float = 0.012
    active_factors_per_attribute: int = 24
    candidate_limit: int = 4200
    formal_relation_limit: int = 4200

@dataclass(frozen=True)
class SafetyConfig:
    close_poll_ms: int = 60

@dataclass(frozen=True)
class RuntimeConfig:
    pip_timeout_seconds: int = 480
    runtime_import_probe_timeout_seconds: int = 28
    runtime_mutex_timeout_ms: int = 600000
    runtime_mutex_poll_ms: int = 250
    heartbeat_seconds: float = 1.0
    stalled_notice_seconds: float = 12.0

VISION_CONFIG = VisionConfig()
DECISION_CONFIG = DecisionConfig()
EXPLORATION_CONFIG = ExplorationConfig()
RELATION_CONFIG = RelationConfig()
SAFETY_CONFIG = SafetyConfig()
RUNTIME_CONFIG = RuntimeConfig()

ACTION_EXECUTED = "executed"
ACTION_BLOCKED = "blocked"
ACTION_FAILED = "failed"

WAIT_OBJECT_0 = 0x00000000
WAIT_ABANDONED = 0x00000080
WAIT_TIMEOUT = 0x00000102

NUMBER_ROLES = ("TARGET", "UNKNOWN")

@dataclass
class RuntimeProgress:
    stage: str
    overall: Optional[float]
    title: str
    detail: str = ""
    current_bytes: Optional[int] = None
    total_bytes: Optional[int] = None
    bytes_per_second: Optional[float] = None
    elapsed: float = 0.0
    attempt: int = 1
    indeterminate: bool = False

@dataclass
class FeatureObservation:
    """One producer observation with explicit availability semantics.

    ``observation_state`` prevents sensor failures or skipped samples from being
    learned as a zero delta.  Producers may introduce arbitrary feature names; the
    learner consumes only generic kind/confidence/state metadata.
    """
    value: object = None
    kind: str = "auto"
    confidence: float = 1.0
    observed_at: float = 0.0
    metadata: dict = field(default_factory=dict)
    observation_state: str = "observed"

    VALID_STATES = {
        "observed", "missing", "unavailable", "stale", "sensor_failed",
        "low_confidence", "not_sampled",
    }

    def __post_init__(self):
        if not self.observed_at:
            self.observed_at = time.monotonic()
        try:
            self.confidence = max(0.0, min(1.0, float(self.confidence)))
        except Exception:
            self.confidence = 0.0
        state = str(self.observation_state or "observed").lower()
        if state not in self.VALID_STATES:
            state = "observed"
        if state == "observed" and self.confidence < 0.12:
            state = "low_confidence"
        if state == "observed" and self.value is None:
            state = "missing"
        self.observation_state = state
        if self.kind in ("", "auto", None):
            self.kind = self.infer_kind(self.value)
        self.metadata = dict(self.metadata or {})

    @staticmethod
    def infer_kind(value):
        if value is None:
            return "missing"
        if isinstance(value, bool):
            return "scalar"
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return "scalar"
        if isinstance(value, (tuple, list)):
            numeric = True
            for item in value:
                try:
                    numeric = numeric and math.isfinite(float(item))
                except (TypeError, ValueError, OverflowError):
                    numeric = False
                    break
            return "vector" if numeric else "signature"
        if isinstance(value, str):
            return "category"
        if isinstance(value, dict):
            return "signature"
        return "signature"

    @classmethod
    def from_any(cls, value, name="", confidence=1.0, observed_at=0.0, metadata=None):
        if isinstance(value, cls):
            return value
        if isinstance(value, dict) and "value" in value and "kind" in value:
            return cls(value=value.get("value"), kind=str(value.get("kind") or "auto"),
                       confidence=value.get("confidence", confidence),
                       observed_at=value.get("observed_at", observed_at),
                       metadata=value.get("metadata") or metadata or {},
                       observation_state=value.get("observation_state", value.get("state", "observed")))
        # Feature semantics come only from producer metadata.  The learner never
        # special-cases names such as rotation/hue/phase, so any future periodic
        # scalar can reuse the same generic period handling.
        meta = dict(metadata or {})
        return cls(value=value, confidence=confidence, observed_at=observed_at, metadata=meta)

    @property
    def is_observed(self):
        return self.observation_state == "observed"

    def snapshot(self):
        return {"value": self.value, "kind": self.kind, "confidence": float(self.confidence),
                "observed_at": float(self.observed_at), "metadata": dict(self.metadata),
                "observation_state": self.observation_state}


@dataclass
class FactorObservation:
    """Unified causal/context factor observation for one decision step."""
    observed_at: float = 0.0
    factors: dict = field(default_factory=dict)
    context: dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.observed_at:
            self.observed_at = time.monotonic()
        normalized = {}
        for name, value in dict(self.factors or {}).items():
            normalized[str(name)] = FeatureObservation.from_any(value, name=str(name),
                                                                  observed_at=self.observed_at)
        self.factors = normalized
        self.context = dict(self.context or {})

    def add(self, name, value, kind="auto", confidence=1.0, metadata=None,
            observation_state="observed"):
        self.factors[str(name)] = FeatureObservation(
            value=value, kind=kind, confidence=confidence,
            observed_at=self.observed_at, metadata=dict(metadata or {}),
            observation_state=observation_state)
        return self

    @staticmethod
    def _category_token(value):
        try:
            raw = json.dumps(value, ensure_ascii=True, sort_keys=True,
                             separators=(",", ":"), default=str)
        except Exception:
            raw = repr(value)
        return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:12]

    def items_for_learning(self):
        """Return generic scalar factors; vectors become independent components."""
        result = []
        lazy_count = sum(1 for observation in self.factors.values()
                         if isinstance(observation, FeatureObservation) and
                         bool(observation.metadata.get("lazy", False)))
        divisor = max(1, min(16, int(math.sqrt(max(1, lazy_count))) // 2 + 1))
        phase = int(self.context.get("coverage_phase", 0) or 0) % divisor
        for name, observation in self.factors.items():
            obs = FeatureObservation.from_any(observation, name=name,
                                              observed_at=self.observed_at)
            # Unknown/skipped/failed observations remain in the registry for
            # diagnostics but are never converted into causal samples.
            if obs.observation_state not in {"observed", "low_confidence"}:
                continue
            if bool(obs.metadata.get("lazy", False)):
                slot = int(hashlib.sha1(str(name).encode("utf-8", "replace")).hexdigest()[:8], 16) % divisor
                if slot != phase:
                    continue
            if obs.kind == "scalar":
                try:
                    value = float(obs.value)
                    if math.isfinite(value):
                        scale = float(obs.metadata.get("scale", 1.0) or 1.0)
                        signal = max(-12.0, min(12.0, math.asinh(value / max(1e-9, abs(scale)))))
                        result.append((name, signal, "scalar", float(obs.confidence)))
                except (TypeError, ValueError, OverflowError):
                    continue
            elif obs.kind == "vector" and isinstance(obs.value, (tuple, list)):
                for index, component in enumerate(obs.value):
                    try:
                        value = float(component)
                        if not math.isfinite(value):
                            continue
                    except (TypeError, ValueError, OverflowError):
                        continue
                    scale = float(obs.metadata.get("scale", 1.0) or 1.0)
                    signal = max(-12.0, min(12.0, math.asinh(value / max(1e-9, abs(scale)))))
                    result.append((f"{name}.{index}", signal, "vector_component",
                                   float(obs.confidence)))
            elif obs.kind != "missing":
                token = self._category_token(obs.value)
                result.append((f"{name}={token}", 1.0, obs.kind, float(obs.confidence)))
        return result


class FeatureProducerRegistry:
    """Runtime-extensible feature producer pipeline.

    A producer returns a mapping of arbitrary names to values/FeatureObservation.
    Nested ``visual_features`` mappings are flattened under ``visual.``.  The registry
    remembers features seen from each producer so a later failure becomes an explicit
    ``sensor_failed`` observation instead of silently reusing stale values.
    """

    def __init__(self):
        self._producers = {}
        self._known = {}

    def register(self, name, producer, declared_features=()):
        key = str(name)
        self._producers[key] = producer
        self._known.setdefault(key, set()).update(str(item) for item in declared_features)

    def feature_names(self):
        return tuple(sorted({feature for names in self._known.values() for feature in names}))

    @staticmethod
    def _flatten(payload):
        flat = {}
        for name, value in dict(payload or {}).items():
            if name in {"visual_features", "feature_observations", "__state__"}:
                if name == "visual_features" and isinstance(value, dict):
                    for child, child_value in value.items():
                        flat[f"visual.{child}"] = child_value
                continue
            flat[str(name)] = value
        return flat

    def extract(self, *args, **kwargs):
        merged = {}
        producer_states = {}
        now = time.monotonic()
        for name, producer in tuple(self._producers.items()):
            try:
                payload = producer(*args, **kwargs)
                requested_state = str((payload or {}).get("__state__", "observed")) if isinstance(payload, dict) else "observed"
                flat = self._flatten(payload) if isinstance(payload, dict) else {}
                if not flat and requested_state == "observed":
                    requested_state = "not_sampled"
                state = requested_state if requested_state in FeatureObservation.VALID_STATES else "observed"
                producer_states[name] = state
                self._known.setdefault(name, set()).update(flat)
                for feature_name, raw in flat.items():
                    observation = FeatureObservation.from_any(
                        raw, name=feature_name, observed_at=now,
                        metadata={"producer": name})
                    if state != "observed" and observation.observation_state == "observed":
                        observation.observation_state = state
                    merged[feature_name] = observation
                if state != "observed":
                    for feature_name in self._known.get(name, ()):
                        merged.setdefault(feature_name, FeatureObservation(
                            None, "missing", 0.0, now, {"producer": name}, state))
            except Exception as exc:
                producer_states[name] = "sensor_failed"
                for feature_name in self._known.get(name, ()):
                    merged[feature_name] = FeatureObservation(
                        None, "missing", 0.0, now,
                        {"producer": name, "error": type(exc).__name__}, "sensor_failed")
        return merged, producer_states


class NumberEntity:
    """Identity core plus a true dynamic feature registry.

    Compatibility attribute access (entity.width/entity.rotation/...) is backed by
    ``features`` so existing OCR/Win32 code does not need a second fixed schema.
    """
    _CORE_FIELDS = {"value", "text", "bbox", "confidence", "entity_id", "features"}
    _DEFAULT_FEATURES = {
        "label": "", "unit": "", "role": "UNKNOWN", "direction": "unknown",
        "is_target": False, "source": "ocr", "center": (0.0, 0.0),
        "width": 0.0, "height": 0.0, "foreground_color": None,
        "background_color": None, "contrast": None, "apparent_opacity": None,
        "visibility_hint": None, "rotation": None, "font_scale": None, "quad": (), "present": 1.0,
        "visibility": None, "detection_confidence": None, "occluded": 0.0,
        "first_seen": 0.0, "last_seen": 0.0, "format_signature": "",
        "glyph_signature": "", "window_id": "", "control_id": "",
        "velocity": {}, "changed_attributes": (), "observed_at": 0.0,
    }

    def __init__(self, value, text, bbox, confidence, entity_id="", features=None, **observations):
        object.__setattr__(self, "features", {})
        object.__setattr__(self, "value", float(value))
        object.__setattr__(self, "text", str(text))
        try:
            x1, y1, x2, y2 = (float(v) for v in bbox)
            bbox = (x1, y1, x2, y2)
        except Exception:
            bbox = tuple(bbox or (0.0, 0.0, 0.0, 0.0))
        object.__setattr__(self, "bbox", bbox)
        try:
            confidence = max(0.0, min(1.0, float(confidence)))
        except Exception:
            confidence = 0.0
        object.__setattr__(self, "confidence", confidence)
        object.__setattr__(self, "entity_id", str(entity_id or ""))
        now = time.monotonic()

        merged = {key: (dict(value) if isinstance(value, dict) else list(value) if isinstance(value, list) else value)
                  for key, value in self._DEFAULT_FEATURES.items()}
        merged.update(dict(observations or {}))
        try:
            x1, y1, x2, y2 = self.bbox
            width = max(0.0, x2 - x1)
            height = max(0.0, y2 - y1)
            if not merged.get("width"):
                merged["width"] = width
            if not merged.get("height"):
                merged["height"] = height
            center = merged.get("center")
            if not center or tuple(center) == (0.0, 0.0):
                merged["center"] = ((x1 + x2) * 0.5, (y1 + y2) * 0.5)
        except Exception:
            pass
        if not merged.get("observed_at"):
            merged["observed_at"] = now
        if not merged.get("first_seen"):
            merged["first_seen"] = merged["observed_at"]
        if not merged.get("last_seen"):
            merged["last_seen"] = merged["observed_at"]
        if merged.get("visibility") is None:
            merged["visibility"] = confidence
        if merged.get("detection_confidence") is None:
            merged["detection_confidence"] = confidence
        try:
            if merged.get("quad"):
                merged["quad"] = tuple((float(point[0]), float(point[1]))
                                       for point in merged.get("quad"))
        except Exception:
            merged["quad"] = ()

        visual = merged.pop("visual_features", {}) or {}
        for name, item in merged.items():
            self.set_feature(name, item, confidence=confidence)
        for name, item in dict(visual).items():
            self.set_feature(f"visual.{name}", item, confidence=confidence)
        for name, item in dict(features or {}).items():
            self.features[str(name)] = FeatureObservation.from_any(
                item, name=str(name), confidence=confidence, observed_at=now)

    def set_feature(self, name, value, kind="auto", confidence=None, metadata=None):
        name = str(name)
        previous = self.features.get(name)
        if confidence is None:
            confidence = float(previous.confidence) if isinstance(previous, FeatureObservation) else self.confidence
        if metadata is None and isinstance(previous, FeatureObservation):
            metadata = previous.metadata
        if kind in ("", "auto", None) and isinstance(previous, FeatureObservation):
            kind = previous.kind
        self.features[name] = FeatureObservation.from_any(
            value if not isinstance(value, FeatureObservation) else value,
            name=name, confidence=confidence,
            observed_at=time.monotonic(), metadata=metadata)
        if isinstance(value, FeatureObservation):
            self.features[name] = value
        return self.features[name]

    def feature_observation(self, name):
        """Return one feature through the same typed interface for every producer."""
        observation = self.features.get(str(name))
        if isinstance(observation, FeatureObservation):
            return observation
        if observation is not None:
            return FeatureObservation.from_any(observation, name=str(name))
        return FeatureObservation(
            value=None, kind="missing", confidence=0.0,
            observation_state="missing",
            metadata={"feature": str(name), "reason": "not_registered"},
        )

    def __getattr__(self, name):
        features = object.__getattribute__(self, "features")
        if name == "visual_features":
            return {key[7:]: obs.value for key, obs in features.items()
                    if key.startswith("visual.") and isinstance(obs, FeatureObservation)}
        observation = features.get(name)
        if isinstance(observation, FeatureObservation):
            return observation.value
        if name in self._DEFAULT_FEATURES:
            default = self._DEFAULT_FEATURES[name]
            return dict(default) if isinstance(default, dict) else default
        raise AttributeError(name)

    def __setattr__(self, name, value):
        if name in self._CORE_FIELDS or "features" not in self.__dict__:
            object.__setattr__(self, name, value)
        else:
            self.set_feature(name, value)

    def snapshot(self):
        now = time.monotonic()
        flat = {
            "entity_id": str(self.entity_id), "value": float(self.value),
            "text": str(self.text), "bbox": tuple(self.bbox),
            "confidence": float(self.confidence),
        }
        registry = {}
        visual = {}
        for name, observation in self.features.items():
            obs = FeatureObservation.from_any(observation, name=name, observed_at=now)
            registry[name] = obs.snapshot()
            if name.startswith("visual."):
                visual[name[7:]] = obs.value
            else:
                flat[name] = obs.value
        observed_at = float(flat.get("observed_at") or now)
        first_seen = float(flat.get("first_seen") or observed_at)
        last_seen = float(flat.get("last_seen") or observed_at)
        derived = {
            "age": FeatureObservation(max(0.0, now - first_seen), "scalar", 1.0, now),
            "time_since_seen": FeatureObservation(max(0.0, now - last_seen), "scalar", 1.0, now),
        }
        for name, obs in derived.items():
            flat[name] = obs.value
            registry[name] = obs.snapshot()
        flat["visual_features"] = visual
        flat["features"] = registry
        return flat

@dataclass
class ActionSemantic:
    type: str = "unknown"
    risk: float = 0.25
    confidence: float = 0.0

    def snapshot(self):
        return {
            "type": self.type, "risk": float(self.risk),
            "confidence": float(self.confidence),
        }

if os.name == "nt":
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
else:
    user32 = None
    kernel32 = None

class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

ULONG_PTR = wintypes.WPARAM

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD)]

class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]

def set_dpi_awareness():
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass

def configure_winapi():
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p,
                                         wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT,
                                          wintypes.WPARAM, wintypes.LPARAM]
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
    user32.MapVirtualKeyW.restype = wintypes.UINT
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                   wintypes.DWORD, ULONG_PTR]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.ClientToScreen.restype = wintypes.BOOL
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsWindow.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.IsIconic.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.ShowWindow.restype = wintypes.BOOL
    user32.IsWindowEnabled.argtypes = [wintypes.HWND]
    user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.EnumWindows.restype = wintypes.BOOL
    user32.EnumChildWindows.restype = wintypes.BOOL
    user32.GetForegroundWindow.argtypes = []
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.LPCWSTR]
    kernel32.CreateMutexW.restype = wintypes.HANDLE
    kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    kernel32.WaitForSingleObject.restype = wintypes.DWORD
    kernel32.ReleaseMutex.argtypes = [wintypes.HANDLE]
    kernel32.ReleaseMutex.restype = wintypes.BOOL
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    if hasattr(kernel32, "QueryFullProcessImageNameW"):
        kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                        wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

def screen_dpi():

    if os.name != "nt" or user32 is None:
        return 96
    try:
        if hasattr(user32, "GetDpiForSystem"):
            value = int(user32.GetDpiForSystem())
            if 72 <= value <= 768:
                return value
    except Exception:
        pass
    return 96

def d_drive_path(value):
    try:
        resolved = os.path.realpath(os.path.abspath(str(value)))
        return resolved if os.path.splitdrive(resolved)[0].upper() == "D:" else None
    except Exception:
        return None

GIB = 1024 ** 3

_CPU_SAMPLE_LOCK = threading.Lock()
_CPU_SAMPLE = None

def _filetime_value(value):
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)

def _cpu_load():

    global _CPU_SAMPLE
    if os.name != "nt":
        return None
    try:
        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
            return None
        current = (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
        with _CPU_SAMPLE_LOCK:
            previous, _CPU_SAMPLE = _CPU_SAMPLE, current
        if previous is None:
            return None
        idle_delta = max(0, current[0] - previous[0])
        total_delta = max(1, current[1] - previous[1] + current[2] - previous[2])
        return max(0.0, min(1.0, 1.0 - idle_delta / total_delta))
    except Exception:
        return None

class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

def _total_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullTotalPhys)
    except Exception:
        pass
    return 8 * GIB

def _available_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullAvailPhys)
    except Exception:
        pass
    return 4 * GIB

class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]

def _power_state():

    if os.name != "nt":
        return False, None
    try:
        status = SYSTEM_POWER_STATUS()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            on_battery = int(status.ACLineStatus) == 0
            percent = int(status.BatteryLifePercent)
            if percent > 100:
                percent = None
            return on_battery, percent
    except Exception:
        pass
    return False, None

def _process_cpu_limit():

    logical = max(1, os.cpu_count() or 1)
    if os.name != "nt":
        return logical
    try:
        process = ctypes.windll.kernel32.GetCurrentProcess()
        process_mask = ctypes.c_size_t()
        system_mask = ctypes.c_size_t()
        if ctypes.windll.kernel32.GetProcessAffinityMask(
                process, ctypes.byref(process_mask), ctypes.byref(system_mask)):
            usable = int(process_mask.value).bit_count()
            if usable > 0:
                logical = min(logical, usable)
    except Exception:
        pass
    return max(1, logical)

def _cpu_topology():

    logical = max(1, os.cpu_count() or 1)
    if os.name != "nt":
        return max(1, logical // 2), logical, 0
    script = (
        "Get-CimInstance Win32_Processor | "
        "Select-Object NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed | "
        "ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        data = json.loads(run.stdout.strip()) if run.returncode == 0 and run.stdout.strip() else []
        if isinstance(data, dict):
            data = [data]
        physical = 0
        reported_logical = 0
        clock = 0
        for item in data if isinstance(data, list) else []:
            try:
                physical += max(0, int(item.get("NumberOfCores") or 0))
                reported_logical += max(0, int(item.get("NumberOfLogicalProcessors") or 0))
                clock = max(clock, int(item.get("MaxClockSpeed") or 0))
            except Exception:
                continue
        return max(1, physical or logical // 2), max(logical, reported_logical), max(0, clock)
    except Exception:
        return max(1, logical // 2), logical, 0

def _gpu_info():
    if os.name != "nt":
        return [], 0
    script = (
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM | ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        if run.returncode or not run.stdout.strip():
            return [], 0
        data = json.loads(run.stdout.strip())
        if isinstance(data, dict):
            data = [data]
        names, vram = [], 0
        for item in data if isinstance(data, list) else []:
            name = str(item.get("Name") or "").strip()
            lower = name.lower()
            if not name or "microsoft basic" in lower or "remote display" in lower:
                continue
            names.append(name)
            try:
                vram = max(vram, int(item.get("AdapterRAM") or 0))
            except Exception:
                pass
        return names, vram
    except Exception:
        return [], 0

def _fmt_gib(value):
    return f"{value / GIB:.1f} GB"

class HardwareProfile:
    def __init__(self, storage):
        self.storage = Path(storage)
        self.tuning_path = self.storage / "硬件自适应.json"
        self.architecture = (platform.machine() or
                             os.environ.get("PROCESSOR_ARCHITECTURE") or "unknown").lower()
        self.physical_cores, self.logical_cpus, self.max_clock_mhz = _cpu_topology()
        self.process_cpus = _process_cpu_limit()
        self.logical_cpus = max(1, min(self.logical_cpus, self.process_cpus))
        self.physical_cores = max(1, min(self.physical_cores, self.logical_cpus))
        self.ram = _total_memory()
        self.on_battery, self.battery_percent = _power_state()
        try:
            self.disk_free = shutil.disk_usage(storage).free
        except Exception:
            self.disk_free = 8 * GIB
        self.gpu_names, self.gpu_vram = _gpu_info()
        self.has_gpu = bool(self.gpu_names)
        gpu_text = " ".join(self.gpu_names).lower()
        self.gpu_vendor = ("nvidia" if "nvidia" in gpu_text else
                           "amd" if any(x in gpu_text for x in ("amd", "radeon")) else
                           "intel" if "intel" in gpu_text else "other")
        self.cpu_text = (os.environ.get("PROCESSOR_IDENTIFIER") or "").lower()
        try:
            self.virtual_left = int(user32.GetSystemMetrics(76))
            self.virtual_top = int(user32.GetSystemMetrics(77))
            self.screen_w = max(1, int(user32.GetSystemMetrics(78)))
            self.screen_h = max(1, int(user32.GetSystemMetrics(79)))
            self.monitor_count = max(1, int(user32.GetSystemMetrics(80)))
            self.remote_session = bool(user32.GetSystemMetrics(SM_REMOTESESSION))
        except Exception:
            self.virtual_left, self.virtual_top = 0, 0
            self.screen_w, self.screen_h, self.monitor_count = 1920, 1080, 1
            self.remote_session = False
        self.dxcam_eligible = (
            self.architecture in {"amd64", "x86_64", "x64"}
            and self.monitor_count == 1 and self.virtual_left == 0 and self.virtual_top == 0
            and not self.remote_session and (3, 10) <= sys.version_info[:2] <= (3, 14)
        )
        # Start from one conservative profile. Runtime OCR/capture benchmarks and
        # live_tune() decide the effective class; CPU/RAM/resolution are only hard
        # resource constraints, not a hand-authored capability tier.
        self.tier = "balanced"
        self.want_dml = bool(self.has_gpu and not self.remote_session and self.disk_free >= 2 * GIB)
        self.backend = "dml?" if self.want_dml else "cpu"
        self.capture_backend = "mss"
        self.ocr_threads = max(1, min(4, self.logical_cpus))
        self.settle = 0.38
        self.state_every = 2
        self.candidate_refresh = 16
        self.ocr_variants = 6
        self.verify_reads = 1
        self.visual_shape = (14, 9)
        self.save_interval = 12
        self.rec_model = "small"
        self.det_model = "small"
        self.ensemble = False
        self.min_ocr_variants = 2
        self.max_ocr_variants = 16
        self.latency_target = 0.62
        self.capture_recheck_interval = 105.0
        self.control_text_scan = not self.remote_session
        self.control_scan_side = 960
        self.uncertain_burst_frames = 2
        self.nominal_state_every = self.state_every
        self.nominal_verify_reads = self.verify_reads

        self.nominal_candidate_refresh = self.candidate_refresh
        self.nominal_ocr_variants = self.ocr_variants
        self.nominal_settle = self.settle
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        self.live_adjusted_at = 0.0
        self.cpu_load_ema = 0.45
        self.resource_pressure_ema = 0.35
        self.resource_recovery = 0
        self.cached_threads = None
        self.cached_rec_model = None
        self.preferred_capture = None
        self.dml_tested_at = 0.0
        self.model_tested_at = 0.0
        self._last_persist = 0.0
        self.screen_dpi = 96
        self.screen_scale = 1.0
        self.semantic_emergency_scan = self.tier != "low"
        identity = "|".join((self.architecture, self.cpu_text,
                             str(self.physical_cores), str(self.logical_cpus),
                             ";".join(self.gpu_names), str(self.monitor_count),
                             f"ram{self.ram // GIB}", f"{self.screen_w}x{self.screen_h}",
                             f"py{sys.version_info.major}.{sys.version_info.minor}"))
        self.profile_key = hashlib.sha256(identity.encode("utf-8", "replace")).hexdigest()[:20]
        self._load_tuning()

        self.nominal_ocr_variants = self.ocr_variants

    def _load_tuning(self):

        try:
            data = json.loads(self.tuning_path.read_text(encoding="utf-8"))
            if (int(data.get("schema", 0)) != AUTOTUNE_SCHEMA or
                    data.get("profile") != self.profile_key):
                return
            age = max(0.0, time.time() - float(data.get("saved_at", 0.0)))
            if age > 45 * 86400:
                return
            threads = int(data.get("ocr_threads", 0))
            if 1 <= threads <= self.logical_cpus:
                self.cached_threads = threads
                self.ocr_threads = threads
            capture = str(data.get("capture", "")).lower()
            if capture in {"dxcam", "mss", "pillow"}:
                self.preferred_capture = capture
            variants = int(data.get("ocr_variants", 0))
            if variants:
                self.ocr_variants = max(self.min_ocr_variants,
                                        min(self.max_ocr_variants, variants))
            cached_model = str(data.get("rec_model", "")).lower()
            if cached_model in {"tiny", "small", "medium"}:
                if cached_model != "medium" or self.ram >= 12 * GIB:
                    self.cached_rec_model = cached_model
                    self.rec_model = cached_model
            self.model_tested_at = max(0.0, float(data.get("model_tested_at", 0.0)))
            self.dml_tested_at = max(0.0, float(data.get("dml_tested_at", 0.0)))
            dml_age = max(0.0, time.time() - self.dml_tested_at) if self.dml_tested_at else float("inf")

            if data.get("backend") == "cpu" and dml_age < 14 * 86400:
                self.want_dml = False
                self.backend = "cpu"
        except Exception:
            pass

    def save_tuning(self, force=False):
        now = time.monotonic()
        if not force and now - self._last_persist < 30.0:
            return
        self._last_persist = now
        data = {
            "schema": AUTOTUNE_SCHEMA,
            "profile": self.profile_key,
            "saved_at": time.time(),
            "ocr_threads": int(self.ocr_threads),
            "ocr_variants": int(self.ocr_variants),
            "rec_model": str(self.rec_model),
            "det_model": str(self.det_model),
            "model_tested_at": float(self.model_tested_at),
            "capture": str(self.capture_backend or "mss"),
            "backend": str(self.backend if self.backend in {"cpu", "dml"} else "cpu"),
            "dml_tested_at": float(self.dml_tested_at),
        }
        try:
            temp = self.tuning_path.with_suffix(".tmp")
            temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                            encoding="utf-8")
            os.replace(temp, self.tuning_path)
        except OSError:
            pass

    @property
    def tag(self):
        gpu = self.gpu_vendor if self.want_dml else "cpu"
        return f"{gpu}-{self.tier}-{self.rec_model}"

    def calibrate_runtime(self, ocr_latency, capture_latency):

        self.ocr_latency = max(0.001, float(ocr_latency or 0.25))
        self.capture_latency = max(0.0005, float(capture_latency or 0.02))
        avail = _available_memory()
        pressure = avail / max(1.0, float(self.ram))
        self.on_battery, self.battery_percent = _power_state()
        if self.on_battery:
            self.ocr_variants = min(self.ocr_variants,
                                    min(self.max_ocr_variants, self.min_ocr_variants + 4))
            self.verify_reads = min(self.verify_reads, 1)
        if self.ocr_latency <= 0.16 and self.capture_latency <= 0.035 and pressure >= 0.18 and not self.on_battery:
            self.runtime_class = "极速"
            self.tier = "high"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 4))
            self.verify_reads = max(self.verify_reads, 2)
            self.candidate_refresh = min(self.candidate_refresh, 8)
            self.state_every = 1
            self.settle = min(self.settle, 0.20)
        elif self.ocr_latency <= 0.34 and pressure >= 0.12:
            self.runtime_class = "快速"
            self.tier = "high"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 2))
            self.verify_reads = max(self.verify_reads, 1)
            self.candidate_refresh = min(self.candidate_refresh, 13)
            self.settle = min(self.settle, 0.30)
        elif self.ocr_latency >= 0.85 or pressure < 0.08:
            self.runtime_class = "节能"
            self.tier = "low"
            self.ocr_variants = max(self.min_ocr_variants, min(self.ocr_variants, self.min_ocr_variants + 1))
            self.verify_reads = min(self.verify_reads, 1)
            self.candidate_refresh = max(self.candidate_refresh, 20)
            self.state_every = max(self.state_every, 3)
            self.settle = max(self.settle, min(0.62, self.ocr_latency * 0.46))
        else:
            self.runtime_class = "均衡"
            self.tier = "balanced"

        self.latency_target = max(0.24, min(1.15, self.ocr_latency * 1.75 + self.capture_latency * 1.8))

        if self.on_battery or pressure < 0.09 or self.ocr_latency > 0.72:
            self.control_text_scan = False
        elif self.runtime_class in {"极速", "快速"} and self.tier != "low":
            self.control_text_scan = True
            self.control_scan_side = 1500 if self.runtime_class == "极速" else 1180
        if self.runtime_class == "极速":
            self.uncertain_burst_frames = 3
        elif self.runtime_class == "节能":
            self.uncertain_burst_frames = 2
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        if not self.on_battery and pressure >= 0.10:
            self.nominal_state_every = self.state_every
            self.nominal_verify_reads = self.verify_reads
            self.nominal_candidate_refresh = self.candidate_refresh
            self.nominal_ocr_variants = self.ocr_variants
            self.nominal_settle = self.settle
        self.save_tuning(force=True)

    def live_tune(self, ocr_latency, capture_latency, confidence, fail_rate=0.0):

        now = time.monotonic()
        if now - self.live_adjusted_at < 2.5:
            return False
        self.live_adjusted_at = now
        ocr_latency = max(0.002, float(ocr_latency or self.ocr_latency if hasattr(self, "ocr_latency") else 0.25))
        capture_latency = max(0.0005, float(capture_latency or self.capture_latency if hasattr(self, "capture_latency") else 0.02))
        confidence = max(0.0, min(1.0, float(confidence)))
        fail_rate = max(0.0, min(1.0, float(fail_rate)))
        pressure = _available_memory() / max(1.0, float(self.ram))
        measured_cpu = _cpu_load()
        if measured_cpu is not None:
            self.cpu_load_ema = self.cpu_load_ema * 0.72 + measured_cpu * 0.28
        self.on_battery, self.battery_percent = _power_state()
        changed = False

        memory_stress = max(0.0, min(1.0, (0.16 - pressure) / 0.12))
        cpu_stress = max(0.0, min(1.0, (self.cpu_load_ema - 0.68) / 0.30))
        battery_stress = 0.52 if self.on_battery else 0.0
        instantaneous_stress = max(memory_stress, cpu_stress, battery_stress)
        self.resource_pressure_ema = (self.resource_pressure_ema * 0.76 +
                                      instantaneous_stress * 0.24)
        if self.resource_pressure_ema < 0.30 and not self.on_battery:
            self.resource_recovery = min(12, self.resource_recovery + 1)
        else:
            self.resource_recovery = 0

        measured_target = max(0.22, min(1.25, ocr_latency * 1.70 + capture_latency * 1.7))
        if self.on_battery:
            measured_target = max(measured_target, 0.46)
            self.verify_reads = min(self.verify_reads, 1)
            cap = min(self.max_ocr_variants, self.min_ocr_variants + 4)
            if self.ocr_variants > cap:
                self.ocr_variants -= 1
                changed = True
        self.latency_target = self.latency_target * 0.82 + measured_target * 0.18

        if pressure < 0.065 or self.cpu_load_ema > 0.94:
            new_variants = max(self.min_ocr_variants,
                               min(self.ocr_variants, self.min_ocr_variants + 1))
            if new_variants != self.ocr_variants:
                self.ocr_variants = new_variants
                changed = True
            self.candidate_refresh = max(self.candidate_refresh, 22)
            self.state_every = max(self.state_every, 3)
            self.verify_reads = min(self.verify_reads, 1)
        elif self.cpu_load_ema > 0.84:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.state_every = min(5, self.state_every + 1)
        elif fail_rate >= 0.20 or confidence < 0.62:
            if ocr_latency < self.latency_target * 1.45 and self.ocr_variants < self.max_ocr_variants:
                self.ocr_variants += 1
                changed = True
            if ocr_latency < 0.58 and pressure > 0.12:
                self.verify_reads = max(self.verify_reads, 1)
            self.candidate_refresh = max(5, self.candidate_refresh - 1)
        elif ocr_latency > self.latency_target * 1.65:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.state_every = min(5, self.state_every + 1)
        elif confidence > 0.90 and fail_rate < 0.04 and pressure > 0.14:
            if ocr_latency < self.latency_target * 0.72:
                self.candidate_refresh = max(6, self.candidate_refresh - 1)
                if self.cpu_load_ema < 0.70:
                    self.state_every = max(self.nominal_state_every, self.state_every - 1)
                    if not self.on_battery:
                        self.verify_reads = max(self.verify_reads,
                                                self.nominal_verify_reads)
                if self.ocr_variants < self.max_ocr_variants and confidence < 0.965:
                    self.ocr_variants += 1
                    changed = True

        if self.resource_recovery >= 3:
            if self.candidate_refresh > self.nominal_candidate_refresh:
                self.candidate_refresh -= 1
                changed = True
            elif self.state_every > self.nominal_state_every:
                self.state_every -= 1
                changed = True
            elif self.verify_reads < self.nominal_verify_reads and confidence < 0.94:
                self.verify_reads += 1
                changed = True
            elif (self.ocr_variants < self.nominal_ocr_variants and
                  self.cpu_load_ema < 0.70):
                self.ocr_variants += 1
                changed = True
            elif self.settle > self.nominal_settle:
                self.settle = max(self.nominal_settle, self.settle - 0.015)
                changed = True
            if changed:
                self.resource_recovery = max(0, self.resource_recovery - 2)
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))

        perception_ok = (self.tier != "low" and not self.on_battery and pressure >= 0.105 and
                         self.cpu_load_ema < 0.84 and ocr_latency < 0.70)
        if perception_ok and (self.resource_recovery >= 2 or confidence < 0.88):
            if not self.control_text_scan:
                self.control_text_scan = True
                changed = True
            desired_side = 1460 if self.cpu_load_ema < 0.62 and ocr_latency < 0.30 else 1120
            self.control_scan_side = max(900, min(1500, desired_side))
        elif (self.on_battery or pressure < 0.08 or self.cpu_load_ema > 0.91 or
              ocr_latency > 0.86):
            if self.control_text_scan:
                self.control_text_scan = False
                changed = True
        self.uncertain_burst_frames = (3 if perception_ok and ocr_latency < 0.42 and
                                       self.cpu_load_ema < 0.78 else 2)
        if changed:
            self.save_tuning()
        return changed

    def calibrate_selection(self, rect, screen=None):

        try:
            x1, y1, x2, y2 = (float(v) for v in rect)
            roi_w = max(1.0, x2 - x1)
            roi_h = max(1.0, y2 - y1)
        except Exception:
            return
        self.selection_roi_shape = (int(round(roi_w)), int(round(roi_h)))
        self.screen_dpi = screen_dpi()
        self.screen_scale = max(0.75, min(4.0, self.screen_dpi / 96.0))
        if self.screen_scale >= 1.75:
            self.control_scan_side = min(1600, max(self.control_scan_side, 1180))
        tiny = roi_h <= 24 or min(roi_w, roi_h) <= 16
        small = roi_h <= 42 or min(roi_w, roi_h) <= 26
        very_wide = roi_w / max(1.0, roi_h) >= 16.0
        pressure = _available_memory() / max(1.0, float(self.ram))
        healthy = (pressure >= 0.10 and getattr(self, "cpu_load_ema", 0.45) < 0.88
                   and not self.on_battery)
        if tiny and healthy:
            self.ocr_variants = min(self.max_ocr_variants,
                                    max(self.ocr_variants, self.min_ocr_variants + 5))
            self.verify_reads = max(self.verify_reads, 2)
            self.uncertain_burst_frames = 3
            self.latency_target = max(self.latency_target, 0.46)
        elif small and healthy:
            self.ocr_variants = min(self.max_ocr_variants,
                                    max(self.ocr_variants, self.min_ocr_variants + 3))
            self.verify_reads = max(self.verify_reads, 1)
            self.uncertain_burst_frames = max(2, self.uncertain_burst_frames)
        elif roi_h >= 120 and roi_w >= 460 and self.ocr_variants > self.min_ocr_variants + 2:
            self.ocr_variants -= 1
        if very_wide and healthy:
            self.ocr_variants = min(self.max_ocr_variants, self.ocr_variants + 1)
        if screen:
            try:
                sw, sh = max(1.0, screen[2] - screen[0]), max(1.0, screen[3] - screen[1])
                relative_area = roi_w * roi_h / max(1.0, sw * sh)
                if relative_area < 0.00022 and healthy:
                    self.verify_reads = max(self.verify_reads, 2)
            except Exception:
                pass
        self.nominal_ocr_variants = max(self.nominal_ocr_variants, self.ocr_variants)
        self.nominal_verify_reads = max(self.nominal_verify_reads, self.verify_reads)
        self.save_tuning()

    def summary(self):
        gpu = self.gpu_names[0] if self.gpu_names else "无可用 GPU"
        if len(gpu) > 34:
            gpu = gpu[:33] + "…"
        mode = ("GPU/DirectML" if self.backend == "dml" else
                "CPU" if self.backend == "cpu" else "自动测速 GPU/CPU")
        model = {"tiny": "PP-OCRv6 Tiny", "small": "PP-OCRv6 Small",
                 "medium": "PP-OCRv6 Medium"}.get(self.rec_model, self.rec_model)
        capture = (self.capture_backend or "auto").upper()
        measured = ""
        if hasattr(self, "ocr_latency"):
            measured = (f" · 实测OCR {self.ocr_latency * 1000:.0f}ms"
                        f"/{getattr(self, 'runtime_class', '自适应')}")
        if self.on_battery:
            power = f" · 电池{self.battery_percent}%" if self.battery_percent is not None else " · 电池"
        else:
            power = ""
        core_text = f"{self.physical_cores}核/{self.logical_cpus}线程 CPU"
        session = " · 远程会话" if self.remote_session else ""
        dpi = f" · 屏幕DPI {self.screen_dpi}" if getattr(self, "screen_dpi", 96) != 96 else ""
        return (f"{core_text} · 内存 {_fmt_gib(self.ram)} · "
                f"D盘可用 {_fmt_gib(self.disk_free)} · {gpu}{power}{session} · {mode} · "
                f"OCR {self.ocr_threads}线程 · {model} · 截图 {capture}{dpi}{measured}")

class ScreenCapture:

    def __init__(self, mss_module, image_grab, image_module, dxcam_module=None,
                 preferred=None):
        self.mss_module = mss_module
        self.dxcam_module = dxcam_module
        self.ImageGrab = image_grab
        self.Image = image_module
        self.local = threading.local()
        self._mss_lock = threading.RLock()
        self._mss_instances = {}
        self._dxcam_lock = threading.RLock()
        self._dxcam = None
        self._closed = False
        available = {"pillow"}
        if mss_module is not None:
            available.add("mss")
        if dxcam_module is not None:
            available.add("dxcam")
        default = "mss" if mss_module is not None else "pillow"
        self.backend = preferred if preferred in available else default
        self.preferred = self.backend
        self.latency = 0.02
        self.benchmark_latency = 0.02
        self.last_benchmark = 0.0
        self.failures = {name: 0 for name in available}
        self.cooldown_until = {name: 0.0 for name in available}

    def _instance(self):
        if self.mss_module is None:
            return None
        obj = getattr(self.local, "mss", None)
        if obj is None:
            # with_cursor is Linux-only in MSS and is becoming an error elsewhere.
            obj = self.mss_module.MSS()
            self.local.mss = obj
            with self._mss_lock:
                self._mss_instances[threading.get_ident()] = obj
        return obj

    def _dx_instance(self):
        if self.dxcam_module is None:
            return None
        with self._dxcam_lock:
            if self._closed:
                return None
            if self._dxcam is None:
                try:
                    self._dxcam = self.dxcam_module.create(
                        output_color="RGB", processor_backend="cv2")
                except TypeError:
                    self._dxcam = self.dxcam_module.create(output_color="RGB")
            return self._dxcam

    def _grab_dxcam(self, rect):
        # DXCam owns one camera per process/output.  Creation and grabbing therefore
        # use a process-wide instance rather than a thread-local instance.
        with self._dxcam_lock:
            obj = self._dx_instance()
            if obj is None:
                raise RuntimeError("DXCam unavailable")
            frame = None
            try:
                frame = obj.grab(region=rect, new_frame_only=False)
            except TypeError:
                frame = obj.grab(region=rect)
            if frame is None:
                time.sleep(0.004)
                try:
                    frame = obj.grab(region=rect, new_frame_only=False)
                except TypeError:
                    frame = obj.grab(region=rect)
            if frame is None or getattr(frame, "size", 0) == 0:
                raise RuntimeError("DXCam capture failed")
            image = self.Image.fromarray(frame)
            return image if image.mode == "RGB" else image.convert("RGB")

    def _grab_mss(self, rect):
        obj = self._instance()
        if obj is None:
            raise RuntimeError("MSS unavailable")
        shot = obj.grab(rect)
        try:
            return shot.to_pil("RGB")
        except Exception:
            return self.Image.frombytes("RGB", shot.size, shot.rgb)

    def _grab_pillow(self, rect):
        try:
            return self.ImageGrab.grab(bbox=rect, all_screens=True)
        except TypeError:
            return self.ImageGrab.grab(bbox=rect)

    def _grab_backend(self, name, rect):
        if name == "dxcam":
            return self._grab_dxcam(rect)
        if name == "mss":
            return self._grab_mss(rect)
        return self._grab_pillow(rect)

    def _record_failure(self, name):
        count = min(7, int(self.failures.get(name, 0)) + 1)
        self.failures[name] = count

        self.cooldown_until[name] = time.monotonic() + min(45.0, 0.7 * (2 ** count))

    def _record_success(self, name):
        self.failures[name] = max(0, int(self.failures.get(name, 0)) - 1)
        self.cooldown_until[name] = 0.0

    def benchmark(self, rect=None):

        if rect is None:
            left = int(user32.GetSystemMetrics(76)) if user32 else 0
            top = int(user32.GetSystemMetrics(77)) if user32 else 0
            width = max(320, int(user32.GetSystemMetrics(78))) if user32 else 1920
            height = max(240, int(user32.GetSystemMetrics(79))) if user32 else 1080
            w, h = min(640, width), min(360, height)
            x = left + max(0, (width - w) // 2)
            y = top + max(0, (height - h) // 2)
            rect = (x, y, x + w, y + h)
        rect = tuple(int(round(v)) for v in rect)
        timings = {}
        for name in ("dxcam", "mss", "pillow"):
            if name == "dxcam" and self.dxcam_module is None:
                continue
            if name == "mss" and self.mss_module is None:
                continue
            samples = []
            try:
                self._grab_backend(name, rect)
                for _ in range(4):
                    t0 = time.perf_counter()
                    image = self._grab_backend(name, rect)
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("capture failed")
                    samples.append(time.perf_counter() - t0)
                samples.sort()
                timings[name] = (samples[1] + samples[2]) * 0.5 if len(samples) >= 4 else samples[len(samples) // 2]
                self._record_success(name)
            except Exception:
                self._record_failure(name)
                continue
        if timings:
            fastest = min(timings, key=timings.get)

            old = self.preferred if self.preferred in timings else fastest
            if timings.get(old, float("inf")) <= timings[fastest] * 1.08:
                fastest = old
            self.preferred = fastest
            self.backend = fastest
            self.latency = timings[fastest]
            self.benchmark_latency = timings[fastest]
        self.last_benchmark = time.monotonic()
        return self.backend

    def should_rebenchmark(self, interval=120.0):

        age = time.monotonic() - float(self.last_benchmark or 0.0)
        baseline = max(0.0005, float(self.benchmark_latency or self.latency or 0.02))
        degraded = self.latency > baseline * 2.25 and age > 18.0
        return degraded or age >= max(30.0, float(interval))

    def grab(self, rect):
        if self._closed:
            raise RuntimeError("截图组件已关闭")
        rect = tuple(int(round(v)) for v in rect)
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            raise ValueError("截图区域无效")
        started = time.perf_counter()
        order = [self.preferred] + [x for x in ("dxcam", "mss", "pillow") if x != self.preferred]
        last_error = None
        try:
            for name in order:
                if name == "dxcam" and self.dxcam_module is None:
                    continue
                if name == "mss" and self.mss_module is None:
                    continue
                if (name != self.preferred and
                        time.monotonic() < self.cooldown_until.get(name, 0.0)):
                    continue
                try:
                    image = self._grab_backend(name, rect)
                    if image.width != rect[2] - rect[0] or image.height != rect[3] - rect[1]:

                        expected_w, expected_h = rect[2] - rect[0], rect[3] - rect[1]
                        if image.width >= expected_w and image.height >= expected_h:
                            image = image.crop((0, 0, expected_w, expected_h))
                        else:
                            raise RuntimeError("截图后端返回了错误尺寸")
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("截图后端返回空画面")
                    self._record_success(name)
                    self.backend = name
                    self.preferred = name
                    return image
                except Exception as exc:
                    last_error = exc
                    self._record_failure(name)
            raise last_error or RuntimeError("没有可用的截图后端")
        finally:
            elapsed = max(0.0005, time.perf_counter() - started)
            self.latency = self.latency * 0.88 + elapsed * 0.12

    def close(self):
        """Release process-level DXCam and every thread-local MSS instance."""
        with self._dxcam_lock:
            self._closed = True
            camera = self._dxcam
            self._dxcam = None
            if camera is not None:
                try:
                    camera.release()
                except (AttributeError, OSError, RuntimeError):
                    pass
        with self._mss_lock:
            instances = list({id(obj): obj for obj in self._mss_instances.values()}.values())
            self._mss_instances.clear()
        for instance in instances:
            try:
                instance.close()
            except (AttributeError, OSError, RuntimeError):
                pass
        try:
            self.local.mss = None
        except AttributeError:
            pass

class DFolderDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.current = Path("D:/")
        self.title("选择 D 盘文件夹")
        self.geometry("620x470")
        self.minsize(520, 380)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text="运行数据保存位置（仅限 D 盘）",
                  font=("Microsoft YaHei UI", 14, "bold")).grid(
                      row=0, column=0, sticky="w", padx=18, pady=(18, 8))
        self.path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.path_var, state="readonly").grid(
            row=1, column=0, sticky="ew", padx=18, pady=(0, 8))
        frame = ttk.Frame(self)
        frame.grid(row=2, column=0, sticky="nsew", padx=18)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.listbox = tk.Listbox(frame, font=("Microsoft YaHei UI", 11),
                                  activestyle="dotbox")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.listbox.bind("<Double-Button-1>", self._open_selected)
        self.listbox.bind("<Return>", self._open_selected)
        buttons = ttk.Frame(self)
        buttons.grid(row=3, column=0, sticky="ew", padx=18, pady=18)
        ttk.Button(buttons, text="上一级", command=self._up).pack(side="left")
        ttk.Button(buttons, text="新建文件夹", command=self._new_folder).pack(
            side="left", padx=8)
        ttk.Button(buttons, text="取消", command=self._cancel).pack(side="right")
        ttk.Button(buttons, text="选择当前文件夹", command=self._choose).pack(
            side="right", padx=8)
        if not Path("D:/").is_dir():
            self.after(50, self._no_drive)
        else:
            self._refresh()
        self.grab_set()
        self.focus_force()

    def _no_drive(self):
        messagebox.showerror(APP_NAME, "未检测到 D 盘。", parent=self)
        self._cancel()

    def _refresh(self):
        valid = d_drive_path(self.current)
        if not valid:
            self.current = Path("D:/")
        else:
            self.current = Path(valid)
        self.path_var.set(str(self.current))
        self.listbox.delete(0, "end")
        try:
            names = sorted((e.name for e in os.scandir(self.current)
                            if e.is_dir(follow_symlinks=False)), key=str.lower)
            for name in names:
                self.listbox.insert("end", name)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法读取该文件夹：\n{exc}", parent=self)

    def _open_selected(self, _event=None):
        selected = self.listbox.curselection()
        if not selected:
            return
        candidate = d_drive_path(self.current / self.listbox.get(selected[0]))
        if candidate and Path(candidate).is_dir():
            self.current = Path(candidate)
            self._refresh()

    def _up(self):
        parent = d_drive_path(self.current.parent)
        if parent:
            self.current = Path(parent)
            self._refresh()

    def _new_folder(self):
        name = simpledialog.askstring("新建文件夹", "文件夹名称：", parent=self)
        if not name:
            return
        name = name.strip()
        if (not name or name.endswith((" ", ".")) or
                any(ch in '<>:"/\\|?*' for ch in name)):
            messagebox.showerror(APP_NAME, "文件夹名称无效。", parent=self)
            return
        target = self.current / name
        if not d_drive_path(target):
            return
        try:
            target.mkdir()
            self.current = target
            self._refresh()
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法创建文件夹：\n{exc}", parent=self)

    def _choose(self):
        chosen = d_drive_path(self.current)
        if chosen:
            self.result = Path(chosen)
            self.grab_release()
            self.destroy()

    def _cancel(self):
        self.result = None
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()

class SelectionOverlay(tk.Toplevel):
    def __init__(self, parent, screenshot, candidates, screen, image_tk, callback):
        super().__init__(parent)
        self.callback = callback
        self.candidates = list(candidates)
        self.left, self.top, right, bottom = screen
        self.width, self.height = right - self.left, bottom - self.top
        self.hovered = None
        self.start = None
        self.manual_rect = None
        self.tooltip_bg = None
        self.tooltip_text = None
        self.visuals = []
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg="black", cursor="crosshair")
        self.geometry(f"{self.width}x{self.height}{self.left:+d}{self.top:+d}")
        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0,
                                cursor="crosshair", width=self.width, height=self.height)
        self.canvas.pack(fill="both", expand=True)
        self.photo = image_tk.PhotoImage(screenshot)
        self.canvas.create_image(0, 0, image=self.photo, anchor="nw")
        initial_candidates = list(self.candidates)
        self.candidates = []
        self.add_candidates(initial_candidates)
        banner_width = min(self.width - 30, 780)
        bx1 = (self.width - banner_width) // 2
        bx2 = bx1 + banner_width
        self.canvas.create_rectangle(bx1, 16, bx2, 88, fill="#090d14",
                                     stipple="gray50", outline="#00f5ff", width=2)
        count = len(self.candidates)
        title = (f"已找出 {count} 个数值 · 单击荧光框选择"
                 if count else "OCR 正在后台识别 · 可立即拖动框选")
        self.title_item = self.canvas.create_text(
            self.width // 2, 39, text=title, fill="#dfff00",
            font=("Microsoft YaHei UI", 16, "bold"))
        self.canvas.create_text(
            self.width // 2, 68,
            text="悬停可查看识别结果；遗漏时可直接拖框；ESC 或右键取消",
            fill="white", font=("Microsoft YaHei UI", 10))
        self.canvas.tag_raise("number")
        self.canvas.bind("<Motion>", self._motion)
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<ButtonPress-3>", lambda _e: self._finish(None))
        self.bind("<Escape>", lambda _e: self._finish(None))
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.focus_force()

    @staticmethod
    def _candidate_overlap(a, b):
        ax1, ay1, ax2, ay2 = a
        bx1, by1, bx2, by2 = b
        ix1, iy1 = max(ax1, bx1), max(ay1, by1)
        ix2, iy2 = min(ax2, bx2), min(ay2, by2)
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        if inter <= 0:
            return 0.0
        aa = max(1.0, (ax2 - ax1) * (ay2 - ay1))
        bb = max(1.0, (bx2 - bx1) * (by2 - by1))
        return inter / max(1.0, aa + bb - inter)

    def add_candidates(self, candidates):
        if not self.winfo_exists():
            return
        added = 0
        for candidate in candidates or ():
            try:
                rect, value, confidence, text = candidate
                duplicate = False
                for existing in self.candidates:
                    same_value = (value is not None and existing[1] is not None and
                                  ScoreReader._same_value(value, existing[1]))
                    if self._candidate_overlap(rect, existing[0]) >= (0.46 if same_value else 0.80):
                        duplicate = True
                        break
                if duplicate:
                    continue
                index = len(self.candidates)
                self.candidates.append(candidate)
                x1 = max(0, int(math.floor(rect[0] - self.left - 5)))
                y1 = max(0, int(math.floor(rect[1] - self.top - 5)))
                x2 = min(self.width - 1, int(math.ceil(rect[2] - self.left + 5)))
                y2 = min(self.height - 1, int(math.ceil(rect[3] - self.top + 5)))
                outer = self.canvas.create_rectangle(
                    x1, y1, x2, y2, outline="#00f5ff", width=7,
                    tags=(f"number-{index}", "number"))
                inner = self.canvas.create_rectangle(
                    x1, y1, x2, y2, outline="#dfff00", width=3,
                    tags=(f"number-{index}", "number"))
                self.visuals.append(((x1, y1, x2, y2), outer, inner))
                added += 1
            except Exception:
                continue
        if added and hasattr(self, "title_item"):
            self.canvas.itemconfigure(
                self.title_item,
                text=f"已找出 {len(self.candidates)} 个数值 · 可立即单击选择（OCR 仍在后台继续）")
            self.canvas.tag_raise("number")

    def _hit(self, x, y):
        inside = []
        nearest = None
        nearest_distance = float("inf")
        for index, (rect, _outer, _inner) in enumerate(self.visuals):
            x1, y1, x2, y2 = rect
            area = max(1, (x2 - x1) * (y2 - y1))
            if x1 <= x <= x2 and y1 <= y <= y2:
                inside.append((area, index))
                continue
            dx = max(x1 - x, 0, x - x2)
            dy = max(y1 - y, 0, y - y2)
            distance = dx * dx + dy * dy
            if distance < nearest_distance:
                nearest_distance = distance
                nearest = index
        if inside:
            return min(inside)[1]
        return nearest if nearest_distance <= 14 * 14 else None

    def _set_hover(self, index, x, y):
        if index == self.hovered:
            if index is not None:
                self._show_tooltip(index, x, y)
            return
        if self.hovered is not None:
            _rect, outer, inner = self.visuals[self.hovered]
            self.canvas.itemconfigure(outer, outline="#00f5ff", width=7)
            self.canvas.itemconfigure(inner, outline="#dfff00", width=3)
        self.hovered = index
        if index is not None:
            _rect, outer, inner = self.visuals[index]
            self.canvas.itemconfigure(outer, outline="#ff00f5", width=9)
            self.canvas.itemconfigure(inner, outline="#ffffff", width=3)
            self.canvas.tag_raise(outer)
            self.canvas.tag_raise(inner)
            self._show_tooltip(index, x, y)
        else:
            self._hide_tooltip()

    def _show_tooltip(self, index, x, y):
        self._hide_tooltip()
        _rect, value, confidence, text = self.candidates[index]
        value_text = f"{value:g}" if value is not None else str(text)
        label = f"{value_text}   识别置信度 {confidence * 100:.0f}%"
        tx = min(self.width - 12, max(12, x + 14))
        ty = min(self.height - 16, max(106, y - 20))
        self.tooltip_text = self.canvas.create_text(
            tx, ty, text=label, anchor="sw", fill="#dfff00",
            font=("Microsoft YaHei UI", 11, "bold"))
        bbox = self.canvas.bbox(self.tooltip_text)
        if bbox:
            self.tooltip_bg = self.canvas.create_rectangle(
                bbox[0] - 8, bbox[1] - 5, bbox[2] + 8, bbox[3] + 5,
                fill="#090d14", outline="#00f5ff", width=2)
            self.canvas.tag_lower(self.tooltip_bg, self.tooltip_text)

    def _hide_tooltip(self):
        for item in (self.tooltip_bg, self.tooltip_text):
            if item:
                self.canvas.delete(item)
        self.tooltip_bg = None
        self.tooltip_text = None

    def _motion(self, event):
        if self.start is None:
            self._set_hover(self._hit(event.x, event.y), event.x, event.y)

    def _press(self, event):
        index = self._hit(event.x, event.y)
        if index is not None:
            self._finish(self.candidates[index])
            return
        self.start = (event.x, event.y)
        self._hide_tooltip()
        if self.manual_rect:
            self.canvas.delete(self.manual_rect)
        self.manual_rect = self.canvas.create_rectangle(
            event.x, event.y, event.x, event.y, outline="#ff00f5", width=5)

    def _drag(self, event):
        if self.start and self.manual_rect:
            self.canvas.coords(self.manual_rect, self.start[0], self.start[1],
                               event.x, event.y)

    def _release(self, event):
        if not self.start:
            return
        x1, y1 = self.start
        self.start = None
        x2, y2 = event.x, event.y
        if abs(x2 - x1) < 6 or abs(y2 - y1) < 6:
            if self.manual_rect:
                self.canvas.delete(self.manual_rect)
                self.manual_rect = None
            return
        rect = (min(x1, x2) + self.left, min(y1, y2) + self.top,
                max(x1, x2) + self.left, max(y1, y2) + self.top)
        self._finish((rect, None, 0.0, ""))

    def _finish(self, selection):
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.withdraw()
        self.update_idletasks()
        self.destroy()
        self.callback(selection)

def virtual_screen_rect():
    if os.name != "nt" or user32 is None:
        return (0, 0, 1920, 1080)
    left = int(user32.GetSystemMetrics(76))
    top = int(user32.GetSystemMetrics(77))
    width = max(1, int(user32.GetSystemMetrics(78)))
    height = max(1, int(user32.GetSystemMetrics(79)))
    return (left, top, left + width, top + height)

def window_title(hwnd):
    length = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, len(buf))
    return buf.value or ""

def window_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, len(buf))
    return buf.value

def _normalized_window_title(value):
    text = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
    text = re.sub(r"\b(?:v(?:ersion)?\s*)?\d+(?:[._-]\d+){1,4}\b", "#", text)
    text = re.sub(r"\d+(?:[.,]\d+)?%?", "#", text)
    text = re.sub(r"\s+", " ", text)
    return text[:160]

def environment_identity_for_window(hwnd=0):
    if os.name != "nt" or user32 is None or kernel32 is None:
        return {"exe": "unknown", "exe_hash": "unknown", "class": "unknown",
                "title": "unknown", "hwnd": 0, "pid": 0}
    try:
        hwnd = int(hwnd or 0)
    except Exception:
        hwnd = 0
    cls = ""
    title = ""
    try:
        if hwnd and user32.IsWindow(wintypes.HWND(hwnd)):
            cls = unicodedata.normalize("NFKC", window_class(hwnd)).strip().lower()[:128]
            title = _normalized_window_title(window_title(hwnd))
        else:
            hwnd = 0
    except Exception:
        hwnd = 0
    pid = wintypes.DWORD(0)
    exe_path = ""
    if hwnd:
        try:
            user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
            if handle:
                try:
                    size = wintypes.DWORD(32768)
                    buf = ctypes.create_unicode_buffer(size.value)
                    if (hasattr(kernel32, "QueryFullProcessImageNameW") and
                            kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size))):
                        exe_path = buf.value
                finally:
                    kernel32.CloseHandle(handle)
        except Exception:
            exe_path = ""
    exe_name = Path(exe_path).name.lower() if exe_path else "unknown"
    fingerprint_source = exe_path.lower() if exe_path else exe_name
    exe_hash = ""
    try:
        if exe_path and os.path.isfile(exe_path):
            stat = os.stat(exe_path)
            digest = hashlib.sha256()
            digest.update(str(stat.st_size).encode("ascii", "replace"))
            with open(exe_path, "rb") as handle:
                digest.update(handle.read(65536))
                if stat.st_size > 131072:
                    handle.seek(max(0, stat.st_size - 65536))
                    digest.update(handle.read(65536))
            exe_hash = digest.hexdigest()[:16]
    except Exception:
        exe_hash = ""
    if not exe_hash:
        exe_hash = hashlib.sha256(fingerprint_source.encode("utf-8", "replace")).hexdigest()[:16]
    return {"exe": exe_name or "unknown", "exe_hash": exe_hash,
            "class": cls or "unknown", "title": title or "unknown", "hwnd": hwnd,
            "pid": int(pid.value)}

def foreground_environment_identity():
    hwnd = 0
    if os.name == "nt" and user32 is not None:
        try:
            hwnd = int(user32.GetForegroundWindow() or 0)
        except Exception:
            hwnd = 0
    return environment_identity_for_window(hwnd)

def client_screen_rect(hwnd):
    if os.name != "nt" or user32 is None or not hwnd:
        return None
    try:
        hwnd = wintypes.HWND(int(hwnd))
        if not user32.IsWindow(hwnd) or user32.IsIconic(hwnd):
            return None
        rect = RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        p1, p2 = POINT(rect.left, rect.top), POINT(rect.right, rect.bottom)
        if not user32.ClientToScreen(hwnd, ctypes.byref(p1)):
            return None
        if not user32.ClientToScreen(hwnd, ctypes.byref(p2)):
            return None
        if p2.x - p1.x < 8 or p2.y - p1.y < 8:
            return None
        return (int(p1.x), int(p1.y), int(p2.x), int(p2.y))
    except Exception:
        return None

def top_level_window_at(x, y):
    if os.name != "nt" or user32 is None:
        return 0
    try:
        hwnd = int(user32.WindowFromPoint(POINT(int(x), int(y))) or 0)
        if not hwnd:
            return 0
        root = int(user32.GetAncestor(wintypes.HWND(hwnd), 2) or hwnd)  # GA_ROOT
        return root if user32.IsWindow(wintypes.HWND(root)) else 0
    except Exception:
        return 0

def normalize_digits(text):
    text = str(text)
    superscript = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻", "0123456789+-")

    def expand_superscript(match):
        return "^" + match.group(1).translate(superscript)

    text = re.sub(r"(?<=10)([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)", expand_superscript, text)
    out = []
    for ch in text:
        try:
            out.append(str(unicodedata.digit(ch)))
        except (TypeError, ValueError):
            out.append(ch)
    text = "".join(out)
    text = unicodedata.normalize("NFKC", text)
    # Protect any short alphabetic suffix while OCR-confusion repair is applied to
    # the numeric run.  The parser can then learn target-specific suffixes instead
    # of requiring another programmer-maintained suffix list.
    suffix_tokens = {}

    def protect_suffix(match):
        suffix = match.group(1)
        token = chr(0xE100 + len(suffix_tokens))
        suffix_tokens[token] = suffix
        return token

    text = re.sub(r"(?<=\d)\s*([A-Za-z]{1,8})\b", protect_suffix, text)
    text = (text.replace("−", "-").replace("—", "-").replace("–", "-")
                .replace("＋", "+").replace("，", ",").replace("．", ".")
                .replace("。", ".").replace("·", ".").replace("٫", ".")
                .replace("٬", ",").replace("％", "%").replace("﹪", "%")
                .replace("'", ",").replace("’", ",").replace("`", ",")
                .replace("\u2009", " ").replace("\u202f", " ").replace("\u00a0", " "))
    text = text.translate(str.maketrans({
        "О": "0", "о": "0", "Ο": "0", "ο": "0", "〇": "0", "Ø": "0",
        "Ι": "1", "і": "1", "ı": "1", "ⅼ": "1", "Ƽ": "2", "З": "3",
        "Ч": "4", "б": "6", "Ϭ": "6", "Ց": "9", "﹒": ".", "∙": ".",
    }))
    text = re.sub(r"(?<=\d)[:;](?=\d)", ".", text)

    for _ in range(3):
        before = text
        text = re.sub(r"(?<=\d)[OoＤD](?=\d|[.,])|(?<=[.,])[OoＤD](?=\d)", "0", text)
        text = re.sub(r"(?<=\d)[Il|](?=\d|[.,])|(?<=[.,])[Il|](?=\d)", "1", text)
        text = re.sub(r"(?<=\d)[Ss](?=\d)|(?<=[.,])[Ss](?=\d)", "5", text)
        text = re.sub(r"(?<=\d)[Zz](?=\d)|(?<=[.,])[Zz](?=\d)", "2", text)
        text = re.sub(r"(?<=\d)[Gg](?=\d)|(?<=[.,])[Gg](?=\d)", "6", text)
        text = re.sub(r"(?<=\d)[Bb](?=\d)|(?<=[.,])[Bb](?=\d)", "8", text)
        text = re.sub(r"(?<=\d)[Qq](?=\d)|(?<=[.,])[Qq](?=\d)", "9", text)
        if text == before:
            break

    def fix_numeric_run(match):
        run = match.group(0)
        if not any(ch.isdigit() for ch in run):
            return run
        mapping = {"O": "0", "o": "0", "D": "0", "I": "1", "l": "1", "L": "1", "|": "1",
                   "S": "5", "s": "5", "Z": "2", "z": "2", "G": "6", "g": "6",
                   "B": "8", "b": "8", "Q": "9", "q": "9", "A": "4", "a": "4"}
        chars = list(run)
        for i, ch in enumerate(chars):
            if ch not in mapping:
                continue
            if ch in "BbQq" and i == len(chars) - 1:
                continue
            chars[i] = mapping[ch]
        return "".join(chars)

    text = re.sub(r"[0-9OoDIlL|SsZzGgBbQqAa.,]+", fix_numeric_run, text)
    text = re.sub(r"(?<=\d)\s+(?=\d)", "", text)
    for token, suffix in suffix_tokens.items():
        text = text.replace(token, suffix)
    return text

SCORE_SUFFIX_FACTORS = {
    "": 1.0,
    "k": 1e3, "m": 1e6, "b": 1e9, "t": 1e12, "q": 1e15,
    "qa": 1e15, "qi": 1e18, "sx": 1e21, "sp": 1e24,
    "oc": 1e27, "no": 1e30, "dc": 1e33,
    "mn": 1e6, "bn": 1e9, "tn": 1e12, "tr": 1e12,
    "ki": 1024.0, "mi": 1024.0 ** 2, "gi": 1024.0 ** 3,
    "ti": 1024.0 ** 4,
    "百": 1e2, "千": 1e3, "万": 1e4, "亿": 1e8,
    "万亿": 1e12, "兆": 1e12, "京": 1e16, "垓": 1e20,
    "秭": 1e24, "穰": 1e28, "沟": 1e32, "涧": 1e36,
    "正": 1e40, "载": 1e44, "%": 1.0,
}

SCORE_SUFFIX_RE = (r"(?:万亿|Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|"
                   r"[A-Za-z]{1,8}|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)?")

NUMERIC_SUFFIX_PATTERN = re.compile(
    r"(万亿|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%|[A-Za-z]{1,8})$",
    re.IGNORECASE)

def _mantissa_hypotheses(mantissa, suffix=""):
    raw = mantissa.replace(" ", "")
    if not raw:
        return []
    sign = ""
    if raw[:1] in "+-":
        sign, raw = raw[0], raw[1:]
    if not raw or not any(ch.isdigit() for ch in raw):
        return []
    hypotheses = []

    def add(body, weight):
        body = sign + body
        try:
            value = float(body)
        except ValueError:
            return
        if math.isfinite(value):
            hypotheses.append((value, float(weight)))

    comma, dot = raw.count(","), raw.count(".")
    if comma and dot:
        decimal = "," if raw.rfind(",") > raw.rfind(".") else "."
        grouping = "." if decimal == "," else ","
        add(raw.replace(grouping, "").replace(decimal, "."), 1.00)
        parts = re.split(r"[.,]", raw)
        if len(parts) > 1 and all(len(x) == 3 for x in parts[1:]):
            add("".join(parts), 0.82)
    elif comma or dot:
        sep = "," if comma else "."
        parts = raw.split(sep)
        if len(parts) == 2:
            left, right = parts
            if not right:
                add(left, 0.70)
            elif len(right) <= 2:
                add(left + "." + right, 1.00)
                if sep == "," and len(right) == 2 and len(left) >= 4:
                    add(left + right, 0.68)
            elif len(right) == 3:

                if suffix:
                    add(left + "." + right, 1.00)
                    add(left + right, 0.82)
                elif sep == ".":
                    add(left + "." + right, 1.00)
                    add(left + right, 0.93)
                else:
                    add(left + right, 1.00)
                    add(left + "." + right, 0.91)
            else:
                add(left + "." + right, 0.90)
                add(left + right, 0.78)
        else:
            tail3 = all(len(x) == 3 for x in parts[1:])
            if tail3:
                add("".join(parts), 1.00)

                if len(parts) <= 3:
                    add("".join(parts[:-1]) + "." + parts[-1], 0.69)
            else:
                add("".join(parts[:-1]) + "." + parts[-1], 0.93)
                add("".join(parts), 0.75)
    else:
        add(raw, 1.00)
    unique = {}
    for value, weight in hypotheses:
        key = float(value)
        if weight > unique.get(key, 0.0):
            unique[key] = weight
    return [(value, weight) for value, weight in unique.items()]

def parse_score_candidates(text, suffix_factors=None):
    text = normalize_digits(text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*\^\s*([-+]?\d+)", r"e\1", text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*([-+]\d+)", r"e\1", text)
    text = re.sub(r"(?<![\dxX×*])10\s*\^\s*([-+]?\d+)", r"1e\1", text)
    pattern = re.compile(
        r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
        r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, re.IGNORECASE)
    results = []

    compound_re = re.compile(
        r"[-+]?(?:\d+(?:[.,]\d+)?)\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
        r"(?:\s*\d+(?:[.,]\d+)?\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百))+"
    )
    unit_re = re.compile(
        r"([-+]?\d+(?:[.,]\d+)?)\s*(载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
    )
    for compound in compound_re.finditer(text):
        parts = unit_re.findall(compound.group(0))
        factors = [SCORE_SUFFIX_FACTORS.get(unit, 1.0) for _number, unit in parts]
        if len(parts) < 2 or any(a <= b for a, b in zip(factors, factors[1:])):
            continue
        total = 0.0
        valid = True
        for (number, unit), factor in zip(parts, factors):
            hypotheses = _mantissa_hypotheses(number, unit)
            if not hypotheses:
                valid = False
                break
            base, _weight = max(hypotheses, key=lambda item: item[1])
            total += base * factor
        if valid and math.isfinite(total):
            results.append((total, 1.075, compound.group(0)))

    for match in pattern.finditer(text):
        token = match.group(0).strip()
        if not token:
            continue
        clean = token.replace(" ", "")
        suffix_match = NUMERIC_SUFFIX_PATTERN.search(clean)
        suffix = suffix_match.group(0) if suffix_match else ""
        if suffix_match:
            clean = clean[:suffix_match.start()]
        exp_match = re.search(r"[eE][-+]?\d+$", clean)
        exponent = exp_match.group(0) if exp_match else ""
        mantissa = clean[:-len(exponent)] if exponent else clean
        learned_factors = suffix_factors if isinstance(suffix_factors, dict) else {}
        factor = SCORE_SUFFIX_FACTORS.get(
            suffix, SCORE_SUFFIX_FACTORS.get(
                suffix.lower(), learned_factors.get(str(suffix).lower(), 1.0)))
        digit_count = sum(ch.isdigit() for ch in token)
        token_weight = min(1.08, 0.91 + digit_count * 0.018)
        for base, parse_weight in _mantissa_hypotheses(mantissa, suffix):
            try:
                if exponent:
                    base *= 10.0 ** int(exponent[1:])
                value = base * factor
            except (OverflowError, ValueError):
                continue

            prefix = text[max(0, match.start() - 2):match.start()]
            suffix_text = text[match.end():match.end() + 2]
            if "(" in prefix and ")" in suffix_text and value > 0:
                value = -value
            if math.isfinite(value):
                results.append((value, parse_weight * token_weight, token))

    dedup = {}
    for value, weight, token in results:
        key = float(value)
        old = dedup.get(key)
        if old is None or weight > old[0]:
            dedup[key] = (weight, token)
    return [(value, weight, token) for value, (weight, token) in dedup.items()]

def parse_score(text, suffix_factors=None):
    candidates = parse_score_candidates(text, suffix_factors=suffix_factors)
    if not candidates:
        return None
    value, _weight, _token = max(
        candidates, key=lambda item: (item[1], sum(ch.isdigit() for ch in item[2]), len(item[2])))
    return value

@dataclass
class NumericObservation:
    raw_text: str
    mantissa: float
    suffix: str
    format_signature: dict
    ordinal_scale: Optional[float] = None
    confidence: float = 0.0
    exponent: int = 0

    @property
    def unscaled_value(self):
        try:
            return float(self.mantissa) * (10.0 ** int(self.exponent))
        except (OverflowError, ValueError, TypeError):
            return float(self.mantissa)


def numeric_observation(text, confidence=0.0):
    norm = normalize_digits(text)
    match = re.search(
        r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
        r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE,
        norm, re.IGNORECASE)
    if not match:
        return None
    token = re.sub(r"\s+", "", match.group(0))
    suffix_match = NUMERIC_SUFFIX_PATTERN.search(token)
    suffix = suffix_match.group(0) if suffix_match else ""
    core = token[:suffix_match.start()] if suffix_match else token
    exponent_match = re.search(r"[eE]([-+]?\d+)$", core)
    exponent = int(exponent_match.group(1)) if exponent_match else 0
    mantissa_text = core[:exponent_match.start()] if exponent_match else core
    hypotheses = _mantissa_hypotheses(mantissa_text, suffix)
    if not hypotheses:
        return None
    mantissa, parse_confidence = max(hypotheses, key=lambda item: item[1])
    signature = {
        "suffix": suffix.lower(), "exponent": bool(exponent_match),
        "decimal": any(ch in mantissa_text for ch in ".,"),
        "grouped": len(re.findall(r"[., ]", mantissa_text)) >= 2,
        "digits": sum(ch.isdigit() for ch in mantissa_text),
    }
    known_factor = SCORE_SUFFIX_FACTORS.get(
        suffix, SCORE_SUFFIX_FACTORS.get(str(suffix).lower()))
    ordinal_scale = (math.log10(known_factor) if known_factor and known_factor > 0 else None)
    return NumericObservation(
        raw_text=token, mantissa=float(mantissa), suffix=suffix,
        format_signature=signature, confidence=max(
            0.0, min(1.0, float(confidence or 0.0) * float(parse_confidence))),
        ordinal_scale=ordinal_scale, exponent=exponent)


class NumericScaleGraph:
    """Per-target graph for previously unseen magnitude suffixes."""

    def __init__(self):
        self.factors = {}
        self.transitions = {}
        self.last_suffix = ""
        self.last_value = None

    def factor_values(self):
        values = {}
        for suffix, stat in self.factors.items():
            try:
                factor = float(stat.get("factor", 1.0))
                if factor > 0.0 and math.isfinite(factor):
                    values[str(suffix).lower()] = factor
            except (TypeError, ValueError, OverflowError):
                continue
        return values

    @staticmethod
    def _snap_factor(value):
        value = abs(float(value))
        if not math.isfinite(value) or value <= 0.0:
            return None
        exponent = max(-300, min(300, int(round(math.log10(value)))))
        power = 10.0 ** exponent
        return power if max(value, power) / max(1e-300, min(value, power)) <= 1.55 else value

    def _provisional_factor(self, observation, expected):
        if observation is None or not observation.suffix or expected is None:
            return None
        try:
            base = float(observation.unscaled_value)
            expected = float(expected)
        except (TypeError, ValueError, OverflowError):
            return None
        if not math.isfinite(base) or not math.isfinite(expected) or abs(base) < 1e-300:
            return None
        factor = self._snap_factor(abs(expected / base))
        if factor is None:
            return None
        candidate = math.copysign(abs(base) * factor, base)
        continuity = abs(candidate - expected) / max(1.0, abs(expected), abs(candidate))
        return factor if continuity <= 0.46 else None

    def parse_candidates(self, text, expected=None):
        learned = self.factor_values()
        base_candidates = parse_score_candidates(text, suffix_factors=learned)
        observation = numeric_observation(text, confidence=1.0)
        if observation is None or not observation.suffix:
            return base_candidates
        suffix = observation.suffix.lower()
        if suffix in SCORE_SUFFIX_FACTORS or suffix in learned:
            return base_candidates
        provisional = self._provisional_factor(observation, expected)
        if provisional is None:
            return base_candidates
        try:
            adjusted = float(observation.unscaled_value) * float(provisional)
        except (TypeError, ValueError, OverflowError):
            return base_candidates
        if not math.isfinite(adjusted):
            return base_candidates
        # Retain the unscaled interpretation with lower evidence in case the display
        # really reset; continuity supplies the provisional interpretation.
        revised = [(value, weight * 0.74, token)
                   for value, weight, token in base_candidates]
        revised.append((adjusted, 1.06, observation.raw_text))
        dedup = {}
        for value, weight, token in revised:
            old = dedup.get(float(value))
            if old is None or weight > old[0]:
                dedup[float(value)] = (float(weight), token)
        return [(value, weight, token) for value, (weight, token) in dedup.items()]

    def observe(self, text, resolved_value, confidence):
        if float(confidence or 0.0) < 0.72:
            return
        observation = numeric_observation(text, confidence=confidence)
        if observation is None or not observation.suffix:
            self.last_suffix = ""
            self.last_value = resolved_value
            return
        suffix = observation.suffix.lower()
        if suffix not in SCORE_SUFFIX_FACTORS:
            try:
                base = float(observation.unscaled_value)
                resolved = float(resolved_value)
                raw_factor = abs(resolved / base)
            except (TypeError, ValueError, OverflowError, ZeroDivisionError):
                raw_factor = 0.0
            factor = self._snap_factor(raw_factor) if raw_factor > 0.0 else None
            if factor is not None:
                stat = self.factors.setdefault(suffix, {"factor": factor, "n": 0.0})
                old_n = max(0.0, float(stat.get("n", 0.0)))
                weight = max(0.10, min(1.0, float(confidence)))
                new_n = old_n + weight
                old_factor = max(1e-300, float(stat.get("factor", factor)))
                log_factor = math.log(max(1e-300, factor))
                learned_log = math.log(old_factor) + (
                    log_factor - math.log(old_factor)) * weight / max(1e-9, new_n)
                stat["factor"] = math.exp(max(-690.0, min(690.0, learned_log)))
                stat["n"] = new_n
                stat["ordinal_scale"] = math.log10(max(1e-300, stat["factor"]))
                stat["last_seen"] = int(time.time())
        if self.last_suffix and self.last_suffix != suffix and self.last_value is not None:
            key = f"{self.last_suffix}>{suffix}"
            transition = self.transitions.setdefault(key, {"n": 0.0, "ratio": 1.0})
            try:
                ratio = abs(float(resolved_value)) / max(1e-300, abs(float(self.last_value)))
                n = float(transition.get("n", 0.0)) + 1.0
                transition["ratio"] = float(transition.get("ratio", ratio)) + (
                    ratio - float(transition.get("ratio", ratio))) / n
                transition["n"] = n
            except (TypeError, ValueError, OverflowError):
                pass
        self.last_suffix = suffix
        self.last_value = resolved_value

    def snapshot(self):
        return {"factors": dict(self.factors), "transitions": dict(self.transitions)}

    def load_snapshot(self, payload):
        if not isinstance(payload, dict):
            return
        self.factors = dict(payload.get("factors", {}))
        self.transitions = dict(payload.get("transitions", {}))

class ScoreReader:

    def __init__(self, engines, capture, image_ops, image_module, np_module,
                 cv2_module, max_variants=6, hardware=None):
        self.engines = list(engines)
        self.capture = capture
        self.ImageOps = image_ops
        self.Image = image_module
        self.np = np_module
        self.cv2 = cv2_module
        self.hardware = hardware
        self.max_variants = max(2, int(max_variants))
        if hardware is not None:
            self.max_variants = max(self.max_variants, int(hardware.max_ocr_variants))
            self.min_variants = int(hardware.min_ocr_variants)
            self.latency_target = float(hardware.latency_target)
        else:
            self.min_variants = 2
            self.latency_target = 0.60
        self.active_variants = max(self.min_variants, min(self.max_variants, int(max_variants)))
        self.latency = 0.25
        self.confidence_ema = 0.78
        self.fail_streak = 0
        self.last_value = None
        self.last_confidence = 0.0
        self.last_text = ""
        # Top OCR interpretations from the latest read.  Learning still consumes a
        # scalar for compatibility, but confidence now reflects multimodal ambiguity.
        self.last_distribution = []
        self.recent = []
        self.source_skill = {}
        self.format_history = []
        self.numeric_scale_graph = NumericScaleGraph()
        self._digit_templates = None
        self._letter_templates = None
        self._glyph_bank = None
        self._glyph_bank_centered = None
        self._glyph_bank_norm = None
        self._glyph_label_indices = {}
        self.character_detail_variants = (0 if hardware is not None and hardware.tier == "low"
                                          else (3 if hardware is not None and hardware.tier == "high"
                                                else 2))

    @staticmethod
    def _as_float(value, default=0.5):
        try:
            if isinstance(value, (list, tuple)):
                value = value[0] if value else default
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return default

    def _parse_numeric_candidates(self, text, expected=None):
        return self.numeric_scale_graph.parse_candidates(text, expected=expected)

    def _extract_lines(self, result):
        lines = []
        txts = (result.get("txts") if isinstance(result, dict) else
                getattr(result, "txts", None))
        scores = (result.get("scores") if isinstance(result, dict) else
                  getattr(result, "scores", None))
        if txts is not None:
            try:
                texts = list(txts)
            except TypeError:
                texts = [txts]
            try:
                score_list = list(scores) if scores is not None and not isinstance(
                    scores, (str, bytes, float, int)) else []
            except TypeError:
                score_list = []
            for i, item in enumerate(texts):
                conf = score_list[i] if i < len(score_list) else scores
                if isinstance(item, (tuple, list)):
                    text = item[0] if item else ""
                    if len(item) > 1 and (conf is None or not score_list):
                        conf = item[1]
                elif isinstance(item, dict):
                    text = item.get("text") or item.get("txt") or ""
                    conf = item.get("score", conf)
                else:
                    text = item
                if str(text).strip():
                    lines.append((str(text), self._as_float(conf)))
            if lines:
                return lines
        body = result[0] if isinstance(result, (tuple, list)) and len(result) == 2 else result
        if isinstance(body, (tuple, list)):
            for item in body:
                if isinstance(item, (tuple, list)) and len(item) >= 2:
                    text = item[1]
                    conf = item[2] if len(item) > 2 else 0.5
                    if str(text).strip():
                        lines.append((str(text), self._as_float(conf)))
        return lines

    def _extract_character_lines(self, result):

        body = (result.get("word_results") if isinstance(result, dict) else
                getattr(result, "word_results", None))
        if not body:
            return []
        rows = []

        def collect(node, parts):
            if isinstance(node, dict):
                token = node.get("text") or node.get("txt") or node.get("word")
                confidence = node.get("score", node.get("confidence"))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
                for child in node.values():
                    collect(child, parts)
                return
            if not isinstance(node, (str, bytes, tuple, list)):
                token = (getattr(node, "text", None) or getattr(node, "txt", None) or
                         getattr(node, "word", None))
                confidence = getattr(node, "score", getattr(node, "confidence", None))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
            if (isinstance(node, (tuple, list)) and len(node) >= 2 and
                    isinstance(node[0], str) and
                    not isinstance(node[1], (str, bytes, tuple, list, dict))):
                token = str(node[0])
                if token:
                    parts.append((token, self._as_float(node[1])))
                return
            if isinstance(node, (tuple, list)):
                for child in node:
                    collect(child, parts)

        try:
            outer = list(body) if isinstance(body, (tuple, list)) else [body]
            def is_leaf(node):
                return (isinstance(node, (tuple, list)) and len(node) >= 2 and
                        isinstance(node[0], str) and
                        not isinstance(node[1], (str, bytes, tuple, list, dict)))
            if outer and all(is_leaf(item) for item in outer):
                outer = [outer]
            for row in outer:
                parts = []
                collect(row, parts)
                if parts:
                    text = "".join(token for token, _confidence in parts)

                    mean = sum(conf for _token, conf in parts) / len(parts)
                    floor = min(conf for _token, conf in parts)
                    rows.append((text, max(0.0, min(1.0, mean * 0.72 + floor * 0.28))))
        except Exception:
            return []
        return rows

    def _pad_and_scale(self, image):
        rgb = image.convert("RGB")
        arr = self.np.asarray(rgb)
        if arr.size:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            fill = tuple(int(x) for x in self.np.median(edge, axis=0))
        else:
            fill = (255, 255, 255)
        border = max(4, min(24, int(round(min(rgb.width, rgb.height) * 0.15))))
        rgb = self.ImageOps.expand(rgb, border=border, fill=fill)

        target_h = 96 if rgb.height < 42 else (112 if rgb.height < 72 else
                   128 if rgb.height < 92 else rgb.height)
        scale = max(1.0, min(8.5, target_h / max(1, rgb.height)))
        if scale > 1.03:
            rgb = rgb.resize((max(12, int(round(rgb.width * scale))),
                              max(12, int(round(rgb.height * scale)))),
                             self.Image.Resampling.LANCZOS)
        return rgb

    def _variants(self, image, limit=None):

        source_rgb = image.convert("RGB")
        rgb = self._pad_and_scale(source_rgb)
        hard_limit = self.max_variants if limit is None else max(1, min(self.max_variants, int(limit)))
        yielded = 0

        def emit(arr_or_img, weight, tag):
            nonlocal yielded
            if yielded >= hard_limit:
                return None
            yielded += 1
            if hasattr(arr_or_img, "convert"):
                arr = self.np.asarray(arr_or_img.convert("RGB"))
            else:
                arr = self.np.asarray(arr_or_img)
                if len(arr.shape) == 2:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_GRAY2RGB)
                elif arr.shape[2] == 4:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_RGBA2RGB)
            return arr, weight, tag

        arr = self.np.asarray(rgb)
        gray = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2GRAY)
        try:
            clahe = self.cv2.createCLAHE(clipLimit=2.8, tileGridSize=(4, 4)).apply(gray)
        except Exception:
            clahe = self.cv2.equalizeHist(gray)
        blur = self.cv2.GaussianBlur(clahe, (0, 0), 0.82)
        sharp = self.cv2.addWeighted(clahe, 2.10, blur, -1.10, 0)

        border_separation = None
        try:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            background = self.np.median(edge.astype("float32"), axis=0)
            delta = arr.astype("float32") - background.reshape(1, 1, 3)
            distance = self.np.sqrt((delta * delta).sum(axis=2))
            p90 = float(self.np.percentile(distance, 90.0))
            p995 = float(self.np.percentile(distance, 99.5))
            if p995 >= max(15.0, p90 * 1.18):
                normalized = self.np.clip(distance * (255.0 / max(1.0, p995)),
                                          0, 255).astype("uint8")
                normalized = self.cv2.GaussianBlur(normalized, (0, 0), 0.36)
                border_separation = 255 - normalized
        except Exception:
            border_separation = None

        pixel_view = None
        if source_rgb.height <= 58 and source_rgb.width <= 1200:
            try:
                sample = self.np.asarray(source_rgb.resize(
                    (min(96, max(8, source_rgb.width)), min(48, max(8, source_rgb.height))),
                    self.Image.Resampling.NEAREST))
                palette = len(self.np.unique(sample.reshape(-1, 3), axis=0))
                if palette <= 180:
                    target = 112 if source_rgb.height < 30 else 96
                    scale_px = max(2, min(10, int(round(target / max(1, source_rgb.height)))))
                    pixel_view = source_rgb.resize(
                        (max(12, source_rgb.width * scale_px),
                         max(12, source_rgb.height * scale_px)),
                        self.Image.Resampling.NEAREST)
            except Exception:
                pixel_view = None

        primary = [(rgb, 1.00, "rgb")]
        if pixel_view is not None:
            primary.append((pixel_view, 1.105, "pixel-nearest"))
        primary.extend([(clahe, 1.10, "clahe"), (sharp, 1.11, "sharp")])
        if border_separation is not None:
            primary.append((border_separation, 1.085, "border-color"))
        try:
            _t, otsu = self.cv2.threshold(sharp, 0, 255,
                                          self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            if float(otsu.mean()) < 127:
                otsu = 255 - otsu
            primary.append((otsu, 1.08, "otsu"))
        except Exception:
            otsu = None
        for data, weight, tag in primary:
            item = emit(data, weight, tag)
            if item:
                yield item
            if yielded >= hard_limit:
                return

        try:
            block = max(15, (min(gray.shape) // 4) | 1)
            block = min(71, block if block % 2 else block + 1)
            adaptive = self.cv2.adaptiveThreshold(
                clahe, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                self.cv2.THRESH_BINARY, block, 7)
            if float(adaptive.mean()) < 127:
                adaptive = 255 - adaptive
            item = emit(adaptive, 1.02, "adaptive")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            rgb_channels = list(self.cv2.split(arr))
            chroma = (arr.max(axis=2).astype("int16") -
                      arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            best_channel = max(rgb_channels + [chroma], key=lambda channel: float(channel.std()))
            if float(best_channel.std()) >= max(4.0, float(gray.std()) * 1.08):
                projected = self.cv2.normalize(best_channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(projected, 1.035, "chroma-best")
                if item:
                    yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            for fx, weight, tag in ((1.20, 1.035, "wide"), (0.84, 1.015, "narrow")):
                warped = self.cv2.resize(sharp, None, fx=fx, fy=1.0,
                                         interpolation=self.cv2.INTER_CUBIC if fx > 1 else self.cv2.INTER_AREA)
                item = emit(warped, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            tall = self.cv2.resize(sharp, None, fx=1.0, fy=1.18,
                                   interpolation=self.cv2.INTER_CUBIC)
            item = emit(tall, 1.035, "tall")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        if hard_limit >= 12 and min(gray.shape[:2]) <= 92:
            try:
                border = int(self.np.median(sharp))
                for dx, dy, weight, tag in ((0.50, 0.0, 1.012, "subpx-x"),
                                            (0.0, 0.50, 1.008, "subpx-y")):
                    matrix = self.np.float32([[1, 0, dx], [0, 1, dy]])
                    shifted = self.cv2.warpAffine(
                        sharp, matrix, (sharp.shape[1], sharp.shape[0]),
                        flags=self.cv2.INTER_CUBIC, borderMode=self.cv2.BORDER_CONSTANT,
                        borderValue=border)
                    item = emit(shifted, weight, tag)
                    if item:
                        yield item
                    if yielded >= hard_limit:
                        return
            except Exception:
                pass

        if hard_limit >= 10 and min(gray.shape[:2]) >= 20:
            try:
                center = ((sharp.shape[1] - 1) * 0.5, (sharp.shape[0] - 1) * 0.5)
                border = int(self.np.median(sharp))
                for angle, weight, tag in ((-1.35, 0.995, "rot-"),
                                           (1.35, 0.995, "rot+")):
                    matrix = self.cv2.getRotationMatrix2D(center, angle, 1.0)
                    rotated = self.cv2.warpAffine(
                        sharp, matrix, (sharp.shape[1], sharp.shape[0]),
                        flags=self.cv2.INTER_CUBIC, borderMode=self.cv2.BORDER_CONSTANT,
                        borderValue=border)
                    item = emit(rotated, weight, tag)
                    if item:
                        yield item
                    if yielded >= hard_limit:
                        return
            except Exception:
                pass

        try:
            gamma = self.np.clip((sharp.astype("float32") / 255.0) ** 0.72 * 255.0,
                                 0, 255).astype("uint8")
            item = emit(gamma, 1.025, "gamma")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            inv = 255 - sharp
            item = emit(inv, 1.00, "invert")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            sigma = max(3.0, min(gray.shape) / 18.0)
            background = self.cv2.GaussianBlur(clahe, (0, 0), sigma)
            local = self.cv2.normalize(self.cv2.absdiff(clahe, background), None, 0, 255,
                                       self.cv2.NORM_MINMAX)
            item = emit(local, 1.015, "local")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            kx = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (2, 1))
            ky = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (1, 2))
            closed_x = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, kx)
            closed_y = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, ky)
            for data, weight, tag in ((closed_x, 1.01, "close-x"), (closed_y, 1.005, "close-y")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            kh = max(3, min(15, ((min(gray.shape) // 8) | 1)))
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (kh, kh))
            top = self.cv2.morphologyEx(clahe, self.cv2.MORPH_TOPHAT, kernel)
            black = self.cv2.morphologyEx(clahe, self.cv2.MORPH_BLACKHAT, kernel)
            top = self.cv2.normalize(top, None, 0, 255, self.cv2.NORM_MINMAX)
            black = self.cv2.normalize(black, None, 0, 255, self.cv2.NORM_MINMAX)
            for data, weight, tag in ((top, 0.99, "tophat"), (black, 0.99, "blackhat")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            for gamma, weight, tag in ((0.58, 0.985, "gamma-light"),
                                       (1.72, 0.975, "gamma-dark")):
                lut = self.np.array([((i / 255.0) ** gamma) * 255 for i in range(256)], dtype="uint8")
                item = emit(self.cv2.LUT(clahe, lut), weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            channels = list(self.cv2.split(arr))
            lab = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2LAB)
            hsv = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2HSV)
            chroma = (arr.max(axis=2).astype("int16") - arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            channels += [lab[:, :, 1], lab[:, :, 2], hsv[:, :, 1], chroma]
            ranked_channels = sorted(channels, key=lambda c: float(c.std()), reverse=True)[:2]
            for index, channel in enumerate(ranked_channels):
                channel = self.cv2.normalize(channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(channel, 0.985 if index == 0 else 0.965, f"color{index + 1}")
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

    def _temporal_fusion(self, rect, count=3):

        frames = []
        size = None
        for index in range(max(2, int(count))):
            try:
                image = self.capture.grab(rect).convert("RGB")
                if size is None:
                    size = image.size
                elif image.size != size:
                    image = image.resize(size, self.Image.Resampling.BICUBIC)
                frames.append(self.np.asarray(image, dtype="uint8"))
            except Exception:
                continue
            if index + 1 < count:
                time.sleep(0.008)
        if len(frames) < 2:
            return None
        try:
            base = frames[0]
            base_gray = self.cv2.cvtColor(base, self.cv2.COLOR_RGB2GRAY).astype("float32")
            aligned = [base]
            h, w = base_gray.shape[:2]
            window = self.cv2.createHanningWindow((w, h), self.cv2.CV_32F) if w >= 8 and h >= 8 else None
            for frame in frames[1:]:
                gray = self.cv2.cvtColor(frame, self.cv2.COLOR_RGB2GRAY).astype("float32")
                try:
                    shift, response = self.cv2.phaseCorrelate(base_gray, gray, window)
                    dx, dy = float(shift[0]), float(shift[1])
                    if response >= 0.08 and abs(dx) <= 3.5 and abs(dy) <= 3.5:
                        matrix = self.np.float32([[1, 0, -dx], [0, 1, -dy]])
                        frame = self.cv2.warpAffine(frame, matrix, (w, h), flags=self.cv2.INTER_LINEAR,
                                                    borderMode=self.cv2.BORDER_REPLICATE)
                except Exception:
                    pass
                aligned.append(frame)
            stack = self.np.stack(aligned, axis=0)
            median = self.np.median(stack, axis=0)
            if len(aligned) >= 3:

                sharpest = max(aligned, key=lambda f: float(self.cv2.Laplacian(
                    self.cv2.cvtColor(f, self.cv2.COLOR_RGB2GRAY), self.cv2.CV_32F).var()))
                median = median * 0.82 + sharpest.astype("float32") * 0.18
            fused = self.np.clip(median, 0, 255).astype("uint8")
            image = self.Image.fromarray(fused)
            return image if image.mode == "RGB" else image.convert("RGB")
        except Exception:
            return None

    def _content_crops(self, image):

        try:
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            h, w = rgb.shape[:2]
            if h < 8 or w < 8:
                return []
            edge = self.np.concatenate((rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]), axis=0)
            background = self.np.median(edge.astype("float32"), axis=0)
            difference = self.np.max(self.np.abs(rgb.astype("float32") - background), axis=2)
            threshold = max(8.0, float(self.np.percentile(difference, 72)) * 0.66)
            masks = [(difference >= threshold).astype("uint8") * 255]

            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gradient = self.cv2.magnitude(
                self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3),
                self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3))
            grad_threshold = max(12.0, float(self.np.percentile(gradient, 78)) * 0.62)
            masks.append((gradient >= grad_threshold).astype("uint8") * 255)

            crops, seen = [], set()
            for mask in masks:
                kernel = self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (max(2, min(7, w // 45)), 2))
                mask = self.cv2.morphologyEx(mask, self.cv2.MORPH_CLOSE, kernel)
                contours, _hierarchy = self.cv2.findContours(
                    mask, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
                boxes = []
                for contour in contours:
                    x, y, bw, bh = self.cv2.boundingRect(contour)
                    if bw * bh < max(2, h * w * 0.00010):
                        continue
                    if bh < max(2, h * 0.055) and bw < max(2, w * 0.018):
                        continue
                    boxes.append((x, y, x + bw, y + bh))
                if not boxes:
                    continue
                x1 = min(box[0] for box in boxes)
                y1 = min(box[1] for box in boxes)
                x2 = max(box[2] for box in boxes)
                y2 = max(box[3] for box in boxes)
                px, py = max(2, int(h * 0.05)), max(2, int(h * 0.08))
                bounds = (max(0, x1 - px), max(0, y1 - py),
                          min(w, x2 + px), min(h, y2 + py))
                bw, bh = bounds[2] - bounds[0], bounds[3] - bounds[1]
                if bw < 5 or bh < 5 or (bw >= w * 0.97 and bh >= h * 0.97):
                    continue
                key = tuple(int(v // 2) for v in bounds)
                if key in seen:
                    continue
                seen.add(key)
                crops.append(image.crop(bounds))
            return crops[:2]
        except Exception:
            return []

    def _normalize_glyph(self, mask):

        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            points = self.cv2.findNonZero(binary)
            if points is None:
                return None
            x, y, w, h = self.cv2.boundingRect(points)
            if w < 1 or h < 2:
                return None
            crop = binary[y:y + h, x:x + w]
            target_w, target_h = 22, 30
            scale = min(target_w / max(1.0, float(w)),
                        target_h / max(1.0, float(h)))
            nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
            interpolation = self.cv2.INTER_AREA if scale < 1.0 else self.cv2.INTER_CUBIC
            resized = self.cv2.resize(crop, (nw, nh), interpolation=interpolation)
            canvas = self.np.zeros((34, 26), dtype="uint8")
            ox, oy = (canvas.shape[1] - nw) // 2, (canvas.shape[0] - nh) // 2
            canvas[oy:oy + nh, ox:ox + nw] = resized
            return canvas.astype("float32") / 255.0
        except Exception:
            return None

    def _ensure_digit_templates(self):

        if self._digit_templates is not None:
            return self._digit_templates
        templates = {str(i): [] for i in range(10)}

        letter_templates = {letter: [] for letter in "ABDGIKLMOQSTZ"}
        fonts = tuple(dict.fromkeys((
            self.cv2.FONT_HERSHEY_SIMPLEX, self.cv2.FONT_HERSHEY_DUPLEX,
            self.cv2.FONT_HERSHEY_COMPLEX_SMALL, self.cv2.FONT_HERSHEY_TRIPLEX,
            self.cv2.FONT_HERSHEY_PLAIN,
        )))
        for font in fonts:
            for thickness in (1, 2, 3):
                for digit in templates:
                    canvas = self.np.zeros((76, 58), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(digit, font, scale, thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, digit, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
                for letter in letter_templates:
                    canvas = self.np.zeros((76, 72), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(letter, font, scale, thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, letter, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        letter_templates[letter].append(normalized)

        try:
            from PIL import ImageDraw, ImageFont
            windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
            font_dir = windir / "Fonts"
            font_names = (
                "segoeui.ttf", "segoeuib.ttf", "seguisb.ttf", "segoeuiz.ttf",
                "arial.ttf", "arialbd.ttf", "tahoma.ttf", "tahomabd.ttf",
                "verdana.ttf", "verdanab.ttf", "calibri.ttf", "calibrib.ttf",
                "consola.ttf", "consolab.ttf", "bahnschrift.ttf",
            )
            available = [font_dir / name for name in font_names if (font_dir / name).exists()]

            for font_path in available[:8]:
                for size in (54,):
                    try:
                        font = ImageFont.truetype(str(font_path), size=size)
                    except Exception:
                        continue
                    for char in "0123456789KMBTQ":
                        canvas = self.Image.new("L", (96, 96), 0)
                        draw = ImageDraw.Draw(canvas)
                        try:
                            box = draw.textbbox((0, 0), char, font=font, stroke_width=0)
                            tw, th = max(1, box[2] - box[0]), max(1, box[3] - box[1])
                            x = (96 - tw) // 2 - box[0]
                            y = (96 - th) // 2 - box[1]
                        except Exception:
                            x, y = 16, 12
                        draw.text((x, y), char, fill=255, font=font)
                        normalized = self._normalize_glyph(self.np.asarray(canvas))
                        if normalized is None:
                            continue
                        if char.isdigit():
                            templates[char].append(normalized)
                        else:
                            letter_templates[char].append(normalized)
        except Exception:
            pass

        segment_map = {
            "0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
            "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
        }
        for thickness in (4, 6, 8):
            for segment_width in (28, 36):
                left = (48 - segment_width) // 2
                right = left + segment_width
                for digit, active in segment_map.items():
                    canvas = self.np.zeros((78, 48), dtype="uint8")
                    t = thickness
                    segments = {
                        "a": (left, 5, right, 5 + t),
                        "b": (right - t, 8, right, 38),
                        "c": (right - t, 40, right, 70),
                        "d": (left, 70 - t, right, 70),
                        "e": (left, 40, left + t, 70),
                        "f": (left, 8, left + t, 38),
                        "g": (left, 37 - t // 2, right, 38 + (t + 1) // 2),
                    }
                    for name in active:
                        x1, y1, x2, y2 = segments[name]
                        self.cv2.rectangle(canvas, (x1, y1), (x2, y2), 255, -1)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
        self._digit_templates = templates
        self._letter_templates = letter_templates

        try:
            arrays, labels = [], []
            for label, variants in list(templates.items()) + list(letter_templates.items()):
                for template in variants:
                    arrays.append(template.astype("float32", copy=False).reshape(-1))
                    labels.append(label)
            if arrays:
                bank = self.np.stack(arrays, axis=0).astype("float32", copy=False)
                centered = bank - bank.mean(axis=1, keepdims=True)
                norms = self.np.sqrt((centered * centered).sum(axis=1)) + 1e-6
                indices = {}
                for index, label in enumerate(labels):
                    indices.setdefault(label, []).append(index)
                self._glyph_bank = bank
                self._glyph_bank_centered = centered
                self._glyph_bank_norm = norms
                self._glyph_label_indices = {
                    label: self.np.asarray(items, dtype="int32")
                    for label, items in indices.items()
                }
        except Exception:
            self._glyph_bank = None
        return templates

    def _classify_digit_glyph(self, mask, allow_suffix=False):
        glyph = self._normalize_glyph(mask)
        if glyph is None or float(glyph.mean()) < 0.025:
            return None, 0.0
        self._ensure_digit_templates()
        try:
            bank = self._glyph_bank
            if bank is None or not len(bank):
                return None, 0.0
            flat = glyph.astype("float32", copy=False).reshape(-1)
            centered = flat - float(flat.mean())
            gnorm = math.sqrt(float((centered * centered).sum())) + 1e-6
            corr = (self._glyph_bank_centered @ centered) / (self._glyph_bank_norm * gnorm)
            corr = self.np.clip((corr + 1.0) * 0.5, 0.0, 1.0)
            overlap = self.np.minimum(bank, flat).sum(axis=1)
            union = self.np.maximum(bank, flat).sum(axis=1)
            iou = overlap / self.np.maximum(1e-6, union)
            pixel_similarity = 1.0 - self.np.abs(bank - flat).mean(axis=1)
            scores = 0.54 * corr + 0.30 * iou + 0.16 * pixel_similarity

            def label_score(label):
                indices = self._glyph_label_indices.get(label)
                if indices is None or not len(indices):
                    return 0.0
                return float(scores[indices].max())

            per_digit = sorted(((label_score(str(i)), str(i)) for i in range(10)), reverse=True)
            best, digit = per_digit[0]
            runner = per_digit[1][0]
            margin = best - runner
            letter_scores = sorted(((label_score(letter), letter)
                                    for letter in (self._letter_templates or {})), reverse=True)
            letter_best = letter_scores[0][0] if letter_scores else 0.0

            if allow_suffix:
                suffix_scores = sorted(((label_score(letter), letter) for letter in "KMBTQ"),
                                       reverse=True)
                suffix_best, suffix = suffix_scores[0]
                suffix_runner = suffix_scores[1][0] if len(suffix_scores) > 1 else 0.0

                if (suffix_best >= 0.59 and suffix_best >= best + 0.018 and
                        suffix_best - suffix_runner >= 0.010):
                    conf = min(0.93, 0.25 + suffix_best * 0.68 +
                               (suffix_best - max(best, suffix_runner)) * 1.30)
                    return suffix, max(0.64, conf)

            if letter_best > best + 0.012:
                return None, max(0.0, min(0.70, best))
            if letter_best > best - 0.018:
                margin -= (letter_best - best + 0.018) * 0.72
            confidence = max(0.0, min(0.95, 0.24 + best * 0.69 + margin * 1.60))
            if best < 0.515 or margin < 0.016 or confidence < 0.62:
                return None, confidence
            return digit, confidence
        except Exception:
            return None, 0.0

    def _classical_mask_token(self, mask):

        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            h, w = binary.shape[:2]
            ratio = float((binary > 0).mean())
            if h < 8 or w < 5 or not 0.012 <= ratio <= 0.54:
                return None
            border_ratio = float(self.np.concatenate((
                binary[0], binary[-1], binary[:, 0], binary[:, -1])).mean()) / 255.0
            if border_ratio > 0.58:
                return None
            contours, _ = self.cv2.findContours(
                binary, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            min_area = max(2.0, h * w * 0.00016)
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = float(self.cv2.contourArea(contour))
                if area >= min_area and bw >= 1 and bh >= 1:
                    boxes.append((x, y, bw, bh, area))
            if not boxes:
                return None
            y0 = min(y for _x, y, _bw, _bh, _a in boxes)
            y1 = max(y + bh for _x, y, _bw, bh, _a in boxes)
            line_h = max(1, y1 - y0)
            punctuation = []
            digit_mask = binary.copy()
            for x, y, bw, bh, area in boxes:
                cy = y + bh * 0.5
                small = bh <= line_h * 0.42 and bw <= line_h * 0.34
                if small and cy >= y0 + line_h * 0.62:
                    mark = "," if bh >= max(3, bw * 1.35) else "."
                    punctuation.append((x + bw * 0.5, mark, 0.82))
                    digit_mask[y:y + bh, x:x + bw] = 0
                elif (bh <= line_h * 0.24 and bw >= max(2, bh * 1.8) and
                      y0 + line_h * 0.28 <= cy <= y0 + line_h * 0.72):
                    punctuation.append((x + bw * 0.5, "-", 0.78))
                    digit_mask[y:y + bh, x:x + bw] = 0

            kx = max(1, int(round(line_h * 0.025)))
            ky = max(1, int(round(line_h * 0.025)))
            grouped = self.cv2.dilate(
                digit_mask, self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (kx * 2 + 1, ky * 2 + 1)), iterations=1)
            groups, _ = self.cv2.findContours(
                grouped, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            group_boxes = []
            for contour in groups:
                gx, gy, gw, gh = self.cv2.boundingRect(contour)
                if gh < line_h * 0.34 or gw < max(2, line_h * 0.052):
                    continue

                if gw > line_h * 1.52:
                    return None
                left = max(0, gx + kx - 2)
                top = max(0, gy + ky - 2)
                right = min(w, gx + gw - kx + 2)
                bottom = min(h, gy + gh - ky + 2)
                if right - left >= 1 and bottom - top >= 2:
                    group_boxes.append((left, top, right, bottom))
            group_boxes.sort(key=lambda box: box[0])
            if not group_boxes or len(group_boxes) > 18:
                return None

            glyphs = []
            suffix_seen = False
            for index, (left, top, right, bottom) in enumerate(group_boxes):
                allow_suffix = index == len(group_boxes) - 1 and len(group_boxes) >= 2
                symbol, confidence = self._classify_digit_glyph(
                    digit_mask[top:bottom, left:right], allow_suffix=allow_suffix)
                if symbol is None:
                    return None
                if symbol in "KMBTQ":
                    if not allow_suffix or suffix_seen:
                        return None
                    suffix_seen = True
                glyphs.append(((left + right) * 0.5, symbol, confidence))
            tokens = sorted(glyphs + punctuation, key=lambda item: item[0])
            text = "".join(item[1] for item in tokens)
            if text.count("-") > 1 or ("-" in text and not text.startswith("-")):
                return None
            if text.count(".") + text.count(",") > 2 or not any(
                    ch.isdigit() for ch in text):
                return None
            if any(ch in "KMBTQ" for ch in text[:-1]):
                return None
            if not parse_score_candidates(text):
                return None
            confidences = [item[2] for item in glyphs]
            confidence = min(confidences) * 0.56 + sum(confidences) / len(confidences) * 0.44
            return text, max(0.0, min(0.93, confidence))
        except Exception:
            return None

    def _classical_numeric_candidates(self, image):

        try:
            rgb = self.np.asarray(self._pad_and_scale(image), dtype="uint8")
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gray = self.cv2.GaussianBlur(gray, (3, 3), 0.35)
            masks = []
            threshold_value, otsu = self.cv2.threshold(
                gray, 0, 255, self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            masks.extend((otsu, 255 - otsu))
            threshold_step = max(6.0, float(gray.std()) * 0.16)
            for fixed_value in (threshold_value - threshold_step,
                                threshold_value + threshold_step):
                _fixed_threshold, fixed = self.cv2.threshold(
                    gray, max(1.0, min(254.0, fixed_value)), 255,
                    self.cv2.THRESH_BINARY)
                masks.extend((fixed, 255 - fixed))
            if min(gray.shape[:2]) >= 17:
                block = max(15, min(61, (min(gray.shape[:2]) // 3) | 1))
                adaptive = self.cv2.adaptiveThreshold(
                    gray, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    self.cv2.THRESH_BINARY, block, 5)
                masks.extend((adaptive, 255 - adaptive))
            votes = {}
            for mask in masks:
                recognized = self._classical_mask_token(mask)
                if recognized is None:
                    continue
                token, confidence = recognized
                votes.setdefault(token, []).append(confidence)
            candidates = []
            for token, confidences in votes.items():
                support = len(confidences)
                digits = sum(ch.isdigit() for ch in token)
                required = 3 if digits == 1 else 2
                mean_conf = sum(confidences) / support

                if support < required or mean_conf < (0.84 if digits == 1 else 0.81):
                    continue
                confidence = min(0.91, mean_conf + min(0.08, 0.025 * (support - 1)))
                source_weight = min(0.94, 0.74 + 0.045 * support)
                for value, parse_weight, _parsed_token in parse_score_candidates(token):
                    candidates.append((value, confidence, token,
                                       source_weight * parse_weight,
                                       "classical:digit-templates"))
            return candidates
        except Exception:
            return []

    @staticmethod
    def _tag_variants(variants, prefix):
        return [(array, weight, f"{prefix}-{tag}") for array, weight, tag in variants]

    @staticmethod
    def _same_value(a, b):
        return abs(a - b) <= max(1e-9, max(abs(a), abs(b), 1.0) * 1e-10)

    @staticmethod
    def _text_quality(text):
        norm = normalize_digits(text).strip()
        if not norm:
            return 0.60
        core = NUMERIC_SUFFIX_PATTERN.sub("", norm).strip()
        useful = sum(ch.isdigit() or ch in "+-., eE" for ch in core)
        noise = sum(ch.isalpha() for ch in core)
        ratio = useful / max(1, len(core))
        punctuation = sum(ch in "+-.,eE" for ch in core)
        punct_penalty = max(0, punctuation - 4) * 0.035
        return max(0.55, min(1.10, 0.80 + 0.34 * ratio - 0.075 * noise - punct_penalty))

    @staticmethod
    def _token_signature(text):
        text = normalize_digits(text)
        text = re.sub(r"\s+", "", text)
        dynamic_suffix = ""
        suffix_match = NUMERIC_SUFFIX_PATTERN.search(text)
        if suffix_match:
            dynamic_suffix = suffix_match.group(0).lower()
            text = text[:suffix_match.start()]
        allowed = set("0123456789+-.,eE%百千万亿兆京垓秭穰沟涧正载")
        allowed.update("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        return ("".join(ch for ch in text if ch in allowed) + dynamic_suffix)[:48]

    @staticmethod
    def _format_signature(text):

        norm = normalize_digits(text)
        match = re.search(
            r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
            r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, norm, re.IGNORECASE)
        if not match:
            return None
        token = re.sub(r"\s+", "", match.group(0))
        suffix_match = NUMERIC_SUFFIX_PATTERN.search(token)
        suffix = suffix_match.group(0).lower() if suffix_match else ""
        core = token[:suffix_match.start()] if suffix_match else token
        exponent = bool(re.search(r"[eE][-+]?\d+$", core))
        mantissa = re.split(r"[eE]", core, maxsplit=1)[0]
        digits = sum(ch.isdigit() for ch in mantissa)
        decimal = 1 if ("." in mantissa or "," in mantissa) else 0
        grouped = 1 if len(re.findall(r"[., ]", mantissa)) >= 2 else 0
        signed = 1 if mantissa[:1] in "+-" else 0
        fraction_digits = -1
        separator_at = max(mantissa.rfind("."), mantissa.rfind(","))
        if separator_at >= 0:
            tail_digits = sum(ch.isdigit() for ch in mantissa[separator_at + 1:])

            if 1 <= tail_digits <= 2 or (suffix and 1 <= tail_digits <= 3):
                fraction_digits = tail_digits
        return (suffix, exponent, decimal, grouped, signed, digits, fraction_digits)

    def _format_prior(self, text, value):

        signature = self._format_signature(text)
        history = [item for item in self.format_history[-14:] if item]
        if signature is None or len(history) < 3:
            return 0.0
        suffix, exponent, decimal, grouped, signed, digits, fraction_digits = signature
        score = 0.0

        def mode(index):
            counts = {}
            for item in history:
                key = item[index]
                counts[key] = counts.get(key, 0) + 1
            return max(counts.items(), key=lambda kv: kv[1]) if counts else (None, 0)

        suffix_mode, suffix_n = mode(0)
        exponent_mode, exponent_n = mode(1)
        decimal_mode, decimal_n = mode(2)
        grouped_mode, grouped_n = mode(3)
        signed_mode, signed_n = mode(4)
        fraction_mode, fraction_n = mode(6)
        digit_values = sorted(int(item[5]) for item in history)
        median_digits = digit_values[len(digit_values) // 2]
        stability = len(history)
        jump = 1.0
        if self.last_value is not None:
            jump = max(abs(value), abs(self.last_value), 1.0) / max(1e-9, min(
                max(abs(value), 1e-9), max(abs(self.last_value), 1e-9)))

        suffix_transition = False
        if suffix != suffix_mode and suffix and suffix_mode and self.last_value is not None:
            learned_factors = self.numeric_scale_graph.factor_values()
            old_factor = SCORE_SUFFIX_FACTORS.get(
                str(suffix_mode).lower(), learned_factors.get(str(suffix_mode).lower()))
            new_factor = SCORE_SUFFIX_FACTORS.get(
                str(suffix).lower(), learned_factors.get(str(suffix).lower()))
            if old_factor and new_factor:
                factor_ratio = max(old_factor, new_factor) / max(1e-12, min(old_factor, new_factor))
                continuity = max(abs(value), abs(self.last_value), 1.0) / max(
                    1e-9, min(max(abs(value), 1e-9), max(abs(self.last_value), 1e-9)))
                suffix_transition = factor_ratio <= 10000.0 and continuity <= 2.4
        if suffix_n >= max(3, int(stability * 0.64)):
            if suffix == suffix_mode:
                score += 0.075
            elif not suffix_transition and jump < 120.0:
                score -= 0.085
        if exponent_n >= max(3, int(stability * 0.72)):
            score += 0.040 if exponent == exponent_mode else (-0.045 if jump < 80.0 else 0.0)
        if decimal_n >= max(3, int(stability * 0.72)):
            score += 0.035 if decimal == decimal_mode else (
                -0.035 if jump < 30.0 and not suffix_transition else 0.0)
        if grouped_n >= max(3, int(stability * 0.78)):
            score += 0.018 if grouped == grouped_mode else -0.015
        if signed_n >= max(3, int(stability * 0.80)) and signed != signed_mode and jump < 20.0:
            score -= 0.025
        if fraction_n >= max(3, int(stability * 0.72)) and int(fraction_mode) >= 0:
            if int(signature[6]) == int(fraction_mode):
                score += 0.030
            elif not suffix_transition and jump < 40.0:
                score -= 0.030
        digit_gap = abs(int(digits) - int(median_digits))
        if digit_gap <= 1:
            score += 0.028
        elif digit_gap >= 3 and jump < 250.0:
            score -= min(0.080, 0.025 * digit_gap)
        return max(-0.16, min(0.14, score))

    def _format_repair_candidates(self, text, expected=None):

        history = [item for item in self.format_history[-14:] if item]
        if len(history) < 5:
            return []

        def mode(index):
            counts = {}
            for item in history:
                key = item[index]
                counts[key] = counts.get(key, 0) + 1
            return max(counts.items(), key=lambda kv: kv[1]) if counts else (None, 0)

        suffix_mode, suffix_n = mode(0)
        fraction_mode, fraction_n = mode(6)
        stable_suffix = str(suffix_mode or "") if suffix_n >= max(4, int(len(history) * 0.70)) else ""
        stable_fraction = (int(fraction_mode) if fraction_n >= max(4, int(len(history) * 0.70))
                           and int(fraction_mode) >= 1 else -1)
        if not stable_suffix and stable_fraction < 1:
            return []

        norm = normalize_digits(text)
        token_match = re.search(
            r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
            r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, norm, re.IGNORECASE)
        if not token_match:
            return []
        token = re.sub(r"\s+", "", token_match.group(0))
        suffix_match = NUMERIC_SUFFIX_PATTERN.search(token)
        current_suffix = suffix_match.group(0) if suffix_match else ""
        body = token[:suffix_match.start()] if suffix_match else token
        exponent_match = re.search(r"[eE][-+]?\d+$", body)
        exponent = exponent_match.group(0) if exponent_match else ""
        mantissa = body[:exponent_match.start()] if exponent_match else body
        raw_digits = "".join(ch for ch in mantissa if ch.isdigit())

        repairs = []
        if stable_fraction >= 1 and not any(ch in mantissa for ch in ".,") and (
                len(raw_digits) > stable_fraction):
            sign = mantissa[:1] if mantissa[:1] in "+-" else ""
            digit_body = raw_digits
            repaired_mantissa = (sign + digit_body[:-stable_fraction] + "." +
                                 digit_body[-stable_fraction:])
            repairs.append(repaired_mantissa + exponent + current_suffix)
        if stable_suffix and not current_suffix:
            repairs.append(body + stable_suffix)
        if stable_suffix and not current_suffix and stable_fraction >= 1 and (
                not any(ch in mantissa for ch in ".,") and
                len(raw_digits) > stable_fraction):
            sign = mantissa[:1] if mantissa[:1] in "+-" else ""
            repaired_mantissa = (sign + raw_digits[:-stable_fraction] + "." +
                                 raw_digits[-stable_fraction:])
            repairs.append(repaired_mantissa + exponent + stable_suffix)

        base_values = self._parse_numeric_candidates(token, expected=expected)
        base_value = base_values[0][0] if base_values else None
        results, seen = [], set()
        for repaired in repairs:
            if repaired == token or repaired in seen:
                continue
            seen.add(repaired)
            for value, parse_weight, _parsed in self._parse_numeric_candidates(
                    repaired, expected=expected):
                repair_weight = 0.64
                if expected is not None:
                    expected_scale = max(1.0, abs(expected))
                    repaired_distance = abs(value - expected) / expected_scale
                    if base_value is None:
                        base_distance = float("inf")
                    else:
                        base_distance = abs(base_value - expected) / expected_scale
                    if repaired_distance <= 0.035:
                        repair_weight = 0.94
                    elif repaired_distance < base_distance * 0.45:
                        repair_weight = 0.86
                    elif repaired_distance < base_distance * 0.72:
                        repair_weight = 0.76
                results.append((value, parse_weight * repair_weight, repaired))
        return results[:4]

    def _remember_format(self, text, confidence, resolved_value=None):
        if confidence < 0.82:
            return
        signature = self._format_signature(text)
        if signature is None:
            return
        if resolved_value is not None:
            self.numeric_scale_graph.observe(text, resolved_value, confidence)
        self.format_history.append(signature)
        if len(self.format_history) > 18:
            self.format_history = self.format_history[-18:]

    @staticmethod
    def _edit_similarity(a, b):
        if not a or not b:
            return 0.0
        if a == b:
            return 1.0
        if abs(len(a) - len(b)) > max(3, int(max(len(a), len(b)) * 0.45)):
            return 0.0
        previous = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            current = [i]
            for j, cb in enumerate(b, 1):
                current.append(min(current[-1] + 1, previous[j] + 1,
                                   previous[j - 1] + (0 if ca == cb else 1)))
            previous = current
        distance = previous[-1]
        return max(0.0, 1.0 - distance / max(len(a), len(b), 1))

    def _source_multiplier(self, source):
        stat = self.source_skill.get(source, {})
        hit = float(stat.get("hit", 0.0))
        miss = float(stat.get("miss", 0.0))
        total = hit + miss
        if total < 1.5:
            return 1.0
        mean = (hit + 1.6) / (total + 3.2)
        confidence = min(1.0, total / 18.0)
        return max(0.72, min(1.30, 1.0 + (mean - 0.5) * 0.60 * confidence))

    def _learn_sources(self, candidates, chosen, confidence):
        if chosen is None or confidence < 0.58:
            return
        trust = max(0.10, min(1.0, (float(confidence) - 0.50) / 0.42))
        by_source = {}
        for value, _conf, _text, _weight, source in candidates:
            by_source.setdefault(source, []).append(value)
        for source, values in by_source.items():
            stat = self.source_skill.setdefault(source, {"hit": 0.0, "miss": 0.0})
            hit = any(self._same_value(value, chosen) for value in values)
            stat["hit" if hit else "miss"] = float(stat.get("hit" if hit else "miss", 0.0)) + trust
            total = float(stat.get("hit", 0.0)) + float(stat.get("miss", 0.0))
            if total > 80.0:
                stat["hit"] *= 0.72
                stat["miss"] *= 0.72
        if len(self.source_skill) > 140:
            ranked = sorted(self.source_skill.items(),
                            key=lambda kv: float(kv[1].get("hit", 0.0)) + float(kv[1].get("miss", 0.0)),
                            reverse=True)[:140]
            self.source_skill = dict(ranked)

    @staticmethod
    def _align_tokens(anchor, token):

        rows, cols = len(anchor) + 1, len(token) + 1
        gap = 0.78
        costs = [[0.0] * cols for _ in range(rows)]
        moves = [[None] * cols for _ in range(rows)]
        for i in range(1, rows):
            costs[i][0], moves[i][0] = i * gap, "up"
        for j in range(1, cols):
            costs[0][j], moves[0][j] = j * gap, "left"
        for i in range(1, rows):
            for j in range(1, cols):
                substitute = costs[i - 1][j - 1] + (0.0 if anchor[i - 1] == token[j - 1] else 1.0)
                delete = costs[i - 1][j] + gap
                insert = costs[i][j - 1] + gap
                best = min((substitute, 0, "diag"), (delete, 1, "up"),
                           (insert, 2, "left"))
                costs[i][j], moves[i][j] = best[0], best[2]
        aligned = []
        i, j = len(anchor), len(token)
        while i or j:
            move = moves[i][j]
            if move == "diag":
                aligned.append((anchor[i - 1], token[j - 1]))
                i, j = i - 1, j - 1
            elif move == "up":
                aligned.append((anchor[i - 1], None))
                i -= 1
            else:
                aligned.append((None, token[j - 1]))
                j -= 1
        aligned.reverse()
        return aligned

    def _aligned_consensus_tokens(self, candidates):

        unique = {}
        for _value, conf, text, weight, source in candidates:
            signature = self._token_signature(text)
            if len(signature) < 2 or conf < 0.28:
                continue
            score = (max(0.02, float(weight)) * (0.18 + float(conf) ** 2) *
                     self._source_multiplier(source))
            key = (signature, source)
            if score > unique.get(key, (0.0, ""))[0]:
                unique[key] = (score, source)
        items = [(signature, score, source)
                 for (signature, _source), (score, source) in unique.items()]
        items.sort(key=lambda item: item[1], reverse=True)
        items = items[:64]
        if len(items) < 3:
            return []

        best_cluster = []
        best_cluster_score = 0.0
        for anchor, anchor_score, _source in items[:24]:
            members = []
            cluster_score = 0.0
            for signature, score, source in items:
                if abs(len(signature) - len(anchor)) > 2:
                    continue
                similarity = self._edit_similarity(anchor, signature)
                if similarity < 0.52:
                    continue
                members.append((signature, score, source))
                cluster_score += score * (0.55 + 0.45 * similarity)
            diversity = len({source for _signature, _score, source in members})
            if len(members) >= 3 and diversity >= 2 and cluster_score > best_cluster_score:
                best_cluster, best_cluster_score = members, cluster_score
        if not best_cluster:
            return []

        anchor = max(
            best_cluster,
            key=lambda item: sum(other_score * self._edit_similarity(item[0], other)
                                 for other, other_score, _source in best_cluster),
        )[0]
        char_votes = [dict() for _ in anchor]
        insert_votes = [dict() for _ in range(len(anchor) + 1)]
        total_weight = sum(score for _signature, score, _source in best_cluster)
        for signature, score, _source in best_cluster:
            chars = [""] * len(anchor)
            inserts = [""] * (len(anchor) + 1)
            cursor = 0
            for left, right in self._align_tokens(anchor, signature):
                if left is None:
                    if right:
                        inserts[cursor] += right
                else:
                    chars[cursor] = right or ""
                    cursor += 1
            for index, value in enumerate(chars):
                char_votes[index][value] = char_votes[index].get(value, 0.0) + score
            for index, value in enumerate(inserts):
                insert_votes[index][value] = insert_votes[index].get(value, 0.0) + score

        slots = []
        top_agreements = []
        for index in range(len(anchor) + 1):
            insertion = sorted(insert_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            if insertion:
                insertion_options = []
                for rank, (value, vote) in enumerate(insertion[:2]):
                    probability = vote / max(1e-9, total_weight)
                    threshold = 0.0 if rank == 0 else (0.34 if value else 0.22)
                    if probability >= threshold:
                        insertion_options.append((value, probability))
                if insertion_options:

                    if insertion_options[0][0] and insertion_options[0][1] < 0.50:
                        insertion_options.insert(0, ("", 1.0 - insertion_options[0][1]))
                    slots.append(insertion_options[:2])
                    top_agreements.append(insertion_options[0][1])
            if index == len(anchor):
                break
            choices = sorted(char_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            options = []
            for rank, (value, vote) in enumerate(choices[:2]):
                probability = vote / max(1e-9, total_weight)
                if rank == 0 or probability >= 0.20:
                    options.append((value, probability))
            if options:
                slots.append(options)
                top_agreements.append(options[0][1])

        if not slots:
            return []
        agreement = sum(top_agreements) / len(top_agreements)
        if agreement < 0.57:
            return []
        beams = [("", 0.0)]
        for options in slots:
            expanded = []
            for prefix, log_score in beams:
                for value, probability in options:
                    expanded.append((prefix + value,
                                     log_score + math.log(max(1e-6, probability))))
            expanded.sort(key=lambda item: item[1], reverse=True)
            beams = expanded[:6]
        source_count = len({source for _signature, _score, source in best_cluster})
        results, seen = [], set()
        for token, log_score in beams:
            if token in seen or not any(ch.isdigit() for ch in token):
                continue
            seen.add(token)
            beam_agreement = math.exp(log_score / max(1, len(slots)))
            combined = max(0.0, min(1.0, agreement * 0.62 + beam_agreement * 0.38))
            results.append((token, combined, source_count))
        return results

    def _with_character_consensus(self, candidates, expected=None):

        work = list(candidates)
        for token, agreement, source_count in self._aligned_consensus_tokens(candidates):
            conf = min(0.982, 0.40 + agreement * 0.53 + min(0.04, source_count * 0.006))
            weight = min(1.13, 0.70 + agreement * 0.40)
            for value, parse_weight, _token in self._parse_numeric_candidates(
                    token, expected=expected):
                work.append((value, conf, token, weight * parse_weight,
                             f"consensus:aligned:{source_count}"))
        return work

    def _pick(self, candidates, expected=None):
        if not candidates:
            self.last_distribution = []
            return None, 0.0, ""
        candidates = self._with_character_consensus(candidates, expected=expected)
        groups = []
        for value, conf, text, weight, source in candidates:
            group = next((g for g in groups if self._same_value(g[0], value)), None)
            evidence = (weight * self._source_multiplier(source) * self._text_quality(text) *
                        (0.16 + conf * conf))
            if group is None:
                groups.append([value, {source: evidence}, conf, text, 1])
            else:
                old = float(group[1].get(source, 0.0))
                if old:
                    group[1][source] = max(old, evidence) + min(old, evidence) * 0.18
                else:
                    group[1][source] = evidence
                if conf > group[2]:
                    group[2], group[3] = conf, text
                group[4] += 1

        scored = []
        for value, source_scores, conf, text, observations in groups:
            evidence = sum(source_scores.values())
            support = len(source_scores)
            evidence += self._format_prior(text, value)
            evidence += min(0.86, 0.205 * (support - 1))
            evidence += min(0.12, 0.018 * max(0, observations - support))

            signature = self._token_signature(text)
            if signature and len(groups) > 1:
                near = 0.0
                for other_value, _other_sources, other_conf, other_text, _obs in groups:
                    if self._same_value(value, other_value):
                        continue
                    other_sig = self._token_signature(other_text)
                    similarity = self._edit_similarity(signature, other_sig)
                    if similarity < 0.78:
                        continue
                    lo = max(1e-12, min(abs(value), abs(other_value)))
                    hi = max(abs(value), abs(other_value), 1e-12)
                    if hi / lo <= 20.0 or len(signature) == len(other_sig):
                        near += (similarity - 0.76) * (0.16 + 0.20 * other_conf)
                evidence += min(0.13, max(0.0, near))

            temporal = sum(c for v, c in self.recent[-6:] if self._same_value(v, value))
            if temporal:
                evidence += min(0.17, temporal * 0.034)

            if expected is not None and not self._same_value(value, expected):
                scale = max(abs(expected), 1.0)
                jump = abs(value - expected) / scale
                if jump > 100000 and support == 1 and conf < 0.90:
                    evidence -= 0.22
                elif jump > 1000 and support == 1 and conf < 0.76:
                    evidence -= 0.10
            elif expected is not None:
                evidence += 0.075

            if self.last_value is not None and self.last_confidence >= 0.68:
                if self._same_value(value, self.last_value):
                    evidence += 0.035
                elif support == 1 and conf < 0.60:
                    scale = max(abs(self.last_value), 1.0)
                    if abs(value - self.last_value) > scale * 100000:
                        evidence -= 0.08
            scored.append([value, evidence, conf, text, support, observations])

        scored.sort(key=lambda g: (g[1], g[2], g[4], g[5]), reverse=True)
        if expected is not None and len(scored) > 1:
            for index, group in enumerate(scored[1:], start=1):
                if (self._same_value(group[0], expected) and
                        group[1] >= scored[0][1] * 0.94 and
                        (group[4] >= 2 or
                         (scored[0][4] == 1 and scored[0][2] < 0.72))):
                    scored.insert(0, scored.pop(index))
                    break
        best = scored[0]
        runner = scored[1][1] if len(scored) > 1 else 0.0
        # Preserve the best few interpretations as a normalized evidence distribution.
        # This is intentionally local to the reader so callers that only need the legacy
        # scalar API remain unchanged.
        top = scored[:3]
        if top:
            peak = max(float(item[1]) for item in top)
            weights = [math.exp(max(-18.0, min(0.0, float(item[1]) - peak))) for item in top]
            total_weight = sum(weights) or 1.0
            self.last_distribution = [
                {"value": float(item[0]), "probability": float(weight / total_weight),
                 "confidence": float(item[2]), "text": str(item[3])}
                for item, weight in zip(top, weights)
            ]
        else:
            self.last_distribution = []
        margin = best[1] - runner
        margin_bonus = min(0.13, max(0.0, margin) * 0.047) if best[4] >= 2 else 0.0
        source_bonus = min(0.12, 0.045 * (best[4] - 1))
        confidence = min(0.997, best[2] + 0.050 * (best[4] - 1) + margin_bonus + source_bonus)
        if runner > 0 and best[1] > 0:
            competition = runner / best[1]
            if competition > 0.50:
                confidence -= min(0.24, (competition - 0.50) * 0.48)
            # A close runner that implies a radically different magnitude is especially
            # dangerous for reinforcement learning because it can create a fake jackpot.
            if len(scored) > 1 and competition > 0.36:
                try:
                    other_value = float(scored[1][0])
                    lo = max(1e-12, min(abs(float(best[0])), abs(other_value)))
                    hi = max(abs(float(best[0])), abs(other_value), 1e-12)
                    magnitude_gap = math.log10(max(1.0, hi / lo))
                    confidence -= min(0.30, magnitude_gap * competition * 0.055)
                except Exception:
                    pass
        confidence = max(0.08, min(0.997, confidence))
        return best[0], confidence, best[3]

    @staticmethod
    def _expanded_rect(rect, ratio=0.06, px=3):
        x1, y1, x2, y2 = map(float, rect)
        w, h = max(1.0, x2 - x1), max(1.0, y2 - y1)
        dx, dy = max(px, w * ratio), max(px, h * ratio)
        return (x1 - dx, y1 - dy, x2 + dx, y2 + dy)

    @staticmethod
    def _shifted_rect(rect, dx=0, dy=0):
        x1, y1, x2, y2 = map(float, rect)
        return (x1 + dx, y1 + dy, x2 + dx, y2 + dy)

    def _run_engine(self, engine_name, engine, variants, candidates, model_weight=1.0,
                    det=False, limit=None, expected=None):
        use = variants if limit is None else variants[:limit]
        for index, (arr, weight, tag) in enumerate(use):
            try:
                kwargs = {"use_det": bool(det), "use_cls": False, "use_rec": True}
                if not det and index < self.character_detail_variants:
                    kwargs.update(return_word_box=True, return_single_char_box=True)
                try:
                    result = engine(arr, **kwargs)
                except (TypeError, ValueError):
                    kwargs.pop("return_word_box", None)
                    kwargs.pop("return_single_char_box", None)
                    result = engine(arr, **kwargs)
                lines = self._extract_lines(result)
                character_lines = self._extract_character_lines(result)
                character_confidence = {
                    self._token_signature(text): conf for text, conf in character_lines
                    if self._token_signature(text)
                }
                for text, conf in lines:
                    signature = self._token_signature(text)
                    if signature in character_confidence:
                        conf = min(conf, conf * 0.42 + character_confidence[signature] * 0.58)
                    parsed = self._parse_numeric_candidates(text, expected=expected)
                    for value, parse_weight, _token in parsed:
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * (0.93 if det else 1.0),
                                           f"{engine_name}:{tag}:{'det' if det else 'rec'}"))
                    if not det:
                        for value, repair_weight, repaired in self._format_repair_candidates(
                                text, expected):
                            candidates.append((value, conf * 0.94, repaired,
                                               weight * model_weight * repair_weight,
                                               f"{engine_name}:{tag}:fmtfix"))
                for text, conf in character_lines:
                    if any(text == existing for existing, _confidence in lines):
                        continue
                    for value, parse_weight, _token in self._parse_numeric_candidates(
                            text, expected=expected):
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * 1.035,
                                           f"{engine_name}:{tag}:chars"))
                    if not det:
                        for value, repair_weight, repaired in self._format_repair_candidates(
                                text, expected):
                            candidates.append((value, conf * 0.95, repaired,
                                               weight * model_weight * repair_weight * 1.015,
                                               f"{engine_name}:{tag}:chars-fmtfix"))

                if len(lines) > 1:
                    joined = "".join(t for t, _c in lines)
                    conf = sum(c for _t, c in lines) / len(lines)
                    for value, parse_weight, _token in self._parse_numeric_candidates(
                            joined, expected=expected):
                        candidates.append((value, conf, joined,
                                           weight * model_weight * 0.82 * parse_weight,
                                           f"{engine_name}:{tag}:joined"))
                if not det and index >= 1:
                    tentative = self._pick(candidates, expected)
                    support = sum(1 for v, _c, _t, _w, _s in candidates
                                  if tentative[0] is not None and self._same_value(v, tentative[0]))
                    if support >= 3 and tentative[1] >= 0.95:
                        break
            except Exception:
                continue

    def _burst_candidates(self, rect, primary_name, primary_engine, primary_weight,
                          expected=None, budget=4, count=2):
        candidates = []
        frames = max(1, min(3, int(count)))
        for frame_index in range(frames):
            try:
                image = self.capture.grab(rect)

                view_limit = 3 if budget >= 7 else 2
                variants = self._tag_variants(
                    list(self._variants(image, view_limit)), f"burst{frame_index + 1}")
                self._run_engine(f"{primary_name}-f{frame_index + 1}", primary_engine,
                                 variants, candidates, primary_weight * 0.985,
                                 det=False, expected=expected)
                if frame_index + 1 < frames:
                    time.sleep(0.010)
            except Exception:
                continue
        return candidates

    def _dynamic_budget(self):
        budget = int(self.active_variants)
        target = self.latency_target
        if self.latency > target * 2.4:
            budget -= 3
        elif self.latency > target * 1.55:
            budget -= 2
        elif self.latency > target * 1.18:
            budget -= 1
        elif self.latency < target * 0.62 and self.confidence_ema < 0.90:
            budget += 1
        if self.fail_streak:
            budget += min(3, self.fail_streak)
        if self.confidence_ema < 0.68:
            budget += 1
        if self.hardware is not None:
            avail = _available_memory()
            if avail < max(1024 ** 3, self.hardware.ram * 0.10):
                budget = min(budget, self.min_variants)
            elif getattr(self.hardware, "cpu_load_ema", 0.0) > 0.90:
                budget = max(self.min_variants, budget - 2)
        return max(self.min_variants, min(self.max_variants, budget))

    def _retune(self, success, confidence):
        self.confidence_ema = self.confidence_ema * 0.86 + float(confidence) * 0.14
        if success:
            self.fail_streak = 0
        else:
            self.fail_streak = min(5, self.fail_streak + 1)
        target = self.latency_target
        if self.latency > target * 1.45 and self.active_variants > self.min_variants:
            self.active_variants -= 1
        elif (self.latency < target * 0.72 and self.confidence_ema < 0.88 and
              self.active_variants < self.max_variants):
            self.active_variants += 1
        elif self.fail_streak >= 2 and self.active_variants < self.max_variants:
            self.active_variants += 1

    def read_image(self, image, expected=None):
        if image is None or image.width < 4 or image.height < 4 or not self.engines:
            return None, 0.0, ""
        variants = list(self._variants(image, self.max_variants))
        candidates = []
        for engine_name, engine, model_weight in self.engines:
            self._run_engine(engine_name, engine, variants, candidates,
                             model_weight, det=False, expected=expected)
        try:
            candidates.extend(self._classical_numeric_candidates(image))
        except Exception:
            pass
        primary_name, primary_engine, primary_weight = self.engines[0]
        self._run_engine(primary_name, primary_engine, variants, candidates,
                         primary_weight, det=True, expected=expected)
        best = self._pick(candidates, expected)
        if best[0] is not None:
            self._learn_sources(candidates, best[0], best[1])
            self._remember_format(best[2], best[1], best[0])
        return best

    def read(self, rect, expected=None):
        started = time.perf_counter()
        best = (None, 0.0, "")
        try:
            image = self.capture.grab(rect)
            if image.width < 4 or image.height < 4:
                self._retune(False, 0.0)
                return best
            budget = self._dynamic_budget()
            variants = list(self._variants(image, budget))
            candidates = []
            if not self.engines:
                self._retune(False, 0.0)
                return best
            primary_name, primary_engine, primary_weight = self.engines[0]
            self._run_engine(primary_name, primary_engine, variants, candidates,
                             primary_weight, det=False, expected=expected)
            best = self._pick(candidates, expected)

            if best[0] is None or best[1] < 0.84:
                candidates.extend(self._classical_numeric_candidates(image))
                best = self._pick(candidates, expected)

            if best[0] is None or best[1] < 0.88:
                for ratio, weight in ((0.055, 0.96), (0.12, 0.90)):
                    try:
                        expanded = self.capture.grab(self._expanded_rect(rect, ratio=ratio,
                                                                         px=4 if ratio < 0.1 else 7))
                        more = self._tag_variants(
                            list(self._variants(expanded, max(2, min(budget, 5)))),
                            f"expand{int(ratio * 1000)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * weight, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.93:
                            break
                    except Exception:
                        continue

            if best[0] is None or best[1] < 0.89:
                for crop_index, tight in enumerate(self._content_crops(image), start=1):
                    try:
                        more = self._tag_variants(
                            list(self._variants(tight, max(2, min(budget, 5)))),
                            f"tight{crop_index}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.94:
                            break
                    except Exception:
                        continue

            if best[0] is None or best[1] < 0.86:
                iw, ih = image.size
                trims = ((0.02, 0.04), (0.05, 0.02), (0.07, 0.07))
                for tx, ty in trims:
                    try:
                        xpad, ypad = int(iw * tx), int(ih * ty)
                        if iw - 2 * xpad < 6 or ih - 2 * ypad < 6:
                            continue
                        inner = image.crop((xpad, ypad, iw - xpad, ih - ypad))
                        more = self._tag_variants(
                            list(self._variants(inner, max(2, min(budget, 4)))),
                            f"trim{int(tx * 100)}x{int(ty * 100)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.97, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.92:
                            break
                    except Exception:
                        continue

            if (best[0] is None or best[1] < 0.76) and budget >= 4:
                for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                    try:
                        shifted = self.capture.grab(self._shifted_rect(rect, dx, dy))
                        more = self._tag_variants(
                            list(self._variants(shifted, 2 if budget < 7 else 3)),
                            f"shift{dx:+d}{dy:+d}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.985, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.90:
                            break
                    except Exception:
                        continue

            burst_frames = (getattr(self.hardware, "uncertain_burst_frames", 2)
                            if self.hardware is not None else 2)
            burst_allowed = (self.hardware is None or
                             (_available_memory() >= max(1100 * 1024 ** 2, self.hardware.ram * 0.085) and
                              getattr(self.hardware, "cpu_load_ema", 0.0) < 0.91))
            if burst_allowed and (best[0] is None or best[1] < 0.86):
                try:
                    candidates.extend(self._burst_candidates(
                        rect, primary_name, primary_engine, primary_weight, expected,
                        budget, burst_frames))
                    best = self._pick(candidates, expected)
                except Exception:
                    pass

            if best[0] is None or best[1] < 0.82:
                try:
                    fused = self._temporal_fusion(rect, 3 if budget >= 4 else 2)
                    if fused is not None:
                        more = self._tag_variants(
                            list(self._variants(fused, max(2, min(budget, 5)))), "temporal")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        if best[0] is None or best[1] < 0.72:
                            candidates.extend(self._classical_numeric_candidates(fused))
                        best = self._pick(candidates, expected)
                except Exception:
                    pass

            ensemble_allowed = True
            if self.hardware is not None:
                ensemble_allowed = (_available_memory() >=
                                    max(1400 * 1024 ** 2, self.hardware.ram * 0.105) and
                                    getattr(self.hardware, "cpu_load_ema", 0.0) < 0.93)
            if (ensemble_allowed and len(self.engines) > 1 and
                    (best[0] is None or best[1] < 0.92)):
                for engine_name, engine, model_weight in self.engines[1:]:
                    self._run_engine(engine_name, engine, variants, candidates,
                                     model_weight, det=False, limit=max(2, min(5, budget)),
                                     expected=expected)
                    best = self._pick(candidates, expected)
                    if best[0] is not None and best[1] >= 0.94:
                        break

            if best[0] is None or best[1] < 0.64:
                self._run_engine(primary_name, primary_engine, variants, candidates,
                                 primary_weight, det=True, limit=max(1, min(3, budget)),
                                 expected=expected)
                best = self._pick(candidates, expected)

            if best[0] is not None and best[1] >= 0.44:
                self._learn_sources(candidates, best[0], best[1])
                self.last_value, self.last_confidence, self.last_text = best
                self._remember_format(best[2], best[1], best[0])
                self.recent.append((best[0], best[1]))
                if len(self.recent) > 8:
                    self.recent = self.recent[-8:]
                self._retune(True, best[1])
            else:
                self._retune(False, best[1])
            return best
        finally:
            elapsed = max(0.001, time.perf_counter() - started)
            self.latency = self.latency * 0.82 + elapsed * 0.18

class EmergencyStop:
    """Thread-safe stop token with an independent ESC polling path.

    The low-level hook remains the primary interrupt path. Every existing
    is_set() checkpoint also polls GetAsyncKeyState, so a broken hook/message
    loop cannot leave an in-progress hold, drag, OCR wait, or decision loop
    without an ESC escape path.
    """
    def __init__(self):
        self._event = threading.Event()

    def set(self):
        self._event.set()

    def clear(self):
        self._event.clear()

    def is_set(self):
        if self._event.is_set():
            return True
        try:
            if os.name == "nt" and (user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000):
                self._event.set()
                return True
        except Exception:
            pass
        return False

    def wait(self, timeout=None):
        if self.is_set():
            return True
        return self._event.wait(timeout)


class EscapeHook:
    def __init__(self, stop_event):
        self.stop_event = stop_event
        self.ready = threading.Event()
        self.hooked = False
        self.thread_id = 0
        self.thread = None
        self.hook = None
        self.callback = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.ready.wait(2)
        return self.hooked

    def _run(self):
        self.thread_id = kernel32.GetCurrentThreadId()
        proc_type = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM)

        def low_level_proc(code, message, data):
            if code >= 0:
                info = ctypes.cast(data, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if info.vkCode == VK_ESCAPE and message in (
                        WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP):
                    self.stop_event.set()
                    return 1
            return user32.CallNextHookEx(self.hook, code, message, data)

        self.callback = proc_type(low_level_proc)
        self.hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL,
                                             ctypes.cast(self.callback, ctypes.c_void_p),
                                             kernel32.GetModuleHandleW(None), 0)
        self.hooked = bool(self.hook)
        self.ready.set()
        if not self.hook:
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def close(self):
        deadline = time.monotonic() + 1.5
        while user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000 and time.monotonic() < deadline:
            time.sleep(0.03)
        if self.thread_id:
            user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)

NAMED_KEY_VKS = {
    "BACKSPACE": 0x08, "TAB": 0x09, "CLEAR": 0x0C, "ENTER": 0x0D,
    "SHIFT": 0x10, "CTRL": 0x11, "ALT": 0x12, "PAUSE": 0x13,
    "CAPSLOCK": 0x14, "IME_KANA": 0x15, "IME_ON": 0x16,
    "IME_JUNJA": 0x17, "IME_FINAL": 0x18, "IME_HANJA": 0x19,
    "IME_OFF": 0x1A, "CONVERT": 0x1C, "NONCONVERT": 0x1D,
    "ACCEPT": 0x1E, "MODECHANGE": 0x1F, "SPACE": 0x20,
    "PAGEUP": 0x21, "PAGEDOWN": 0x22, "END": 0x23, "HOME": 0x24,
    "LEFT": 0x25, "UP": 0x26, "RIGHT": 0x27, "DOWN": 0x28,
    "SELECT": 0x29, "PRINT": 0x2A, "EXECUTE": 0x2B,
    "PRINTSCREEN": 0x2C, "INSERT": 0x2D, "DELETE": 0x2E, "HELP": 0x2F,
    "LWIN": 0x5B, "RWIN": 0x5C, "APPS": 0x5D, "SLEEP": 0x5F,
    "MULTIPLY": 0x6A, "ADD": 0x6B, "SEPARATOR": 0x6C,
    "SUBTRACT": 0x6D, "DECIMAL": 0x6E, "DIVIDE": 0x6F,
    "NUMLOCK": 0x90, "SCROLLLOCK": 0x91,
    "LSHIFT": 0xA0, "RSHIFT": 0xA1, "LCTRL": 0xA2, "RCTRL": 0xA3,
    "LALT": 0xA4, "RALT": 0xA5, "BROWSER_BACK": 0xA6,
    "BROWSER_FORWARD": 0xA7, "BROWSER_REFRESH": 0xA8,
    "BROWSER_STOP": 0xA9, "BROWSER_SEARCH": 0xAA,
    "BROWSER_FAVORITES": 0xAB, "BROWSER_HOME": 0xAC,
    "VOLUME_MUTE": 0xAD, "VOLUME_DOWN": 0xAE, "VOLUME_UP": 0xAF,
    "MEDIA_NEXT": 0xB0, "MEDIA_PREVIOUS": 0xB1, "MEDIA_STOP": 0xB2,
    "MEDIA_PLAY_PAUSE": 0xB3, "LAUNCH_MAIL": 0xB4,
    "LAUNCH_MEDIA": 0xB5, "LAUNCH_APP1": 0xB6, "LAUNCH_APP2": 0xB7,
    "OEM_SEMICOLON": 0xBA, "OEM_PLUS": 0xBB, "OEM_COMMA": 0xBC,
    "OEM_MINUS": 0xBD, "OEM_PERIOD": 0xBE, "OEM_SLASH": 0xBF,
    "OEM_BACKTICK": 0xC0, "OEM_LBRACKET": 0xDB,
    "OEM_BACKSLASH": 0xDC, "OEM_RBRACKET": 0xDD,
    "OEM_QUOTE": 0xDE, "OEM_8": 0xDF, "OEM_102": 0xE2,
    "PROCESSKEY": 0xE5, "PACKET": 0xE7, "ATTN": 0xF6,
    "CRSEL": 0xF7, "EXSEL": 0xF8, "EREOF": 0xF9, "PLAY": 0xFA,
    "ZOOM": 0xFB, "NONAME": 0xFC, "PA1": 0xFD, "OEM_CLEAR": 0xFE,
}
NAMED_KEY_VKS.update({str(digit): 0x30 + digit for digit in range(10)})
NAMED_KEY_VKS.update({chr(code): code for code in range(0x41, 0x5B)})
NAMED_KEY_VKS.update({f"NUMPAD{digit}": 0x60 + digit for digit in range(10)})
NAMED_KEY_VKS.update({f"F{number}": 0x6F + number for number in range(1, 25)})

# The action universe is deliberately discovered rather than curated.  Named
# keys make logs readable; unnamed/reserved virtual-key codes remain explorable
# under a stable VK_XX name.  ESC is the sole excluded key because it is the
# user's unconditional emergency stop.
KEY_UNIVERSE = {name: int(vk) for name, vk in NAMED_KEY_VKS.items()
                if int(vk) != VK_ESCAPE}
_NAMED_VK_CODES = set(KEY_UNIVERSE.values())
for _vk in range(1, 256):
    if _vk != VK_ESCAPE and _vk not in _NAMED_VK_CODES:
        KEY_UNIVERSE[f"VK_{_vk:02X}"] = _vk
KEY_ACTIONS = {f"key:{name}": vk for name, vk in KEY_UNIVERSE.items()}
KEY_NAME_TO_VK = {name.split(":", 1)[1]: vk for name, vk in KEY_ACTIONS.items()}
ATOMIC_KEY_ACTIONS = tuple(KEY_ACTIONS)
OBSERVE_ACTION = "wait:observe"
KEY_ACTION_PRIORS = {action: 0.20 for action in KEY_ACTIONS}
KEY_ACTION_PRIORS[OBSERVE_ACTION] = 0.26

# These values describe operating-system side-effect risk, not whether a key is
# useful to the target application.  Every non-ESC VK stays in KEY_UNIVERSE;
# system-facing keys simply require causal/semantic evidence before execution.
SYSTEM_KEY_RISK = {
    0x2C: 0.78,  # PRINTSCREEN
    0x5B: 0.96, 0x5C: 0.96,  # Windows shell keys
    0x5D: 0.62, 0x5F: 1.00,  # context menu / sleep
    0xE5: 0.58, 0xE7: 0.62,  # IME process / packet injection
}
for _vk in range(0xA6, 0xAD):  # browser navigation/search/home
    SYSTEM_KEY_RISK[_vk] = 0.86
for _vk in range(0xAD, 0xB4):  # volume/media transport
    SYSTEM_KEY_RISK[_vk] = 0.76
for _vk in range(0xB4, 0xB8):  # launch mail/media/apps
    SYSTEM_KEY_RISK[_vk] = 0.90

_INPUT_STATE_LOCK = threading.RLock()
_PRESSED_KEYS = set()
_PRESSED_MOUSE_BUTTONS = set()
_MOUSE_DOWN_TO_BUTTON = {
    MOUSEEVENTF_LEFTDOWN: "left", MOUSEEVENTF_RIGHTDOWN: "right",
    MOUSEEVENTF_MIDDLEDOWN: "middle", MOUSEEVENTF_XDOWN: "x",
}
_MOUSE_UP_TO_BUTTON = {
    MOUSEEVENTF_LEFTUP: "left", MOUSEEVENTF_RIGHTUP: "right",
    MOUSEEVENTF_MIDDLEUP: "middle", MOUSEEVENTF_XUP: "x",
}

def _track_key_state(vk, up):
    with _INPUT_STATE_LOCK:
        if up:
            _PRESSED_KEYS.discard(int(vk))
        else:
            _PRESSED_KEYS.add(int(vk))

def _track_mouse_state(flags, data=0):
    flags = int(flags)
    data = int(data) & 0xFFFFFFFF
    with _INPUT_STATE_LOCK:
        for flag, name in _MOUSE_DOWN_TO_BUTTON.items():
            if flags & flag:
                token = f"{name}:{data}" if name == "x" else name
                _PRESSED_MOUSE_BUTTONS.add(token)
        for flag, name in _MOUSE_UP_TO_BUTTON.items():
            if flags & flag:
                if name == "x":
                    _PRESSED_MOUSE_BUTTONS.discard(f"x:{data}")
                else:
                    _PRESSED_MOUSE_BUTTONS.discard(name)

def _send_key_event(vk, up=False):
    if vk == VK_ESCAPE:
        return False
    scan_ex = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC_EX))
    scan = scan_ex & 0xFF
    extended = bool(scan_ex & 0xFF00)
    if not scan:
        scan = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC)) & 0xFF
    try:
        flags = KEYEVENTF_SCANCODE | (KEYEVENTF_EXTENDEDKEY if extended else 0)
        if up:
            flags |= KEYEVENTF_KEYUP
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.union.ki = KEYBDINPUT(0, scan, flags, 0, 0)
        if scan and int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1:
            _track_key_state(vk, up)
            return True
    except Exception:
        pass
    try:
        flags = (KEYEVENTF_EXTENDEDKEY if extended else 0) | (KEYEVENTF_KEYUP if up else 0)
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.union.ki = KEYBDINPUT(vk, 0, flags, 0, 0)
        if int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1:
            _track_key_state(vk, up)
            return True
        # keybd_event is a compatibility fallback. It has no success return value,
        # so an exception-free call is the strongest acknowledgement available.
        user32.keybd_event(vk, 0, flags, 0)
        _track_key_state(vk, up)
        return True
    except Exception:
        return False

def press_keys(vks, duration=0.075, stop_event=None):
    keys = []
    for vk in vks:
        vk = int(vk)
        if vk != VK_ESCAPE and vk not in keys:
            keys.append(vk)
    if not keys:
        return False
    down = []
    successful = True
    try:
        for vk in keys:
            if _send_key_event(vk, False):
                down.append(vk)
            else:
                successful = False
                break
        if len(down) == len(keys):
            try:
                duration = float(duration)
            except (TypeError, ValueError, OverflowError):
                successful = False
                duration = 0.0
            if not math.isfinite(duration):
                successful = False
            if successful:
                end = time.monotonic() + max(0.018, duration)
                while time.monotonic() < end:
                    if stop_event is not None and stop_event.is_set():
                        successful = False
                        break
                    time.sleep(min(0.018, max(0.001, end - time.monotonic())))
        else:
            successful = False
    finally:
        for vk in reversed(down):
            if not _send_key_event(vk, True):
                successful = False
    return successful

MOUSE_BUTTONS = {
    "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0),
    "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0),
    "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0),
    "x1": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON1),
    "x2": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON2),
}

def _mouse_event(flags, data=0):
    try:
        user32.mouse_event(int(flags), 0, 0, int(data) & 0xFFFFFFFF, 0)
        _track_mouse_state(flags, data)
        return True
    except Exception:
        return False

def move_pointer(x, y):
    try:
        return bool(user32.SetCursorPos(int(round(x)), int(round(y))))
    except Exception:
        return False

def click_point(x, y, button="left", clicks=1, stop_event=None):
    flags = MOUSE_BUTTONS.get(str(button).lower())
    if flags is None or not move_pointer(x, y):
        return False
    down, up, data = flags
    completed = 0
    for index in range(max(1, int(clicks))):
        if stop_event is not None and stop_event.is_set():
            return False
        if not _mouse_event(down, data):
            return False
        released = False
        try:
            end = time.monotonic() + 0.050
            while time.monotonic() < end:
                if stop_event is not None and stop_event.is_set():
                    break
                time.sleep(0.008)
        finally:
            released = _mouse_event(up, data)
        if not released:
            return False
        completed += 1
        if stop_event is not None and stop_event.is_set():
            return False
        if index + 1 < clicks:
            time.sleep(0.065)
    return completed == max(1, int(clicks))

def scroll_point(x, y, amount, horizontal=False):
    if not move_pointer(x, y):
        return False
    return _mouse_event(MOUSEEVENTF_HWHEEL if horizontal else MOUSEEVENTF_WHEEL,
                        int(amount))

def drag_pointer(x1, y1, x2, y2, button="left", duration=0.45, stop_event=None):
    flags = MOUSE_BUTTONS.get(str(button).lower())
    if flags is None or not move_pointer(x1, y1):
        return False
    down, up, data = flags
    if not _mouse_event(down, data):
        return False
    completed = True
    try:
        duration = max(0.02, float(duration))
        steps = max(2, int(math.ceil(duration / 0.014)))
        started = time.monotonic()
        for step in range(1, steps + 1):
            if stop_event is not None and stop_event.is_set():
                completed = False
                break
            progress = step / steps
            eased = progress * progress * (3.0 - 2.0 * progress)
            if not move_pointer(x1 + (x2 - x1) * eased, y1 + (y2 - y1) * eased):
                completed = False
                break
            target = started + duration * progress
            while time.monotonic() < target:
                if stop_event is not None and stop_event.is_set():
                    completed = False
                    break
                time.sleep(min(0.006, target - time.monotonic()))
            if not completed:
                break
    finally:
        released = _mouse_event(up, data)
    return bool(completed and released)

def release_all_inputs():
    # Last-resort insurance for exceptions, window destruction and interrupted
    # temporal actions.  ESC is never synthesized here or anywhere else.
    with _INPUT_STATE_LOCK:
        keys = list(_PRESSED_KEYS)
        buttons = list(_PRESSED_MOUSE_BUTTONS)
    for vk in reversed(keys):
        try:
            _send_key_event(vk, True)
        except Exception:
            pass
    for token in buttons:
        try:
            if token == "left":
                _mouse_event(MOUSEEVENTF_LEFTUP, 0)
            elif token == "right":
                _mouse_event(MOUSEEVENTF_RIGHTUP, 0)
            elif token == "middle":
                _mouse_event(MOUSEEVENTF_MIDDLEUP, 0)
            elif token.startswith("x:"):
                data = int(token.split(":", 1)[1])
                _mouse_event(MOUSEEVENTF_XUP, data)
        except Exception:
            pass

def _acquire_runtime_mutex(data_dir, stop_event=None, wait_callback=None):
    if os.name != "nt" or kernel32 is None:
        return None
    digest = hashlib.sha1((str(Path(data_dir).resolve()).lower() + "|" + RUNTIME_FINGERPRINT)
                          .encode("utf-8", "replace")).hexdigest()[:24]
    name = f"Local\\ValueAI_Runtime_{digest}"
    handle = kernel32.CreateMutexW(None, False, name)
    if not handle:
        raise OSError("无法创建运行时互斥锁")
    started = time.monotonic()
    deadline = started + RUNTIME_CONFIG.runtime_mutex_timeout_ms / 1000.0
    last_notice = -1
    while True:
        if stop_event is not None and stop_event.is_set():
            try:
                kernel32.CloseHandle(handle)
            except Exception:
                pass
            raise InterruptedError("运行时准备已取消")
        result = int(kernel32.WaitForSingleObject(
            handle, RUNTIME_CONFIG.runtime_mutex_poll_ms))
        if result in (WAIT_OBJECT_0, WAIT_ABANDONED):
            return handle
        if result != WAIT_TIMEOUT:
            try:
                kernel32.CloseHandle(handle)
            except Exception:
                pass
            raise OSError(f"运行时互斥锁等待失败: {result}")
        waited = int(time.monotonic() - started)
        if wait_callback is not None and waited != last_notice:
            last_notice = waited
            wait_callback(waited)
        if time.monotonic() >= deadline:
            try:
                kernel32.CloseHandle(handle)
            except Exception:
                pass
            raise TimeoutError("等待另一个实例完成运行时构建超时")

def _release_runtime_mutex(handle):
    if not handle or kernel32 is None:
        return
    try:
        kernel32.ReleaseMutex(handle)
    except Exception:
        pass
    try:
        kernel32.CloseHandle(handle)
    except Exception:
        pass

class Learner:

    DELAY_BOUNDS = (0.12, 0.28, 0.55, 0.95, 1.45, 2.20, 3.40, 5.20, 8.00, 12.00)

    # Opposite/synergistic keys are learned from transitions and sequences.  No
    # key is assigned a movement meaning before the environment demonstrates it.
    INVERSES = {}

    def __init__(self, state_file):
        self.state_file = Path(state_file)
        self.stats = {}
        self.contexts = {}
        self.families = {}
        self.pairs = {}
        self.triples = {}
        self.sequences = {}
        self.sequence_contexts = {}
        self.aliases = {}
        self.models = {}
        self.steps = 0
        self.best = None
        self.last_action = None
        self.prev_action = None
        self.last_reward = 0.0
        self.positive = 0
        self.history = []
        self.atomic_trace = []
        self.recent = {}
        self.action_trace = []
        self.delays = {}
        self.delayed_attribute_effects = {}
        self.passive = {}
        self.passive_families = {}
        self.outcomes = {}
        self.return_trace = []
        self.trajectory = []
        self.eligibility = []
        self.last_rate_signal = 0.0
        self.nstep = {}
        self.trajectory_sequences = {}
        self.rates = {}
        self.passive_rates = {}
        self.passive_attributes = {}
        self.influence = {}
        self.effects = {}
        self.scopes = {}
        self.parameters = {}
        self.numeric_scales = {}
        self.relation_candidates = {}
        self.attribute_relations = {}
        self.input_reliability = {}
        self.measurement_failures = {}
        self.causal_validations = {}
        self.side_effects = {}
        self.attribute_trace = []
        self.factor_trace = []
        self._attribute_relation_index = {}
        self._attribute_relation_index_step = -1
        self._db = None
        self._table_specs = {
            "stats": "actions", "contexts": "contexts", "families": "families",
            "pairs": "pairs", "triples": "triples", "sequences": "sequences",
            "sequence_contexts": "sequence_contexts", "aliases": "aliases",
            "models": "transitions", "delays": "delays",
            "delayed_attribute_effects": "delayed_attribute_effects", "passive": "passive",
            "passive_families": "passive_families", "nstep": "nstep",
            "trajectory_sequences": "trajectory_sequences", "rates": "rates",
            "passive_rates": "passive_rates", "passive_attributes": "passive_attributes",
            "influence": "influence",
            "effects": "effects", "scopes": "scopes", "parameters": "parameters",
            "numeric_scales": "numeric_scales",
            "key_probes": "key_probes", "coverage": "coverage",
            "relation_candidates": "relation_candidates",
            "attribute_relations": "attribute_relations",
            "input_reliability": "input_reliability",
            "measurement_failures": "measurement_failures",
            "causal_validations": "causal_validations",
            "side_effects": "side_effects",
        }
        self._dirty = {table: set() for table in self._table_specs.values()}
        self._deleted = {table: set() for table in self._table_specs.values()}
        self._table_by_id = {}
        self._open_store()
        self._sync_table_refs()

    def _sync_table_refs(self):
        self._table_by_id = {id(getattr(self, attr)): table for attr, table in self._table_specs.items()}

    def _open_store(self):
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(self.state_file), timeout=6.0)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute("PRAGMA temp_store=MEMORY")
        self._db.execute("PRAGMA busy_timeout=6000")
        for table in self._table_specs.values():
            self._db.execute(f'CREATE TABLE IF NOT EXISTS "{table}" (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID')
        self._db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID')
        self._db.commit()
        for attr, table in self._table_specs.items():
            loaded = {}
            try:
                for key, value in self._db.execute(f'SELECT key, value FROM "{table}"'):
                    try:
                        loaded[str(key)] = json.loads(value)
                    except Exception:
                        continue
            except sqlite3.DatabaseError:
                loaded = {}
            setattr(self, attr, loaded)
        meta = {}
        try:
            for key, value in self._db.execute('SELECT key, value FROM meta'):
                try:
                    meta[str(key)] = json.loads(value)
                except Exception:
                    continue
        except sqlite3.DatabaseError:
            meta = {}
        self.steps = int(meta.get("steps", 0) or 0)
        self.best = meta.get("best")
        self.positive = int(meta.get("positive", 0) or 0)
        self.recent = meta.get("recent", {}) if isinstance(meta.get("recent", {}), dict) else {}
        self.outcomes = meta.get("outcomes", {}) if isinstance(meta.get("outcomes", {}), dict) else {}
        # Only ESC is a hard global exclusion; all other keys use state-aware cooldowns.

    def _mark_dirty(self, table, key):
        table_name = self._table_by_id.get(id(table))
        if table_name:
            self._dirty[table_name].add(str(key))
            self._deleted[table_name].discard(str(key))

    def _delete_key(self, attr, key):
        table = getattr(self, attr)
        if key in table:
            del table[key]
            table_name = self._table_specs[attr]
            self._deleted[table_name].add(str(key))
            self._dirty[table_name].discard(str(key))

    @staticmethod
    def _value(stat):
        base_q = float(stat.get("long_q", stat.get("q", 0.0)))
        recent_q = float(stat.get("recent_q", base_q))
        drift = max(0.0, min(1.0, float(stat.get("drift", 0.0))))
        q = base_q * (1.0 - 0.72 * drift) + recent_q * (0.72 * drift)
        short_n = int(stat.get("short_n", 0))
        medium_n = int(stat.get("medium_n", 0))
        long_n = int(stat.get("return_n", 0))
        target_n = int(stat.get("target_return_n", 0))
        if short_n:
            q = q * 0.84 + float(stat.get("short_return", q)) * 0.16
        if medium_n:
            q = q * 0.87 + float(stat.get("medium_return", q)) * 0.13
        if long_n:
            q = q * 0.88 + float(stat.get("long_return", q)) * 0.12
        if target_n:
            # Episode-future peak improvement is intentionally stronger than
            # immediate return once enough observations support it.
            weight = min(0.24, 0.08 + math.log1p(target_n) * 0.035)
            q = q * (1.0 - weight) + float(stat.get("long_target_return", q)) * weight
        return q, int(stat.get("n", 0)), float(stat.get("v", 0.0))

    @staticmethod
    def _horizon_value(stat):
        return (float(stat.get("short_return", 0.0)), int(stat.get("short_n", 0)),
                float(stat.get("long_return", 0.0)), int(stat.get("return_n", 0)))

    def _update_return_stat(self, table, key, short_value, long_value,
                            medium_value=None, target_value=None):
        stat = table.setdefault(key, {"n": 0, "q": 0.0, "long_q": 0.0, "recent_q": 0.0,
                                      "drift": 0.0, "last_seen": 0, "v": 0.0,
                                      "good": 0, "bad": 0, "zero": 0, "up": 0.0, "down": 0.0})
        sn = int(stat.get("short_n", 0)) + 1
        ln = int(stat.get("return_n", 0)) + 1
        mn = int(stat.get("medium_n", 0)) + (1 if medium_value is not None else 0)
        tn = int(stat.get("target_return_n", 0)) + (1 if target_value is not None else 0)
        srate = max(0.06, 1.0 / min(18, sn))
        lrate = max(0.028, 1.0 / min(46, ln))
        stat["short_return"] = float(stat.get("short_return", short_value)) + srate * (
            float(short_value) - float(stat.get("short_return", short_value)))
        stat["long_return"] = float(stat.get("long_return", long_value)) + lrate * (
            float(long_value) - float(stat.get("long_return", long_value)))
        if medium_value is not None:
            mrate = max(0.04, 1.0 / min(30, max(1, mn)))
            stat["medium_return"] = float(stat.get("medium_return", medium_value)) + mrate * (
                float(medium_value) - float(stat.get("medium_return", medium_value)))
            stat["medium_n"] = mn
        if target_value is not None:
            trate = max(0.025, 1.0 / min(60, max(1, tn)))
            stat["long_target_return"] = float(stat.get("long_target_return", target_value)) + trate * (
                float(target_value) - float(stat.get("long_target_return", target_value)))
            stat["target_return_n"] = tn
        stat["short_n"], stat["return_n"] = sn, ln
        self._mark_dirty(table, key)

    def _update_horizon_trace(self, action, state, reward, observed_at=None, before=None, after=None):
        now = float(observed_at if observed_at is not None else time.monotonic())
        current_after = float(after) if after is not None else None
        kept = []
        for entry in self.return_trace:
            age = max(0.0, now - float(entry["time"]))
            learned_horizon = max(2.0, self.adaptive_credit_horizon(entry.get("action")))
            short_tau = 2.0
            medium_tau = 30.0
            long_tau = max(30.0, learned_horizon * 1.8)
            entry["short"] += math.exp(-age / short_tau) * float(reward)
            entry["medium"] = float(entry.get("medium", entry.get("long", 0.0))) + math.exp(-age / medium_tau) * float(reward)
            entry["long"] += math.exp(-age / long_tau) * float(reward)
            target_return = float(entry.get("target_return", 0.0))
            if current_after is not None:
                peak = max(float(entry.get("peak", current_after)), current_after)
                entry["peak"] = peak
                start_value = float(entry.get("start_value", peak))
                ref = max(1e-6, abs(start_value) * 0.0025, abs(peak) * 1e-9, 1e-6)
                target_return = math.asinh((peak - start_value) / ref)
                entry["target_return"] = max(-12.0, min(12.0, target_return))
            self._update_return_stat(self.stats, entry["action"], entry["short"], entry["long"],
                                     entry.get("medium"), entry.get("target_return"))
            self._update_return_stat(self.contexts, self._context_key(entry["state"], entry["action"]),
                                     entry["short"], entry["long"], entry.get("medium"),
                                     entry.get("target_return"))
            kept.append(entry)
        # Retention is count-bounded for memory only; there is no time cutoff.
        self.return_trace = kept[-255:]
        start_value = float(before) if before is not None else (current_after if current_after is not None else 0.0)
        peak = current_after if current_after is not None else start_value
        ref = max(1e-6, abs(start_value) * 0.0025, abs(peak) * 1e-9, 1e-6)
        target_return = math.asinh((peak - start_value) / ref)
        current = {"action": action, "state": state, "time": now,
                   "short": float(reward), "medium": float(reward), "long": float(reward),
                   "start_value": start_value, "peak": peak,
                   "target_return": max(-12.0, min(12.0, target_return))}
        self.return_trace.append(current)
        self._update_return_stat(self.stats, action, current["short"], current["long"],
                                 current["medium"], current["target_return"])
        self._update_return_stat(self.contexts, self._context_key(state, action),
                                 current["short"], current["long"], current["medium"],
                                 current["target_return"])

    def _nstep_value(self, state, action):
        values = []
        for key, weight in ((f"global>{action}", 0.72),):
            q, n, v = self._value(self.nstep.get(key, {}))
            if n:
                values.append((q, n, v, weight))
        for family in self._state_families(state)[:4]:
            q, n, v = self._value(self.nstep.get(f"{family}>{action}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [w * min(3.5, 0.6 + math.log1p(n)) for _q, n, _v, w in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _base), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _w in values),
                sum(v * w for (_q, _n, v, _base), w in zip(values, weights)) / denom)

    def _sequence_value(self, action, state):
        parts = self._macro_parts(action)
        if len(parts) < 2:
            return 0.0, 0, 0.0
        key = "|".join(parts)
        values = []
        for table, base_w in ((self.sequences, 0.82), (self.trajectory_sequences, 1.12)):
            q, n, v = self._value(table.get(key, {}))
            if n:
                values.append((q, n, v, base_w))
        for family in self._state_families(state)[:4]:
            q, n, v = self._value(self.sequence_contexts.get(f"{family}>{key}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [base * min(3.6, 0.62 + math.log1p(n)) for _q, n, _v, base in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _b), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _b in values),
                sum(v * w for (_q, _n, v, _b), w in zip(values, weights)) / denom)

    def passive_rate_estimate(self, state):
        """Return expected no-action rate, effective evidence and uncertainty."""
        global_q, global_n, global_v = self._value(self.passive_rates.get("global", {}))
        values = []
        evidence = 0.0
        variance = 0.0
        for family in self._state_families(state)[:4]:
            q, n, v = self._value(self.passive_rates.get(family, {}))
            if n:
                weight = min(3.0, 0.65 + math.log1p(n))
                values.append((q, weight))
                evidence += float(n)
                variance += max(0.0, float(v)) * weight
        if not values:
            return (global_q if global_n else 0.0, float(global_n), max(0.0, float(global_v)))
        denom = max(1e-9, sum(weight for _q, weight in values))
        local = sum(q * weight for q, weight in values) / denom
        mean = 0.68 * local + 0.32 * global_q if global_n else local
        evidence += float(global_n) * 0.35
        uncertainty = variance / denom
        if global_n:
            uncertainty = uncertainty * 0.76 + max(0.0, float(global_v)) * 0.24
        return mean, evidence, uncertainty

    @staticmethod
    def _rate_signal(before, after, elapsed, confidence=1.0):
        elapsed = max(0.06, min(20.0, float(elapsed or 0.0)))
        delta = float(after) - float(before)
        reference = max(1e-6, abs(float(before)) * 0.0025, abs(float(after)) * 1e-9)
        signal = math.asinh(delta / (reference * elapsed)) if delta else 0.0
        conf = max(0.0, min(1.0, float(confidence)))
        reliability = max(0.03, min(1.0, (conf - 0.20) / 0.68))
        return max(-8.0, min(8.0, signal * reliability))

    @staticmethod
    def _influence_key(action, bins=8):
        point = Learner._mouse_point(action)
        if point is not None:
            fx, fy = point
            x = max(0, min(bins - 1, int(fx * bins)))
            y = max(0, min(bins - 1, int(fy * bins)))
            return f"r{bins}:{x}:{y}"
        raw = str(action or "")
        if raw.startswith("key:"):
            return "k:" + raw.split(":", 1)[1]
        if raw.startswith(("hold:", "pulse:")):
            parts = raw.split(":")
            return "k:" + parts[1] if len(parts) > 1 else None
        if raw.startswith("chord:"):
            names = raw.split(":", 2)[1]
            return "c:" + hashlib.sha1(names.encode("utf-8", "replace")).hexdigest()[:10]
        if raw == OBSERVE_ACTION or not raw:
            return None
        family = raw.split(":", 1)[0]
        return "a:" + family + ":" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:8]

    def influence_value(self, state, action):
        region = self._influence_key(action)
        if region is None:
            return 0.0, 0, 0.0
        values = []
        for key, base_w in ((f"global>{region}", 0.72), (f"action>{action}", 0.88)):
            q, n, v = self._value(self.influence.get(key, {}))
            if n:
                values.append((q, n, v, base_w))
        for family in self._state_families(state)[:3]:
            q, n, v = self._value(self.influence.get(f"{family}>{region}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [base * min(3.0, 0.65 + math.log1p(n)) for _q, n, _v, base in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _b), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _b in values),
                sum(v * w for (_q, _n, v, _b), w in zip(values, weights)) / denom)

    def observe_influence(self, action, state, visual_change=0.0, reward=0.0):
        if action == OBSERVE_ACTION:
            return
        region = self._influence_key(action)
        if region is None:
            return
        change = max(0.0, min(2.0, float(visual_change)))
        payoff = max(-2.0, min(2.0, float(reward)))
        target = change * 0.95 + max(0.0, payoff) * 0.16
        if change < 0.025 and abs(payoff) < 0.035:
            target -= 0.18
        if payoff < -0.35:
            target -= min(0.30, abs(payoff) * 0.05)
        target = max(-0.65, min(2.2, target))
        self._update(self.influence, f"global>{region}", target, 0.88, record_outcome=False)
        self._update(self.influence, f"action>{action}", target, 0.72, record_outcome=False)
        for family in self._state_families(state)[:3]:
            self._update(self.influence, f"{family}>{region}", target, 0.80, record_outcome=False)

    def scope_value(self, scope_key):
        stat = self.scopes.get(str(scope_key), {})
        if not isinstance(stat, dict):
            return 0.0, 0.0, 0.0
        n = max(0.0, float(stat.get("n", 0.0)))
        if n <= 0.0:
            return 0.0, 0.0, 0.0
        reward = float(stat.get("reward", 0.0))
        visual = float(stat.get("visual", 0.0))
        effective = float(stat.get("effective", 0.0))
        risk = float(stat.get("risk", 0.0))
        value = reward + visual * 0.18 + effective * 0.30 - risk * 0.62
        return value, n, risk

    def choose_scope(self, scope_keys, stagnant=0, priors=None):
        ordered = list(dict.fromkeys(str(key) for key in scope_keys if key))
        if not ordered:
            return None
        priors = dict(priors or {})
        total = sum(self.scope_value(key)[1] for key in ordered) + 2.0
        scored = []
        for key in ordered:
            value, n, risk = self.scope_value(key)
            stat = self.scopes.get(key, {}) if isinstance(self.scopes.get(key, {}), dict) else {}
            effective = max(0.0, min(1.0, float(stat.get("effective", 0.0) or 0.0)))
            alpha = 1.0 + effective * n
            beta = 1.0 + max(0.0, (1.0 - effective) * n + risk * n)
            try:
                thompson = random.betavariate(alpha, beta) - 0.5
            except (ValueError, OverflowError):
                thompson = effective - 0.5
            uncertainty = 1.0 / math.sqrt(n + 1.0)
            information_weight = ((0.24 + min(0.30, max(0, stagnant) * 0.006)) *
                                  math.exp(-n / 18.0))
            exploration = math.sqrt(math.log(total + 1.0) / (n + 1.0)) * information_weight
            prior = max(0.001, min(0.999, float(priors.get(key, 0.50))))
            # Priors rank every region from the first decision but never exclude one.
            # Their influence decays rapidly once the scope has measured evidence.
            prior_term = (prior - 0.5) * 0.72 * math.exp(-n / 2.4)
            scored.append((value + thompson * 0.20 + exploration + prior_term - risk * 0.24, key))
        return max(scored)[1]

    def observe_scope(self, scope_key, reward=0.0, visual_change=0.0,
                      performed=True, blocked=False):
        if not scope_key:
            return
        key = str(scope_key)
        weight = 1.0 if performed else 0.35
        stat = self.scopes.setdefault(
            key, {"n": 0.0, "reward": 0.0, "visual": 0.0,
                  "effective": 0.0, "risk": 0.0})
        old_n = max(0.0, float(stat.get("n", 0.0)))
        new_n = old_n + weight
        payoff = max(-4.0, min(4.0, float(reward)))
        visual = max(0.0, min(2.0, float(visual_change)))
        effective = 1.0 if visual >= 0.025 or abs(payoff) >= 0.035 else 0.0
        risk = 1.0 if blocked or payoff < -0.35 else 0.0
        for name, value in (("reward", payoff), ("visual", visual),
                            ("effective", effective), ("risk", risk)):
            old = float(stat.get(name, 0.0))
            stat[name] = old + (value - old) * weight / max(1e-9, new_n)
        stat["n"] = new_n
        stat["last_seen"] = int(time.time())
        self._mark_dirty(self.scopes, key)

    def focus_actions(self, actions, state, stagnant, priors=None, limit=110):
        actions = list(dict.fromkeys(actions))
        if len(actions) <= limit or stagnant >= 34:
            return actions
        priors = priors or {}
        scored, unknown = [], []
        for action in actions:
            iq, inn, _iv = self.influence_value(state, action)
            if inn <= 0:
                unknown.append(action)
                continue
            quality = self.action_quality(action, state)
            prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
            _q, trials, _v = self._value(self.stats.get(action, {}))
            prior_strength = math.exp(-max(0.0, float(trials)) / 1.15)
            score = quality * 0.58 + iq * 0.58 + (prior - 0.5) * 0.10 * prior_strength
            scored.append((score, action))
        if len(scored) < max(12, len(actions) // 8):
            return actions[:max(limit, min(len(actions), limit + 24))]
        exploit_budget = max(12, int(limit * (0.82 if stagnant < 14 else 0.70)))
        explore_budget = max(6, limit - exploit_budget)
        kept = [a for _score, a in sorted(scored, reverse=True)[:exploit_budget]]
        if unknown:
            stride = max(1, len(unknown) // explore_budget)
            offset = self.steps % stride
            kept.extend(unknown[offset::stride][:explore_budget])
        if stagnant >= 18:
            extras = [a for _score, a in sorted(scored, key=lambda x: x[0])[:max(4, limit // 10)]]
            kept.extend(extras)
        return list(dict.fromkeys(kept))[:limit]

    def _trajectory_learning(self, action, state, reward, next_state, reliability,
                             before, after, best_before):
        now = time.monotonic()
        transition = {
            "action": action, "state": state, "next": next_state,
            "reward": float(reward), "before": float(before), "after": float(after),
            "reliability": float(reliability), "step": int(self.steps), "time": now,
        }
        self.trajectory.append(transition)
        if len(self.trajectory) > 192:
            self.trajectory = self.trajectory[-192:]

        gamma = LEARNING_CONFIG.discount_gamma
        lam = LEARNING_CONFIG.eligibility_lambda
        recent = self.trajectory[-64:]
        returns = [0.0] * len(recent)
        running = 0.0
        for idx in range(len(recent) - 1, -1, -1):
            running = float(recent[idx]["reward"]) + gamma * running
            returns[idx] = running

        breakout = best_before is not None and float(after) > float(best_before)
        horizon = max(2.0, self.adaptive_credit_horizon())
        for idx, (item, g_return) in enumerate(zip(recent, returns)):
            age_steps = len(recent) - 1 - idx
            age_seconds = max(0.0, now - float(item.get("time", now)))
            eligibility = max(lam ** age_steps, math.exp(-age_seconds / horizon) * 0.42)
            target = g_return
            if breakout and age_steps > 0:
                ref = max(1e-6, abs(float(item["before"])) * 0.0025, abs(float(after)) * 1e-9)
                long_gain = math.asinh((float(after) - float(item["before"])) / ref)
                if long_gain > 0:
                    target += min(10.0, long_gain) * (0.78 + min(0.20, math.log1p(age_steps) * 0.035))
            target = max(-12.0, min(12.0, target))
            weight = max(0.10, min(1.0, float(item.get("reliability", 1.0)))) * eligibility
            old_action, old_state = item["action"], item["state"]
            self._update(self.nstep, f"global>{old_action}", target, 0.78 * weight,
                         record_outcome=False)
            for family in self._state_families(old_state)[:4]:
                self._update(self.nstep, f"{family}>{old_action}", target, 0.82 * weight,
                             record_outcome=False)

        atomic = []
        for item in recent[-16:]:
            atomic.extend(self._macro_parts(item["action"]))
        atomic = [part for part in atomic if part and part != OBSERVE_ACTION][-24:]
        if atomic:
            terminal_bonus = 0.0
            if breakout and recent:
                start_value = float(recent[max(0, len(recent) - 16)]["before"])
                ref = max(1e-6, abs(start_value) * 0.0025, abs(float(after)) * 1e-9)
                terminal_bonus = max(0.0, min(10.0, math.asinh((float(after) - start_value) / ref)))
            for length in range(2, min(8, len(atomic)) + 1):
                sequence = "|".join(atomic[-length:])
                local_rewards = [float(item["reward"]) for item in recent[-min(length, len(recent)):]]
                seq_return = 0.0
                for r in local_rewards:
                    seq_return = seq_return * gamma + r
                if breakout:
                    breakout_target = terminal_bonus * (0.82 + 0.05 * min(7, length - 1))
                    seq_return = max(seq_return + terminal_bonus * 0.34, breakout_target)
                self._update(self.trajectory_sequences, sequence,
                             max(-12.0, min(12.0, seq_return)),
                             0.72 if length <= 3 else 0.56, record_outcome=breakout)

        if breakout and len(recent) >= 3:
            final_value = float(after)
            for item in recent[:-1]:
                ref = max(1e-6, abs(float(item["before"])) * 0.0025, abs(final_value) * 1e-9)
                goal_return = math.asinh((final_value - float(item["before"])) / ref)
                if goal_return <= 0:
                    continue
                age_seconds = max(0.0, now - float(item.get("time", now)))
                replay_weight = max(0.12, math.exp(-age_seconds / horizon))
                replay_target = min(12.0, goal_return)
                old_action, old_state = item["action"], item["state"]
                self._update(self.nstep, f"global>{old_action}", replay_target, 0.42 * replay_weight,
                             record_outcome=False)
                self._update(self.contexts, self._context_key(old_state, old_action),
                             replay_target, 0.28 * replay_weight, record_outcome=False)

    def needs_isolation(self, action, state, confidence=1.0, scene_changed=False):
        if not action or action == OBSERVE_ACTION:
            return False
        stat = self.stats.get(action, {})
        _q, n, variance = self._value(stat)
        good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
        conflict = (float(stat.get("drift", 0.0)) >= 0.42 or
                    (n >= 3 and good > 0 and bad > 0 and min(good, bad) / max(1, good + bad) >= 0.24) or
                    variance > 0.55)
        return bool(n < 3 or float(confidence) < 0.72 or conflict or scene_changed)

    def _update(self, table, key, target, weight=1.0, record_outcome=True):
        stat = table.setdefault(
            key, {"n": 0, "q": 0.0, "long_q": 0.0, "recent_q": 0.0,
                  "drift": 0.0, "last_seen": 0, "v": 0.0, "good": 0, "bad": 0,
                  "zero": 0, "up": 0.0, "down": 0.0})
        stat["n"] = int(stat.get("n", 0)) + 1
        old = float(stat.get("long_q", stat.get("q", 0.0)))
        n = stat["n"]
        rate = max(0.035, 1.0 / min(n, 32))
        sample = float(target) * float(weight)
        if n >= 9 and old * sample < -0.055 and abs(sample - old) > 0.34:
            rate = max(rate, 0.17 if n < 40 else 0.12)
            stat["good"] = int(float(stat.get("good", 0)) * 0.91)
            stat["bad"] = int(float(stat.get("bad", 0)) * 0.91)
        new = old + rate * (sample - old)
        recent_old = float(stat.get("recent_q", old))
        recent_rate = 0.34 if n < 12 else 0.22
        recent_new = recent_old + recent_rate * (sample - recent_old)
        conflict = ((new * recent_new < -0.035 and abs(new - recent_new) > 0.22) or
                    abs(new - recent_new) > max(0.42, abs(new) * 0.85 + 0.12))
        drift_old = max(0.0, min(1.0, float(stat.get("drift", 0.0))))
        drift_target = 1.0 if conflict else max(0.0, min(1.0, abs(new - recent_new) / 0.9))
        drift = drift_old * (0.82 if conflict else 0.92) + drift_target * (0.18 if conflict else 0.08)
        if drift > 0.58 and n >= 8:
            new = new * 0.76 + recent_new * 0.24
            stat["good"] = int(float(stat.get("good", 0)) * 0.96)
            stat["bad"] = int(float(stat.get("bad", 0)) * 0.96)
            stat["zero"] = int(float(stat.get("zero", 0)) * 0.97)
        stat["q"] = new
        stat["long_q"] = new
        stat["recent_q"] = recent_new
        stat["drift"] = max(0.0, min(1.0, drift))
        stat["last_seen"] = int(time.time())
        err = sample - recent_new
        stat["v"] = float(stat.get("v", 0.0)) * 0.91 + err * err * 0.09
        if record_outcome:
            if sample > 0.035:
                stat["good"] = int(stat.get("good", 0)) + 1
                stat["up"] = float(stat.get("up", 0.0)) * 0.90 + sample * 0.10
                stat["down"] = float(stat.get("down", 0.0)) * 0.94
            elif sample < -0.035:
                stat["bad"] = int(stat.get("bad", 0)) + 1
                stat["down"] = float(stat.get("down", 0.0)) * 0.90 + abs(sample) * 0.10
                stat["up"] = float(stat.get("up", 0.0)) * 0.94
            else:
                stat["zero"] = int(stat.get("zero", 0)) + 1
                stat["up"] = float(stat.get("up", 0.0)) * 0.97
                stat["down"] = float(stat.get("down", 0.0)) * 0.97
        self._mark_dirty(table, key)

    @staticmethod
    def _context_key(state, action):
        return f"{state}>{action}"

    @staticmethod
    def _macro_parts(action):
        if not isinstance(action, str) or not action.startswith("macro:"):
            return (action,)
        payload = action[6:]
        delay_match = re.match(r"^(\d{1,7}):(.*)$", payload, re.S)
        if delay_match:
            payload = delay_match.group(2)
        parts = tuple(x for x in payload.split("|") if x and not x.startswith("macro:"))
        return parts if parts else ()

    @staticmethod
    def _macro_interval_ms(action):
        if not isinstance(action, str) or not action.startswith("macro:"):
            return None
        match = re.match(r"^macro:(\d{1,7}):", action)
        if not match:
            return None
        try:
            # Integrity guard only; the learned search range is not capped here.
            return max(1, min(600000, int(match.group(1))))
        except Exception:
            return None

    @classmethod
    def _make_macro(cls, parts):
        flat = []
        for action in parts:
            flat.extend(cls._macro_parts(action))
        flat = [x for x in flat if x]
        if len(flat) < 2:
            return flat[0] if flat else None
        return "macro:" + "|".join(flat[:6])

    @staticmethod
    def _state_families(state):
        visual = re.search(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)", state)
        semantic = re.search(r":t([udf]):g(\d+):s(\d+):m(-?\d+)", state)
        if not semantic:
            return []
        trend, gap, stale, magnitude = semantic.groups()
        mag = int(magnitude)
        mag_bucket = max(-4, min(10, mag // 2))
        keys = [f"sem:t{trend}:g{gap}:m{mag_bucket}",
                f"stale:t{trend}:s{min(4, int(stale))}"]
        app = re.search(r":a([0-9a-f]{8})", state)
        controls = re.search(r":c([0-9a-f]{8})", state)
        if app:
            keys.append(f"L0:app:{app.group(1)}")
        if controls:
            keys.append(f"L2:controls:{controls.group(1)}:t{trend}")
        semantic_scene = re.search(r":h([0-9a-f]{8})", state)
        if semantic_scene:
            scene_hash = semantic_scene.group(1)
            keys.append(f"ui:{scene_hash[:4]}:t{trend}:g{min(3, int(gap))}")
            keys.append(f"ui2:{scene_hash[4:]}:s{min(4, int(stale))}")
        structured_scene = re.search(r":u([0-9a-f]{10})", state)
        if structured_scene:
            scene_hash = structured_scene.group(1)
            keys.append(f"scene:{scene_hash[:5]}:t{trend}:g{min(3, int(gap))}")
            keys.append(f"scene2:{scene_hash[5:]}:s{min(4, int(stale))}")
            keys.append(f"L1:scene:{scene_hash}:g{min(3, int(gap))}")
        if visual:
            phash, ehash, color, layout = visual.groups()
            for i in range(4):
                band = phash[i * 4:(i + 1) * 4]
                keys.append(f"p{i}:{band}:t{trend}:g{min(3, int(gap))}:c{color}")
            keys.append(f"e0:{ehash[:4]}:t{trend}:l{layout[:2]}")
            keys.append(f"e1:{ehash[4:]}:t{trend}:l{layout[-2:]}")
        feature_match = re.search(r":sf([0-9a-f]{12})n(\d+):", state)
        if feature_match:
            digest, count = feature_match.groups()
            count_bucket = min(7, int(math.log2(int(count) + 1)))
            keys.append(f"features:{digest[:6]}:{digest[6:]}:n{count_bucket}")
        # Numeric state v2 deliberately carries both an exact content hash and
        # coarse structural features.  The latter let similar numeric scenes share
        # experience instead of requiring an identical SHA1 digest.
        number_match = re.search(
            r":nf([0-9a-f]{10})-chg(\d+)-pred(\d+)-dir([udf]):", state)
        if number_match:
            digest, changed_count, predictive_count, target_direction = number_match.groups()
            changed_bucket = min(7, int(math.log2(int(changed_count) + 1)))
            predictive_bucket = min(7, int(math.log2(int(predictive_count) + 1)))
            keys.append(f"L2:numbers:{digest}")
            keys.append(f"numbers:dir{target_direction}:chg{changed_bucket}:pred{predictive_bucket}")
            keys.append(f"numbers2:chg{changed_bucket}:pred{predictive_bucket}")
        else:
            # Compatibility with profiles produced by the short-lived pure-hash
            # format and by the original structured numeric signature.
            hash_match = re.search(r":nf([0-9a-f]{10}):", state)
            if hash_match:
                keys.append(f"L2:numbers:{hash_match.group(1)}")
            legacy_number_match = re.search(
                r":nf([0-9a-f]{4})-([a-z]+)-i(-?\d+|x)-c(-?\d+|x)-l([01])-m([01]):", state)
            if legacy_number_match:
                structure, affordability, income_bucket, cost_bucket, level_changed, multiplier_changed = legacy_number_match.groups()
                keys.append(f"numbers:aff:{affordability}:i{income_bucket}:l{level_changed}:m{multiplier_changed}")
                keys.append(f"numbers2:{structure}:c{cost_bucket}:aff{affordability}")
        rate = re.search(r":v(-?\d+):a(-?\d+)", state)
        if rate:
            velocity, acceleration = rate.groups()
            keys.append(f"dyn:v{velocity}:a{acceleration}:t{trend}")
        motion = re.search(r":r([0-9a-f]{6})", state)
        if motion:
            raw_motion = motion.group(1)
            keys.append(f"motion:{raw_motion[:3]}:t{trend}")
            keys.append(f"motion2:{raw_motion[3:]}:g{min(3, int(gap))}")
        return keys

    @classmethod
    def _key_probe_family(cls, state):
        families = cls._state_families(state)
        if not families:
            raw = str(state or "unknown")
            return "state:" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:12]
        structural = [item for item in families
                      if item.startswith(("L0:", "L1:", "L2:", "ui:", "scene:", "numbers:"))]
        chosen = structural[:4] or families[:4]
        raw = "|".join(chosen)
        return "family:" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:12]

    @staticmethod
    def _coverage_key_from_point(point, rows=8, cols=12):
        try:
            fx, fy = point
            col = max(0, min(cols - 1, int(float(fx) * cols)))
            row = max(0, min(rows - 1, int(float(fy) * rows)))
            return f"r{rows}c{cols}:{row}:{col}"
        except Exception:
            return None

    def key_probe_status(self, name, state):
        family = self._key_probe_family(state)
        key = f"{name}|{family}"
        stat = self.key_probes.get(key, {})
        env_stat = self.key_probes.get(f"{name}|environment", {})
        alpha = max(0.0, float(stat.get("effect_alpha", 1.0)))
        beta = max(0.0, float(stat.get("effect_beta", 1.0)))
        effect_probability = alpha / max(1e-9, alpha + beta)
        cooldown_until = max(int(stat.get("cooldown_until", 0) or 0),
                             int(env_stat.get("cooldown_until", 0) or 0))
        return {
            "key": key, "family": family,
            "miss_count": int(stat.get("miss_count", 0) or 0),
            "last_probe_step": int(stat.get("last_probe_step", -1)),
            "cooldown_until": cooldown_until,
            "effect_probability": effect_probability,
            "samples": max(0.0, alpha + beta - 2.0),
        }

    def key_probe_allowed(self, name, state, stagnant=0):
        status = self.key_probe_status(name, state)
        if self.steps >= status["cooldown_until"]:
            return True
        # Severe stagnation may revisit a state-local no-effect cooldown, but an
        # environment focus-loss cooldown remains protected until it expires.
        env = self.key_probes.get(f"{name}|environment", {})
        if self.steps < int(env.get("cooldown_until", 0) or 0):
            return False
        if int(stagnant) >= LEARNING_CONFIG.stagnation_extreme:
            interval = max(9, int(math.sqrt(status["samples"] + 1.0) * 11.0))
            seed = int(hashlib.sha1(status["key"].encode("utf-8", "replace")).hexdigest()[:6], 16)
            return (self.steps + seed) % interval == 0
        return False

    def observe_key_probe(self, name, state, effect=False, confidence=1.0, lost_focus=False):
        name = str(name or "")
        if not name:
            return
        confidence = max(0.0, min(1.0, float(confidence or 0.0)))
        family = self._key_probe_family(state)
        key = f"{name}|{family}"
        stat = self.key_probes.setdefault(
            key, {"miss_count": 0, "last_probe_step": -1, "cooldown_until": 0,
                  "effect_alpha": 1.0, "effect_beta": 1.0, "effect_probability": 0.5})
        stat["last_probe_step"] = int(self.steps)
        weight = max(0.12, confidence)
        if effect:
            stat["effect_alpha"] = float(stat.get("effect_alpha", 1.0)) + weight
            stat["miss_count"] = 0
            stat["cooldown_until"] = min(int(stat.get("cooldown_until", 0) or 0), self.steps)
        elif confidence >= 0.35:
            stat["effect_beta"] = float(stat.get("effect_beta", 1.0)) + weight
            misses = int(stat.get("miss_count", 0) or 0) + 1
            stat["miss_count"] = misses
            alpha = float(stat.get("effect_alpha", 1.0))
            beta = float(stat.get("effect_beta", 1.0))
            posterior = alpha / max(1e-9, alpha + beta)
            # Low posterior means lower priority in this state, never permanent deletion.
            if misses >= 2:
                cooldown = int(round((8.0 + 18.0 * (1.0 - posterior)) *
                                     min(12.0, 1.55 ** min(7, misses - 1))))
                stat["cooldown_until"] = max(int(stat.get("cooldown_until", 0) or 0),
                                             self.steps + cooldown)
        alpha = float(stat.get("effect_alpha", 1.0))
        beta = float(stat.get("effect_beta", 1.0))
        stat["effect_probability"] = alpha / max(1e-9, alpha + beta)
        self._mark_dirty(self.key_probes, key)

        if lost_focus:
            env_key = f"{name}|environment"
            env = self.key_probes.setdefault(
                env_key, {"miss_count": 0, "last_probe_step": -1, "cooldown_until": 0,
                          "effect_alpha": 1.0, "effect_beta": 1.0, "effect_probability": 0.5})
            misses = int(env.get("miss_count", 0) or 0) + 1
            env["miss_count"] = misses
            env["last_probe_step"] = int(self.steps)
            env["effect_beta"] = float(env.get("effect_beta", 1.0)) + max(0.5, weight)
            env["effect_probability"] = float(env.get("effect_alpha", 1.0)) / max(
                1e-9, float(env.get("effect_alpha", 1.0)) + float(env.get("effect_beta", 1.0)))
            long_cooldown = int(round(min(2400.0, 90.0 * (1.75 ** min(6, misses - 1)))))
            env["cooldown_until"] = max(int(env.get("cooldown_until", 0) or 0),
                                        self.steps + long_cooldown)
            self._mark_dirty(self.key_probes, env_key)

    def observe_spatial_coverage(self, action, reward=0.0):
        # A persistent, multi-scale interaction heat map. Coarse cells generalize early;
        # finer cells become useful automatically as observations accumulate.
        for part in self._macro_parts(action):
            point = self._mouse_point(part)
            if point is None:
                continue
            for rows, cols in ((4, 6), (8, 12), (16, 24)):
                key = self._coverage_key_from_point(point, rows=rows, cols=cols)
                if not key:
                    continue
                stat = self.coverage.setdefault(
                    key, {"n": 0.0, "effect": 0.0, "reward": 0.0,
                          "positive": 0.0, "last_step": -1})
                n = float(stat.get("n", 0.0)) + 1.0
                sample = float(reward)
                stat["effect"] = float(stat.get("effect", 0.0)) + (
                    abs(sample) - float(stat.get("effect", 0.0))) / n
                stat["reward"] = float(stat.get("reward", 0.0)) + (
                    sample - float(stat.get("reward", 0.0))) / n
                positive = 1.0 if sample > 0.035 else 0.0
                stat["positive"] = float(stat.get("positive", 0.0)) + (
                    positive - float(stat.get("positive", 0.0))) / n
                stat["n"] = n
                stat["last_step"] = int(self.steps)
                self._mark_dirty(self.coverage, key)

    def interaction_map_value(self, point):
        if point is None:
            return 0.0, 0.0, 1.0
        weighted = evidence = 0.0
        uncertainty = 0.0
        for rows, cols, scale in ((4, 6, 0.55), (8, 12, 0.85), (16, 24, 1.0)):
            key = self._coverage_key_from_point(point, rows=rows, cols=cols)
            stat = self.coverage.get(key, {}) if key else {}
            n = max(0.0, float(stat.get("n", 0.0)))
            if n <= 0.0:
                uncertainty += scale
                continue
            reward = float(stat.get("reward", 0.0))
            effect = max(0.0, float(stat.get("effect", 0.0)))
            positive = max(0.0, min(1.0, float(stat.get("positive", 0.0))))
            age = max(0, self.steps - int(stat.get("last_step", self.steps)))
            freshness = math.exp(-age / max(45.0, 9.0 * math.sqrt(n + 1.0)))
            confidence = min(1.0, math.log1p(n) / 2.8) * scale
            # Reward direction dominates; visual/effect likelihood keeps interactive
            # regions alive even before their target-value consequence is understood.
            value = reward * 0.72 + effect * (0.10 + 0.12 * positive)
            if n >= 3.0 and effect < 0.035 and positive < 0.12:
                value -= min(0.24, math.log1p(n) * 0.045)
            weighted += value * confidence * (0.62 + 0.38 * freshness)
            evidence += confidence
            uncertainty += scale / math.sqrt(n + 1.0)
        return (weighted / max(1e-9, evidence) if evidence else 0.0,
                evidence, uncertainty / (0.55 + 0.85 + 1.0))

    @classmethod
    def _inverse_action(cls, action):
        direct = cls.INVERSES.get(action)
        if direct:
            return direct
        if not isinstance(action, str):
            return None
        if action.startswith("hold:"):
            parts = action.split(":")
            if len(parts) == 3:
                inverse = cls.INVERSES.get(f"key:{parts[1]}")
                if inverse:
                    return f"hold:{inverse.split(':', 1)[1]}:{parts[2]}"
        if action.startswith("pulse:"):
            parts = action.split(":")
            if len(parts) == 5:
                inverse = cls.INVERSES.get(f"key:{parts[1]}")
                if inverse:
                    return f"pulse:{inverse.split(':', 1)[1]}:{parts[2]}:{parts[3]}:{parts[4]}"
        if action.startswith("chord:"):
            names = action.split(":", 1)[1].split("+")
            changed = False
            mapped = []
            for name in names:
                inverse = cls.INVERSES.get(f"key:{name}")
                if inverse:
                    mapped.append(inverse.split(":", 1)[1])
                    changed = True
                else:
                    mapped.append(name)
            if changed:
                return "chord:" + "+".join(mapped)
        return None

    @classmethod
    def _model_state(cls, state):

        families = cls._state_families(state)
        if not families:
            return "unknown"
        return "~".join(families[:4])

    def _update_model(self, state, action, reward, next_state, reliability=1.0):
        current = self._model_state(state)
        following = self._model_state(next_state)
        key = f"{current}>{action}"
        prior_q, prior_n, _prior_variance = self._value(self.models.get(key, {}))
        self._update(self.models, key, reward, max(0.18, min(1.0, reliability)),
                     record_outcome=reliability >= 0.30)
        stat = self.models.get(key, {})
        prediction = prior_q if prior_n > 0 else 0.0
        error = float(reward) - float(prediction)
        error_weight = max(0.08, min(1.0, float(reliability)))
        old_en = float(stat.get("prediction_n", 0.0))
        new_en = old_en + error_weight
        old_mean = float(stat.get("prediction_error_mean", 0.0))
        delta_error = error - old_mean
        new_mean = old_mean + delta_error * error_weight / max(1e-9, new_en)
        stat["prediction_error_m2"] = (float(stat.get("prediction_error_m2", 0.0)) +
                                       error_weight * delta_error * (error - new_mean))
        stat["prediction_error_mean"] = new_mean
        stat["prediction_error_abs"] = (float(stat.get("prediction_error_abs", abs(error))) * 0.82 +
                                         abs(error) * 0.18)
        stat["prediction_n"] = new_en
        stat["last_seen"] = int(time.time())
        self._mark_dirty(self.models, key)
        if not isinstance(stat.get("next"), dict):
            stat["next"] = {}
        transitions = stat["next"]
        transitions[following] = float(transitions.get(following, 0.0)) + max(
            0.12, min(1.0, reliability))
        if len(transitions) > 9:
            keep = sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:9]
            stat["next"] = dict(keep)
            transitions = stat["next"]
        total = sum(float(value) for value in transitions.values())
        if total > 160.0:
            for name in tuple(transitions):
                transitions[name] = float(transitions[name]) * 0.72

    def _effect_value(self, state, action):
        values = []
        keys = [(f"global>{action}", 0.72)]
        keys.extend((f"{family}>{action}", 1.0) for family in self._state_families(state)[:4])
        for key, base_weight in keys:
            stat = self.effects.get(key, {})
            n = float(stat.get("n", 0.0)) if isinstance(stat, dict) else 0.0
            chain_n = float(stat.get("chain_n", 0.0)) if isinstance(stat, dict) else 0.0
            if n <= 0 and chain_n <= 0:
                continue
            utility = float(stat.get("utility", 0.0))
            if chain_n > 0:
                chain_weight = min(0.48, 0.10 + math.log1p(chain_n) * 0.075)
                utility = utility * (1.0 - chain_weight) + float(
                    stat.get("chain_utility", 0.0)) * chain_weight
            uncertainty = float(stat.get("uncertainty", 0.0))
            combined_n = n + chain_n * 0.35
            weight = base_weight * min(4.0, 0.65 + math.log1p(combined_n))
            values.append((utility, uncertainty, combined_n, weight))
        if not values:
            return 0.0, 0.0, 0.0
        denom = max(1e-9, sum(item[3] for item in values))
        utility = sum(item[0] * item[3] for item in values) / denom
        uncertainty = sum(item[1] * item[3] for item in values) / denom
        n = sum(item[2] for item in values)
        return utility, n, uncertainty

    @staticmethod
    def _prediction_reliability(samples, variance=0.0, mean_error=0.0):
        samples = max(0.0, float(samples or 0.0))
        evidence = 1.0 - math.exp(-samples / 4.0)
        noise = math.sqrt(max(0.0, float(variance or 0.0))) + abs(float(mean_error or 0.0))
        return max(0.0, min(1.0, evidence / (1.0 + noise)))

    @staticmethod
    def _blend_estimates(estimates, fallback=0.0):
        """Blend learned estimates by evidence and observed variance, not fixed source weights."""
        weighted = 0.0
        weight_sum = 0.0
        evidence = 0.0
        uncertainty = 0.0
        for estimate in estimates:
            try:
                q, n, variance = float(estimate[0]), max(0.0, float(estimate[1])), max(0.0, float(estimate[2]))
            except (TypeError, ValueError, OverflowError, IndexError):
                continue
            if n <= 0.0 or not math.isfinite(q):
                continue
            reliability = (n / (n + 1.0)) / (1.0 + math.sqrt(variance))
            if reliability <= 0.0:
                continue
            weighted += q * reliability
            weight_sum += reliability
            evidence += n
            uncertainty += math.sqrt(variance) * reliability
        if weight_sum <= 0.0:
            return float(fallback), 0.0, 0.0
        return weighted / weight_sum, evidence, uncertainty / weight_sum

    def predict_target_gain(self, state, action):
        """Predict action-caused TARGET gain through learned numeric attributes.

        The prediction follows action -> expected entity/attribute transition ->
        learned attribute relation -> future TARGET value.  Passive-pair relations
        are excluded, so this is a causal residual estimate rather than a raw
        temporal correlation.
        """
        state_condition = self._key_probe_family(state)
        source_effect = self.effects.get(f"global>{action}", {})
        source_entities = source_effect.get("entities", {}) if isinstance(source_effect, dict) else {}
        if self._attribute_relation_index_step != self.steps:
            index = {}
            for relation in self.attribute_relations.values():
                if not isinstance(relation, dict) or bool(relation.get("passive_pair", False)):
                    continue
                from_action = str(relation.get("from_action", ""))
                if from_action:
                    index.setdefault(from_action, []).append(relation)
            self._attribute_relation_index = index
            self._attribute_relation_index_step = self.steps
        weighted_prediction = 0.0
        total_weight = 0.0
        evidence = 0.0
        weighted_uncertainty = 0.0
        for relation in self._attribute_relation_index.get(str(action), ()):
            try:
                if (not bool(relation.get("to_target", False)) or
                        str(relation.get("to_attribute", "")) != "value"):
                    continue
                n = max(0.0, float(relation.get("n", 0.0)))
                if n < 0.35:
                    continue
                exact_state = str(relation.get("state_condition", "")) == state_condition
                state_weight = 1.0 if exact_state else 0.42
                from_entity = str(relation.get("from_entity", ""))
                from_attribute = str(relation.get("from_attribute", ""))
                attr_stat = {}
                entity_stat = source_entities.get(from_entity, {}) if isinstance(source_entities, dict) else {}
                if isinstance(entity_stat, dict):
                    attrs = entity_stat.get("attributes", {})
                    if isinstance(attrs, dict):
                        attr_stat = attrs.get(from_attribute, {}) or {}
                expected_signal = float(attr_stat.get("mean", relation.get("from_signal", 0.0)) or 0.0)
                change_rate = max(0.05, min(1.0, float(attr_stat.get("change_rate", 1.0) or 0.0)))
                from_signal = float(relation.get("from_signal", 0.0) or 0.0)
                from_sq = max(0.04, float(relation.get("from_sq", 0.0) or 0.0), from_signal ** 2)
                coefficient = max(-8.0, min(8.0, float(relation.get("causal_product", 0.0)) / from_sq))
                prediction = max(-8.0, min(8.0, expected_signal * coefficient * change_rate))
                pn = max(0.0, float(relation.get("prediction_n", 0.0)))
                error_variance = (max(0.0, float(relation.get("prediction_error_m2", 0.0))) /
                                  max(1.0, pn - 1.0)) if pn > 1.0 else 0.0
                error_mean = float(relation.get("prediction_error_mean", 0.0) or 0.0)
                reliability = self._prediction_reliability(n, error_variance, error_mean)
                weight = state_weight * max(0.06, reliability) * min(3.0, 0.55 + math.log1p(n))
                weighted_prediction += prediction * weight
                total_weight += weight
                evidence += n * state_weight
                weighted_uncertainty += (math.sqrt(error_variance) + 1.0 / math.sqrt(n + 1.0)) * weight
            except (TypeError, ValueError, OverflowError):
                continue
        if total_weight <= 0.0:
            return 0.0, 0.0, 1.0
        return (weighted_prediction / total_weight, evidence,
                weighted_uncertainty / total_weight)

    @staticmethod
    def _finite_attribute(value):
        try:
            result = float(value)
            return result if math.isfinite(result) else None
        except (TypeError, ValueError):
            return None

    @classmethod
    def _snapshot_feature_registry(cls, item):
        """Normalize both new registry snapshots and legacy snapshots."""
        if not isinstance(item, dict):
            return {}
        observed_at = cls._finite_attribute(item.get("observed_at")) or time.monotonic()
        confidence = cls._finite_attribute(item.get("confidence"))
        confidence = max(0.0, min(1.0, confidence if confidence is not None else 1.0))
        result = {}
        raw_registry = item.get("features", {})
        if isinstance(raw_registry, dict):
            for name, value in raw_registry.items():
                result[str(name)] = FeatureObservation.from_any(
                    value, name=str(name), confidence=confidence, observed_at=observed_at)

        # Core value/text/bbox remain identity/display fields, but their changes are
        # still observable through the same generic comparison machinery.
        for name in ("value", "text", "bbox"):
            if name in item:
                result[name] = FeatureObservation.from_any(
                    item.get(name), name=name, confidence=confidence, observed_at=observed_at)

        # Legacy compatibility: any producer field that is not in the registry is
        # automatically admitted.  This is what makes future attributes zero-touch
        # for Learner code.
        ignored = {"entity_id", "confidence", "features", "visual_features"}
        for name, value in item.items():
            if name in ignored or name in result:
                continue
            result[str(name)] = FeatureObservation.from_any(
                value, name=str(name), confidence=confidence, observed_at=observed_at)
        visual = item.get("visual_features", {})
        if isinstance(visual, dict):
            for name, value in visual.items():
                key = f"visual.{name}"
                if key not in result:
                    result[key] = FeatureObservation.from_any(
                        value, name=key, confidence=confidence, observed_at=observed_at)
        return result

    @staticmethod
    def _stable_feature_token(value):
        try:
            raw = json.dumps(value, ensure_ascii=True, sort_keys=True,
                             separators=(",", ":"), default=str)
        except Exception:
            raw = repr(value)
        return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]

    @classmethod
    def _entity_attribute_delta(cls, before_item, after_item):
        """Compare every common/appearing feature by generic type, never by name."""
        attributes = {}
        before_features = cls._snapshot_feature_registry(before_item)
        after_features = cls._snapshot_feature_registry(after_item)
        all_names = set(before_features) | set(after_features)

        for name in all_names:
            before_obs = before_features.get(name)
            after_obs = after_features.get(name)
            if before_obs is None or after_obs is None:
                observed = after_obs or before_obs
                state = getattr(observed, "observation_state", "missing") if observed else "missing"
                appeared = after_obs is not None
                # Absence in a snapshot is only a presence transition when the
                # producer actually observed the feature. Missing/sensor-failed/
                # not-sampled data remains unknown and cannot become a fake delta.
                if observed is None or state != "observed":
                    attributes[name] = {
                        "delta": None, "signal": 0.0, "changed": None,
                        "observed": False, "status": state, "kind": "missing",
                        "confidence": float(getattr(observed, "confidence", 0.0) or 0.0),
                    }
                else:
                    attributes[name] = {
                        "delta": 1.0 if appeared else -1.0,
                        "signal": 1.0 if appeared else -1.0,
                        "changed": True, "observed": True, "status": "observed",
                        "kind": "presence", "confidence": float(observed.confidence),
                    }
                continue
            confidence = math.sqrt(max(0.0, float(before_obs.confidence)) *
                                   max(0.0, float(after_obs.confidence)))
            before_state = getattr(before_obs, "observation_state", "observed")
            after_state = getattr(after_obs, "observation_state", "observed")
            if before_state != "observed" or after_state != "observed":
                status = after_state if after_state != "observed" else before_state
                attributes[name] = {
                    "delta": None, "signal": 0.0, "changed": None,
                    "observed": False, "status": status, "kind": "missing",
                    "confidence": confidence,
                }
                continue
            kind = after_obs.kind if after_obs.kind != "missing" else before_obs.kind
            metadata = dict(before_obs.metadata or {})
            metadata.update(dict(after_obs.metadata or {}))

            if kind == "scalar":
                before_value = cls._finite_attribute(before_obs.value)
                after_value = cls._finite_attribute(after_obs.value)
                if before_value is None or after_value is None:
                    continue
                delta = after_value - before_value
                period = cls._finite_attribute(metadata.get("period"))
                if period is not None and period > 0:
                    delta = (delta + period * 0.5) % period - period * 0.5
                explicit_scale = cls._finite_attribute(metadata.get("scale"))
                if name == "value":
                    reference = max(1e-6, abs(before_value) * 0.01,
                                    abs(after_value) * 1e-8, 1.0)
                    signal = math.asinh(delta / reference)
                    changed = abs(delta) > max(1e-9, reference * 1e-5)
                else:
                    denominator = max(1e-9, abs(explicit_scale or 0.0),
                                      abs(before_value), abs(after_value), 1.0)
                    signal = delta / denominator
                    threshold = cls._finite_attribute(metadata.get("threshold"))
                    threshold = max(1e-6, threshold if threshold is not None else 0.008)
                    changed = abs(signal) > threshold
                attributes[name] = {
                    "delta": float(delta), "signal": max(-12.0, min(12.0, float(signal))),
                    "changed": bool(changed), "kind": "scalar",
                    "confidence": confidence, "observed": True, "status": "observed",
                }
                continue

            if kind == "vector" and isinstance(before_obs.value, (tuple, list)) and isinstance(after_obs.value, (tuple, list)):
                if len(before_obs.value) != len(after_obs.value) or not before_obs.value:
                    before_token = cls._stable_feature_token(before_obs.value)
                    after_token = cls._stable_feature_token(after_obs.value)
                    changed = before_token != after_token
                    attributes[name] = {"delta": int(changed), "signal": float(changed),
                                        "changed": changed, "kind": "signature",
                                        "confidence": confidence, "observed": True, "status": "observed"}
                    continue
                deltas, before_values, after_values = [], [], []
                valid = True
                for bv, av in zip(before_obs.value, after_obs.value):
                    b = cls._finite_attribute(bv)
                    a = cls._finite_attribute(av)
                    if b is None or a is None:
                        valid = False
                        break
                    before_values.append(b)
                    after_values.append(a)
                    deltas.append(a - b)
                if not valid:
                    continue
                explicit_scale = cls._finite_attribute(metadata.get("scale"))
                base_norm = math.sqrt(sum(v * v for v in before_values))
                after_norm = math.sqrt(sum(v * v for v in after_values))
                denominator = max(1e-9, abs(explicit_scale or 0.0), base_norm, after_norm, 1.0)
                delta_norm = math.sqrt(sum(v * v for v in deltas))
                sign = 1.0 if sum(deltas) >= 0 else -1.0
                signal = sign * delta_norm / denominator
                threshold = cls._finite_attribute(metadata.get("threshold"))
                threshold = max(1e-6, threshold if threshold is not None else 0.010)
                attributes[name] = {
                    "delta": [float(v) for v in deltas],
                    "signal": max(-12.0, min(12.0, signal)),
                    "changed": bool(delta_norm / denominator > threshold),
                    "kind": "vector", "confidence": confidence, "observed": True, "status": "observed",
                }
                # Components are generated generically so directional relationships
                # are not lost when a vector's aggregate magnitude is similar.
                for index, delta in enumerate(deltas):
                    component_scale = max(1e-9, abs(explicit_scale or 0.0),
                                          abs(before_values[index]), abs(after_values[index]), 1.0)
                    component_signal = delta / component_scale
                    attributes[f"{name}.{index}"] = {
                        "delta": float(delta),
                        "signal": max(-12.0, min(12.0, component_signal)),
                        "changed": bool(abs(component_signal) > threshold),
                        "kind": "vector_component", "confidence": confidence,
                        "observed": True, "status": "observed",
                    }
                continue

            before_token = cls._stable_feature_token(before_obs.value)
            after_token = cls._stable_feature_token(after_obs.value)
            changed = before_token != after_token
            attributes[name] = {
                "delta": int(changed), "signal": float(changed), "changed": bool(changed),
                "kind": kind if kind != "missing" else "signature",
                "confidence": confidence, "before_token": before_token,
                "after_token": after_token, "observed": True, "status": "observed",
            }
        return attributes

    @staticmethod
    def _sparse_trace_records(records, limit=96):
        """Keep dense recent causes plus geometric samples of long-delay causes."""
        records = list(records or ())
        limit = max(16, int(limit))
        if len(records) <= limit:
            return records
        recent_count = limit // 2
        recent = records[-recent_count:]
        older = records[:-recent_count]
        sampled = []
        index = len(older) - 1
        stride = 1
        while index >= 0 and len(sampled) < limit - recent_count:
            sampled.append(older[index])
            index -= stride
            stride = min(48, stride + 1)
        return list(reversed(sampled)) + recent

    @staticmethod
    def _factor_sketch_batch(factors, phase=0, limit=48):
        """Generic activity ranking plus rotating coverage for arbitrary factors."""
        unique = {}
        for factor in factors or ():
            if not isinstance(factor, dict):
                continue
            name = str(factor.get("name", ""))
            if name and name not in unique:
                unique[name] = factor
        items = list(unique.values())
        limit = max(8, int(limit))
        if len(items) <= limit:
            return items

        def activity(item):
            try:
                return abs(float(item.get("signal", 0.0))) * max(
                    0.05, float(item.get("confidence", 1.0)))
            except (TypeError, ValueError, OverflowError):
                return 0.0

        head_count = min(16, limit // 3)
        active = sorted(items, key=lambda item: (activity(item), str(item.get("name", ""))),
                        reverse=True)[:head_count]
        active_names = {str(item.get("name", "")) for item in active}
        tail = [item for item in items if str(item.get("name", "")) not in active_names]
        tail.sort(key=lambda item: hashlib.sha1(
            str(item.get("name", "")).encode("utf-8", "replace")).hexdigest())
        start = int(phase or 0) % max(1, len(tail))
        rotated = (tail + tail)[start:start + max(0, limit - len(active))]
        return active + rotated

    @staticmethod
    def _relation_candidate_key(factor_name, to_entity, to_attribute):
        raw = f"{factor_name}>{to_entity}.{to_attribute}"
        return "rc_" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:20]

    def _update_relation_candidate(self, factor, outcome, lag, weight, to_target=False):
        """Update a compact covariance sketch and report promotion readiness."""
        factor_name = str(factor.get("name", ""))
        to_entity = str(outcome.get("entity", ""))
        to_attribute = str(outcome.get("attribute", ""))
        key = self._relation_candidate_key(factor_name, to_entity, to_attribute)
        stat = self.relation_candidates.get(key)
        if stat is None:
            if len(self.relation_candidates) >= RELATION_CONFIG.candidate_limit:
                return False, 0.0
            stat = {
                "n": 0.0, "factor_name": factor_name,
                "factor_source": str(factor.get("source", "dynamic")),
                "factor_kind": str(factor.get("kind", "unknown")),
                "to_entity": to_entity, "to_attribute": to_attribute,
                "from_mean": 0.0, "to_mean": 0.0, "cross_m2": 0.0,
                "activity": 0.0, "lag": 0.0, "promoted": False,
            }
            self.relation_candidates[key] = stat
        try:
            from_signal = float(factor.get("signal", 0.0))
            to_signal = float(outcome.get("signal", 0.0))
            weight = max(1e-6, min(1.0, float(weight)))
        except (TypeError, ValueError, OverflowError):
            return bool(stat.get("promoted", False)), 0.0
        old_n = max(0.0, float(stat.get("n", 0.0)))
        new_n = old_n + weight
        old_from = float(stat.get("from_mean", 0.0))
        old_to = float(stat.get("to_mean", 0.0))
        delta_from = from_signal - old_from
        delta_to = to_signal - old_to
        new_from = old_from + delta_from * weight / max(1e-9, new_n)
        new_to = old_to + delta_to * weight / max(1e-9, new_n)
        stat["cross_m2"] = float(stat.get("cross_m2", 0.0)) + (
            weight * delta_from * (to_signal - new_to))
        stat["from_mean"], stat["to_mean"] = new_from, new_to
        stat["activity"] = float(stat.get("activity", 0.0)) * 0.88 + min(
            24.0, abs(from_signal * to_signal)) * 0.12
        stat["lag"] = float(stat.get("lag", 0.0)) + (
            float(lag) - float(stat.get("lag", 0.0))) * weight / max(1e-9, new_n)
        stat["n"] = new_n
        covariance = float(stat.get("cross_m2", 0.0)) / max(1.0, new_n)
        score = abs(covariance) * math.sqrt(new_n + 1.0) + float(stat["activity"]) * 0.035
        threshold = (RELATION_CONFIG.target_promotion_evidence if to_target else
                     RELATION_CONFIG.promotion_evidence)
        if (new_n >= threshold and
                (abs(covariance) >= RELATION_CONFIG.promotion_covariance or
                 score >= RELATION_CONFIG.promotion_covariance * 2.0 or to_target)):
            stat["promoted"] = True
        stat["score"] = score
        stat["last_seen"] = int(time.time())
        self._mark_dirty(self.relation_candidates, key)
        return bool(stat.get("promoted", False)), score

    def _admit_relation_factor(self, to_entity, to_attribute, factor_name, candidate_score):
        """Keep only the strongest active factor names for one target attribute."""
        scores = {}
        keys = {}
        for relation_key, relation in self.attribute_relations.items():
            if (not isinstance(relation, dict) or bool(relation.get("passive", False)) or
                    str(relation.get("to_entity", "")) != str(to_entity) or
                    str(relation.get("to_attribute", "")) != str(to_attribute)):
                continue
            name = str(relation.get("factor_name", ""))
            if not name:
                continue
            n = max(0.0, float(relation.get("n", 0.0)))
            strength = abs(float(relation.get(
                "causal_product", relation.get("product", 0.0)) or 0.0)) * math.log1p(n + 1.0)
            scores[name] = max(scores.get(name, 0.0), strength)
            keys.setdefault(name, []).append(relation_key)
        if factor_name in scores or len(scores) < RELATION_CONFIG.active_factors_per_attribute:
            return True
        weakest = min(scores, key=scores.get)
        if float(candidate_score) <= max(1e-6, scores[weakest]) * 1.12:
            return False
        for relation_key in keys.get(weakest, ()):
            self._delete_key("attribute_relations", relation_key)
        return True

    def record_numeric_effect(self, action, state, before_numbers, after_numbers,
                              reliability=1.0, delay=0.0, factor_observation=None):
        if not action or not isinstance(before_numbers, dict) or not isinstance(after_numbers, dict):
            return
        reliability = max(0.08, min(1.0, float(reliability)))
        entity_transitions = {}
        target_values = []
        role_values = {}  # weak semantic summaries only; never defines entity identity.
        common_ids = set(before_numbers) & set(after_numbers)
        for entity_id in common_ids:
            before_item, after_item = before_numbers.get(entity_id), after_numbers.get(entity_id)
            if not isinstance(before_item, dict) or not isinstance(after_item, dict):
                continue
            try:
                confidence = math.sqrt(max(0.0, float(before_item.get("confidence", 0.0))) *
                                       max(0.0, float(after_item.get("confidence", 0.0))))
            except (TypeError, ValueError, OverflowError):
                continue
            if confidence < 0.20:
                continue
            attributes = self._entity_attribute_delta(before_item, after_item)
            role = str(after_item.get("role") or before_item.get("role") or "UNKNOWN").upper()
            # Learn passive attribute drift from OBSERVE_ACTION, then subtract the
            # expected no-action drift from action transitions. This turns temporal
            # correlation into a closer approximation of action-caused residuals.
            elapsed = max(0.06, float(delay or 0.0))
            for attribute, observation in attributes.items():
                if observation.get("observed") is False:
                    continue
                # Any numeric feature can acquire a passive drift baseline.  No feature
                # name is privileged here; producers only declare generic feature kind.
                if str(observation.get("kind", "")) not in {
                        "scalar", "vector", "vector_component", "presence"}:
                    continue
                try:
                    raw_signal = float(observation.get("signal", 0.0))
                except (TypeError, ValueError, OverflowError):
                    continue
                passive_key = f"{entity_id}.{attribute}"
                if action == OBSERVE_ACTION:
                    stat = self.passive_attributes.setdefault(passive_key, {"n": 0.0, "rate": 0.0})
                    weight = reliability * max(0.20, confidence)
                    old_n = float(stat.get("n", 0.0))
                    new_n = old_n + weight
                    observed_rate = raw_signal / elapsed
                    stat["rate"] = float(stat.get("rate", 0.0)) + (observed_rate - float(stat.get("rate", 0.0))) * weight / max(1e-9, new_n)
                    stat["n"] = new_n
                    self._mark_dirty(self.passive_attributes, passive_key)
                else:
                    stat = self.passive_attributes.get(passive_key, {})
                    if float(stat.get("n", 0.0)) >= 0.8:
                        residual = raw_signal - float(stat.get("rate", 0.0)) * elapsed
                        observation["raw_signal"] = raw_signal
                        observation["signal"] = max(-12.0, min(12.0, residual))
                        observation["changed"] = bool(abs(residual) > 0.018)
            entity_transitions[str(entity_id)] = {
                "role": role, "confidence": confidence, "attributes": attributes,
            }
            value_observation = attributes.get("value")
            if value_observation:
                value_signal = float(value_observation.get("signal", 0.0)) * confidence
                role_values.setdefault(role, []).append(value_signal)
                if bool(after_item.get("is_target") or before_item.get("is_target")):
                    target_values.append(value_signal)

        # Entity appearance/disappearance uses the same registry comparator, so
        # lifecycle learning automatically includes future features without another
        # hand-maintained attribute list.
        for entity_id in set(after_numbers) - set(before_numbers):
            item = after_numbers.get(entity_id)
            if isinstance(item, dict):
                confidence = max(0.0, min(1.0, float(item.get("confidence", 0.0))))
                attributes = self._entity_attribute_delta({}, item)
                entity_transitions[str(entity_id)] = {
                    "role": str(item.get("role", "UNKNOWN")).upper(),
                    "confidence": confidence, "attributes": attributes,
                }
        for entity_id in set(before_numbers) - set(after_numbers):
            item = before_numbers.get(entity_id)
            if isinstance(item, dict):
                confidence = max(0.0, min(1.0, float(item.get("confidence", 0.0))))
                attributes = self._entity_attribute_delta(item, {})
                entity_transitions[str(entity_id)] = {
                    "role": str(item.get("role", "UNKNOWN")).upper(),
                    "confidence": confidence, "attributes": attributes,
                }
        if not entity_transitions:
            return
        signals = {role: max(-8.0, min(8.0, sum(values)))
                   for role, values in role_values.items() if values}
        # The selected entity is identified by entity_id/is_target; role labels are not
        # allowed to decide utility or causal structure.
        utility = max(-10.0, min(10.0, sum(target_values))) if target_values else 0.0
        changed_ids = [entity_id for entity_id, transition in entity_transitions.items()
                       if any(bool(item.get("changed"))
                              for item in transition.get("attributes", {}).values())]
        influence_region = self._influence_key(action)
        if influence_region is not None and action != OBSERVE_ACTION:
            attribute_strengths = []
            for transition in entity_transitions.values():
                for observation in transition.get("attributes", {}).values():
                    if observation.get("observed") is False:
                        continue
                    if observation.get("changed"):
                        attribute_strengths.append(min(2.0, abs(float(observation.get("signal", 0.0)))))
            attribute_influence = min(2.2, sum(attribute_strengths) /
                                      max(1.0, math.sqrt(len(attribute_strengths)))) if attribute_strengths else -0.12
            self._update(self.influence, f"global>{influence_region}", attribute_influence,
                         reliability * 0.58, record_outcome=False)
            self._update(self.influence, f"action>{action}", attribute_influence,
                         reliability * 0.66, record_outcome=False)
            for family in self._state_families(state)[:3]:
                self._update(self.influence, f"{family}>{influence_region}", attribute_influence,
                             reliability * 0.54, record_outcome=False)

        now = time.monotonic()
        current_changes = []
        for entity_id, transition in entity_transitions.items():
            for attribute, observation in transition.get("attributes", {}).items():
                if observation.get("observed") is False:
                    continue
                if observation.get("changed"):
                    try:
                        signal = float(observation.get("signal", 0.0))
                    except (TypeError, ValueError, OverflowError):
                        continue
                    current_changes.append({
                        "entity": str(entity_id), "attribute": str(attribute),
                        "signal": max(-12.0, min(12.0, signal)),
                        "kind": str(observation.get("kind", "scalar")),
                        "confidence": max(0.05, min(1.0, float(observation.get("confidence", 1.0) or 1.0))),
                    })
        current_changes.sort(key=lambda item: (item["attribute"] == "value",
                                                abs(item["signal"])), reverse=True)

        elapsed = max(0.06, float(delay or 0.0))
        cause_time = max(0.0, now - elapsed)
        if not isinstance(factor_observation, FactorObservation):
            factor_observation = FactorObservation(observed_at=cause_time)
            factor_observation.add("action", str(action), kind="category", confidence=reliability)
            factor_observation.add("elapsed", elapsed, kind="scalar", confidence=reliability,
                                   metadata={"scale": max(0.06, self.adaptive_credit_horizon(action))})
            factor_observation.add("state", self._key_probe_family(state), kind="category",
                                   confidence=reliability)
            history_raw = "|".join(self.action_trace[-12:])
            if history_raw:
                factor_observation.add("history", history_raw, kind="signature",
                                       confidence=reliability)
        else:
            factor_observation.observed_at = float(factor_observation.observed_at or cause_time)
            if "action" not in factor_observation.factors:
                factor_observation.add("action", str(action), kind="category", confidence=reliability)
            factor_observation.add("elapsed", elapsed, kind="scalar", confidence=reliability,
                                   metadata={"scale": max(0.06, self.adaptive_credit_horizon(action))})
            if "state" not in factor_observation.factors:
                factor_observation.add("state", self._key_probe_family(state), kind="category",
                                       confidence=reliability)

        factor_items = []
        for name, signal, kind, confidence in factor_observation.items_for_learning():
            factor_items.append({
                "name": str(name), "signal": float(signal), "kind": str(kind),
                "confidence": max(0.05, min(1.0, float(confidence))),
                "source": str(name).split("=", 1)[0], "entity": "", "attribute": "",
            })
        cause_record = {
            "time": float(factor_observation.observed_at or cause_time),
            "action": str(action), "state": str(state), "reliability": reliability,
            "factors": factor_items,
        }

        # Numeric attribute changes are themselves factors for future attributes.
        # They share the same relation table as action/time/screen/mouse/history.
        outcome_factor_items = [{
            "name": f"entity:{item['entity']}.{item['attribute']}",
            "signal": float(item["signal"]), "kind": str(item["kind"]),
            "confidence": float(item["confidence"]), "source": "entity_attribute",
            "entity": str(item["entity"]), "attribute": str(item["attribute"]),
        } for item in current_changes]

        priors = self._sparse_trace_records(self.factor_trace, limit=96)
        priors.append(cause_record)
        current_state_condition = self._key_probe_family(state)

        # Explicit delayed conditional model: P(delta attribute | action, state, dt).
        # Target attributes include unchanged observations so probability-of-change is
        # identifiable; non-target attributes are added when they actually changed.
        delayed_outcomes = []
        for entity_id, transition in entity_transitions.items():
            after_item = after_numbers.get(entity_id, {}) if isinstance(after_numbers.get(entity_id, {}), dict) else {}
            before_item = before_numbers.get(entity_id, {}) if isinstance(before_numbers.get(entity_id, {}), dict) else {}
            is_target = bool(after_item.get("is_target") or before_item.get("is_target"))
            for attribute, observation in transition.get("attributes", {}).items():
                if observation.get("observed") is False:
                    continue
                try:
                    signal = float(observation.get("signal", 0.0) or 0.0)
                except (TypeError, ValueError, OverflowError):
                    continue
                if not math.isfinite(signal):
                    continue
                changed = bool(observation.get("changed"))
                if not is_target and not changed:
                    continue
                outcome_name = (f"target.{attribute}" if is_target else
                                f"entity:{entity_id}.{attribute}")
                delayed_outcomes.append((
                    outcome_name, signal, changed,
                    max(0.05, min(1.0, float(observation.get("confidence", 1.0) or 1.0)))))

        for prior in priors:
            try:
                prior_time = float(prior.get("time", now))
            except (TypeError, ValueError, OverflowError, AttributeError):
                prior_time = now
            lag = max(0.0, now - prior_time)
            prior_action = str(prior.get("action") or OBSERVE_ACTION)
            base_horizon = max(0.5, self.adaptive_credit_horizon(prior_action))
            prior_reliability = max(0.05, min(1.0, float(prior.get("reliability", 1.0) or 1.0)))
            prior_state = str(prior.get("state") or state)
            delay_weight = math.exp(-lag / max(0.5, base_horizon) * 0.18)
            if delay_weight >= 1e-5:
                for outcome_name, outcome_signal, outcome_changed, outcome_confidence in delayed_outcomes:
                    self.record_delayed_attribute_effect(
                        prior_action, prior_state, outcome_name, outcome_signal, outcome_changed, lag,
                        reliability * prior_reliability * outcome_confidence * delay_weight)
            sparse_factors = self._factor_sketch_batch(
                prior.get("factors", ()), phase=self.steps + int(lag * 10.0), limit=48)
            for factor in sparse_factors:
                try:
                    factor_name = str(factor.get("name", ""))
                    from_signal = float(factor.get("signal", 0.0))
                    factor_confidence = max(0.05, min(1.0, float(factor.get("confidence", 1.0))))
                except (TypeError, ValueError, OverflowError, AttributeError):
                    continue
                if not factor_name or not math.isfinite(from_signal):
                    continue
                for outcome in current_changes:
                    to_entity = str(outcome["entity"])
                    to_attribute = str(outcome["attribute"])
                    to_signal = float(outcome["signal"])
                    if (factor.get("entity") == to_entity and factor.get("attribute") == to_attribute
                            and lag < 0.02):
                        continue
                    state_condition = str(prior.get("state_condition") or
                                          self._key_probe_family(str(prior.get("state") or state)))
                    raw_key = (f"{state_condition}|{prior_action}|factor:{factor_name}>"
                               f"{action}|{to_entity}.{to_attribute}")
                    relation_key = "ar_" + hashlib.sha1(
                        raw_key.encode("utf-8", "replace")).hexdigest()[:20]
                    baseline_raw = f"{state_condition}|factor:{factor_name}>{to_entity}.{to_attribute}"
                    baseline_key = "pb_" + hashlib.sha1(
                        baseline_raw.encode("utf-8", "replace")).hexdigest()[:20]
                    existing = self.attribute_relations.get(relation_key, {})
                    learned_horizon = max(base_horizon, float(existing.get("effective_horizon", 0.0) or 0.0))
                    temporal_weight = math.exp(-lag / max(0.5, learned_horizon) * 0.22)
                    if temporal_weight < 1e-5:
                        continue
                    weight = reliability * prior_reliability * factor_confidence * temporal_weight
                    if weight < 1e-6:
                        continue
                    to_item = after_numbers.get(to_entity, {})
                    to_target = bool(isinstance(to_item, dict) and to_item.get("is_target"))
                    promoted, candidate_score = self._update_relation_candidate(
                        factor, outcome, lag, weight, to_target=to_target)
                    if not promoted:
                        continue
                    if (not existing and not self._admit_relation_factor(
                            to_entity, to_attribute, factor_name, candidate_score)):
                        continue
                    relation = self.attribute_relations.setdefault(
                        relation_key, {"n": 0.0, "from_action": prior_action,
                                       "factor_name": factor_name,
                                       "factor_source": str(factor.get("source", "dynamic")),
                                       "factor_kind": str(factor.get("kind", "unknown")),
                                       "from_entity": str(factor.get("entity", "")),
                                       "from_attribute": str(factor.get("attribute", "")),
                                       "to_action": action, "to_entity": to_entity,
                                       "to_attribute": to_attribute, "state_condition": state_condition,
                                       "baseline_key": baseline_key, "lag": 0.0,
                                       "lag_n": 0.0, "lag_m2": 0.0, "effective_horizon": base_horizon,
                                       "useful_lag_max": 0.0, "product": 0.0,
                                       "causal_product": 0.0, "from_signal": 0.0,
                                       "to_signal": 0.0, "last_seen": 0})
                    relation["factor_name"] = factor_name
                    relation["factor_source"] = str(factor.get("source", relation.get("factor_source", "dynamic")))
                    relation["factor_kind"] = str(factor.get("kind", relation.get("factor_kind", "unknown")))
                    relation["from_action"] = prior_action
                    relation["from_entity"] = str(factor.get("entity", ""))
                    relation["from_attribute"] = str(factor.get("attribute", ""))
                    relation["to_entity"], relation["to_attribute"] = to_entity, to_attribute
                    relation["to_action"] = str(action)
                    relation["state_condition"] = state_condition
                    relation["baseline_key"] = baseline_key
                    from_role = str(prior.get("roles", {}).get(factor.get("entity"), "UNKNOWN"))
                    to_role = str(entity_transitions.get(to_entity, {}).get("role", "UNKNOWN"))
                    from_target = bool(prior.get("targets", {}).get(factor.get("entity"), False))
                    relation["from_role"], relation["to_role"] = from_role, to_role
                    relation["from_target"], relation["to_target"] = from_target, to_target

                    relation_n = float(relation.get("n", 0.0)) + weight
                    old_lag = float(relation.get("lag", 0.0))
                    new_lag = old_lag + (lag - old_lag) * weight / max(1e-9, relation_n)
                    lag_n = float(relation.get("lag_n", 0.0)) + weight
                    lag_delta = lag - old_lag
                    relation["lag_m2"] = float(relation.get("lag_m2", 0.0)) + weight * lag_delta * (lag - new_lag)
                    relation["lag_n"] = lag_n
                    relation["lag"] = new_lag

                    product = max(-24.0, min(24.0, from_signal * to_signal))
                    relation["product"] = (float(relation.get("product", 0.0)) +
                                           (product - float(relation.get("product", 0.0))) *
                                           weight / max(1e-9, relation_n))
                    passive_pair = (prior_action == OBSERVE_ACTION or action == OBSERVE_ACTION)
                    relation["passive_pair"] = bool(passive_pair)
                    if passive_pair:
                        baseline = self.attribute_relations.setdefault(
                            baseline_key, {"n": 0.0, "product": 0.0, "lag": 0.0,
                                           "state_condition": state_condition, "passive": True,
                                           "factor_name": factor_name,
                                           "from_entity": str(factor.get("entity", "")),
                                           "from_attribute": str(factor.get("attribute", "")),
                                           "to_entity": to_entity, "to_attribute": to_attribute,
                                           "last_seen": 0})
                        bn = float(baseline.get("n", 0.0)) + weight
                        baseline["product"] = float(baseline.get("product", 0.0)) + (
                            product - float(baseline.get("product", 0.0))) * weight / max(1e-9, bn)
                        baseline["lag"] = float(baseline.get("lag", 0.0)) + (
                            lag - float(baseline.get("lag", 0.0))) * weight / max(1e-9, bn)
                        baseline["n"] = bn
                        baseline["last_seen"] = int(time.time())
                        self._mark_dirty(self.attribute_relations, baseline_key)
                    baseline = self.attribute_relations.get(baseline_key, {})
                    baseline_n = float(baseline.get("n", 0.0))
                    baseline_product = float(baseline.get("product", 0.0)) if baseline_n >= 0.8 else 0.0
                    causal_product = product - baseline_product
                    relation["baseline_n"] = baseline_n
                    relation["causal_product"] = (float(relation.get("causal_product", 0.0)) +
                        (causal_product - float(relation.get("causal_product", 0.0))) *
                        weight / max(1e-9, relation_n))

                    old_from_sq = float(relation.get("from_sq", 0.0))
                    relation["from_sq"] = old_from_sq + (from_signal ** 2 - old_from_sq) * weight / max(1e-9, relation_n)
                    coefficient = float(relation.get("causal_product", 0.0)) / max(0.04, float(relation.get("from_sq", 0.0)))
                    predicted_target = max(-12.0, min(12.0, coefficient * from_signal))
                    prediction_error = to_signal - predicted_target
                    old_pn = float(relation.get("prediction_n", 0.0))
                    new_pn = old_pn + weight
                    old_error = float(relation.get("prediction_error_mean", 0.0))
                    error_delta = prediction_error - old_error
                    new_error = old_error + error_delta * weight / max(1e-9, new_pn)
                    relation["prediction_error_m2"] = (float(relation.get("prediction_error_m2", 0.0)) +
                        weight * error_delta * (prediction_error - new_error))
                    relation["prediction_error_mean"] = new_error
                    relation["prediction_n"] = new_pn
                    relation["from_signal"] = float(relation.get("from_signal", 0.0)) + (
                        from_signal - float(relation.get("from_signal", 0.0))) * weight / max(1e-9, relation_n)
                    relation["to_signal"] = float(relation.get("to_signal", 0.0)) + (
                        to_signal - float(relation.get("to_signal", 0.0))) * weight / max(1e-9, relation_n)
                    relation["n"] = relation_n

                    lag_variance = max(0.0, float(relation.get("lag_m2", 0.0)) /
                                       max(1.0, float(relation.get("lag_n", 0.0)) - 1.0))
                    lag_std = math.sqrt(lag_variance)
                    if abs(causal_product) >= 0.015 or (to_target and to_attribute == "value"):
                        relation["useful_lag_max"] = max(float(relation.get("useful_lag_max", 0.0)), lag)
                    relation["effective_horizon"] = max(
                        base_horizon, new_lag + 2.2 * lag_std,
                        float(relation.get("useful_lag_max", 0.0)) * 1.12)
                    relation["last_seen"] = int(time.time())
                    self._mark_dirty(self.attribute_relations, relation_key)

                    if to_attribute == "value" and to_target and not passive_pair:
                        passive_overlap = min(0.82, abs(baseline_product) * 0.10) if baseline_n >= 0.8 else 0.0
                        chain_horizon = max(0.5, float(relation.get("effective_horizon", base_horizon)))
                        chain_signal = to_signal * (1.0 - passive_overlap) * math.exp(-lag / chain_horizon * 0.18)
                        source_key = f"global>{prior_action}"
                        source_effect = self.effects.setdefault(
                            source_key, {"n": 0.0, "utility": 0.0, "m2": 0.0,
                                         "uncertainty": 0.0, "signals": {}, "delay": 0.0})
                        chain_n = float(source_effect.get("chain_n", 0.0)) + weight
                        source_effect["chain_utility"] = (
                            float(source_effect.get("chain_utility", 0.0)) +
                            (chain_signal - float(source_effect.get("chain_utility", 0.0))) *
                            weight / max(1e-9, chain_n))
                        source_effect["chain_n"] = chain_n
                        source_effect["chain_delay"] = (
                            float(source_effect.get("chain_delay", 0.0)) * 0.86 + lag * 0.14)
                        source_effect["last_seen"] = int(time.time())
                        self._mark_dirty(self.effects, source_key)

        # Trace length is a memory bound, not a time/Top-N credit cutoff.  Every
        # relation carries its own learned lag distribution/effective horizon.
        if factor_items:
            self.factor_trace.append(cause_record)
        if outcome_factor_items:
            self.factor_trace.append({
                "time": now, "action": str(action), "state": str(state),
                "reliability": reliability, "factors": outcome_factor_items,
                "roles": {entity_id: transition.get("role", "UNKNOWN")
                          for entity_id, transition in entity_transitions.items()},
                "targets": {entity_id: bool((after_numbers.get(entity_id) or {}).get("is_target"))
                            for entity_id in entity_transitions},
            })
        if len(self.factor_trace) > 512:
            # Keep a dense recent half plus a geometrically thinned older half so
            # long delays remain discoverable without an ever-growing trace.
            recent = self.factor_trace[-256:]
            older = self.factor_trace[:-256]
            thinned = []
            stride = 1
            index = len(older) - 1
            while index >= 0 and len(thinned) < 256:
                thinned.append(older[index])
                index -= stride
                stride = min(32, stride + 1)
            self.factor_trace = list(reversed(thinned)) + recent
        self.attribute_trace = self.factor_trace
        if len(self.relation_candidates) >= RELATION_CONFIG.candidate_limit:
            keep_count = max(512, int(RELATION_CONFIG.candidate_limit * 0.84))
            keep_candidates = set(sorted(
                self.relation_candidates,
                key=lambda name: (
                    bool(self.relation_candidates[name].get("promoted", False)),
                    float(self.relation_candidates[name].get("score", 0.0)),
                    float(self.relation_candidates[name].get("n", 0.0)),
                    int(self.relation_candidates[name].get("last_seen", 0))),
                reverse=True)[:keep_count])
            for candidate_key in tuple(self.relation_candidates):
                if candidate_key not in keep_candidates:
                    self._delete_key("relation_candidates", candidate_key)
        if len(self.attribute_relations) > RELATION_CONFIG.formal_relation_limit:
            keep_count = max(512, int(RELATION_CONFIG.formal_relation_limit * 0.90))
            keep_relations = set(sorted(
                self.attribute_relations,
                key=lambda name: self._retention_priority(self.attribute_relations[name]),
                reverse=True)[:keep_count])
            for relation_key in tuple(self.attribute_relations):
                if relation_key not in keep_relations:
                    self._delete_key("attribute_relations", relation_key)
        history_raw = "|".join(self.action_trace[-5:-1])
        history_key = ("none" if not history_raw else
                       hashlib.sha1(history_raw.encode("utf-8", "replace")).hexdigest()[:10])
        for key in [f"global>{action}"] + [f"{family}>{action}" for family in self._state_families(state)[:4]]:
            stat = self.effects.setdefault(key, {"n": 0.0, "utility": 0.0, "m2": 0.0,
                                                  "uncertainty": 0.0, "signals": {}, "delay": 0.0})
            old_n = float(stat.get("n", 0.0))
            new_n = old_n + reliability
            old_mean = float(stat.get("utility", 0.0))
            diff = utility - old_mean
            new_mean = old_mean + diff * reliability / max(1e-9, new_n)
            m2 = float(stat.get("m2", 0.0)) + reliability * diff * (utility - new_mean)
            stat["n"], stat["utility"], stat["m2"] = new_n, new_mean, m2
            stat["uncertainty"] = math.sqrt(max(0.0, m2 / max(1.0, new_n)))
            stat["delay"] = float(stat.get("delay", 0.0)) * 0.84 + max(0.0, float(delay)) * 0.16
            stat["last_seen"] = int(time.time())
            signal_stats = stat.setdefault("signals", {})
            for role, signal in signals.items():
                role_stat = signal_stats.setdefault(role, {"n": 0.0, "mean": 0.0, "delta": 0.0})
                rn = float(role_stat.get("n", 0.0)) + reliability
                role_stat["mean"] = float(role_stat.get("mean", 0.0)) + (signal - float(role_stat.get("mean", 0.0))) * reliability / max(1e-9, rn)
                raw_deltas = [transition.get("attributes", {}).get("value", {}).get("delta", 0.0)
                              for transition in entity_transitions.values()
                              if transition.get("role") == role]
                role_stat["delta"] = (float(role_stat.get("delta", 0.0)) * 0.84 +
                                      float(sum(raw_deltas)) * 0.16)
                role_stat["n"] = rn

            entity_stats = stat.setdefault("entities", {})
            for entity_id, transition in entity_transitions.items():
                confidence = max(0.05, min(1.0, float(transition.get("confidence", 0.0))))
                weight = reliability * confidence
                entity_stat = entity_stats.setdefault(
                    entity_id, {"n": 0.0, "role": transition.get("role", "UNKNOWN"),
                                "attributes": {}, "delay": 0.0})
                entity_stat["role"] = transition.get("role", entity_stat.get("role", "UNKNOWN"))
                entity_stat["n"] = float(entity_stat.get("n", 0.0)) + weight
                entity_stat["delay"] = (float(entity_stat.get("delay", 0.0)) * 0.86 +
                                        max(0.0, float(delay)) * 0.14)
                attribute_stats = entity_stat.setdefault("attributes", {})
                for attribute, observation in transition.get("attributes", {}).items():
                    attribute_stat = attribute_stats.setdefault(
                        attribute, {"n": 0.0, "mean": 0.0, "m2": 0.0,
                                    "change_rate": 0.0, "magnitude": 0.0})
                    old_an = float(attribute_stat.get("n", 0.0))
                    new_an = old_an + weight
                    signal = float(observation.get("signal", 0.0))
                    old_mean = float(attribute_stat.get("mean", 0.0))
                    difference = signal - old_mean
                    new_attr_mean = old_mean + difference * weight / max(1e-9, new_an)
                    attribute_stat["m2"] = (float(attribute_stat.get("m2", 0.0)) +
                                            weight * difference * (signal - new_attr_mean))
                    attribute_stat["mean"] = new_attr_mean
                    attribute_stat["n"] = new_an
                    changed = 1.0 if observation.get("changed") else 0.0
                    attribute_stat["change_rate"] = (
                        float(attribute_stat.get("change_rate", 0.0)) +
                        (changed - float(attribute_stat.get("change_rate", 0.0))) *
                        weight / max(1e-9, new_an))
                    attribute_stat["magnitude"] = (
                        float(attribute_stat.get("magnitude", 0.0)) * 0.84 + abs(signal) * 0.16)
                    attribute_stat["last_delta"] = observation.get("delta")

            if len(entity_stats) > 48:
                keep = sorted(entity_stats, key=lambda entity_id: float(
                    entity_stats[entity_id].get("n", 0.0)), reverse=True)[:48]
                stat["entities"] = {entity_id: entity_stats[entity_id] for entity_id in keep}

            relations = stat.setdefault("relations", {})
            for left_index, left in enumerate(changed_ids):
                for right in changed_ids[left_index + 1:]:
                    relation_key = ">".join(sorted((left, right)))
                    relation = relations.setdefault(relation_key, {"n": 0.0, "delay": 0.0})
                    relation["n"] = float(relation.get("n", 0.0)) + reliability
                    relation["delay"] = float(relation.get("delay", 0.0)) * 0.84 + float(delay) * 0.16
            if len(relations) > 64:
                keep = sorted(relations, key=lambda relation: float(
                    relations[relation].get("n", 0.0)), reverse=True)[:64]
                stat["relations"] = {relation: relations[relation] for relation in keep}

            histories = stat.setdefault("histories", {})
            history = histories.setdefault(history_key, {"n": 0.0, "utility": 0.0})
            history_n = float(history.get("n", 0.0)) + reliability
            history["utility"] = (float(history.get("utility", 0.0)) +
                                  (utility - float(history.get("utility", 0.0))) *
                                  reliability / max(1e-9, history_n))
            history["n"] = history_n
            if len(histories) > 16:
                keep = sorted(histories, key=lambda name: float(
                    histories[name].get("n", 0.0)), reverse=True)[:16]
                stat["histories"] = {name: histories[name] for name in keep}
            self._mark_dirty(self.effects, key)

    def _model_lookahead(self, state, action, actions, cache=None):
        current = self._model_state(state)
        stat = self.models.get(f"{current}>{action}", {})
        q, n, variance = self._value(stat)
        if isinstance(stat, dict):
            variance += float(stat.get("prediction_error_abs", 0.0) or 0.0) ** 2
        effect_q, effect_n, effect_uncertainty = self._effect_value(state, action)
        if effect_n:
            effect_weight = min(0.34, 0.07 + math.log1p(effect_n) * 0.055)
            q += effect_q * effect_weight - min(0.22, effect_uncertainty * LEARNING_CONFIG.uncertainty_penalty)
        transitions = stat.get("next", {}) if isinstance(stat, dict) else {}
        if n < 2 or not isinstance(transitions, dict) or not transitions:
            return q, n, variance + effect_uncertainty * 0.15
        action_list = list(dict.fromkeys(actions))
        memo = cache if cache is not None else {}

        def best_from(model_state, depth):
            key = (model_state, depth)
            if key in memo:
                return memo[key]
            if depth <= 0:
                return 0.0
            ranked = []
            for candidate in action_list:
                cstat = self.models.get(f"{model_state}>{candidate}", {})
                cq, cn, cv = self._value(cstat)
                if cn <= 0:
                    continue
                # State-family causal effects are not exact for synthetic model states, so use global effects here.
                estat = self.effects.get(f"global>{candidate}", {})
                en = float(estat.get("n", 0.0)) if isinstance(estat, dict) else 0.0
                if en > 0:
                    cq += float(estat.get("utility", 0.0)) * min(0.26, 0.05 + math.log1p(en) * 0.045)
                    cq -= min(0.18, float(estat.get("uncertainty", 0.0)) * LEARNING_CONFIG.uncertainty_penalty)
                cq -= min(0.20, math.sqrt(max(0.0, cv)) * 0.025)
                ranked.append((cq, candidate, cstat, cn))
            if not ranked:
                memo[key] = 0.0
                return 0.0
            ranked.sort(reverse=True, key=lambda item: item[0])
            best = -float("inf")
            for immediate, candidate, cstat, cn in ranked[:LEARNING_CONFIG.beam_width]:
                future = 0.0
                next_map = cstat.get("next", {}) if isinstance(cstat, dict) else {}
                if depth > 1 and isinstance(next_map, dict) and next_map:
                    total = sum(max(0.0, float(v)) for v in next_map.values())
                    if total > 0:
                        for next_model_state, count in sorted(next_map.items(), key=lambda item: float(item[1]), reverse=True)[:LEARNING_CONFIG.transition_branches]:
                            future += max(0.0, float(count)) / total * best_from(next_model_state, depth - 1)
                value = immediate + LEARNING_CONFIG.model_discount * future
                if value > best:
                    best = value
            memo[key] = 0.0 if best == -float("inf") else best
            return memo[key]

        total = sum(max(0.0, float(value)) for value in transitions.values())
        if total <= 0:
            return q, n, variance + effect_uncertainty * 0.15
        expected_future = 0.0
        for following, count in sorted(transitions.items(), key=lambda item: float(item[1]), reverse=True)[:LEARNING_CONFIG.transition_branches]:
            expected_future += max(0.0, float(count)) / total * best_from(
                following, max(1, LEARNING_CONFIG.beam_depth - 1))
        return q + LEARNING_CONFIG.model_discount * expected_future, n, variance + effect_uncertainty * 0.15

    @staticmethod
    def _action_aliases(action):

        if not isinstance(action, str):
            return []
        if action.startswith("uia:"):
            parts = action.split(":")
            if len(parts) < 3:
                return []
            pattern, control_id = parts[1], parts[2]
            base_id = re.sub(r"_r\d+c\d+$", "", control_id)
            return [f"uia:{pattern}", f"uia:{pattern}:control:{base_id}", f"control:{base_id}"]
        if action.startswith("click:control:"):
            control_id = action.split(":", 2)[2]
            base_id = re.sub(r"_r\d+c\d+$", "", control_id)
            return [f"control:{base_id}"]
        if action.startswith(("mouse:", "pointer:", "click:", "wheel:", "drag:", "tap:")):
            try:
                point = Learner._mouse_point(action)
                if point is None:
                    return []
                fx, fy = point
                kind = action.split(":", 1)[0]
                family = "click:left" if kind == "mouse" else kind
                if kind == "click":
                    family += ":" + action.split(":")[1]
                elif kind == "wheel":
                    wheel_parts = action.split(":")
                    family += ":" + wheel_parts[1] + (":positive" if int(wheel_parts[2]) > 0 else ":negative")
                elif kind == "drag":
                    family += ":" + action.split(":")[1]
                elif kind == "tap":
                    tap_parts = action.split(":")
                    family += ":" + tap_parts[1] + f":r{tap_parts[5]}:i{tap_parts[6]}"
                aliases = ["mouse:" + family]
                for bins in (6, 12, 24):
                    qx = max(0, min(bins - 1, int(fx * bins)))
                    qy = max(0, min(bins - 1, int(fy * bins)))
                    aliases.append(f"{family}:m{bins}:{qx}:{qy}")
                    if kind == "mouse":
                        aliases.append(f"m{bins}:{qx}:{qy}")
                return aliases
            except Exception:
                return []

        try:
            if action.startswith("key:"):
                name = action.split(":", 1)[1]
                aliases = [f"kbd:key:{name}"]
                if len(name) == 1 and name.isalpha():
                    aliases.append("kbd:letter")
                elif len(name) == 1 and name.isdigit():
                    aliases.append("kbd:number")
                return aliases
            if action.startswith("hold:"):
                _kind, name, milliseconds = action.split(":")
                duration = int(milliseconds)
                aliases = [f"kbd:key:{name}",
                           f"kbd:hold:{name}:{'long' if duration >= 450 else 'short'}"]
                return aliases
            if action.startswith("pulse:"):
                _kind, name, milliseconds, repeats, interval = action.split(":")
                duration = int(milliseconds)
                count = int(repeats)
                gap = int(interval)
                aliases = [f"kbd:key:{name}", f"kbd:pulse:{name}:r{count}",
                           f"kbd:pulse:{name}:i{max(20, round(gap / 20) * 20)}",
                           f"kbd:hold:{name}:{'long' if duration >= 450 else 'short'}"]
                return aliases
            if action.startswith("chord:"):
                parts = action.split(":")
                names = parts[1].split("+") if len(parts) >= 2 else []
                aliases = ["kbd:chord:" + "+".join(sorted(names))]
                if len(parts) == 3:
                    aliases.append(f"kbd:chord-duration:{max(20, round(int(parts[2]) / 20) * 20)}")
                aliases.extend(f"kbd:key:{name}" for name in names)
                return aliases
        except Exception:
            return []
        return []

    @staticmethod
    def _mouse_point(action):
        if not isinstance(action, str):
            return None
        try:
            parts = action.split(":")
            if parts[0] == "mouse" and len(parts) == 3:
                grid, sx, sy = 20, int(parts[1]), int(parts[2])
            elif parts[0] in {"mouse", "pointer"} and len(parts) == 4:
                if parts[1] == "v":
                    grid, sx, sy = 10000, int(parts[2]), int(parts[3])
                else:
                    grid, sx, sy = int(parts[1]), int(parts[2]), int(parts[3])
            elif parts[0] == "click" and len(parts) == 6:
                grid = 10000 if parts[2] == "v" else int(parts[2])
                sx, sy = int(parts[3]), int(parts[4])
            elif parts[0] == "wheel" and len(parts) == 6:
                grid = 10000 if parts[3] == "v" else int(parts[3])
                sx, sy = int(parts[4]), int(parts[5])
            elif parts[0] == "drag" and len(parts) == 8:
                grid = 10000 if parts[2] == "v" else int(parts[2])
                sx = (int(parts[3]) + int(parts[5])) * 0.5
                sy = (int(parts[4]) + int(parts[6])) * 0.5
            elif parts[0] == "tap" and len(parts) == 8:
                grid = 10000 if parts[2] == "v" else int(parts[2])
                sx, sy = int(parts[3]), int(parts[4])
            else:
                return None
            grid = max(2, int(grid))
            return max(0.0, min(1.0, sx / grid)), max(0.0, min(1.0, sy / grid))
        except Exception:
            return None

    def _spatial_value(self, state, action):

        target = self._mouse_point(action)
        if target is None:
            return 0.0, 0, 0.0
        tx, ty = target
        weighted_q = variance = weight_sum = 0.0
        evidence_n = 0

        sigma2 = 0.070 ** 2
        for other, stat in self.stats.items():
            point = self._mouse_point(other)
            if point is None or other == action:
                continue
            dx, dy = point[0] - tx, point[1] - ty
            d2 = dx * dx + dy * dy
            if d2 > 0.20 ** 2:
                continue
            q, n, v = self._value(stat)
            if not n:
                continue
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, other), {}))
            local_q = (0.42 * q + 0.58 * cq) if cn else q
            local_v = (0.55 * v + 0.45 * cv) if cn else v
            kernel = math.exp(-0.5 * d2 / sigma2)
            sample_weight = kernel * min(3.6, 0.58 + math.log1p(n + cn))
            weighted_q += local_q * sample_weight
            variance += local_v * sample_weight
            weight_sum += sample_weight
            evidence_n += min(12, n + cn)
        if weight_sum < 0.20:
            return 0.0, 0, 0.0

        effective_n = max(1, min(48, int(round(evidence_n * min(1.0, weight_sum / 7.0)))))
        return weighted_q / weight_sum, effective_n, variance / weight_sum

    def _alias_value(self, state, action):
        aliases = self._action_aliases(action)
        if not aliases:
            return 0.0, 0, 0.0
        semantic = self._state_families(state)[:2]
        weighted_q = variance = weight_sum = 0.0
        total_n = 0
        for alias in aliases:
            keys = [(f"global>{alias}", 0.55)]
            keys.extend((f"{family}>{alias}", 1.0) for family in semantic)
            for key, scale in keys:
                stat = self.aliases.get(key, {})
                q, n, v = self._value(stat)
                if not n:
                    continue
                w = scale * min(3.4, 0.65 + math.log1p(n))
                weighted_q += q * w
                variance += v * w
                weight_sum += w
                total_n += n
        if not weight_sum:
            return 0.0, 0, 0.0
        return weighted_q / weight_sum, total_n, variance / weight_sum

    def _update_aliases(self, state, action, reward, contextual_target,
                        record_outcome=True):
        aliases = self._action_aliases(action)
        if not aliases:
            return
        semantic = self._state_families(state)[:2]
        for alias in aliases:
            self._update(self.aliases, f"global>{alias}", reward, 0.62,
                         record_outcome=record_outcome)
            for family in semantic:
                self._update(self.aliases, f"{family}>{alias}", contextual_target, 0.72,
                             record_outcome=record_outcome)

    def _family_value(self, state, action):
        weighted_q = 0.0
        weight_sum = 0.0
        variance = 0.0
        total_n = 0
        good = bad = 0
        for family in self._state_families(state):
            stat = self.families.get(f"{family}>{action}", {})
            q, n, v = self._value(stat)
            if not n:
                continue
            hierarchy = (1.22 if family.startswith("L2:") else
                         1.00 if family.startswith("L1:") else
                         0.76 if family.startswith("L0:") else 0.92)
            w = min(4.2, math.log1p(n) + 0.55) * hierarchy
            weighted_q += q * w
            variance += v * w
            weight_sum += w
            total_n += n
            good += int(stat.get("good", 0))
            bad += int(stat.get("bad", 0))
        if not weight_sum:
            return 0.0, 0, 0.0, 0, 0
        return weighted_q / weight_sum, total_n, variance / weight_sum, good, bad

    def _future_value(self, state, actions=None):
        best = 0.0
        iterable = actions or []
        if not iterable:
            prefix = f"{state}>"
            iterable = [k[len(prefix):] for k in self.contexts if k.startswith(prefix)]
        for action in iterable:
            q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, _fv, _fg, _fb = self._family_value(state, action)
            if n or fn:
                blended = q if n and not fn else fq if fn and not n else 0.70 * q + 0.30 * fq
                best = max(best, blended)
        return best

    @staticmethod
    def _success_posterior(stat):
        good = max(0.0, float(stat.get("good", 0)))
        bad = max(0.0, float(stat.get("bad", 0)))
        zero = max(0.0, float(stat.get("zero", 0)))
        alpha = good + 1.0
        beta = bad + 1.0 + zero * 0.58
        total = alpha + beta
        mean = alpha / max(1e-9, total)
        variance = alpha * beta / max(1e-9, total * total * (total + 1.0))
        lower = max(0.0, mean - 1.15 * math.sqrt(max(0.0, variance)))
        return mean, lower, alpha, beta

    @staticmethod
    def _raw_reward(before, after, confidence=1.0):
        delta = after - before
        reference = max(1e-6, abs(before) * 0.0025, abs(after) * 1e-9)
        reward = math.asinh(delta / reference) if delta else 0.0
        if before > 0 and after > 0 and delta:
            reward += max(-2.0, min(2.0, math.log(after / before) * 0.42))
        conf = max(0.0, min(1.0, float(confidence)))
        reliability = max(0.03, min(1.0, (conf - 0.20) / 0.68))
        return max(-8.0, min(8.0, reward * reliability)), reliability, reference

    def passive_value(self, state):
        global_q, global_n, _v = self._value(self.passive.get("global", {}))
        values = []
        for family in self._state_families(state)[:5]:
            q, n, _v = self._value(self.passive_families.get(family, {}))
            if n:
                values.append((q, min(3.0, 0.7 + math.log1p(n))))
        if not values:
            return global_q if global_n else 0.0
        denom = sum(w for _q, w in values)
        family_q = sum(q * w for q, w in values) / max(1e-9, denom)
        return 0.66 * family_q + 0.34 * global_q if global_n else family_q

    def observe_passive(self, before, after, state, confidence=1.0, elapsed_seconds=1.0):
        reward, _reliability, _reference = self._raw_reward(before, after, confidence)
        rate_signal = self._rate_signal(before, after, elapsed_seconds, confidence)
        self._update(self.passive, "global", reward, 0.96)
        self._update(self.passive_rates, "global", rate_signal, 1.0, record_outcome=False)
        for family in self._state_families(state)[:5]:
            self._update(self.passive_families, family, reward, 0.96)
            self._update(self.passive_rates, family, rate_signal, 1.0, record_outcome=False)
        return reward

    def _outcome_signal(self, action):

        trail = self.outcomes.get(action, [])
        values = []
        for item in trail[-10:] if isinstance(trail, list) else []:
            try:
                values.append(float(item[0] if isinstance(item, (list, tuple)) else item))
            except Exception:
                continue
        if not values:
            return 0.0, 0.0, 0.0
        ordered = sorted(values)
        median = ordered[len(ordered) // 2]
        downside = max(0.0, -ordered[max(0, len(ordered) // 5)])
        trend = 0.0
        if len(values) >= 4:
            split = max(2, len(values) // 2)
            old = sum(values[:split]) / split
            new = sum(values[split:]) / max(1, len(values) - split)
            trend = max(-2.5, min(2.5, new - old))
        return median, trend, downside

    def _outcome_distribution(self, action):

        trail = self.outcomes.get(action, [])
        values = []
        for item in trail[-12:] if isinstance(trail, list) else []:
            try:
                values.append(float(item[0] if isinstance(item, (list, tuple)) else item))
            except Exception:
                continue
        if not values:
            return 0.0, 0.0, 0.0, 0.5, 0
        ordered = sorted(values)
        n = len(ordered)
        q25 = ordered[max(0, int((n - 1) * 0.25))]
        q75 = ordered[min(n - 1, int((n - 1) * 0.75))]
        tail_n = max(1, int(math.ceil(n * 0.25)))
        cvar = sum(ordered[:tail_n]) / tail_n
        positive = sum(value > 0.035 for value in values) / n
        return q25, q75, cvar, positive, n

    def expand_actions(self, actions, state, stagnant, limit=5):

        base = list(dict.fromkeys(a for a in actions if a and not a.startswith("macro:")))
        if not base or limit <= 0:
            return base
        allowed = set(base)
        ranked = []

        for sequence, stat in self.sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 6 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            context_values = []
            for family in self._state_families(state)[:4]:
                sq, sn, sv = self._value(self.sequence_contexts.get(f"{family}>{sequence}", {}))
                if sn:
                    context_values.append((sq, sn, sv))
            if context_values:
                weights = [min(3.0, 0.65 + math.log1p(sn)) for _sq, sn, _sv in context_values]
                denom = max(1e-9, sum(weights))
                contextual_q = sum(sq * w for (sq, _sn, _sv), w in zip(context_values, weights)) / denom
                contextual_v = sum(sv * w for (_sq, _sn, sv), w in zip(context_values, weights)) / denom
                contextual_n = sum(sn for _sq, sn, _sv in context_values)
            else:
                contextual_q = contextual_v = 0.0
                contextual_n = 0
            success, lower, _a, _b = self._success_posterior(stat)
            threshold_n = 2 if stagnant > 24 else 3
            threshold_q = 0.02 if stagnant > 38 else 0.08
            blended_q = q if not contextual_n else 0.56 * q + 0.44 * contextual_q
            effective_n = n + min(8, contextual_n)
            if effective_n >= threshold_n and blended_q > threshold_q and success >= 0.51:
                score = blended_q + 0.16 * (success - 0.5) + 0.12 * (lower - 0.35)
                score += min(0.14, math.log1p(effective_n) * 0.026)
                score -= min(0.11, math.sqrt(max(0.0, v + contextual_v * 0.35)) * 0.025)
                ranked.append((score, self._make_macro(parts)))

        for sequence, stat in self.trajectory_sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 6 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            if n < (2 if stagnant > 18 else 3):
                continue
            success, lower, _a, _b = self._success_posterior(stat)
            # Trajectory replay may contain temporary-loss prefixes; long-return q is intentional.
            threshold = -0.04 if stagnant > 28 else 0.10
            if q > threshold or (stagnant > 20 and success >= 0.46):
                score = q + 0.10 * (success - 0.5) + 0.06 * (lower - 0.30)
                score -= min(0.10, math.sqrt(max(0.0, v)) * 0.018)
                ranked.append((score, self._make_macro(parts)))

        for action in base:
            q, n, v = self._value(self.stats.get(action, {}))
            stat = self.stats.get(action, {})
            success, lower, _a, _b = self._success_posterior(stat)
            if n >= 5 and q > 0.16 and success >= 0.62 and lower >= 0.42:
                score = q + 0.12 * success - min(0.08, math.sqrt(max(0.0, v)) * 0.02)
                ranked.append((score, self._make_macro((action, action))))
                if n >= 12 and q > 0.34 and success >= 0.72:
                    ranked.append((score * 0.94, self._make_macro((action, action, action))))

        out = list(base)
        seen = set(out)
        for _score, macro in sorted(ranked, reverse=True):
            if macro and macro not in seen:
                out.append(macro)
                seen.add(macro)
                if len(out) >= len(base) + limit:
                    break
        return out

    def choose_group(self, groups, state, stagnant, priors=None):
        priors = priors or {}
        available = {name: list(dict.fromkeys(actions)) for name, actions in groups.items() if actions}
        if not available:
            return None
        if len(available) == 1:
            return next(iter(available))
        # Exploration is driven by uncertainty and performance rather than a permanent
        # random floor. Mature, consistently profitable groups can become nearly greedy.
        group_samples = []
        group_quality = []
        for actions in available.values():
            local_n = local_best = 0.0
            for candidate in actions[:32]:
                q, n, _v = self._value(self.stats.get(candidate, {}))
                local_n += min(6.0, float(n))
                if n >= 3:
                    local_best = max(local_best, q)
            group_samples.append(local_n / max(1, len(actions[:32])))
            group_quality.append(local_best)
        evidence = sum(group_samples) / max(1, len(group_samples))
        quality = max(group_quality, default=0.0)
        uncertainty = 1.0 / math.sqrt(1.0 + max(0.0, evidence))
        epsilon = 0.006 + 0.20 * uncertainty * math.exp(-self.steps / 1500.0)
        if quality > 0.18 and stagnant < 8:
            epsilon *= max(0.12, 0.55 / math.sqrt(1.0 + evidence))
        if stagnant > LEARNING_CONFIG.stagnation_medium:
            epsilon = max(epsilon, min(0.28, 0.10 + stagnant * 0.006))
        if stagnant > LEARNING_CONFIG.stagnation_high:
            epsilon = max(epsilon, min(0.46, 0.18 + stagnant * 0.007))
        scored = []
        for name, actions in available.items():
            ranked = []
            sample_n = 0
            for action in actions[:48]:
                quality = self.action_quality(action, state)
                stat = self.stats.get(action, {})
                _q, n, _v = self._value(stat)
                sample_n += min(8, n)
                prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
                prior_strength = math.exp(-max(0.0, float(n)) / 1.15)
                ranked.append(quality + (prior - 0.50) * 0.08 * prior_strength)
            ranked.sort(reverse=True)
            head = ranked[:min(6, len(ranked))]
            exploitation = (max(head) if head else 0.0) * 0.64
            exploitation += (sum(head) / len(head) if head else 0.0) * 0.36
            novelty = 0.34 / math.sqrt(1.0 + sample_n / max(1, len(actions)))
            breadth_penalty = min(0.10, math.log1p(len(actions)) * 0.012)
            scored.append((exploitation + novelty - breadth_penalty, name))
        if random.random() < epsilon:
            floor = min(score for score, _name in scored)
            weights = [max(0.05, score - floor + 0.18) for score, _name in scored]
            pick = random.random() * sum(weights)
            for weight, (_score, name) in zip(weights, scored):
                pick -= weight
                if pick <= 0:
                    return name
        return max(scored)[1]

    @classmethod
    def _estimated_action_cost(cls, action):
        parts = cls._macro_parts(action)
        cost = max(0, len(parts) - 1) * 0.012
        for part in parts:
            raw = str(part or "")
            try:
                fields = raw.split(":")
                if raw.startswith("hold:") and len(fields) == 3:
                    cost += min(0.10, int(fields[2]) / 1000.0 * 0.010)
                elif raw.startswith("pulse:") and len(fields) == 5:
                    total_ms = int(fields[2]) * int(fields[3]) + int(fields[4]) * max(0, int(fields[3]) - 1)
                    cost += min(0.14, total_ms / 1000.0 * 0.008)
                elif raw.startswith("chord:") and len(fields) == 3:
                    cost += min(0.10, int(fields[2]) / 1000.0 * 0.010)
                elif raw.startswith(("drag:", "tap:")):
                    cost += 0.010
            except (TypeError, ValueError, OverflowError):
                cost += 0.008
        return min(0.24, cost)

    def choose(self, actions, state, stagnant, priors=None):
        priors = priors or {}
        if not actions:
            return None
        lookahead_cache = {}
        spatial_cache = {}

        def spatial_value(action):
            point = self._mouse_point(action)
            if point is None:
                return 0.0, 0, 0.0
            key = (round(point[0], 4), round(point[1], 4))
            if key not in spatial_cache:
                spatial_cache[key] = self._spatial_value(state, action)
            return spatial_cache[key]
        evidence_values = []
        uncertainty_values = []
        proven = False
        for candidate in actions:
            stat = self.stats.get(candidate, {})
            q, n, variance = self._value(stat)
            success, lower, _a, _b = self._success_posterior(stat)
            evidence_values.append(float(n))
            uncertainty_values.append(math.sqrt(max(0.0, float(variance))) / math.sqrt(float(n) + 1.0))
            if n >= 8 and q > 0.16 and success >= 0.64 and lower >= 0.47:
                proven = True
        mean_evidence = sum(evidence_values) / max(1, len(evidence_values))
        model_uncertainty = (sum(uncertainty_values) / max(1, len(uncertainty_values)) +
                             1.0 / math.sqrt(1.0 + mean_evidence))
        base_decay = LEARNING_CONFIG.exploration_initial * math.exp(
            -self.steps / max(120.0, LEARNING_CONFIG.exploration_decay_steps))
        epsilon = max(0.0015, min(0.42, base_decay * min(1.0, 0.28 + model_uncertainty)))
        if proven and stagnant < 10:
            epsilon *= max(0.08, min(0.35, 0.58 / math.sqrt(1.0 + mean_evidence)))
        # Learned action delays stretch the stagnation boundary; a responsive scene shrinks it.
        delay_samples = []
        for candidate in actions[:28]:
            hint = self.delay_hint(candidate)
            if hint > 0:
                delay_samples.append(hint)
        learned_delay = sorted(delay_samples)[len(delay_samples)//2] if delay_samples else 0.0
        response_scale = max(0.72, min(1.55, 1.0 + learned_delay * 0.55 - min(0.25, abs(self.last_rate_signal) * 0.025)))
        medium = max(6, int(round(LEARNING_CONFIG.stagnation_medium * response_scale)))
        high = max(medium + 5, int(round(LEARNING_CONFIG.stagnation_high * response_scale)))
        extreme = max(high + 7, int(round(LEARNING_CONFIG.stagnation_extreme * response_scale)))
        if stagnant > medium:
            epsilon = max(epsilon, min(LEARNING_CONFIG.exploration_medium, 0.10 + stagnant * 0.006))
        if stagnant > high:
            epsilon = max(epsilon, min(LEARNING_CONFIG.exploration_high, 0.18 + stagnant * 0.0065))
        if stagnant > extreme:
            epsilon = max(epsilon, min(LEARNING_CONFIG.exploration_extreme, 0.26 + stagnant * 0.0068))
        if random.random() < epsilon:
            weights = []
            for action in actions:
                _q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
                _fq, fn, _fv, _fg, _fb = self._family_value(state, action)
                _aq, an, _av = self._alias_value(state, action)
                sq, sn, _sv = spatial_value(action)
                gq, gn, _gv = self._value(self.stats.get(action, {}))
                mq, mn, _mv = self._model_lookahead(
                    state, action, actions, lookahead_cache)
                predicted_gain, predicted_n, predicted_uncertainty = self.predict_target_gain(state, action)
                stat = self.stats.get(action, {})
                bad, good = int(stat.get("bad", 0)), int(stat.get("good", 0))
                zero = int(stat.get("zero", 0))
                _mean_success, lower_success, _a, _b = self._success_posterior(stat)
                recent_median, recent_trend, recent_downside = self._outcome_signal(action)
                q25, q75, cvar, positive_rate, distribution_n = self._outcome_distribution(action)
                risk = 0.72 + 0.56 * lower_success
                risk *= max(0.34, min(1.38, 1.0 + recent_median * 0.10 + recent_trend * 0.055
                                                   - recent_downside * 0.045))
                if distribution_n >= 4:

                    if stagnant < 18:
                        risk *= max(0.28, min(1.45, 0.84 + positive_rate * 0.36 + q25 * 0.045
                                                   + cvar * 0.028))
                    else:
                        risk *= max(0.34, min(1.65, 0.82 + positive_rate * 0.24 + q75 * 0.050
                                                   - max(0.0, -cvar) * 0.018))
                if gn >= 8 and bad > good * 2 + 2 and gq < -0.08:
                    risk = 0.20
                if gn >= 8 and zero / max(1, gn) > 0.78 and gq <= 0.02:
                    risk *= 0.46
                if action.startswith("macro:"):
                    risk *= 0.82
                if mn >= 4 and mq < -0.18:
                    risk *= max(0.24, 1.0 + mq * 0.30)
                if predicted_n > 0:
                    prediction_trust = self._prediction_reliability(predicted_n,
                        predicted_uncertainty * predicted_uncertainty)
                    risk *= max(0.30, min(1.75, 1.0 + predicted_gain * 0.12 * prediction_trust))
                    risk *= 1.0 + min(0.22, predicted_uncertainty * 0.05)
                if sn >= 3:

                    risk *= max(0.42, min(1.42, 1.0 + sq * 0.22))
                prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
                tested = max(0.0, n + fn * 0.12 + an * 0.10 + gn * 0.08 + sn * 0.055)
                prior_strength = math.exp(-tested / 1.10)
                prior_weight = 1.0 + (prior - 0.50) * 0.22 * prior_strength
                weights.append(risk * prior_weight / math.sqrt(
                    n + fn * 0.12 + an * 0.10 + gn * 0.08 + mn * 0.10 + sn * 0.055 + 1.0))
            total = sum(weights)
            if total > 0:
                pick = random.random() * total
                for action, weight in zip(actions, weights):
                    pick -= weight
                    if pick <= 0:
                        return action
            return actions[-1]

        total = max(3, self.steps + 2)
        best_action, best_value = None, -float("inf")
        inverse = self._inverse_action(self.last_action) if self.last_reward < -0.08 else None
        for action in actions:
            gq, gn, gv = self._value(self.stats.get(action, {}))
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, fv, fgood, fbad = self._family_value(state, action)
            aq, an, av = self._alias_value(state, action)
            sq, sn, sv = spatial_value(action)
            nq, nn, nv = self._nstep_value(state, action)
            rq, rn, rv = self._value(self.rates.get(action, {}))
            iq, inn, iv = self.influence_value(state, action)
            xq, xn, xv = self._sequence_value(action, state)
            pq, pn, _ = self._value(self.pairs.get(f"{self.last_action}>{action}", {}))
            tq, tn, _ = self._value(
                self.triples.get(f"{self.prev_action}>{self.last_action}>{action}", {}))
            mq, mn, mv = self._model_lookahead(
                state, action, actions, lookahead_cache)
            predicted_gain, predicted_n, predicted_uncertainty = self.predict_target_gain(state, action)
            delayed_gain, delayed_n, delayed_uncertainty = self.predict_delayed_target_gain(state, action)

            base, blend_n, blend_uncertainty = self._blend_estimates(
                ((gq, gn, gv), (cq, cn, cv), (fq, fn, fv), (aq, an, av),
                 (sq, sn, sv)), fallback=gq)
            value = base
            stat = self.stats.get(action, {})
            short_return, short_n, long_return, return_n = self._horizon_value(stat)
            if return_n or short_n:
                horizon_signal = long_return if stagnant >= 12 else (0.58 * short_return + 0.42 * long_return)
                horizon_weight = min(0.34, 0.08 + max(0, stagnant) * 0.0065)
                value += horizon_signal * horizon_weight
            if nn:
                nstep_weight = min(0.46, 0.14 + math.log1p(nn) * 0.055)
                if stagnant >= 10:
                    nstep_weight = min(0.58, nstep_weight + stagnant * 0.004)
                value = value * (1.0 - nstep_weight) + nq * nstep_weight
            if rn:
                value += max(-0.38, min(0.42, rq * (0.10 if stagnant < 12 else 0.15)))
            if inn:
                value += max(-0.22, min(0.34, iq * 0.16))
            if xn:
                sequence_weight = min(0.62, 0.24 + math.log1p(xn) * 0.075)
                value = value * (1.0 - sequence_weight) + xq * sequence_weight
                if xq > 0.20:
                    value += min(0.34, xq * 0.055)
            if self.last_action:
                value += 0.22 * pq
            if self.prev_action and self.last_action:
                value += 0.10 * tq
            if mn:
                model_stat = self.models.get(f"{self._model_state(state)}>{action}", {})
                model_error = float(model_stat.get("prediction_error_abs", 0.0)) if isinstance(model_stat, dict) else 0.0
                model_trust = min(0.34, self._prediction_reliability(mn, mv, model_error) * 0.34)
                value = value * (1.0 - model_trust) + mq * model_trust
            if predicted_n > 0:
                prediction_trust = self._prediction_reliability(
                    predicted_n, predicted_uncertainty * predicted_uncertainty)
                value += max(-1.25, min(1.25, predicted_gain)) * prediction_trust * 0.48
                value -= min(0.30, predicted_uncertainty * (0.08 + 0.12 * prediction_trust))

            stat = self.stats.get(action, {})
            good = int(stat.get("good", 0)) + fgood
            bad = int(stat.get("bad", 0)) + fbad
            zero = int(stat.get("zero", 0))
            success, lower_success, alpha, beta = self._success_posterior(stat)
            try:
                sampled_success = random.betavariate(alpha, beta)
            except Exception:
                sampled_success = success
            value += (0.15 * (success - 0.5) + 0.10 * (sampled_success - 0.5) +
                      0.14 * (lower_success - 0.35))
            recent_median, recent_trend, recent_downside = self._outcome_signal(action)
            value += max(-0.34, min(0.34, recent_median * 0.11 + recent_trend * 0.075
                                    - recent_downside * 0.065))
            q25, q75, cvar, positive_rate, distribution_n = self._outcome_distribution(action)
            if distribution_n >= 4:
                spread = max(0.0, q75 - q25)
                if stagnant < 16:
                    value += max(-0.32, min(0.28, q25 * 0.070 + cvar * 0.050 +
                                             (positive_rate - 0.50) * 0.16 - spread * 0.016))
                else:
                    value += max(-0.20, min(0.38, q75 * 0.080 +
                                             (positive_rate - 0.45) * 0.12 -
                                             max(0.0, -cvar) * 0.026))

            n_eff = (min(24.0, blend_n) * 0.42 + pn * 0.15 + tn * 0.07 +
                     mn * 0.14 + nn * 0.16 + rn * 0.08 + inn * 0.05 + xn * 0.18 +
                     min(12.0, predicted_n) * 0.12 + min(12.0, delayed_n) * 0.10)
            prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
            # Text-derived priors are cold-start only: after roughly 2-3 trials
            # measured outcomes dominate almost completely.
            prior_strength = math.exp(-max(0.0, n_eff) / 1.15)
            value += (prior - 0.50) * 0.12 * prior_strength
            ucb_scale = 0.25 if proven else 0.48
            value += ucb_scale * math.sqrt(math.log(total + 1.0) / (n_eff + 1.0))
            variance = max(0.0, blend_uncertainty * blend_uncertainty + mv * 0.28 +
                           nv * 0.24 + rv * 0.12 + iv * 0.08 + xv * 0.18 +
                           predicted_uncertainty * predicted_uncertainty * 0.20 +
                           delayed_uncertainty * delayed_uncertainty * 0.12)
            value += min(0.16, 0.052 * math.sqrt(variance))
            if n_eff > 8:
                value -= min(0.15, 0.025 * math.sqrt(variance))

            # Keep objective utility and exploration utility explicit. Information
            # value decays with model maturity; side-effect and uncertainty penalties
            # remain independently learned rather than being hidden inside target gain.
            prediction_trust_final = (self._prediction_reliability(
                predicted_n, predicted_uncertainty * predicted_uncertainty)
                if predicted_n > 0 else 0.0)
            delayed_trust = 1.0 - math.exp(-max(0.0, delayed_n) / 4.0)
            maturity = 1.0 - math.exp(-max(0.0, n_eff) / 8.0)
            expected_target_gain = max(-0.30, min(0.30, predicted_gain * prediction_trust_final * 0.18))
            information_weight = (0.20 * (1.0 - maturity) *
                                  math.exp(-self.steps / 4200.0) + 0.012)
            information_gain = information_weight * min(1.5,
                1.0 / math.sqrt(n_eff + 1.0) + math.sqrt(variance) * 0.35)
            long_term_gain = max(-0.34, min(0.34, delayed_gain * delayed_trust * 0.30))
            uncertainty_risk = min(0.30,
                predicted_uncertainty * (0.035 + 0.055 * prediction_trust_final) +
                delayed_uncertainty * delayed_trust * 0.045)
            predicted_side_risk, side_evidence, side_uncertainty = self.predict_side_effect_risk(action, state)
            side_trust = 1.0 - math.exp(-max(0.0, side_evidence) / 3.5)
            side_effect_risk = min(0.72,
                predicted_side_risk * side_trust * 0.62 + side_uncertainty * 0.045)
            action_cost = self._estimated_action_cost(action)
            decision_delta = (expected_target_gain + information_gain + long_term_gain -
                              uncertainty_risk - side_effect_risk - action_cost)
            value += decision_delta

            if gn >= 6:
                neutral_rate = zero / max(1, gn)
                if neutral_rate > 0.62 and gq <= 0.04:
                    value -= min(0.34, (neutral_rate - 0.62) * 0.72)
                downside = float(stat.get("down", 0.0))
                if downside > 0.0:
                    value -= min(0.24, downside * 0.035)

            recent = self.recent.get(action, {})
            if recent:
                age = max(0, self.steps - int(recent.get("step", self.steps)))
                value += float(recent.get("r", 0.0)) * 0.27 * math.exp(-age / 105.0)

            if gn >= 7 and bad > good * 2 + 2 and gq < -0.10:
                value -= min(1.05, 0.080 * (bad - good))
            if cn == 0 and fn == 0 and an == 0:
                value += 0.085
            if inverse and action == inverse:
                value += min(0.42, 0.15 + abs(self.last_reward) * 0.08)
            if action.startswith("macro:") and gn < 2:
                value -= 0.06

            recent_count = self.action_trace[-7:].count(action)
            recent_reward = float(recent.get("r", 0.0)) if recent else 0.0
            if recent_count >= 3 and recent_reward <= 0.02:
                value -= 0.10 * (recent_count - 2)
            elif action == self.last_action and self.last_reward > 0.14 and recent_reward > 0.08:

                value += min(0.30, 0.09 + self.last_reward * 0.055)
            value += random.random() * 1e-6
            if value > best_value:
                best_action, best_value = action, value
        return best_action

    def learn(self, action, before, after, state, next_state, confidence=1.0, actions=None,
              action_started=None, observed_at=None, elapsed_seconds=None, visual_change=0.0,
              pre_action_rate=None, pre_action_reliability=0.0,
              paired_treatment_rate=None, paired_treatment_reliability=0.0):
        delta = after - before
        reward, reliability, reference = self._raw_reward(before, after, confidence)
        if elapsed_seconds is None:
            if action_started is not None and observed_at is not None:
                elapsed_seconds = max(0.06, float(observed_at) - float(action_started))
            else:
                elapsed_seconds = 1.0
        rate_signal = self._rate_signal(before, after, elapsed_seconds, confidence)
        passive_rate, passive_n, passive_variance = self.passive_rate_estimate(state)
        pre_action_reliability = max(0.0, min(1.0, float(pre_action_reliability or 0.0)))
        if pre_action_rate is not None and pre_action_reliability > 0.0:
            try:
                measured_pre_rate = float(pre_action_rate)
                if not math.isfinite(measured_pre_rate):
                    measured_pre_rate = passive_rate
            except (TypeError, ValueError, OverflowError):
                measured_pre_rate = passive_rate
            # Same-cycle baseline gets priority, historical passive rate remains the
            # stabilizer when the short pre-action observation is noisy.
            blend = 0.35 + 0.55 * pre_action_reliability
            expected_passive_rate = passive_rate * (1.0 - blend) + measured_pre_rate * blend
            effective_passive_n = passive_n + pre_action_reliability * 3.0
        else:
            expected_passive_rate = passive_rate
            effective_passive_n = passive_n
        rate_advantage = max(-5.0, min(5.0, rate_signal - expected_passive_rate))
        acceleration = max(-5.0, min(5.0, rate_signal - expected_passive_rate))
        causal_confidence = 1.0
        intervention_confidence = 0.0
        intervention_ate = rate_advantage
        if action == OBSERVE_ACTION:
            self._record_intervention_control(state, rate_signal, reliability)
        else:
            paired_control = measured_pre_rate if (pre_action_rate is not None and
                                                    pre_action_reliability > 0.0) else None
            treatment_rate_for_validation = rate_signal
            treatment_reliability_for_validation = reliability
            if paired_treatment_rate is not None and float(paired_treatment_reliability or 0.0) >= 0.20:
                try:
                    candidate_rate = float(paired_treatment_rate)
                    if math.isfinite(candidate_rate):
                        treatment_rate_for_validation = candidate_rate
                        treatment_reliability_for_validation = max(
                            0.0, min(1.0, float(paired_treatment_reliability)))
                except (TypeError, ValueError, OverflowError):
                    pass
            intervention_confidence, intervention_ate, _intervention_ci = self._record_intervention_treatment(
                action, state, treatment_rate_for_validation, treatment_reliability_for_validation,
                paired_control=paired_control, paired_confidence=pre_action_reliability)
            passive_noise = math.sqrt(max(0.0, passive_variance))
            separation = abs(rate_advantage) / max(0.10, 0.16 + passive_noise * 0.70)
            baseline_trust = 1.0 - math.exp(-max(0.0, effective_passive_n) / 4.0)
            visual_support = max(0.0, min(1.0, float(visual_change) / 0.08))
            consistency, consistency_streak = self._causal_consistency(
                action, state, rate_advantage, reliability)
            repeat_support = min(1.0, max(0.0, consistency * 0.75 + min(0.25, consistency_streak * 0.08)))
            causal_confidence = max(0.08, min(1.0,
                0.08 + separation * 0.22 + baseline_trust * 0.16 + visual_support * 0.12 +
                repeat_support * 0.16 + intervention_confidence * 0.38))
            # Prefer the paired/similar-state treatment-control estimate as its CI
            # becomes informative; retain the passive residual as cold-start support.
            causal_advantage = (rate_advantage * (1.0 - intervention_confidence) +
                                intervention_ate * intervention_confidence)
            counterfactual_reward = max(-8.0, min(8.0, causal_advantage * reliability))
            counterfactual_trust = max(baseline_trust * 0.65, intervention_confidence)
            reward = (reward * (1.0 - counterfactual_trust) +
                      counterfactual_reward * counterfactual_trust)
            reward *= max(0.12, causal_confidence)
            if abs(causal_advantage) > max(0.035, passive_noise * 0.45):
                reward += acceleration * 0.060 * reliability * causal_confidence
        if reliability < 0.30:
            reward *= max(0.025, (reliability / 0.30) ** 1.5)
        best_before = self.best
        if best_before is not None and after > best_before:
            best_gain = math.asinh((after - best_before) / reference)
            best_bonus = min(1.15, max(0.0, best_gain) * 0.16) * reliability
            if action != OBSERVE_ACTION:
                causal_gate = max(0.12, min(1.0, 0.18 + max(0.0, rate_advantage) * 0.24))
                best_bonus *= causal_gate
            reward += best_bonus
        if action == OBSERVE_ACTION:
            self._update(self.passive, "global", reward, 0.96)
            self._update(self.passive_rates, "global", rate_signal, 1.0, record_outcome=False)
            for family in self._state_families(state)[:5]:
                self._update(self.passive_families, family, reward, 0.96)
                self._update(self.passive_rates, family, rate_signal, 1.0, record_outcome=False)
            assignments = [(action, state, 1.0, 0.0)]
        else:
            baseline = self.passive_value(state)
            if abs(baseline) > 0.012:
                reward -= max(-5.0, min(5.0, baseline * 0.95 * causal_confidence))
            observed_at = float(observed_at if observed_at is not None else time.monotonic())
            action_started = float(action_started if action_started is not None else observed_at)
            candidates = [(action, state, action_started)]
            credit_horizon = self.adaptive_credit_horizon(action)
            for item in reversed(self.history):
                try:
                    old_action, old_state = item[0], item[1]
                    old_started = float(item[2]) if len(item) >= 3 else observed_at - 0.8
                except Exception:
                    continue
                elapsed = observed_at - old_started
                if elapsed >= 0:
                    candidates.append((old_action, old_state, old_started))
            weighted = []
            current_scene = state.split(":x", 1)[0]
            current_families = set(self._state_families(state))
            for index, (candidate_action, candidate_state, started) in enumerate(candidates):
                elapsed = max(0.0, observed_at - started)
                probability = self.delay_probability(candidate_action, elapsed)
                probability *= math.exp(-elapsed / max(0.25, credit_horizon) * 0.32)
                candidate_scene = candidate_state.split(":x", 1)[0]
                if candidate_scene == current_scene:
                    state_weight = 1.0
                else:
                    candidate_families = set(self._state_families(candidate_state))
                    overlap = len(current_families & candidate_families) / max(1, len(current_families | candidate_families))
                    state_weight = 0.52 + 0.38 * overlap
                if index == 0:
                    probability *= 1.08
                weighted.append((candidate_action, candidate_state, elapsed, max(1e-5, probability * state_weight)))
            total_weight = sum(item[3] for item in weighted) or 1.0
            assignments = [(a, st, w / total_weight, elapsed) for a, st, elapsed, w in weighted]
        reward = max(-8.0, min(8.0, reward))
        learning_weight = reliability if action == OBSERVE_ACTION else reliability * causal_confidence
        trusted_outcome = reliability >= 0.30 and (action == OBSERVE_ACTION or causal_confidence >= 0.28)
        current_share = assignments[0][2] if assignments else 1.0
        current_reward = reward * current_share
        future = self._future_value(next_state, actions)
        contextual_target = current_reward + 0.32 * future
        if action != OBSERVE_ACTION:
            self._update(self.rates, action, rate_advantage, max(0.10, learning_weight),
                         record_outcome=trusted_outcome)
        self._update(self.stats, action, current_reward, max(0.10, learning_weight),
                     record_outcome=trusted_outcome)
        self._update(self.contexts, self._context_key(state, action), contextual_target,
                     max(0.10, learning_weight), record_outcome=trusted_outcome)
        self._update_aliases(state, action, current_reward, contextual_target, trusted_outcome)
        for family in self._state_families(state):
            self._update(self.families, f"{family}>{action}", contextual_target, 0.80,
                         record_outcome=trusted_outcome)
        self._update_model(state, action, current_reward, next_state, max(0.08, learning_weight))
        if self.last_action:
            self._update(self.pairs, f"{self.last_action}>{action}", current_reward, 0.90,
                         record_outcome=trusted_outcome)
        if self.prev_action and self.last_action:
            self._update(self.triples, f"{self.prev_action}>{self.last_action}>{action}",
                         current_reward, 0.78, record_outcome=trusted_outcome)
        parts = self._macro_parts(action)
        if len(parts) > 1:
            for part in parts:
                self._update(self.stats, part, current_reward / max(1.0, math.sqrt(len(parts))),
                             0.48, record_outcome=trusted_outcome)
        if abs(reward) > 0.035 and action != OBSERVE_ACTION:
            dynamic_share_floor = max(0.0008, 0.020 / math.sqrt(max(1.0, len(assignments))))
            for old_action, old_state, share, elapsed in assignments[1:]:
                if share < dynamic_share_floor:
                    continue
                credit = reward * share
                self._update(self.stats, old_action, credit, 0.92,
                             record_outcome=trusted_outcome)
                self._update(self.contexts, self._context_key(old_state, old_action), credit, 0.88,
                             record_outcome=trusted_outcome)
                for family in self._state_families(old_state):
                    self._update(self.families, f"{family}>{old_action}", credit, 0.62,
                                 record_outcome=trusted_outcome)
                self.record_delay(old_action, elapsed, effect=True, weight=min(1.0, share * 2.4))
                old_recent = self.recent.get(old_action, {})
                old_recent_r = float(old_recent.get("r", 0.0))
                self.recent[old_action] = {"r": old_recent_r * 0.72 + credit * 0.28,
                                           "step": self.steps}
                old_trail = self.outcomes.setdefault(old_action, [])
                if not isinstance(old_trail, list):
                    old_trail = self.outcomes[old_action] = []
                old_trail.append([round(float(credit), 7), int(self.steps)])
                if len(old_trail) > 10:
                    del old_trail[:-10]
            if assignments:
                self.record_delay(action, assignments[0][3], effect=True,
                                  weight=min(1.0, assignments[0][2] * 2.0))
        for part in parts:
            if part:
                self.atomic_trace.append(part)
        if len(self.atomic_trace) > 28:
            self.atomic_trace = self.atomic_trace[-28:]
        if abs(current_reward) > 0.035:
            for length in range(2, min(6, len(self.atomic_trace)) + 1):
                if len(self.atomic_trace) >= length:
                    sequence = "|".join(self.atomic_trace[-length:])
                    weight = 0.92 if length == 2 else (0.78 if length == 3 else max(0.46, 0.72 - length * 0.045))
                    self._update(self.sequences, sequence, current_reward, weight,
                                 record_outcome=trusted_outcome)
                    for family in self._state_families(state)[:4]:
                        self._update(self.sequence_contexts, f"{family}>{sequence}",
                                     contextual_target, weight * 0.78,
                                     record_outcome=trusted_outcome)
        started = float(action_started if action_started is not None else time.monotonic())
        self.history.append((action, state, started))
        if len(self.history) > 512:
            self.history = self.history[-512:]
        self.prev_action = self.last_action
        self.last_action = action
        self.last_reward = current_reward
        self.steps += 1
        self.action_trace.append(action)
        if len(self.action_trace) > 36:
            self.action_trace = self.action_trace[-36:]
        old_recent = self.recent.get(action, {})
        old_r = float(old_recent.get("r", 0.0))
        self.recent[action] = {"r": old_r * 0.66 + current_reward * 0.34, "step": self.steps}
        trail = self.outcomes.setdefault(action, [])
        if not isinstance(trail, list):
            trail = self.outcomes[action] = []
        trail.append([round(float(current_reward), 7), int(self.steps)])
        if len(trail) > 10:
            del trail[:-10]
        if len(self.outcomes) > 260:
            ranked_outcomes = sorted(
                self.outcomes.items(),
                key=lambda kv: int(kv[1][-1][1]) if isinstance(kv[1], list) and kv[1] else -1,
                reverse=True)[:220]
            self.outcomes = dict(ranked_outcomes)
        if len(self.recent) > 150:
            keep = sorted(self.recent.items(), key=lambda kv: int(kv[1].get("step", 0)),
                          reverse=True)[:150]
            self.recent = dict(keep)
        self.record_action_parameters(action, current_reward, learning_weight)
        self._update_horizon_trace(action, state, current_reward, observed_at, before=before, after=after)
        self.observe_influence(action, state, visual_change, current_reward)
        self.observe_spatial_coverage(action, current_reward)
        self._trajectory_learning(action, state, current_reward, next_state, reliability,
                                  before, after, best_before)
        self.last_rate_signal = rate_signal
        if delta > 0:
            self.positive += 1
        if self.best is None or after > self.best:
            self.best = after
        return delta, current_reward
    @staticmethod
    def _action_parameter_observations(action):
        observations = []
        macro_interval = Learner._macro_interval_ms(action)
        if macro_interval is not None:
            observations.append(("macro.interval_ms", float(macro_interval)))
        for part in Learner._macro_parts(action):
            try:
                fields = str(part).split(":")
                kind = fields[0]
                if kind == "hold" and len(fields) == 3:
                    observations += [("hold.duration_ms", float(fields[2])),
                                     (f"hold.{fields[1]}.duration_ms", float(fields[2]))]
                elif kind == "pulse" and len(fields) == 5:
                    observations += [("pulse.press_ms", float(fields[2])),
                                     ("pulse.repeat", float(fields[3])),
                                     ("pulse.interval_ms", float(fields[4]))]
                elif kind == "chord" and len(fields) == 3:
                    observations.append(("chord.duration_ms", float(fields[2])))
                elif kind == "click" and len(fields) == 6 and fields[1] != "control":
                    observations.append(("mouse.click_count", float(fields[5])))
                elif kind == "tap" and len(fields) == 8:
                    observations += [("mouse.tap_repeat", float(fields[5])),
                                     ("mouse.tap_interval_ms", float(fields[6])),
                                     ("mouse.tap_press_ms", float(fields[7]))]
                elif kind == "wheel" and len(fields) == 6:
                    observations.append(("mouse.wheel_amount", abs(float(fields[2]))))
                elif kind == "drag" and len(fields) == 8:
                    grid = 10000.0 if fields[2] == "v" else max(2.0, float(fields[2]))
                    distance = math.hypot(float(fields[5]) - float(fields[3]),
                                          float(fields[6]) - float(fields[4])) / grid
                    observations += [("mouse.drag_distance", max(1e-6, distance)),
                                     ("mouse.drag_duration_ms", float(fields[7]))]
            except Exception:
                continue
        return observations

    def record_action_parameters(self, action, reward, reliability=1.0):
        reward = max(-8.0, min(8.0, float(reward)))
        reliability = max(0.05, min(1.0, float(reliability)))
        for key, value in self._action_parameter_observations(action):
            if not math.isfinite(value) or value <= 0:
                continue
            stat = self.parameters.setdefault(key, {
                "n": 0.0, "useful_n": 0.0, "mean_log": 0.0, "m2_log": 0.0,
                "min_observed": value, "max_observed": value,
                "best_value": value, "best_reward": -1e9})
            stat["n"] = float(stat.get("n", 0.0)) + reliability
            stat["min_observed"] = min(float(stat.get("min_observed", value)), value)
            stat["max_observed"] = max(float(stat.get("max_observed", value)), value)
            if reward > float(stat.get("best_reward", -1e9)):
                stat["best_reward"] = reward
                stat["best_value"] = value
            if reward > 0.015:
                w = reliability * min(2.5, 0.45 + reward)
                old_w = float(stat.get("useful_n", 0.0))
                new_w = old_w + w
                x = math.log(max(1e-9, value))
                mean = float(stat.get("mean_log", x)) if old_w > 0 else x
                delta = x - mean
                mean += delta * w / max(1e-9, new_w)
                m2 = float(stat.get("m2_log", 0.0)) + w * delta * (x - mean)
                stat["mean_log"], stat["m2_log"], stat["useful_n"] = mean, m2, new_w
            stat["last_seen"] = int(time.time())
            self._mark_dirty(self.parameters, key)

    def sample_parameter(self, key, default_min, default_max, fraction, integer=False, log_scale=True):
        lo0, hi0 = sorted((max(1e-9, float(default_min)), max(1e-9, float(default_max))))
        stat = self.parameters.get(str(key), {})
        if not isinstance(stat, dict):
            stat = {}
        useful = max(0.0, float(stat.get("useful_n", 0.0)))
        observed_min = max(1e-9, float(stat.get("min_observed", lo0)))
        observed_max = max(observed_min, float(stat.get("max_observed", hi0)))
        best = max(1e-9, float(stat.get("best_value", (lo0 + hi0) * 0.5)))
        best_reward = float(stat.get("best_reward", -1e9))
        lo = min(lo0, observed_min)
        hi = max(hi0, observed_max)
        # Bounds expand only when useful evidence accumulates at the observed frontier.
        if useful >= 0.8 and best_reward > 0.015:
            if best >= hi * 0.82:
                hi = max(hi, best * 1.8)
            if best <= lo * 1.18:
                lo = max(1e-9, min(lo, best * 0.55))
        f = max(0.0, min(1.0 - 1e-12, float(fraction)))
        explore = useful < 1.2 or f < max(0.12, 0.62 / math.sqrt(useful + 1.0))
        if log_scale:
            log_lo, log_hi = math.log(lo), math.log(max(lo * (1.0 + 1e-9), hi))
            if explore or useful <= 0:
                value = math.exp(log_lo + f * (log_hi - log_lo))
            else:
                mean = float(stat.get("mean_log", (log_lo + log_hi) * 0.5))
                variance = max(0.0, float(stat.get("m2_log", 0.0)) / max(1e-9, useful))
                sigma = max(0.10, min(1.35, math.sqrt(variance) + 0.42 / math.sqrt(useful + 1.0)))
                u1 = max(1e-9, ((f * 0.7548776662466927) + 0.1732050807568877) % 1.0)
                u2 = ((f * 0.5698402909980532) + 0.4142135623730951) % 1.0
                z = math.sqrt(-2.0 * math.log(u1)) * math.cos(math.tau * u2)
                value = math.exp(max(log_lo, min(log_hi, mean + z * sigma)))
        else:
            center = best if useful > 0 else (lo + hi) * 0.5
            span = (hi - lo) * max(0.08, min(0.5, 0.72 / math.sqrt(useful + 1.0)))
            value = lo + f * (hi - lo) if explore else center + (f * 2.0 - 1.0) * span
            value = max(lo, min(hi, value))
        return int(max(1, round(value))) if integer else float(value)

    def adaptive_credit_horizon(self, action=None):
        samples = []
        miss_evidence = 0.0
        parts = self._macro_parts(action) if action else tuple(self.delays)
        for part in parts:
            stat = self.delays.get(part, {})
            raw = stat.get("samples", []) if isinstance(stat, dict) else []
            if isinstance(raw, list):
                samples.extend(float(x) for x in raw if isinstance(x, (int, float)) and x >= 0)
            if isinstance(stat, dict):
                miss_evidence = max(miss_evidence, float(stat.get("miss", 0.0)))
        if not samples:
            # Repeated early misses widen the prior credit horizon automatically.
            # This is a decay scale, never an exclusion boundary.
            return 6.0 * (1.0 + math.log1p(miss_evidence) * 0.85 +
                          math.log1p(max(0, self.steps)) * 0.035)
        samples.sort()
        def quantile(q):
            index = min(len(samples) - 1, max(0, int(round((len(samples) - 1) * q))))
            return samples[index]
        p90, p99 = quantile(0.90), quantile(0.99)
        return max(2.0, p90 * 1.35, p99 * 1.9, max(samples) * 1.15)

    def _delay_bin_index(self, elapsed):
        elapsed = max(0.0, float(elapsed or 0.0))
        index = 0
        while index + 1 < len(self.DELAY_BOUNDS) and elapsed > self.DELAY_BOUNDS[index]:
            index += 1
        return index

    def record_delayed_attribute_effect(self, action, state, outcome, signal, changed,
                                        elapsed, reliability=1.0):
        if not action or not outcome:
            return
        try:
            signal = max(-12.0, min(12.0, float(signal)))
            reliability = max(0.02, min(1.0, float(reliability)))
        except (TypeError, ValueError, OverflowError):
            return
        index = self._delay_bin_index(elapsed)
        family = self._key_probe_family(state)
        for scope in (family, "global"):
            raw_key = f"{scope}>{action}>{outcome}>d{index}"
            key = "de_" + hashlib.sha1(raw_key.encode("utf-8", "replace")).hexdigest()[:24]
            stat = self.delayed_attribute_effects.setdefault(
                key, {"n": 0.0, "mean": 0.0, "m2": 0.0, "change": 0.0,
                      "action": str(action), "outcome": str(outcome),
                      "state_family": scope, "delay_bin": index, "last_seen": 0})
            old_n = max(0.0, float(stat.get("n", 0.0) or 0.0))
            new_n = old_n + reliability
            old_mean = float(stat.get("mean", 0.0) or 0.0)
            delta = signal - old_mean
            new_mean = old_mean + delta * reliability / max(1e-9, new_n)
            stat["m2"] = max(0.0, float(stat.get("m2", 0.0) or 0.0) +
                             reliability * delta * (signal - new_mean))
            stat["mean"] = new_mean
            old_change = float(stat.get("change", 0.0) or 0.0)
            sample_change = 1.0 if changed else 0.0
            stat["change"] = old_change + (sample_change - old_change) * reliability / max(1e-9, new_n)
            stat["n"] = new_n
            stat["last_seen"] = int(time.time())
            self._mark_dirty(self.delayed_attribute_effects, key)
        if len(self.delayed_attribute_effects) > 5200:
            keep = {key for key, _value in sorted(
                self.delayed_attribute_effects.items(),
                key=lambda item: (float(item[1].get("n", 0.0) or 0.0),
                                  int(item[1].get("last_seen", 0) or 0)),
                reverse=True)[:4600]}
            for old_key in list(self.delayed_attribute_effects):
                if old_key not in keep:
                    self._delete_key("delayed_attribute_effects", old_key)

    def _delayed_effect_stat(self, action, state, outcome, delay_index):
        family = self._key_probe_family(state)
        values = []
        for scope, weight in ((family, 1.0), ("global", 0.55)):
            raw_key = f"{scope}>{action}>{outcome}>d{int(delay_index)}"
            key = "de_" + hashlib.sha1(raw_key.encode("utf-8", "replace")).hexdigest()[:24]
            stat = self.delayed_attribute_effects.get(key, {})
            n = max(0.0, float(stat.get("n", 0.0) or 0.0)) if isinstance(stat, dict) else 0.0
            if n > 0:
                values.append((stat, weight, n))
        if not values:
            return 0.0, 0.0, 0.0, 0.0
        total_weight = sum(weight * min(4.0, 0.6 + math.log1p(n)) for _stat, weight, n in values)
        mean = change = variance = evidence = 0.0
        for stat, weight, n in values:
            w = weight * min(4.0, 0.6 + math.log1p(n)) / max(1e-9, total_weight)
            mean += float(stat.get("mean", 0.0) or 0.0) * w
            change += max(0.0, min(1.0, float(stat.get("change", 0.0) or 0.0))) * w
            variance += max(0.0, float(stat.get("m2", 0.0) or 0.0) / max(1.0, n - 1.0)) * w
            evidence += n * w
        return mean, change, evidence, math.sqrt(max(0.0, variance))

    def predict_delayed_target_gain(self, state, action):
        gain = evidence = uncertainty = weight_sum = 0.0
        horizon = max(0.8, self.adaptive_credit_horizon(action))
        previous_bound = 0.0
        for index, bound in enumerate(self.DELAY_BOUNDS):
            midpoint = (previous_bound + bound) * 0.5
            previous_bound = bound
            mean, probability, n, sigma = self._delayed_effect_stat(
                action, state, "target.value", index)
            if n <= 0.0:
                continue
            passive_mean, passive_probability, passive_n, passive_sigma = self._delayed_effect_stat(
                OBSERVE_ACTION, state, "target.value", index)
            passive_trust = 1.0 - math.exp(-max(0.0, passive_n) / 3.0)
            residual_mean = mean - passive_mean * passive_trust
            residual_probability = max(0.0, probability - passive_probability * passive_trust * 0.55)
            temporal = math.exp(-midpoint / horizon * 0.28)
            trust = 1.0 - math.exp(-n / 3.0)
            w = temporal * trust
            gain += residual_mean * max(0.15, residual_probability) * w
            uncertainty += (sigma + passive_sigma * passive_trust + 1.0 / math.sqrt(n + 1.0)) * w
            evidence += n * w
            weight_sum += w
        if weight_sum <= 0.0:
            return 0.0, 0.0, 1.0
        return gain / weight_sum, evidence, uncertainty / weight_sum

    def delay_hint(self, action):
        hints = []
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            bins = stat.get("bins", []) if isinstance(stat, dict) else []
            if isinstance(bins, list) and sum(float(x) for x in bins) >= 1.2:
                total = sum(float(x) for x in bins)
                acc = 0.0
                for index, count in enumerate(bins[:len(self.DELAY_BOUNDS)]):
                    acc += float(count)
                    if acc >= total * 0.62:
                        hints.append(min(0.95, self.DELAY_BOUNDS[index] * 0.52))
                        break
            else:
                late = float(stat.get("late", 0.0)) if isinstance(stat, dict) else 0.0
                if late > 0.12:
                    hints.append(min(0.42, 0.055 + late * 0.30))
        return max(hints, default=0.0)
    def delay_probability(self, action, elapsed):
        elapsed = max(0.0, float(elapsed))
        values = []
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            bins = stat.get("bins", []) if isinstance(stat, dict) else []
            total = sum(float(x) for x in bins) if isinstance(bins, list) else 0.0
            samples = stat.get("samples", []) if isinstance(stat, dict) else []
            if isinstance(samples, list) and len(samples) >= 3:
                logs = [math.log1p(max(0.0, float(x))) for x in samples if isinstance(x, (int, float))]
                if logs:
                    center = math.log1p(elapsed)
                    mean = sum(logs) / len(logs)
                    variance = sum((x - mean) ** 2 for x in logs) / max(1, len(logs) - 1)
                    bandwidth = max(0.18, min(0.95, math.sqrt(max(0.0, variance)) * 0.55 + 0.16))
                    kernel = sum(math.exp(-0.5 * ((center - x) / bandwidth) ** 2) for x in logs) / len(logs)
                    tail = 0.035 * math.exp(-elapsed / max(0.5, self.adaptive_credit_horizon(part)))
                    values.append(max(0.004, kernel + tail))
                    continue
            index = 0
            while index + 1 < len(self.DELAY_BOUNDS) and elapsed > self.DELAY_BOUNDS[index]:
                index += 1
            if total >= 1.5 and bins:
                count = float(bins[min(index, len(bins) - 1)])
                probability = (count + 0.18) / (total + 0.18 * len(self.DELAY_BOUNDS))
                evidence = 1.05 + min(0.72, math.log1p(total) * 0.24)
                probability *= evidence
                probability *= 1.0 / max(0.62, self.DELAY_BOUNDS[min(index, len(self.DELAY_BOUNDS)-1)] ** 0.12)
            else:
                probability = 0.56 * math.exp(-elapsed / 0.58) + 0.10 * math.exp(-elapsed / 2.5) + 0.025
            values.append(max(0.004, probability))
        return max(values, default=max(0.004, 0.92 * math.exp(-elapsed / 0.72)))

    def delay_probe_window(self, action, stagnant=0):
        learned = []
        misses = 0.0
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            samples = stat.get("samples", []) if isinstance(stat, dict) else []
            if isinstance(samples, list):
                learned.extend(float(x) for x in samples if isinstance(x, (int, float)) and x >= 0)
            if isinstance(stat, dict):
                misses = max(misses, float(stat.get("miss", 0.0)))
        if learned:
            learned.sort()
            p90 = learned[min(len(learned) - 1, int(round((len(learned) - 1) * 0.90)))]
            return max(0.28, p90 * 1.18 + 0.12)
        # Cold-start probes expand with both stagnation and repeated early misses.
        pressure = math.log1p(max(0, stagnant)) + math.log1p(max(0.0, misses)) * 1.35
        return 0.62 * (1.0 + 0.26 * pressure * pressure)
    def record_delay(self, action, delay_seconds=None, effect=False, weight=1.0):
        delay = max(0.0, float(delay_seconds or 0.0))
        weight = max(0.05, min(1.0, float(weight)))
        for part in self._macro_parts(action):
            stat = self.delays.setdefault(part, {"n": 0, "late": 0.0, "bins": [0.0] * len(self.DELAY_BOUNDS), "miss": 0.0})
            if not isinstance(stat.get("bins"), list) or len(stat.get("bins", [])) != len(self.DELAY_BOUNDS):
                stat["bins"] = [0.0] * len(self.DELAY_BOUNDS)
            stat["n"] = int(stat.get("n", 0)) + 1
            late_value = 1.0 if effect and delay > 0.42 else 0.0
            rate = 0.22 if stat["n"] < 10 else 0.09
            stat["late"] = float(stat.get("late", 0.0)) * (1.0 - rate) + late_value * rate
            if effect:
                index = 0
                while index + 1 < len(self.DELAY_BOUNDS) and delay > self.DELAY_BOUNDS[index]:
                    index += 1
                stat["bins"][index] = float(stat["bins"][index]) + weight
                raw_samples = stat.setdefault("samples", [])
                if not isinstance(raw_samples, list):
                    raw_samples = stat["samples"] = []
                raw_samples.append(float(delay))
                if len(raw_samples) > 96:
                    # Keep a mix of recent and tail observations so long delays do not
                    # disappear merely because they are rare.
                    recent = raw_samples[-64:]
                    tails = sorted(raw_samples[:-64])[-32:]
                    stat["samples"] = tails + recent
                stat["miss"] = float(stat.get("miss", 0.0)) * 0.96
            else:
                stat["miss"] = min(30.0, float(stat.get("miss", 0.0)) + weight)
                if stat["miss"] > 4.0:
                    decay = 0.994 if stat["miss"] < 10.0 else 0.982
                    stat["bins"] = [float(x) * decay for x in stat["bins"]]
            if sum(float(x) for x in stat["bins"]) > 80.0:
                stat["bins"] = [float(x) * 0.72 for x in stat["bins"]]
            self._mark_dirty(self.delays, part)
        if len(self.delays) > 220:
            keep = {key for key, _value in sorted(self.delays.items(),
                          key=lambda kv: int(kv[1].get("n", 0)), reverse=True)[:200]}
            for key in list(self.delays):
                if key not in keep:
                    self._delete_key("delays", key)
    def record_input_result(self, action, status):
        if status not in {ACTION_EXECUTED, ACTION_BLOCKED, ACTION_FAILED}:
            return
        raw_action = str(action or "unknown")
        records = [raw_action]
        # A failed macro does not imply that every earlier atom failed. Only expand
        # a macro after complete execution, otherwise keep reliability attribution
        # at the macro level.
        if raw_action.startswith("macro:") and status == ACTION_EXECUTED:
            records.extend(self._macro_parts(raw_action))
        for part in dict.fromkeys(records):
            kind = str(part).split(":", 1)[0] or "unknown"
            for key in (f"action:{part}", f"kind:{kind}"):
                stat = self.input_reliability.setdefault(
                    key, {"executed": 0.0, "blocked": 0.0, "failed": 0.0, "last_step": 0})
                stat[status] = float(stat.get(status, 0.0)) + 1.0
                stat["last_step"] = int(self.steps)
                self._mark_dirty(self.input_reliability, key)

    def record_measurement_failure(self, action, state, health):
        health = dict(health or {})
        reason = str(health.get("failure_reason") or "measurement_invalid")[:180]
        family = self._key_probe_family(state)
        key = f"{family}>{str(action or 'unknown')[:180]}"
        stat = self.measurement_failures.setdefault(
            key, {"n": 0.0, "last_step": 0, "reasons": {}, "confidence_mean": 0.0})
        old_n = max(0.0, float(stat.get("n", 0.0) or 0.0))
        new_n = old_n + 1.0
        confidence = max(0.0, min(1.0, float(health.get("confidence", 0.0) or 0.0)))
        stat["confidence_mean"] = float(stat.get("confidence_mean", 0.0) or 0.0) + (confidence - float(stat.get("confidence_mean", 0.0) or 0.0)) / new_n
        stat["n"] = new_n
        stat["last_step"] = int(self.steps)
        reasons = stat.setdefault("reasons", {})
        for token in (part for part in reason.split(";") if part):
            reasons[token] = int(reasons.get(token, 0) or 0) + 1
        self._mark_dirty(self.measurement_failures, key)
        if len(self.measurement_failures) > 256:
            keep = {k for k, _v in sorted(self.measurement_failures.items(),
                    key=lambda item: (int(item[1].get("last_step", 0)), float(item[1].get("n", 0.0))),
                    reverse=True)[:220]}
            for old_key in list(self.measurement_failures):
                if old_key not in keep:
                    self._delete_key("measurement_failures", old_key)

    def input_success_probability(self, action):
        stat = self.input_reliability.get(f"action:{action}", {})
        executed = max(0.0, float(stat.get("executed", 0.0)))
        failed = max(0.0, float(stat.get("failed", 0.0)))
        blocked = max(0.0, float(stat.get("blocked", 0.0)))
        total = executed + failed + blocked
        if total <= 0.0:
            return 1.0, 0.0
        # BLOCKED is usually environmental/focus related; discount it relative to a
        # genuine input-send failure so action utility is not contaminated by it.
        effective_bad = failed + blocked * 0.25
        return (executed + 1.0) / max(1e-9, executed + effective_bad + 2.0), total

    @staticmethod
    def _moment_update(stat, prefix, value, weight):
        value = float(value)
        weight = max(0.02, float(weight))
        n_key, mean_key, m2_key = f"{prefix}_n", f"{prefix}_mean", f"{prefix}_m2"
        old_n = max(0.0, float(stat.get(n_key, 0.0) or 0.0))
        old_mean = float(stat.get(mean_key, 0.0) or 0.0)
        new_n = old_n + weight
        delta = value - old_mean
        new_mean = old_mean + delta * weight / max(1e-9, new_n)
        stat[m2_key] = max(0.0, float(stat.get(m2_key, 0.0) or 0.0) +
                           weight * delta * (value - new_mean))
        stat[mean_key] = new_mean
        stat[n_key] = new_n
        return new_n, new_mean

    def _record_intervention_control(self, state, rate, confidence):
        family = self._key_probe_family(state)
        key = f"control|{family}"
        stat = self.causal_validations.setdefault(
            key, {"n": 0.0, "observations": 0, "last_seen": 0})
        weight = max(0.08, min(1.0, float(confidence or 0.0)))
        self._moment_update(stat, "control", float(rate), weight)
        stat["n"] = float(stat.get("control_n", 0.0))
        stat["observations"] = int(stat.get("observations", 0) or 0) + 1
        stat["last_seen"] = int(time.time())
        self._mark_dirty(self.causal_validations, key)
        return stat

    def _record_intervention_treatment(self, action, state, treatment_rate, confidence,
                                       paired_control=None, paired_confidence=0.0):
        """Learn treatment/control ATE, uncertainty and CI in a similar state family."""
        family = self._key_probe_family(state)
        key = f"{action}|{family}"
        stat = self.causal_validations.setdefault(
            key, {"positive": 0.0, "negative": 0.0, "streak": 0, "last_sign": 0,
                  "n": 0.0, "observations": 0, "last_seen": 0})
        weight = max(0.08, min(1.0, float(confidence or 0.0)))
        self._moment_update(stat, "treatment", float(treatment_rate), weight)

        control_bucket = self.causal_validations.get(f"control|{family}", {})
        if paired_control is not None and float(paired_confidence or 0.0) >= 0.20:
            pair_weight = weight * max(0.20, min(1.0, float(paired_confidence)))
            self._moment_update(stat, "paired", float(treatment_rate) - float(paired_control), pair_weight)
            # The paired baseline is also a valid same-family no-action sample.
            self._record_intervention_control(state, float(paired_control), float(paired_confidence))
            control_bucket = self.causal_validations.get(f"control|{family}", {})

        treatment_n = max(0.0, float(stat.get("treatment_n", 0.0) or 0.0))
        control_n = max(0.0, float(control_bucket.get("control_n", 0.0) or 0.0))
        paired_n = max(0.0, float(stat.get("paired_n", 0.0) or 0.0))
        treatment_mean = float(stat.get("treatment_mean", 0.0) or 0.0)
        control_mean = float(control_bucket.get("control_mean", 0.0) or 0.0)
        paired_mean = float(stat.get("paired_mean", 0.0) or 0.0)

        if paired_n >= 0.8:
            ate = paired_mean
            paired_var = max(0.0, float(stat.get("paired_m2", 0.0) or 0.0) /
                             max(1.0, paired_n - 1.0))
            se = math.sqrt(paired_var / max(1.0, paired_n))
            effective_n = paired_n
        else:
            ate = treatment_mean - control_mean
            treatment_var = max(0.0, float(stat.get("treatment_m2", 0.0) or 0.0) /
                                max(1.0, treatment_n - 1.0))
            control_var = max(0.0, float(control_bucket.get("control_m2", 0.0) or 0.0) /
                              max(1.0, control_n - 1.0))
            se = math.sqrt(treatment_var / max(1.0, treatment_n) +
                           control_var / max(1.0, control_n)) if control_n > 0 else math.sqrt(
                               treatment_var / max(1.0, treatment_n))
            effective_n = min(treatment_n, control_n) if control_n > 0 else 0.0
        ci = 1.96 * se
        excludes_zero = abs(ate) > ci and effective_n >= 1.0
        sample_gate = 1.0 - math.exp(-max(0.0, effective_n) / 3.0)
        signal_gate = abs(ate) / max(0.06, abs(ate) + ci + 0.06)
        intervention_confidence = max(0.0, min(1.0,
            sample_gate * signal_gate * (1.0 if excludes_zero else 0.55)))
        stat["ate"] = float(ate)
        stat["standard_error"] = float(se)
        stat["ci95"] = float(ci)
        stat["ci95_low"] = float(ate - ci)
        stat["ci95_high"] = float(ate + ci)
        stat["intervention_confidence"] = float(intervention_confidence)
        stat["control_n"] = control_n
        stat["n"] = max(float(stat.get("n", 0.0) or 0.0), treatment_n, paired_n)
        stat["observations"] = int(stat.get("observations", 0) or 0) + 1
        stat["last_seen"] = int(time.time())
        self._mark_dirty(self.causal_validations, key)
        return intervention_confidence, ate, ci

    def side_effect_risk(self, action, state=None):
        keys = [f"global>{action}"]
        if state:
            keys.insert(0, f"{self._key_probe_family(state)}>{action}")
        weighted = 0.0
        total = 0.0
        evidence = 0.0
        for key in keys:
            stat = self.side_effects.get(key, {})
            n = max(0.0, float(stat.get("n", 0.0) or 0.0))
            if n <= 0:
                continue
            weight = min(3.0, math.log1p(n) + 0.25)
            weighted += max(0.0, min(1.0, float(stat.get("risk", 0.0) or 0.0))) * weight
            total += weight
            evidence += n
        if total <= 0:
            return 0.0, 0.0
        return weighted / total, evidence

    def predict_side_effect_risk(self, action, state=None):
        """Return learned risk, evidence and interaction uncertainty.

        Chords are not blacklisted. Their risk is inferred from their own history,
        component keys and previously observed overlapping chords; unknown interaction
        risk decays only as evidence is collected.
        """
        own_risk, own_n = self.side_effect_risk(action, state)
        raw = str(action or "")
        names = []
        if raw.startswith("chord:"):
            try:
                names = [name for name in raw.split(":", 2)[1].split("+") if name]
            except Exception:
                names = []
        if len(names) < 2:
            uncertainty = 1.0 / math.sqrt(1.0 + own_n)
            return own_risk, own_n, uncertainty

        component_survival = 1.0
        component_evidence = 0.0
        for name in names:
            risk, n = self.side_effect_risk(f"key:{name}", state)
            trust = 1.0 - math.exp(-max(0.0, n) / 3.0)
            component_survival *= max(0.0, 1.0 - risk * trust)
            component_evidence += n
        component_risk = 1.0 - component_survival

        similar_weight = similar_risk = similar_n = 0.0
        wanted = set(names)
        for key, stat in self.side_effects.items():
            if not str(key).startswith("global>chord:") or not isinstance(stat, dict):
                continue
            candidate = str(key).split("global>", 1)[1]
            try:
                candidate_names = set(candidate.split(":", 2)[1].split("+"))
            except Exception:
                continue
            overlap = len(wanted & candidate_names) / max(1, len(wanted | candidate_names))
            if overlap <= 0.0:
                continue
            n = max(0.0, float(stat.get("n", 0.0) or 0.0))
            if n <= 0.0:
                continue
            weight = overlap * min(3.0, math.log1p(n) + 0.25)
            similar_risk += max(0.0, min(1.0, float(stat.get("risk", 0.0) or 0.0))) * weight
            similar_weight += weight
            similar_n += n * overlap
        learned_interaction = similar_risk / similar_weight if similar_weight else 0.0
        own_trust = 1.0 - math.exp(-max(0.0, own_n) / 2.0)
        similar_trust = 1.0 - math.exp(-max(0.0, similar_n) / 4.0)
        predicted = max(component_risk, own_risk * own_trust, learned_interaction * similar_trust)
        evidence = own_n + component_evidence * 0.25 + similar_n * 0.50
        interaction_uncertainty = 1.0 / math.sqrt(
            1.0 + own_n + similar_n * 0.65 + component_evidence * 0.12)
        return max(0.0, min(1.0, predicted)), evidence, interaction_uncertainty

    def record_side_effect(self, action, state, risk, signals=None, reliability=1.0):
        if not action or action == OBSERVE_ACTION:
            return
        risk = max(0.0, min(1.0, float(risk or 0.0)))
        reliability = max(0.05, min(1.0, float(reliability or 0.0)))
        for key in (f"global>{action}", f"{self._key_probe_family(state)}>{action}"):
            stat = self.side_effects.setdefault(
                key, {"n": 0.0, "risk": 0.0, "m2": 0.0, "signals": {}, "last_seen": 0})
            old_n = max(0.0, float(stat.get("n", 0.0) or 0.0))
            new_n = old_n + reliability
            old_mean = float(stat.get("risk", 0.0) or 0.0)
            delta = risk - old_mean
            new_mean = old_mean + delta * reliability / max(1e-9, new_n)
            stat["m2"] = max(0.0, float(stat.get("m2", 0.0) or 0.0) +
                             reliability * delta * (risk - new_mean))
            stat["risk"] = new_mean
            stat["n"] = new_n
            stat["last_seen"] = int(time.time())
            signal_stats = stat.setdefault("signals", {})
            for name, value in dict(signals or {}).items():
                try:
                    sample = max(0.0, min(1.0, float(value)))
                except Exception:
                    continue
                signal_stats[str(name)] = float(signal_stats.get(str(name), 0.0)) * 0.88 + sample * 0.12
            self._mark_dirty(self.side_effects, key)

    def _causal_consistency(self, action, state, rate_advantage, confidence):
        magnitude = abs(float(rate_advantage))
        if magnitude < 0.018 or confidence < 0.25:
            return 0.0, 0
        family = self._key_probe_family(state)
        key = f"{action}|{family}"
        stat = self.causal_validations.setdefault(
            key, {"positive": 0.0, "negative": 0.0, "streak": 0, "last_sign": 0,
                  "n": 0.0, "observations": 0})
        sign = 1 if rate_advantage > 0 else -1
        weight = max(0.10, min(1.0, float(confidence)))
        if sign > 0:
            stat["positive"] = float(stat.get("positive", 0.0)) + weight
        else:
            stat["negative"] = float(stat.get("negative", 0.0)) + weight
        last_sign = int(stat.get("last_sign", 0) or 0)
        stat["streak"] = (int(stat.get("streak", 0) or 0) + 1) if last_sign == sign else 1
        stat["last_sign"] = sign
        stat["n"] = float(stat.get("n", 0.0)) + weight
        stat["observations"] = int(stat.get("observations", 0) or 0) + 1
        positive = float(stat.get("positive", 0.0))
        negative = float(stat.get("negative", 0.0))
        directional = max(positive, negative) / max(1e-9, positive + negative)
        streak = int(stat.get("streak", 0) or 0)
        observations = int(stat.get("observations", 0) or 0)
        directional_strength = max(0.0, min(1.0, (directional - 0.5) * 2.0))
        # One coincidence is intentionally weak evidence. Repeated same-direction
        # residuals are required before causal confidence gets a material boost.
        repeat_gate = 0.08 if observations < 2 else min(1.0, 0.36 + 0.18 * (observations - 2))
        streak_gate = 0.20 if streak < 2 else min(1.0, 0.45 + 0.18 * (streak - 2))
        consistency = directional_strength * repeat_gate * streak_gate
        self._mark_dirty(self.causal_validations, key)
        return consistency, streak

    def action_quality(self, action, state=None):
        gq = self._value(self.stats.get(action, {}))[0]
        median, trend, downside = self._outcome_signal(action)
        recent_adjust = max(-0.35, min(0.35, median * 0.10 + trend * 0.07 - downside * 0.06))
        if not state:
            return gq + recent_adjust
        cq, cn, _ = self._value(self.contexts.get(self._context_key(state, action), {}))
        fq, fn, _fv, _fg, _fb = self._family_value(state, action)
        aq, an, _av = self._alias_value(state, action)
        nq, nn, _nv = self._nstep_value(state, action)
        rq, rn, _rv = self._value(self.rates.get(action, {}))
        iq, inn, _iv = self.influence_value(state, action)
        xq, xn, _xv = self._sequence_value(action, state)
        if cn:
            base = 0.46 * cq + 0.22 * gq + 0.12 * fq + (0.05 * aq if an else 0.0)
        elif fn:
            base = 0.47 * gq + 0.31 * fq + (0.07 * aq if an else 0.0)
        elif an:
            base = 0.66 * gq + 0.19 * aq
        else:
            base = gq
        if nn:
            weight = min(0.40, 0.16 + math.log1p(nn) * 0.045)
            base = base * (1.0 - weight) + nq * weight
        if rn:
            base += max(-0.28, min(0.32, rq * 0.11))
        if inn:
            base += max(-0.16, min(0.24, iq * 0.12))
        if xn:
            weight = min(0.56, 0.22 + math.log1p(xn) * 0.065)
            base = base * (1.0 - weight) + xq * weight
        input_probability, input_samples = self.input_success_probability(action)
        if input_samples >= 2.0:
            base -= (1.0 - input_probability) * min(0.34, 0.07 + math.log1p(input_samples) * 0.055)
        side_risk, side_samples = self.side_effect_risk(action, state)
        if side_samples > 0.0:
            # Risk is learned independently from efficacy.  It lowers exploration in
            # this state without permanently blacklisting any non-ESC input.
            risk_trust = min(1.0, math.log1p(side_samples) / math.log(8.0))
            base -= side_risk * risk_trust * 0.82
        return base + recent_adjust

    def preferred_actions(self, prefix="", limit=8):
        ranked = []
        for action, stat in self.stats.items():
            if action.startswith("macro:"):
                continue
            if prefix and not action.startswith(prefix):
                continue
            q, n, _ = self._value(stat)
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            zero = int(stat.get("zero", 0))
            success = (good + 1) / (good + bad + zero + 2)
            if n >= 6 and zero / max(1, n) > 0.78 and q <= 0.02:
                continue
            if n >= 2 and q > -0.08 and success >= 0.28:
                downside = float(stat.get("down", 0.0))
                ranked.append((q + min(0.2, math.log1p(n) * 0.02) + success * 0.07
                               - min(0.12, downside * 0.025), action))
        ranked.sort(reverse=True)
        return [action for _score, action in ranked[:limit]]

    @staticmethod
    def _retention_priority(value):
        if not isinstance(value, dict):
            return -1e9
        sample_values = []
        for name in ("n", "useful_n", "chain_n", "prediction_n"):
            try:
                candidate = float(value.get(name, 0.0) or 0.0)
                if math.isfinite(candidate):
                    sample_values.append(max(0.0, candidate))
            except (TypeError, ValueError, OverflowError):
                continue
        samples = max(sample_values, default=0.0)
        strengths = []
        for name in ("q", "utility", "reward", "chain_utility", "best_reward", "effective",
                     "causal_product", "product", "ate", "score", "activity"):
            try:
                candidate = abs(float(value.get(name, 0.0)))
                if math.isfinite(candidate) and candidate < 1e6:
                    strengths.append(candidate)
            except (TypeError, ValueError, OverflowError):
                continue
        strength = min(8.0, max(strengths, default=0.0))
        try:
            uncertainty = max(0.0, min(4.0, float(value.get("uncertainty", 0.0) or 0.0)))
        except (TypeError, ValueError, OverflowError):
            uncertainty = 0.0
        try:
            prediction_n = max(0.0, float(value.get("prediction_n", 0.0) or 0.0))
            prediction_m2 = max(0.0, float(value.get("prediction_error_m2", 0.0) or 0.0))
            prediction_mean = abs(float(value.get("prediction_error_mean", 0.0) or 0.0))
            prediction_variance = prediction_m2 / max(1.0, prediction_n - 1.0) if prediction_n > 1.0 else 0.0
            prediction_reliability = (1.0 - math.exp(-prediction_n / 3.0)) / (
                1.0 + prediction_mean + math.sqrt(prediction_variance))
        except (TypeError, ValueError, OverflowError):
            prediction_reliability = 0.0
        causal_strength = 0.0
        try:
            causal_strength = min(8.0, abs(float(value.get("causal_product", 0.0) or 0.0)))
        except (TypeError, ValueError, OverflowError):
            pass
        target_bonus = 0.85 if bool(value.get("to_target", False)) else 0.0
        if bool(value.get("to_target", False)) and str(value.get("to_attribute", "")) == "value":
            target_bonus += 0.65
        if bool(value.get("passive", False)):
            target_bonus *= 0.35
        try:
            last_seen = int(value.get("last_seen", 0) or 0)
        except (TypeError, ValueError, OverflowError):
            last_seen = 0
        age_penalty = 0.0
        if last_seen > 0:
            age_days = max(0.0, (time.time() - last_seen) / 86400.0)
            age_penalty = math.log1p(age_days) * 0.18
        return (math.log1p(samples) + strength * 0.45 + causal_strength * 0.52 +
                prediction_reliability * 1.10 + target_bonus + uncertainty * 0.08 - age_penalty)

    def _trim_attr(self, attr, limit):
        table = getattr(self, attr)
        if len(table) <= limit:
            return
        ranked = sorted(table.items(),
                        key=lambda kv: self._retention_priority(kv[1]), reverse=True)
        keep = {key for key, _value in ranked[:limit]}
        for key in list(table):
            if key not in keep:
                self._delete_key(attr, key)

    def save(self):
        if self._db is None:
            return
        for attr, limit in (("contexts", 18000), ("families", 14000), ("pairs", 5200),
                            ("triples", 6200), ("sequences", 6000),
                            ("sequence_contexts", 9000), ("aliases", 9000),
                            ("models", 12000), ("passive_families", 3000),
                            ("nstep", 16000), ("trajectory_sequences", 9000),
                            ("rates", 5000), ("passive_rates", 3500),
                            ("passive_attributes", 6000), ("influence", 10000),
                            ("effects", 12000), ("scopes", 3000),
                            ("parameters", 4000),
                            ("numeric_scales", 32),
                            ("relation_candidates", RELATION_CONFIG.candidate_limit),
                            ("attribute_relations", RELATION_CONFIG.formal_relation_limit),
                            ("key_probes", 9000), ("coverage", 1200),
                            ("input_reliability", 1200), ("causal_validations", 5000),
                            ("side_effects", 2600)):
            self._trim_attr(attr, limit)
        dirty_snapshot = {name: set(values) for name, values in self._dirty.items()}
        deleted_snapshot = {name: set(values) for name, values in self._deleted.items()}
        with self._db:
            self._db.execute('DELETE FROM meta WHERE key=?', ("quarantined_keys",))
            for attr, table_name in self._table_specs.items():
                table = getattr(self, attr)
                deleted = deleted_snapshot[table_name]
                if deleted:
                    self._db.executemany(f'DELETE FROM "{table_name}" WHERE key=?',
                                         ((key,) for key in deleted))
                rows = []
                for key in dirty_snapshot[table_name]:
                    if key in table:
                        rows.append((key, json.dumps(table[key], ensure_ascii=False, separators=(",", ":"))))
                if rows:
                    self._db.executemany(
                        f'INSERT INTO "{table_name}"(key,value) VALUES(?,?) '
                        'ON CONFLICT(key) DO UPDATE SET value=excluded.value', rows)
            meta = {
                "version": 29, "steps": self.steps, "best": self.best,
                "positive": self.positive, "recent": self.recent, "outcomes": self.outcomes,
            }
            self._db.executemany(
                'INSERT INTO meta(key,value) VALUES(?,?) '
                'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                ((key, json.dumps(value, ensure_ascii=False, separators=(",", ":")))
                 for key, value in meta.items()))
        for table_name in self._dirty:
            self._dirty[table_name].difference_update(dirty_snapshot[table_name])
            self._deleted[table_name].difference_update(deleted_snapshot[table_name])

    def close(self):
        try:
            self.save()
        finally:
            if self._db is not None:
                try:
                    self._db.close()
                finally:
                    self._db = None

class ValueAI:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.storage = None
        self.data_dir = None
        self.runtime_dir = None
        self.runtime_version = ""
        self.hardware = None
        self.reader = None
        self.capture = None
        self.cv2 = None
        self.np = None
        self.ImageTk = None
        self.window_roi = None
        self.target_hwnd = 0
        self.target_pid = 0
        self.target_identity = None
        self._target_lost_since = None
        self._target_read_failures = 0
        self._target_anchor = {}
        self._operation_rect_cache = None
        self._operation_scope_signature = ""
        self._operation_scope_reason = "target"
        self._operation_scope_key = ""
        self._window_seen = {}
        self._temporal_windows = {}
        self._last_action_at = 0.0
        self._active_learner = None
        self._controls = {}
        self._control_graph_hash = "c00000000"
        self._dynamic_key_actions = set()
        self._key_action_gates = {}
        self._last_decision_state = ""
        self._number_auto_history = {}
        self._runtime_progress_value = 0
        self._runtime_started_at = 0.0
        self._runtime_last_activity_at = 0.0
        self._runtime_last_progress = None
        self._runtime_process = None
        self._runtime_process_lock = threading.RLock()
        self._runtime_worker = None
        self._runtime_tune_thread = None
        self._runtime_ready = False
        self._last_isolation_scene = None
        self._log_once_keys = set()
        self._selection_snapshot = None
        self._selection_screen = None
        self._selection_overlay = None
        self._selection_scan_cancel = None
        self._selection_scan_id = 0
        self._key_probe_misses = {}
        self._visual_noise_stats = {"n": 0.0, "mean": 0.0, "m2": 0.0}
        self.stop_event = EmergencyStop()
        self.hook = None
        self.worker = None
        self._close_requested = False
        self.last_summary = ""
        self._visual_cache = "v0"
        self._semantic_scene = "h00000000"
        self._semantic_tokens = ()
        self._semantic_features = {}
        self._scene_revision = 0
        self.target_entity = None
        self.scene_numbers = {}
        self._scene_number_entities = []
        self._number_tracks = {}
        self._number_attribute_activity = {}
        self._number_auto_history = {}
        self._number_visual_refresh_step = 0
        self._number_fast_read_at = {}
        self._number_fast_read_cursor = 0
        self._number_fast_read_misses = {}
        self._number_change_flags = {}
        self._number_structure_hash = "n00000000"
        self._last_semantic_scan_at = 0.0
        self._last_semantic_scan_step = -999999
        self._danger_regions = []
        self._recognized_actions = set()
        self._last_control_count = 0
        self._last_danger_count = 0
        self._environment_cache = None
        self._environment_cache_at = 0.0
        self._last_decision_family = ""
        self._state_velocity = 0.0
        self._state_acceleration = 0.0
        self._motion_mask = 0
        self._source_health = {
            "target": {"valid": False, "confidence": 0.0, "failure_reason": "not_read",
                       "observation_state": "missing", "updated_at": 0.0},
            "scene_ocr": {"valid": True, "confidence": 0.5, "failure_reason": "",
                          "observation_state": "observed", "updated_at": 0.0},
            "capture": {"valid": True, "confidence": 0.5, "failure_reason": "",
                         "observation_state": "observed", "updated_at": 0.0},
            "visual_features": {"valid": False, "confidence": 0.0, "failure_reason": "not_sampled",
                                "observation_state": "not_sampled", "updated_at": 0.0},
            "target_relocalization": {"valid": False, "confidence": 0.0, "failure_reason": "not_sampled",
                                      "observation_state": "not_sampled", "updated_at": 0.0},
        }
        self._pending_scene_drop = None
        self._state_quantiles = {}
        self._candidate_scan_index = 0
        self.action_priors = dict(KEY_ACTION_PRIORS)
        self._build_ui()
        self.root.after(80, self._choose_storage)
        self.root.after(100, self._poll)

    def _build_ui(self):
        self.root.title(APP_NAME)
        self.root.geometry("820x620")
        self.root.minsize(520, 420)
        self.root.resizable(True, True)
        self.root.configure(bg="#f3f6fb")
        self.root.protocol("WM_DELETE_WINDOW", self._close)

        style = ttk.Style(self.root)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass
        style.configure("ValueAI.Horizontal.TProgressbar", thickness=14)
        style.configure("ValueAI.TButton", font=("Microsoft YaHei UI", 11, "bold"), padding=(18, 11))

        header = tk.Frame(self.root, bg="#172033")
        header.pack(fill="x")
        tk.Label(header, text=APP_NAME, bg="#172033", fg="#ffffff",
                 font=("Microsoft YaHei UI", 23, "bold")).pack(
                     anchor="w", padx=34, pady=(20, 2))
        self.header_subtitle = tk.Label(
            header, text="选择一个屏幕数值，让 AI 自主发现能让它增长的操作",
            bg="#172033", fg="#b9c5d8", font=("Microsoft YaHei UI", 10),
            justify="left")
        self.header_subtitle.pack(anchor="w", fill="x", padx=35, pady=(0, 19))

        scroll_host = tk.Frame(self.root, bg="#f3f6fb")
        scroll_host.pack(fill="both", expand=True)
        self.content_canvas = tk.Canvas(
            scroll_host, bg="#f3f6fb", highlightthickness=0, borderwidth=0)
        self.content_scrollbar = ttk.Scrollbar(
            scroll_host, orient="vertical", command=self.content_canvas.yview)
        self.content_canvas.configure(yscrollcommand=self.content_scrollbar.set)
        self.content_scrollbar.pack(side="right", fill="y")
        self.content_canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(self.content_canvas, bg="#f3f6fb")
        self.content_body = body
        self._content_window = self.content_canvas.create_window(
            (0, 0), window=body, anchor="nw")
        body.bind("<Configure>", self._on_body_configure)
        self.content_canvas.bind("<Configure>", self._on_canvas_configure)
        self.content_canvas.bind("<MouseWheel>", self._on_content_mousewheel)

        setup_card = tk.Frame(body, bg="#ffffff", highlightthickness=1, highlightbackground="#dde3ed")
        setup_card.pack(fill="x", padx=30, pady=(22, 0))
        setup_inner = tk.Frame(setup_card, bg="#ffffff")
        setup_inner.pack(fill="x", padx=22, pady=18)
        tk.Label(setup_inner, text="运行环境", bg="#ffffff", fg="#1c2738",
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w")
        tk.Label(setup_inner, text="数据位置", bg="#ffffff", fg="#7b8797",
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(10, 3))
        self.path_var = tk.StringVar(value="等待选择 D 盘文件夹")
        self.path_entry = ttk.Entry(setup_inner, textvariable=self.path_var, state="readonly")
        self.path_entry.pack(fill="x")
        self.hardware_var = tk.StringVar(value="尚未检测本机配置")
        self.hardware_label = tk.Label(
            setup_inner, textvariable=self.hardware_var, bg="#ffffff", fg="#647185",
            font=("Microsoft YaHei UI", 9), justify="left")
        self.hardware_label.pack(anchor="w", fill="x", pady=(6, 12))

        progress_head = tk.Frame(setup_inner, bg="#ffffff")
        progress_head.pack(fill="x")
        self.progress_stage_var = tk.StringVar(value="等待开始")
        self.progress_percent_var = tk.StringVar(value="0%")
        tk.Label(progress_head, textvariable=self.progress_stage_var, bg="#ffffff", fg="#445168",
                 font=("Microsoft YaHei UI", 9)).pack(side="left")
        tk.Label(progress_head, textvariable=self.progress_percent_var, bg="#ffffff", fg="#19725a",
                 font=("Microsoft YaHei UI", 10, "bold")).pack(side="right")
        self.progress_var = tk.DoubleVar(value=0.0)
        self.progress = ttk.Progressbar(setup_inner, mode="determinate", maximum=100,
                                        variable=self.progress_var,
                                        style="ValueAI.Horizontal.TProgressbar")
        self.progress.pack(fill="x", pady=(7, 0))
        self.progress_detail_var = tk.StringVar(value="")
        self.progress_detail_label = tk.Label(
            setup_inner, textvariable=self.progress_detail_var, bg="#ffffff",
            fg="#3f4d61", font=("Microsoft YaHei UI", 9, "bold"), justify="left")
        self.progress_detail_label.pack(anchor="w", fill="x", pady=(8, 0))
        self.file_progress_var = tk.DoubleVar(value=0.0)
        self.file_progress = ttk.Progressbar(
            setup_inner, mode="determinate", maximum=100,
            variable=self.file_progress_var,
            style="ValueAI.Horizontal.TProgressbar")
        self.progress_transfer_var = tk.StringVar(value="")
        self.progress_transfer_label = tk.Label(
            setup_inner, textvariable=self.progress_transfer_var, bg="#ffffff",
            fg="#647185", font=("Microsoft YaHei UI", 9), justify="left")
        self.progress_transfer_label.pack(anchor="w", fill="x", pady=(4, 0))
        self.progress_elapsed_var = tk.StringVar(value="已用时 00:00")
        tk.Label(setup_inner, textvariable=self.progress_elapsed_var,
                 bg="#ffffff", fg="#7b8797",
                 font=("Microsoft YaHei UI", 8)).pack(anchor="w", pady=(3, 0))

        action_card = tk.Frame(body, bg="#ffffff", highlightthickness=1, highlightbackground="#dde3ed")
        action_card.pack(fill="x", padx=30, pady=(16, 0))
        action_inner = tk.Frame(action_card, bg="#ffffff")
        action_inner.pack(fill="x", padx=22, pady=17)
        self.selection_var = tk.StringVar(value="尚未选择数值")
        tk.Label(action_inner, textvariable=self.selection_var, bg="#ffffff", fg="#1c2738",
                 font=("Microsoft YaHei UI", 12, "bold")).pack(anchor="w")
        self.status_var = tk.StringVar(value="准备运行环境后即可选择屏幕数值")
        self.status_label = tk.Label(
            action_inner, textvariable=self.status_var, bg="#ffffff", fg="#687589",
            font=("Microsoft YaHei UI", 9), justify="left")
        self.status_label.pack(anchor="w", fill="x", pady=(5, 14))
        self.button_row = tk.Frame(action_inner, bg="#ffffff")
        self.button_row.pack(fill="x")
        self.button_row.columnconfigure(0, weight=1)
        self.button_row.columnconfigure(1, weight=1)
        self.value_button = ttk.Button(self.button_row, text="数值", state="disabled",
                                       command=self._select_value, style="ValueAI.TButton")
        self.confirm_button = ttk.Button(self.button_row, text="确认", state="disabled",
                                         command=self._start, style="ValueAI.TButton")
        self.value_button.grid(row=0, column=0, sticky="ew", padx=(0, 7))
        self.confirm_button.grid(row=0, column=1, sticky="ew", padx=(7, 0))
        self._buttons_stacked = False

        self.help_label = tk.Label(
            body,
            text=("按 ESC 可立即停止 AI。目标窗口拥有较高探索优先级；整个虚拟桌面仍会以低预算、"
                  "粗粒度方式感知并进行少量安全探索。"),
            bg="#f3f6fb", fg="#7a4a21", font=("Microsoft YaHei UI", 9),
            justify="left")
        self.help_label.pack(anchor="w", fill="x", padx=32, pady=(15, 24))

    def _on_body_configure(self, _event=None):
        try:
            self.content_canvas.configure(scrollregion=self.content_canvas.bbox("all"))
        except tk.TclError:
            pass

    def _on_canvas_configure(self, event):
        try:
            self.content_canvas.itemconfigure(self._content_window, width=max(1, event.width))
            self._on_content_resize(event.width)
        except tk.TclError:
            pass

    def _on_content_mousewheel(self, event):
        try:
            self.content_canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
        except tk.TclError:
            pass

    def _on_content_resize(self, width):
        wrap = max(250, int(width) - 112)
        for label in (self.header_subtitle, self.hardware_label, self.progress_detail_label,
                      self.progress_transfer_label, self.status_label, self.help_label):
            label.configure(wraplength=wrap)
        stacked = int(width) < 600
        if stacked == self._buttons_stacked:
            return
        self._buttons_stacked = stacked
        self.value_button.grid_forget()
        self.confirm_button.grid_forget()
        if stacked:
            self.value_button.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 7))
            self.confirm_button.grid(row=1, column=0, columnspan=2, sticky="ew")
        else:
            self.value_button.grid(row=0, column=0, sticky="ew", padx=(0, 7))
            self.confirm_button.grid(row=0, column=1, sticky="ew", padx=(7, 0))

    @staticmethod
    def _format_bytes(value):
        try:
            value = max(0.0, float(value))
        except (TypeError, ValueError, OverflowError):
            return ""
        units = ("B", "KB", "MB", "GB")
        index = 0
        while value >= 1000.0 and index < len(units) - 1:
            value /= 1000.0
            index += 1
        return f"{value:.1f} {units[index]}" if index else f"{value:.0f} {units[index]}"

    @staticmethod
    def _format_elapsed(seconds):
        seconds = max(0, int(float(seconds or 0.0)))
        hours, remainder = divmod(seconds, 3600)
        minutes, secs = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}" if hours else f"{minutes:02d}:{secs:02d}"

    def _hardware_brief(self):
        if self.hardware is None:
            return "尚未检测本机配置"
        gpu = str(self.hardware.gpu_names[0]) if self.hardware.gpu_names else "CPU"
        if len(gpu) > 46:
            gpu = gpu[:43] + "…"
        return (f"本机：{self.hardware.physical_cores}核{self.hardware.logical_cpus}线程 · "
                f"{_fmt_gib(self.hardware.ram)} · {gpu}")

    def _runtime_progress(self, percent, title, detail="", current_bytes=None,
                          total_bytes=None, bytes_per_second=None, attempt=1,
                          indeterminate=False, stage="runtime"):
        now = time.monotonic()
        if not self._runtime_started_at:
            self._runtime_started_at = now
        overall = None if percent is None else max(0.0, min(100.0, float(percent)))
        progress = RuntimeProgress(
            stage=str(stage), overall=overall, title=str(title), detail=str(detail or ""),
            current_bytes=(None if current_bytes is None else max(0, int(current_bytes))),
            total_bytes=(None if total_bytes is None else max(0, int(total_bytes))),
            bytes_per_second=(None if bytes_per_second is None else max(0.0, float(bytes_per_second))),
            elapsed=max(0.0, now - self._runtime_started_at), attempt=max(1, int(attempt)),
            indeterminate=bool(indeterminate))
        self._runtime_last_activity_at = now
        self.events.put(("runtime_progress", progress))

    def _apply_runtime_progress(self, progress):
        if not isinstance(progress, RuntimeProgress):
            return
        self._runtime_last_progress = progress
        if progress.overall is not None:
            self._runtime_progress_value = max(
                float(self._runtime_progress_value), float(progress.overall))
            self.progress_var.set(self._runtime_progress_value)
            self.progress_percent_var.set(f"{self._runtime_progress_value:.0f}%")
        else:
            self.progress_percent_var.set("")
        self.progress_stage_var.set(progress.title)
        self.progress_detail_var.set(progress.detail)
        self.progress_elapsed_var.set(f"已用时 {self._format_elapsed(progress.elapsed)}")

        transfer_parts = []
        if progress.current_bytes is not None:
            current_text = self._format_bytes(progress.current_bytes)
            if progress.total_bytes:
                transfer_parts.append(
                    f"{current_text} / {self._format_bytes(progress.total_bytes)}")
                file_percent = 100.0 * progress.current_bytes / max(1, progress.total_bytes)
                self.file_progress.stop()
                self.file_progress.configure(mode="determinate")
                self.file_progress_var.set(max(0.0, min(100.0, file_percent)))
            else:
                transfer_parts.append(f"已下载 {current_text}")
                self.file_progress.configure(mode="indeterminate")
                self.file_progress.start(14)
            if not self.file_progress.winfo_manager():
                self.file_progress.pack(fill="x", pady=(7, 0), before=self.progress_transfer_label)
        else:
            self.file_progress.stop()
            if self.file_progress.winfo_manager():
                self.file_progress.pack_forget()
        if progress.bytes_per_second:
            transfer_parts.append(f"{self._format_bytes(progress.bytes_per_second)}/s")
        self._runtime_transfer_base = " · ".join(transfer_parts)
        self.progress_transfer_var.set(self._runtime_transfer_base)

    def _update_runtime_heartbeat(self):
        if self._runtime_ready or not self._runtime_started_at:
            return
        now = time.monotonic()
        elapsed = now - self._runtime_started_at
        self.progress_elapsed_var.set(f"已用时 {self._format_elapsed(elapsed)}")
        silence = now - float(self._runtime_last_activity_at or self._runtime_started_at)
        if silence < RUNTIME_CONFIG.stalled_notice_seconds:
            return
        process_alive = False
        with self._runtime_process_lock:
            process_alive = bool(self._runtime_process and self._runtime_process.poll() is None)
        if process_alive:
            notice = ("正在解压或写入组件，进度可能暂时不变" if silence < 30.0 else
                      "网络或系统响应较慢，安装程序仍在运行")
        else:
            notice = "正在等待当前步骤完成，程序仍在运行"
        base = getattr(self, "_runtime_transfer_base", "")
        self.progress_transfer_var.set(" · ".join(part for part in (base, notice) if part))

    def _terminate_runtime_process(self):
        with self._runtime_process_lock:
            process = self._runtime_process
        if process is None or process.poll() is not None:
            return
        try:
            process.terminate()
            process.wait(timeout=2.0)
        except (OSError, subprocess.TimeoutExpired):
            try:
                process.kill()
                process.wait(timeout=1.0)
            except (OSError, subprocess.TimeoutExpired):
                pass
        finally:
            with self._runtime_process_lock:
                if self._runtime_process is process and process.poll() is not None:
                    self._runtime_process = None

    def _choose_storage(self):
        dialog = DFolderDialog(self.root)
        self.root.wait_window(dialog)
        if not dialog.result:
            self.root.destroy()
            return
        self.storage = dialog.result
        try:
            self.data_dir = self.storage / DATA_DIR_NAME
            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.hardware = HardwareProfile(self.data_dir)
            arch = re.sub(r"[^a-z0-9_-]", "", self.hardware.architecture) or "64bit"
            version = f"py{sys.version_info.major}{sys.version_info.minor}-{arch}"
            self.runtime_version = f"{version}-{RUNTIME_FINGERPRINT}"
            self.runtime_dir = self.data_dir / f"runtime-{version}-{RUNTIME_FINGERPRINT}"
            for path in (self.data_dir / "缓存",
                         self.data_dir / "临时文件", self.data_dir / "日志"):
                path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法在所选文件夹写入数据：\n{exc}", parent=self.root)
            self.root.destroy()
            return
        self.path_var.set(str(self.data_dir))
        self.hardware_var.set(self._hardware_brief())
        self.status_var.set("首次运行会自动准备视觉识别组件；进度会显示在上方。")
        self._runtime_started_at = time.monotonic()
        self._runtime_last_activity_at = self._runtime_started_at
        self._runtime_progress_value = 2
        self.progress_var.set(2)
        self.progress_percent_var.set("2%")
        self.progress_stage_var.set("正在初始化运行目录")
        self._runtime_worker = threading.Thread(
            target=self._prepare_runtime, name="runtime-prepare", daemon=True)
        self._runtime_worker.start()

    def _prepare_runtime(self):
        cache = self.data_dir / "缓存"
        temp = self.data_dir / "临时文件"
        marker = self.runtime_dir / f".ready-runtime-{RUNTIME_FINGERPRINT}"
        runtime_mutex = None
        runtime_imports_ready = False
        try:
            self._runtime_progress(5, "正在检查运行环境")
            runtime_mutex = _acquire_runtime_mutex(
                self.data_dir, stop_event=self.stop_event,
                wait_callback=lambda waited: self._runtime_progress(
                    5, "另一个程序实例正在准备视觉识别组件",
                    detail=f"已等待 {waited} 秒", stage="runtime_mutex"))
            env = os.environ.copy()
            directed = {
                "PIP_CACHE_DIR": cache / "pip", "TMP": temp, "TEMP": temp,
                "XDG_CACHE_HOME": cache, "HF_HOME": cache / "huggingface",
                "RAPIDOCR_HOME": cache / "rapidocr",
                "MPLCONFIGDIR": cache / "matplotlib", "NUMBA_CACHE_DIR": cache / "numba",
                "PYTHONPYCACHEPREFIX": cache / "pycache",
            }
            for key, value in directed.items():
                Path(value).mkdir(parents=True, exist_ok=True)
                env[key] = str(value)
                os.environ[key] = str(value)
            model_root = cache / "rapidocr_models"
            model_root.mkdir(parents=True, exist_ok=True)
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            env["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)
            env["OMP_WAIT_POLICY"] = "PASSIVE"
            env["ORT_LOG_SEVERITY_LEVEL"] = "3"
            sys.pycache_prefix = str(cache / "pycache")
            if str(self.runtime_dir) not in sys.path:
                sys.path.insert(0, str(self.runtime_dir))

            self._runtime_progress(10, "正在准备依赖与缓存")
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            lock_file = temp / f"runtime-lock-{RUNTIME_FINGERPRINT}.txt"
            lock_file.write_text("\n".join(RUNTIME_LOCK) + "\n", encoding="utf-8")

            def runtime_marker(runtime_path):
                return runtime_path / f".ready-runtime-{RUNTIME_FINGERPRINT}"

            def runtime_probe(runtime_path):
                imports = "import rapidocr,onnxruntime,cv2,PIL,mss,numpy"
                probe_code = "import sys;sys.path.insert(0," + repr(str(runtime_path)) + ");" + imports
                probe_env = env.copy()
                probe_env["PYTHONNOUSERSITE"] = "1"
                run = subprocess.run(
                    [sys.executable, "-S", "-c", probe_code], env=probe_env,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=RUNTIME_CONFIG.runtime_import_probe_timeout_seconds,
                    creationflags=creationflags)
                return run.returncode == 0

            def install_into(target_dir, packages, no_deps=False):
                target_dir.mkdir(parents=True, exist_ok=True)
                command = [sys.executable, "-m", "pip", "install",
                           "--prefer-binary", "--disable-pip-version-check",
                           "--no-warn-script-location", "--progress-bar=raw",
                           "--constraint", str(lock_file),
                           "--target", str(target_dir)]
                if no_deps:
                    command.append("--no-deps")
                if self.hardware.disk_free < 5 * GIB:
                    command.append("--no-cache-dir")
                command += list(packages)
                last_output = ""
                for attempt in range(2):
                    self._runtime_progress(
                        18 + attempt * 2, "正在解析视觉识别组件",
                        detail=f"安装尝试 {attempt + 1}/2", attempt=attempt + 1,
                        indeterminate=True, stage="pip_resolve")
                    process = subprocess.Popen(
                        command, env=env, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, bufsize=0,
                        creationflags=creationflags)
                    with self._runtime_process_lock:
                        self._runtime_process = process
                    line_queue = queue.Queue()
                    reader_done = threading.Event()

                    def read_output():
                        pending = b""
                        try:
                            while True:
                                chunk = process.stdout.read(4096) if process.stdout else b""
                                if not chunk:
                                    break
                                pending += chunk
                                parts = re.split(br"[\r\n]+", pending)
                                pending = parts.pop() if parts else b""
                                for part in parts:
                                    if part:
                                        line_queue.put(part.decode("utf-8", "replace"))
                            if pending:
                                line_queue.put(pending.decode("utf-8", "replace"))
                        finally:
                            reader_done.set()

                    threading.Thread(
                        target=read_output, name="pip-output", daemon=True).start()
                    attempt_started = time.monotonic()
                    transfer_started = attempt_started
                    transfer_start_bytes = 0
                    last_bytes = 0
                    current_file = ""
                    output_tail = []
                    timed_out = False
                    while process.poll() is None or not reader_done.is_set() or not line_queue.empty():
                        if self.stop_event.is_set():
                            self._terminate_runtime_process()
                            raise InterruptedError("运行时准备已取消")
                        if time.monotonic() - attempt_started > RUNTIME_CONFIG.pip_timeout_seconds:
                            timed_out = True
                            self._terminate_runtime_process()
                        try:
                            line = line_queue.get(timeout=0.20)
                        except queue.Empty:
                            if timed_out and process.poll() is not None:
                                break
                            continue
                        line = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", str(line)).strip()
                        if not line:
                            continue
                        output_tail.append(line)
                        output_tail = output_tail[-60:]
                        self._runtime_last_activity_at = time.monotonic()
                        download_match = re.search(r"(?:Downloading|Using cached)\s+(\S+)", line)
                        if download_match:
                            raw_name = download_match.group(1).split("?", 1)[0].rstrip("/")
                            current_file = raw_name.rsplit("/", 1)[-1][:96]
                            transfer_started = time.monotonic()
                            transfer_start_bytes = 0
                            last_bytes = 0
                            self._runtime_progress(
                                24 + attempt * 2, "正在下载视觉识别组件",
                                detail=current_file, attempt=attempt + 1,
                                indeterminate=True, stage="pip_download")
                        progress_match = re.search(r"Progress\s+(\d+)\s+of\s+(\d+)", line)
                        if progress_match:
                            current = int(progress_match.group(1))
                            total = int(progress_match.group(2))
                            if current < last_bytes:
                                transfer_started = time.monotonic()
                                transfer_start_bytes = 0
                            last_bytes = current
                            duration = max(0.001, time.monotonic() - transfer_started)
                            speed = max(0.0, current - transfer_start_bytes) / duration
                            self._runtime_progress(
                                24 + attempt * 2, "正在下载视觉识别组件",
                                detail=current_file or "当前组件", current_bytes=current,
                                total_bytes=total, bytes_per_second=speed,
                                attempt=attempt + 1, indeterminate=(total <= 0),
                                stage="pip_download")
                        elif "Installing collected packages" in line:
                            detail = line.split(":", 1)[-1].strip()[:120]
                            self._runtime_progress(
                                33 + attempt, "正在解压并写入组件",
                                detail=detail, attempt=attempt + 1,
                                indeterminate=True, stage="pip_install")
                        elif "Retrying" in line or "retry" in line.lower():
                            self._runtime_progress(
                                22 + attempt * 2, "下载连接中断，正在自动重试",
                                detail=line[:140], attempt=attempt + 1,
                                indeterminate=True, stage="pip_retry")
                    try:
                        return_code = process.wait(timeout=2.0)
                    except subprocess.TimeoutExpired:
                        self._terminate_runtime_process()
                        return_code = process.poll()
                    try:
                        if process.stdout is not None:
                            process.stdout.close()
                    except OSError:
                        pass
                    with self._runtime_process_lock:
                        if self._runtime_process is process:
                            self._runtime_process = None
                    last_output = "\n".join(output_tail)
                    if return_code == 0 and not timed_out:
                        self._runtime_progress(
                            36, "正在验证已安装组件", stage="pip_complete")
                        return
                    if timed_out:
                        self._log_runtime(
                            "pip_install_timeout",
                            f"attempt={attempt + 1} timeout={RUNTIME_CONFIG.pip_timeout_seconds}s")
                    if attempt == 0:
                        retry_until = time.monotonic() + 0.8
                        while time.monotonic() < retry_until and not self.stop_event.is_set():
                            time.sleep(0.05)
                tail = "\n".join(last_output.splitlines()[-18:])
                raise RuntimeError(tail or f"pip 安装失败或超过 {RUNTIME_CONFIG.pip_timeout_seconds} 秒")

            def atomic_build(packages, target_path=None):
                target_path = Path(target_path or self.runtime_dir)
                temp_path = target_path.with_name(target_path.name + "-temp")
                backup_path = target_path.with_name(target_path.name + "-previous")
                shutil.rmtree(temp_path, ignore_errors=True)
                shutil.rmtree(backup_path, ignore_errors=True)
                try:
                    install_into(temp_path, packages)
                    self._runtime_progress(38, "正在验证新安装的组件")
                    # Atomic dependency validation performs imports only.  The one
                    # real OCR smoke test below uses the formal model/configuration
                    # and the same engine that continues into normal operation.
                    if not runtime_probe(temp_path):
                        raise RuntimeError("运行时导入自检失败")
                    runtime_marker(temp_path).write_text("ok", encoding="ascii")
                    if target_path.exists():
                        os.replace(str(target_path), str(backup_path))
                    try:
                        os.replace(str(temp_path), str(target_path))
                    except Exception:
                        if backup_path.exists() and not target_path.exists():
                            os.replace(str(backup_path), str(target_path))
                        raise
                    shutil.rmtree(backup_path, ignore_errors=True)
                    return target_path
                except Exception:
                    shutil.rmtree(temp_path, ignore_errors=True)
                    raise

            marker = runtime_marker(self.runtime_dir)
            if marker.exists():
                required = ("rapidocr", "onnxruntime", "cv2", "PIL", "mss")
                healthy = all((self.runtime_dir / name).exists() for name in required)
                if healthy:
                    try:
                        healthy = runtime_probe(self.runtime_dir)
                    except Exception:
                        healthy = False
                if not healthy:
                    marker.unlink(missing_ok=True)

            if not marker.exists():
                backend_pkg = ONNXRUNTIME_DML_SPEC if self.hardware.want_dml else ONNXRUNTIME_CPU_SPEC
                try:
                    atomic_build([f"rapidocr=={RAPIDOCR_VERSION}", backend_pkg, MSS_SPEC, COMTYPES_SPEC, DXCAM_SPEC])
                except Exception:
                    if not self.hardware.want_dml:
                        raise
                    self.hardware.want_dml = False
                    self.hardware.backend = "cpu"
                    self.hardware.dml_tested_at = time.time()
                    self.runtime_dir = self.data_dir / (
                        f"runtime-{self.runtime_version}-{self.hardware.tag}")
                    marker = runtime_marker(self.runtime_dir)
                    if not marker.exists() or not runtime_probe(self.runtime_dir):
                        atomic_build([f"rapidocr=={RAPIDOCR_VERSION}", ONNXRUNTIME_CPU_SPEC, MSS_SPEC, COMTYPES_SPEC, DXCAM_SPEC],
                                     target_path=self.runtime_dir)

            if str(self.runtime_dir) not in sys.path:
                sys.path.insert(0, str(self.runtime_dir))
            importlib.invalidate_caches()
            try:
                import onnxruntime as ort
            except Exception:
                if not self.hardware.want_dml:
                    raise

                for module_name in tuple(sys.modules):
                    if module_name == "onnxruntime" or module_name.startswith("onnxruntime."):
                        sys.modules.pop(module_name, None)
                self.hardware.want_dml = False
                self.hardware.backend = "cpu"
                self.hardware.dml_tested_at = time.time()
                old_runtime = self.runtime_dir
                self.runtime_dir = self.data_dir / (
                    f"runtime-{self.runtime_version}-{self.hardware.tag}")
                marker = runtime_marker(self.runtime_dir)
                if not marker.exists() or not runtime_probe(self.runtime_dir):
                    atomic_build([f"rapidocr=={RAPIDOCR_VERSION}", ONNXRUNTIME_CPU_SPEC, MSS_SPEC, COMTYPES_SPEC, DXCAM_SPEC],
                                 target_path=self.runtime_dir)
                while str(old_runtime) in sys.path:
                    sys.path.remove(str(old_runtime))
                if str(self.runtime_dir) not in sys.path:
                    sys.path.insert(0, str(self.runtime_dir))
                importlib.invalidate_caches()
                import onnxruntime as ort
            self._runtime_progress(50, "正在加载图像处理组件")
            from PIL import Image, ImageGrab, ImageOps, ImageTk
            import cv2
            import numpy as np
            try:
                cv_threads = (1 if self.hardware.tier == "low" else
                              min(4, max(1, self.hardware.physical_cores // 2)))
                cv2.setUseOptimized(True)
                cv2.setNumThreads(cv_threads)
            except Exception as exc:
                self._log_once("opencv_tuning", "opencv_tuning_error", type(exc).__name__)
            try:
                import mss
            except Exception:
                mss = None
            dxcam = None
            if self.hardware.dxcam_eligible and self.hardware.tier != "low":
                try:
                    import dxcam as _dxcam
                    dxcam = _dxcam
                except Exception:
                    dxcam = None
            self._runtime_progress(58, "正在加载文字识别模型")
            from rapidocr import (EngineType, LangDet, LangRec, ModelType,
                                  OCRVersion, RapidOCR)
            runtime_imports_ready = True

            model_map = {"tiny": ModelType.TINY, "small": ModelType.SMALL,
                         "medium": ModelType.MEDIUM}
            rec_model = model_map.get(self.hardware.rec_model, ModelType.SMALL)
            det_model = model_map.get(self.hardware.det_model, ModelType.SMALL)

            def make_params(use_dml=False, version=OCRVersion.PPOCRV6,
                            rec_size=None, det_size=None, threads=None,
                            rec_lang=None, det_lang=None):
                thread_count = max(1, int(threads or self.hardware.ocr_threads))
                return {
                    "Global.text_score": 0.14,
                    "Global.use_preprocess_img": True,
                    "Global.use_vertical_padding": True,
                    "Global.min_height": 26,
                    "Global.width_height_ratio": 18,
                    "Global.min_side_len": 26,
                    "Global.max_side_len": 2200,
                    "Global.model_root_dir": str(model_root),
                    "Det.engine_type": EngineType.ONNXRUNTIME,
                    "Det.lang_type": det_lang or LangDet.CH,
                    "Det.model_type": det_size or det_model,
                    "Det.ocr_version": version,
                    "Rec.engine_type": EngineType.ONNXRUNTIME,
                    "Rec.lang_type": rec_lang or LangRec.CH,
                    "Rec.model_type": rec_size or rec_model,
                    "Rec.ocr_version": version,
                    "EngineConfig.onnxruntime.intra_op_num_threads": thread_count,
                    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                    "EngineConfig.onnxruntime.enable_cpu_mem_arena": self.hardware.ram >= 8 * GIB,
                    "EngineConfig.onnxruntime.use_dml": bool(use_dml),
                }

            probe = np.full((82, 320, 3), 248, dtype="uint8")
            cv2.putText(probe, "98765.4", (8, 58), cv2.FONT_HERSHEY_SIMPLEX,
                        1.35, (18, 18, 18), 2, cv2.LINE_AA)

            def build_baseline(use_dml):
                # This is the only startup OCR smoke test.  It uses the formal model
                # root/configuration and returns the same engine used by the app.
                engine = RapidOCR(params=make_params(
                    use_dml=use_dml, threads=self.hardware.ocr_threads))
                started = time.perf_counter()
                result = engine(probe, use_det=False, use_cls=False, use_rec=True)
                elapsed = max(0.001, time.perf_counter() - started)
                texts = (result.get("txts") if isinstance(result, dict) else
                         getattr(result, "txts", None))
                if texts is None:
                    raise RuntimeError("主 OCR 模型自检未返回文字")
                joined = "".join(str(x[0] if isinstance(x, (tuple, list)) and x else x)
                                 for x in list(texts))
                if parse_score(joined) is None:
                    raise RuntimeError("主 OCR 模型自检未识别数值")
                return engine, elapsed

            # Start with one conservative model.  Live measurements during normal
            # use tune sampling/latency; extra model families are never a startup
            # prerequisite and are not downloaded speculatively.
            if not self.hardware.cached_rec_model:
                self.hardware.rec_model = "tiny" if self.hardware.ram < 6 * GIB else "small"
                rec_model = model_map[self.hardware.rec_model]
            self._runtime_progress(
                66, "正在下载或加载主 OCR 模型",
                detail=f"PP-OCRv6 {self.hardware.rec_model}",
                indeterminate=True, stage="ocr_model")
            available = set(ort.get_available_providers())
            dml_possible = self.hardware.want_dml and "DmlExecutionProvider" in available
            primary = None
            chosen_ocr_time = 0.0
            if dml_possible:
                try:
                    primary, chosen_ocr_time = build_baseline(True)
                    self.hardware.backend = "dml"
                except Exception as exc:
                    self._log_once("dml_probe", "dml_probe_error", type(exc).__name__)
            if primary is None:
                primary, chosen_ocr_time = build_baseline(False)
                self.hardware.backend = "cpu"
            self.hardware.dml_tested_at = time.time()
            self.hardware.model_tested_at = time.time()
            engines = [("ocrv6-primary", primary, 1.0)]

            self._runtime_progress(88, "正在验证屏幕捕获", stage="capture_baseline")
            self.capture = ScreenCapture(
                mss, ImageGrab, Image, dxcam_module=dxcam,
                preferred=self.hardware.preferred_capture)
            try:
                screen = virtual_screen_rect()
                if not screen:
                    raise RuntimeError("无法读取虚拟桌面范围")
                width = min(320, max(8, screen[2] - screen[0]))
                height = min(200, max(8, screen[3] - screen[1]))
                check_rect = (screen[0], screen[1], screen[0] + width, screen[1] + height)
                image = self.capture.grab(check_rect)
                if image.width <= 0 or image.height <= 0:
                    raise RuntimeError("屏幕捕获返回空图像")
            except Exception as exc:
                self.capture.close()
                self.capture = None
                raise RuntimeError(f"屏幕捕获自检失败：{type(exc).__name__}") from exc
            self.hardware.capture_backend = self.capture.backend
            self.hardware.calibrate_runtime(chosen_ocr_time, self.capture.latency)
            self.cv2, self.np, self.ImageTk = cv2, np, ImageTk
            self.reader = ScoreReader(engines, self.capture, ImageOps, Image, np, cv2,
                                      max_variants=self.hardware.ocr_variants,
                                      hardware=self.hardware)
            marker.write_text("ok", encoding="ascii")
            self._runtime_progress(99, "正在完成启动检查")
            self.events.put(("runtime_ready", self.hardware.summary()))
        except InterruptedError:
            self._log_runtime("runtime_prepare_cancelled", "user_close")
        except Exception as exc:
            self._log_exception("runtime_prepare_error", exc)
            if not runtime_imports_ready:
                try:
                    marker.unlink(missing_ok=True)
                except OSError as cleanup_exc:
                    self._log_runtime("runtime_marker_cleanup_error", type(cleanup_exc).__name__)
            self.events.put(("error", "视觉识别组件准备失败", str(exc)))
        finally:
            _release_runtime_mutex(runtime_mutex)

    def _start_background_tuning(self):
        if self._runtime_tune_thread and self._runtime_tune_thread.is_alive():
            return
        self._runtime_tune_thread = threading.Thread(
            target=self._background_runtime_tune,
            name="runtime-background-tune", daemon=True)
        self._runtime_tune_thread.start()

    def _background_runtime_tune(self):
        """Improve capture choice after the app is already usable."""
        deadline = time.monotonic() + 1.5
        while time.monotonic() < deadline and not self.stop_event.is_set():
            time.sleep(0.05)
        if (self.stop_event.is_set() or self.capture is None or
                self._selection_scan_cancel is not None or
                (self.worker is not None and self.worker.is_alive())):
            return
        try:
            self.capture.benchmark()
            self.hardware.capture_backend = self.capture.backend
            self.hardware.save_tuning(force=True)
            self.events.put(("runtime_tuned", self.capture.backend.upper()))
        except Exception as exc:
            self._log_runtime("background_capture_tune_error", type(exc).__name__)

    def _select_value(self):
        if not self.reader or not self.capture or not self.ImageTk:
            return
        if self._selection_scan_cancel is not None:
            self._selection_scan_cancel.set()
        self._selection_scan_cancel = threading.Event()
        self._selection_scan_id += 1
        scan_id = self._selection_scan_id
        self.target_entity = None
        self.scene_numbers = {}
        self._scene_number_entities = []
        self._number_tracks = {}
        self._number_attribute_activity = {}
        self._number_visual_refresh_step = 0
        self._number_change_flags = {}
        self._number_structure_hash = "n00000000"
        self._semantic_features = {}
        self._semantic_scene = "h00000000"
        self._semantic_tokens = ()
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.selection_var.set("正在截图；截图出现后可立即拖框或等待荧光框逐步出现……")
        self.status_var.set("OCR 会在后台继续，不需要等待扫描完成。")
        self.root.update_idletasks()
        self.root.withdraw()
        self.root.after(
            30, lambda: threading.Thread(
                target=self._scan_screen_numbers,
                args=(scan_id, self._selection_scan_cancel), daemon=True).start())

    def _scan_screen_numbers(self, scan_id, cancel_event):
        try:
            screen = virtual_screen_rect()
            image = self.capture.grab(screen)
            if cancel_event.is_set():
                return
            # Display the screenshot immediately. OCR results stream into the already-visible overlay.
            self.events.put(("number_scan", scan_id, image, [], screen))

            def publish(candidates):
                if candidates and not cancel_event.is_set():
                    self.events.put(("number_scan_candidates", scan_id, candidates))

            candidates = self._detect_screen_numbers(
                image, screen, progress_callback=publish, cancel_event=cancel_event)
            if not cancel_event.is_set():
                self.events.put(("number_scan_complete", scan_id, candidates))
        except Exception as exc:
            self._log_exception("number_scan_error", exc)
            if not cancel_event.is_set():
                self.events.put(("number_scan_error", scan_id, str(exc)))

    def _detect_screen_numbers(self, image, screen, progress_callback=None, cancel_event=None):
        rgb = self.np.asarray(image.convert("RGB"))
        height, width = rgb.shape[:2]
        if width < 4 or height < 4 or not self.reader.engines:
            return []
        number_pattern = re.compile(
            r"[-+−＋]?(?:(?:\d{1,3}(?:[.,，．'’ ]\d{3})+|\d+)"
            r"(?:[.,，．]\d+)?|[.,，．]\d+)(?:[eE][-+−＋]?\d+)?\s*" +
            SCORE_SUFFIX_RE, re.IGNORECASE)
        found = []
        _engine_name, primary_engine, _engine_weight = self.reader.engines[0]

        def add_result(view, offset_x, offset_y, scale_x, scale_y, active_engine=None):
            if cancel_event is not None and cancel_event.is_set():
                return
            before_count = len(found)
            try:
                engine = active_engine or primary_engine
                try:
                    result = engine(view, use_det=True, use_cls=False, use_rec=True)
                except TypeError:
                    result = engine(view)
                texts = (result.get("txts") if isinstance(result, dict) else
                         getattr(result, "txts", None))
                boxes = (result.get("boxes") if isinstance(result, dict) else
                         getattr(result, "boxes", None))
                scores = (result.get("scores") if isinstance(result, dict) else
                          getattr(result, "scores", None))
                if texts is None or boxes is None:
                    return
                texts, boxes = list(texts), list(boxes)
                try:
                    scores = list(scores) if scores is not None else []
                except TypeError:
                    scores = []
                for index, raw in enumerate(texts):
                    if index >= len(boxes):
                        continue
                    if isinstance(raw, dict):
                        text = raw.get("text") or raw.get("txt") or ""
                    elif isinstance(raw, (tuple, list)):
                        text = raw[0] if raw else ""
                    else:
                        text = raw
                    text = unicodedata.normalize("NFKC", str(text)).strip()
                    if not text:
                        continue
                    try:
                        points = self.np.asarray(boxes[index], dtype="float32").reshape(-1, 2)
                        if len(points) < 2:
                            continue
                        local_x1 = float(points[:, 0].min())
                        local_y1 = float(points[:, 1].min())
                        local_x2 = float(points[:, 0].max())
                        local_y2 = float(points[:, 1].max())
                    except Exception:
                        continue
                    if local_x2 - local_x1 < 2 or local_y2 - local_y1 < 2:
                        continue
                    confidence = self.reader._as_float(
                        scores[index] if index < len(scores) else 0.65)
                    spans = list(number_pattern.finditer(text))
                    if not spans and self.reader._parse_numeric_candidates(text):
                        spans = [None]
                    for match in spans:
                        token = match.group(0) if match else text
                        parsed = self.reader._parse_numeric_candidates(token)
                        if not parsed:
                            continue
                        value, _weight, parsed_token = max(
                            parsed,
                            key=lambda item: (item[1],
                                              sum(ch.isdigit() for ch in item[2]),
                                              len(item[2])))
                        bx1, by1, bx2, by2 = local_x1, local_y1, local_x2, local_y2
                        if match and len(text) > 1:
                            start = max(0.0, min(1.0, match.start() / len(text)))
                            end = max(start, min(1.0, match.end() / len(text)))
                            if local_x2 - local_x1 >= (local_y2 - local_y1) * 0.72:
                                bx1 = local_x1 + (local_x2 - local_x1) * start
                                bx2 = local_x1 + (local_x2 - local_x1) * end
                            else:
                                by1 = local_y1 + (local_y2 - local_y1) * start
                                by2 = local_y1 + (local_y2 - local_y1) * end
                        x1 = screen[0] + offset_x + bx1 * scale_x
                        y1 = screen[1] + offset_y + by1 * scale_y
                        x2 = screen[0] + offset_x + bx2 * scale_x
                        y2 = screen[1] + offset_y + by2 * scale_y
                        pad_x = max(3.0, (x2 - x1) * 0.055)
                        pad_y = max(3.0, (y2 - y1) * 0.16)
                        rect = (max(screen[0], x1 - pad_x),
                                max(screen[1], y1 - pad_y),
                                min(screen[2], x2 + pad_x),
                                min(screen[3], y2 + pad_y))
                        found.append((rect, value, confidence, parsed_token))
            except Exception:
                return
            finally:
                if progress_callback is not None and len(found) > before_count:
                    try:
                        progress_callback(found[before_count:])
                    except Exception:
                        pass

        max_overview = 2200.0
        overview_scale = min(1.0, max_overview / max(width, height))
        if overview_scale < 0.995:
            overview = self.cv2.resize(rgb, None, fx=overview_scale, fy=overview_scale,
                                       interpolation=self.cv2.INTER_AREA)
        else:
            overview = rgb
        for _name, overview_engine, _weight in self.reader.engines:
            if cancel_event is not None and cancel_event.is_set():
                return []
            add_result(overview, 0, 0, width / overview.shape[1],
                       height / overview.shape[0], overview_engine)

        tile_width = min(width, 1700)
        tile_height = min(height, 1150)

        def starts(length, span):
            if length <= span:
                return [0]
            step = max(1, span - max(96, span // 10))
            values = list(range(0, max(1, length - span + 1), step))
            last = length - span
            if not values or values[-1] != last:
                values.append(last)
            return values

        tile_starts = [(x, y) for y in starts(height, tile_height)
                       for x in starts(width, tile_width)]
        if len(tile_starts) > 1 or overview_scale < 0.90:
            for x, y in tile_starts:
                if cancel_event is not None and cancel_event.is_set():
                    return []
                tile = rgb[y:y + tile_height, x:x + tile_width]
                add_result(tile, x, y, 1.0, 1.0)

        def area(candidate):
            rect = candidate[0]
            return max(1.0, (rect[2] - rect[0]) * (rect[3] - rect[1]))

        def overlap(a, b):
            x1, y1 = max(a[0], b[0]), max(a[1], b[1])
            x2, y2 = min(a[2], b[2]), min(a[3], b[3])
            intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
            if not intersection:
                return 0.0
            aa = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
            ab = max(1.0, (b[2] - b[0]) * (b[3] - b[1]))
            return intersection / max(1.0, aa + ab - intersection)

        deduplicated = []
        for candidate in sorted(found, key=lambda item: (-item[2], area(item))):
            duplicate = False
            for existing in deduplicated:
                same_value = ScoreReader._same_value(candidate[1], existing[1])
                if overlap(candidate[0], existing[0]) >= (0.48 if same_value else 0.82):
                    duplicate = True
                    break
            if not duplicate:
                deduplicated.append(candidate)
        deduplicated.sort(key=lambda item: (item[0][1], item[0][0], -item[2]))
        return deduplicated

    def _selection_done(self, selection):
        if self._selection_scan_cancel is not None:
            self._selection_scan_cancel.set()
        self._selection_overlay = None
        if not selection:
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            self.status_var.set("点击“数值”重新扫描整个屏幕。")
            self.value_button.configure(state="normal")
            return
        rect, detected_value, detected_confidence, detected_text = selection
        screen = virtual_screen_rect()
        x1 = max(screen[0], min(screen[2], int(rect[0])))
        y1 = max(screen[1], min(screen[3], int(rect[1])))
        x2 = max(screen[0], min(screen[2], int(rect[2])))
        y2 = max(screen[1], min(screen[3], int(rect[3])))
        rect = (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
        if rect[2] - rect[0] < 4 or rect[3] - rect[1] < 4:
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            self.value_button.configure(state="normal")
            return
        if not self._bind_target_window(rect):
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("无法绑定目标程序窗口，请重新选择程序内的数值")
            self.status_var.set("数值必须位于可操作程序的客户区内。")
            self.value_button.configure(state="normal")
            self.confirm_button.configure(state="disabled")
            return
        snapshot = self._selection_snapshot
        snapshot_screen = self._selection_screen or screen
        self.selection_var.set("正在精确核验所选数值……")
        threading.Thread(
            target=self._recognize_selection,
            args=(rect, snapshot, snapshot_screen, detected_value,
                  detected_confidence, detected_text), daemon=True).start()

    def _recognize_selection(self, rect, snapshot, screen, detected_value,
                             detected_confidence, detected_text):
        try:
            self.hardware.calibrate_selection(rect, virtual_screen_rect())
            roi_h = max(1, int(rect[3] - rect[1]))
            if roi_h <= 28 and self.hardware.tier != "low":
                self.reader.character_detail_variants = max(
                    self.reader.character_detail_variants, 3)
        except Exception as exc:
            self._log_once("selection_calibration", "selection_calibration_error", type(exc).__name__)
        value, confidence, text = None, 0.0, ""
        if snapshot is not None:
            crop = (max(0, int(math.floor(rect[0] - screen[0]))),
                    max(0, int(math.floor(rect[1] - screen[1]))),
                    min(snapshot.width, int(math.ceil(rect[2] - screen[0]))),
                    min(snapshot.height, int(math.ceil(rect[3] - screen[1]))))
            if crop[2] - crop[0] >= 4 and crop[3] - crop[1] >= 4:
                try:
                    value, confidence, text = self.reader.read_image(
                        snapshot.crop(crop), expected=detected_value)
                except Exception:
                    value, confidence, text = None, 0.0, ""
        if detected_value is not None:
            agrees = value is not None and ScoreReader._same_value(value, detected_value)
            if value is None or (not agrees and confidence < detected_confidence + 0.12):
                value, confidence, text = (detected_value, detected_confidence,
                                           detected_text)
            elif agrees:
                confidence = min(0.997, max(confidence, detected_confidence) + 0.035)
        if value is not None:
            try:
                self._bootstrap_target_semantics(rect, snapshot, screen, value, confidence, text)
                self._remember_target_anchor(rect, text, value)
            except Exception as exc:
                self._log_runtime("target_semantic_bootstrap_error", type(exc).__name__)
        self.events.put(("selection", value, confidence, text))

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        release_all_inputs()
        self.stop_event.clear()
        self._visual_cache = "v0"
        self._danger_regions = []
        self._recognized_actions = set()
        self._controls = {}
        self._control_graph_hash = "c00000000"
        self._dynamic_key_actions = set()
        self._key_action_gates = {}
        self._last_decision_state = ""
        self._last_isolation_scene = None
        self._last_control_count = 0
        self._last_danger_count = 0
        self._environment_cache = None
        self._environment_cache_at = 0.0
        self._state_velocity = 0.0
        self._state_acceleration = 0.0
        self._motion_mask = 0
        self._target_read_failures = 0
        self._operation_rect_cache = None
        self._operation_scope_signature = ""
        self._operation_scope_reason = "target"
        self._operation_scope_key = ""
        self.action_priors = dict(KEY_ACTION_PRIORS)
        self.hook = EscapeHook(self.stop_event)
        if not self.hook.start():
            messagebox.showerror(APP_NAME, "无法启用 ESC 紧急停止，因此未启动 AI。",
                                 parent=self.root)
            return
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.status_var.set("AI 已开启；按 ESC 立即停止")
        self.root.withdraw()
        # The AI worker is intentionally non-daemon so process teardown cannot cut
        # through input release or SQLite finalization.
        self.worker = threading.Thread(target=self._run_ai, daemon=False)
        self.worker.start()

    def _log_runtime(self, event, detail=""):
        if not self.data_dir:
            return
        try:
            log_dir = self.data_dir / "日志"
            log_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y-%m-%d %H:%M:%S")
            line = f"[{stamp}] {event}"
            if detail:
                line += " | " + str(detail).replace("\r", " ").replace("\n", " ")[:900]
            with (log_dir / "运行日志.txt").open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except Exception:
            pass

    def _log_once(self, key, event, detail=""):
        token = str(key)
        if token in self._log_once_keys:
            return
        self._log_once_keys.add(token)
        self._log_runtime(event, detail)

    def _log_exception(self, event, exc=None):
        detail = traceback.format_exc()
        if detail.strip() == "NoneType: None" and exc is not None:
            detail = f"{type(exc).__name__}: {exc}"
        self._log_runtime(event, detail)

    def _bind_target_window(self, rect):
        cx = (float(rect[0]) + float(rect[2])) * 0.5
        cy = (float(rect[1]) + float(rect[3])) * 0.5
        hwnd = top_level_window_at(cx, cy)
        client = client_screen_rect(hwnd)
        if not hwnd or not client:
            return False
        if not (client[0] <= cx <= client[2] and client[1] <= cy <= client[3]):
            return False
        cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
        self.target_hwnd = int(hwnd)
        self.target_identity = environment_identity_for_window(hwnd)
        self.target_pid = int(self.target_identity.get("pid", 0) or 0)
        self.window_roi = (
            max(0.0, min(1.0, (rect[0] - client[0]) / cw)),
            max(0.0, min(1.0, (rect[1] - client[1]) / ch)),
            max(0.0, min(1.0, (rect[2] - client[0]) / cw)),
            max(0.0, min(1.0, (rect[3] - client[1]) / ch)),
        )
        self._environment_cache = self.target_identity
        self._environment_cache_at = time.monotonic()
        self._target_lost_since = None
        self._target_read_failures = 0
        self._operation_rect_cache = None
        self._operation_scope_signature = ""
        self._operation_scope_key = ""
        self._window_seen = {}
        self._temporal_windows = {}
        self._last_action_at = 0.0
        # Prime the visible-window snapshot so pre-existing unrelated desktop windows
        # are not mistaken for action-created popups.
        self._related_operation_windows()
        self._log_runtime("target_bound",
                          f"hwnd={self.target_hwnd} pid={self.target_pid} exe={self.target_identity.get('exe')}")
        return True

    def _target_client_rect(self):
        rect = client_screen_rect(self.target_hwnd)
        if rect:
            self._target_lost_since = None
            return rect
        if self._target_lost_since is None:
            self._target_lost_since = time.monotonic()
            self._log_once("target_window_unavailable", "target_window_unavailable", f"hwnd={self.target_hwnd}")
        return None

    def _current_roi(self):
        client = self._target_client_rect()
        if client and self.window_roi:
            cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
            x1 = client[0] + self.window_roi[0] * cw
            y1 = client[1] + self.window_roi[1] * ch
            x2 = client[0] + self.window_roi[2] * cw
            y2 = client[1] + self.window_roi[3] * ch
            if x2 - x1 >= 4 and y2 - y1 >= 4:
                return (x1, y1, x2, y2)
        return None

    def _related_operation_windows(self):
        if os.name != "nt" or user32 is None or not self.target_pid:
            return []
        now = time.monotonic()
        windows = []
        visible = set()
        try:
            fg = int(user32.GetForegroundWindow() or 0)
            fg_root = int(user32.GetAncestor(wintypes.HWND(fg), 2) or fg) if fg else 0
        except Exception:
            fg_root = 0
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def visit(hwnd, _lparam):
            if self.stop_event.is_set():
                return False
            try:
                hwnd_i = int(hwnd)
                if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                    return True
                rect = client_screen_rect(hwnd)
                if not rect or rect[2] - rect[0] < 24 or rect[3] - rect[1] < 24:
                    return True
                visible.add(hwnd_i)
                first_seen = self._window_seen.setdefault(hwnd_i, now)
                pid = wintypes.DWORD(0)
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                same_process = int(pid.value) == int(self.target_pid)
                if same_process:
                    windows.append((hwnd_i, rect))
                    return True
                # Foreign-process windows are admitted only when they are newly visible
                # in a tight post-action window and actually become foreground. This
                # captures launchers/dialogs spawned by the target without scanning the desktop.
                action_age = now - float(self._last_action_at or 0.0)
                association_window = max(2.5, min(8.0,
                    1.4 + float(getattr(self.hardware, "settle", 0.38) or 0.38) * 4.0 +
                    float(getattr(self.reader, "latency", 0.25) or 0.25) * 2.2))
                newly_visible = now - float(first_seen) <= association_window
                if (hwnd_i == fg_root and self._last_action_at and
                        0.0 <= action_age <= association_window and newly_visible):
                    link = self._temporal_windows.setdefault(
                        hwnd_i, {"score": 0.0, "last": now, "pid": int(pid.value)})
                    link["score"] = min(3.0, float(link.get("score", 0.0)) +
                                        max(0.70, 1.35 - action_age * 0.22))
                    link["last"] = now
                link = self._temporal_windows.get(hwnd_i)
                if link and float(link.get("score", 0.0)) >= 0.68 and now - float(link.get("last", now)) <= 45.0:
                    windows.append((hwnd_i, rect))
            except Exception:
                pass
            return True

        callback = callback_type(visit)
        try:
            user32.EnumWindows(callback, 0)
        except Exception:
            pass
        for hwnd_i in tuple(self._temporal_windows):
            link = self._temporal_windows.get(hwnd_i, {})
            if hwnd_i not in visible or now - float(link.get("last", now)) > 45.0:
                self._temporal_windows.pop(hwnd_i, None)
        if len(self._window_seen) > 320:
            self._window_seen = {hwnd: self._window_seen[hwnd] for hwnd in visible if hwnd in self._window_seen}
        # Deduplicate while preserving target/same-process ordering.
        dedup = {}
        for hwnd_i, rect in windows:
            dedup[hwnd_i] = rect
        return list(dedup.items())

    @staticmethod
    def _rect_union(rects):
        rects = [tuple(r) for r in rects if r and r[2] > r[0] and r[3] > r[1]]
        if not rects:
            return None
        return (min(r[0] for r in rects), min(r[1] for r in rects),
                max(r[2] for r in rects), max(r[3] for r in rects))

    @staticmethod
    def _clip_rect(rect, bounds):
        if not rect or not bounds:
            return None
        clipped = (max(bounds[0], rect[0]), max(bounds[1], rect[1]),
                   min(bounds[2], rect[2]), min(bounds[3], rect[3]))
        return clipped if clipped[2] > clipped[0] and clipped[3] > clipped[1] else None

    @staticmethod
    def _rect_overlap_ratio(a, b):
        if not a or not b:
            return 0.0
        ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
        ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
        inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
        area = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
        return inter / area

    def _adaptive_operation_rect(self, stagnant=0, refresh=False, reason="decision"):
        if self.stop_event.is_set():
            return None
        if not refresh and self._operation_rect_cache:
            return self._operation_rect_cache
        virtual = virtual_screen_rect()
        if not virtual or virtual[2] <= virtual[0] or virtual[3] <= virtual[1]:
            return None
        env = self._environment_identity()
        app_token = str(env.get("exe_hash", "unknown"))[:12]
        learner = self._active_learner
        target = self._target_client_rect()
        if not target:
            return None

        related = self._related_operation_windows()
        local_windows = [(int(self.target_hwnd), target)]
        seen_hwnd = {int(self.target_hwnd)}
        for hwnd, rect in related:
            if int(hwnd) not in seen_hwnd and rect:
                local_windows.append((int(hwnd), rect))
                seen_hwnd.add(int(hwnd))

        specs = [(f"{app_token}|local:target", "target-window", target)]
        priors = {f"{app_token}|local:target": 0.96}
        for hwnd, rect in local_windows[1:]:
            temporal = hwnd in self._temporal_windows
            tag = "linked" if temporal else "same-process"
            key = f"{app_token}|local:{tag}:{hwnd}"
            specs.append((key, f"{tag}-window", rect))
            priors[key] = 0.82 if temporal else 0.74
        union = self._rect_union([rect for _hwnd, rect in local_windows])
        if union and len(local_windows) > 1:
            union = self._clip_rect(union, virtual)
            if union:
                key = f"{app_token}|local:union"
                specs.append((key, "related-window-union", union))
                priors[key] = 0.66

        vw = max(1.0, virtual[2] - virtual[0])
        vh = max(1.0, virtual[3] - virtual[1])

        def qrect(depth, ix, iy):
            cells = 1 << depth
            w, h = vw / cells, vh / cells
            return (virtual[0] + ix * w, virtual[1] + iy * h,
                    virtual[0] + (ix + 1) * w, virtual[1] + (iy + 1) * h)

        # The whole virtual desktop is executable from cold start, but only through
        # coarse, low-budget cells.  The target window keeps a strong prior; it is a
        # preference rather than an absolute boundary.  Visual novelty, UIA/OCR
        # evidence and measured causal effects decide which cells receive more budget.
        linked_external_rects = [rect for hwnd, rect in local_windows[1:]
                                 if int(hwnd) in self._temporal_windows and rect]
        desktop_depth = max(1, min(5, int(EXPLORATION_CONFIG.desktop_depth)))
        desktop_cells = 1 << desktop_depth
        stagnation_bonus = min(
            EXPLORATION_CONFIG.desktop_stagnation_prior_bonus,
            max(0.0, float(stagnant)) /
            max(1.0, float(LEARNING_CONFIG.stagnation_extreme)) *
            EXPLORATION_CONFIG.desktop_stagnation_prior_bonus)
        for iy in range(desktop_cells):
            for ix in range(desktop_cells):
                rect = qrect(desktop_depth, ix, iy)
                key = f"{app_token}|q{desktop_depth}:{ix}:{iy}"
                value, evidence, risk = learner.scope_value(key) if learner else (0.0, 0.0, 0.0)
                linked = any(self._rect_overlap_ratio(evidence_rect, rect) >= 0.08
                             for evidence_rect in linked_external_rects)
                local_overlap = self._rect_overlap_ratio(rect, union) if union else 0.0
                if linked:
                    scope_reason = "external-evidence"
                    prior = 0.46
                elif evidence >= 1.25 and value > 0.012 and risk < 0.62:
                    scope_reason = "desktop-learned"
                    prior = 0.30 + max(-0.12, min(0.22, value * 0.10)) - min(0.16, risk * 0.12)
                elif local_overlap >= 0.42:
                    scope_reason = "desktop-local-context"
                    prior = 0.34
                else:
                    scope_reason = "desktop-cold"
                    prior = EXPLORATION_CONFIG.desktop_cold_prior + stagnation_bonus
                # Never use zero probability.  Unseen cells retain a small novelty
                # bonus so the learner can break the outside-region evidence loop.
                if evidence <= 0.0:
                    prior += 0.035
                specs.append((key, scope_reason, rect))
                priors[key] = max(0.08, min(0.64, prior))

        if learner is not None:
            proven_external, refinement = [], []
            for key in list(getattr(learner, "scopes", {})):
                match = re.search(rf"^{re.escape(app_token)}\|q(\d+):(\d+):(\d+)$", str(key))
                if not match:
                    continue
                depth, ix, iy = map(int, match.groups())
                if depth > 7 or not (0 <= ix < (1 << depth) and 0 <= iy < (1 << depth)):
                    continue
                rect = qrect(depth, ix, iy)
                value, n, risk = learner.scope_value(key)
                external = not union or self._rect_overlap_ratio(rect, union) < 0.82
                if external and n >= 1.2 and value > 0.012 and risk < 0.62:
                    proven_external.append((value + min(0.24, n * 0.018), key, rect))
                    if depth < 7 and n >= 2.2:
                        for dy in (0, 1):
                            for dx in (0, 1):
                                child_key = f"{app_token}|q{depth + 1}:{ix * 2 + dx}:{iy * 2 + dy}"
                                child_rect = qrect(depth + 1, ix * 2 + dx, iy * 2 + dy)
                                child_value, child_n, child_risk = learner.scope_value(child_key)
                                if child_n <= 0.0 or child_risk < 0.72:
                                    refinement.append((child_n, -child_value, child_key, child_rect))
            for _score, key, rect in sorted(proven_external, reverse=True)[:3]:
                if all(existing[0] != key for existing in specs):
                    specs.append((key, "proven-external", rect))
                priors[key] = max(priors.get(key, 0.10), 0.62)
            refine_budget = 1 + int(stagnant >= LEARNING_CONFIG.stagnation_medium) + int(
                stagnant >= LEARNING_CONFIG.stagnation_extreme)
            for _n, _neg_value, key, rect in sorted(refinement)[:refine_budget]:
                if all(existing[0] != key for existing in specs):
                    specs.append((key, "external-refinement", rect))
                priors[key] = max(priors.get(key, 0.10), 0.26)

        keys = [key for key, _name, _rect in specs]
        selected_key = learner.choose_scope(keys, stagnant, priors=priors) if learner else keys[0]
        if learner is not None:
            cold_scopes = [item for item in specs if item[1] == "desktop-cold"]
            if cold_scopes:
                unknown_ratio = len(cold_scopes) / max(1.0, float(desktop_cells ** 2))
                coverage_pressure = min(
                    0.20, 0.035 + unknown_ratio * 0.055 +
                    max(0.0, float(stagnant)) /
                    max(1.0, float(LEARNING_CONFIG.stagnation_extreme)) * 0.10)
                probe_phase = self._parameter_fraction("desktop-scope-coverage", learner.steps)
                if probe_phase < coverage_pressure:
                    selected_key = min(
                        cold_scopes,
                        key=lambda item: (
                            learner.scope_value(item[0])[1],
                            self._parameter_fraction(item[0], learner.steps)))[0]
        scope_key, scope_reason, chosen = next(
            (item for item in specs if item[0] == selected_key), specs[0])
        chosen = self._clip_rect(chosen, virtual) or target
        signature = tuple(round(float(v), 1) for v in chosen)
        if signature != self._operation_scope_signature or scope_key != self._operation_scope_key:
            self._controls = {}
            self._recognized_actions = set()
            self._danger_regions = []
            self._log_runtime(
                "operation_scope",
                f"reason={scope_reason} prior={priors.get(scope_key, 0.5):.3f} rect={signature}")
        self._operation_scope_signature = signature
        self._operation_scope_reason = scope_reason
        self._operation_scope_key = scope_key
        self._operation_rect_cache = chosen
        return chosen

    @staticmethod
    def _numeric_format_signature(text):
        raw = unicodedata.normalize("NFKC", str(text or "")).strip().lower()
        return {
            "percent": "%" in raw,
            "decimal": bool(re.search(r"[.,]\d", raw)),
            "scientific": bool(re.search(r"e[-+]?\d", raw)),
            "suffix": "".join(re.findall(r"[a-z%]+", raw))[-6:],
            "digits": sum(ch.isdigit() for ch in raw),
        }

    def _target_relation_tokens(self, entity, entities=None, client=None):
        if not isinstance(entity, NumberEntity):
            return ()
        client = client or self._target_client_rect() or virtual_screen_rect()
        if not client:
            return ()
        width = max(1.0, float(client[2] - client[0]))
        height = max(1.0, float(client[3] - client[1]))
        try:
            cx, cy = (float(entity.bbox[0] + entity.bbox[2]) * 0.5,
                      float(entity.bbox[1] + entity.bbox[3]) * 0.5)
        except Exception:
            return ()
        tokens = []
        pool = list(entities) if entities is not None else list(self.scene_numbers.values())
        for other in pool:
            if not isinstance(other, NumberEntity) or other is entity:
                continue
            label = self._normalized_number_label(getattr(other, "label", ""))
            if not label:
                continue
            try:
                ox, oy = other.center
                dx = (float(ox) - cx) / width
                dy = (float(oy) - cy) / height
                distance = math.hypot(dx, dy)
            except Exception:
                continue
            if distance > 0.48:
                continue
            # Coarse relative geometry is intentionally tolerant of layout motion.
            horizontal = "r" if dx > 0.035 else "l" if dx < -0.035 else "c"
            vertical = "d" if dy > 0.035 else "u" if dy < -0.035 else "c"
            distance_band = min(4, int(distance / 0.10))
            label_hash = hashlib.sha1(label.encode("utf-8", "replace")).hexdigest()[:8]
            tokens.append(f"{label_hash}:{horizontal}{vertical}:d{distance_band}")
        return tuple(sorted(set(tokens))[:16])

    @staticmethod
    def _relation_similarity(left, right):
        a, b = set(left or ()), set(right or ())
        if not a or not b:
            return 0.0
        return len(a & b) / max(1, len(a | b))

    def _remember_target_anchor(self, rect, text, value):
        client = self._target_client_rect()
        normalized = self.window_roi or (0.0, 0.0, 0.0, 0.0)
        entity = self.target_entity
        env = self._environment_identity(force=False)
        self._target_anchor = {
            "label": str(getattr(entity, "label", "") or "").strip(),
            "role": str(getattr(entity, "role", "TARGET") or "TARGET").upper(),
            "window_id": str(getattr(entity, "window_id", "") or ""),
            "control_id": str(getattr(entity, "control_id", "") or ""),
            "relations": self._target_relation_tokens(entity, client=client),
            "exe_hash": str(env.get("exe_hash", "") or ""),
            "window_class": str(env.get("class", "") or ""),
            "roi": tuple(normalized),
            "client": tuple(client) if client else None,
            "observed_at": time.monotonic(),
        }

    def _target_identity_score(self, entity):
        if not isinstance(entity, NumberEntity) or not self._target_anchor:
            return 1.0
        anchor = self._target_anchor
        score = 0.0
        weight = 0.0
        label_a = self._normalized_number_label(anchor.get("label", ""))
        label_b = self._normalized_number_label(entity.label)
        if label_a and label_b:
            score += difflib.SequenceMatcher(None, label_a, label_b).ratio() * 3.4
            weight += 3.4
        window_a = str(anchor.get("window_id", "") or "")
        window_b = str(getattr(entity, "window_id", "") or "")
        if window_a and window_b:
            score += (1.0 if window_a == window_b else 0.0) * 2.2
            weight += 2.2
        control_a = str(anchor.get("control_id", "") or "")
        control_b = str(getattr(entity, "control_id", "") or "")
        if control_a and control_b:
            score += (1.0 if control_a == control_b else 0.0) * 1.8
            weight += 1.8
        relation_score = self._relation_similarity(
            anchor.get("relations", ()), self._target_relation_tokens(entity))
        if anchor.get("relations"):
            score += relation_score * 2.5
            weight += 2.5
        # Position contributes only as short-term temporal continuity, never as a
        # fixed identity requirement. A large legitimate move can be rescued by
        # stable labels/window/relations.
        try:
            roi = anchor.get("roi") or ()
            if len(roi) == 4:
                old_x = (float(roi[0]) + float(roi[2])) * 0.5
                old_y = (float(roi[1]) + float(roi[3])) * 0.5
                client = self._target_client_rect() or virtual_screen_rect()
                cw = max(1.0, float(client[2] - client[0]))
                ch = max(1.0, float(client[3] - client[1]))
                ex, ey = entity.center
                nx = (float(ex) - client[0]) / cw
                ny = (float(ey) - client[1]) / ch
                age = max(0.0, time.monotonic() - float(anchor.get("observed_at", 0.0) or 0.0))
                continuity = max(0.0, 1.0 - math.hypot(nx - old_x, ny - old_y) * 1.35)
                continuity *= math.exp(-age / 2.5)
                score += continuity * 0.55
                weight += 0.55
        except Exception as exc:
            self._log_once("target_identity_continuity", "target_identity_continuity_error", type(exc).__name__)
        return score / max(1e-9, weight) if weight else 1.0

    def _target_relocate_threshold(self):
        latency = float(getattr(self.reader, "latency", 0.25) or 0.25)
        verification = int(getattr(self.hardware, "verify_reads", 0) or 0)
        return max(2, min(6, 2 + verification + int(latency > 0.7)))

    def _relocalize_target(self, expected=None):
        if self.stop_event.is_set() or not self.capture or not self.reader:
            return False
        old_client = self._target_client_rect()
        old_roi = self._current_roi()
        if not old_client:
            return False
        anchor = dict(self._target_anchor or {})
        regions = []
        if old_roi:
            rw, rh = old_roi[2] - old_roi[0], old_roi[3] - old_roi[1]
            cw, ch = old_client[2] - old_client[0], old_client[3] - old_client[1]
            for scale in (1.5, 3.0):
                px = max(rw * scale, cw * 0.08 * scale)
                py = max(rh * scale, ch * 0.08 * scale)
                regions.append(self._clip_rect((old_roi[0] - px, old_roi[1] - py,
                                                old_roi[2] + px, old_roi[3] + py), old_client))
        regions.append(old_client)
        for _hwnd, rect in self._related_operation_windows():
            regions.append(rect)
        unique, seen = [], set()
        for region in regions:
            if not region:
                continue
            key = tuple(round(float(v), 1) for v in region)
            if key not in seen:
                seen.add(key)
                unique.append(region)

        best = None
        anchor_label = self._normalized_number_label(anchor.get("label", ""))
        anchor_role = str(anchor.get("role") or "TARGET").upper()
        anchor_relations = tuple(anchor.get("relations") or ())
        anchor_window_id = str(anchor.get("window_id", "") or "")
        anchor_control_id = str(anchor.get("control_id", "") or "")
        anchor_roi = anchor.get("roi") or self.window_roi or (0, 0, 0, 0)
        old_center = ((anchor_roi[0] + anchor_roi[2]) * 0.5,
                      (anchor_roi[1] + anchor_roi[3]) * 0.5)
        anchor_age = max(0.0, time.monotonic() - float(anchor.get("observed_at", 0.0) or 0.0))

        for region in unique:
            if self.stop_event.is_set():
                return False
            try:
                image = self.capture.grab(region)
                items = self._ocr_scene_items(image, region, max_side=None)
                entities = self._number_entities_from_items(items)
            except Exception as exc:
                self._set_source_health(
                    "target_relocalization", False, 0.0,
                    f"scan_exception:{type(exc).__name__}", "sensor_failed")
                continue
            for entity in entities:
                if self.stop_event.is_set():
                    return False
                center_x = (entity.bbox[0] + entity.bbox[2]) * 0.5
                center_y = (entity.bbox[1] + entity.bbox[3]) * 0.5
                candidate_hwnd = top_level_window_at(center_x, center_y)
                candidate_identity = environment_identity_for_window(candidate_hwnd) if candidate_hwnd else {}
                if candidate_hwnd and self.target_pid and int(candidate_identity.get("pid", 0) or 0) != self.target_pid:
                    continue
                if (anchor.get("exe_hash") and candidate_identity.get("exe_hash") and
                        str(candidate_identity.get("exe_hash")) != str(anchor.get("exe_hash"))):
                    continue
                candidate_client = client_screen_rect(candidate_hwnd) if candidate_hwnd else old_client
                if not candidate_client:
                    continue

                label = self._normalized_number_label(entity.label)
                label_score = (difflib.SequenceMatcher(None, anchor_label, label).ratio()
                               if anchor_label and label else 0.0)
                window_score = 1.0 if (anchor_window_id and entity.window_id == anchor_window_id) else 0.0
                control_score = 1.0 if (anchor_control_id and entity.control_id == anchor_control_id) else 0.0
                relation_score = self._relation_similarity(
                    anchor_relations, self._target_relation_tokens(entity, entities, candidate_client))
                process_score = 1.0 if candidate_hwnd else 0.55
                role_score = 1.0 if entity.role == anchor_role else 0.0

                cw = max(1.0, candidate_client[2] - candidate_client[0])
                ch = max(1.0, candidate_client[3] - candidate_client[1])
                nx = (center_x - candidate_client[0]) / cw
                ny = (center_y - candidate_client[1]) / ch
                continuity = max(0.0, 1.0 - math.hypot(nx - old_center[0], ny - old_center[1]) * 1.35)
                continuity *= math.exp(-anchor_age / 2.5)

                # Only identity evidence participates here. Value, formatting, glyph,
                # size, color, rotation and visibility are learnable outcomes and are
                # intentionally absent from this score. ``expected`` is likewise not
                # used as identity evidence.
                score = (label_score * 3.8 + relation_score * 2.6 +
                         window_score * 2.2 + control_score * 1.6 +
                         process_score * 1.4 + continuity * 0.55 +
                         role_score * 0.18 + float(entity.confidence) * 0.82)
                if best is None or score > best[0]:
                    best = (score, entity, candidate_hwnd, candidate_client)

        if best is None:
            self._set_source_health("target_relocalization", False, 0.0, "no_candidate", "missing")
            self._log_runtime("target_relocation_failed", "no-candidate")
            return False
        score, entity, hwnd, client = best
        has_stable_anchor = bool(anchor_label or anchor_relations or anchor_window_id or anchor_control_id)
        minimum = 2.35 if has_stable_anchor else 1.55
        if score < minimum:
            self._set_source_health("target_relocalization", False, entity.confidence,
                                    f"weak:{score:.3f}", "low_confidence")
            self._log_runtime("target_relocation_failed", f"weak={score:.3f}")
            return False
        if hwnd:
            identity = environment_identity_for_window(hwnd)
            if self.target_pid and int(identity.get("pid", 0) or 0) != self.target_pid:
                self._log_runtime("target_relocation_failed", "pid-mismatch")
                return False
            self.target_hwnd = int(hwnd)
            self.target_identity = identity
            self.target_pid = int(identity.get("pid", 0) or self.target_pid)
        cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
        self.window_roi = (
            max(0.0, min(1.0, (entity.bbox[0] - client[0]) / cw)),
            max(0.0, min(1.0, (entity.bbox[1] - client[1]) / ch)),
            max(0.0, min(1.0, (entity.bbox[2] - client[0]) / cw)),
            max(0.0, min(1.0, (entity.bbox[3] - client[1]) / ch)),
        )
        entity.is_target = True
        entity.direction = "maximize"
        entity.entity_id = str(getattr(self.target_entity, "entity_id", "") or entity.entity_id)
        if anchor_label and not entity.label:
            entity.label = anchor.get("label", "")
        if entity.role == "UNKNOWN":
            entity.role = anchor_role if anchor_role in NUMBER_ROLES else "TARGET"
        self.target_entity = entity
        remaining = [item for item in self._scene_number_entities if not item.is_target]
        self._update_scene_numbers(remaining + [entity], target_value=entity.value)
        self._remember_target_anchor(entity.bbox, entity.text, entity.value)
        self._set_source_health("target_relocalization", True, entity.confidence, "", "observed")
        self._target_read_failures = 0
        self._operation_rect_cache = None
        self._operation_scope_signature = ""
        self._operation_scope_key = ""
        self._log_runtime("target_relocated", f"score={score:.3f} label={entity.label} role={entity.role}")
        return True

    def _foreground_root(self):
        if os.name != "nt" or user32 is None:
            return 0
        try:
            fg = int(user32.GetForegroundWindow() or 0)
            return int(user32.GetAncestor(wintypes.HWND(fg), 2) or fg) if fg else 0
        except (OSError, ValueError, TypeError):
            return 0

    def _target_process_alive(self):
        if os.name != "nt" or kernel32 is None or not self.target_pid:
            return None
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        SYNCHRONIZE = 0x00100000
        handle = kernel32.OpenProcess(
            PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, False, int(self.target_pid))
        if not handle:
            return None
        try:
            status = int(kernel32.WaitForSingleObject(handle, 0))
            if status == WAIT_TIMEOUT:
                return True
            if status in {WAIT_OBJECT_0, WAIT_ABANDONED}:
                return False
            return None
        finally:
            kernel32.CloseHandle(handle)

    def _observe_action_side_effects(self, learner, action, state, foreground_before,
                                     control_graph_before, scope_signature_before,
                                     numbers_before=None, numbers_after=None, reliability=1.0):
        """Measure recoverability/system disruption independently of target OCR success."""
        if learner is None or action == OBSERVE_ACTION:
            return False
        try:
            foreground_after = self._foreground_root() if os.name == "nt" else foreground_before
            focus_shift = 1.0 if (foreground_before and foreground_after and
                                  int(foreground_before) != int(foreground_after)) else 0.0
            verified_windows = self._verified_input_windows() if os.name == "nt" else set()
            external_foreground = 1.0 if (foreground_after and verified_windows and
                                          int(foreground_after) not in verified_windows) else 0.0
            target_window_lost = 0.0
            if os.name == "nt" and self.target_hwnd and user32 is not None:
                target_window_lost = (0.0 if user32.IsWindow(
                    wintypes.HWND(int(self.target_hwnd))) else 1.0)
            process_alive = self._target_process_alive()
            target_process_exit = 1.0 if process_alive is False else 0.0
            scope_shift = 1.0 if (scope_signature_before and
                                  scope_signature_before != str(self._operation_scope_signature or "")) else 0.0
            topology_shift = 1.0 if (control_graph_before and
                                     control_graph_before != str(self._control_graph_hash or "")) else 0.0
            components = {
                "focus_shift": focus_shift, "external_foreground": external_foreground,
                "target_window_lost": target_window_lost,
                "target_process_exit": target_process_exit,
                "scope_shift": scope_shift, "window_topology_shift": topology_shift,
            }
            if isinstance(numbers_after, dict):
                target_id = str(getattr(self.target_entity, "entity_id", "") or "")
                components["target_missing"] = (
                    1.0 if target_id and target_id not in numbers_after else 0.0)
                if isinstance(numbers_before, dict):
                    before_count = max(1, len(numbers_before))
                    components["number_loss"] = max(0.0, min(1.0,
                        (len(numbers_before) - len(numbers_after)) / float(before_count)))
            elif target_process_exit or target_window_lost:
                # A failed OCR read is not itself evidence of disappearance, but a
                # dead process/window is. This lets destructive actions be learned
                # even when they destroy the very sensor used for the objective.
                components["target_missing"] = 1.0

            weights = {
                "focus_shift": 0.52, "external_foreground": 0.58,
                "target_window_lost": 0.94, "target_process_exit": 0.995,
                "target_missing": 0.82, "number_loss": 0.30,
                "scope_shift": 0.30, "window_topology_shift": 0.14,
            }
            survival = 1.0
            for name, sample in components.items():
                survival *= max(0.0, 1.0 - weights.get(name, 0.0) * float(sample))
            confidence = max(0.05, min(1.0, float(reliability or 0.0)))
            learner.record_side_effect(
                action, state, 1.0 - survival, signals=components, reliability=confidence)
            self._set_source_health("side_effect_sensor", True, confidence, "", "observed")
            return True
        except Exception as exc:
            self._set_source_health(
                "side_effect_sensor", False, 0.0,
                f"side_effect_exception:{type(exc).__name__}", "sensor_failed")
            self._log_runtime("side_effect_sensor_error", type(exc).__name__)
            return False

    def _verified_input_windows(self):
        windows = {int(self.target_hwnd)} if self.target_hwnd else set()
        for hwnd, _rect in self._related_operation_windows():
            windows.add(int(hwnd))
        return windows

    def _scope_window(self):
        key = str(self._operation_scope_key or "")
        match = re.search(r"\|local:(?:same-process|linked):(\d+)$", key)
        if match:
            return int(match.group(1))
        if "|local:target" in key:
            return int(self.target_hwnd or 0)
        return 0

    @staticmethod
    def _action_input_kind(action):
        parts = Learner._macro_parts(action)
        has_keyboard = any(str(part).startswith(("key:", "hold:", "pulse:", "chord:")) for part in parts)
        has_pointer = any(str(part).startswith(("mouse:", "pointer:", "click:", "tap:", "wheel:", "drag:"))
                          for part in parts)
        if has_keyboard and has_pointer:
            return "mixed"
        if has_keyboard:
            return "keyboard"
        if has_pointer:
            return "pointer"
        return "other"

    def _input_scope_ready(self, action, restore=False):
        if action == OBSERVE_ACTION:
            return True
        if os.name != "nt" or user32 is None or not self.target_hwnd:
            return False
        kind = self._action_input_kind(action)
        scope_key = str(self._operation_scope_key or "")
        desktop_scope = ("|q" in scope_key or
                         self._operation_scope_reason in {"external-evidence",
                                                          "external-refinement", "proven-external"})
        expected = self._scope_window()
        fg_root = self._foreground_root()
        verified = self._verified_input_windows()

        # Keyboard input follows the currently verified foreground.  Desktop scopes
        # never steal focus merely because the pointer search expanded outside the app.
        if kind in {"keyboard", "mixed"} and fg_root in verified:
            return True
        if kind == "pointer" and desktop_scope:
            return True
        if expected and fg_root == expected:
            return True
        if kind == "pointer" and not expected and fg_root in verified:
            return True
        if not restore or desktop_scope:
            return False

        # Local target/same-process/learned-linked scopes may explicitly foreground
        # their own window; they no longer force the original target unconditionally.
        target = expected or (int(self.target_hwnd) if kind == "keyboard" else 0)
        if not target or target not in verified:
            return False
        try:
            if user32.IsIconic(wintypes.HWND(target)):
                user32.ShowWindow(wintypes.HWND(target), 9)  # SW_RESTORE
            user32.SetForegroundWindow(wintypes.HWND(target))
            time.sleep(0.055)
            return self._foreground_root() == target
        except (OSError, ValueError, TypeError) as exc:
            self._log_runtime("input_scope_focus_error", f"{type(exc).__name__}:{scope_key}")
            return False

    def _environment_identity(self, force=False):
        now = time.monotonic()
        if (not force and self._environment_cache and
                now - self._environment_cache_at < 1.5):
            return self._environment_cache
        identity = (environment_identity_for_window(self.target_hwnd)
                    if self.target_hwnd else foreground_environment_identity())
        self._environment_cache = identity
        self._environment_cache_at = now
        return identity

    def _factor_observation(self, action, state, numbers, learner=None, observed_at=None,
                            elapsed=0.0, visual_change=0.0, pre_action_rate=None):
        """Capture heterogeneous causes in one registry for factor->attribute learning."""
        observed_at = float(observed_at or time.monotonic())
        phase = int(getattr(learner, "steps", 0) or 0)
        observation = FactorObservation(observed_at=observed_at,
                                        context={"coverage_phase": phase})
        observation.add("action", str(action), kind="category")
        observation.add("state.family", Learner._key_probe_family(state), kind="category")
        if self._keyboard_action_names(action):
            gate = self._key_action_gate(learner, state, action)
            observation.add("input.key.scope", str(gate.get("scope", "unknown")), kind="category")
            observation.add("input.key.risk", float(gate.get("risk", 0.0)), kind="scalar",
                            metadata={"scale": 1.0})
            observation.add("input.key.evidence", float(gate.get("evidence", 0.0)), kind="scalar",
                            metadata={"scale": 1.0})
        observation.add("time.elapsed", max(0.0, float(elapsed or 0.0)), kind="scalar",
                        metadata={"scale": max(0.25, float(elapsed or 0.0), 1.0)})
        observation.add("screen.visual_change", max(0.0, float(visual_change or 0.0)),
                        kind="scalar", metadata={"scale": 0.08})
        observation.add("state.velocity", float(self._state_velocity or 0.0), kind="scalar",
                        metadata={"scale": max(0.5, abs(float(self._state_velocity or 0.0)))})
        observation.add("state.acceleration", float(self._state_acceleration or 0.0), kind="scalar",
                        metadata={"scale": max(0.5, abs(float(self._state_acceleration or 0.0)))})
        if pre_action_rate is not None:
            try:
                rate = float(pre_action_rate)
                if math.isfinite(rate):
                    observation.add("time.passive_rate", rate, kind="scalar",
                                    metadata={"scale": max(0.5, abs(rate))})
            except (TypeError, ValueError, OverflowError) as exc:
                observation.add("time.passive_rate", None, kind="missing", confidence=0.0,
                                metadata={"error": type(exc).__name__},
                                observation_state="sensor_failed")
        observation.add("screen.visual_signature", str(self._visual_cache or "v0"), kind="category")
        observation.add("screen.semantic_scene", str(self._semantic_scene or "h0"), kind="category")
        observation.add("window.control_graph", str(self._control_graph_hash or "c0"), kind="category")
        observation.add("window.operation_scope", str(self._operation_scope_signature or "none"), kind="category")
        absolute_target_rect = self._current_roi()
        observation.add(
            "target.context_signature",
            self._target_context_signature(absolute_target_rect) if absolute_target_rect else "ctx0",
            kind="category")
        for source_name, health in self._source_health.items():
            observation.add(f"source.{source_name}.valid", bool(health.get("valid", False)), kind="category")
            observation.add(f"source.{source_name}.state", str(health.get("observation_state", "observed")), kind="category")
            observation.add(f"source.{source_name}.confidence", float(health.get("confidence", 0.0) or 0.0),
                            kind="scalar", metadata={"scale": 1.0})
        observation.add("screen.motion", int(self._motion_mask or 0), kind="scalar",
                        metadata={"scale": float(0xFFFFFF)})
        observation.add("scene.number_count", len(numbers or {}), kind="scalar",
                        metadata={"scale": max(1.0, float(len(numbers or {})))})

        history = "|".join(getattr(learner, "action_trace", [])[-24:]) if learner is not None else ""
        if history:
            observation.add("history.actions", history, kind="signature")

        try:
            point = Learner._mouse_point(action)
            if point is not None:
                observation.add("mouse.position", tuple(float(v) for v in point), kind="vector",
                                metadata={"scale": 1.0})
        except (TypeError, ValueError, IndexError) as exc:
            observation.add("mouse.position", None, kind="missing", confidence=0.0,
                            metadata={"error": type(exc).__name__},
                            observation_state="sensor_failed")
        if os.name == "nt" and user32 is not None:
            try:
                pt = POINT()
                if user32.GetCursorPos(ctypes.byref(pt)):
                    rect = self._adaptive_operation_rect(refresh=False, reason="factor-cursor") or virtual_screen_rect()
                    width = max(1.0, float(rect[2] - rect[0]))
                    height = max(1.0, float(rect[3] - rect[1]))
                    cursor = ((float(pt.x) - rect[0]) / width, (float(pt.y) - rect[1]) / height)
                    observation.add("mouse.cursor", cursor, kind="vector", metadata={"scale": 1.0})
            except (OSError, ValueError, TypeError) as exc:
                observation.add("mouse.cursor", None, kind="missing", confidence=0.0,
                                metadata={"error": type(exc).__name__},
                                observation_state="sensor_failed")
            try:
                foreground = int(self._foreground_root() or 0)
                if foreground:
                    identity = environment_identity_for_window(foreground)
                    token = "|".join(str(identity.get(key, "")) for key in ("exe_hash", "class", "title"))
                    observation.add("window.foreground", token, kind="category")
            except (OSError, ValueError, TypeError) as exc:
                observation.add("window.foreground", None, kind="missing", confidence=0.0,
                                metadata={"error": type(exc).__name__},
                                observation_state="sensor_failed")
        try:
            target_identity = self._environment_identity(force=False)
            token = "|".join(str(target_identity.get(key, "")) for key in ("exe_hash", "class", "title"))
            observation.add("window.target", token, kind="category")
        except (OSError, ValueError, TypeError) as exc:
            observation.add("window.target", None, kind="missing", confidence=0.0,
                            metadata={"error": type(exc).__name__},
                            observation_state="sensor_failed")

        # Every numeric entity feature is present in FactorObservation.  To keep the
        # relation update cost bounded, these absolute-value factors use deterministic
        # rotating coverage; attribute *changes* are always learned immediately.
        for entity_id, item in dict(numbers or {}).items():
            if not isinstance(item, dict):
                continue
            registry = Learner._snapshot_feature_registry(item)
            for feature_name, feature in registry.items():
                metadata = dict(feature.metadata or {})
                metadata["lazy"] = True
                if feature.kind == "scalar" and "scale" not in metadata:
                    try:
                        value = abs(float(feature.value))
                        metadata["scale"] = max(1.0, value * 0.05)
                    except Exception:
                        metadata["scale"] = 1.0
                observation.factors[f"number:{entity_id}.{feature_name}"] = FeatureObservation(
                    value=feature.value, kind=feature.kind, confidence=feature.confidence,
                    observed_at=observed_at, metadata=metadata,
                    observation_state=feature.observation_state)
        return observation

    def _set_source_health(self, source, valid, confidence=0.0, failure_reason="", observation_state=None):
        source = str(source or "unknown")
        try:
            confidence = max(0.0, min(1.0, float(confidence)))
        except Exception:
            confidence = 0.0
        if observation_state is None:
            if valid and confidence >= 0.18:
                observation_state = "observed"
            elif valid:
                observation_state = "low_confidence"
            else:
                observation_state = "missing"
        observation_state = str(observation_state or "missing").lower()
        if observation_state not in FeatureObservation.VALID_STATES:
            observation_state = "missing"
        # ``valid`` means suitable for causal learning, not merely that a function
        # returned. Low-confidence/missing/sensor-failed/not-sampled remain explicit.
        causal_valid = bool(valid) and observation_state == "observed"
        self._source_health[source] = {
            "valid": causal_valid,
            "confidence": confidence,
            "failure_reason": str(failure_reason or "")[:160],
            "observation_state": observation_state,
            "updated_at": time.monotonic(),
        }

    def _measurement_health(self, before_numbers=None, after_numbers=None, target_confidence=None):
        """Return observation validity without turning sensor failures into action effects."""
        sources = {name: dict(value) for name, value in self._source_health.items()}
        reasons = []
        confidence_parts = []
        target = sources.get("target", {})
        if target_confidence is not None:
            try:
                confidence_parts.append(max(0.0, min(1.0, float(target_confidence))))
            except Exception:
                reasons.append("target_confidence_invalid")
        if not bool(target.get("valid", False)):
            reasons.append(str(target.get("failure_reason") or "target_not_observed"))
        elif target.get("confidence") is not None:
            confidence_parts.append(float(target.get("confidence", 0.0) or 0.0))

        scene = sources.get("scene_ocr", {})
        scene_recent = time.monotonic() - float(scene.get("updated_at", 0.0) or 0.0) < max(2.0, LEARNING_CONFIG.semantic_refresh_seconds * 1.8)
        if scene_recent and not bool(scene.get("valid", True)):
            reasons.append(str(scene.get("failure_reason") or "scene_not_observed"))
        elif scene_recent:
            confidence_parts.append(float(scene.get("confidence", 0.0) or 0.0))
        capture = sources.get("capture", {})
        capture_recent = time.monotonic() - float(capture.get("updated_at", 0.0) or 0.0) < max(2.0, LEARNING_CONFIG.semantic_refresh_seconds * 1.8)
        if capture_recent and not bool(capture.get("valid", True)):
            reasons.append(str(capture.get("failure_reason") or "capture_not_observed"))
        elif capture_recent:
            confidence_parts.append(float(capture.get("confidence", 0.0) or 0.0))

        before_count = len(before_numbers or {})
        after_count = len(after_numbers or {})
        if before_count >= 3 and after_count < before_count:
            retained = after_count / max(1.0, float(before_count))
            # Only treat a large topology loss as a measurement problem when the
            # latest scene OCR itself is weak/recent. A deliberate UI change can still
            # be learned once a healthy follow-up scan confirms it.
            if (scene_recent and str(scene.get("observation_state", "")) != "confirmed_absent" and
                    retained < 0.55 and float(scene.get("confidence", 0.0) or 0.0) < 0.70):
                reasons.append("scene_entity_drop_unconfirmed")

        confidence = min(confidence_parts) if confidence_parts else 0.0
        return {
            "valid": not reasons,
            "confidence": max(0.0, min(1.0, confidence)),
            "failure_reason": ";".join(dict.fromkeys(reason for reason in reasons if reason)),
            "source_health": sources,
        }

    def _target_context_signature(self, rect):
        try:
            x1, y1, x2, y2 = [float(v) for v in rect]
        except Exception:
            return "ctx0"
        cx, cy = (x1 + x2) * 0.5, (y1 + y2) * 0.5
        basis = self._target_client_rect() or virtual_screen_rect()
        bw = max(1.0, float(basis[2]) - float(basis[0]))
        bh = max(1.0, float(basis[3]) - float(basis[1]))
        tfx = max(0.0, min(1.0, (cx - float(basis[0])) / bw))
        tfy = max(0.0, min(1.0, (cy - float(basis[1])) / bh))
        tokens = []

        target = self.target_entity
        role = str(getattr(target, "role", "UNKNOWN") or "UNKNOWN").upper() if target else "UNKNOWN"
        tokens.append(f"target-role:{role}")

        nearby_numbers = []
        for entity in self.scene_numbers.values():
            if not isinstance(entity, NumberEntity) or bool(entity.is_target):
                continue
            try:
                ex, ey = entity.center
                dx, dy = (float(ex) - cx) / bw, (float(ey) - cy) / bh
                distance = math.hypot(dx, dy)
            except Exception:
                continue
            if distance > VISION_CONFIG.nearby_radius_fraction:
                continue
            label = self._normalized_number_label(entity.label)
            label_hash = hashlib.sha1(label.encode("utf-8", "replace")).hexdigest()[:6] if label else "none"
            relx = max(-4, min(4, int(round(dx * 12))))
            rely = max(-4, min(4, int(round(dy * 12))))
            nearby_numbers.append((distance,
                f"num:{entity.role}:{label_hash}:{str(entity.unit or '')[:20]}:r{rely}:c{relx}"))
        for _distance, token in sorted(nearby_numbers)[:VISION_CONFIG.context_number_limit]:
            tokens.append(token)

        nearby_controls = []
        for control in self._controls.values():
            try:
                fx, fy = control.get("center", (None, None))
                fx, fy = float(fx), float(fy)
            except Exception:
                continue
            distance = math.hypot(fx - tfx, fy - tfy)
            if distance > VISION_CONFIG.nearby_radius_fraction * 1.25:
                continue
            text = unicodedata.normalize("NFKC", str(control.get("text", ""))).strip().lower()
            text = re.sub(r"\d+(?:[.,]\d+)?", "#", text)
            text_hash = hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:6] if text else "none"
            relx = max(-4, min(4, int(round((fx - tfx) * 12))))
            rely = max(-4, min(4, int(round((fy - tfy) * 12))))
            nearby_controls.append((distance,
                f"ctl:{control.get('role','control')}:{control.get('action_type','unknown')}:"
                f"{text_hash}:r{rely}:c{relx}"))
        for _distance, token in sorted(nearby_controls)[:VISION_CONFIG.context_control_limit]:
            tokens.append(token)

        # Page-wide semantic tokens are only a fallback when no local structure is
        # available; otherwise unrelated UI changes would unnecessarily fork profiles.
        if len(tokens) <= 1:
            for token in sorted(self._semantic_tokens)[:VISION_CONFIG.context_semantic_limit]:
                tokens.append(f"sem:{token}")
        raw = "|".join(sorted(set(tokens)))
        return "ctx" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:12]

    def _stable_target_structure_fingerprint(self):
        """Describe durable nearby UI structure without using mutable number appearance."""
        target = self.target_entity
        tokens = []
        if target is not None:
            for token in self._target_relation_tokens(target):
                tokens.append(f"relation:{token}")
        try:
            rect = self._current_roi()
            if rect:
                tcx = (float(rect[0]) + float(rect[2])) * 0.5
                tcy = (float(rect[1]) + float(rect[3])) * 0.5
                client = self._target_client_rect() or virtual_screen_rect()
                cw = max(1.0, float(client[2] - client[0]))
                ch = max(1.0, float(client[3] - client[1]))
                nearby = []
                for control in self._controls.values():
                    bbox = control.get("bbox")
                    if not bbox or len(bbox) != 4:
                        continue
                    ccx = (float(bbox[0]) + float(bbox[2])) * 0.5
                    ccy = (float(bbox[1]) + float(bbox[3])) * 0.5
                    dx, dy = (ccx - tcx) / cw, (ccy - tcy) / ch
                    distance = math.hypot(dx, dy)
                    if distance > 0.42:
                        continue
                    text = unicodedata.normalize("NFKC", str(control.get("text", ""))).strip().lower()
                    text = re.sub(r"[-+]?\d+(?:[.,]\d+)?(?:e[-+]?\d+)?", "#", text)
                    # Non-numeric surrounding text is a stable landmark; the target
                    # number value itself is never placed in the identity.
                    text_key = (hashlib.sha1(text.encode("utf-8", "replace")).hexdigest()[:8]
                                if text and text != "#" else "none")
                    if abs(dx) <= 0.035 and abs(dy) <= 0.035:
                        relation = "overlap"
                    elif abs(dx) >= abs(dy):
                        relation = "right" if dx > 0 else "left"
                    else:
                        relation = "below" if dy > 0 else "above"
                    distance_band = min(5, int(distance / 0.07))
                    nearby.append((distance,
                        f"near:{relation}:{distance_band}:{control.get('role','control')}:"
                        f"{control.get('action_type','unknown')}:{control.get('control_id','')}:{text_key}"))
                tokens.extend(token for _distance, token in sorted(nearby)[:14])
        except Exception as exc:
            self._log_once("profile_structure", "profile_structure_error", type(exc).__name__)

        # A topology summary helps distinguish two unlabeled targets in the same
        # executable even when neither has a stable control id.
        topology = []
        for control in self._controls.values():
            role = str(control.get("role", "control"))
            action_type = str(control.get("action_type", "unknown"))
            patterns = ",".join(sorted(str(x) for x in control.get("uia_patterns", ())))
            topology.append(f"{role}:{action_type}:{patterns}")
        if topology:
            counts = {}
            for token in topology:
                counts[token] = counts.get(token, 0) + 1
            tokens.extend(f"topology:{token}:{count}" for token, count in sorted(counts.items())[:24])
        if not tokens:
            return "struct0"
        raw = "|".join(sorted(set(tokens)))
        return "struct" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:14]

    def _profile_file(self):
        env = self._environment_identity(force=True)
        target = self.target_entity
        label = self._normalized_number_label(getattr(target, "label", "")) if target else ""
        control_id = str(getattr(target, "control_id", "") or "") if target else ""
        structure_key = self._stable_target_structure_fingerprint()

        # The database identity contains only durable application/target anchors.
        # Layout, nearby controls, screen topology and current structure are context
        # signatures *inside* this long-lived profile, so resizing or moving the UI
        # does not silently discard prior learning.
        durable_anchor = control_id or label or "unlabeled-target"
        identity_parts = [
            "env", str(env.get("exe", "unknown")), str(env.get("exe_hash", "unknown")),
            str(env.get("class", "unknown")), "target", durable_anchor,
        ]
        raw = "|".join(identity_parts)
        key = hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:20]
        profile = self.data_dir / f"学习状态-{key}.db"
        self._log_runtime(
            "environment",
            f"exe={env.get('exe')} class={env.get('class')} title={env.get('title')} "
            f"context_structure={structure_key} durable_target={durable_anchor[:80]} profile={key}")
        return profile

    @staticmethod
    def _action_uses_virtual_coordinates(action):
        try:
            parts = str(action).split(":")
            if parts[0] in {"mouse", "pointer"}:
                return len(parts) == 4 and parts[1] == "v"
            if parts[0] in {"click", "tap"}:
                return len(parts) >= 5 and parts[2] == "v"
            if parts[0] == "wheel":
                return len(parts) == 6 and parts[3] == "v"
            if parts[0] == "drag":
                return len(parts) == 8 and parts[2] == "v"
        except Exception:
            pass
        return False

    @classmethod
    def _spatial_action_identity_stable(cls, action):
        raw = str(action or "")
        return raw.startswith(("click:control:", "uia:")) or cls._action_uses_virtual_coordinates(raw)

    @staticmethod
    def _action_point_fraction(action):
        try:
            parts = str(action).split(":")
            if parts[0] in {"mouse", "pointer"}:
                if len(parts) == 3:
                    grid, x, y = 20.0, float(parts[1]), float(parts[2])
                elif len(parts) == 4 and parts[1] == "v":
                    grid, x, y = 10000.0, float(parts[2]), float(parts[3])
                else:
                    grid, x, y = float(parts[1]), float(parts[2]), float(parts[3])
            elif parts[0] == "click":
                grid = 10000.0 if parts[2] == "v" else float(parts[2])
                x, y = float(parts[3]), float(parts[4])
            elif parts[0] == "wheel":
                grid = 10000.0 if parts[3] == "v" else float(parts[3])
                x, y = float(parts[4]), float(parts[5])
            elif parts[0] == "drag":
                grid = 10000.0 if parts[2] == "v" else float(parts[2])
                x, y = float(parts[3]), float(parts[4])
            elif parts[0] == "tap" and len(parts) == 8:
                grid = 10000.0 if parts[2] == "v" else float(parts[2])
                x, y = float(parts[3]), float(parts[4])
            else:
                return None
            grid = max(1.0, grid)
            return max(0.0, min(1.0, x / grid)), max(0.0, min(1.0, y / grid))
        except Exception:
            return None

    def _scope_fraction_to_virtual(self, fx, fy, rect=None):
        cr = rect or self._adaptive_operation_rect(refresh=False, reason="coordinate-map")
        vr = virtual_screen_rect()
        if not cr or not vr:
            return None
        vw, vh = max(1.0, vr[2] - vr[0]), max(1.0, vr[3] - vr[1])
        x = cr[0] + max(0.0, min(1.0, float(fx))) * (cr[2] - cr[0])
        y = cr[1] + max(0.0, min(1.0, float(fy))) * (cr[3] - cr[1])
        return (max(0.0, min(1.0, (x - vr[0]) / vw)),
                max(0.0, min(1.0, (y - vr[1]) / vh)))

    def _virtual_fraction_to_scope(self, fx, fy, rect=None):
        cr = rect or self._adaptive_operation_rect(refresh=False, reason="coordinate-map")
        vr = virtual_screen_rect()
        if not cr or not vr:
            return None
        cw, ch = max(1.0, cr[2] - cr[0]), max(1.0, cr[3] - cr[1])
        x = vr[0] + max(0.0, min(1.0, float(fx))) * (vr[2] - vr[0])
        y = vr[1] + max(0.0, min(1.0, float(fy))) * (vr[3] - vr[1])
        return ((x - cr[0]) / cw, (y - cr[1]) / ch)

    def _point_is_dangerous(self, fx, fy):
        for x1, y1, x2, y2 in self._danger_regions:
            if x1 <= fx <= x2 and y1 <= fy <= y2:
                return True
        return False

    def _action_is_dangerous(self, action):
        for part in Learner._macro_parts(action):
            if part.startswith(("key:", "hold:", "pulse:", "chord:")):
                if not self._keyboard_action_allowed(part):
                    return True
                if (self._active_learner is not None and self._last_decision_state and
                        not self._keyboard_action_evidence_allowed(
                            part, self._last_decision_state, self._active_learner)):
                    return True
            if part.startswith("click:control:") or part.startswith("uia:"):
                control_id = (part.split(":", 2)[2] if part.startswith("click:control:")
                              else self._uia_control_id_from_action(part))
                control = self._controls.get(control_id, {})
                if not control or control.get("danger") or not control.get("enabled", True):
                    return True
                continue
            point = self._action_fraction(part)
            scope_point = self._virtual_fraction_to_scope(*point) if point else None
            if scope_point and self._point_is_dangerous(*scope_point):
                return True
        return False

    def _screen_ready(self):
        client = self._target_client_rect()
        roi = self._current_roi()
        scope = self._adaptive_operation_rect(refresh=False, reason="ready")
        return bool(client and client[2] - client[0] >= 80 and client[3] - client[1] >= 80 and roi and scope)

    @staticmethod
    def _parameter_fraction(seed, index=0):
        digest = hashlib.sha1(str(seed).encode("utf-8", "replace")).digest()
        offset = int.from_bytes(digest[:8], "big") / float(2 ** 64)
        return (offset + (int(index) + 1) * 0.6180339887498949) % 1.0

    @staticmethod
    def _key_evidence(learner, state, action):
        q, n, _variance = learner._value(learner.stats.get(action, {}))
        iq, influence_n, _influence_variance = learner.influence_value(state, action)
        effect_q, effect_n, _effect_uncertainty = learner._effect_value(state, action)
        evidence_n = float(n) + float(influence_n) * 0.35 + float(effect_n) * 0.20
        values = []
        if n:
            values.append((q, min(3.0, 0.7 + math.log1p(n))))
        if influence_n:
            values.append((iq, min(2.2, 0.55 + math.log1p(influence_n))))
        if effect_n:
            values.append((effect_q, min(2.0, 0.45 + math.log1p(effect_n))))
        if not values:
            return 0.0, 0.0
        denominator = max(1e-9, sum(weight for _value, weight in values))
        return sum(value * weight for value, weight in values) / denominator, evidence_n

    @staticmethod
    def _base_key_system_risk(name):
        vk = KEY_NAME_TO_VK.get(str(name))
        if vk is None:
            return 0.35
        return float(SYSTEM_KEY_RISK.get(int(vk), 0.12))

    def _key_action_gate(self, learner, state, action):
        """Separate key usefulness learning from operating-system side-effect risk.

        Ordinary unknown VKs can be cold-probed.  System-facing VKs remain in the
        theoretical universe but enter an execution candidate pool only after screen/
        UIA hints or target-application history provides evidence for them.
        """
        names = self._keyboard_action_names(action)
        if not names:
            return {"scope": "not-keyboard", "risk": 0.0, "evidence": 1.0,
                    "semantic_evidence": 0.0, "allowed": True}
        base_risk = max(self._base_key_system_risk(name) for name in names)
        semantic_evidence = 0.0
        for name in names:
            atomic = f"key:{name}"
            if atomic in self._dynamic_key_actions:
                semantic_evidence += 1.0
        if str(action) in self._dynamic_key_actions:
            semantic_evidence += 0.65

        learned_value = 0.0
        learned_samples = 0.0
        probe_samples = 0.0
        posterior_support = 0.0
        input_samples = 0.0
        input_probability = 0.5
        if learner is not None:
            for name in names:
                atomic = f"key:{name}"
                value, samples = self._key_evidence(learner, state, atomic)
                learned_value = max(learned_value, float(value))
                learned_samples += float(samples)
                probe = learner.key_probe_status(name, state)
                ps = float(probe.get("samples", 0.0) or 0.0)
                probe_samples += ps
                posterior = float(probe.get("effect_probability", 0.5) or 0.5)
                if ps > 0.0:
                    posterior_support += max(0.0, posterior - 0.5) * min(2.0, ps)
            input_probability, input_samples = learner.input_success_probability(action)

        history_evidence = learned_samples + probe_samples * 0.65 + input_samples * 0.20
        positive_feedback = max(0.0, learned_value) * min(4.0, history_evidence + 1.0)
        evidence = semantic_evidence + min(4.5, history_evidence * 0.45 +
                                            posterior_support + positive_feedback * 0.55)
        learned_side_risk = 0.0
        risk_samples = 0.0
        if learner is not None:
            learned_side_risk, risk_samples = learner.side_effect_risk(action, state)
        side_trust = 1.0 - math.exp(-max(0.0, float(risk_samples)) / 3.0)
        risk = max(base_risk, float(learned_side_risk) * side_trust)

        guarded = base_risk >= 0.55
        if not guarded:
            scope = "cold-probe"
            allowed = True
        else:
            threshold = 0.90 + max(0.0, base_risk - 0.55) * 1.55
            semantic_unlock = semantic_evidence >= 0.95
            history_unlock = (history_evidence >= 2.4 and learned_value > 0.008 and
                              (posterior_support > 0.08 or input_probability >= 0.72))
            allowed = bool((semantic_unlock or history_unlock) and risk < 0.93)
            scope = "evidence-unlocked" if allowed else "candidate-only"
        result = {"scope": scope, "risk": max(0.0, min(1.0, risk)),
                  "evidence": float(evidence), "semantic_evidence": float(semantic_evidence),
                  "allowed": bool(allowed)}
        self._key_action_gates[str(action)] = result
        return result

    def _keyboard_action_evidence_allowed(self, action, state, learner):
        return bool(self._key_action_gate(learner, state, action).get("allowed", False))

    def _adaptive_candidate_limits(self, learner, stagnant):
        latency = float(getattr(self.reader, "latency", 0.25) or 0.25)
        target = float(getattr(self.hardware, "latency_target", 0.35) or 0.35)
        pressure = max(0.65, min(1.55, latency / max(0.05, target)))
        exploration = min(1.0, max(0.0, float(stagnant) / max(1.0, LEARNING_CONFIG.stagnation_high)))
        success_rate = float(getattr(learner, "positive", 0)) / max(1.0, float(getattr(learner, "steps", 0)))
        efficiency = max(0.72, min(1.16, 1.05 - success_rate * 0.55))
        keyboard = int(round((EXPLORATION_CONFIG.keyboard_candidate_base +
                              exploration * (EXPLORATION_CONFIG.keyboard_candidate_max -
                                             EXPLORATION_CONFIG.keyboard_candidate_base)) *
                             efficiency / max(0.82, pressure)))
        mouse = int(round((EXPLORATION_CONFIG.mouse_candidate_base +
                           exploration * (EXPLORATION_CONFIG.mouse_candidate_max -
                                          EXPLORATION_CONFIG.mouse_candidate_base)) *
                          efficiency / max(0.82, pressure)))
        keyboard = max(24, min(EXPLORATION_CONFIG.keyboard_candidate_max, keyboard))
        mouse = max(60, min(EXPLORATION_CONFIG.mouse_candidate_max, mouse))
        return keyboard, mouse

    def _learned_key_actions(self, learner, state):
        ranked = []
        for action in ATOMIC_KEY_ACTIONS:
            value, samples = self._key_evidence(learner, state, action)
            name = action.split(":", 1)[1]
            probe = learner.key_probe_status(name, state)
            posterior = float(probe.get("effect_probability", 0.5))
            probe_samples = float(probe.get("samples", 0.0))
            # Single keys are always discoverable; only temporal descendants require
            # positive target/scene influence evidence and a reasonably stable focus.
            effective_samples = samples + probe_samples * 0.55
            threshold = 0.54 + 0.14 / math.sqrt(effective_samples + 1.0)
            if effective_samples >= 1.8 and value > 0.012 and posterior >= threshold:
                ranked.append((value + (posterior - 0.5) * 0.16 +
                               min(0.18, math.log1p(effective_samples) * 0.025), action))
        ranked.sort(reverse=True)
        return [action for _value, action in ranked]

    @staticmethod
    def _modifier_key_name(name):
        vk = KEY_NAME_TO_VK.get(str(name))
        return vk in {0x10, 0x11, 0x12, 0x5B, 0x5C, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5}

    def _key_combination_ready(self, learner, state, name):
        action = f"key:{name}"
        value, samples = self._key_evidence(learner, state, action)
        probe = learner.key_probe_status(name, state)
        posterior = float(probe.get("effect_probability", 0.5))
        evidence = samples + float(probe.get("samples", 0.0)) * 0.60
        modifier = self._modifier_key_name(name)
        needed = 3.4 if modifier else 2.0
        probability_needed = 0.68 if modifier else 0.58
        return evidence >= needed and posterior >= probability_needed and value > 0.010

    def _chord_side_effect_ready(self, learner, state, names, stagnant=0):
        names = tuple(dict.fromkeys(str(name) for name in names if name))
        if len(names) < 2:
            return False
        candidate = "chord:" + "+".join(names)
        risk, _evidence, uncertainty = learner.predict_side_effect_risk(candidate, state)
        threshold = min(0.58, 0.46 + max(0, int(stagnant)) * 0.0025)
        # Unknown interaction risk is explicit. It can be overcome by evidence and
        # sustained stagnation, but combinations predicted to be destructive are not
        # promoted merely because each component key looked useful in isolation.
        return risk + uncertainty * 0.34 <= threshold

    def _keyboard_candidates(self, learner, stagnant, state=""):
        remembered = (learner.preferred_actions("key:", limit=18) +
                      learner.preferred_actions("hold:", limit=12) +
                      learner.preferred_actions("pulse:", limit=12) +
                      learner.preferred_actions("chord:", limit=10))
        remembered = [action for action in remembered if self._keyboard_action_allowed(action)]
        hinted = sorted(action for action in self._dynamic_key_actions
                        if self._keyboard_action_allowed(action))[:16]
        learned_atomic = self._learned_key_actions(learner, state)
        learned_names = {action.split(":", 1)[1] for action in learned_atomic}
        filtered_hinted = []
        for action in hinted:
            raw = str(action)
            if raw.startswith("key:"):
                filtered_hinted.append(action)
            elif raw.startswith(("hold:", "pulse:")):
                parts = raw.split(":")
                if len(parts) >= 2 and parts[1] in learned_names:
                    filtered_hinted.append(action)
            elif raw.startswith("chord:"):
                names = raw.split(":", 2)[1].split("+")
                if (len(names) >= 2 and
                        all(self._key_combination_ready(learner, state, name) for name in names) and
                        self._chord_side_effect_ready(learner, state, names, stagnant)):
                    filtered_hinted.append(action)
        hinted = filtered_hinted
        filtered_remembered = []
        for action in remembered:
            raw = str(action)
            if raw.startswith("key:"):
                filtered_remembered.append(action)
            elif raw.startswith(("hold:", "pulse:")):
                parts = raw.split(":")
                if len(parts) >= 2 and parts[1] in learned_names:
                    filtered_remembered.append(action)
            elif raw.startswith("chord:"):
                names = raw.split(":", 2)[1].split("+")
                if (len(names) >= 2 and all(name in learned_names for name in names) and
                        all(self._key_combination_ready(learner, state, name) for name in names) and
                        self._chord_side_effect_ready(learner, state, names, stagnant)):
                    filtered_remembered.append(action)
        remembered = filtered_remembered

        # Every non-ESC VK remains in the theoretical universe. Ordinary unknown
        # keys enter the cold-start bandit immediately; system-facing keys stay in
        # a candidate-only pool until semantic/UIA/history evidence unlocks them.
        universe = list(ATOMIC_KEY_ACTIONS)
        probe_budget = min(
            len(universe), EXPLORATION_CONFIG.key_probe_max,
            EXPLORATION_CONFIG.key_probe_base +
            min(EXPLORATION_CONFIG.key_probe_stagnation_bonus, max(0, int(stagnant))))
        bandit = []
        untested = []
        for candidate in universe:
            name = candidate.split(":", 1)[1]
            gate = self._key_action_gate(learner, state, candidate)
            if not gate.get("allowed", False):
                continue
            if not learner.key_probe_allowed(name, state, stagnant):
                continue
            value, value_samples = self._key_evidence(learner, state, candidate)
            status = learner.key_probe_status(name, state)
            probe_samples = float(status.get("samples", 0.0))
            samples = max(probe_samples, float(value_samples))
            probability = max(1e-4, min(1.0 - 1e-4, float(status.get("effect_probability", 0.5))))
            posterior_total = max(2.0, probe_samples + 2.0)
            alpha = max(0.25, probability * posterior_total)
            beta = max(0.25, (1.0 - probability) * posterior_total)
            try:
                thompson = random.betavariate(alpha, beta)
            except (ValueError, OverflowError):
                thompson = probability
            ucb = math.sqrt(math.log(learner.steps + len(universe) + 2.0) / (samples + 1.0))
            uncertainty_value = math.sqrt(max(0.0, probability * (1.0 - probability)))
            information_value = 1.0 / math.sqrt(samples + 1.0)
            inert_penalty = min(0.55, max(0.0, -value) * math.log1p(samples) +
                                float(status.get("miss_count", 0)) * EXPLORATION_CONFIG.inert_miss_weight)
            input_probability, input_samples = learner.input_success_probability(candidate)
            reliability_penalty = (1.0 - input_probability) * min(0.30, math.log1p(input_samples) * 0.08)
            side_risk, side_samples = learner.side_effect_risk(candidate, state)
            risk_evidence = 1.0 - math.exp(-max(0.0, side_samples) / 4.0)
            side_effect_penalty = max(0.0, min(0.70, side_risk * risk_evidence * 0.70))
            score = (thompson + EXPLORATION_CONFIG.uncertainty_value_weight * ucb +
                     EXPLORATION_CONFIG.information_value_weight * (uncertainty_value + information_value) +
                     max(-0.30, min(0.30, value * 0.12)) - inert_penalty - reliability_penalty -
                     side_effect_penalty)
            bandit.append((score, candidate, probe_samples))
            if probe_samples <= 1e-9:
                # Coverage ledger: deterministic age/hash order guarantees every
                # still-unknown VK receives a state-family trial eventually.
                last_step = int(status.get("last_probe_step", -1))
                seed = int(hashlib.sha1((status.get("key", "") + candidate).encode(
                    "utf-8", "replace")).hexdigest()[:8], 16)
                untested.append((last_step, seed, candidate))

        eligible_count = max(1, len(bandit))
        unknown_ratio = min(1.0, len(untested) / eligible_count)
        coverage_quota = (min(len(untested), max(1, int(math.ceil(
            probe_budget * max(0.35, unknown_ratio))))) if untested and probe_budget else 0)
        coverage_probes = [candidate for _last, _seed, candidate in
                           sorted(untested, key=lambda item: (item[0], item[1]))[:coverage_quota]]
        coverage_set = set(coverage_probes)
        ranked_bandit = [candidate for _score, candidate, _samples in
                         sorted(bandit, key=lambda item: item[0], reverse=True)
                         if candidate not in coverage_set]
        probes = coverage_probes + ranked_bandit[:max(0, probe_budget - len(coverage_probes))]
        # Put coverage probes first so the later adaptive candidate limit cannot
        # starve rare/unknown keys behind already-known actions.
        actions = list(dict.fromkeys(coverage_probes + remembered + hinted +
                                     learned_atomic[:EXPLORATION_CONFIG.learned_atomic_limit] + probes))

        # Temporal parameters begin with broad log-uniform coverage. Successful
        # frontier values expand the learned range rather than hitting permanent caps.
        parameter_keys = list(dict.fromkeys(learned_atomic[:10]))
        for index, atomic in enumerate(parameter_keys):
            name = atomic.split(":", 1)[1]
            fraction = self._parameter_fraction(f"hold:{name}", learner.steps + index)
            duration = learner.sample_parameter(f"hold.{name}.duration_ms", 40, 3000,
                                                fraction, integer=True, log_scale=True)
            actions.append(f"hold:{name}:{duration}")

            press_fraction = self._parameter_fraction(f"press:{name}", learner.steps + index * 3)
            interval_fraction = self._parameter_fraction(f"interval:{name}", learner.steps + index * 5)
            repeat_fraction = self._parameter_fraction(f"repeat:{name}", learner.steps + index * 7)
            press_ms = learner.sample_parameter("pulse.press_ms", 25, 1200, press_fraction,
                                                integer=True, log_scale=True)
            interval_ms = learner.sample_parameter("pulse.interval_ms", 25, 900, interval_fraction,
                                                   integer=True, log_scale=True)
            repeat_count = learner.sample_parameter("pulse.repeat", 2, 10, repeat_fraction,
                                                     integer=True, log_scale=False)
            actions.append(f"pulse:{name}:{press_ms}:{repeat_count}:{interval_ms}")

        if len(learned_atomic) >= 2:
            ready = [action for action in learned_atomic
                     if self._key_combination_ready(learner, state, action.split(":", 1)[1])]
            anchors = ready[:min(10, 4 + max(0, stagnant) // 9)]
            partners = ready[:18]
            if len(partners) >= 2:
                for index, anchor in enumerate(anchors):
                    partner_index = (learner.steps * 3 + index * 7) % len(partners)
                    partner = partners[partner_index]
                    left, right = anchor.split(":", 1)[1], partner.split(":", 1)[1]
                    if left == right:
                        partner = partners[(partner_index + 1) % len(partners)]
                        right = partner.split(":", 1)[1]
                    if left == right:
                        continue
                    if not self._chord_side_effect_ready(learner, state, (left, right), stagnant):
                        continue
                    fraction = self._parameter_fraction(f"chord:{left}+{right}", learner.steps + index)
                    duration = learner.sample_parameter("chord.duration_ms", 35, 2200, fraction,
                                                        integer=True, log_scale=True)
                    actions.append(f"chord:{left}+{right}:{duration}")
        keyboard_limit, _mouse_limit = self._adaptive_candidate_limits(learner, stagnant)
        return [action for action in dict.fromkeys(actions)
                if self._keyboard_action_allowed(action) and
                self._keyboard_action_evidence_allowed(action, state, learner) and
                self._keyboard_action_probe_allowed(action, state, learner, stagnant)][:keyboard_limit]

    @staticmethod
    def _keyboard_action_names(action):
        raw = str(action or "")
        try:
            if raw.startswith("key:"):
                return (raw.split(":", 1)[1],)
            if raw.startswith(("hold:", "pulse:")):
                return (raw.split(":")[1],)
            if raw.startswith("chord:"):
                return tuple(raw.split(":", 2)[1].split("+"))
        except Exception:
            return ()
        return ()

    def _keyboard_action_probe_allowed(self, action, state, learner, stagnant=0):
        names = self._keyboard_action_names(action)
        if not names:
            return True
        return all(learner.key_probe_allowed(name, state, stagnant) for name in names)

    def _keyboard_action_allowed(self, action):
        raw = str(action or "")
        if raw.startswith("key:"):
            name = raw.split(":", 1)[1]
            return name in KEY_NAME_TO_VK and KEY_NAME_TO_VK[name] != VK_ESCAPE
        if raw.startswith("hold:"):
            try:
                _kind, name, milliseconds = raw.split(":")
                return (name in KEY_NAME_TO_VK and KEY_NAME_TO_VK[name] != VK_ESCAPE and
                        1 <= int(milliseconds) <= 600000)
            except Exception:
                return False
        if raw.startswith("pulse:"):
            try:
                _kind, name, milliseconds, repeats, interval = raw.split(":")
                return (name in KEY_NAME_TO_VK and KEY_NAME_TO_VK[name] != VK_ESCAPE and
                        1 <= int(milliseconds) <= 600000 and 1 <= int(repeats) <= 2048 and
                        1 <= int(interval) <= 600000)
            except Exception:
                return False
        if raw.startswith("chord:"):
            try:
                parts = raw.split(":")
                if len(parts) not in {2, 3}:
                    return False
                names = parts[1].split("+")
                duration_ok = len(parts) == 2 or 1 <= int(parts[2]) <= 600000
                return (2 <= len(names) <= 4 and len(set(names)) == len(names) and duration_ok and
                        all(name in KEY_NAME_TO_VK and KEY_NAME_TO_VK[name] != VK_ESCAPE
                            for name in names))
            except Exception:
                return False
        return True

    def _observe_key_probe(self, action, state, before, after, confidence, visual_change):
        if self._active_learner is None:
            return
        names = []
        for part in Learner._macro_parts(action):
            names.extend(self._keyboard_action_names(part))
        names = list(dict.fromkeys(name for name in names if name and name != "ESC"))
        if not names:
            return
        learner = self._active_learner
        lost_focus = not self._input_scope_ready(action, restore=False)
        numeric_effect = abs(float(after) - float(before)) > max(1e-9, abs(float(before)) * 1e-10)
        visual_effect = float(visual_change or 0.0) >= self._visual_change_threshold()
        effect = bool(numeric_effect or visual_effect)
        for name in names:
            learner.observe_key_probe(name, state, effect=effect, confidence=confidence,
                                      lost_focus=lost_focus)
            if effect:
                self._key_probe_misses.pop(name, None)
                continue
            if float(confidence or 0.0) < 0.35:
                continue
            status = learner.key_probe_status(name, state)
            self._key_probe_misses[name] = int(status.get("miss_count", 0))
            if lost_focus:
                self._log_runtime("key_cooldown",
                                  f"{name}:foreground until={status.get('cooldown_until')}")
            elif int(status.get("cooldown_until", 0)) > learner.steps:
                self._log_runtime(
                    "key_cooldown",
                    f"{name}:state={status.get('family')} p={status.get('effect_probability', 0.5):.3f} "
                    f"until={status.get('cooldown_until')}")

    @staticmethod
    def _keyboard_category(action):
        raw = str(action)
        if raw.startswith("chord:"):
            return "combined"
        if raw.startswith(("hold:", "pulse:")):
            return "temporal"
        return "atomic"
    def _mouse_input_candidates(self, learner, click_actions, stagnant):
        remembered = []
        for prefix in ("mouse:", "pointer:", "click:", "tap:", "wheel:", "drag:"):
            remembered.extend(learner.preferred_actions(prefix, limit=14))
        remembered = [action for action in remembered if self._spatial_action_identity_stable(action)]
        safe_click_actions = [a for a in click_actions if not self._action_is_dangerous(a)]
        base_clicks = [a for a in safe_click_actions if str(a).startswith("mouse:")][:60]
        if self._operation_scope_reason == "desktop-cold":
            # Cold desktop cells get perception-first probing: pointer movement plus
            # a handful of single left clicks at the strongest safe visual/UIA
            # candidates.  Repeated clicks, wheels and drags require evidence.
            ranked = sorted(
                base_clicks,
                key=lambda candidate: float(self.action_priors.get(candidate, 0.50)),
                reverse=True)[:EXPLORATION_CONFIG.desktop_cold_action_limit]
            click_budget = min(7, max(3, len(ranked) // 4))
            cold_clicks = ranked[:click_budget]
            pointer_actions = []
            for candidate in ranked:
                parts = str(candidate).split(":")
                if len(parts) == 4 and parts[1] == "v":
                    pointer = f"pointer:v:{parts[2]}:{parts[3]}"
                    self.action_priors[pointer] = max(
                        0.48, min(0.62, float(self.action_priors.get(candidate, 0.50))))
                    pointer_actions.append(pointer)
            for candidate in cold_clicks:
                self.action_priors[candidate] = min(
                    0.48, max(0.30, float(self.action_priors.get(candidate, 0.50)) * 0.62))
            return list(dict.fromkeys(pointer_actions + cold_clicks))[
                :EXPLORATION_CONFIG.desktop_cold_action_limit]
        actions = list(dict.fromkeys(a for a in remembered + safe_click_actions
                                     if not self._action_is_dangerous(a)))
        _keyboard_limit, mouse_limit = self._adaptive_candidate_limits(learner, stagnant)
        if not base_clicks:
            return actions[:mouse_limit]
        variant_count = min(len(base_clicks), max(8, int(round(math.sqrt(len(base_clicks)) *
                                                               (1.7 + min(1.4, stagnant * 0.025))))))
        start = (learner.steps * max(1, variant_count)) % len(base_clicks)
        sample = (base_clicks + base_clicks)[start:start + variant_count]
        button_names = tuple(MOUSE_BUTTONS)
        for index, action in enumerate(sample):
            try:
                parts = action.split(":")
                coordinate_token = None
                if len(parts) == 3:
                    grid, qx, qy = 20, int(parts[1]), int(parts[2])
                elif len(parts) == 4 and parts[1] == "v":
                    coordinate_token = "v"
                    grid, qx, qy = 10000, int(parts[2]), int(parts[3])
                elif len(parts) == 4:
                    grid, qx, qy = int(parts[1]), int(parts[2]), int(parts[3])
                else:
                    continue
                grid = max(2, grid)
                parent_prior = self.action_priors.get(action, 0.50)
                seed_index = learner.steps * max(1, variant_count) + index
                click_fraction = self._parameter_fraction(f"mouse-click:{action}", seed_index)
                tap_fraction = self._parameter_fraction(f"mouse-tap:{action}", seed_index * 3 + 1)
                interval_fraction = self._parameter_fraction(f"mouse-gap:{action}", seed_index * 5 + 2)
                press_fraction = self._parameter_fraction(f"mouse-press:{action}", seed_index * 7 + 3)
                wheel_fraction = self._parameter_fraction(f"mouse-wheel:{action}", seed_index * 11 + 4)
                angle_fraction = self._parameter_fraction(f"mouse-angle:{action}", seed_index * 13 + 5)
                distance_fraction = self._parameter_fraction(f"mouse-distance:{action}", seed_index * 17 + 6)
                duration_fraction = self._parameter_fraction(f"mouse-duration:{action}", seed_index * 19 + 7)
                button = button_names[min(len(button_names) - 1, int(click_fraction * len(button_names)))]
                count_fraction = self._parameter_fraction(f"mouse-click-count:{action}", seed_index)
                click_count = learner.sample_parameter("mouse.click_count", 1, 3, count_fraction,
                                                       integer=True, log_scale=False)
                repeat_count = learner.sample_parameter("mouse.tap_repeat", 2, 12, tap_fraction,
                                                        integer=True, log_scale=False)
                interval_ms = learner.sample_parameter("mouse.tap_interval_ms", 25, 900, interval_fraction,
                                                       integer=True, log_scale=True)
                press_ms = learner.sample_parameter("mouse.tap_press_ms", 18, 350, press_fraction,
                                                    integer=True, log_scale=True)
                wheel_amount = learner.sample_parameter("mouse.wheel_amount", 24, WHEEL_DELTA * 8.0,
                                                        wheel_fraction, integer=True, log_scale=True)
                if self._parameter_fraction(f"mouse-wheel-sign:{action}", seed_index) < 0.5:
                    wheel_amount = -wheel_amount
                wheel_axis = "h" if self._parameter_fraction(
                    f"mouse-wheel-axis:{action}", seed_index) < 0.5 else "v"
                distance = learner.sample_parameter("mouse.drag_distance", 0.008, 0.34,
                                                    distance_fraction, integer=False, log_scale=True)
                angle = angle_fraction * math.tau
                distance_x, distance_y = distance, distance
                if coordinate_token == "v":
                    scope = self._adaptive_operation_rect(refresh=False, reason="mouse-parameter")
                    virtual = virtual_screen_rect()
                    if scope and virtual:
                        distance_x *= max(0.01, (scope[2] - scope[0]) / max(1.0, virtual[2] - virtual[0]))
                        distance_y *= max(0.01, (scope[3] - scope[1]) / max(1.0, virtual[3] - virtual[1]))
                ex = max(0, min(grid, int(round(qx + math.cos(angle) * distance_x * grid))))
                ey = max(0, min(grid, int(round(qy + math.sin(angle) * distance_y * grid))))
                drag_ms = learner.sample_parameter("mouse.drag_duration_ms", 20, 2400, duration_fraction,
                                                   integer=True, log_scale=True)
                coordinate = coordinate_token or str(grid)
                variants = [
                    f"pointer:{coordinate}:{qx}:{qy}",
                    f"click:{button}:{coordinate}:{qx}:{qy}:{click_count}",
                    f"tap:{button}:{coordinate}:{qx}:{qy}:{repeat_count}:{interval_ms}:{press_ms}",
                    f"wheel:{wheel_axis}:{wheel_amount}:{coordinate}:{qx}:{qy}",
                    f"drag:{button}:{coordinate}:{qx}:{qy}:{ex}:{ey}:{drag_ms}",
                ]
                for variant in variants:
                    if self._action_is_dangerous(variant):
                        continue
                    actions.append(variant)
                    self.action_priors.setdefault(variant, parent_prior * 0.86)
            except Exception as exc:
                self._log_runtime("mouse_candidate_error", type(exc).__name__)
        return list(dict.fromkeys(actions))[:mouse_limit]

    @staticmethod
    def _action_semantic_from_text(raw_text):
        _intent, sensitive, _token = ValueAI._semantic_text_features(raw_text)
        if sensitive:
            return ActionSemantic(type="safety_sensitive", risk=1.0, confidence=0.98)
        return ActionSemantic(type="unknown", risk=0.18, confidence=0.08)
    def _update_semantic_features_from_action(self, semantic):
        if not isinstance(semantic, ActionSemantic):
            return
        if semantic.type == "safety_sensitive":
            self._semantic_features["has_safety_sensitive_control"] = True

    def _number_feature_registry(self):
        registry = getattr(self, "_number_feature_registry_instance", None)
        if registry is None:
            registry = FeatureProducerRegistry()
            registry.register(
                "core_visual", self._produce_number_visual_core,
                declared_features=(
                    "foreground_color", "background_color", "contrast",
                    "visibility_hint", "apparent_opacity", "rotation",
                    "font_scale", "quad", "glyph_signature",
                    "visual.edge_density", "visual.local_range",
                    "visual.luminance", "visual.saturation",
                    "visual.screen_font_scale", "visual.screen_font_width_scale",
                    "visual.rotation_confidence", "visual.opacity_color_distance",
                    "visual.opacity_foreground_separation", "visual.opacity_edge_support",
                ))
            registry.register(
                "auto_visual", self._produce_number_visual_auto,
                declared_features=(
                    "visual.auto.local.coarse", "visual.auto.local.fine",
                    "visual.auto.color.histogram", "visual.auto.gradient.orientation",
                    "visual.auto.contour.hu", "visual.auto.affine.shape",
                    "visual.auto.texture.blocks",
                ))
            self._number_feature_registry_instance = registry
        return registry

    def _mark_number_visual_state(self, entities, state, reason=""):
        state = str(state or "not_sampled")
        if state not in FeatureObservation.VALID_STATES:
            state = "not_sampled"
        now = time.monotonic()
        registry = self._number_feature_registry()
        for entity in tuple(entities or ()):
            if not isinstance(entity, NumberEntity):
                continue
            for name in registry.feature_names():
                previous = entity.features.get(name)
                kind = previous.kind if isinstance(previous, FeatureObservation) else "missing"
                metadata = dict(previous.metadata) if isinstance(previous, FeatureObservation) else {}
                metadata.update({"producer_state": state, "reason": str(reason or "")})
                entity.features[name] = FeatureObservation(
                    None, kind, 0.0, now, metadata, state)

    def _number_visual_features(self, rgb, points, screen_rect):
        observations, producer_states = self._number_feature_registry().extract(
            rgb, points, screen_rect)
        flat, visual = {}, {}
        for name, observation in observations.items():
            value = observation.value if observation.observation_state == "observed" else None
            if name.startswith("visual."):
                visual[name[7:]] = value
            else:
                flat[name] = value
        flat["visual_features"] = visual
        flat["feature_observations"] = {
            name: observation.snapshot() for name, observation in observations.items()}
        if hasattr(self, "_source_health") and producer_states:
            states = set(producer_states.values())
            if "sensor_failed" in states:
                state, valid = "sensor_failed", False
            elif "observed" in states:
                state, valid = "observed", True
            elif "low_confidence" in states:
                state, valid = "low_confidence", False
            else:
                state, valid = "not_sampled", False
            observed_conf = [obs.confidence for obs in observations.values()
                             if obs.observation_state == "observed"]
            confidence = sum(observed_conf) / max(1, len(observed_conf)) if observed_conf else 0.0
            reason = "" if valid else ",".join(sorted(states))
            self._set_source_health("visual_features", valid, confidence, reason, state)
        return flat

    def _produce_number_visual_core(self, rgb, points, screen_rect):
        features = {}
        try:
            pts = self.np.asarray(points, dtype="float32").reshape(-1, 2)
            x1 = max(0, int(math.floor(float(pts[:, 0].min()))))
            y1 = max(0, int(math.floor(float(pts[:, 1].min()))))
            x2 = min(int(rgb.shape[1]), int(math.ceil(float(pts[:, 0].max()))) + 1)
            y2 = min(int(rgb.shape[0]), int(math.ceil(float(pts[:, 1].max()))) + 1)
            if x2 - x1 < 2 or y2 - y1 < 2:
                return features
            patch = self.np.asarray(rgb[y1:y2, x1:x2], dtype="float32")
            if patch.ndim != 3 or patch.shape[2] < 3:
                return features
            gray = self.cv2.cvtColor(patch.astype("uint8"), self.cv2.COLOR_RGB2GRAY).astype("float32")
            border = max(1, min(gray.shape) // 7)
            border_mask = self.np.zeros(gray.shape, dtype=bool)
            border_mask[:border, :] = True
            border_mask[-border:, :] = True
            border_mask[:, :border] = True
            border_mask[:, -border:] = True
            background_pixels = patch[border_mask]
            if not background_pixels.size:
                background_pixels = patch.reshape(-1, 3)
            background = self.np.median(background_pixels, axis=0)
            background_luma = float(0.299 * background[0] + 0.587 * background[1] + 0.114 * background[2])
            difference = self.np.abs(gray - background_luma)
            cutoff = max(7.0, float(self.np.percentile(difference, 68)))
            foreground_mask = difference >= cutoff
            if int(foreground_mask.sum()) < max(2, gray.size // 40):
                foreground_mask = difference >= max(4.0, float(self.np.percentile(difference, 82)))
            foreground_pixels = patch[foreground_mask]
            foreground = (self.np.mean(foreground_pixels, axis=0)
                          if foreground_pixels.size else self.np.mean(patch.reshape(-1, 3), axis=0))
            foreground_luma = float(0.299 * foreground[0] + 0.587 * foreground[1] + 0.114 * foreground[2])
            contrast = abs(foreground_luma - background_luma) / 255.0
            sobel_x = self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3)
            sobel_y = self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3)
            edge = self.cv2.magnitude(sobel_x, sobel_y)
            edge_density = float((edge > max(16.0, float(edge.mean()) * 1.35)).mean())
            color_distance = float(self.np.linalg.norm(foreground[:3] - background[:3])) / (255.0 * math.sqrt(3.0))
            foreground_separation = (float(difference[foreground_mask].mean()) / 255.0
                                     if int(foreground_mask.sum()) else 0.0)
            edge_support = max(0.0, min(1.0, edge_density * 4.0))
            # A screenshot cannot reveal the real alpha channel. This is deliberately
            # an apparent-opacity proxy based on foreground/background separation,
            # edge support and color mixing rather than a claim of true transparency.
            apparent_opacity = max(0.0, min(1.0,
                color_distance * 0.46 + foreground_separation * 0.36 + edge_support * 0.18))
            tiny = self.cv2.resize(difference, (12, 8), interpolation=self.cv2.INTER_AREA)
            threshold = max(4.0, float(tiny.mean()) + float(tiny.std()) * 0.12)
            glyph_value = 0
            for bit in (tiny >= threshold).reshape(-1):
                glyph_value = (glyph_value << 1) | int(bool(bit))

            polygon_rotation = 0.0
            if len(pts) >= 2:
                vector = pts[1] - pts[0]
                polygon_rotation = math.degrees(math.atan2(float(vector[1]), float(vector[0])))
                polygon_rotation = (polygon_rotation + 90.0) % 180.0 - 90.0
            rotation = polygon_rotation
            rotation_confidence = 0.25 if len(pts) >= 4 else 0.0
            estimated_quad = ()
            ys, xs = self.np.nonzero(foreground_mask)
            if len(xs) >= max(8, gray.size // 80):
                coords = self.np.column_stack((xs.astype("float32"), ys.astype("float32")))
                centered = coords - coords.mean(axis=0, keepdims=True)
                covariance = self.np.cov(centered, rowvar=False)
                eigenvalues, eigenvectors = self.np.linalg.eigh(covariance)
                order = self.np.argsort(eigenvalues)
                major = eigenvectors[:, order[-1]]
                anisotropy = float(eigenvalues[order[-1]] / max(1e-6, eigenvalues[order[-2]]))
                if anisotropy >= 1.18:
                    mask_rotation = math.degrees(math.atan2(float(major[1]), float(major[0])))
                    mask_rotation = (mask_rotation + 90.0) % 180.0 - 90.0
                    rotation = mask_rotation
                    rotation_confidence = max(rotation_confidence, min(1.0, (anisotropy - 1.0) / 2.5))
                if len(coords) >= 5:
                    rect = self.cv2.minAreaRect(coords.reshape(-1, 1, 2))
                    box = self.cv2.boxPoints(rect)
                    box[:, 0] += float(x1)
                    box[:, 1] += float(y1)
                    screen_w = max(1.0, float(screen_rect[2] - screen_rect[0]))
                    screen_h = max(1.0, float(screen_rect[3] - screen_rect[1]))
                    scale_x = screen_w / max(1.0, float(rgb.shape[1]))
                    scale_y = screen_h / max(1.0, float(rgb.shape[0]))
                    estimated_quad = tuple((float(screen_rect[0]) + float(px) * scale_x,
                                            float(screen_rect[1]) + float(py) * scale_y)
                                           for px, py in box)

            local_range = float(self.np.percentile(gray, 95) - self.np.percentile(gray, 5)) / 255.0
            visibility_hint = max(0.0, min(1.0, contrast * 1.45 + edge_density * 0.28))
            screen_w = max(1.0, float(screen_rect[2] - screen_rect[0]))
            screen_h = max(1.0, float(screen_rect[3] - screen_rect[1]))
            scale_x = screen_w / max(1.0, float(rgb.shape[1]))
            scale_y = screen_h / max(1.0, float(rgb.shape[0]))
            glyph_height_screen = max(0.0, float(pts[:, 1].max()) - float(pts[:, 1].min())) * scale_y
            glyph_width_screen = max(0.0, float(pts[:, 0].max()) - float(pts[:, 0].min())) * scale_x
            client = self._target_client_rect() or virtual_screen_rect()
            client_w = max(1.0, float(client[2] - client[0]))
            client_h = max(1.0, float(client[3] - client[1]))
            font_scale = glyph_height_screen / client_h
            font_width_scale = glyph_width_screen / client_w
            features = {
                "foreground_color": tuple(int(max(0, min(255, round(v)))) for v in foreground[:3]),
                "background_color": tuple(int(max(0, min(255, round(v)))) for v in background[:3]),
                "contrast": float(contrast), "visibility_hint": float(visibility_hint),
                "apparent_opacity": FeatureObservation(
                    float(apparent_opacity), "scalar", 0.72, time.monotonic(),
                    {"proxy": True, "scale": 1.0, "method": "color_edge_mixing"}),
                "rotation": FeatureObservation(
                    float(rotation), "scalar", max(0.08, float(rotation_confidence)),
                    time.monotonic(), {"period": 180.0}),
                "font_scale": float(max(0.0, font_scale)),
                "quad": estimated_quad,
                "glyph_signature": f"g{glyph_value:024x}",
                "visual_features": {
                    "edge_density": edge_density, "local_range": local_range,
                    "luminance": float(gray.mean()) / 255.0,
                    "saturation": float((patch.max(axis=2) - patch.min(axis=2)).mean()) / 255.0,
                    "screen_font_scale": float(max(0.0, font_scale)),
                    "screen_font_width_scale": float(max(0.0, font_width_scale)),
                    "rotation_confidence": float(rotation_confidence),
                    "opacity_color_distance": float(color_distance),
                    "opacity_foreground_separation": float(foreground_separation),
                    "opacity_edge_support": float(edge_support),
                },
            }
        except Exception as exc:
            raise RuntimeError(f"number_visual_features:{type(exc).__name__}") from exc
        return features

    def _produce_number_visual_auto(self, rgb, points, screen_rect):
        """Discover generic visual dimensions without assigning them domain semantics."""
        pts = self.np.asarray(points, dtype="float32").reshape(-1, 2)
        x1 = max(0, int(math.floor(float(pts[:, 0].min()))))
        y1 = max(0, int(math.floor(float(pts[:, 1].min()))))
        x2 = min(int(rgb.shape[1]), int(math.ceil(float(pts[:, 0].max()))) + 1)
        y2 = min(int(rgb.shape[0]), int(math.ceil(float(pts[:, 1].max()))) + 1)
        if x2 - x1 < 3 or y2 - y1 < 3:
            return {"__state__": "not_sampled"}
        patch = self.np.asarray(rgb[y1:y2, x1:x2, :3], dtype="uint8")
        gray = self.cv2.cvtColor(patch, self.cv2.COLOR_RGB2GRAY)
        gray_f = gray.astype("float32") / 255.0

        def pooled(width, height):
            tiny = self.cv2.resize(gray_f, (width, height), interpolation=self.cv2.INTER_AREA)
            centered = tiny - float(tiny.mean())
            denom = max(0.03, float(tiny.std()))
            return tuple(float(v) for v in (centered / denom).reshape(-1))

        # Color distribution is deliberately channel-generic: the learner decides
        # whether any component matters instead of receiving a named color rule.
        histogram = []
        for channel in range(3):
            hist = self.cv2.calcHist([patch], [channel], None, [6], [0, 256]).reshape(-1)
            hist = hist / max(1.0, float(hist.sum()))
            histogram.extend(float(v) for v in hist)

        gx = self.cv2.Sobel(gray_f, self.cv2.CV_32F, 1, 0, ksize=3)
        gy = self.cv2.Sobel(gray_f, self.cv2.CV_32F, 0, 1, ksize=3)
        magnitude, angle = self.cv2.cartToPolar(gx, gy, angleInDegrees=True)
        bins = self.np.floor((angle % 180.0) / 22.5).astype("int32") % 8
        orientation = self.np.zeros(8, dtype="float64")
        for index in range(8):
            orientation[index] = float(magnitude[bins == index].sum())
        orientation /= max(1e-9, float(orientation.sum()))

        _threshold, binary = self.cv2.threshold(
            gray, 0, 255, self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
        moments = self.cv2.moments(binary)
        hu = self.cv2.HuMoments(moments).reshape(-1)
        hu_log = tuple(float(-math.copysign(math.log10(abs(v) + 1e-30), v)) for v in hu)

        h, w = gray.shape[:2]
        foreground_fraction = min(float((binary > 0).mean()), float((binary == 0).mean()))
        covariance = self.np.cov(self.np.column_stack(self.np.nonzero(binary)).astype("float64"), rowvar=False)             if int((binary > 0).sum()) >= 4 else self.np.eye(2)
        eig = self.np.linalg.eigvalsh(covariance)
        anisotropy = float(max(eig) / max(1e-9, min(eig)))
        shape = (float(w / max(1.0, h)), float(foreground_fraction),
                 float(math.log1p(anisotropy)), float(gray_f.mean()), float(gray_f.std()))
        blocks = self.cv2.resize(gray_f, (4, 4), interpolation=self.cv2.INTER_AREA)
        blocks = tuple(float(v) for v in blocks.reshape(-1))
        now = time.monotonic()
        return {
            "visual_features": {
                "auto.local.coarse": FeatureObservation(pooled(4, 3), "vector", 0.80, now, {"scale": 1.0}),
                "auto.local.fine": FeatureObservation(pooled(6, 4), "vector", 0.76, now, {"scale": 1.0}),
                "auto.color.histogram": FeatureObservation(tuple(histogram), "vector", 0.82, now, {"scale": 1.0}),
                "auto.gradient.orientation": FeatureObservation(tuple(float(v) for v in orientation), "vector", 0.78, now, {"scale": 1.0}),
                "auto.contour.hu": FeatureObservation(hu_log, "vector", 0.68, now, {"scale": 8.0}),
                "auto.affine.shape": FeatureObservation(shape, "vector", 0.72, now, {"scale": 1.0}),
                "auto.texture.blocks": FeatureObservation(blocks, "vector", 0.74, now, {"scale": 1.0}),
            }
        }

    def _augment_number_auto_features(self, entities):
        """Add generic relative-geometry and temporal features discovered at runtime."""
        entities = [item for item in tuple(entities or ()) if isinstance(item, NumberEntity) and item.entity_id]
        if not entities:
            return
        client = self._target_client_rect() or virtual_screen_rect()
        cw = max(1.0, float(client[2] - client[0]))
        ch = max(1.0, float(client[3] - client[1]))
        now = time.monotonic()
        live_ids = set()
        for entity in entities:
            live_ids.add(entity.entity_id)
            cx = (float(entity.bbox[0]) + float(entity.bbox[2])) * 0.5
            cy = (float(entity.bbox[1]) + float(entity.bbox[3])) * 0.5
            neighbors = []
            for other in entities:
                if other is entity:
                    continue
                ox = (float(other.bbox[0]) + float(other.bbox[2])) * 0.5
                oy = (float(other.bbox[1]) + float(other.bbox[3])) * 0.5
                dx, dy = (ox - cx) / cw, (oy - cy) / ch
                distance = math.hypot(dx, dy)
                neighbors.append((distance, dx, dy,
                                  max(0.0, float(other.bbox[2] - other.bbox[0])) / cw,
                                  max(0.0, float(other.bbox[3] - other.bbox[1])) / ch))
            geometry = []
            for _distance, dx, dy, ow, oh in sorted(neighbors)[:4]:
                geometry.extend((dx, dy, ow, oh))
            while len(geometry) < 16:
                geometry.extend((0.0, 0.0, 0.0, 0.0))
            entity.set_feature("visual.auto.context.relative_geometry",
                               FeatureObservation(tuple(geometry[:16]), "vector", 0.72, now,
                                                  {"scale": 1.0, "producer": "auto_context"}))

            fine = entity.feature_observation("visual.auto.local.fine")
            if fine.observation_state != "observed" or not isinstance(fine.value, (tuple, list)):
                continue
            try:
                vector = tuple(float(v) for v in fine.value)
            except (TypeError, ValueError, OverflowError):
                continue
            history = self._number_auto_history.setdefault(entity.entity_id, [])
            projection = sum((index + 1) * value for index, value in enumerate(vector)) / max(1.0, len(vector))
            history.append((now, float(projection)))
            del history[:-24]
            if len(history) < 5:
                continue
            values = self.np.asarray([item[1] for item in history], dtype="float64")
            activity = float(values.std())
            entity.set_feature("visual.auto.temporal.activity",
                               FeatureObservation(activity, "scalar", 0.68, now,
                                                  {"scale": max(0.05, activity), "producer": "auto_temporal"}))
            centered = values - float(values.mean())
            variance = float(self.np.dot(centered, centered))
            best_lag, best_corr = 0, 0.0
            if variance > 1e-9:
                for lag in range(2, min(9, len(values) - 1)):
                    left, right = centered[:-lag], centered[lag:]
                    denom = math.sqrt(float(self.np.dot(left, left) * self.np.dot(right, right)))
                    corr = float(self.np.dot(left, right) / denom) if denom > 1e-9 else 0.0
                    if corr > best_corr:
                        best_lag, best_corr = lag, corr
            if best_lag and best_corr >= 0.18:
                intervals = [history[i][0] - history[i - 1][0] for i in range(1, len(history))]
                median_dt = sorted(intervals)[len(intervals) // 2] if intervals else 0.0
                period = max(0.0, float(best_lag) * float(median_dt))
                phase = ((now - history[0][0]) / max(1e-6, period)) % 1.0 if period > 0 else 0.0
                confidence = max(0.25, min(0.82, best_corr))
                entity.set_feature("visual.auto.temporal.period",
                                   FeatureObservation(period, "scalar", confidence, now,
                                                      {"scale": max(0.2, period), "producer": "auto_temporal"}))
                entity.set_feature("visual.auto.temporal.phase",
                                   FeatureObservation(phase, "scalar", confidence, now,
                                                      {"period": 1.0, "scale": 1.0, "producer": "auto_temporal"}))
        for entity_id in tuple(self._number_auto_history):
            if entity_id not in live_ids:
                self._number_auto_history.pop(entity_id, None)

    def _ocr_scene_items(self, image, screen_rect, max_side=None):
        if self.stop_event.is_set():
            return []
        if image is None or not self.reader or not self.reader.engines:
            return []
        try:
            rgb = self.np.asarray(image.convert("RGB"))
            h, w = rgb.shape[:2]
            if h < 8 or w < 8:
                return []
            max_side = int(max_side or (1180 if getattr(self.hardware, "tier", "balanced") != "low" else 760))
            scale = min(1.0, max(420, max_side) / max(w, h))
            view = (self.cv2.resize(rgb, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
                    if scale < 0.995 else rgb)
            _name, engine, _weight = self.reader.engines[0]
            if self.stop_event.is_set():
                return []
            try:
                result = engine(view, use_det=True, use_cls=False, use_rec=True)
            except TypeError:
                result = engine(view)
            texts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
            boxes = result.get("boxes") if isinstance(result, dict) else getattr(result, "boxes", None)
            scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
            if texts is None or boxes is None:
                return []
            texts, boxes = list(texts), list(boxes)
            try:
                scores = list(scores) if scores is not None else []
            except TypeError:
                scores = []
            sx = (screen_rect[2] - screen_rect[0]) / max(1.0, float(view.shape[1]))
            sy = (screen_rect[3] - screen_rect[1]) / max(1.0, float(view.shape[0]))
            items = []
            for index, raw in enumerate(texts):
                if self.stop_event.is_set():
                    return []
                if index >= len(boxes):
                    continue
                if isinstance(raw, dict):
                    text = raw.get("text") or raw.get("txt") or ""
                elif isinstance(raw, (tuple, list)):
                    text = raw[0] if raw else ""
                else:
                    text = raw
                text = unicodedata.normalize("NFKC", str(text)).strip()
                if not text:
                    continue
                try:
                    pts = self.np.asarray(boxes[index], dtype="float32").reshape(-1, 2)
                    if len(pts) < 2:
                        continue
                    x1, y1 = float(pts[:, 0].min()), float(pts[:, 1].min())
                    x2, y2 = float(pts[:, 0].max()), float(pts[:, 1].max())
                    bbox = (screen_rect[0] + x1 * sx, screen_rect[1] + y1 * sy,
                            screen_rect[0] + x2 * sx, screen_rect[1] + y2 * sy)
                    conf = self.reader._as_float(scores[index] if index < len(scores) else 0.68)
                    if bbox[2] - bbox[0] >= 2 and bbox[3] - bbox[1] >= 2:
                        visual = self._number_visual_features(view, pts, screen_rect)
                        ocr_quad = tuple((screen_rect[0] + float(px) * sx,
                                          screen_rect[1] + float(py) * sy) for px, py in pts)
                        visual["quad"] = ocr_quad
                        items.append({"text": text, "bbox": bbox, "confidence": conf, **visual})
                except Exception:
                    continue
            return items
        except Exception as exc:
            self._log_runtime("scene_ocr_error", type(exc).__name__)
            return []

    @staticmethod
    def _bbox_overlap_ratio(a, b):
        try:
            ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
            ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
            inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
            area = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
            return inter / area
        except Exception:
            return 0.0

    @staticmethod
    def _number_unit(text, label):
        raw = unicodedata.normalize("NFKC", f"{label} {text}").lower()
        if "%" in raw or "百分" in raw:
            return "%"
        if any(token in raw for token in ("/s", "/sec", "每秒", "per second", "秒收益")):
            return "/s"
        if any(token in raw for token in ("ms", "毫秒")):
            return "ms"
        if any(token in raw for token in ("秒", " sec", "second")):
            return "s"
        return ""

    @staticmethod
    def _number_role(label, text, is_target=False):
        # Only the user-selected value has a programmer-defined objective role.
        # Other numbers keep OCR text/label/unit as identity features and acquire
        # meaning from observed causal relations instead of a semantic word list.
        return "TARGET" if is_target else "UNKNOWN"
    @staticmethod
    def _clean_numeric_label(text):
        text = unicodedata.normalize("NFKC", str(text or "")).strip()
        text = re.sub(r"[-+−＋]?(?:\d{1,3}(?:[.,，．'’ ]\d{3})+|\d+)(?:[.,，．]\d+)?(?:[eE][-+−＋]?\d+)?", " ", text)
        text = re.sub(r"[=:：|/\-]+$", "", text).strip(" \t:：=-|[]()（）")
        return re.sub(r"\s+", " ", text)[:80]

    def _best_label_for_number(self, number_item, items):
        nb = number_item["bbox"]
        nx1, ny1, nx2, ny2 = nb
        nw, nh = max(1.0, nx2 - nx1), max(1.0, ny2 - ny1)
        ncy = (ny1 + ny2) * 0.5
        candidates = []
        own = self._clean_numeric_label(number_item.get("text", ""))
        if own and re.search(r"[A-Za-z\u4e00-\u9fff]", own):
            candidates.append((5.4, own))
        for item in items:
            if item is number_item:
                continue
            label = self._clean_numeric_label(item.get("text", ""))
            if not label or not re.search(r"[A-Za-z\u4e00-\u9fff]", label):
                continue
            bx1, by1, bx2, by2 = item["bbox"]
            bcy = (by1 + by2) * 0.5
            same_row = abs(bcy - ncy) <= max(nh, by2 - by1) * 0.82
            if same_row and bx2 <= nx1 + nw * 0.20:
                gap = max(0.0, nx1 - bx2)
                score = 4.8 - gap / max(36.0, nw * 5.0)
                candidates.append((score, label))
                continue
            horizontal_overlap = max(0.0, min(nx2, bx2) - max(nx1, bx1)) / max(1.0, min(nw, bx2 - bx1))
            if by2 <= ny1 + nh * 0.12 and horizontal_overlap >= 0.20:
                gap = max(0.0, ny1 - by2)
                score = 3.9 - gap / max(28.0, nh * 4.0)
                candidates.append((score, label))
                continue
            if same_row and bx1 >= nx2 - nw * 0.12:
                gap = max(0.0, bx1 - nx2)
                score = 3.0 - gap / max(36.0, nw * 5.0)
                candidates.append((score, label))
        if not candidates:
            return ""
        candidates.sort(reverse=True, key=lambda item: item[0])
        return candidates[0][1] if candidates[0][0] > 1.25 else ""

    def _number_window_identity(self, bbox):
        try:
            center_x = (float(bbox[0]) + float(bbox[2])) * 0.5
            center_y = (float(bbox[1]) + float(bbox[3])) * 0.5
            hwnd = top_level_window_at(center_x, center_y)
            identity = (environment_identity_for_window(hwnd) if hwnd else
                        (self.target_identity or self._environment_identity()))
            title = self._normalized_number_label(identity.get("title", ""))
            raw = f"{identity.get('exe_hash', 'unknown')}|{identity.get('class', '')}|{title}"
            return "win_" + hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:12]
        except Exception:
            return str((self.target_identity or {}).get("exe_hash", ""))

    def _number_entities_from_items(self, items, target_rect=None, target_value=None):
        entities = []
        number_items = []
        for item in items:
            parsed = parse_score_candidates(
                item.get("text", ""),
                suffix_factors=self.reader.numeric_scale_graph.factor_values())
            if not parsed:
                continue
            value, _weight, parsed_text = max(parsed, key=lambda x: (x[1], len(x[2])))
            number_items.append((item, float(value), str(parsed_text)))
        target_index = None
        target_score = -1e9
        for index, (item, value, parsed_text) in enumerate(number_items):
            overlap = self._bbox_overlap_ratio(target_rect, item["bbox"]) if target_rect else 0.0
            same_value = (target_value is not None and ScoreReader._same_value(value, target_value))
            if target_rect:
                tx = (target_rect[0] + target_rect[2]) * 0.5
                ty = (target_rect[1] + target_rect[3]) * 0.5
                bx = (item["bbox"][0] + item["bbox"][2]) * 0.5
                by = (item["bbox"][1] + item["bbox"][3]) * 0.5
                distance = math.hypot(tx - bx, ty - by)
            else:
                distance = 0.0
            score = overlap * 8.0 + (3.0 if same_value else 0.0) - distance / 180.0
            if score > target_score:
                target_score, target_index = score, index
        for index, (item, value, parsed_text) in enumerate(number_items):
            is_target = target_rect is not None and index == target_index and target_score > -2.0
            label = self._best_label_for_number(item, items)
            role = self._number_role(label, item.get("text", ""), is_target=is_target)
            direction = "maximize" if is_target else "unknown"
            format_signature = json.dumps(
                self._numeric_format_signature(item.get("text", "")),
                ensure_ascii=True, sort_keys=True, separators=(",", ":"))
            bbox = tuple(item["bbox"])
            width, height = max(0.0, bbox[2] - bbox[0]), max(0.0, bbox[3] - bbox[1])
            entities.append(NumberEntity(
                value=value, text=str(item.get("text", ""))[:100], bbox=bbox,
                confidence=float(item.get("confidence", 0.0)), label=label,
                unit=self._number_unit(item.get("text", ""), label), role=role,
                direction=direction, is_target=is_target, source="ocr",
                center=((bbox[0] + bbox[2]) * 0.5, (bbox[1] + bbox[3]) * 0.5),
                width=width, height=height,
                foreground_color=item.get("foreground_color"),
                background_color=item.get("background_color"),
                contrast=item.get("contrast"), visibility_hint=item.get("visibility_hint"),
                rotation=item.get("rotation"), font_scale=item.get("font_scale"),
                quad=tuple(item.get("quad") or ()),
                present=1.0, visibility=float(item.get("confidence", 0.0)),
                detection_confidence=float(item.get("confidence", 0.0)), occluded=0.0,
                format_signature=format_signature,
                glyph_signature=str(item.get("glyph_signature", "")),
                window_id=self._number_window_identity(bbox),
                visual_features=dict(item.get("visual_features", {})),
                features=dict(item.get("feature_observations", {})),
                observed_at=time.monotonic()))
        return entities

    @staticmethod
    def _normalized_number_label(value):
        raw = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
        raw = re.sub(r"[-+−＋]?\d+(?:[.,，．'’ ]\d+)*(?:[eE][-+−＋]?\d+)?", "#", raw)
        return re.sub(r"\s+", " ", raw)[:80]

    def _number_identity_seed(self, entity):
        # Seed IDs with semantic/hierarchy anchors only. Mutable attributes such as
        # numeric format, unit suffix, geometry and glyph appearance are observations
        # to learn, not identity. Duplicate unlabeled numbers are disambiguated later
        # by assignment and temporal continuity rather than frozen spatial bins.
        label = self._normalized_number_label(entity.label)
        control_id = str(getattr(entity, "control_id", "") or "")
        semantic = label or control_id or str(entity.role or "UNKNOWN")
        return "|".join((str(entity.window_id), control_id, semantic,
                         "target" if entity.is_target else "number"))

    def _number_track_score(self, entity, track):
        if bool(entity.is_target) != bool(track.get("is_target")):
            return -1e9
        score = 0.0
        label = self._normalized_number_label(entity.label)
        old_label = self._normalized_number_label(track.get("label"))
        if label and old_label:
            score += 3.8 if label == old_label else difflib.SequenceMatcher(None, label, old_label).ratio() * 2.0
        elif not label and not old_label:
            score += 0.20
        if str(entity.window_id) and str(entity.window_id) == str(track.get("window_id", "")):
            score += 1.65
        if str(entity.control_id) and str(entity.control_id) == str(track.get("control_id", "")):
            score += 1.45
        # Role is only a weak semantic hint. Format, unit, glyph and size are
        # deliberately excluded because they are learnable mutable properties.
        if str(entity.role) == str(track.get("role", "UNKNOWN")):
            score += 0.10
        old_center = track.get("center", (None, None))
        if isinstance(old_center, (tuple, list)) and len(old_center) >= 2:
            try:
                client = self._target_client_rect() or virtual_screen_rect()
                diagonal = max(1.0, math.hypot(client[2] - client[0], client[3] - client[1]))
                elapsed = max(0.0, time.monotonic() - float(
                    track.get("observed_at", track.get("last_seen", time.monotonic()))))
                velocity = track.get("velocity", {}) if isinstance(track.get("velocity"), dict) else {}
                px = float(old_center[0]) + float(velocity.get("x", 0.0) or 0.0) * elapsed
                py = float(old_center[1]) + float(velocity.get("y", 0.0) or 0.0) * elapsed
                distance = math.hypot(entity.center[0] - px, entity.center[1] - py) / diagonal
                continuity = max(-0.35, 1.05 - distance * 3.6) * math.exp(-elapsed / 3.5)
                score += continuity
            except Exception:
                pass
        return score

    @staticmethod
    def _hungarian_maximize(weights):
        """Return row->column assignment for a rectangular maximum-weight matrix."""
        if not weights:
            return []
        n = len(weights)
        real_m = max((len(row) for row in weights), default=0)
        # One dummy column per row lets uncertain entities remain unmatched.
        m = real_m + n
        matrix = []
        for row in weights:
            padded = [float(row[j]) if j < len(row) else -1e6 for j in range(real_m)]
            padded.extend([0.0] * n)
            matrix.append(padded)
        # Hungarian algorithm (minimization of -weight), n <= m.
        u = [0.0] * (n + 1)
        v = [0.0] * (m + 1)
        pcol = [0] * (m + 1)
        way = [0] * (m + 1)
        for i in range(1, n + 1):
            pcol[0] = i
            j0 = 0
            minv = [float("inf")] * (m + 1)
            used = [False] * (m + 1)
            while True:
                used[j0] = True
                i0 = pcol[j0]
                delta = float("inf")
                j1 = 0
                for j in range(1, m + 1):
                    if used[j]:
                        continue
                    cur = -matrix[i0 - 1][j - 1] - u[i0] - v[j]
                    if cur < minv[j]:
                        minv[j] = cur
                        way[j] = j0
                    if minv[j] < delta:
                        delta, j1 = minv[j], j
                for j in range(m + 1):
                    if used[j]:
                        u[pcol[j]] += delta
                        v[j] -= delta
                    else:
                        minv[j] -= delta
                j0 = j1
                if pcol[j0] == 0:
                    break
            while True:
                j1 = way[j0]
                pcol[j0] = pcol[j1]
                j0 = j1
                if j0 == 0:
                    break
        assignment = [-1] * n
        for j in range(1, m + 1):
            if pcol[j] and pcol[j] <= n:
                assignment[pcol[j] - 1] = j - 1
        return assignment

    def _assign_number_entity_ids(self, entities):
        now = time.monotonic()
        if not hasattr(self, "_number_attribute_activity"):
            self._number_attribute_activity = {}
        used_ids = set()
        previous_tracks = dict(self._number_tracks)
        ordered = sorted(entities, key=lambda entity: (not entity.is_target, -entity.confidence))

        # Pin the user-selected target identity, then solve all remaining identities
        # jointly instead of greedily consuming the locally best old track.
        fixed = {}
        for row, entity in enumerate(ordered):
            if entity.is_target and self.target_entity is not None and self.target_entity.entity_id:
                fixed[row] = self.target_entity.entity_id
                used_ids.add(self.target_entity.entity_id)

        candidate_ids = []
        for entity_id, track in previous_tracks.items():
            if entity_id in used_ids:
                continue
            age = now - float(track.get("last_seen", now))
            if age <= 45.0:
                candidate_ids.append(entity_id)
        free_rows = [row for row in range(len(ordered)) if row not in fixed]
        threshold = 1.95
        weight_matrix = []
        raw_scores = []
        for row in free_rows:
            scores = [self._number_track_score(ordered[row], previous_tracks[entity_id])
                      for entity_id in candidate_ids]
            raw_scores.append(scores)
            # Dummy columns have zero weight, so subtracting the acceptance threshold
            # makes any below-threshold real match lose to creating a new identity.
            weight_matrix.append([score - threshold for score in scores])
        assignments = self._hungarian_maximize(weight_matrix) if free_rows else []
        chosen_by_row = dict(fixed)
        for local_row, assigned_col in enumerate(assignments):
            row = free_rows[local_row]
            if 0 <= assigned_col < len(candidate_ids):
                score = raw_scores[local_row][assigned_col]
                entity_id = candidate_ids[assigned_col]
                if score >= threshold and entity_id not in used_ids:
                    chosen_by_row[row] = entity_id
                    used_ids.add(entity_id)

        for row, entity in enumerate(ordered):
            chosen_id = chosen_by_row.get(row, "")
            if not chosen_id:
                digest = hashlib.sha1(self._number_identity_seed(entity).encode(
                    "utf-8", "replace")).hexdigest()[:10]
                base = "num_" + digest
                chosen_id = base
                suffix = 1
                # Never accidentally resurrect an unmatched old track just because its
                # content hash happens to be identical this frame.
                while chosen_id in used_ids or chosen_id in previous_tracks:
                    suffix += 1
                    chosen_id = f"{base}_{suffix}"
                used_ids.add(chosen_id)
            entity.entity_id = chosen_id
            old = previous_tracks.get(chosen_id)
            if old:
                entity.first_seen = float(old.get("first_seen", old.get("observed_at", now)) or now)
                entity.last_seen = now
                entity.present = 1.0
                entity.visibility = max(0.0, min(1.0, float(entity.confidence)))
                entity.detection_confidence = max(0.0, min(1.0, float(entity.confidence)))
                entity.occluded = 0.0
                elapsed = max(0.02, now - float(old.get("observed_at", old.get("last_seen", now))))
                current = entity.snapshot()
                transitions = Learner._entity_attribute_delta(old, current)
                entity.changed_attributes = tuple(sorted(
                    name for name, observation in transitions.items() if observation.get("changed")))
                activity = self._number_attribute_activity.setdefault(chosen_id, {})
                for name, observation in transitions.items():
                    old_activity = float(activity.get(name, 0.0))
                    activity[name] = old_activity * 0.88 + (1.0 if observation.get("changed") else 0.0) * 0.12
                velocity = {}
                for name, observation in transitions.items():
                    delta = observation.get("delta")
                    if isinstance(delta, (int, float)):
                        velocity[name] = float(delta) / elapsed
                    elif isinstance(delta, list):
                        velocity[name] = [float(value) / elapsed for value in delta]
                entity.velocity = velocity
            else:
                entity.first_seen = now
                entity.last_seen = now
                entity.present = 1.0
                entity.visibility = max(0.0, min(1.0, float(entity.confidence)))
                entity.detection_confidence = max(0.0, min(1.0, float(entity.confidence)))
                entity.occluded = 0.0
                self._number_attribute_activity.setdefault(
                    chosen_id, {"discovery": 0.35, "value": 0.35})
            snapshot = entity.snapshot()
            snapshot["last_seen"] = now
            self._number_tracks[chosen_id] = snapshot
        for entity_id, track in tuple(self._number_tracks.items()):
            if entity_id not in used_ids and now - float(track.get("last_seen", now)) > 45.0:
                self._number_tracks.pop(entity_id, None)
                self._number_attribute_activity.pop(entity_id, None)
                self._number_fast_read_at.pop(entity_id, None)
                self._number_fast_read_misses.pop(entity_id, None)
        if len(self._number_tracks) > 256:
            keep = sorted(self._number_tracks, key=lambda entity_id: float(
                self._number_tracks[entity_id].get("last_seen", 0.0)), reverse=True)[:256]
            self._number_tracks = {entity_id: self._number_tracks[entity_id] for entity_id in keep}
            self._number_attribute_activity = {
                entity_id: self._number_attribute_activity.get(entity_id, {}) for entity_id in keep}

    def _update_scene_numbers(self, entities, target_value=None):
        previous = {entity_id: entity.snapshot() if isinstance(entity, NumberEntity) else dict(entity)
                    for entity_id, entity in self.scene_numbers.items()
                    if isinstance(entity, (NumberEntity, dict))}
        entities = [entity for entity in entities if isinstance(entity, NumberEntity)]
        target = next((entity for entity in entities if entity.is_target), None)
        if target is None and self.target_entity is not None:
            target = self.target_entity
            entities.append(target)
        if target is not None and target_value is not None:
            target.value = float(target_value)
            target.is_target = True
            if target.role == "UNKNOWN":
                target.role = "TARGET"
        if target is not None:
            self.target_entity = target

        self._assign_number_entity_ids(entities)
        scene = {entity.entity_id: entity for entity in entities if entity.entity_id}
        self.scene_numbers = scene
        self._scene_number_entities = list(scene.values())
        self._augment_number_auto_features(self._scene_number_entities)

        flags = {}
        for entity_id, entity in scene.items():
            old = previous.get(entity_id)
            if not old:
                continue
            transitions = Learner._entity_attribute_delta(old, entity.snapshot())
            for attribute, observation in transitions.items():
                if observation.get("changed"):
                    flags[f"{entity_id}:{attribute}_changed"] = True
                    flags[f"{entity.role.lower()}_{attribute}_changed"] = True
            if transitions.get("value", {}).get("changed"):
                flags[f"{entity.role.lower()}_changed"] = True
        self._number_change_flags = flags
        structure_tokens = []
        for entity_id, entity in sorted(scene.items()):
            folded = self._normalized_number_label(entity.label)
            structure_tokens.append(
                f"{entity_id}:{entity.role}:{folded[:24]}:{entity.unit}:{entity.format_signature}")
        self._number_structure_hash = "n" + hashlib.sha1(
            "|".join(structure_tokens).encode("utf-8", "replace")).hexdigest()[:8]

    def _bootstrap_target_semantics(self, rect, snapshot, screen, value, confidence, text):
        fallback = NumberEntity(
            float(value), str(text or value), tuple(rect), float(confidence),
            role="TARGET", direction="maximize", is_target=True, source="selection",
            format_signature=json.dumps(
                self._numeric_format_signature(text or value), sort_keys=True, separators=(",", ":")),
            window_id=self._number_window_identity(rect))
        self.target_entity = fallback
        if snapshot is None:
            self._update_scene_numbers([fallback], target_value=value)
            return
        client = self._target_client_rect()
        if not client:
            self._update_scene_numbers([fallback], target_value=value)
            return
        crop = (max(0, int(math.floor(client[0] - screen[0]))),
                max(0, int(math.floor(client[1] - screen[1]))),
                min(snapshot.width, int(math.ceil(client[2] - screen[0]))),
                min(snapshot.height, int(math.ceil(client[3] - screen[1]))))
        if crop[2] - crop[0] < 8 or crop[3] - crop[1] < 8:
            self._update_scene_numbers([fallback], target_value=value)
            return
        image = snapshot.crop(crop)
        items = self._ocr_scene_items(image, client, max_side=1320)
        entities = self._number_entities_from_items(items, target_rect=rect, target_value=value)
        if not any(entity.is_target for entity in entities):
            entities.append(fallback)
        self._semantic_features = {}
        self._update_scene_numbers(entities, target_value=value)
        semantic_tokens = [f"num:{entity.role}:{hashlib.sha1(entity.label.encode('utf-8', 'replace')).hexdigest()[:4]}"
                           for entity in entities if entity.role != "UNKNOWN"]
        for item in items:
            semantic = self._action_semantic_from_text(item.get("text", ""))
            self._update_semantic_features_from_action(semantic)
            if semantic.type != "unknown":
                semantic_tokens.append(f"act:{semantic.type}")
        if semantic_tokens:
            self._remember_semantic_scene(semantic_tokens)
        self._last_semantic_scan_at = time.monotonic()

    def _refresh_number_visual_attributes(self):
        all_entities = [entity for entity in self.scene_numbers.values()
                        if isinstance(entity, NumberEntity)]
        if not all_entities:
            return
        if self.capture is None or self.np is None or self.cv2 is None:
            self._mark_number_visual_state(all_entities, "sensor_failed", "visual_runtime_unavailable")
            self._set_source_health(
                "visual_features", False, 0.0, "visual_runtime_unavailable", "sensor_failed")
            return
        # Every refresh defines a new sampling instant. Budgeted-out entities are
        # explicitly not_sampled rather than silently carrying forward old pixels.
        self._mark_number_visual_state(all_entities, "not_sampled", "refresh_budget")
        entities = list(all_entities)
        if not hasattr(self, "_number_attribute_activity"):
            self._number_attribute_activity = {}
        self._number_visual_refresh_step = int(getattr(self, "_number_visual_refresh_step", 0)) + 1
        if len(entities) > 24:
            runtime_class = str(getattr(getattr(self, "hardware", None), "runtime_class", ""))
            budget = min(len(entities), 30 if runtime_class == "极速" else 20)
            ranked = sorted(
                entities,
                key=lambda entity: (bool(entity.is_target),
                                    sum(float(value) for value in self._number_attribute_activity.get(
                                        entity.entity_id, {}).values()),
                                    float(entity.confidence)),
                reverse=True)
            active_budget = max(1, budget * 2 // 3)
            selected = ranked[:active_budget]
            remainder = ranked[active_budget:]
            if remainder:
                start = (self._number_visual_refresh_step * max(1, budget - active_budget)) % len(remainder)
                selected.extend((remainder + remainder)[start:start + budget - len(selected)])
            unique_entities, seen_entity_ids = [], set()
            for entity in selected:
                if entity.entity_id not in seen_entity_ids:
                    seen_entity_ids.add(entity.entity_id)
                    unique_entities.append(entity)
            entities = unique_entities
        bounds = virtual_screen_rect()
        union = self._rect_union([entity.bbox for entity in entities])
        if not union:
            self._set_source_health("visual_features", False, 0.0, "empty_visual_union", "not_sampled")
            return
        padding = max(3.0, min(18.0, max(entity.height for entity in entities) * 0.40))
        capture_rect = self._clip_rect((union[0] - padding, union[1] - padding,
                                        union[2] + padding, union[3] + padding), bounds)
        if not capture_rect:
            self._set_source_health("visual_features", False, 0.0, "invalid_visual_rect", "not_sampled")
            return
        try:
            image = self.capture.grab(capture_rect)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            now = time.monotonic()
            for entity in entities:
                before = entity.snapshot()
                source_points = entity.quad if entity.quad and len(entity.quad) >= 4 else (
                    (entity.bbox[0], entity.bbox[1]), (entity.bbox[2], entity.bbox[1]),
                    (entity.bbox[2], entity.bbox[3]), (entity.bbox[0], entity.bbox[3]))
                points = self.np.asarray([[float(px) - capture_rect[0], float(py) - capture_rect[1]]
                                          for px, py in source_points], dtype="float32")
                visual = self._number_visual_features(rgb, points, capture_rect)
                observations = dict(visual.get("feature_observations", {}))
                for name, payload in observations.items():
                    observation = FeatureObservation.from_any(
                        payload, name=name, observed_at=now)
                    entity.set_feature(name, observation)
                entity.observed_at = now
                entity.last_seen = now
                entity.present = 1.0
                entity.visibility = max(0.0, min(1.0, float(entity.confidence)))
                entity.detection_confidence = max(0.0, min(1.0, float(entity.confidence)))
                entity.occluded = 0.0
                transitions = Learner._entity_attribute_delta(before, entity.snapshot())
                activity = self._number_attribute_activity.setdefault(entity.entity_id, {})
                for name, observation in transitions.items():
                    old_activity = float(activity.get(name, 0.0))
                    activity[name] = old_activity * 0.92 + (
                        1.0 if observation.get("changed") else 0.0) * 0.08
                if "discovery" in activity:
                    activity["discovery"] = float(activity["discovery"]) * 0.86
            self._augment_number_auto_features(self.scene_numbers.values())
        except Exception as exc:
            self._mark_number_visual_state(all_entities, "sensor_failed", type(exc).__name__)
            self._set_source_health(
                "visual_features", False, 0.0,
                f"visual_refresh_exception:{type(exc).__name__}", "sensor_failed")
            self._log_once("number_visual_refresh", "number_visual_refresh_error", type(exc).__name__)

    def _fast_number_read_rect(self, entity):
        try:
            x1, y1, x2, y2 = (float(v) for v in entity.bbox)
            now = time.monotonic()
            elapsed = max(0.0, now - float(entity.observed_at or now))
            vx = float(entity.velocity.get("x", 0.0) or 0.0) if isinstance(entity.velocity, dict) else 0.0
            vy = float(entity.velocity.get("y", 0.0) or 0.0) if isinstance(entity.velocity, dict) else 0.0
            dx, dy = vx * min(1.25, elapsed), vy * min(1.25, elapsed)
            width, height = max(3.0, x2 - x1), max(3.0, y2 - y1)
            margin_x = max(3.0, width * 0.20)
            margin_y = max(2.0, height * 0.26)
            rect = (x1 + dx - margin_x, y1 + dy - margin_y,
                    x2 + dx + margin_x, y2 + dy + margin_y)
            return self._clip_rect(rect, virtual_screen_rect())
        except Exception:
            return None

    def _refresh_tracked_number_values_fast(self, score_override=None):
        """Re-read tracked numeric bboxes without a full-scene detection pass.

        Target is supplied by the dedicated high-confidence reader. Other numbers are
        budgeted by recent attribute activity, causal use, and time since last read;
        stable numbers naturally fall into a slower round-robin cadence.
        """
        if self.stop_event.is_set() or not self.reader:
            return 0
        now = time.monotonic()
        if score_override is not None and isinstance(self.target_entity, NumberEntity):
            self.target_entity.value = float(score_override)
            self.target_entity.observed_at = now
        candidates = []
        learner = self._active_learner
        predictive = {}
        if learner is not None:
            try:
                for relation in learner.attribute_relations.values():
                    if not isinstance(relation, dict):
                        continue
                    entity_id = str(relation.get("from_entity", ""))
                    if not entity_id:
                        continue
                    n = float(relation.get("n", 0.0))
                    strength = abs(float(relation.get("causal_product", relation.get("product", 0.0))))
                    predictive[entity_id] = max(predictive.get(entity_id, 0.0), math.log1p(n) * min(4.0, strength))
            except Exception:
                predictive = {}
        for entity_id, entity in self.scene_numbers.items():
            if not isinstance(entity, NumberEntity) or entity.is_target:
                continue
            activity = self._number_attribute_activity.get(entity_id, {})
            changed = 1.0 if ("value" in entity.changed_attributes or float(activity.get("value", 0.0)) > 0.08) else 0.0
            causal = min(2.0, predictive.get(entity_id, 0.0) * 0.18)
            age = max(0.0, now - float(self._number_fast_read_at.get(entity_id, 0.0)))
            misses = int(self._number_fast_read_misses.get(entity_id, 0))
            priority = changed * 2.5 + causal + min(2.0, age * 0.45) + float(entity.confidence) * 0.15 - misses * 0.08
            candidates.append((priority, age, entity_id, entity))
        if not candidates:
            return 0
        tier = str(getattr(self.hardware, "tier", "balanced")) if self.hardware else "balanced"
        base_budget = 2 if tier == "low" else (5 if tier == "high" else 3)
        active_count = sum(1 for entity_id, entity in self.scene_numbers.items()
                           if isinstance(entity, NumberEntity) and not entity.is_target and
                           float(self._number_attribute_activity.get(entity_id, {}).get("value", 0.0)) > 0.08)
        budget = max(1, min(8, base_budget + min(3, active_count)))
        ranked = sorted(candidates, reverse=True)
        selected = ranked[:budget]
        # Guarantee ordinary entities eventually get sampled even if a few hot values
        # dominate the priority ranking indefinitely.
        if len(ranked) > budget:
            rr_index = self._number_fast_read_cursor % len(ranked)
            rr = ranked[rr_index]
            self._number_fast_read_cursor = (rr_index + 1) % len(ranked)
            if all(item[2] != rr[2] for item in selected):
                selected[-1] = rr
        refreshed = 0
        for _priority, _age, entity_id, entity in selected:
            if self.stop_event.is_set():
                break
            rect = self._fast_number_read_rect(entity)
            if not rect:
                continue
            expected = float(entity.value)
            try:
                value, confidence, text = self.reader.read(rect, expected=expected)
            except Exception:
                value, confidence, text = None, 0.0, ""
            self._number_fast_read_at[entity_id] = time.monotonic()
            if value is None or confidence < 0.34:
                self._number_fast_read_misses[entity_id] = min(20, int(self._number_fast_read_misses.get(entity_id, 0)) + 1)
                continue
            # Large discontinuities require stronger OCR confidence, while ordinary
            # changes can be accepted immediately for action-level causality.
            scale = max(1.0, abs(expected))
            relative = abs(float(value) - expected) / scale
            if relative > 30.0 and confidence < 0.82:
                self._number_fast_read_misses[entity_id] = min(20, int(self._number_fast_read_misses.get(entity_id, 0)) + 1)
                continue
            old_value = float(entity.value)
            entity.value = float(value)
            if abs(entity.value - old_value) > max(1e-9, abs(old_value) * 1e-10):
                activity = self._number_attribute_activity.setdefault(entity_id, {})
                activity["value"] = float(activity.get("value", 0.0)) * 0.82 + 0.18
                changed = set(entity.changed_attributes)
                changed.add("value")
                entity.changed_attributes = tuple(sorted(changed))
            else:
                activity = self._number_attribute_activity.setdefault(entity_id, {})
                activity["value"] = float(activity.get("value", 0.0)) * 0.96
            if text:
                entity.text = str(text)[:100]
                entity.format_signature = json.dumps(
                    self._numeric_format_signature(text), ensure_ascii=True,
                    sort_keys=True, separators=(",", ":"))
            entity.confidence = max(0.0, min(1.0, float(confidence)))
            entity.detection_confidence = entity.confidence
            entity.last_seen = time.monotonic()
            entity.observed_at = entity.last_seen
            entity.source = "fast-ocr"
            self._number_fast_read_misses[entity_id] = max(0, int(self._number_fast_read_misses.get(entity_id, 0)) - 1)
            refreshed += 1
        return refreshed

    def _update_number_spatial_features(self):
        client = self._target_client_rect() or virtual_screen_rect()
        if not client:
            return
        cw = max(1.0, float(client[2] - client[0]))
        ch = max(1.0, float(client[3] - client[1]))
        entities = [entity for entity in self.scene_numbers.values() if isinstance(entity, NumberEntity)]
        normalized = {}
        for entity in entities:
            try:
                cx, cy = (float(entity.center[0]), float(entity.center[1]))
                fx = (cx - float(client[0])) / cw
                fy = (cy - float(client[1])) / ch
                normalized[entity.entity_id] = (fx, fy)
                entity.set_feature("window_center", (fx, fy), kind="vector", confidence=entity.confidence,
                                   metadata={"scale": 1.0, "coordinate_space": "target_client"})
                entity.set_feature("window_width_ratio", max(0.0, float(entity.width) / cw),
                                   kind="scalar", confidence=entity.confidence, metadata={"scale": 1.0})
                entity.set_feature("window_height_ratio", max(0.0, float(entity.height) / ch),
                                   kind="scalar", confidence=entity.confidence, metadata={"scale": 1.0})
            except Exception:
                continue
        for entity in entities:
            point = normalized.get(entity.entity_id)
            if point is None:
                continue
            fx, fy = point
            others = [(math.hypot(ox - fx, oy - fy), ox - fx, oy - fy)
                      for other_id, (ox, oy) in normalized.items() if other_id != entity.entity_id]
            if others:
                distance, dx, dy = min(others, key=lambda item: item[0])
                entity.set_feature("nearest_number_offset", (dx, dy), kind="vector",
                                   confidence=entity.confidence, metadata={"scale": 1.0})
                entity.set_feature("nearest_number_distance", distance, kind="scalar",
                                   confidence=entity.confidence, metadata={"scale": 1.0})
            controls = []
            for control in self._controls.values():
                try:
                    cfx, cfy = control.get("center", (None, None))
                    cfx, cfy = float(cfx), float(cfy)
                    controls.append((math.hypot(cfx - fx, cfy - fy), cfx - fx, cfy - fy))
                except Exception:
                    continue
            if controls:
                distance, dx, dy = min(controls, key=lambda item: item[0])
                entity.set_feature("nearest_control_offset", (dx, dy), kind="vector",
                                   confidence=entity.confidence, metadata={"scale": 1.0})
                entity.set_feature("nearest_control_distance", distance, kind="scalar",
                                   confidence=entity.confidence, metadata={"scale": 1.0})

    def _number_snapshot(self, score_override=None, refresh_visual=True):
        if refresh_visual:
            self._refresh_number_visual_attributes()
        self._update_number_spatial_features()
        snapshot = {}
        target_id = getattr(self.target_entity, "entity_id", "")
        for entity_id, entity in self.scene_numbers.items():
            if not isinstance(entity, NumberEntity):
                continue
            item = entity.snapshot()
            if entity.is_target or entity_id == target_id:
                item["semantic_role"] = item.get("role", "TARGET")
                item["role"] = "TARGET"
            snapshot[str(entity_id)] = item
        if score_override is not None and self.target_entity is not None:
            entity_id = self.target_entity.entity_id or "num_target"
            target = snapshot.setdefault(
                entity_id, {"entity_id": entity_id, "confidence": 1.0,
                            "label": "", "role": "TARGET", "is_target": True})
            target["value"] = float(score_override)
            target["role"] = "TARGET"
            target["is_target"] = True
            target["confidence"] = max(0.75, float(target.get("confidence", 0.0)))
        return snapshot

    def _number_state_signature(self, score):
        learner = self._active_learner
        predictive = {}
        if learner is not None:
            for relation in learner.attribute_relations.values():
                try:
                    if not bool(relation.get("to_target", False)) or bool(relation.get("passive_pair", False)):
                        continue
                    if str(relation.get("to_attribute", "")) != "value":
                        continue
                    key = (str(relation.get("from_entity", "")), str(relation.get("from_attribute", "")))
                    n = float(relation.get("n", 0.0))
                    product = abs(float(relation.get("causal_product", relation.get("product", 0.0))))
                    predictive[key] = max(predictive.get(key, 0.0), math.log1p(n) * min(4.0, product))
                except Exception:
                    continue
        candidates = []
        for entity_id, entity in self.scene_numbers.items():
            if not isinstance(entity, NumberEntity):
                continue
            activity = self._number_attribute_activity.get(entity_id, {})
            attrs = set(activity) | set(entity.velocity) | set(entity.changed_attributes)
            for attribute in attrs:
                if attribute == "discovery":
                    continue
                score_weight = float(activity.get(attribute, 0.0)) + predictive.get((entity_id, attribute), 0.0) * 0.28
                if entity.is_target:
                    score_weight += 0.10
                if score_weight <= 0.015:
                    continue
                velocity = entity.velocity.get(attribute)
                if isinstance(velocity, (int, float)) and math.isfinite(float(velocity)):
                    v = float(velocity)
                    bucket = "0" if abs(v) < 1e-9 else ("+" if v > 0 else "-") + str(min(9, int(math.log10(abs(v) + 1.0) * 2.0)))
                elif isinstance(velocity, list) and velocity:
                    mag = math.sqrt(sum(float(x) * float(x) for x in velocity))
                    bucket = "v" + str(min(9, int(math.log10(mag + 1.0) * 2.0)))
                else:
                    bucket = "c1" if attribute in entity.changed_attributes else "c0"
                candidates.append((score_weight, f"{entity_id}.{attribute}={bucket}"))
        top = [token for _weight, token in sorted(candidates, reverse=True)[:8]]
        if not top:
            target = self.target_entity
            if isinstance(target, NumberEntity):
                top = [f"{target.entity_id}.value={'+' if float(score) >= 0 else '-'}"]
        digest = hashlib.sha1("|".join(top).encode("utf-8", "replace")).hexdigest()[:10]
        changed_count = 0
        for entity in self.scene_numbers.values():
            if isinstance(entity, NumberEntity):
                changed_count += len(set(entity.changed_attributes) - {"discovery"})
        predictive_count = sum(1 for value in predictive.values() if value > 0.02)
        target_direction = "f"
        target = self.target_entity
        if isinstance(target, NumberEntity):
            try:
                target_velocity = float(target.velocity.get("value", 0.0) or 0.0)
            except (TypeError, ValueError):
                target_velocity = 0.0
            if abs(target_velocity) <= 1e-9:
                target_velocity = float(self._state_velocity or 0.0)
            if target_velocity > 1e-9:
                target_direction = "u"
            elif target_velocity < -1e-9:
                target_direction = "d"
        return (f"nf{digest}-chg{min(999, changed_count)}"
                f"-pred{min(999, predictive_count)}-dir{target_direction}")

    def _semantic_feature_signature(self):
        """Hash whatever semantic evidence exists; no domain vocabulary is assumed."""
        bag = {}

        def add(raw, prefix="token", near=False):
            normalized = unicodedata.normalize("NFKC", str(raw or "")).strip().lower()
            if not normalized:
                return
            normalized = re.sub(r"\d+(?:[.,，．'’ ]\d+)*", "#", normalized)
            normalized = re.sub(r"\s+", " ", normalized)[:120]
            digest = hashlib.sha1(normalized.encode("utf-8", "replace")).hexdigest()[:10]
            key = f"{prefix}:{digest}:{'near' if near else 'present'}"
            bag[key] = bag.get(key, 0) + 1

        for token in self._semantic_tokens:
            add(token, "scene")
        for name, value in dict(self._semantic_features or {}).items():
            if value:
                add(name, "feature")
        target = self.target_entity
        target_center = getattr(target, "center", None) if isinstance(target, NumberEntity) else None
        basis = self._target_client_rect() or virtual_screen_rect()
        scale = max(1.0, math.hypot(float(basis[2] - basis[0]), float(basis[3] - basis[1])))
        for control in self._controls.values():
            center = control.get("center")
            near = False
            if target_center and center:
                try:
                    # control centers are normalized while target center is screen-space.
                    tx = (float(target_center[0]) - basis[0]) / max(1.0, basis[2] - basis[0])
                    ty = (float(target_center[1]) - basis[1]) / max(1.0, basis[3] - basis[1])
                    near = math.hypot(float(center[0]) - tx, float(center[1]) - ty) <= 0.28
                except Exception:
                    near = False
            add(control.get("text") or control.get("id"), "control", near=near)
        for entity in self.scene_numbers.values():
            if not isinstance(entity, NumberEntity):
                continue
            near = False
            if target_center and entity.center:
                try:
                    near = math.hypot(float(entity.center[0]) - float(target_center[0]),
                                      float(entity.center[1]) - float(target_center[1])) / scale <= 0.24
                except Exception:
                    near = False
            add(entity.label or entity.text, "number", near=near)
        encoded = "|".join(f"{key}={min(99, count)}" for key, count in sorted(bag.items()))
        digest = hashlib.sha1(encoded.encode("utf-8", "replace")).hexdigest()[:12]
        return f"sf{digest}n{min(999, sum(bag.values()))}"

    def _bind_control_number_semantics(self):
        """Bind spatial neighbors without assigning application-domain names."""
        if not self._controls or not self._scene_number_entities:
            return
        client = self._target_client_rect()
        if not client:
            return
        cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
        for control in self._controls.values():
            x1, y1, x2, y2 = control.get("bbox", (0.0, 0.0, 0.0, 0.0))
            cx, cy = control.get("center", ((x1+x2)*0.5, (y1+y2)*0.5))
            ranked = []
            for entity in self._scene_number_entities:
                bx1 = (entity.bbox[0] - client[0]) / cw
                by1 = (entity.bbox[1] - client[1]) / ch
                bx2 = (entity.bbox[2] - client[0]) / cw
                by2 = (entity.bbox[3] - client[1]) / ch
                ex, ey = (bx1 + bx2) * 0.5, (by1 + by2) * 0.5
                inside = (x1 - 0.02 <= ex <= x2 + 0.02 and y1 - 0.02 <= ey <= y2 + 0.02)
                below = (x1 - 0.03 <= ex <= x2 + 0.03 and y2 <= ey <= y2 + 0.075)
                right = (x2 <= ex <= x2 + 0.09 and y1 - 0.02 <= ey <= y2 + 0.02)
                distance = math.hypot(ex - cx, ey - cy)
                spatial_bonus = 3.0 if inside else (2.0 if below else (1.5 if right else 0.0))
                score = spatial_bonus + entity.confidence - distance * 5.0
                if score > 0.35:
                    ranked.append((score, entity))
            if ranked:
                ranked.sort(reverse=True, key=lambda item: item[0])
                control["nearby_number_ids"] = tuple(
                    entity.entity_id for _score, entity in ranked[:4])
                best_score, best = ranked[0]
                if best_score >= 1.0:
                    best.control_id = str(control.get("id", ""))

    def _scan_scene_semantics(self, score=None, reason="periodic", force=False):
        if self.stop_event.is_set():
            return False
        now = time.monotonic()
        if not force and now - self._last_semantic_scan_at < LEARNING_CONFIG.semantic_refresh_seconds:
            return False
        client = self._target_client_rect()
        if not client:
            self._set_source_health("scene_ocr", False, 0.0, "scene_client_unavailable")
            return False
        scan_rect = self._adaptive_operation_rect(refresh=False, reason="semantic-scan") or client
        try:
            if self.stop_event.is_set():
                return False
            image = self.capture.grab(scan_rect)
            self._set_source_health("capture", True, 1.0, "")
            if self.stop_event.is_set():
                return False
            items = self._ocr_scene_items(image, scan_rect)
            if not items:
                self._set_source_health("scene_ocr", False, 0.0, "scene_ocr_empty", "not_sampled")
                return False
            scene_confidence = sum(float(item.get("confidence", 0.0) or 0.0) for item in items) / max(1, len(items))
            target_rect = self._current_roi()
            target_value = score if score is not None else (self.target_entity.value if self.target_entity else None)
            old_hash = self._number_structure_hash
            entities = self._number_entities_from_items(items, target_rect=target_rect, target_value=target_value)
            previous_count = len(self.scene_numbers)
            observed_count = len(entities)
            if previous_count >= 3 and observed_count < max(1, int(math.ceil(previous_count * 0.55))):
                structure = "|".join(sorted(
                    f"{self._normalized_number_label(entity.label)}:{entity.role}:{entity.unit}"
                    for entity in entities))
                drop_token = hashlib.sha1(
                    f"{observed_count}|{structure}".encode("utf-8", "replace")).hexdigest()[:12]
                pending = self._pending_scene_drop or {}
                confirmed = (pending.get("token") == drop_token and
                             now - float(pending.get("at", 0.0) or 0.0) <=
                             max(2.0, LEARNING_CONFIG.semantic_refresh_seconds * 3.0))
                if not confirmed:
                    self._pending_scene_drop = {"token": drop_token, "at": now,
                                                "previous": previous_count, "observed": observed_count}
                    self._set_source_health(
                        "scene_ocr", False, scene_confidence,
                        "scene_entity_drop_unconfirmed", "stale")
                    self._log_runtime("measurement_failure",
                                      f"scene_drop {previous_count}->{observed_count} awaiting confirmation")
                    return False
                self._pending_scene_drop = None
                self._set_source_health(
                    "scene_ocr", True, scene_confidence, "", "confirmed_absent")
            else:
                self._pending_scene_drop = None
                self._set_source_health("scene_ocr", True, scene_confidence, "", "observed")
            candidate_target = next((entity for entity in entities if entity.is_target), None)
            if candidate_target is not None and self._target_anchor:
                identity_score = self._target_identity_score(candidate_target)
                if identity_score < 0.42:
                    self._log_runtime("target_identity_drop", f"score={identity_score:.3f}")
                    if self._relocalize_target(expected=target_value):
                        self._last_semantic_scan_at = now
                        return True
            self._semantic_features = {}
            self._update_scene_numbers(entities, target_value=target_value)
            self._bind_control_number_semantics()
            semantic_tokens = [f"num:{entity.role}:{hashlib.sha1(entity.label.encode('utf-8', 'replace')).hexdigest()[:4]}"
                               for entity in entities if entity.role != "UNKNOWN"]
            for item in items:
                semantic = self._action_semantic_from_text(item.get("text", ""))
                self._update_semantic_features_from_action(semantic)
                if semantic.type != "unknown":
                    semantic_tokens.append(f"act:{semantic.type}")
            if semantic_tokens:
                self._remember_semantic_scene(semantic_tokens)
            self._last_semantic_scan_at = now
            changed = old_hash != self._number_structure_hash
            return True
        except Exception as exc:
            self._set_source_health("scene_ocr", False, 0.0, f"scene_ocr_exception:{type(exc).__name__}")
            self._set_source_health("capture", False, 0.0, f"capture_or_scan_exception:{type(exc).__name__}")
            self._log_runtime("semantic_scan_error", f"{reason}:{type(exc).__name__}")
            return False

    def _should_semantic_refresh(self, action, stagnant, learner_steps=0):
        if stagnant >= 12:
            return True
        if learner_steps - self._last_semantic_scan_step >= LEARNING_CONFIG.semantic_refresh_steps:
            return True
        if str(action).startswith(("click:control:", "uia:")):
            control_id = (str(action).split(":", 2)[2] if str(action).startswith("click:control:")
                          else self._uia_control_id_from_action(action))
            control = self._controls.get(control_id, {})
            if control.get("action_type") not in {None, "", "unknown", "navigate", "continue"}:
                return True
        return False

    @staticmethod
    def _semantic_text_features(raw_text):
        text = unicodedata.normalize("NFKC", str(raw_text or "")).strip().lower()
        compact = re.sub(r"\s+", "", text)
        if not compact:
            return 0.0, False, None

        # Hard-coded text is reserved for an irreversible/external side-effect
        # safety barrier. Ordinary progression/economy words never receive a
        # positive or negative utility prior.
        irreversible = (
            "delete", "erase", "format", "uninstall", "factory reset", "clear data",
            "checkout", "payment", "pay now", "confirm purchase", "order now",
            "删除", "抹除", "格式化", "卸载", "恢复出厂", "清除数据",
            "支付", "付款", "结账", "确认购买", "订购",
        )
        def has_term(term):
            if any(ord(ch) > 127 for ch in term):
                return term in text
            return re.search(r"(?<![a-z0-9_])" + re.escape(term) + r"(?![a-z0-9_])", text) is not None
        sensitive = any(has_term(term) for term in irreversible)
        folded = re.sub(r"\d+(?:[.,]\d+)?", "#", compact)[:64]
        prefix = "risk:" if sensitive else "text:"
        token = prefix + hashlib.sha1(folded.encode("utf-8", "replace")).hexdigest()[:8]
        return (-0.12 if sensitive else 0.0), sensitive, token
    def _remember_semantic_scene(self, tokens):
        cleaned = sorted({str(x) for x in tokens if x})[:32]
        if not cleaned:
            return self._semantic_scene
        digest = hashlib.sha1("|".join(cleaned).encode("utf-8", "replace")).hexdigest()[:8]
        candidate = "h" + digest
        if candidate != self._semantic_scene:
            self._scene_revision += 1
        self._semantic_scene = candidate
        self._semantic_tokens = tuple(cleaned)
        return candidate

    @staticmethod
    def _key_hints_from_text(raw_text):

        text = unicodedata.normalize("NFKC", str(raw_text or "")).strip().lower()
        if not text:
            return []
        aliases = {
            "space": "SPACE", "spacebar": "SPACE", "空格": "SPACE", "空格键": "SPACE",
            "enter": "ENTER", "return": "ENTER", "回车": "ENTER", "回车键": "ENTER",
            "tab": "TAB", "tab键": "TAB",
            "up": "UP", "uparrow": "UP", "上": "UP", "上键": "UP", "↑": "UP",
            "down": "DOWN", "downarrow": "DOWN", "下": "DOWN", "下键": "DOWN", "↓": "DOWN",
            "left": "LEFT", "leftarrow": "LEFT", "左": "LEFT", "左键": "LEFT", "←": "LEFT",
            "right": "RIGHT", "rightarrow": "RIGHT", "右": "RIGHT", "右键": "RIGHT", "→": "RIGHT",
            "backspace": "BACKSPACE", "退格": "BACKSPACE", "退格键": "BACKSPACE",
            "delete": "DELETE", "del": "DELETE", "删除键": "DELETE",
            "insert": "INSERT", "ins": "INSERT", "home": "HOME", "end": "END",
            "pageup": "PAGEUP", "pgup": "PAGEUP", "pagedown": "PAGEDOWN",
            "pgdn": "PAGEDOWN", "shift": "SHIFT", "ctrl": "CTRL",
            "control": "CTRL", "alt": "ALT", "win": "LWIN", "windows": "LWIN",
        }
        hints = []
        key_token = (r"spacebar|backspace|delete|insert|pageup|pagedown|uparrow|downarrow|"
                     r"leftarrow|rightarrow|windows|control|return|enter|space|tab|del|ins|"
                     r"home|end|pgup|pgdn|shift|ctrl|alt|win|up|down|left|right|"
                     r"空格键?|回车键?|tab键|退格键?|删除键|上键|下键|左键|右键|↑|↓|←|→|"
                     r"f(?:[1-9]|1\d|2[0-4])|[a-z0-9]")
        patterns = [
            rf"(?:press|tap|hit|key|按下?|按键|键)\s*[:：]?\s*[\[(【]?\s*({key_token})\s*[\])】]?",
            rf"[\[(【]\s*({key_token})\s*[\])】]",
            rf"\b({key_token})\s*key\b",
            rf"({key_token})\s*键\b",
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.I):
                token = match.group(1).lower().replace(" ", "")
                name = aliases.get(token, token.upper())
                action = f"key:{name}"
                if action in KEY_ACTIONS and action not in hints:
                    hints.append(action)
        combo_pattern = re.compile(
            rf"(ctrl|control|shift|alt|win|windows)\s*\+\s*({key_token})", re.I)
        for match in combo_pattern.finditer(text):
            left = aliases.get(match.group(1).lower(), match.group(1).upper())
            right = aliases.get(match.group(2).lower(), match.group(2).upper())
            action = f"chord:{left}+{right}"
            if left != "ESC" and right != "ESC" and action not in hints:
                hints.append(action)
        return hints

    @staticmethod
    def _control_slug(text, role, semantic):
        normalized = unicodedata.normalize("NFKC", str(text or "")).strip().lower()
        normalized = re.sub(r"\d+(?:[.,]\d+)?", "#", normalized)
        ascii_slug = re.sub(r"[^a-z0-9]+", "_", normalized).strip("_")[:34]
        if ascii_slug:
            return ascii_slug
        seed = f"{role}|{semantic}|{normalized}"
        return f"{role}_{hashlib.sha1(seed.encode('utf-8', 'replace')).hexdigest()[:10]}"

    def _register_control(self, role, text, bbox, semantic="neutral", enabled=True,
                          source="vision", score=0.0, danger=False):
        try:
            x1, y1, x2, y2 = [max(0.0, min(1.0, float(v))) for v in bbox]
            if x2 <= x1 or y2 <= y1:
                return None
            role = re.sub(r"[^a-z0-9_]+", "_", str(role or "control").lower()).strip("_") or "control"
            semantic = str(semantic or "neutral")
            action_semantic = self._action_semantic_from_text(text)
            base = self._control_slug(text, role, semantic)
            if action_semantic.type != "unknown":
                base = f"{action_semantic.type}_{base}"[:72]
            control_id = base
            center = ((x1 + x2) * 0.5, (y1 + y2) * 0.5)
            existing = self._controls.get(control_id)
            if existing:
                old = existing.get("center", center)
                if abs(old[0] - center[0]) > 0.12 or abs(old[1] - center[1]) > 0.12:
                    control_id = f"{base}_r{min(3,int(center[1]*4))}c{min(5,int(center[0]*6))}"
            self._update_semantic_features_from_action(action_semantic)
            danger = bool(danger or action_semantic.risk >= 0.92)
            item = {
                "id": control_id, "role": role, "text": str(text or "")[:120],
                "bbox": (x1, y1, x2, y2), "center": center,
                "semantic": semantic, "enabled": bool(enabled), "source": str(source),
                "score": float(score), "danger": bool(danger),
                "action": f"click:control:{control_id}",
                "action_type": action_semantic.type, "risk": action_semantic.risk,
                "semantic_confidence": action_semantic.confidence,
            }
            previous = self._controls.get(control_id)
            if previous is None or float(previous.get("score", -1e9)) <= float(score):
                self._controls[control_id] = item
            return self._controls.get(control_id)
        except Exception as exc:
            self._log_runtime("control_register_error", type(exc).__name__)
            return None

    def _control_graph_update(self):
        tokens = []
        for control in self._controls.values():
            if control.get("danger"):
                continue
            x, y = control.get("center", (0.5, 0.5))
            tokens.append(f"{control.get('role')}|{control.get('semantic')}|{control.get('action_type', 'unknown')}|"
                          f"{self._control_slug(control.get('text'), control.get('role'), control.get('semantic'))}|"
                          f"{int(bool(control.get('enabled', True)))}|r{min(3,int(y*4))}c{min(5,int(x*6))}")
        digest = hashlib.sha1("|".join(sorted(tokens)[:64]).encode("utf-8", "replace")).hexdigest()[:8]
        self._control_graph_hash = "c" + digest
        return self._control_graph_hash

    def _control_action_point_fraction(self, action):
        raw = str(action or "")
        if raw.startswith("click:control:"):
            control_id = raw.split(":", 2)[2]
        elif raw.startswith("uia:"):
            control_id = self._uia_control_id_from_action(raw)
        else:
            return None
        control = self._controls.get(control_id)
        if not control or control.get("danger") or not control.get("enabled", True):
            return None
        return control.get("center")

    def _action_fraction(self, action):
        control_point = self._control_action_point_fraction(action)
        if control_point is not None:
            return self._scope_fraction_to_virtual(*control_point)
        point = self._action_point_fraction(action)
        if point is None:
            return None
        if self._action_uses_virtual_coordinates(action):
            return point
        # Legacy actions are interpreted in the current scope only for compatibility;
        # newly generated actions are always virtual-screen stable.
        return self._scope_fraction_to_virtual(*point)

    def _uia_control_candidates(self, screen):
        """Discover interactable descendants by supported UI Automation patterns."""
        if os.name != "nt" or not screen or not self.target_hwnd:
            return []
        controls, scene_tokens = [], []
        try:
            import comtypes.client
            try:
                comtypes.client.GetModule("UIAutomationCore.dll")
            except Exception:
                pass
            from comtypes.gen import UIAutomationClient as UIA
            automation_class = getattr(UIA, "CUIAutomation8", None) or getattr(UIA, "CUIAutomation", None)
            interface = getattr(UIA, "IUIAutomation", None)
            if automation_class is None or interface is None:
                return []
            automation = comtypes.client.CreateObject(automation_class, interface=interface)
            root = automation.ElementFromHandle(wintypes.HWND(self.target_hwnd))
            condition = automation.CreateTrueCondition()
            elements = root.FindAll(4, condition)  # TreeScope_Subtree
            count = int(getattr(elements, "Length", 0) or 0)
        except Exception as exc:
            self._log_once("uia_init", "uia_init_error", type(exc).__name__)
            return []

        # Pattern IDs come from UIAutomationCore; availability is queried per element.
        pattern_ids = (
            (10000, "invoke"), (10001, "selection"), (10002, "value"),
            (10003, "range"), (10004, "scroll"), (10005, "expand"),
            (10010, "select_item"), (10015, "toggle"), (10017, "scroll_item"),
            (10018, "legacy"),
        )
        pattern_interfaces = {
            "invoke": "IUIAutomationInvokePattern",
            "selection": "IUIAutomationSelectionPattern",
            "value": "IUIAutomationValuePattern",
            "range": "IUIAutomationRangeValuePattern",
            "scroll": "IUIAutomationScrollPattern",
            "expand": "IUIAutomationExpandCollapsePattern",
            "select_item": "IUIAutomationSelectionItemPattern",
            "toggle": "IUIAutomationTogglePattern",
            "scroll_item": "IUIAutomationScrollItemPattern",
            "legacy": "IUIAutomationLegacyIAccessiblePattern",
        }
        sw, sh = max(1.0, float(screen[2] - screen[0])), max(1.0, float(screen[3] - screen[1]))
        for index in range(count):
            if self.stop_event.is_set():
                break
            try:
                element = elements.GetElement(index)
                if not bool(getattr(element, "CurrentIsEnabled", True)):
                    continue
                if bool(getattr(element, "CurrentIsOffscreen", False)):
                    continue
                supported = []
                pattern_objects = {}
                for pattern_id, pattern_name in pattern_ids:
                    try:
                        pattern = element.GetCurrentPattern(pattern_id)
                        if pattern:
                            interface_name = pattern_interfaces.get(pattern_name)
                            interface_type = getattr(UIA, interface_name, None) if interface_name else None
                            if interface_type is not None and hasattr(pattern, "QueryInterface"):
                                try:
                                    pattern = pattern.QueryInterface(interface_type)
                                except Exception:
                                    pass
                            supported.append(pattern_name)
                            pattern_objects[pattern_name] = pattern
                    except Exception:
                        continue
                if not supported:
                    continue
                rect = getattr(element, "CurrentBoundingRectangle", None)
                if rect is None:
                    continue
                try:
                    left = float(getattr(rect, "left", getattr(rect, "Left", 0.0)))
                    top = float(getattr(rect, "top", getattr(rect, "Top", 0.0)))
                    right = float(getattr(rect, "right", getattr(rect, "Right", 0.0)))
                    bottom = float(getattr(rect, "bottom", getattr(rect, "Bottom", 0.0)))
                except Exception:
                    try:
                        left, top, right, bottom = (float(rect[i]) for i in range(4))
                    except Exception:
                        continue
                left, top = max(float(screen[0]), left), max(float(screen[1]), top)
                right, bottom = min(float(screen[2]), right), min(float(screen[3]), bottom)
                width, height = right - left, bottom - top
                if width < 4 or height < 4 or width * height > sw * sh * 0.45:
                    continue
                label = unicodedata.normalize(
                    "NFKC", str(getattr(element, "CurrentName", "") or "")).strip().lower()
                automation_id = str(getattr(element, "CurrentAutomationId", "") or "")
                access_key = unicodedata.normalize(
                    "NFKC", str(getattr(element, "CurrentAccessKey", "") or "")).strip()
                accelerator_key = unicodedata.normalize(
                    "NFKC", str(getattr(element, "CurrentAcceleratorKey", "") or "")).strip()
                text_basis = label or automation_id or "+".join(supported)
                intent, danger, semantic_token = self._semantic_text_features(text_basis)
                semantic = "positive" if intent > 0.04 else "negative" if intent < -0.04 else "neutral"
                if semantic_token:
                    scene_tokens.append(("danger:" if danger else "") + semantic_token)
                fx1 = max(0.0, min(1.0, (left - screen[0]) / sw))
                fy1 = max(0.0, min(1.0, (top - screen[1]) / sh))
                fx2 = max(0.0, min(1.0, (right - screen[0]) / sw))
                fy2 = max(0.0, min(1.0, (bottom - screen[1]) / sh))
                if danger:
                    margin_x = min(0.025, max(0.004, (fx2 - fx1) * 0.16))
                    margin_y = min(0.025, max(0.004, (fy2 - fy1) * 0.20))
                    self._danger_regions.append((max(0.0, fx1 - margin_x), max(0.0, fy1 - margin_y),
                                                 min(1.0, fx2 + margin_x), min(1.0, fy2 + margin_y)))
                    continue
                for hint_text in (label, access_key, accelerator_key):
                    for hinted_action in self._key_hints_from_text(hint_text):
                        if self._keyboard_action_allowed(hinted_action):
                            self._dynamic_key_actions.add(hinted_action)
                            self.action_priors[hinted_action] = max(
                                self.action_priors.get(hinted_action, 0.0), 0.56)
                role = "uia_" + "_".join(supported[:3])
                score = 720.0 + min(180.0, len(supported) * 35.0) + intent * 90.0
                item = self._register_control(role, text_basis, (fx1, fy1, fx2, fy2), semantic,
                                              enabled=True, source="uia", score=score, danger=False)
                if item:
                    item["uia_patterns"] = tuple(supported)
                    item["uia_access_key"] = access_key
                    item["uia_accelerator_key"] = accelerator_key
                    item["_uia_element"] = element
                    item["_uia_patterns_runtime"] = pattern_objects
                    info = {}
                    try:
                        pattern = pattern_objects.get("range")
                        if pattern is not None:
                            info["range"] = {
                                "value": float(getattr(pattern, "CurrentValue")),
                                "minimum": float(getattr(pattern, "CurrentMinimum")),
                                "maximum": float(getattr(pattern, "CurrentMaximum")),
                                "small_change": float(getattr(pattern, "CurrentSmallChange", 0.0) or 0.0),
                                "large_change": float(getattr(pattern, "CurrentLargeChange", 0.0) or 0.0),
                                "readonly": bool(getattr(pattern, "CurrentIsReadOnly", False)),
                            }
                    except Exception:
                        pass
                    try:
                        pattern = pattern_objects.get("value")
                        if pattern is not None:
                            info["value"] = {
                                "value": str(getattr(pattern, "CurrentValue", "") or ""),
                                "readonly": bool(getattr(pattern, "CurrentIsReadOnly", False)),
                            }
                    except Exception:
                        pass
                    try:
                        pattern = pattern_objects.get("scroll")
                        if pattern is not None:
                            info["scroll"] = {
                                "horizontal": bool(getattr(pattern, "CurrentHorizontallyScrollable", False)),
                                "vertical": bool(getattr(pattern, "CurrentVerticallyScrollable", False)),
                                "h_percent": float(getattr(pattern, "CurrentHorizontalScrollPercent", -1.0)),
                                "v_percent": float(getattr(pattern, "CurrentVerticalScrollPercent", -1.0)),
                            }
                    except Exception:
                        pass
                    try:
                        pattern = pattern_objects.get("expand")
                        if pattern is not None:
                            info["expand"] = {"state": int(getattr(pattern, "CurrentExpandCollapseState", -1))}
                    except Exception:
                        pass
                    item["uia_pattern_info"] = info
                    controls.append(item)
            except Exception as exc:
                self._log_once(f"uia_element:{index % 8}", "uia_element_error", type(exc).__name__)
        if scene_tokens:
            self._remember_semantic_scene(scene_tokens)
        return sorted(controls, key=lambda item: float(item.get("score", 0.0)), reverse=True)

    def _native_control_candidates(self, screen):
        if os.name != "nt" or not screen or not self.target_hwnd:
            return []
        uia_controls = self._uia_control_candidates(screen)
        if uia_controls:
            return uia_controls
        sw, sh = screen[2] - screen[0], screen[3] - screen[1]
        if sw < 1 or sh < 1:
            return []
        controls, scene_tokens = [], []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def visit(hwnd, _lparam=0):
            if self.stop_event.is_set():
                return False
            try:
                if not user32.IsWindowVisible(hwnd) or not user32.IsWindowEnabled(hwnd):
                    return True
                rect = RECT()
                if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                    return True
                left, top = max(screen[0], rect.left), max(screen[1], rect.top)
                right, bottom = min(screen[2], rect.right), min(screen[3], rect.bottom)
                width, height = right - left, bottom - top
                area = width * height
                if width < 8 or height < 8 or area > sw * sh * 0.35:
                    return True
                style = int(user32.GetWindowLongPtrW(hwnd, -16))
                tab_stop = bool(style & 0x00010000)
                label = unicodedata.normalize("NFKC", window_title(hwnd)).strip().lower()
                # UIA is preferred.  This fallback is deliberately class-name agnostic:
                # focusability or a visible child caption is enough to become a candidate,
                # while visual/random coverage remains available for everything else.
                if int(hwnd) == int(self.target_hwnd):
                    return True
                if not tab_stop and not label:
                    return True
                intent, danger, semantic_token = self._semantic_text_features(label)
                semantic = "positive" if intent > 0.04 else "negative" if intent < -0.04 else "neutral"
                if semantic_token:
                    scene_tokens.append(("danger:" if danger else "") + semantic_token)
                fx1 = max(0.0, min(1.0, (left - screen[0]) / sw))
                fy1 = max(0.0, min(1.0, (top - screen[1]) / sh))
                fx2 = max(0.0, min(1.0, (right - screen[0]) / sw))
                fy2 = max(0.0, min(1.0, (bottom - screen[1]) / sh))
                if danger:
                    margin_x = min(0.025, max(0.004, (fx2 - fx1) * 0.16))
                    margin_y = min(0.025, max(0.004, (fy2 - fy1) * 0.20))
                    self._danger_regions.append((max(0.0, fx1 - margin_x), max(0.0, fy1 - margin_y),
                                                 min(1.0, fx2 + margin_x), min(1.0, fy2 + margin_y)))
                    return True
                for hinted_action in self._key_hints_from_text(label):
                    if self._keyboard_action_allowed(hinted_action):
                        self._dynamic_key_actions.add(hinted_action)
                        self.action_priors[hinted_action] = max(self.action_priors.get(hinted_action, 0.50), 0.54)
                        scene_tokens.append("hint:" + hinted_action)
                role = "native_focusable" if tab_stop else "native_control"
                score = 610.0 + intent * 90.0 + (55.0 if tab_stop else 0.0)
                item = self._register_control(role, label, (fx1, fy1, fx2, fy2), semantic,
                                              enabled=True, source="native", score=score, danger=False)
                if item:
                    controls.append(item)
            except Exception as exc:
                self._log_runtime("native_control_error", type(exc).__name__)
            return True

        child_callback = callback_type(visit)
        try:
            visit(self.target_hwnd, 0)
            user32.EnumChildWindows(wintypes.HWND(self.target_hwnd), child_callback, 0)
        except Exception as exc:
            self._log_runtime("native_enum_error", type(exc).__name__)
            return []
        if scene_tokens:
            self._remember_semantic_scene(scene_tokens)
        return sorted(controls, key=lambda item: float(item.get("score", 0.0)), reverse=True)
    def _ocr_control_candidates(self, image, screen, force=False):
        if self.stop_event.is_set():
            return []
        enabled = getattr(self.hardware, "control_text_scan", False)
        if (not enabled and not force) or not self.reader or not self.reader.engines:
            return []
        available = _available_memory()
        cpu_load = getattr(self.hardware, "cpu_load_ema", 0.0)
        if available < max(850 * 1024 ** 2, self.hardware.ram * 0.065) or cpu_load > 0.93:
            return []
        if getattr(self.hardware, "on_battery", False) and not force:
            return []
        try:
            rgb = self.np.asarray(image.convert("RGB"))
            h, w = rgb.shape[:2]
            if h < 20 or w < 20:
                return []
            max_side = max(520, int(getattr(self.hardware, "control_scan_side", 1080)))
            if force and not enabled:
                max_side = min(max_side, 660)
            scale = min(1.0, max_side / max(w, h))
            work = (self.cv2.resize(rgb, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
                    if scale < 0.995 else rgb)
            _engine_name, engine, _weight = self.reader.engines[0]
            out, scene_tokens = [], []

            def run_view(view, view_weight=1.0):
                if self.stop_event.is_set():
                    return
                try:
                    try:
                        result = engine(view, use_det=True, use_cls=False, use_rec=True)
                    except TypeError:
                        result = engine(view)
                    txts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
                    boxes = result.get("boxes") if isinstance(result, dict) else getattr(result, "boxes", None)
                    scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
                    if txts is None or boxes is None:
                        return
                    texts, box_list = list(txts), list(boxes)
                    try:
                        score_list = list(scores) if scores is not None else []
                    except TypeError:
                        score_list = []
                    wh = float(view.shape[0] * view.shape[1])
                    for index, raw_text in enumerate(texts):
                        if self.stop_event.is_set():
                            return
                        if index >= len(box_list):
                            continue
                        text = unicodedata.normalize("NFKC", str(raw_text)).strip().lower()
                        if not text:
                            continue
                        try:
                            pts = self.np.asarray(box_list[index], dtype="float32").reshape(-1, 2)
                            if len(pts) < 2:
                                continue
                            x1, y1 = float(pts[:, 0].min()), float(pts[:, 1].min())
                            x2, y2 = float(pts[:, 0].max()), float(pts[:, 1].max())
                            bw, bh = x2 - x1, y2 - y1
                            area = max(1.0, bw * bh)
                            if bw < 4 or bh < 4 or area > wh * 0.18:
                                continue
                            fx1, fy1 = x1 / view.shape[1], y1 / view.shape[0]
                            fx2, fy2 = x2 / view.shape[1], y2 / view.shape[0]
                            conf = self.reader._as_float(score_list[index] if index < len(score_list) else 0.72)
                            intent, is_danger, semantic_token = self._semantic_text_features(text)
                            semantic = "positive" if intent > 0.04 else "negative" if intent < -0.04 else "neutral"
                            if semantic_token and conf >= 0.34:
                                scene_tokens.append(("danger:" if is_danger else "") + semantic_token)
                            if is_danger and conf >= 0.30:
                                margin_x = min(0.028, max(0.005, (fx2 - fx1) * 0.24))
                                margin_y = min(0.030, max(0.006, (fy2 - fy1) * 0.42))
                                self._danger_regions.append((max(0.0, fx1 - margin_x), max(0.0, fy1 - margin_y),
                                                             min(1.0, fx2 + margin_x), min(1.0, fy2 + margin_y)))
                                continue
                            if conf >= 0.42:
                                for hinted_action in self._key_hints_from_text(text):
                                    if self._keyboard_action_allowed(hinted_action):
                                        self._dynamic_key_actions.add(hinted_action)
                                        hint_prior = min(0.58, 0.51 + conf * 0.07)
                                        self.action_priors[hinted_action] = max(self.action_priors.get(hinted_action, 0.0), hint_prior)
                                        scene_tokens.append("hint:" + hinted_action)
                            score = (760.0 + intent * 90.0 + conf * 260.0 +
                                     min(150.0, math.log1p(area) * 17.0)) * view_weight
                            role = "button" if intent > 0.04 else "text_control"
                            item = self._register_control(role, text, (fx1, fy1, fx2, fy2), semantic,
                                                          enabled=True, source="ocr", score=score, danger=False)
                            if item:
                                out.append(item)
                        except Exception as exc:
                            self._log_runtime("ocr_control_item_error", type(exc).__name__)
                except Exception as exc:
                    self._log_runtime("ocr_control_view_error", type(exc).__name__)

            run_view(work, 1.0)
            runtime_class = getattr(self.hardware, "runtime_class", "")
            if (len(out) < 2 and runtime_class in {"极速", "快速"} and
                    getattr(self.hardware, "cpu_load_ema", 0.0) < 0.76):
                try:
                    gray = self.cv2.cvtColor(work, self.cv2.COLOR_RGB2GRAY)
                    clahe = self.cv2.createCLAHE(clipLimit=2.6, tileGridSize=(6, 6)).apply(gray)
                    enhanced = self.cv2.cvtColor(clahe, self.cv2.COLOR_GRAY2RGB)
                    run_view(enhanced, 0.96)
                except Exception as exc:
                    self._log_runtime("ocr_control_enhance_error", type(exc).__name__)
            if scene_tokens:
                self._remember_semantic_scene(scene_tokens)
            dedup = {}
            for item in out:
                if self.stop_event.is_set():
                    return []
                key = item.get("id")
                if key and float(item.get("score", 0.0)) > float(dedup.get(key, {}).get("score", -1e9)):
                    dedup[key] = item
            return sorted(dedup.values(), key=lambda item: float(item.get("score", 0.0)), reverse=True)
        except Exception as exc:
            self._log_runtime("ocr_control_error", type(exc).__name__)
            return []
    @staticmethod
    def _uia_control_id_from_action(action):
        parts = str(action or "").split(":")
        if len(parts) >= 3 and parts[0] == "uia":
            return parts[2]
        return ""

    def _uia_actions_for_control(self, control, learner=None, stagnant=0):
        if not isinstance(control, dict) or control.get("source") != "uia":
            return []
        control_id = str(control.get("id") or "")
        if not control_id or control.get("danger") or not control.get("enabled", True):
            return []
        patterns = set(control.get("uia_patterns") or ())
        info = control.get("uia_pattern_info", {}) if isinstance(control.get("uia_pattern_info"), dict) else {}
        actions = []
        # Direct semantic patterns first.  They are more precise than a center click.
        if "invoke" in patterns:
            actions.append(f"uia:invoke:{control_id}")
        if "toggle" in patterns:
            actions.append(f"uia:toggle:{control_id}")
        if "select_item" in patterns:
            actions.append(f"uia:select:{control_id}")
        if "scroll_item" in patterns:
            actions.append(f"uia:scroll_into_view:{control_id}")
        if "expand" in patterns:
            expand_state = int((info.get("expand") or {}).get("state", -1))
            if expand_state == 0:
                actions.append(f"uia:expand:{control_id}")
            elif expand_state in {1, 2}:
                actions.append(f"uia:collapse:{control_id}")
            elif expand_state != 3:
                actions.extend((f"uia:expand:{control_id}", f"uia:collapse:{control_id}"))

        step = int(getattr(learner, "steps", 0) or 0)
        range_info = info.get("range") if isinstance(info.get("range"), dict) else None
        if range_info and not range_info.get("readonly", False):
            try:
                lo = float(range_info.get("minimum"))
                hi = float(range_info.get("maximum"))
                if math.isfinite(lo) and math.isfinite(hi) and hi > lo:
                    base_fraction = self._parameter_fraction(f"uia-range:{control_id}", step)
                    if learner is not None:
                        learned_fraction = learner.sample_parameter(
                            f"uia.range.{control_id}.fraction", 1e-5, 1.0,
                            base_fraction, integer=False, log_scale=False)
                        fraction = max(0.0, min(1.0, float(learned_fraction)))
                    else:
                        fraction = base_fraction
                    value = lo + (hi - lo) * fraction
                    actions.append(f"uia:range:{control_id}:{value:.12g}")
            except Exception:
                pass

        scroll_info = info.get("scroll") if isinstance(info.get("scroll"), dict) else None
        if scroll_info and (scroll_info.get("horizontal") or scroll_info.get("vertical")):
            def sampled_percent(axis, offset):
                fraction = self._parameter_fraction(f"uia-scroll-{axis}:{control_id}", step + offset)
                if learner is not None:
                    fraction = learner.sample_parameter(
                        f"uia.scroll.{control_id}.{axis}.fraction", 1e-5, 1.0,
                        fraction, integer=False, log_scale=False)
                return max(0.0, min(100.0, float(fraction) * 100.0))
            hp = sampled_percent("h", 3) if scroll_info.get("horizontal") else -1.0
            vp = sampled_percent("v", 7) if scroll_info.get("vertical") else -1.0
            actions.append(f"uia:scroll:{control_id}:{hp:.6g}:{vp:.6g}")

        value_info = info.get("value") if isinstance(info.get("value"), dict) else None
        if value_info and not value_info.get("readonly", False):
            current = parse_score(str(value_info.get("value", "")))
            if current is not None and math.isfinite(float(current)):
                base_fraction = self._parameter_fraction(f"uia-value:{control_id}", step + 11)
                factor = (learner.sample_parameter(
                    f"uia.value.{control_id}.factor", 0.25, 4.0,
                    base_fraction, integer=False, log_scale=True)
                    if learner is not None else math.exp(math.log(0.25) + base_fraction * math.log(16.0)))
                candidate = float(current) * float(factor) if abs(float(current)) > 1e-12 else float(factor)
                if math.isfinite(candidate):
                    actions.append(f"uia:value:{control_id}:{candidate:.12g}")

        # Legacy default action is useful only when no richer actionable pattern exists.
        if not actions and "legacy" in patterns:
            actions.append(f"uia:legacy_default:{control_id}")
        actions = list(dict.fromkeys(actions))
        control["uia_actions"] = tuple(actions)
        control["uia_actionable"] = bool(actions)
        return actions

    def _point_hits_actionable_uia(self, fx, fy):
        try:
            x, y = float(fx), float(fy)
        except Exception:
            return False
        for control in self._controls.values():
            if not control.get("uia_actionable") or control.get("danger"):
                continue
            try:
                x1, y1, x2, y2 = control.get("bbox", ())
                if float(x1) <= x <= float(x2) and float(y1) <= y <= float(y2):
                    return True
            except Exception:
                continue
        return False

    def _perform_uia_action(self, action):
        parts = str(action or "").split(":")
        if len(parts) < 3 or parts[0] != "uia":
            return False
        kind, control_id = parts[1], parts[2]
        control = self._controls.get(control_id)
        if not control or control.get("danger") or not control.get("enabled", True):
            return False
        patterns = control.get("_uia_patterns_runtime", {})
        if not isinstance(patterns, dict):
            return False
        try:
            if kind == "invoke":
                patterns["invoke"].Invoke()
            elif kind == "toggle":
                patterns["toggle"].Toggle()
            elif kind == "select":
                patterns["select_item"].Select()
            elif kind == "scroll_into_view":
                patterns["scroll_item"].ScrollIntoView()
            elif kind == "expand":
                patterns["expand"].Expand()
            elif kind == "collapse":
                patterns["expand"].Collapse()
            elif kind == "range" and len(parts) == 4:
                patterns["range"].SetValue(float(parts[3]))
            elif kind == "value" and len(parts) == 4:
                patterns["value"].SetValue(str(parts[3]))
            elif kind == "scroll" and len(parts) == 5:
                patterns["scroll"].SetScrollPercent(float(parts[3]), float(parts[4]))
            elif kind == "legacy_default":
                patterns["legacy"].DoDefaultAction()
            else:
                return False
            return True
        except Exception as exc:
            self._log_runtime("uia_action_error", f"{kind}:{type(exc).__name__}")
            return False

    def _click_candidates(self, roi, stagnant=0):
        if not roi:
            return []
        cr = self._adaptive_operation_rect(stagnant=stagnant, refresh=False, reason="candidate-scan")
        if self.stop_event.is_set():
            return []
        if not cr or cr[2] - cr[0] < 80 or cr[3] - cr[1] < 80:
            return []
        cold_desktop_scope = self._operation_scope_reason == "desktop-cold"
        self._danger_regions = []
        self._recognized_actions = set()
        self._controls = {}
        self._semantic_features = {}
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"))
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
        except Exception as exc:
            self._log_runtime("candidate_capture_error", type(exc).__name__)
            return []
        h, w = gray.shape
        if not h or not w:
            return []
        target_client = self._target_client_rect()
        native_controls = self._native_control_candidates(cr) if target_client and tuple(cr) == tuple(target_client) else []
        force_semantics = (cold_desktop_scope or not self._semantic_tokens or
                           stagnant >= (18 if self.hardware.tier == "low" else 28))
        ocr_controls = self._ocr_control_candidates(image, cr, force=force_semantics)
        recognized_controls = list(native_controls) + list(ocr_controls)
        points = []
        coverage_points = []
        self._bind_control_number_semantics()
        learner = self._active_learner
        for control in self._controls.values():
            self._uia_actions_for_control(control, learner=learner, stagnant=stagnant)
        # If a standard control exposes an actionable UIA pattern, do not also seed
        # its center into blind mouse exploration.  _perform_uia_action() owns the
        # center-click fallback if the semantic invocation fails.
        recognized_points = [
            (float(item.get("score", 0.0)), *item.get("center", (0.5, 0.5)))
            for item in recognized_controls if not item.get("uia_actionable")
        ]
        points.extend(recognized_points)
        self._control_graph_update()
        self._last_control_count = len(self._controls)
        self._last_danger_count = len(self._danger_regions)
        memory_tight = _available_memory() < max(900 * 1024 ** 2, self.hardware.ram * 0.075)
        fgray = gray.astype("float32")
        area_scale = math.sqrt(max(1.0, w * h))
        resource_factor = 0.62 if memory_tight else max(
            0.55, min(1.35, 1.18 - float(getattr(self.hardware, "cpu_load_ema", 0.0)) * 0.42))
        sample_count = int(max(20, min(132, area_scale / 12.0 * resource_factor + max(0, stagnant) * 0.75)))
        if cold_desktop_scope:
            sample_count = min(40, sample_count)
        patch_radius = max(4, int(round(area_scale / max(18.0, math.sqrt(sample_count) * 7.0))))
        for sample_index in range(sample_count):
            if self.stop_event.is_set():
                return []
            sequence_index = self._candidate_scan_index + sample_index
            fx = self._parameter_fraction("mouse-probe-x", sequence_index)
            fy = self._parameter_fraction("mouse-probe-y", sequence_index * 3 + 1)
            if self._point_is_dangerous(fx, fy) or self._point_hits_actionable_uia(fx, fy):
                continue
            coverage_points.append((fx, fy))
            cx, cy = int(round(fx * (w - 1))), int(round(fy * (h - 1)))
            x1, x2 = max(0, cx - patch_radius), min(w, cx + patch_radius + 1)
            y1, y2 = max(0, cy - patch_radius), min(h, cy + patch_radius + 1)
            cell = fgray[y1:y2, x1:x2]
            if cell.size < 16:
                continue
            edge = (self.np.abs(self.np.diff(cell, axis=0)).mean() +
                    self.np.abs(self.np.diff(cell, axis=1)).mean())
            contrast = float(cell.std())
            points.append((contrast * 0.62 + float(edge) * 1.38, fx, fy))
        self._candidate_scan_index += sample_count
        candidates = list(points)
        try:
            if memory_tight:
                max_side = 560
            elif getattr(self.hardware, "runtime_class", "") == "极速":
                max_side = 1100
            else:
                max_side = 980 if self.hardware.tier == "high" else (780 if self.hardware.tier == "balanced" else 620)
            scale = min(1.0, max_side / max(w, h))
            small = self.cv2.resize(gray, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
            blur = self.cv2.GaussianBlur(small, (3, 3), 0)
            median = float(self.np.median(blur))
            low = max(24, int(median * 0.45))
            high = min(220, max(low + 40, int(median * 1.25)))
            edges = self.cv2.Canny(blur, low, high)
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (3, 3))
            closed = self.cv2.morphologyEx(edges, self.cv2.MORPH_CLOSE, kernel)
            contours, _ = self.cv2.findContours(closed, self.cv2.RETR_LIST, self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            sh, sw = small.shape
            for contour in contours:
                if self.stop_event.is_set():
                    return []
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = bw * bh
                if not (42 <= area <= sw * sh * 0.15 and bw >= 7 and bh >= 7):
                    continue
                aspect = bw / max(1.0, bh)
                if not (0.20 <= aspect <= 9.0):
                    continue
                fx, fy = (x + bw / 2) / sw, (y + bh / 2) / sh
                if self._point_is_dangerous(fx, fy) or self._point_hits_actionable_uia(fx, fy):
                    continue
                rectangularity = self.cv2.contourArea(contour) / max(1.0, area)
                perimeter = self.cv2.arcLength(contour, True)
                compact = min(1.0, perimeter / max(1.0, 2.0 * (bw + bh)))
                score = min(1.2, rectangularity * 1.4 + compact * 0.35) * 2.5 + min(2.2, math.log1p(area) / 3.8)
                boxes.append((score, fx, fy))
            boxes.sort(reverse=True)
            candidates.extend(boxes[:100])
        except Exception as exc:
            self._log_runtime("visual_candidate_error", type(exc).__name__)
        if self.hardware.tier != "low":
            try:
                corner_limit = 80 if self.hardware.tier == "high" else 52
                corners = self.cv2.goodFeaturesToTrack(gray, maxCorners=corner_limit,
                                                       qualityLevel=0.04, minDistance=max(10, min(w, h) // 48))
                if corners is not None:
                    for pt in corners.reshape(-1, 2):
                        if self.stop_event.is_set():
                            return []
                        fx, fy = float(pt[0]) / w, float(pt[1]) / h
                        if (not self._point_is_dangerous(fx, fy) and
                                not self._point_hits_actionable_uia(fx, fy)):
                            candidates.append((0.85, fx, fy))
            except Exception as exc:
                self._log_runtime("corner_candidate_error", type(exc).__name__)
        grid = 10000
        recognized_keys = set()
        for _score, fx, fy in recognized_points:
            if self._point_is_dangerous(fx, fy):
                continue
            virtual_point = self._scope_fraction_to_virtual(fx, fy, cr)
            if virtual_point:
                recognized_keys.add((max(1, min(grid - 1, round(virtual_point[0] * grid))),
                                     max(1, min(grid - 1, round(virtual_point[1] * grid)))))
        semantic_actions = []
        for control in sorted(self._controls.values(), key=lambda item: float(item.get("score", 0.0)), reverse=True):
            if self.stop_event.is_set():
                return []
            fallback_action = control.get("action")
            uia_actions = list(control.get("uia_actions") or ())
            candidate_actions = uia_actions if uia_actions else ([fallback_action] if fallback_action else [])
            if candidate_actions and not control.get("danger") and control.get("enabled", True):
                action_type = str(control.get("action_type", "unknown"))
                prior = 0.50
                if action_type != "unknown":
                    prior += 0.02
                if control.get("semantic") == "positive":
                    prior += 0.02
                elif control.get("semantic") == "negative":
                    prior -= 0.02
                for action in candidate_actions:
                    if str(action).startswith("uia:"):
                        action_prior = min(0.58, prior + 0.035)
                    else:
                        action_prior = prior
                    self.action_priors[action] = max(0.46, min(0.58, action_prior))
                    self._recognized_actions.add(action)
                    semantic_actions.append(action)

        all_actions, seen = [], set()
        learner = self._active_learner
        if learner is not None:
            heat_ranked = []
            for visual_score, fx, fy in candidates:
                virtual_point = self._scope_fraction_to_virtual(fx, fy, cr)
                heat_value, heat_n, heat_uncertainty = learner.interaction_map_value(virtual_point)
                # Positive learned effect increases density; uncertainty preserves exploration.
                boost = max(-1.8, min(2.4, heat_value * 0.72))
                boost += min(0.55, heat_uncertainty * (0.20 + min(0.30, stagnant * 0.008)))
                heat_ranked.append((float(visual_score) + boost, fx, fy))
            ranked_candidates = sorted(heat_ranked, reverse=True)
        else:
            ranked_candidates = sorted(candidates, reverse=True)
        score_hi = float(ranked_candidates[0][0]) if ranked_candidates else 1.0
        score_lo = float(ranked_candidates[-1][0]) if ranked_candidates else 0.0
        span = max(1e-6, score_hi - score_lo)
        for score, fx, fy in ranked_candidates:
            if self.stop_event.is_set():
                return []
            if self._point_is_dangerous(fx, fy):
                continue
            virtual_point = self._scope_fraction_to_virtual(fx, fy, cr)
            if not virtual_point:
                continue
            qx = max(1, min(grid - 1, round(virtual_point[0] * grid)))
            qy = max(1, min(grid - 1, round(virtual_point[1] * grid)))
            action = f"mouse:v:{qx}:{qy}"
            if action in seen:
                continue
            seen.add(action)
            prior = max(0.12, min(0.98, 0.12 + 0.86 * ((float(score) - score_lo) / span)))
            if learner is not None:
                heat_value, heat_n, heat_uncertainty = learner.interaction_map_value(virtual_point)
                prior += max(-0.22, min(0.26, heat_value * 0.11))
                if heat_n < 0.35:
                    prior += min(0.055, heat_uncertainty * 0.035)
                prior = max(0.08, min(0.995, prior))
            if (qx, qy) in recognized_keys:
                prior = max(prior, 0.56)
                self._recognized_actions.add(action)
            all_actions.append((action, prior))
        all_actions.sort(key=lambda item: float(item[1]), reverse=True)

        if memory_tight:
            budget = 72
        elif self.hardware.tier == "high":
            budget = 160
        elif self.hardware.tier == "balanced":
            budget = 128
        else:
            budget = 88
        budget += min(32, stagnant // 3)
        budget = min(192, budget)
        if cold_desktop_scope:
            budget = min(budget, EXPLORATION_CONFIG.desktop_cold_action_limit)

        # A second, explicitly unbiased channel selects least-tested spatial regions.
        # Its share grows from measured coverage uncertainty and stagnation, rather than
        # being a fixed percentage of the candidate budget.
        learner = self._active_learner
        coverage_ranked, coverage_seen = [], set()
        unknown_regions = 0
        for index, (fx, fy) in enumerate(coverage_points):
            virtual_point = self._scope_fraction_to_virtual(fx, fy, cr)
            if not virtual_point:
                continue
            qx = max(1, min(grid - 1, round(virtual_point[0] * grid)))
            qy = max(1, min(grid - 1, round(virtual_point[1] * grid)))
            action = f"mouse:v:{qx}:{qy}"
            if action in coverage_seen:
                continue
            coverage_seen.add(action)
            region = Learner._coverage_key_from_point(virtual_point, rows=16, cols=24)
            stat = learner.coverage.get(region, {}) if learner is not None and region else {}
            attempts = float(stat.get("n", 0.0))
            last_step = int(stat.get("last_step", -1))
            if attempts < 1.0:
                unknown_regions += 1
            age = (learner.steps - last_step) if learner is not None and last_step >= 0 else 10 ** 6
            tie = self._parameter_fraction(f"coverage:{action}", index + (learner.steps if learner else 0))
            coverage_ranked.append((attempts, -age, tie, action))
        coverage_ranked.sort(key=lambda item: (item[0], item[1], item[2]))
        unknown_ratio = unknown_regions / max(1, len(coverage_ranked))
        stagnation_pressure = min(0.28, max(0.0, float(stagnant)) / max(1.0, LEARNING_CONFIG.stagnation_extreme) * 0.28)
        coverage_fraction = min(0.62, 0.08 + unknown_ratio * 0.34 + stagnation_pressure)
        coverage_budget = min(len(coverage_ranked), max(6, int(round(budget * coverage_fraction))))
        visual_budget = max(0, budget - coverage_budget)
        selected_actions = [action for action, _prior in all_actions[:visual_budget]]
        selected_priors = dict(all_actions[:visual_budget])
        for _attempts, _age, _tie, action in coverage_ranked:
            if action in selected_actions:
                continue
            selected_actions.append(action)
            selected_priors.setdefault(action, 0.50)
            if len(selected_actions) >= budget:
                break
        if len(selected_actions) < budget:
            for action, prior in all_actions[visual_budget:]:
                if action not in selected_actions:
                    selected_actions.append(action)
                    selected_priors[action] = prior
                if len(selected_actions) >= budget:
                    break
        if cold_desktop_scope:
            semantic_actions = semantic_actions[:6]
        result = list(dict.fromkeys(semantic_actions + selected_actions))
        self.action_priors.update(selected_priors)
        return result[:max(budget, len(semantic_actions))]

    def _mouse_neighborhood(self, actions, radius=1, limit=18, learner=None):
        out, seen = [], set()
        fine_grid = 10000
        for action in actions:
            point = Learner._mouse_point(action)
            if point is None:
                continue
            try:
                fx, fy = point
                stable_virtual = self._action_uses_virtual_coordinates(action)
                parent_prior = float(self.action_priors.get(action, 0.50))
                samples = 0
                if learner is not None:
                    _q, samples, _variance = learner._value(learner.stats.get(action, {}))
                search_radius = max(0.00018, min(0.085,
                    0.052 * max(0.5, float(radius)) / math.sqrt(float(samples) + 1.0)))
                local_count = min(14, max(5, limit - len(out)))
                for local_index in range(local_count):
                    angle = math.tau * self._parameter_fraction(
                        f"mouse-neighborhood:{action}", (samples + 1) * 17 + local_index)
                    distance = search_radius * math.sqrt((local_index + 0.5) / local_count)
                    candidate_x = max(0.0, min(1.0, fx + math.cos(angle) * distance))
                    candidate_y = max(0.0, min(1.0, fy + math.sin(angle) * distance))
                    x = max(1, min(fine_grid - 1, round(candidate_x * fine_grid)))
                    y = max(1, min(fine_grid - 1, round(candidate_y * fine_grid)))
                    # All spatial actions feed a common anchor map. Refinement emits a
                    # neutral pointer action so successful click/tap/wheel/drag regions
                    # can guide subsequent modality discovery without presupposing it.
                    candidate = (f"mouse:v:{x}:{y}" if stable_virtual
                                 else f"mouse:{fine_grid}:{x}:{y}")
                    if candidate in seen:
                        continue
                    seen.add(candidate)
                    out.append(candidate)
                    self.action_priors.setdefault(candidate, max(0.40, parent_prior * 0.95))
                    if len(out) >= limit:
                        return out
            except Exception:
                continue
        return out

    def _visual_effect_probe(self, rect=None):
        cr = rect or self._adaptive_operation_rect(refresh=False, reason="visual-probe")
        if not cr or self.capture is None or self.cv2 is None or self.np is None:
            return None
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            tiny = self.cv2.resize(gray, (8, 6), interpolation=self.cv2.INTER_AREA).astype("float32")
            return tiny
        except Exception:
            return None

    def _visual_effect_change(self, before_probe, after_probe):
        if before_probe is None or after_probe is None:
            return 0.0
        try:
            diff = self.np.abs(after_probe.astype("float32") - before_probe.astype("float32"))
            median = float(self.np.median(diff))
            mad = float(self.np.median(self.np.abs(diff - median)))
            threshold = max(3.5, median + 2.2 * max(1.0, mad))
            bits = diff >= threshold
            mask = 0
            # Compress 8x6 changes into a stable 6x4 regional signature.
            compact = self.cv2.resize(diff, (6, 4), interpolation=self.cv2.INTER_AREA)
            cmedian = float(self.np.median(compact))
            cmad = float(self.np.median(self.np.abs(compact - cmedian)))
            cthreshold = max(3.2, cmedian + 1.9 * max(1.0, cmad))
            for bit in (compact >= cthreshold).reshape(-1):
                mask = (mask << 1) | int(bool(bit))
            if int(bits.sum()) == 0:
                mask = 0
            self._motion_mask = int(mask) & 0xFFFFFF
            magnitude = float(diff.mean()) / 24.0 + float(self.np.percentile(diff, 85)) / 80.0
            return max(0.0, min(2.0, magnitude))
        except Exception:
            return 0.0

    def _update_visual_noise(self, change):
        try:
            value = max(0.0, float(change or 0.0))
            stat = self._visual_noise_stats
            n = float(stat.get("n", 0.0)) + 1.0
            mean = float(stat.get("mean", 0.0))
            delta = value - mean
            mean += delta / n
            m2 = float(stat.get("m2", 0.0)) + delta * (value - mean)
            stat.update({"n": n, "mean": mean, "m2": m2})
        except Exception:
            pass

    def _visual_change_threshold(self):
        stat = self._visual_noise_stats
        n = float(stat.get("n", 0.0))
        if n < 4.0:
            return 0.018
        mean = max(0.0, float(stat.get("mean", 0.0)))
        variance = max(0.0, float(stat.get("m2", 0.0)) / max(1.0, n - 1.0))
        threshold = mean + math.sqrt(variance) * 2.8
        return max(0.006, min(0.22, threshold))

    def _visual_signature(self, refresh=False):
        if not refresh and self._visual_cache and self._visual_cache != "v0":
            return self._visual_cache
        cr = self._adaptive_operation_rect(refresh=False, reason="visual-state")
        if not cr or cr[2] - cr[0] < 1 or cr[3] - cr[1] < 1:
            return self._visual_cache or "v0"
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8").copy()

            roi = self._current_roi()
            if roi:
                x1 = max(0, int(roi[0] - cr[0] - 7))
                y1 = max(0, int(roi[1] - cr[1] - 7))
                x2 = min(rgb.shape[1], int(roi[2] - cr[0] + 7))
                y2 = min(rgb.shape[0], int(roi[3] - cr[1] + 7))
                if x2 > x1 and y2 > y1:
                    fill = self.np.median(rgb.reshape(-1, 3), axis=0).astype("uint8")
                    rgb[y1:y2, x1:x2] = fill
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY).astype("float32")

            ph = self.cv2.resize(gray, (9, 8), interpolation=self.cv2.INTER_AREA)
            pdiff = ph[:, 1:] - ph[:, :-1]

            p_deadband = max(1.6, float(ph.std()) * 0.032)
            pbits = pdiff >= p_deadband
            pvalue = 0
            for bit in pbits.reshape(-1):
                pvalue = (pvalue << 1) | int(bool(bit))

            sobelx = self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3)
            sobely = self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3)
            edge = self.cv2.magnitude(sobelx, sobely)
            eh = self.cv2.resize(edge, (9, 4), interpolation=self.cv2.INTER_AREA)
            ediff = eh[:, 1:] - eh[:, :-1]
            e_deadband = max(0.9, float(eh.std()) * 0.026)
            ebits = ediff >= e_deadband
            evalue = 0
            for bit in ebits.reshape(-1):
                evalue = (evalue << 1) | int(bool(bit))

            tiny_rgb = self.cv2.resize(rgb, (4, 3), interpolation=self.cv2.INTER_AREA).astype("float32")
            colorfulness = float((tiny_rgb.max(axis=2) - tiny_rgb.min(axis=2)).mean())
            color_bucket = max(0, min(7, int(colorfulness / 18.0)))

            layout = self.cv2.resize(gray, (4, 3), interpolation=self.cv2.INTER_AREA)
            lm = float(layout.mean())
            l_deadband = max(1.4, float(layout.std()) * 0.055)
            layout_value = 0
            for bit in (layout >= lm + l_deadband).reshape(-1):
                layout_value = (layout_value << 1) | int(bool(bit))

            candidate = (f"p{pvalue:016x}e{evalue:08x}"
                         f"c{color_bucket}l{layout_value:03x}")

            previous = self._visual_cache
            match = re.fullmatch(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)",
                                 previous or "")
            if match:
                old_p, old_e, old_c, old_l = match.groups()
                try:
                    p_distance = bin(int(old_p, 16) ^ int(f"{pvalue:016x}", 16)).count("1")
                    e_distance = bin(int(old_e, 16) ^ int(f"{evalue:08x}", 16)).count("1")
                    l_distance = bin(int(old_l, 16) ^ int(f"{layout_value:03x}", 16)).count("1")
                    color_distance = abs(int(old_c) - int(color_bucket))
                    if (p_distance <= 8 and e_distance <= 6 and l_distance <= 3 and
                            color_distance <= 1):
                        candidate = previous
                except Exception as exc:
                    self._log_once("visual_signature_compare", "visual_signature_compare_error", type(exc).__name__)
            self._visual_cache = candidate
        except Exception as exc:
            self._log_once("visual_signature", "visual_signature_error", type(exc).__name__)
        return self._visual_cache or "v0"

    def _adaptive_state_bucket(self, name, value):
        """Quantile-rank bucket with online, bounded history and adaptive resolution."""
        try:
            value = float(value)
            if not math.isfinite(value):
                return 0
        except (TypeError, ValueError, OverflowError):
            return 0
        history = self._state_quantiles.setdefault(str(name), [])
        history.append(value)
        if len(history) > 512:
            # Deterministic thinning retains the full observed range without a
            # fixed domain threshold or an ever-growing history buffer.
            history[:] = history[::2]
            if not history or history[-1] != value:
                history.append(value)
        sample_count = len(history)
        bins = max(3, min(9, int(round(math.sqrt(sample_count + 8.0) / 2.0)) + 1))
        ordered = sorted(history)
        less = 0
        equal = 0
        for item in ordered:
            if item < value:
                less += 1
            elif item == value:
                equal += 1
        percentile = (less + equal * 0.5) / max(1.0, float(sample_count))
        return max(0, min(bins - 1, int(percentile * bins)))

    def _structured_scene_signature(self, score):
        env = self._environment_identity()
        cursor_bucket = "x"
        if os.name == "nt" and user32 is not None:
            try:
                pt = POINT()
                if user32.GetCursorPos(ctypes.byref(pt)):
                    cr = self._adaptive_operation_rect(refresh=False, reason="cursor-state") or virtual_screen_rect()
                    sw, sh = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
                    fx = max(0.0, min(1.0, (pt.x - cr[0]) / sw))
                    fy = max(0.0, min(1.0, (pt.y - cr[1]) / sh))
                    cx = self._adaptive_state_bucket("cursor.x", fx)
                    cy = self._adaptive_state_bucket("cursor.y", fy)
                    cursor_bucket = f"{cx}{cy}"
            except Exception as exc:
                self._log_once("cursor_bucket", "cursor_bucket_error", type(exc).__name__)
        title = env.get("title", "unknown")
        cls = env.get("class", "unknown")
        modal = int(any(token in (title + " " + cls) for token in (
            "dialog", "popup", "modal", "messagebox", "确认", "提示", "警告")))
        semantic = ",".join(sorted(self._semantic_tokens)[:18])
        features = self._semantic_feature_signature()
        raw = (f"{env.get('exe_hash')}|{cls}|{title}|controls={min(31,self._last_control_count)}|"
               f"danger={min(15,self._last_danger_count)}|modal={modal}|sem={semantic}|"
               f"features={features}|numbers={self._number_structure_hash}")
        scene_hash = hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:10]
        return f"u{scene_hash}:x{cursor_bucket}"

    def _state_key(self, score, previous, stagnant, best, refresh_visual=False):
        visual = self._visual_signature(refresh_visual)
        threshold = max(1e-9, abs(previous) * 0.0005)
        delta = score - previous
        trend = "u" if delta > threshold else ("d" if delta < -threshold else "f")
        if best is None or score >= best:
            relative_gap = 0.0
        else:
            relative_gap = (best - score) / max(1.0, abs(best))
        gap = self._adaptive_state_bucket("target.relative_gap", max(0.0, relative_gap))
        stale = self._adaptive_state_bucket("state.stagnation", max(0.0, float(stagnant)))
        log_magnitude = 0.0 if score == 0 else math.copysign(math.log1p(abs(score)), score)
        magnitude = self._adaptive_state_bucket("target.log_magnitude", log_magnitude)
        semantic = self._semantic_scene or "h00000000"
        structured = self._structured_scene_signature(score)
        env = self._environment_identity()
        app_hash = str(env.get("exe_hash", "unknown"))[:8]
        if not re.fullmatch(r"[0-9a-f]{8}", app_hash):
            app_hash = hashlib.sha1(app_hash.encode("utf-8", "replace")).hexdigest()[:8]
        control_hash = self._control_graph_hash if re.fullmatch(r"c[0-9a-f]{8}", self._control_graph_hash or "") else "c00000000"
        velocity_bucket = self._adaptive_state_bucket("state.velocity", float(self._state_velocity))
        acceleration_bucket = self._adaptive_state_bucket("state.acceleration", float(self._state_acceleration))
        motion = int(self._motion_mask) & 0xFFFFFF
        number_features = self._number_state_signature(score)
        semantic_features = self._semantic_feature_signature()
        scope_raw = f"{self._operation_scope_reason}|{self._operation_scope_signature}"
        scope_hash = hashlib.sha1(scope_raw.encode("utf-8", "replace")).hexdigest()[:6]
        absolute_target_rect = self._current_roi()
        target_context = self._target_context_signature(absolute_target_rect) if absolute_target_rect else "ctx0"
        return (f"{visual}:{semantic}:{structured}:a{app_hash}:{control_hash}:o{scope_hash}:{target_context}:"
                f"{semantic_features}:{number_features}:"
                f"t{trend}:g{gap}:s{stale}:m{magnitude}:v{velocity_bucket}:"
                f"a{acceleration_bucket}:r{motion:06x}")
    def _perform(self, action, quality):
        if action != OBSERVE_ACTION and not self._input_scope_ready(action, restore=True):
            self._log_runtime("input_paused", f"当前操作 scope 不可用: {self._operation_scope_reason}")
            return ACTION_BLOCKED
        if self._action_is_dangerous(action):
            self._log_runtime("danger_action_blocked", action)
            return ACTION_BLOCKED

        def point(grid, sx, sy):
            stable_virtual = str(grid) == "v"
            cr = virtual_screen_rect() if stable_virtual else self._adaptive_operation_rect(
                refresh=False, reason="action")
            if not cr:
                return None
            grid_value = 10000 if stable_virtual else max(2, int(grid))
            if cr[2] - cr[0] < 1 or cr[3] - cr[1] < 1:
                return None
            fx = max(0.0, min(1.0, float(sx) / grid_value))
            fy = max(0.0, min(1.0, float(sy) / grid_value))
            return (cr[0] + fx * (cr[2] - cr[0]),
                    cr[1] + fy * (cr[3] - cr[1]))

        def perform_atomic(item, allow_repeat=True):
            repeatable = item in KEY_ACTIONS or item.startswith(("mouse:", "click:"))
            repeats = (2 if allow_repeat and repeatable and quality > 1.35 else 1)
            for repeat_index in range(repeats):
                if self.stop_event.is_set():
                    return ACTION_BLOCKED
                success = False
                try:
                    if item == OBSERVE_ACTION:
                        success = True
                    elif item in KEY_ACTIONS:
                        success = press_keys((KEY_ACTIONS[item],), 0.045, self.stop_event)
                    elif item.startswith("hold:"):
                        _kind, name, milliseconds = item.split(":")
                        vk = KEY_NAME_TO_VK.get(name)
                        if vk is None:
                            return ACTION_FAILED
                        duration = max(0.018, int(milliseconds) / 1000.0)
                        if quality > 0.65:
                            duration *= 1.10
                        success = press_keys((vk,), duration, self.stop_event)
                    elif item.startswith("pulse:"):
                        _kind, name, milliseconds, repeat_count, interval_ms = item.split(":")
                        vk = KEY_NAME_TO_VK.get(name)
                        if vk is None:
                            return ACTION_FAILED
                        duration = max(0.005, min(600.0, int(milliseconds) / 1000.0))
                        count = max(1, min(2048, int(repeat_count)))
                        interval = max(0.001, min(600.0, int(interval_ms) / 1000.0))
                        success = True
                        for pulse_index in range(count):
                            if self.stop_event.is_set():
                                return ACTION_BLOCKED
                            if not press_keys((vk,), duration, self.stop_event):
                                return ACTION_FAILED if not self.stop_event.is_set() else ACTION_BLOCKED
                            if pulse_index + 1 < count:
                                end = time.monotonic() + interval
                                while time.monotonic() < end:
                                    if self.stop_event.is_set():
                                        return ACTION_BLOCKED
                                    time.sleep(min(0.012, max(0.002, end - time.monotonic())))
                    elif item.startswith("chord:"):
                        parts = item.split(":")
                        names = parts[1].split("+") if len(parts) >= 2 else []
                        vks = [KEY_NAME_TO_VK[name] for name in names if name in KEY_NAME_TO_VK]
                        if len(vks) != len(names) or len(vks) < 2:
                            return ACTION_FAILED
                        duration = (max(0.005, min(600.0, int(parts[2]) / 1000.0))
                                    if len(parts) == 3 else 0.090)
                        success = press_keys(vks, duration, self.stop_event)
                    elif item.startswith("mouse:"):
                        parts = item.split(":")
                        if len(parts) == 3:
                            grid, sx, sy = 20, parts[1], parts[2]
                        elif len(parts) == 4:
                            grid, sx, sy = (parts[1] if parts[1] == "v" else int(parts[1])), parts[2], parts[3]
                        else:
                            return ACTION_FAILED
                        target = point(grid, sx, sy)
                        if target is None:
                            return ACTION_BLOCKED
                        success = click_point(*target, button="left", clicks=1,
                                              stop_event=self.stop_event)
                    elif item.startswith("pointer:"):
                        _kind, grid, sx, sy = item.split(":")
                        target = point(grid, sx, sy)
                        if target is None:
                            return ACTION_BLOCKED
                        success = move_pointer(*target)
                    elif item.startswith("uia:"):
                        control_id = self._uia_control_id_from_action(item)
                        control = self._controls.get(control_id)
                        if not control or not control.get("enabled", True) or control.get("danger"):
                            return ACTION_BLOCKED
                        success = self._perform_uia_action(item)
                        if not success:
                            # UIA is primary. A center click is used only as an immediate
                            # fallback for this already-discovered control.
                            target_fraction = control.get("center")
                            cr = self._adaptive_operation_rect(refresh=False, reason="uia-fallback")
                            if not target_fraction or not cr:
                                return ACTION_FAILED
                            target = (cr[0] + float(target_fraction[0]) * (cr[2] - cr[0]),
                                      cr[1] + float(target_fraction[1]) * (cr[3] - cr[1]))
                            success = click_point(*target, button="left", clicks=1,
                                                  stop_event=self.stop_event)
                            if success:
                                self._log_runtime("uia_mouse_fallback", str(item)[:160])
                    elif item.startswith("click:control:"):
                        control_id = item.split(":", 2)[2]
                        control = self._controls.get(control_id)
                        if not control or not control.get("enabled", True) or control.get("danger"):
                            return ACTION_BLOCKED
                        target_fraction = control.get("center")
                        cr = self._adaptive_operation_rect(refresh=False, reason="control-action")
                        if not target_fraction or not cr:
                            return ACTION_BLOCKED
                        target = (cr[0] + float(target_fraction[0]) * (cr[2] - cr[0]),
                                  cr[1] + float(target_fraction[1]) * (cr[3] - cr[1]))
                        success = click_point(*target, button="left", clicks=1,
                                              stop_event=self.stop_event)
                    elif item.startswith("click:"):
                        _kind, button, grid, sx, sy, clicks = item.split(":")
                        target = point(grid, sx, sy)
                        if target is None:
                            return ACTION_BLOCKED
                        success = click_point(*target, button=button, clicks=int(clicks),
                                              stop_event=self.stop_event)
                    elif item.startswith("tap:"):
                        _kind, button, grid, sx, sy, repeat_count, interval_ms, press_ms = item.split(":")
                        target = point(grid, sx, sy)
                        flags = MOUSE_BUTTONS.get(button.lower())
                        if target is None:
                            return ACTION_BLOCKED
                        if not flags or not move_pointer(*target):
                            return ACTION_FAILED
                        down, up, data = flags
                        count = max(1, min(2048, int(repeat_count)))
                        interval = max(0.001, min(600.0, int(interval_ms) / 1000.0))
                        press_time = max(0.005, min(600.0, int(press_ms) / 1000.0))
                        success = True
                        for tap_index in range(count):
                            if self.stop_event.is_set():
                                return ACTION_BLOCKED
                            if not _mouse_event(down, data):
                                return ACTION_FAILED
                            released = False
                            try:
                                end = time.monotonic() + press_time
                                while time.monotonic() < end:
                                    if self.stop_event.is_set():
                                        break
                                    time.sleep(min(0.008, max(0.001, end - time.monotonic())))
                            finally:
                                released = _mouse_event(up, data)
                            if not released:
                                return ACTION_FAILED
                            if self.stop_event.is_set():
                                return ACTION_BLOCKED
                            if tap_index + 1 < count:
                                end = time.monotonic() + interval
                                while time.monotonic() < end:
                                    if self.stop_event.is_set():
                                        return ACTION_BLOCKED
                                    time.sleep(min(0.010, max(0.002, end - time.monotonic())))
                    elif item.startswith("wheel:"):
                        _kind, axis, amount, grid, sx, sy = item.split(":")
                        target = point(grid, sx, sy)
                        if target is None:
                            return ACTION_BLOCKED
                        success = scroll_point(*target, int(amount), horizontal=axis.lower() == "h")
                    elif item.startswith("drag:"):
                        (_kind, button, grid, sx, sy, ex, ey, milliseconds) = item.split(":")
                        start = point(grid, sx, sy)
                        end_point = point(grid, ex, ey)
                        if start is None or end_point is None:
                            return ACTION_BLOCKED
                        success = drag_pointer(
                            *start, *end_point, button=button,
                            duration=max(0.005, min(600.0, int(milliseconds) / 1000.0)),
                            stop_event=self.stop_event)
                    else:
                        return ACTION_FAILED
                except (OSError, ValueError, TypeError, KeyError, OverflowError,
                        ctypes.ArgumentError) as exc:
                    self._log_runtime("input_action_error", f"{type(exc).__name__}:{str(item)[:120]}")
                    return ACTION_FAILED

                if not success:
                    return ACTION_BLOCKED if self.stop_event.is_set() else ACTION_FAILED
                if repeat_index + 1 < repeats:
                    end = time.monotonic() + 0.055
                    while time.monotonic() < end:
                        if self.stop_event.is_set():
                            return ACTION_BLOCKED
                        time.sleep(min(0.012, max(0.002, end - time.monotonic())))
            return ACTION_EXECUTED

        if action.startswith("macro:"):
            parts = Learner._macro_parts(action)
            if not parts:
                return ACTION_FAILED
            learned_pause = Learner._macro_interval_ms(action)
            for index, item in enumerate(parts):
                if self.stop_event.is_set() or not self._screen_ready():
                    return ACTION_BLOCKED
                status = perform_atomic(item, allow_repeat=False)
                if status != ACTION_EXECUTED:
                    return status
                if index + 1 < len(parts):
                    pause = ((learned_pause or 60) / 1000.0)
                    end = time.monotonic() + pause
                    while time.monotonic() < end:
                        if self.stop_event.is_set():
                            return ACTION_BLOCKED
                        time.sleep(min(0.012, max(0.002, end - time.monotonic())))
            return ACTION_EXECUTED
        return perform_atomic(action, allow_repeat=True)

    def _read_current(self, verify_low_confidence=True, expected=None):
        if self.stop_event.is_set():
            return None, 0.0
        roi = self._current_roi()
        if not roi:
            self._set_source_health("target", False, 0.0, "target_roi_unavailable")
            self._target_read_failures += 1
            if self._target_read_failures >= self._target_relocate_threshold():
                self._relocalize_target(expected=expected)
            return None, 0.0
        value, confidence, _text = self.reader.read(roi, expected=expected)
        if self.stop_event.is_set():
            return None, confidence
        min_conf = 0.28 if self.hardware.verify_reads else 0.34
        if value is None or confidence < min_conf:
            self._set_source_health(
                "target", False, confidence,
                "target_ocr_no_value" if value is None else "target_ocr_low_confidence")
            self._target_read_failures += 1
            if self._target_read_failures >= self._target_relocate_threshold():
                if self._relocalize_target(expected=expected) and not self.stop_event.is_set():
                    roi = self._current_roi()
                    if roi:
                        value, confidence, _text = self.reader.read(roi, expected=expected)
                        if value is not None and confidence >= min_conf:
                            self._target_read_failures = 0
                            self._set_source_health("target", True, confidence, "")
                            return value, confidence
            return None, confidence
        self._target_read_failures = 0
        self._set_source_health("target", True, confidence, "")

        catastrophic = False
        suspicious = False
        if expected is not None:
            scale = max(1.0, abs(expected))
            ratio = abs(value - expected) / scale
            catastrophic = ratio > 100000

            suspicious = ratio > 24 or (expected > 0 and value >= 0 and value < expected * 0.08)
        mandatory_verify = catastrophic or suspicious
        should_verify = (verify_low_confidence and
                         (mandatory_verify or
                          (self.hardware.verify_reads and confidence < 0.78)) and
                         not self.stop_event.is_set())
        if should_verify:
            reads = [(value, confidence)]
            extra = max(1 if mandatory_verify else 0, self.hardware.verify_reads)
            if catastrophic:
                extra += 1
            for _ in range(extra):
                if self.stop_event.is_set():
                    break
                value2, confidence2, _text2 = self.reader.read(roi, expected=expected)
                if value2 is not None and confidence2 >= min_conf:
                    reads.append((value2, confidence2))
                if self.stop_event.is_set():
                    break
                if confidence2 >= 0.90 and any(
                        ScoreReader._same_value(value2, v) for v, _c in reads[:-1]):
                    break
            ranked = []
            for candidate, conf in reads:
                support = [c for v, c in reads if ScoreReader._same_value(v, candidate)]
                ranked.append((sum(support) + 0.12 * len(support), max(support),
                               len(support), candidate))
            ranked.sort(reverse=True)
            _weight, best_conf, support, best_value = ranked[0]
            if expected is not None and support == 1:
                scale = max(1.0, abs(expected))
                if abs(best_value - expected) > scale * 100000 and best_conf < 0.94:
                    self._set_source_health("target", False, best_conf, "target_ocr_unconfirmed_jump")
                    return None, best_conf
            value = best_value
            confidence = min(0.997, best_conf + 0.065 * max(0, support - 1))
        self._set_source_health("target", True, confidence, "")
        return value, confidence

    def _mouse_region_key(self, action, rows=4, cols=6):
        point = self._action_fraction(action)
        if not point:
            return "unknown"
        fx, fy = point
        col = max(0, min(cols - 1, int(fx * cols)))
        row = max(0, min(rows - 1, int(fy * rows)))
        return f"r{row}c{col}"

    def _rank_leaf_actions(self, learner, actions, state, limit=28):
        ranked = []
        for action in dict.fromkeys(actions):
            if not action or self._action_is_dangerous(action):
                continue
            quality = learner.action_quality(action, state)
            _q, n, _v = learner._value(learner.stats.get(action, {}))
            prior = max(0.0, min(1.0, float(self.action_priors.get(action, 0.50))))
            novelty = 0.16 / math.sqrt(n + 1.0)
            prior_strength = math.exp(-max(0.0, float(n)) / 1.15)
            ranked.append((quality + (prior - 0.5) * 0.10 * prior_strength + novelty, action))
        ranked.sort(reverse=True)
        if len(ranked) <= limit:
            return [a for _score, a in ranked]
        proven = [a for _score, a in ranked[:max(8, limit * 2 // 3)]]
        tail = [a for _score, a in ranked[max(8, limit * 2 // 3):]]
        rotate = []
        if tail:
            start = learner.steps % len(tail)
            rotate = (tail + tail)[start:start + max(0, limit - len(proven))]
        return list(dict.fromkeys(proven + rotate))[:limit]

    def _parameterize_macro_actions(self, learner, actions):
        out = []
        for action in actions:
            if not str(action).startswith("macro:"):
                out.append(action)
                continue
            parts = Learner._macro_parts(action)
            if len(parts) < 2:
                continue
            payload = "|".join(parts)
            fraction = self._parameter_fraction(f"macro-gap:{payload}", learner.steps)
            interval = learner.sample_parameter("macro.interval_ms", 10, 1500, fraction,
                                                integer=True, log_scale=True)
            variant = f"macro:{interval}:{payload}"
            self.action_priors.setdefault(variant, float(self.action_priors.get(action, 0.50)) * 0.96)
            out.append(variant)
        return list(dict.fromkeys(out))

    def _choose_hierarchical_action(self, learner, state, stagnant, key_actions, mouse_actions):
        safe_mouse = [a for a in mouse_actions if not self._action_is_dangerous(a)]
        protected = [a for a in safe_mouse if a in self._recognized_actions]
        _keyboard_limit, mouse_limit = self._adaptive_candidate_limits(learner, stagnant)
        focus_limit = max(36, min(mouse_limit, int(round(mouse_limit * (0.58 + min(0.30, stagnant * 0.012))))))
        focused = learner.focus_actions(safe_mouse, state, stagnant, self.action_priors, focus_limit)
        safe_mouse = list(dict.fromkeys(protected + focused))
        top = {
            "keyboard": list(key_actions),
            "click": [a for a in safe_mouse if a.startswith(("mouse:", "click:", "tap:", "pointer:"))],
            "wheel": [a for a in safe_mouse if a.startswith("wheel:")],
            "drag": [a for a in safe_mouse if a.startswith("drag:")],
            "wait": [OBSERVE_ACTION],
        }
        family = learner.choose_group(top, state, stagnant, self.action_priors)
        if not family:
            return None, [], "none"
        leaf = top[family]
        path = family
        if family == "keyboard":
            sub = {}
            for action in leaf:
                sub.setdefault(self._keyboard_category(action), []).append(action)
            category = learner.choose_group(sub, state, stagnant, self.action_priors)
            if category:
                leaf = sub[category]
                path += "/" + category
        elif family == "click":
            operation_groups = {}
            for candidate in leaf:
                operation_groups.setdefault(str(candidate).split(":", 1)[0], []).append(candidate)
            operation_type = learner.choose_group(operation_groups, state, stagnant, self.action_priors)
            if operation_type:
                leaf = operation_groups[operation_type]
                path += "/" + operation_type
            recognized_points = [self._action_fraction(a) for a in self._recognized_actions]
            recognized_points = [p for p in recognized_points if p]
            remembered = []
            for prefix in ("mouse:", "click:", "tap:", "pointer:"):
                remembered.extend(learner.preferred_actions(prefix, limit=24))
            remembered = [action for action in remembered if self._spatial_action_identity_stable(action)]
            remembered_points = [self._action_fraction(a) for a in remembered]
            remembered_points = [p for p in remembered_points if p]
            sources = {"recognized": [], "history": [], "new": []}
            for action in leaf:
                point = self._action_fraction(action)
                if not point:
                    sources["new"].append(action)
                    continue
                if any(abs(point[0]-p[0]) <= 0.018 and abs(point[1]-p[1]) <= 0.018 for p in recognized_points):
                    sources["recognized"].append(action)
                elif any(abs(point[0]-p[0]) <= 0.022 and abs(point[1]-p[1]) <= 0.022 for p in remembered_points):
                    sources["history"].append(action)
                else:
                    sources["new"].append(action)
            source = learner.choose_group(sources, state, stagnant, self.action_priors)
            if source:
                leaf = sources[source]
                path += "/" + source
        if family in {"click", "wheel", "drag"} and len(leaf) > 1:
            regions = {}
            for action in leaf:
                regions.setdefault(self._mouse_region_key(action), []).append(action)
            region = learner.choose_group(regions, state, stagnant, self.action_priors)
            if region:
                leaf = regions[region]
                path += "/" + region
        leaf = self._rank_leaf_actions(learner, leaf, state, limit=EXPLORATION_CONFIG.leaf_rank_limit)
        if family != "wait":
            leaf = learner.expand_actions(
                leaf, state, stagnant,
                limit=min(EXPLORATION_CONFIG.leaf_expand_max, max(2, len(leaf) // 6)))
            leaf = self._parameterize_macro_actions(learner, leaf)
            leaf = [a for a in leaf if not self._action_is_dangerous(a)]
        action = learner.choose(leaf, state, stagnant, priors=self.action_priors) if leaf else None
        self._last_decision_family = path
        return action, leaf, path

    def _causal_validation_confidence(self, learner, action, state):
        family = learner._key_probe_family(state)
        stat = learner.causal_validations.get(f"{action}|{family}", {})
        try:
            return max(0.0, min(1.0, float(stat.get("intervention_confidence", 0.0) or 0.0)))
        except (TypeError, ValueError, OverflowError):
            return 0.0

    def _should_measure_pre_action_baseline(self, learner, action, state, quality):
        if action == OBSERVE_ACTION or self.stop_event.is_set():
            return False
        passive_rate, passive_n, passive_uncertainty = learner.passive_rate_estimate(state)
        _q, action_samples, action_variance = learner._value(learner.stats.get(action, {}))
        high_value = float(quality or 0.0) >= DECISION_CONFIG.causal_probe_quality
        causal_confidence = self._causal_validation_confidence(learner, action, state)
        # Promising but causally uncertain actions get an explicit matched
        # observe -> action -> observe experiment instead of being credited for drift.
        targeted_experiment = high_value and causal_confidence < 0.62
        moving_environment = abs(float(passive_rate)) >= DECISION_CONFIG.causal_probe_min_passive_rate
        evidence_gap = 1.0 / math.sqrt(max(0.0, float(action_samples) + float(passive_n)) + 1.0)
        model_uncertainty = (math.sqrt(max(0.0, float(action_variance))) +
                             math.sqrt(max(0.0, float(passive_uncertainty))) + evidence_gap)
        uncertain = model_uncertainty >= 0.42 or action_samples < 2 or passive_n < 1.2
        return bool(targeted_experiment or moving_environment or uncertain)

    def _measure_pre_action_baseline(self, learner, state, before, before_conf):
        started = time.monotonic()
        latency = float(getattr(self.reader, "latency", 0.25) or 0.25)
        duration = max(DECISION_CONFIG.causal_probe_min_seconds,
                       min(DECISION_CONFIG.causal_probe_max_seconds, 0.08 + latency * 0.40))
        end = started + duration
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(min(0.018, max(0.002, end - time.monotonic())))
        elapsed = max(0.06, time.monotonic() - started)
        if self.stop_event.is_set():
            return before, before_conf, None, 0.0, elapsed
        passive_score, passive_conf = self._read_current(False, expected=before)
        if passive_score is None:
            return before, before_conf, None, 0.0, elapsed
        reliability = math.sqrt(max(0.0, float(before_conf)) * max(0.0, float(passive_conf)))
        if reliability < 0.28:
            return before, before_conf, None, reliability, elapsed
        rate = Learner._rate_signal(before, passive_score, elapsed, reliability)
        learner.observe_passive(before, passive_score, state, reliability, elapsed)
        if learner.best is None or float(passive_score) > float(learner.best):
            learner.best = float(passive_score)
        return passive_score, passive_conf, rate, reliability, elapsed

    def _measure_post_action_window(self, before, before_conf, duration):
        """Observe the treatment for the same duration as its local no-action baseline."""
        duration = max(0.06, float(duration or 0.0))
        started = time.monotonic()
        end = started + duration
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(min(0.018, max(0.002, end - time.monotonic())))
        if self.stop_event.is_set():
            return None, 0.0, None, 0.0
        observed, confidence = self._read_current(False, expected=before)
        if observed is None:
            return None, 0.0, None, 0.0
        elapsed = max(0.06, time.monotonic() - started)
        reliability = math.sqrt(max(0.0, float(before_conf)) * max(0.0, float(confidence)))
        if reliability < 0.20:
            return observed, confidence, None, reliability
        rate = Learner._rate_signal(before, observed, elapsed, reliability)
        return observed, confidence, rate, reliability

    def _adaptive_wait(self, quality=0.0, delay_hint=0.0):
        base = self.hardware.settle
        latency = self.reader.latency if self.reader else 0.25
        capture = self.capture.latency if self.capture else 0.02
        delay = base + min(0.34, latency * 0.34 + capture * 0.45) + max(0.0, min(0.92, delay_hint))
        if quality > 0.9:
            delay += 0.045
        floor = 0.18 if self.hardware.tier == "high" else 0.22
        end = time.monotonic() + max(floor, min(1.65, delay))
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(0.022)

    def _isolation_observe(self, before, value, confidence, action_started, duration=1.5):
        current, current_conf = value, confidence
        deadline = max(time.monotonic(), float(action_started) + max(0.55, float(duration)))
        last_read = 0.0
        while time.monotonic() < deadline and not self.stop_event.is_set():
            now = time.monotonic()
            if now - last_read < 0.16:
                time.sleep(min(0.045, deadline - now))
                continue
            last_read = now
            candidate, candidate_conf = self._read_current(False, expected=current if current is not None else before)
            if candidate is None:
                continue
            if current is None:
                current, current_conf = candidate, candidate_conf
                continue
            old_delta, new_delta = current - before, candidate - before
            same_direction = (old_delta == 0 or new_delta == 0 or old_delta * new_delta >= 0)
            if same_direction or candidate_conf >= current_conf + 0.08:
                current, current_conf = candidate, max(current_conf * 0.88, candidate_conf)
        return current, current_conf, time.monotonic()

    def _run_ai(self):
        learner = None
        last_save = time.monotonic()
        last_capture_check = time.monotonic()
        reason = "用户按下 ESC，AI 已关闭"
        try:
            time.sleep(0.60)
            if self.stop_event.is_set():
                return
            score, score_conf = None, 0.0
            while not self.stop_event.is_set() and score is None:
                if self._screen_ready():
                    score, score_conf = self._read_current()
                if score is None:
                    time.sleep(0.16)
            if self.stop_event.is_set():
                return
            try:
                if self._scan_scene_semantics(score, reason="selection", force=True):
                    self._last_semantic_scan_step = 0
            except Exception as exc:
                self._log_runtime("initial_semantic_scan_error", type(exc).__name__)
            # Build the stable application/target profile after context discovery;
            # layout and scene structure remain context inside the database.
            learner = Learner(self._profile_file())
            self._active_learner = learner
            self.reader.numeric_scale_graph.load_snapshot(
                learner.numeric_scales.get("target", {}))
            if self.reader.last_text and score is not None:
                self.reader.numeric_scale_graph.observe(
                    self.reader.last_text, score, score_conf)
            if learner.best is None:
                learner.best = score
            stagnant = 0
            click_actions = []
            failures = 0
            previous_score = score
            state = self._state_key(score, score, stagnant, learner.best, True)

            if not self.stop_event.is_set():
                passive_started = time.monotonic()
                end = time.monotonic() + max(0.16, min(0.38, self.hardware.settle * 0.70))
                while time.monotonic() < end and not self.stop_event.is_set():
                    time.sleep(0.020)
                passive_score, passive_conf = self._read_current(False, expected=score)
                if passive_score is not None and passive_conf >= 0.50:
                    passive_reliability = math.sqrt(max(0.0, score_conf) * max(0.0, passive_conf))
                    passive_elapsed = max(0.06, time.monotonic() - passive_started)
                    passive_rate = Learner._rate_signal(score, passive_score, passive_elapsed, passive_reliability)
                    self._state_acceleration = passive_rate - self._state_velocity
                    self._state_velocity = passive_rate
                    learner.observe_passive(score, passive_score, state, passive_reliability, passive_elapsed)
                    previous_score, score, score_conf = score, passive_score, passive_conf
                    if learner.best is None or score > learner.best:
                        learner.best = score
            loop_count = 0
            failure_window = []
            while not self.stop_event.is_set():
                loop_count += 1
                if not self._screen_ready():
                    time.sleep(0.12)
                    continue
                previous_scope = self._operation_scope_signature
                if not self._adaptive_operation_rect(stagnant=stagnant, refresh=True, reason="learning-cycle"):
                    time.sleep(0.08)
                    continue
                if self._operation_scope_signature != previous_scope:
                    click_actions = []
                if self._target_read_failures >= self._target_relocate_threshold():
                    recovered, recovered_conf = self._read_current(False, expected=score)
                    if recovered is None:
                        time.sleep(min(0.22, 0.06 + self.reader.latency * 0.10))
                        continue
                    previous_score, score, score_conf = score, recovered, recovered_conf
                    click_actions = []
                roi = self._current_roi()
                refresh_every = self.hardware.candidate_refresh
                if stagnant > DECISION_CONFIG.refresh_stagnation:
                    refresh_every = max(3, refresh_every // 3)
                if (learner.steps % refresh_every == 0 or not click_actions):
                    discovered = self._click_candidates(roi, stagnant=stagnant)
                    remembered = [action for action in learner.preferred_actions("mouse:", limit=40)
                                  if self._spatial_action_identity_stable(action)]
                    refine_limit = max(24, min(96, len(remembered) * 5))
                    refine_radius = 2 if stagnant > DECISION_CONFIG.refresh_stagnation else 1
                    refined = self._mouse_neighborhood(
                        remembered, radius=refine_radius, limit=refine_limit, learner=learner)
                    _keyboard_limit, mouse_limit = self._adaptive_candidate_limits(learner, stagnant)
                    click_actions = list(dict.fromkeys(remembered + refined + discovered))[:mouse_limit]
                semantic_step_interval = max(2, int(round(
                    LEARNING_CONFIG.semantic_refresh_steps *
                    max(0.62, min(1.75, 0.82 + self.reader.latency * 0.55 - min(0.28, abs(self._state_velocity) * 0.025))))))
                semantic_time_interval = max(0.65, min(4.2,
                    LEARNING_CONFIG.semantic_refresh_seconds *
                    max(0.42, min(1.45, 0.64 + self.reader.latency * 0.42))))
                if (learner.steps - self._last_semantic_scan_step >= semantic_step_interval or
                        (stagnant >= max(6, semantic_step_interval * 2) and
                         time.monotonic() - self._last_semantic_scan_at >= semantic_time_interval * 0.55)):
                    reason_hint = "stagnant" if stagnant >= 12 else "periodic"
                    if self._scan_scene_semantics(score, reason=reason_hint, force=False):
                        self._last_semantic_scan_step = learner.steps
                refresh_state = learner.steps % self.hardware.state_every == 0
                state = self._state_key(score, previous_score, stagnant, learner.best,
                                        refresh_visual=refresh_state)
                self._last_decision_state = state
                key_actions = self._keyboard_candidates(learner, stagnant, state)
                if self._operation_scope_reason == "desktop-cold":
                    key_actions = []
                mouse_actions = self._mouse_input_candidates(learner, click_actions, stagnant)
                passive_interval = (DECISION_CONFIG.passive_interval_high if self.hardware.tier == "high" else
                                    (DECISION_CONFIG.passive_interval_balanced if self.hardware.tier == "balanced" else
                                     DECISION_CONFIG.passive_interval_low))
                _passive_rate, passive_n, passive_uncertainty = learner.passive_rate_estimate(state)
                passive_information_gap = 1.0 / math.sqrt(max(0.0, float(passive_n)) + 1.0)
                passive_need = min(1.0, math.sqrt(max(0.0, float(passive_uncertainty))) + passive_information_gap)
                adaptive_passive_interval = max(5, int(round(
                    passive_interval * max(0.38, min(1.55, 1.42 - passive_need)))))
                scheduled_observation = (loop_count > 2 and passive_need >= 0.24 and
                                         loop_count % adaptive_passive_interval == 0)
                if scheduled_observation:
                    action, decision_actions, decision_path = OBSERVE_ACTION, [OBSERVE_ACTION], "scheduled/wait"
                else:
                    action, decision_actions, decision_path = self._choose_hierarchical_action(
                        learner, state, stagnant, key_actions, mouse_actions)
                if not action:
                    time.sleep(0.05)
                    continue
                if loop_count % DECISION_CONFIG.decision_log_interval == 0:
                    self._log_runtime(
                        "decision",
                        f"path={decision_path} keyboard={len(key_actions)} mouse={len(mouse_actions)} "
                        f"leaf={len(decision_actions)} stagnant={stagnant} controls={self._last_control_count} "
                        f"danger={self._last_danger_count} ocr={self.reader.latency:.3f}s capture={self.capture.latency:.3f}s")
                before = score
                semantic_probe = False
                if (action != OBSERVE_ACTION and self._should_semantic_refresh(action, stagnant, learner.steps) and
                        time.monotonic() - self._last_semantic_scan_at >= 1.0):
                    semantic_probe = self._scan_scene_semantics(before, reason="action_probe", force=True)
                    if semantic_probe:
                        self._last_semantic_scan_step = learner.steps
                        state = self._state_key(score, previous_score, stagnant, learner.best, refresh_visual=False)
                        self._last_decision_state = state
                quality = learner.action_quality(action, state)
                delay_hint = learner.delay_hint(action)
                pre_action_rate = None
                pre_action_reliability = 0.0
                matched_observation_seconds = 0.0
                paired_treatment_rate = None
                paired_treatment_reliability = 0.0
                if self._should_measure_pre_action_baseline(learner, action, state, quality):
                    (baseline_score, baseline_conf, pre_action_rate, pre_action_reliability,
                     matched_observation_seconds) = self._measure_pre_action_baseline(
                        learner, state, before, score_conf)
                    if baseline_score is not None:
                        before = float(baseline_score)
                        score = before
                        score_conf = float(baseline_conf)
                        state = self._state_key(score, previous_score, stagnant, learner.best,
                                                refresh_visual=False)
                        self._last_decision_state = state
                self._refresh_tracked_number_values_fast(score_override=before)
                numbers_before = self._number_snapshot(score_override=before)
                scene_changed = (self._last_isolation_scene != self._control_graph_hash)
                isolation_mode = learner.needs_isolation(action, state, score_conf, scene_changed)
                self._last_isolation_scene = self._control_graph_hash
                _influence_q, influence_n, _influence_v = learner.influence_value(state, action)
                probe_visual = ((action == OBSERVE_ACTION and learner.steps % 2 == 0) or
                                (action != OBSERVE_ACTION and
                                 (influence_n < 3 or stagnant >= 10 or learner.steps % 4 == 0)))
                key_probe_rect = self._target_client_rect() if str(action).startswith("key:") else None
                visual_before = self._visual_effect_probe(key_probe_rect) if probe_visual else None
                action_scope_key = self._operation_scope_key
                scope_relevant = any(part.startswith(
                    ("mouse:", "pointer:", "click:", "tap:", "wheel:", "drag:"))
                    for part in Learner._macro_parts(action))
                action_started = time.monotonic()
                factor_before = self._factor_observation(
                    action, state, numbers_before, learner=learner,
                    observed_at=action_started, pre_action_rate=pre_action_rate)
                foreground_before = self._foreground_root() if os.name == "nt" else 0
                control_graph_before = str(self._control_graph_hash or "")
                scope_signature_before = str(self._operation_scope_signature or "")
                if action != OBSERVE_ACTION:
                    self._last_action_at = action_started
                performed = self._perform(action, quality)
                if action != OBSERVE_ACTION:
                    learner.record_input_result(action, performed)
                if performed != ACTION_EXECUTED:
                    if scope_relevant:
                        learner.observe_scope(
                            action_scope_key, performed=False, blocked=(performed == ACTION_BLOCKED))
                    self._log_runtime("input_reliability", f"{performed}:{str(action)[:160]}")
                    time.sleep(0.12 if performed == ACTION_BLOCKED else 0.08)
                    continue
                if str(action).startswith("key:") and not self._input_scope_ready(action, restore=False):
                    name = str(action).split(":", 1)[1]
                    learner.observe_key_probe(name, state, effect=False, confidence=1.0, lost_focus=True)
                    learner.record_side_effect(action, state, 1.0,
                                               signals={"focus_shift": 1.0}, reliability=1.0)
                    self._key_probe_misses.pop(name, None)
                    status = learner.key_probe_status(name, state)
                    self._log_runtime("key_cooldown",
                                      f"{name}:foreground until={status.get('cooldown_until')}")
                    self._input_scope_ready(action, restore=True)
                    time.sleep(0.08)
                    continue
                if action != OBSERVE_ACTION and matched_observation_seconds > 0.0:
                    (_paired_score, _paired_conf, paired_treatment_rate,
                     paired_treatment_reliability) = self._measure_post_action_window(
                        before, score_conf, matched_observation_seconds)
                self._adaptive_wait(quality, delay_hint)
                if self.stop_event.is_set():
                    break
                new_score, new_conf = self._read_current(expected=before)
                # Independent channel prevents expected-aware OCR from anchoring on
                # the old value when the target legitimately jumps by orders of magnitude.
                if (new_score is not None and not self.stop_event.is_set() and
                        (learner.steps % 7 == 0 or (probe_visual and learner.steps % 3 == 0))):
                    independent, independent_conf = self._read_current(False, expected=None)
                    if independent is not None:
                        disagreement = abs(float(independent) - float(new_score)) / max(1.0, abs(float(new_score)), abs(float(before)))
                        primary_jump = abs(float(new_score) - float(before)) / max(1.0, abs(float(before)))
                        independent_jump = abs(float(independent) - float(before)) / max(1.0, abs(float(before)))
                        if (disagreement > 0.08 and independent_conf >= new_conf + 0.03) or (independent_jump > 0.24 and primary_jump < 0.08 and independent_conf >= 0.62):
                            new_score, new_conf = independent, independent_conf
                        elif disagreement <= 0.03:
                            new_conf = min(0.997, math.sqrt(max(0.0, new_conf) * max(0.0, independent_conf)) + 0.04)
                if new_score is not None and isolation_mode and not self.stop_event.is_set():
                    new_score, new_conf, _isolated_at = self._isolation_observe(
                        before, new_score, new_conf, action_started, duration=1.5)
                if new_score is None:
                    if action != OBSERVE_ACTION:
                        self._observe_action_side_effects(
                            learner, action, state, foreground_before, control_graph_before,
                            scope_signature_before, numbers_before=numbers_before,
                            numbers_after=None, reliability=max(0.35, float(score_conf or 0.0)))
                    failures += 1
                    failure_window.append(1)
                    if len(failure_window) > 24:
                        failure_window = failure_window[-24:]
                    if failures % 3 == 0:
                        try:
                            live_roi = self._current_roi()
                            self.capture.benchmark(live_roi)
                            self.hardware.capture_backend = self.capture.backend
                            self.hardware.save_tuning()
                        except Exception as exc:
                            self._log_runtime("capture_rebenchmark_error", type(exc).__name__)
                    if learner is not None:
                        learner.history.append((action, state, action_started))
                        if len(learner.history) > 14:
                            learner.history = learner.history[-14:]
                    score = before
                    previous_score = before
                    time.sleep(min(0.8, 0.08 + failures * 0.035))
                    continue
                failures = 0
                failure_window.append(0)
                if len(failure_window) > 24:
                    failure_window = failure_window[-24:]
                delayed_effect = False
                effect_observed_at = time.monotonic()
                tiny = max(1e-9, abs(before) * 1e-10)
                if abs(new_score - before) <= tiny and not self.stop_event.is_set():
                    probe_window = learner.delay_probe_window(action, stagnant)
                    target = action_started + probe_window
                    while time.monotonic() < target and not self.stop_event.is_set():
                        time.sleep(min(0.055, max(0.012, target - time.monotonic())))
                    if not self.stop_event.is_set() and time.monotonic() >= target - 0.02:
                        delayed, delayed_conf = self._read_current(False, expected=before)
                        if delayed is not None and (delayed != before or delayed_conf > new_conf):
                            delayed_effect = abs(delayed - before) > tiny
                            new_score, new_conf = delayed, delayed_conf
                            if delayed_effect:
                                effect_observed_at = time.monotonic()
                if action != OBSERVE_ACTION and abs(new_score - before) <= tiny:
                    elapsed_effect = max(0.0, effect_observed_at - action_started)
                    learner.record_delay(action, elapsed_effect, effect=False, weight=0.12)

                if abs(new_score - before) > tiny and not self.stop_event.is_set():
                    _q, action_samples, _variance = learner._value(
                        learner.stats.get(action, {}))
                    relative_change = abs(new_score - before) / max(1.0, abs(before))
                    if relative_change > 0.24 and not isolation_mode:
                        new_score, new_conf, effect_observed_at = self._isolation_observe(
                            before, new_score, new_conf, action_started, duration=1.5)
                        relative_change = abs(new_score - before) / max(1.0, abs(before))
                    distribution = list(getattr(self.reader, "last_distribution", []) or [])
                    distribution_ambiguous = False
                    if len(distribution) >= 2:
                        try:
                            p2 = float(distribution[1].get("probability", 0.0))
                            v1 = float(distribution[0].get("value", new_score))
                            v2 = float(distribution[1].get("value", new_score))
                            lo = max(1e-12, min(abs(v1), abs(v2)))
                            hi = max(abs(v1), abs(v2), 1e-12)
                            distribution_ambiguous = p2 >= 0.18 or (p2 >= 0.10 and hi / lo >= 10.0)
                        except Exception:
                            distribution_ambiguous = True
                    needs_confirmation = (action_samples < 5 or new_conf < 0.90 or
                                          relative_change > 0.24 or distribution_ambiguous)
                    if needs_confirmation:
                        end = time.monotonic() + min(0.18, 0.045 + self.reader.latency * 0.16)
                        while time.monotonic() < end and not self.stop_event.is_set():
                            time.sleep(0.018)
                        confirmed, confirmed_conf = self._read_current(False, expected=new_score)
                        if confirmed is not None:
                            same_direction = ((new_score - before) * (confirmed - before) > 0 or
                                              abs(confirmed - before) <= tiny)
                            if same_direction and new_score > before and confirmed > before:
                                new_score = min(new_score, confirmed)
                            elif same_direction and new_score < before and confirmed < before:

                                new_score = max(new_score, confirmed)
                            elif confirmed_conf >= new_conf - 0.03:
                                new_score = confirmed
                            new_conf = math.sqrt(max(0.0, new_conf) *
                                                 max(0.0, confirmed_conf))
                        else:
                            new_conf *= 0.72

                observation_conf = math.sqrt(max(0.0, score_conf) * max(0.0, new_conf))
                measurement_elapsed = max(0.06, time.monotonic() - action_started)
                if (action != OBSERVE_ACTION and
                        (semantic_probe or str(action).startswith(("click:control:", "uia:")) or
                         learner.steps - self._last_semantic_scan_step >= LEARNING_CONFIG.semantic_refresh_steps) and
                        time.monotonic() - self._last_semantic_scan_at >= 0.55):
                    if self._scan_scene_semantics(new_score, reason="effect", force=True):
                        self._last_semantic_scan_step = learner.steps
                self._refresh_tracked_number_values_fast(score_override=new_score)
                numbers_after = self._number_snapshot(score_override=new_score)
                visual_after = self._visual_effect_probe(key_probe_rect) if visual_before is not None else None
                visual_change = self._visual_effect_change(visual_before, visual_after)
                if action == OBSERVE_ACTION and visual_before is not None:
                    self._update_visual_noise(visual_change)
                if visual_before is None:
                    self._motion_mask = 0
                measurement_health = self._measurement_health(
                    numbers_before, numbers_after, target_confidence=new_conf)
                measurement_valid = bool(measurement_health.get("valid", False))
                if measurement_valid:
                    self._observe_key_probe(action, state, before, new_score, new_conf, visual_change)
                transition_rate = Learner._rate_signal(before, new_score, measurement_elapsed, observation_conf)
                if action == OBSERVE_ACTION:
                    self._state_acceleration = transition_rate - self._state_velocity
                    self._state_velocity = transition_rate
                else:
                    historical_passive_rate, _passive_n, _passive_v = learner.passive_rate_estimate(state)
                    expected_rate = (float(pre_action_rate) if pre_action_rate is not None
                                     else float(historical_passive_rate))
                    self._state_acceleration = transition_rate - expected_rate
                    # Keep state velocity as an estimate of environmental drift rather
                    # than overwriting it with an action-caused jump.
                    self._state_velocity = self._state_velocity * 0.72 + expected_rate * 0.28
                long_q, long_n, _long_v = learner._nstep_value(state, action)
                strategic_loss = new_score < before and long_n >= 3 and long_q > 0.18
                if measurement_valid:
                    next_stagnant = (0 if new_score > before else
                                     stagnant + (1 if strategic_loss or new_score == before else 2))
                else:
                    # Sensor uncertainty must not masquerade as action ineffectiveness.
                    next_stagnant = 0 if new_score > before else stagnant
                next_state = self._state_key(
                    new_score, before, next_stagnant, learner.best,
                    refresh_visual=((learner.steps + 1) % self.hardware.state_every == 0))
                if measurement_valid:
                    delta, reward = learner.learn(
                        action, before, new_score, state, next_state,
                        confidence=observation_conf, actions=decision_actions,
                        action_started=action_started, observed_at=effect_observed_at,
                        elapsed_seconds=measurement_elapsed, visual_change=visual_change,
                        pre_action_rate=pre_action_rate,
                        pre_action_reliability=pre_action_reliability,
                        paired_treatment_rate=paired_treatment_rate,
                        paired_treatment_reliability=paired_treatment_reliability)
                    if scope_relevant:
                        learner.observe_scope(action_scope_key, reward=reward,
                                              visual_change=visual_change, performed=True)
                else:
                    delta, reward = float(new_score - before), 0.0
                    learner.record_measurement_failure(action, state, measurement_health)
                    if learner.best is None or float(new_score) > float(learner.best):
                        learner.best = float(new_score)
                    self._log_runtime(
                        "measurement_failure",
                        f"action={str(action)[:120]} reason={measurement_health.get('failure_reason','')} "
                        f"confidence={measurement_health.get('confidence',0.0):.3f}")
                if measurement_valid and action != OBSERVE_ACTION:
                    self._observe_action_side_effects(
                        learner, action, state, foreground_before, control_graph_before,
                        scope_signature_before, numbers_before=numbers_before,
                        numbers_after=numbers_after, reliability=observation_conf)
                if measurement_valid:
                    factor_before.add("time.elapsed", measurement_elapsed, kind="scalar",
                                      confidence=observation_conf,
                                      metadata={"scale": max(0.25, learner.adaptive_credit_horizon(action))})
                    factor_before.add("screen.visual_change", visual_change, kind="scalar",
                                      confidence=observation_conf, metadata={"scale": 0.08})
                    learner.record_numeric_effect(
                        action, state, numbers_before, numbers_after,
                        reliability=observation_conf, delay=measurement_elapsed,
                        factor_observation=factor_before)
                previous_score, score, score_conf = before, new_score, new_conf
                stagnant = 0 if delta > 0 else next_stagnant

                old_scene = state.split(":x", 1)[0]
                new_scene = next_state.split(":x", 1)[0]
                if old_scene != new_scene:
                    click_actions = []

                if measurement_valid and delta > 0:
                    hot = [p for p in Learner._macro_parts(action) if Learner._mouse_point(p) is not None]
                    if hot:
                        local = self._mouse_neighborhood(
                            hot, radius=1, limit=max(20, len(hot) * 12), learner=learner)
                        _keyboard_limit, mouse_limit = self._adaptive_candidate_limits(learner, stagnant)
                        click_actions = list(dict.fromkeys(hot + local + click_actions))[:mouse_limit]

                if (loop_count % 24 == 0 and
                        time.monotonic() - last_capture_check >= 18.0 and
                        self.capture.should_rebenchmark(self.hardware.capture_recheck_interval)):
                    try:
                        live_roi = self._current_roi()
                        old_backend = self.capture.backend
                        self.capture.benchmark(live_roi)
                        self.hardware.capture_backend = self.capture.backend
                        if self.capture.backend != old_backend:
                            self.hardware.save_tuning(force=True)
                        last_capture_check = time.monotonic()
                    except Exception as exc:
                        self._log_runtime("capture_health_error", type(exc).__name__)

                if loop_count % 16 == 0:
                    fail_rate = sum(failure_window) / max(1, len(failure_window))
                    self.hardware.live_tune(self.reader.latency, self.capture.latency,
                                            self.reader.confidence_ema, fail_rate)
                    self.reader.latency_target = self.hardware.latency_target
                    target_variants = max(self.reader.min_variants,
                                          min(self.reader.max_variants, self.hardware.ocr_variants))
                    if abs(self.reader.active_variants - target_variants) > 1:
                        self.reader.active_variants += 1 if target_variants > self.reader.active_variants else -1

                if time.monotonic() - last_save > self.hardware.save_interval:
                    try:
                        learner.numeric_scales["target"] = self.reader.numeric_scale_graph.snapshot()
                        learner._mark_dirty(learner.numeric_scales, "target")
                        learner.save()
                    except (OSError, sqlite3.Error) as exc:
                        self._log_runtime("learner_save_error", f"{type(exc).__name__}: {exc}")
                    last_save = time.monotonic()
            if self.stop_event.is_set():
                reason = "用户按下 ESC，AI 已关闭"
        except Exception as exc:
            reason = f"AI 因错误停止：{exc}"
            self._log_exception("ai_fatal_error", exc)
        finally:
            release_all_inputs()
            self._active_learner = None
            if learner is not None:
                try:
                    learner.numeric_scales["target"] = self.reader.numeric_scale_graph.snapshot()
                    learner._mark_dirty(learner.numeric_scales, "target")
                    learner.close()
                except Exception as exc:
                    self._log_runtime("learner_final_save_error", f"{type(exc).__name__}: {exc}")
            if self.hook:
                self.hook.close()
            summary = (f"{reason}\n当前数值：{score:g}　最高数值：{learner.best:g}　"
                       f"累计学习：{learner.steps} 步　有效提升：{learner.positive} 次") \
                if learner is not None and 'score' in locals() and score is not None else reason
            self.events.put(("stopped", summary))

    def _poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "runtime_progress":
                    self._apply_runtime_progress(event[1])
                elif kind == "runtime_ready":
                    self._runtime_ready = True
                    self._runtime_progress_value = 100
                    self.progress_var.set(100)
                    self.progress_percent_var.set("100%")
                    self.progress_stage_var.set("准备完成")
                    self.progress_detail_var.set("主 OCR 与屏幕捕获已可用")
                    self.file_progress.stop()
                    if self.file_progress.winfo_manager():
                        self.file_progress.pack_forget()
                    self.progress_transfer_var.set("")
                    self.hardware_var.set(
                        f"{self._hardware_brief()} · OCR {self.hardware.rec_model} · "
                        f"截图 {self.hardware.capture_backend.upper()}")
                    self.status_var.set("准备完成。点击“数值”后截图会立即出现，OCR 框会逐步叠加。")
                    self.value_button.configure(state="normal")
                    self._start_background_tuning()
                elif kind == "runtime_tuned":
                    self.hardware_var.set(
                        f"{self._hardware_brief()} · OCR {self.hardware.rec_model} · 截图 {event[1]}")
                elif kind == "number_scan":
                    scan_id, image, candidates, screen = event[1:]
                    if scan_id != self._selection_scan_id:
                        continue
                    self.root.withdraw()
                    self._selection_snapshot = image
                    self._selection_screen = screen
                    self._selection_overlay = SelectionOverlay(
                        self.root, image, candidates, screen, self.ImageTk,
                        self._selection_done)
                elif kind == "number_scan_candidates":
                    scan_id, candidates = event[1:]
                    if scan_id == self._selection_scan_id and self._selection_overlay is not None:
                        try:
                            self._selection_overlay.add_candidates(candidates)
                        except tk.TclError:
                            pass
                elif kind == "number_scan_complete":
                    scan_id, candidates = event[1:]
                    if scan_id == self._selection_scan_id and self._selection_overlay is not None:
                        try:
                            self._selection_overlay.add_candidates(candidates)
                            count = len(self._selection_overlay.candidates)
                            title = (f"OCR 已完成 · 找到 {count} 个数值 · 可单击选择"
                                     if count else "OCR 已完成 · 可直接拖动框选目标数值")
                            self._selection_overlay.canvas.itemconfigure(
                                self._selection_overlay.title_item, text=title)
                        except tk.TclError:
                            pass
                elif kind == "number_scan_error":
                    scan_id, message = event[1:]
                    if scan_id != self._selection_scan_id:
                        continue
                    if self._selection_overlay is not None:
                        try:
                            self._selection_overlay.canvas.itemconfigure(
                                self._selection_overlay.title_item,
                                text="OCR 自动识别未完成 · 仍可直接拖动框选")
                        except tk.TclError:
                            pass
                        self._log_runtime("selection_ocr_error", message)
                        continue
                    self._selection_snapshot = None
                    self._selection_screen = None
                    self.root.deiconify()
                    self.root.lift()
                    self.selection_var.set("全屏数值扫描失败")
                    self.status_var.set(message)
                    self.value_button.configure(state="normal")
                elif kind == "selection":
                    value, _confidence, _text = event[1:]
                    self._selection_snapshot = None
                    self._selection_screen = None
                    self.root.deiconify()
                    self.root.lift()
                    self.value_button.configure(state="normal")
                    if value is None:
                        self.selection_var.set("未识别到数值，请重新扫描或拖框")
                        self.status_var.set("拖框范围应只包含目标数字，并留少量边距。")
                        self.confirm_button.configure(state="disabled")
                    else:
                        target_label = str(getattr(self.target_entity, "label", "") or "").strip()
                        target_role = str(getattr(self.target_entity, "role", "") or "").strip()
                        identity = f"{target_label} / {target_role}" if target_label else target_role
                        suffix = f"　语义：{identity}" if identity else ""
                        self.selection_var.set(f"已选择：{value:g}{suffix}　AI范围：自适应")
                        self.status_var.set("点击“确认”后 AI 自动开始；按 ESC 停止。")
                        self.confirm_button.configure(state="normal")
                elif kind == "stopped":
                    self.last_summary = event[1]
                    if self._close_requested:
                        continue
                    self.root.deiconify()
                    self.root.lift()
                    self.status_var.set(self.last_summary)
                    self.value_button.configure(state="normal")
                    self.confirm_button.configure(state="normal")
                elif kind == "error":
                    self.progress_stage_var.set("准备失败")
                    self.file_progress.stop()
                    self.status_var.set(event[1])
                    messagebox.showerror(event[1], event[2], parent=self.root)
        except queue.Empty:
            pass
        self._update_runtime_heartbeat()
        if self.root.winfo_exists():
            self.root.after(100, self._poll)

    def _finish_close(self):
        release_all_inputs()
        worker_alive = bool(
            (self.worker and self.worker.is_alive()) or
            (self._runtime_worker and self._runtime_worker.is_alive()) or
            (self._runtime_tune_thread and self._runtime_tune_thread.is_alive()))
        if worker_alive:
            try:
                self.root.after(SAFETY_CONFIG.close_poll_ms, self._finish_close)
            except tk.TclError:
                pass
            return
        if self.hook:
            self.hook.close()
            self.hook = None
        if self.capture is not None:
            try:
                self.capture.close()
            except (OSError, RuntimeError):
                pass
            self.capture = None
        try:
            if self.root.winfo_exists():
                self.root.destroy()
        except tk.TclError:
            pass

    def _close(self):
        if self._close_requested:
            return
        self._close_requested = True
        self.stop_event.set()
        self._terminate_runtime_process()
        if self._selection_scan_cancel is not None:
            self._selection_scan_cancel.set()
        if self.hook:
            self.hook.close()
        release_all_inputs()
        try:
            self.root.withdraw()
        except tk.TclError:
            pass
        # Do not destroy Tk while the non-daemon AI worker is still unwinding.
        # The worker releases all input and closes SQLite in its own finally block.
        self._finish_close()

def main():
    if os.name != "nt" or sys.maxsize <= 2 ** 32:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "本程序仅支持 64 位 Windows 11。")
        root.destroy()
        return
    if not ((3, 10) <= sys.version_info[:2] <= (3, 13)):
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "为保证固定依赖组合，本程序需要 64 位 Python 3.10–3.13。")
        root.destroy()
        return
    set_dpi_awareness()
    configure_winapi()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    ValueAI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
