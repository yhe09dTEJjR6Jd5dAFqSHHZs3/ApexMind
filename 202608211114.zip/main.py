import ctypes
import hashlib
import importlib
import json
import math
import os
import platform
import queue
import random
import re
import shutil
import sqlite3
import subprocess
import sys
import threading
import time
import unicodedata
from ctypes import wintypes
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional
import base64
import urllib.error
import urllib.request
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

APP_NAME = "屏幕数值 AI"
DATA_DIR_NAME = "屏幕数值AI数据"
RAPIDOCR_VERSION = "3.9.2"
RUNTIME_SCHEMA = 9
AUTOTUNE_SCHEMA = 6
MSS_SPEC = "mss>=10.2,<12"
DXCAM_SPEC = "dxcam==0.3.0"
COMTYPES_SPEC = "comtypes>=1.4,<2"
VK_ESCAPE = 0x1B
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WH_KEYBOARD_LL = 13
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_SCANCODE = 0x0008
MAPVK_VK_TO_VSC = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_XDOWN = 0x0080
MOUSEEVENTF_XUP = 0x0100
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x1000
XBUTTON1 = 0x0001
XBUTTON2 = 0x0002
WHEEL_DELTA = 120
SM_REMOTESESSION = 0x1000

@dataclass(frozen=True)
class LearningConfig:
    discount_gamma: float = 0.93
    eligibility_lambda: float = 0.82
    exploration_initial: float = 0.24
    exploration_min: float = 0.03
    exploration_decay_steps: float = 1450.0
    stagnation_medium: int = 15
    stagnation_high: int = 32
    stagnation_extreme: int = 54
    exploration_medium: float = 0.20
    exploration_high: float = 0.36
    exploration_extreme: float = 0.54
    model_discount: float = 0.36
    beam_depth: int = 4
    beam_width: int = 8
    transition_branches: int = 5
    uncertainty_penalty: float = 0.055
    semantic_refresh_steps: int = 5
    semantic_refresh_seconds: float = 2.8
    vlm_min_interval: float = 18.0

LEARNING_CONFIG = LearningConfig()

NUMBER_ROLES = (
    "TARGET", "RESOURCE", "COST", "INCOME", "RATE", "LEVEL", "MULTIPLIER",
    "TIME", "HEALTH", "CAPACITY", "PROGRESS", "COUNT", "UNKNOWN",
)

@dataclass
class NumberEntity:
    value: float
    text: str
    bbox: tuple
    confidence: float
    label: str = ""
    unit: str = ""
    role: str = "UNKNOWN"
    direction: str = "unknown"
    is_target: bool = False
    source: str = "ocr"

    def snapshot(self):
        return {
            "value": float(self.value), "text": str(self.text), "bbox": tuple(self.bbox),
            "confidence": float(self.confidence), "label": str(self.label),
            "unit": str(self.unit), "role": str(self.role),
            "direction": str(self.direction), "is_target": bool(self.is_target),
        }

@dataclass
class ActionSemantic:
    type: str = "unknown"
    target: str = ""
    cost_resource: str = ""
    cost: Optional[float] = None
    expected_effect: str = "unknown"
    risk: float = 0.25
    confidence: float = 0.0

    def snapshot(self):
        return {
            "type": self.type, "target": self.target, "cost_resource": self.cost_resource,
            "cost": self.cost, "expected_effect": self.expected_effect,
            "risk": float(self.risk), "confidence": float(self.confidence),
        }

@dataclass
class ActionEffect:
    action: str
    signals: dict = field(default_factory=dict)
    deltas: dict = field(default_factory=dict)
    delay: float = 0.0
    reliability: float = 0.0

if os.name == "nt":
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
else:
    user32 = None
    kernel32 = None

class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]

class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

ULONG_PTR = wintypes.WPARAM

class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]

class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD)]

class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]

def set_dpi_awareness():
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass

def configure_winapi():
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p,
                                         wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT,
                                          wintypes.WPARAM, wintypes.LPARAM]
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
    user32.MapVirtualKeyW.restype = wintypes.UINT
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                   wintypes.DWORD, ULONG_PTR]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.GetClientRect.restype = wintypes.BOOL
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.ClientToScreen.restype = wintypes.BOOL
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsWindow.restype = wintypes.BOOL
    user32.IsIconic.argtypes = [wintypes.HWND]
    user32.IsIconic.restype = wintypes.BOOL
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetForegroundWindow.restype = wintypes.BOOL
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.ShowWindow.restype = wintypes.BOOL
    user32.IsWindowEnabled.argtypes = [wintypes.HWND]
    user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.EnumWindows.restype = wintypes.BOOL
    user32.EnumChildWindows.restype = wintypes.BOOL
    user32.GetForegroundWindow.argtypes = []
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    if hasattr(kernel32, "QueryFullProcessImageNameW"):
        kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                        wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

def screen_dpi():

    if os.name != "nt" or user32 is None:
        return 96
    try:
        if hasattr(user32, "GetDpiForSystem"):
            value = int(user32.GetDpiForSystem())
            if 72 <= value <= 768:
                return value
    except Exception:
        pass
    return 96

def d_drive_path(value):
    try:
        resolved = os.path.realpath(os.path.abspath(str(value)))
        return resolved if os.path.splitdrive(resolved)[0].upper() == "D:" else None
    except Exception:
        return None

GIB = 1024 ** 3

_CPU_SAMPLE_LOCK = threading.Lock()
_CPU_SAMPLE = None

def _filetime_value(value):
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)

def _cpu_load():

    global _CPU_SAMPLE
    if os.name != "nt":
        return None
    try:
        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
            return None
        current = (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
        with _CPU_SAMPLE_LOCK:
            previous, _CPU_SAMPLE = _CPU_SAMPLE, current
        if previous is None:
            return None
        idle_delta = max(0, current[0] - previous[0])
        total_delta = max(1, current[1] - previous[1] + current[2] - previous[2])
        return max(0.0, min(1.0, 1.0 - idle_delta / total_delta))
    except Exception:
        return None

class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

def _total_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullTotalPhys)
    except Exception:
        pass
    return 8 * GIB

def _available_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullAvailPhys)
    except Exception:
        pass
    return 4 * GIB

class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]

def _power_state():

    if os.name != "nt":
        return False, None
    try:
        status = SYSTEM_POWER_STATUS()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            on_battery = int(status.ACLineStatus) == 0
            percent = int(status.BatteryLifePercent)
            if percent > 100:
                percent = None
            return on_battery, percent
    except Exception:
        pass
    return False, None

def _process_cpu_limit():

    logical = max(1, os.cpu_count() or 1)
    if os.name != "nt":
        return logical
    try:
        process = ctypes.windll.kernel32.GetCurrentProcess()
        process_mask = ctypes.c_size_t()
        system_mask = ctypes.c_size_t()
        if ctypes.windll.kernel32.GetProcessAffinityMask(
                process, ctypes.byref(process_mask), ctypes.byref(system_mask)):
            usable = int(process_mask.value).bit_count()
            if usable > 0:
                logical = min(logical, usable)
    except Exception:
        pass
    return max(1, logical)

def _cpu_topology():

    logical = max(1, os.cpu_count() or 1)
    if os.name != "nt":
        return max(1, logical // 2), logical, 0
    script = (
        "Get-CimInstance Win32_Processor | "
        "Select-Object NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed | "
        "ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        data = json.loads(run.stdout.strip()) if run.returncode == 0 and run.stdout.strip() else []
        if isinstance(data, dict):
            data = [data]
        physical = 0
        reported_logical = 0
        clock = 0
        for item in data if isinstance(data, list) else []:
            try:
                physical += max(0, int(item.get("NumberOfCores") or 0))
                reported_logical += max(0, int(item.get("NumberOfLogicalProcessors") or 0))
                clock = max(clock, int(item.get("MaxClockSpeed") or 0))
            except Exception:
                continue
        return max(1, physical or logical // 2), max(logical, reported_logical), max(0, clock)
    except Exception:
        return max(1, logical // 2), logical, 0

def _gpu_info():
    if os.name != "nt":
        return [], 0
    script = (
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM | ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        if run.returncode or not run.stdout.strip():
            return [], 0
        data = json.loads(run.stdout.strip())
        if isinstance(data, dict):
            data = [data]
        names, vram = [], 0
        for item in data if isinstance(data, list) else []:
            name = str(item.get("Name") or "").strip()
            lower = name.lower()
            if not name or "microsoft basic" in lower or "remote display" in lower:
                continue
            names.append(name)
            try:
                vram = max(vram, int(item.get("AdapterRAM") or 0))
            except Exception:
                pass
        return names, vram
    except Exception:
        return [], 0

def _fmt_gib(value):
    return f"{value / GIB:.1f} GB"

class HardwareProfile:
    def __init__(self, storage):
        self.storage = Path(storage)
        self.tuning_path = self.storage / "硬件自适应.json"
        self.architecture = (platform.machine() or
                             os.environ.get("PROCESSOR_ARCHITECTURE") or "unknown").lower()
        self.physical_cores, self.logical_cpus, self.max_clock_mhz = _cpu_topology()
        self.process_cpus = _process_cpu_limit()
        self.logical_cpus = max(1, min(self.logical_cpus, self.process_cpus))
        self.physical_cores = max(1, min(self.physical_cores, self.logical_cpus))
        self.ram = _total_memory()
        self.on_battery, self.battery_percent = _power_state()
        try:
            self.disk_free = shutil.disk_usage(storage).free
        except Exception:
            self.disk_free = 8 * GIB
        self.gpu_names, self.gpu_vram = _gpu_info()
        self.has_gpu = bool(self.gpu_names)
        gpu_text = " ".join(self.gpu_names).lower()
        self.gpu_vendor = ("nvidia" if "nvidia" in gpu_text else
                           "amd" if any(x in gpu_text for x in ("amd", "radeon")) else
                           "intel" if "intel" in gpu_text else "other")
        self.cpu_text = (os.environ.get("PROCESSOR_IDENTIFIER") or "").lower()
        try:
            self.virtual_left = int(user32.GetSystemMetrics(76))
            self.virtual_top = int(user32.GetSystemMetrics(77))
            self.screen_w = max(1, int(user32.GetSystemMetrics(78)))
            self.screen_h = max(1, int(user32.GetSystemMetrics(79)))
            self.monitor_count = max(1, int(user32.GetSystemMetrics(80)))
            self.remote_session = bool(user32.GetSystemMetrics(SM_REMOTESESSION))
        except Exception:
            self.virtual_left, self.virtual_top = 0, 0
            self.screen_w, self.screen_h, self.monitor_count = 1920, 1080, 1
            self.remote_session = False
        self.dxcam_eligible = (
            self.architecture in {"amd64", "x86_64", "x64"}
            and self.monitor_count == 1 and self.virtual_left == 0 and self.virtual_top == 0
            and not self.remote_session and (3, 10) <= sys.version_info[:2] <= (3, 14)
        )
        screen_load = self.screen_w * self.screen_h

        score = 0
        score += 2 if self.logical_cpus >= 12 and self.physical_cores >= 6 else (1 if self.logical_cpus >= 8 else 0)
        score += 1 if self.physical_cores >= 8 else 0
        if self.max_clock_mhz >= 3600 and self.physical_cores >= 6:
            score += 1
        elif 0 < self.max_clock_mhz < 1800:
            score -= 1
        score += 2 if self.ram >= 24 * GIB else (1 if self.ram >= 12 * GIB else 0)
        if self.on_battery:
            score -= 1
        score += 1 if self.disk_free >= 10 * GIB else 0
        score += 1 if self.has_gpu else 0
        if screen_load >= 28_000_000:
            score -= 2
        elif screen_load >= 15_000_000:
            score -= 1
        if self.ram < 6 * GIB or self.logical_cpus <= 2 or self.disk_free < 2 * GIB:
            score = -2
        if score >= 5:
            self.tier = "high"
        elif score <= 0:
            self.tier = "low"
        else:
            self.tier = "balanced"

        self.want_dml = (self.has_gpu and not self.remote_session and self.ram >= 8 * GIB
                         and self.disk_free >= 2 * GIB)
        self.backend = "dml?" if self.want_dml else "cpu"
        self.capture_backend = "mss"

        if self.tier == "high":
            self.ocr_threads = min(12, max(3, min(self.logical_cpus, self.physical_cores + 2)))
            self.settle = 0.24
            self.state_every = 1
            self.candidate_refresh = 8
            self.ocr_variants = 11
            self.verify_reads = 2
            self.visual_shape = (22, 13)
            self.save_interval = 7
            self.rec_model = "medium"
            self.det_model = "small"
            self.ensemble = self.ram >= 12 * GIB and self.disk_free >= 4 * GIB
            self.min_ocr_variants = 4
            self.max_ocr_variants = 16
            self.latency_target = 0.42
            self.capture_recheck_interval = 72.0
        elif self.tier == "low":
            self.ocr_threads = min(2, max(1, self.physical_cores))
            self.settle = 0.55
            self.state_every = 4
            self.candidate_refresh = 26
            self.ocr_variants = 5
            self.verify_reads = 0
            self.visual_shape = (11, 7)
            self.save_interval = 22
            self.rec_model = "tiny" if self.ram < 8 * GIB else "small"
            self.det_model = "tiny"
            self.ensemble = False
            self.min_ocr_variants = 2
            self.max_ocr_variants = 7
            self.latency_target = 0.82
            self.capture_recheck_interval = 150.0
        else:
            self.ocr_threads = min(8, max(2, min(self.logical_cpus, self.physical_cores + 1)))
            self.settle = 0.34
            self.state_every = 2
            self.candidate_refresh = 14
            self.ocr_variants = 8
            self.verify_reads = 1
            self.visual_shape = (16, 10)
            self.save_interval = 11
            self.rec_model = "small"
            self.det_model = "small"
            self.ensemble = self.ram >= 10 * GIB and self.disk_free >= 4 * GIB
            self.min_ocr_variants = 3
            self.max_ocr_variants = 13
            self.latency_target = 0.58
            self.capture_recheck_interval = 105.0

        self.nominal_state_every = self.state_every
        self.nominal_verify_reads = self.verify_reads

        if self.tier == "high":
            self.control_text_scan = True
            self.control_scan_side = 1440
            self.uncertain_burst_frames = 3
        elif self.tier == "balanced":
            self.control_text_scan = True
            self.control_scan_side = 1080
            self.uncertain_burst_frames = 2
        else:

            self.control_text_scan = self.ram >= 6 * GIB and self.logical_cpus >= 2
            self.control_scan_side = 620
            self.uncertain_burst_frames = 2
        self.nominal_candidate_refresh = self.candidate_refresh
        self.nominal_ocr_variants = self.ocr_variants
        self.nominal_settle = self.settle
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        self.live_adjusted_at = 0.0
        self.cpu_load_ema = 0.45
        self.resource_pressure_ema = 0.35
        self.resource_recovery = 0
        self.cached_threads = None
        self.cached_rec_model = None
        self.preferred_capture = None
        self.dml_tested_at = 0.0
        self.model_tested_at = 0.0
        self._last_persist = 0.0
        self.screen_dpi = 96
        self.screen_scale = 1.0
        self.semantic_emergency_scan = self.tier != "low"
        identity = "|".join((self.architecture, self.cpu_text,
                             str(self.physical_cores), str(self.logical_cpus),
                             ";".join(self.gpu_names), str(self.monitor_count),
                             f"ram{self.ram // GIB}", f"{self.screen_w}x{self.screen_h}",
                             f"py{sys.version_info.major}.{sys.version_info.minor}"))
        self.profile_key = hashlib.sha256(identity.encode("utf-8", "replace")).hexdigest()[:20]
        self._load_tuning()

        self.nominal_ocr_variants = self.ocr_variants

    def _load_tuning(self):

        try:
            data = json.loads(self.tuning_path.read_text(encoding="utf-8"))
            if (int(data.get("schema", 0)) != AUTOTUNE_SCHEMA or
                    data.get("profile") != self.profile_key):
                return
            age = max(0.0, time.time() - float(data.get("saved_at", 0.0)))
            if age > 45 * 86400:
                return
            threads = int(data.get("ocr_threads", 0))
            if 1 <= threads <= self.logical_cpus:
                self.cached_threads = threads
                self.ocr_threads = threads
            capture = str(data.get("capture", "")).lower()
            if capture in {"dxcam", "mss", "pillow"}:
                self.preferred_capture = capture
            variants = int(data.get("ocr_variants", 0))
            if variants:
                self.ocr_variants = max(self.min_ocr_variants,
                                        min(self.max_ocr_variants, variants))
            cached_model = str(data.get("rec_model", "")).lower()
            if cached_model in {"tiny", "small", "medium"}:
                if cached_model != "medium" or self.ram >= 12 * GIB:
                    self.cached_rec_model = cached_model
                    self.rec_model = cached_model
            self.model_tested_at = max(0.0, float(data.get("model_tested_at", 0.0)))
            self.dml_tested_at = max(0.0, float(data.get("dml_tested_at", 0.0)))
            dml_age = max(0.0, time.time() - self.dml_tested_at) if self.dml_tested_at else float("inf")

            if data.get("backend") == "cpu" and dml_age < 14 * 86400:
                self.want_dml = False
                self.backend = "cpu"
        except Exception:
            pass

    def save_tuning(self, force=False):
        now = time.monotonic()
        if not force and now - self._last_persist < 30.0:
            return
        self._last_persist = now
        data = {
            "schema": AUTOTUNE_SCHEMA,
            "profile": self.profile_key,
            "saved_at": time.time(),
            "ocr_threads": int(self.ocr_threads),
            "ocr_variants": int(self.ocr_variants),
            "rec_model": str(self.rec_model),
            "det_model": str(self.det_model),
            "model_tested_at": float(self.model_tested_at),
            "capture": str(self.capture_backend or "mss"),
            "backend": str(self.backend if self.backend in {"cpu", "dml"} else "cpu"),
            "dml_tested_at": float(self.dml_tested_at),
        }
        try:
            temp = self.tuning_path.with_suffix(".tmp")
            temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                            encoding="utf-8")
            os.replace(temp, self.tuning_path)
        except OSError:
            pass

    @property
    def tag(self):
        gpu = self.gpu_vendor if self.want_dml else "cpu"
        return f"{gpu}-{self.tier}-{self.rec_model}"

    def calibrate_runtime(self, ocr_latency, capture_latency):

        self.ocr_latency = max(0.001, float(ocr_latency or 0.25))
        self.capture_latency = max(0.0005, float(capture_latency or 0.02))
        avail = _available_memory()
        pressure = avail / max(1.0, float(self.ram))
        self.on_battery, self.battery_percent = _power_state()
        if self.on_battery:
            self.ocr_variants = min(self.ocr_variants,
                                    min(self.max_ocr_variants, self.min_ocr_variants + 4))
            self.verify_reads = min(self.verify_reads, 1)
        if self.ocr_latency <= 0.16 and self.capture_latency <= 0.035 and pressure >= 0.18 and not self.on_battery:
            self.runtime_class = "极速"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 4))
            self.verify_reads = max(self.verify_reads, 2)
            self.candidate_refresh = min(self.candidate_refresh, 8)
            self.state_every = 1
            self.settle = min(self.settle, 0.20)
        elif self.ocr_latency <= 0.34 and pressure >= 0.12:
            self.runtime_class = "快速"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 2))
            self.verify_reads = max(self.verify_reads, 1)
            self.candidate_refresh = min(self.candidate_refresh, 13)
            self.settle = min(self.settle, 0.30)
        elif self.ocr_latency >= 0.85 or pressure < 0.08:
            self.runtime_class = "节能"
            self.ocr_variants = max(self.min_ocr_variants, min(self.ocr_variants, self.min_ocr_variants + 1))
            self.verify_reads = min(self.verify_reads, 1)
            self.candidate_refresh = max(self.candidate_refresh, 20)
            self.state_every = max(self.state_every, 3)
            self.settle = max(self.settle, min(0.62, self.ocr_latency * 0.46))
        else:
            self.runtime_class = "均衡"

        self.latency_target = max(0.24, min(1.15, self.ocr_latency * 1.75 + self.capture_latency * 1.8))

        if self.on_battery or pressure < 0.09 or self.ocr_latency > 0.72:
            self.control_text_scan = False
        elif self.runtime_class in {"极速", "快速"} and self.tier != "low":
            self.control_text_scan = True
            self.control_scan_side = 1500 if self.runtime_class == "极速" else 1180
        if self.runtime_class == "极速":
            self.uncertain_burst_frames = 3
        elif self.runtime_class == "节能":
            self.uncertain_burst_frames = 2
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        if not self.on_battery and pressure >= 0.10:
            self.nominal_state_every = self.state_every
            self.nominal_verify_reads = self.verify_reads
            self.nominal_candidate_refresh = self.candidate_refresh
            self.nominal_ocr_variants = self.ocr_variants
            self.nominal_settle = self.settle
        self.save_tuning(force=True)

    def live_tune(self, ocr_latency, capture_latency, confidence, fail_rate=0.0):

        now = time.monotonic()
        if now - self.live_adjusted_at < 2.5:
            return False
        self.live_adjusted_at = now
        ocr_latency = max(0.002, float(ocr_latency or self.ocr_latency if hasattr(self, "ocr_latency") else 0.25))
        capture_latency = max(0.0005, float(capture_latency or self.capture_latency if hasattr(self, "capture_latency") else 0.02))
        confidence = max(0.0, min(1.0, float(confidence)))
        fail_rate = max(0.0, min(1.0, float(fail_rate)))
        pressure = _available_memory() / max(1.0, float(self.ram))
        measured_cpu = _cpu_load()
        if measured_cpu is not None:
            self.cpu_load_ema = self.cpu_load_ema * 0.72 + measured_cpu * 0.28
        self.on_battery, self.battery_percent = _power_state()
        changed = False

        memory_stress = max(0.0, min(1.0, (0.16 - pressure) / 0.12))
        cpu_stress = max(0.0, min(1.0, (self.cpu_load_ema - 0.68) / 0.30))
        battery_stress = 0.52 if self.on_battery else 0.0
        instantaneous_stress = max(memory_stress, cpu_stress, battery_stress)
        self.resource_pressure_ema = (self.resource_pressure_ema * 0.76 +
                                      instantaneous_stress * 0.24)
        if self.resource_pressure_ema < 0.30 and not self.on_battery:
            self.resource_recovery = min(12, self.resource_recovery + 1)
        else:
            self.resource_recovery = 0

        measured_target = max(0.22, min(1.25, ocr_latency * 1.70 + capture_latency * 1.7))
        if self.on_battery:
            measured_target = max(measured_target, 0.46)
            self.verify_reads = min(self.verify_reads, 1)
            cap = min(self.max_ocr_variants, self.min_ocr_variants + 4)
            if self.ocr_variants > cap:
                self.ocr_variants -= 1
                changed = True
        self.latency_target = self.latency_target * 0.82 + measured_target * 0.18

        if pressure < 0.065 or self.cpu_load_ema > 0.94:
            new_variants = max(self.min_ocr_variants,
                               min(self.ocr_variants, self.min_ocr_variants + 1))
            if new_variants != self.ocr_variants:
                self.ocr_variants = new_variants
                changed = True
            self.candidate_refresh = max(self.candidate_refresh, 22)
            self.state_every = max(self.state_every, 3)
            self.verify_reads = min(self.verify_reads, 1)
        elif self.cpu_load_ema > 0.84:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.state_every = min(5, self.state_every + 1)
        elif fail_rate >= 0.20 or confidence < 0.62:
            if ocr_latency < self.latency_target * 1.45 and self.ocr_variants < self.max_ocr_variants:
                self.ocr_variants += 1
                changed = True
            if ocr_latency < 0.58 and pressure > 0.12:
                self.verify_reads = max(self.verify_reads, 1)
            self.candidate_refresh = max(5, self.candidate_refresh - 1)
        elif ocr_latency > self.latency_target * 1.65:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.state_every = min(5, self.state_every + 1)
        elif confidence > 0.90 and fail_rate < 0.04 and pressure > 0.14:
            if ocr_latency < self.latency_target * 0.72:
                self.candidate_refresh = max(6, self.candidate_refresh - 1)
                if self.cpu_load_ema < 0.70:
                    self.state_every = max(self.nominal_state_every, self.state_every - 1)
                    if not self.on_battery:
                        self.verify_reads = max(self.verify_reads,
                                                self.nominal_verify_reads)
                if self.ocr_variants < self.max_ocr_variants and confidence < 0.965:
                    self.ocr_variants += 1
                    changed = True

        if self.resource_recovery >= 3:
            if self.candidate_refresh > self.nominal_candidate_refresh:
                self.candidate_refresh -= 1
                changed = True
            elif self.state_every > self.nominal_state_every:
                self.state_every -= 1
                changed = True
            elif self.verify_reads < self.nominal_verify_reads and confidence < 0.94:
                self.verify_reads += 1
                changed = True
            elif (self.ocr_variants < self.nominal_ocr_variants and
                  self.cpu_load_ema < 0.70):
                self.ocr_variants += 1
                changed = True
            elif self.settle > self.nominal_settle:
                self.settle = max(self.nominal_settle, self.settle - 0.015)
                changed = True
            if changed:
                self.resource_recovery = max(0, self.resource_recovery - 2)
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))

        perception_ok = (self.tier != "low" and not self.on_battery and pressure >= 0.105 and
                         self.cpu_load_ema < 0.84 and ocr_latency < 0.70)
        if perception_ok and (self.resource_recovery >= 2 or confidence < 0.88):
            if not self.control_text_scan:
                self.control_text_scan = True
                changed = True
            desired_side = 1460 if self.cpu_load_ema < 0.62 and ocr_latency < 0.30 else 1120
            self.control_scan_side = max(900, min(1500, desired_side))
        elif (self.on_battery or pressure < 0.08 or self.cpu_load_ema > 0.91 or
              ocr_latency > 0.86):
            if self.control_text_scan:
                self.control_text_scan = False
                changed = True
        self.uncertain_burst_frames = (3 if perception_ok and ocr_latency < 0.42 and
                                       self.cpu_load_ema < 0.78 else 2)
        if changed:
            self.save_tuning()
        return changed

    def calibrate_selection(self, rect, screen=None):

        try:
            x1, y1, x2, y2 = (float(v) for v in rect)
            roi_w = max(1.0, x2 - x1)
            roi_h = max(1.0, y2 - y1)
        except Exception:
            return
        self.selection_roi_shape = (int(round(roi_w)), int(round(roi_h)))
        self.screen_dpi = screen_dpi()
        self.screen_scale = max(0.75, min(4.0, self.screen_dpi / 96.0))
        if self.screen_scale >= 1.75:
            self.control_scan_side = min(1600, max(self.control_scan_side, 1180))
        tiny = roi_h <= 24 or min(roi_w, roi_h) <= 16
        small = roi_h <= 42 or min(roi_w, roi_h) <= 26
        very_wide = roi_w / max(1.0, roi_h) >= 16.0
        pressure = _available_memory() / max(1.0, float(self.ram))
        healthy = (pressure >= 0.10 and getattr(self, "cpu_load_ema", 0.45) < 0.88
                   and not self.on_battery)
        if tiny and healthy:
            self.ocr_variants = min(self.max_ocr_variants,
                                    max(self.ocr_variants, self.min_ocr_variants + 5))
            self.verify_reads = max(self.verify_reads, 2)
            self.uncertain_burst_frames = 3
            self.latency_target = max(self.latency_target, 0.46)
        elif small and healthy:
            self.ocr_variants = min(self.max_ocr_variants,
                                    max(self.ocr_variants, self.min_ocr_variants + 3))
            self.verify_reads = max(self.verify_reads, 1)
            self.uncertain_burst_frames = max(2, self.uncertain_burst_frames)
        elif roi_h >= 120 and roi_w >= 460 and self.ocr_variants > self.min_ocr_variants + 2:
            self.ocr_variants -= 1
        if very_wide and healthy:
            self.ocr_variants = min(self.max_ocr_variants, self.ocr_variants + 1)
        if screen:
            try:
                sw, sh = max(1.0, screen[2] - screen[0]), max(1.0, screen[3] - screen[1])
                relative_area = roi_w * roi_h / max(1.0, sw * sh)
                if relative_area < 0.00022 and healthy:
                    self.verify_reads = max(self.verify_reads, 2)
            except Exception:
                pass
        self.nominal_ocr_variants = max(self.nominal_ocr_variants, self.ocr_variants)
        self.nominal_verify_reads = max(self.nominal_verify_reads, self.verify_reads)
        self.save_tuning()

    def summary(self):
        gpu = self.gpu_names[0] if self.gpu_names else "无可用 GPU"
        if len(gpu) > 34:
            gpu = gpu[:33] + "…"
        mode = ("GPU/DirectML" if self.backend == "dml" else
                "CPU" if self.backend == "cpu" else "自动测速 GPU/CPU")
        model = {"tiny": "PP-OCRv6 Tiny", "small": "PP-OCRv6 Small",
                 "medium": "PP-OCRv6 Medium"}.get(self.rec_model, self.rec_model)
        capture = (self.capture_backend or "auto").upper()
        measured = ""
        if hasattr(self, "ocr_latency"):
            measured = (f" · 实测OCR {self.ocr_latency * 1000:.0f}ms"
                        f"/{getattr(self, 'runtime_class', '自适应')}")
        if self.on_battery:
            power = f" · 电池{self.battery_percent}%" if self.battery_percent is not None else " · 电池"
        else:
            power = ""
        core_text = f"{self.physical_cores}核/{self.logical_cpus}线程 CPU"
        session = " · 远程会话" if self.remote_session else ""
        dpi = f" · 屏幕DPI {self.screen_dpi}" if getattr(self, "screen_dpi", 96) != 96 else ""
        return (f"{core_text} · 内存 {_fmt_gib(self.ram)} · "
                f"D盘可用 {_fmt_gib(self.disk_free)} · {gpu}{power}{session} · {mode} · "
                f"OCR {self.ocr_threads}线程 · {model} · 截图 {capture}{dpi}{measured}")

class ScreenCapture:

    def __init__(self, mss_module, image_grab, image_module, dxcam_module=None,
                 preferred=None):
        self.mss_module = mss_module
        self.dxcam_module = dxcam_module
        self.ImageGrab = image_grab
        self.Image = image_module
        self.local = threading.local()
        available = {"pillow"}
        if mss_module is not None:
            available.add("mss")
        if dxcam_module is not None:
            available.add("dxcam")
        default = "mss" if mss_module is not None else "pillow"
        self.backend = preferred if preferred in available else default
        self.preferred = self.backend
        self.latency = 0.02
        self.benchmark_latency = 0.02
        self.last_benchmark = 0.0
        self.failures = {name: 0 for name in available}
        self.cooldown_until = {name: 0.0 for name in available}

    def _instance(self):
        if self.mss_module is None:
            return None
        obj = getattr(self.local, "mss", None)
        if obj is None:
            obj = self.mss_module.MSS(with_cursor=False)
            self.local.mss = obj
        return obj

    def _dx_instance(self):
        if self.dxcam_module is None:
            return None
        obj = getattr(self.local, "dxcam", None)
        if obj is None:
            try:
                obj = self.dxcam_module.create(output_color="RGB", processor_backend="cv2")
            except TypeError:
                obj = self.dxcam_module.create(output_color="RGB")
            self.local.dxcam = obj
        return obj

    def _grab_dxcam(self, rect):
        obj = self._dx_instance()
        if obj is None:
            raise RuntimeError("DXCam unavailable")
        frame = None
        try:
            frame = obj.grab(region=rect, new_frame_only=False)
        except TypeError:
            frame = obj.grab(region=rect)
        if frame is None:
            time.sleep(0.004)
            try:
                frame = obj.grab(region=rect, new_frame_only=False)
            except TypeError:
                frame = obj.grab(region=rect)
        if frame is None or getattr(frame, "size", 0) == 0:
            raise RuntimeError("DXCam capture failed")
        return self.Image.fromarray(frame, mode="RGB")

    def _grab_mss(self, rect):
        obj = self._instance()
        if obj is None:
            raise RuntimeError("MSS unavailable")
        shot = obj.grab(rect)
        try:
            return shot.to_pil("RGB")
        except Exception:
            return self.Image.frombytes("RGB", shot.size, shot.rgb)

    def _grab_pillow(self, rect):
        try:
            return self.ImageGrab.grab(bbox=rect, all_screens=True)
        except TypeError:
            return self.ImageGrab.grab(bbox=rect)

    def _grab_backend(self, name, rect):
        if name == "dxcam":
            return self._grab_dxcam(rect)
        if name == "mss":
            return self._grab_mss(rect)
        return self._grab_pillow(rect)

    def _record_failure(self, name):
        count = min(7, int(self.failures.get(name, 0)) + 1)
        self.failures[name] = count

        self.cooldown_until[name] = time.monotonic() + min(45.0, 0.7 * (2 ** count))

    def _record_success(self, name):
        self.failures[name] = max(0, int(self.failures.get(name, 0)) - 1)
        self.cooldown_until[name] = 0.0

    def benchmark(self, rect=None):

        if rect is None:
            left = int(user32.GetSystemMetrics(76)) if user32 else 0
            top = int(user32.GetSystemMetrics(77)) if user32 else 0
            width = max(320, int(user32.GetSystemMetrics(78))) if user32 else 1920
            height = max(240, int(user32.GetSystemMetrics(79))) if user32 else 1080
            w, h = min(640, width), min(360, height)
            x = left + max(0, (width - w) // 2)
            y = top + max(0, (height - h) // 2)
            rect = (x, y, x + w, y + h)
        rect = tuple(int(round(v)) for v in rect)
        timings = {}
        for name in ("dxcam", "mss", "pillow"):
            if name == "dxcam" and self.dxcam_module is None:
                continue
            if name == "mss" and self.mss_module is None:
                continue
            samples = []
            try:
                self._grab_backend(name, rect)
                for _ in range(4):
                    t0 = time.perf_counter()
                    image = self._grab_backend(name, rect)
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("capture failed")
                    samples.append(time.perf_counter() - t0)
                samples.sort()
                timings[name] = (samples[1] + samples[2]) * 0.5 if len(samples) >= 4 else samples[len(samples) // 2]
                self._record_success(name)
            except Exception:
                self._record_failure(name)
                continue
        if timings:
            fastest = min(timings, key=timings.get)

            old = self.preferred if self.preferred in timings else fastest
            if timings.get(old, float("inf")) <= timings[fastest] * 1.08:
                fastest = old
            self.preferred = fastest
            self.backend = fastest
            self.latency = timings[fastest]
            self.benchmark_latency = timings[fastest]
        self.last_benchmark = time.monotonic()
        return self.backend

    def should_rebenchmark(self, interval=120.0):

        age = time.monotonic() - float(self.last_benchmark or 0.0)
        baseline = max(0.0005, float(self.benchmark_latency or self.latency or 0.02))
        degraded = self.latency > baseline * 2.25 and age > 18.0
        return degraded or age >= max(30.0, float(interval))

    def grab(self, rect):
        rect = tuple(int(round(v)) for v in rect)
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            raise ValueError("截图区域无效")
        started = time.perf_counter()
        order = [self.preferred] + [x for x in ("dxcam", "mss", "pillow") if x != self.preferred]
        last_error = None
        try:
            for name in order:
                if name == "dxcam" and self.dxcam_module is None:
                    continue
                if name == "mss" and self.mss_module is None:
                    continue
                if (name != self.preferred and
                        time.monotonic() < self.cooldown_until.get(name, 0.0)):
                    continue
                try:
                    image = self._grab_backend(name, rect)
                    if image.width != rect[2] - rect[0] or image.height != rect[3] - rect[1]:

                        expected_w, expected_h = rect[2] - rect[0], rect[3] - rect[1]
                        if image.width >= expected_w and image.height >= expected_h:
                            image = image.crop((0, 0, expected_w, expected_h))
                        else:
                            raise RuntimeError("截图后端返回了错误尺寸")
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("截图后端返回空画面")
                    self._record_success(name)
                    self.backend = name
                    self.preferred = name
                    return image
                except Exception as exc:
                    last_error = exc
                    self._record_failure(name)
            raise last_error or RuntimeError("没有可用的截图后端")
        finally:
            elapsed = max(0.0005, time.perf_counter() - started)
            self.latency = self.latency * 0.88 + elapsed * 0.12

class DFolderDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.current = Path("D:/")
        self.title("选择 D 盘文件夹")
        self.geometry("620x470")
        self.minsize(520, 380)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text="运行数据保存位置（仅限 D 盘）",
                  font=("Microsoft YaHei UI", 14, "bold")).grid(
                      row=0, column=0, sticky="w", padx=18, pady=(18, 8))
        self.path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.path_var, state="readonly").grid(
            row=1, column=0, sticky="ew", padx=18, pady=(0, 8))
        frame = ttk.Frame(self)
        frame.grid(row=2, column=0, sticky="nsew", padx=18)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.listbox = tk.Listbox(frame, font=("Microsoft YaHei UI", 11),
                                  activestyle="dotbox")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.listbox.bind("<Double-Button-1>", self._open_selected)
        self.listbox.bind("<Return>", self._open_selected)
        buttons = ttk.Frame(self)
        buttons.grid(row=3, column=0, sticky="ew", padx=18, pady=18)
        ttk.Button(buttons, text="上一级", command=self._up).pack(side="left")
        ttk.Button(buttons, text="新建文件夹", command=self._new_folder).pack(
            side="left", padx=8)
        ttk.Button(buttons, text="取消", command=self._cancel).pack(side="right")
        ttk.Button(buttons, text="选择当前文件夹", command=self._choose).pack(
            side="right", padx=8)
        if not Path("D:/").is_dir():
            self.after(50, self._no_drive)
        else:
            self._refresh()
        self.grab_set()
        self.focus_force()

    def _no_drive(self):
        messagebox.showerror(APP_NAME, "未检测到 D 盘。", parent=self)
        self._cancel()

    def _refresh(self):
        valid = d_drive_path(self.current)
        if not valid:
            self.current = Path("D:/")
        else:
            self.current = Path(valid)
        self.path_var.set(str(self.current))
        self.listbox.delete(0, "end")
        try:
            names = sorted((e.name for e in os.scandir(self.current)
                            if e.is_dir(follow_symlinks=False)), key=str.lower)
            for name in names:
                self.listbox.insert("end", name)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法读取该文件夹：\n{exc}", parent=self)

    def _open_selected(self, _event=None):
        selected = self.listbox.curselection()
        if not selected:
            return
        candidate = d_drive_path(self.current / self.listbox.get(selected[0]))
        if candidate and Path(candidate).is_dir():
            self.current = Path(candidate)
            self._refresh()

    def _up(self):
        parent = d_drive_path(self.current.parent)
        if parent:
            self.current = Path(parent)
            self._refresh()

    def _new_folder(self):
        name = simpledialog.askstring("新建文件夹", "文件夹名称：", parent=self)
        if not name:
            return
        name = name.strip()
        if (not name or name.endswith((" ", ".")) or
                any(ch in '<>:"/\\|?*' for ch in name)):
            messagebox.showerror(APP_NAME, "文件夹名称无效。", parent=self)
            return
        target = self.current / name
        if not d_drive_path(target):
            return
        try:
            target.mkdir()
            self.current = target
            self._refresh()
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法创建文件夹：\n{exc}", parent=self)

    def _choose(self):
        chosen = d_drive_path(self.current)
        if chosen:
            self.result = Path(chosen)
            self.grab_release()
            self.destroy()

    def _cancel(self):
        self.result = None
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()

class SelectionOverlay(tk.Toplevel):
    def __init__(self, parent, screenshot, candidates, screen, image_tk, callback):
        super().__init__(parent)
        self.callback = callback
        self.candidates = list(candidates)
        self.left, self.top, right, bottom = screen
        self.width, self.height = right - self.left, bottom - self.top
        self.hovered = None
        self.start = None
        self.manual_rect = None
        self.tooltip_bg = None
        self.tooltip_text = None
        self.visuals = []
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(bg="black", cursor="crosshair")
        self.geometry(f"{self.width}x{self.height}{self.left:+d}{self.top:+d}")
        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0,
                                cursor="crosshair", width=self.width, height=self.height)
        self.canvas.pack(fill="both", expand=True)
        self.photo = image_tk.PhotoImage(screenshot)
        self.canvas.create_image(0, 0, image=self.photo, anchor="nw")
        for index, candidate in enumerate(self.candidates):
            rect = candidate[0]
            x1 = max(0, int(math.floor(rect[0] - self.left - 5)))
            y1 = max(0, int(math.floor(rect[1] - self.top - 5)))
            x2 = min(self.width - 1, int(math.ceil(rect[2] - self.left + 5)))
            y2 = min(self.height - 1, int(math.ceil(rect[3] - self.top + 5)))
            outer = self.canvas.create_rectangle(
                x1, y1, x2, y2, outline="#00f5ff", width=7,
                tags=(f"number-{index}", "number"))
            inner = self.canvas.create_rectangle(
                x1, y1, x2, y2, outline="#dfff00", width=3,
                tags=(f"number-{index}", "number"))
            self.visuals.append(((x1, y1, x2, y2), outer, inner))
        banner_width = min(self.width - 30, 780)
        bx1 = (self.width - banner_width) // 2
        bx2 = bx1 + banner_width
        self.canvas.create_rectangle(bx1, 16, bx2, 88, fill="#090d14",
                                     stipple="gray50", outline="#00f5ff", width=2)
        count = len(self.candidates)
        title = (f"已找出 {count} 个数值 · 单击荧光框选择"
                 if count else "未自动识别到数值 · 请拖动框选")
        self.canvas.create_text(self.width // 2, 39, text=title, fill="#dfff00",
                                font=("Microsoft YaHei UI", 16, "bold"))
        self.canvas.create_text(
            self.width // 2, 68,
            text="悬停可查看识别结果；遗漏时可直接拖框；ESC 或右键取消",
            fill="white", font=("Microsoft YaHei UI", 10))
        self.canvas.tag_raise("number")
        self.canvas.bind("<Motion>", self._motion)
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.canvas.bind("<ButtonPress-3>", lambda _e: self._finish(None))
        self.bind("<Escape>", lambda _e: self._finish(None))
        try:
            self.grab_set()
        except tk.TclError:
            pass
        self.focus_force()

    def _hit(self, x, y):
        inside = []
        nearest = None
        nearest_distance = float("inf")
        for index, (rect, _outer, _inner) in enumerate(self.visuals):
            x1, y1, x2, y2 = rect
            area = max(1, (x2 - x1) * (y2 - y1))
            if x1 <= x <= x2 and y1 <= y <= y2:
                inside.append((area, index))
                continue
            dx = max(x1 - x, 0, x - x2)
            dy = max(y1 - y, 0, y - y2)
            distance = dx * dx + dy * dy
            if distance < nearest_distance:
                nearest_distance = distance
                nearest = index
        if inside:
            return min(inside)[1]
        return nearest if nearest_distance <= 14 * 14 else None

    def _set_hover(self, index, x, y):
        if index == self.hovered:
            if index is not None:
                self._show_tooltip(index, x, y)
            return
        if self.hovered is not None:
            _rect, outer, inner = self.visuals[self.hovered]
            self.canvas.itemconfigure(outer, outline="#00f5ff", width=7)
            self.canvas.itemconfigure(inner, outline="#dfff00", width=3)
        self.hovered = index
        if index is not None:
            _rect, outer, inner = self.visuals[index]
            self.canvas.itemconfigure(outer, outline="#ff00f5", width=9)
            self.canvas.itemconfigure(inner, outline="#ffffff", width=3)
            self.canvas.tag_raise(outer)
            self.canvas.tag_raise(inner)
            self._show_tooltip(index, x, y)
        else:
            self._hide_tooltip()

    def _show_tooltip(self, index, x, y):
        self._hide_tooltip()
        _rect, value, confidence, text = self.candidates[index]
        value_text = f"{value:g}" if value is not None else str(text)
        label = f"{value_text}   识别置信度 {confidence * 100:.0f}%"
        tx = min(self.width - 12, max(12, x + 14))
        ty = min(self.height - 16, max(106, y - 20))
        self.tooltip_text = self.canvas.create_text(
            tx, ty, text=label, anchor="sw", fill="#dfff00",
            font=("Microsoft YaHei UI", 11, "bold"))
        bbox = self.canvas.bbox(self.tooltip_text)
        if bbox:
            self.tooltip_bg = self.canvas.create_rectangle(
                bbox[0] - 8, bbox[1] - 5, bbox[2] + 8, bbox[3] + 5,
                fill="#090d14", outline="#00f5ff", width=2)
            self.canvas.tag_lower(self.tooltip_bg, self.tooltip_text)

    def _hide_tooltip(self):
        for item in (self.tooltip_bg, self.tooltip_text):
            if item:
                self.canvas.delete(item)
        self.tooltip_bg = None
        self.tooltip_text = None

    def _motion(self, event):
        if self.start is None:
            self._set_hover(self._hit(event.x, event.y), event.x, event.y)

    def _press(self, event):
        index = self._hit(event.x, event.y)
        if index is not None:
            self._finish(self.candidates[index])
            return
        self.start = (event.x, event.y)
        self._hide_tooltip()
        if self.manual_rect:
            self.canvas.delete(self.manual_rect)
        self.manual_rect = self.canvas.create_rectangle(
            event.x, event.y, event.x, event.y, outline="#ff00f5", width=5)

    def _drag(self, event):
        if self.start and self.manual_rect:
            self.canvas.coords(self.manual_rect, self.start[0], self.start[1],
                               event.x, event.y)

    def _release(self, event):
        if not self.start:
            return
        x1, y1 = self.start
        self.start = None
        x2, y2 = event.x, event.y
        if abs(x2 - x1) < 6 or abs(y2 - y1) < 6:
            if self.manual_rect:
                self.canvas.delete(self.manual_rect)
                self.manual_rect = None
            return
        rect = (min(x1, x2) + self.left, min(y1, y2) + self.top,
                max(x1, x2) + self.left, max(y1, y2) + self.top)
        self._finish((rect, None, 0.0, ""))

    def _finish(self, selection):
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.withdraw()
        self.update_idletasks()
        self.destroy()
        self.callback(selection)

def virtual_screen_rect():
    if os.name != "nt" or user32 is None:
        return (0, 0, 1920, 1080)
    left = int(user32.GetSystemMetrics(76))
    top = int(user32.GetSystemMetrics(77))
    width = max(1, int(user32.GetSystemMetrics(78)))
    height = max(1, int(user32.GetSystemMetrics(79)))
    return (left, top, left + width, top + height)

def window_title(hwnd):
    length = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, len(buf))
    return buf.value or ""

def window_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, len(buf))
    return buf.value

def _normalized_window_title(value):
    text = unicodedata.normalize("NFKC", str(value or "")).strip().lower()
    text = re.sub(r"\b(?:v(?:ersion)?\s*)?\d+(?:[._-]\d+){1,4}\b", "#", text)
    text = re.sub(r"\d+(?:[.,]\d+)?%?", "#", text)
    text = re.sub(r"\s+", " ", text)
    return text[:160]

def environment_identity_for_window(hwnd=0):
    if os.name != "nt" or user32 is None or kernel32 is None:
        return {"exe": "unknown", "exe_hash": "unknown", "class": "unknown",
                "title": "unknown", "hwnd": 0, "pid": 0}
    try:
        hwnd = int(hwnd or 0)
    except Exception:
        hwnd = 0
    cls = ""
    title = ""
    try:
        if hwnd and user32.IsWindow(wintypes.HWND(hwnd)):
            cls = unicodedata.normalize("NFKC", window_class(hwnd)).strip().lower()[:128]
            title = _normalized_window_title(window_title(hwnd))
        else:
            hwnd = 0
    except Exception:
        hwnd = 0
    pid = wintypes.DWORD(0)
    exe_path = ""
    if hwnd:
        try:
            user32.GetWindowThreadProcessId(wintypes.HWND(hwnd), ctypes.byref(pid))
            PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
            if handle:
                try:
                    size = wintypes.DWORD(32768)
                    buf = ctypes.create_unicode_buffer(size.value)
                    if (hasattr(kernel32, "QueryFullProcessImageNameW") and
                            kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size))):
                        exe_path = buf.value
                finally:
                    kernel32.CloseHandle(handle)
        except Exception:
            exe_path = ""
    exe_name = Path(exe_path).name.lower() if exe_path else "unknown"
    fingerprint_source = exe_path.lower() if exe_path else exe_name
    exe_hash = ""
    try:
        if exe_path and os.path.isfile(exe_path):
            stat = os.stat(exe_path)
            digest = hashlib.sha256()
            digest.update(str(stat.st_size).encode("ascii", "replace"))
            with open(exe_path, "rb") as handle:
                digest.update(handle.read(65536))
                if stat.st_size > 131072:
                    handle.seek(max(0, stat.st_size - 65536))
                    digest.update(handle.read(65536))
            exe_hash = digest.hexdigest()[:16]
    except Exception:
        exe_hash = ""
    if not exe_hash:
        exe_hash = hashlib.sha256(fingerprint_source.encode("utf-8", "replace")).hexdigest()[:16]
    return {"exe": exe_name or "unknown", "exe_hash": exe_hash,
            "class": cls or "unknown", "title": title or "unknown", "hwnd": hwnd,
            "pid": int(pid.value)}

def foreground_environment_identity():
    hwnd = 0
    if os.name == "nt" and user32 is not None:
        try:
            hwnd = int(user32.GetForegroundWindow() or 0)
        except Exception:
            hwnd = 0
    return environment_identity_for_window(hwnd)

def client_screen_rect(hwnd):
    if os.name != "nt" or user32 is None or not hwnd:
        return None
    try:
        hwnd = wintypes.HWND(int(hwnd))
        if not user32.IsWindow(hwnd) or user32.IsIconic(hwnd):
            return None
        rect = RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        p1, p2 = POINT(rect.left, rect.top), POINT(rect.right, rect.bottom)
        if not user32.ClientToScreen(hwnd, ctypes.byref(p1)):
            return None
        if not user32.ClientToScreen(hwnd, ctypes.byref(p2)):
            return None
        if p2.x - p1.x < 8 or p2.y - p1.y < 8:
            return None
        return (int(p1.x), int(p1.y), int(p2.x), int(p2.y))
    except Exception:
        return None

def top_level_window_at(x, y):
    if os.name != "nt" or user32 is None:
        return 0
    try:
        hwnd = int(user32.WindowFromPoint(POINT(int(x), int(y))) or 0)
        if not hwnd:
            return 0
        root = int(user32.GetAncestor(wintypes.HWND(hwnd), 2) or hwnd)  # GA_ROOT
        return root if user32.IsWindow(wintypes.HWND(root)) else 0
    except Exception:
        return 0

def normalize_digits(text):
    text = str(text)
    superscript = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻", "0123456789+-")

    def expand_superscript(match):
        return "^" + match.group(1).translate(superscript)

    text = re.sub(r"(?<=10)([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)", expand_superscript, text)
    out = []
    for ch in text:
        try:
            out.append(str(unicodedata.digit(ch)))
        except (TypeError, ValueError):
            out.append(ch)
    text = "".join(out)
    text = unicodedata.normalize("NFKC", text)
    suffix_tokens = {"Qa": "\ue000", "Qi": "\ue001", "Sx": "\ue002",
                     "Sp": "\ue003", "Oc": "\ue004", "No": "\ue005",
                     "Dc": "\ue006", "Ki": "\ue007", "Mi": "\ue008",
                     "Gi": "\ue009", "Ti": "\ue00a"}

    for index, letter in enumerate("abcdefghijklmnopqrstuvwxyz"):
        suffix_tokens["a" + letter] = chr(0xE020 + index)
    for suffix, token in suffix_tokens.items():
        text = re.sub(rf"(?<=\d)\s*{suffix}\b", token, text, flags=re.IGNORECASE)
    text = (text.replace("−", "-").replace("—", "-").replace("–", "-")
                .replace("＋", "+").replace("，", ",").replace("．", ".")
                .replace("。", ".").replace("·", ".").replace("٫", ".")
                .replace("٬", ",").replace("％", "%").replace("﹪", "%")
                .replace("'", ",").replace("’", ",").replace("`", ",")
                .replace("\u2009", " ").replace("\u202f", " ").replace("\u00a0", " "))
    text = text.translate(str.maketrans({
        "О": "0", "о": "0", "Ο": "0", "ο": "0", "〇": "0", "Ø": "0",
        "Ι": "1", "і": "1", "ı": "1", "ⅼ": "1", "Ƽ": "2", "З": "3",
        "Ч": "4", "б": "6", "Ϭ": "6", "Ց": "9", "﹒": ".", "∙": ".",
    }))
    text = re.sub(r"(?<=\d)[:;](?=\d)", ".", text)

    for _ in range(3):
        before = text
        text = re.sub(r"(?<=\d)[OoＤD](?=\d|[.,])|(?<=[.,])[OoＤD](?=\d)", "0", text)
        text = re.sub(r"(?<=\d)[Il|](?=\d|[.,])|(?<=[.,])[Il|](?=\d)", "1", text)
        text = re.sub(r"(?<=\d)[Ss](?=\d)|(?<=[.,])[Ss](?=\d)", "5", text)
        text = re.sub(r"(?<=\d)[Zz](?=\d)|(?<=[.,])[Zz](?=\d)", "2", text)
        text = re.sub(r"(?<=\d)[Gg](?=\d)|(?<=[.,])[Gg](?=\d)", "6", text)
        text = re.sub(r"(?<=\d)[Bb](?=\d)|(?<=[.,])[Bb](?=\d)", "8", text)
        text = re.sub(r"(?<=\d)[Qq](?=\d)|(?<=[.,])[Qq](?=\d)", "9", text)
        if text == before:
            break

    def fix_numeric_run(match):
        run = match.group(0)
        if not any(ch.isdigit() for ch in run):
            return run
        mapping = {"O": "0", "o": "0", "D": "0", "I": "1", "l": "1", "L": "1", "|": "1",
                   "S": "5", "s": "5", "Z": "2", "z": "2", "G": "6", "g": "6",
                   "B": "8", "b": "8", "Q": "9", "q": "9", "A": "4", "a": "4"}
        chars = list(run)
        for i, ch in enumerate(chars):
            if ch not in mapping:
                continue
            if ch in "BbQq" and i == len(chars) - 1:
                continue
            chars[i] = mapping[ch]
        return "".join(chars)

    text = re.sub(r"[0-9OoDIlL|SsZzGgBbQqAa.,]+", fix_numeric_run, text)
    text = re.sub(r"(?<=\d)\s+(?=\d)", "", text)
    for suffix, token in suffix_tokens.items():
        text = text.replace(token, suffix)
    return text

SCORE_SUFFIX_FACTORS = {
    "": 1.0,
    "k": 1e3, "m": 1e6, "b": 1e9, "t": 1e12, "q": 1e15,
    "qa": 1e15, "qi": 1e18, "sx": 1e21, "sp": 1e24,
    "oc": 1e27, "no": 1e30, "dc": 1e33,
    "mn": 1e6, "bn": 1e9, "tn": 1e12, "tr": 1e12,
    "ki": 1024.0, "mi": 1024.0 ** 2, "gi": 1024.0 ** 3,
    "ti": 1024.0 ** 4,
    "百": 1e2, "千": 1e3, "万": 1e4, "亿": 1e8,
    "万亿": 1e12, "兆": 1e12, "京": 1e16, "垓": 1e20,
    "秭": 1e24, "穰": 1e28, "沟": 1e32, "涧": 1e36,
    "正": 1e40, "载": 1e44, "%": 1.0,
}

for _suffix_index, _suffix_letter in enumerate("abcdefghijklmnopqrstuvwxyz"):
    SCORE_SUFFIX_FACTORS.setdefault("a" + _suffix_letter, 10.0 ** (15 + 3 * _suffix_index))
SCORE_SUFFIXES = tuple(sorted((x for x in SCORE_SUFFIX_FACTORS if x),
                              key=len, reverse=True))
SCORE_SUFFIX_RE = (r"(?:万亿|Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|"
                   r"a[a-z]|[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)?")

def _mantissa_hypotheses(mantissa, suffix=""):
    raw = mantissa.replace(" ", "")
    if not raw:
        return []
    sign = ""
    if raw[:1] in "+-":
        sign, raw = raw[0], raw[1:]
    if not raw or not any(ch.isdigit() for ch in raw):
        return []
    hypotheses = []

    def add(body, weight):
        body = sign + body
        try:
            value = float(body)
        except ValueError:
            return
        if math.isfinite(value):
            hypotheses.append((value, float(weight)))

    comma, dot = raw.count(","), raw.count(".")
    if comma and dot:
        decimal = "," if raw.rfind(",") > raw.rfind(".") else "."
        grouping = "." if decimal == "," else ","
        add(raw.replace(grouping, "").replace(decimal, "."), 1.00)
        parts = re.split(r"[.,]", raw)
        if len(parts) > 1 and all(len(x) == 3 for x in parts[1:]):
            add("".join(parts), 0.82)
    elif comma or dot:
        sep = "," if comma else "."
        parts = raw.split(sep)
        if len(parts) == 2:
            left, right = parts
            if not right:
                add(left, 0.70)
            elif len(right) <= 2:
                add(left + "." + right, 1.00)
                if sep == "," and len(right) == 2 and len(left) >= 4:
                    add(left + right, 0.68)
            elif len(right) == 3:

                if suffix:
                    add(left + "." + right, 1.00)
                    add(left + right, 0.82)
                elif sep == ".":
                    add(left + "." + right, 1.00)
                    add(left + right, 0.93)
                else:
                    add(left + right, 1.00)
                    add(left + "." + right, 0.91)
            else:
                add(left + "." + right, 0.90)
                add(left + right, 0.78)
        else:
            tail3 = all(len(x) == 3 for x in parts[1:])
            if tail3:
                add("".join(parts), 1.00)

                if len(parts) <= 3:
                    add("".join(parts[:-1]) + "." + parts[-1], 0.69)
            else:
                add("".join(parts[:-1]) + "." + parts[-1], 0.93)
                add("".join(parts), 0.75)
    else:
        add(raw, 1.00)
    unique = {}
    for value, weight in hypotheses:
        key = float(value)
        if weight > unique.get(key, 0.0):
            unique[key] = weight
    return [(value, weight) for value, weight in unique.items()]

def parse_score_candidates(text):
    text = normalize_digits(text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*\^\s*([-+]?\d+)", r"e\1", text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*([-+]\d+)", r"e\1", text)
    text = re.sub(r"(?<![\dxX×*])10\s*\^\s*([-+]?\d+)", r"1e\1", text)
    pattern = re.compile(
        r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
        r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, re.IGNORECASE)
    results = []

    compound_re = re.compile(
        r"[-+]?(?:\d+(?:[.,]\d+)?)\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
        r"(?:\s*\d+(?:[.,]\d+)?\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百))+"
    )
    unit_re = re.compile(
        r"([-+]?\d+(?:[.,]\d+)?)\s*(载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
    )
    for compound in compound_re.finditer(text):
        parts = unit_re.findall(compound.group(0))
        factors = [SCORE_SUFFIX_FACTORS.get(unit, 1.0) for _number, unit in parts]
        if len(parts) < 2 or any(a <= b for a, b in zip(factors, factors[1:])):
            continue
        total = 0.0
        valid = True
        for (number, unit), factor in zip(parts, factors):
            hypotheses = _mantissa_hypotheses(number, unit)
            if not hypotheses:
                valid = False
                break
            base, _weight = max(hypotheses, key=lambda item: item[1])
            total += base * factor
        if valid and math.isfinite(total):
            results.append((total, 1.075, compound.group(0)))

    for match in pattern.finditer(text):
        token = match.group(0).strip()
        if not token:
            continue
        clean = token.replace(" ", "")
        suffix = ""
        lower_clean = clean.lower()
        for candidate in SCORE_SUFFIXES:
            if lower_clean.endswith(candidate.lower()):
                suffix = candidate
                clean = clean[:-len(candidate)]
                break
        exp_match = re.search(r"[eE][-+]?\d+$", clean)
        exponent = exp_match.group(0) if exp_match else ""
        mantissa = clean[:-len(exponent)] if exponent else clean
        factor = SCORE_SUFFIX_FACTORS.get(suffix,
                    SCORE_SUFFIX_FACTORS.get(suffix.lower(), 1.0))
        digit_count = sum(ch.isdigit() for ch in token)
        token_weight = min(1.08, 0.91 + digit_count * 0.018)
        for base, parse_weight in _mantissa_hypotheses(mantissa, suffix):
            try:
                if exponent:
                    base *= 10.0 ** int(exponent[1:])
                value = base * factor
            except (OverflowError, ValueError):
                continue

            prefix = text[max(0, match.start() - 2):match.start()]
            suffix_text = text[match.end():match.end() + 2]
            if "(" in prefix and ")" in suffix_text and value > 0:
                value = -value
            if math.isfinite(value):
                results.append((value, parse_weight * token_weight, token))

    dedup = {}
    for value, weight, token in results:
        key = float(value)
        old = dedup.get(key)
        if old is None or weight > old[0]:
            dedup[key] = (weight, token)
    return [(value, weight, token) for value, (weight, token) in dedup.items()]

def parse_score(text):
    candidates = parse_score_candidates(text)
    if not candidates:
        return None
    value, _weight, _token = max(
        candidates, key=lambda item: (item[1], sum(ch.isdigit() for ch in item[2]), len(item[2])))
    return value

class ScoreReader:

    def __init__(self, engines, capture, image_ops, image_module, np_module,
                 cv2_module, max_variants=6, hardware=None):
        self.engines = list(engines)
        self.capture = capture
        self.ImageOps = image_ops
        self.Image = image_module
        self.np = np_module
        self.cv2 = cv2_module
        self.hardware = hardware
        self.max_variants = max(2, int(max_variants))
        if hardware is not None:
            self.max_variants = max(self.max_variants, int(hardware.max_ocr_variants))
            self.min_variants = int(hardware.min_ocr_variants)
            self.latency_target = float(hardware.latency_target)
        else:
            self.min_variants = 2
            self.latency_target = 0.60
        self.active_variants = max(self.min_variants, min(self.max_variants, int(max_variants)))
        self.latency = 0.25
        self.confidence_ema = 0.78
        self.fail_streak = 0
        self.last_value = None
        self.last_confidence = 0.0
        self.last_text = ""
        self.recent = []
        self.source_skill = {}
        self.format_history = []
        self._digit_templates = None
        self._letter_templates = None
        self._glyph_bank = None
        self._glyph_bank_centered = None
        self._glyph_bank_norm = None
        self._glyph_label_indices = {}
        self.character_detail_variants = (0 if hardware is not None and hardware.tier == "low"
                                          else (3 if hardware is not None and hardware.tier == "high"
                                                else 2))

    @staticmethod
    def _as_float(value, default=0.5):
        try:
            if isinstance(value, (list, tuple)):
                value = value[0] if value else default
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return default

    def _extract_lines(self, result):
        lines = []
        txts = (result.get("txts") if isinstance(result, dict) else
                getattr(result, "txts", None))
        scores = (result.get("scores") if isinstance(result, dict) else
                  getattr(result, "scores", None))
        if txts is not None:
            try:
                texts = list(txts)
            except TypeError:
                texts = [txts]
            try:
                score_list = list(scores) if scores is not None and not isinstance(
                    scores, (str, bytes, float, int)) else []
            except TypeError:
                score_list = []
            for i, item in enumerate(texts):
                conf = score_list[i] if i < len(score_list) else scores
                if isinstance(item, (tuple, list)):
                    text = item[0] if item else ""
                    if len(item) > 1 and (conf is None or not score_list):
                        conf = item[1]
                elif isinstance(item, dict):
                    text = item.get("text") or item.get("txt") or ""
                    conf = item.get("score", conf)
                else:
                    text = item
                if str(text).strip():
                    lines.append((str(text), self._as_float(conf)))
            if lines:
                return lines
        body = result[0] if isinstance(result, (tuple, list)) and len(result) == 2 else result
        if isinstance(body, (tuple, list)):
            for item in body:
                if isinstance(item, (tuple, list)) and len(item) >= 2:
                    text = item[1]
                    conf = item[2] if len(item) > 2 else 0.5
                    if str(text).strip():
                        lines.append((str(text), self._as_float(conf)))
        return lines

    def _extract_character_lines(self, result):

        body = (result.get("word_results") if isinstance(result, dict) else
                getattr(result, "word_results", None))
        if not body:
            return []
        rows = []

        def collect(node, parts):
            if isinstance(node, dict):
                token = node.get("text") or node.get("txt") or node.get("word")
                confidence = node.get("score", node.get("confidence"))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
                for child in node.values():
                    collect(child, parts)
                return
            if not isinstance(node, (str, bytes, tuple, list)):
                token = (getattr(node, "text", None) or getattr(node, "txt", None) or
                         getattr(node, "word", None))
                confidence = getattr(node, "score", getattr(node, "confidence", None))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
            if (isinstance(node, (tuple, list)) and len(node) >= 2 and
                    isinstance(node[0], str) and
                    not isinstance(node[1], (str, bytes, tuple, list, dict))):
                token = str(node[0])
                if token:
                    parts.append((token, self._as_float(node[1])))
                return
            if isinstance(node, (tuple, list)):
                for child in node:
                    collect(child, parts)

        try:
            outer = list(body) if isinstance(body, (tuple, list)) else [body]
            def is_leaf(node):
                return (isinstance(node, (tuple, list)) and len(node) >= 2 and
                        isinstance(node[0], str) and
                        not isinstance(node[1], (str, bytes, tuple, list, dict)))
            if outer and all(is_leaf(item) for item in outer):
                outer = [outer]
            for row in outer:
                parts = []
                collect(row, parts)
                if parts:
                    text = "".join(token for token, _confidence in parts)

                    mean = sum(conf for _token, conf in parts) / len(parts)
                    floor = min(conf for _token, conf in parts)
                    rows.append((text, max(0.0, min(1.0, mean * 0.72 + floor * 0.28))))
        except Exception:
            return []
        return rows

    def _pad_and_scale(self, image):
        rgb = image.convert("RGB")
        arr = self.np.asarray(rgb)
        if arr.size:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            fill = tuple(int(x) for x in self.np.median(edge, axis=0))
        else:
            fill = (255, 255, 255)
        border = max(4, min(24, int(round(min(rgb.width, rgb.height) * 0.15))))
        rgb = self.ImageOps.expand(rgb, border=border, fill=fill)

        target_h = 96 if rgb.height < 42 else (112 if rgb.height < 72 else
                   128 if rgb.height < 92 else rgb.height)
        scale = max(1.0, min(8.5, target_h / max(1, rgb.height)))
        if scale > 1.03:
            rgb = rgb.resize((max(12, int(round(rgb.width * scale))),
                              max(12, int(round(rgb.height * scale)))),
                             self.Image.Resampling.LANCZOS)
        return rgb

    def _variants(self, image, limit=None):

        source_rgb = image.convert("RGB")
        rgb = self._pad_and_scale(source_rgb)
        hard_limit = self.max_variants if limit is None else max(1, min(self.max_variants, int(limit)))
        yielded = 0

        def emit(arr_or_img, weight, tag):
            nonlocal yielded
            if yielded >= hard_limit:
                return None
            yielded += 1
            if hasattr(arr_or_img, "convert"):
                arr = self.np.asarray(arr_or_img.convert("RGB"))
            else:
                arr = self.np.asarray(arr_or_img)
                if len(arr.shape) == 2:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_GRAY2RGB)
                elif arr.shape[2] == 4:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_RGBA2RGB)
            return arr, weight, tag

        arr = self.np.asarray(rgb)
        gray = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2GRAY)
        try:
            clahe = self.cv2.createCLAHE(clipLimit=2.8, tileGridSize=(4, 4)).apply(gray)
        except Exception:
            clahe = self.cv2.equalizeHist(gray)
        blur = self.cv2.GaussianBlur(clahe, (0, 0), 0.82)
        sharp = self.cv2.addWeighted(clahe, 2.10, blur, -1.10, 0)

        border_separation = None
        try:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            background = self.np.median(edge.astype("float32"), axis=0)
            delta = arr.astype("float32") - background.reshape(1, 1, 3)
            distance = self.np.sqrt((delta * delta).sum(axis=2))
            p90 = float(self.np.percentile(distance, 90.0))
            p995 = float(self.np.percentile(distance, 99.5))
            if p995 >= max(15.0, p90 * 1.18):
                normalized = self.np.clip(distance * (255.0 / max(1.0, p995)),
                                          0, 255).astype("uint8")
                normalized = self.cv2.GaussianBlur(normalized, (0, 0), 0.36)
                border_separation = 255 - normalized
        except Exception:
            border_separation = None

        pixel_view = None
        if source_rgb.height <= 58 and source_rgb.width <= 1200:
            try:
                sample = self.np.asarray(source_rgb.resize(
                    (min(96, max(8, source_rgb.width)), min(48, max(8, source_rgb.height))),
                    self.Image.Resampling.NEAREST))
                palette = len(self.np.unique(sample.reshape(-1, 3), axis=0))
                if palette <= 180:
                    target = 112 if source_rgb.height < 30 else 96
                    scale_px = max(2, min(10, int(round(target / max(1, source_rgb.height)))))
                    pixel_view = source_rgb.resize(
                        (max(12, source_rgb.width * scale_px),
                         max(12, source_rgb.height * scale_px)),
                        self.Image.Resampling.NEAREST)
            except Exception:
                pixel_view = None

        primary = [(rgb, 1.00, "rgb")]
        if pixel_view is not None:
            primary.append((pixel_view, 1.105, "pixel-nearest"))
        primary.extend([(clahe, 1.10, "clahe"), (sharp, 1.11, "sharp")])
        if border_separation is not None:
            primary.append((border_separation, 1.085, "border-color"))
        try:
            _t, otsu = self.cv2.threshold(sharp, 0, 255,
                                          self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            if float(otsu.mean()) < 127:
                otsu = 255 - otsu
            primary.append((otsu, 1.08, "otsu"))
        except Exception:
            otsu = None
        for data, weight, tag in primary:
            item = emit(data, weight, tag)
            if item:
                yield item
            if yielded >= hard_limit:
                return

        try:
            block = max(15, (min(gray.shape) // 4) | 1)
            block = min(71, block if block % 2 else block + 1)
            adaptive = self.cv2.adaptiveThreshold(
                clahe, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                self.cv2.THRESH_BINARY, block, 7)
            if float(adaptive.mean()) < 127:
                adaptive = 255 - adaptive
            item = emit(adaptive, 1.02, "adaptive")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            rgb_channels = list(self.cv2.split(arr))
            chroma = (arr.max(axis=2).astype("int16") -
                      arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            best_channel = max(rgb_channels + [chroma], key=lambda channel: float(channel.std()))
            if float(best_channel.std()) >= max(4.0, float(gray.std()) * 1.08):
                projected = self.cv2.normalize(best_channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(projected, 1.035, "chroma-best")
                if item:
                    yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            for fx, weight, tag in ((1.20, 1.035, "wide"), (0.84, 1.015, "narrow")):
                warped = self.cv2.resize(sharp, None, fx=fx, fy=1.0,
                                         interpolation=self.cv2.INTER_CUBIC if fx > 1 else self.cv2.INTER_AREA)
                item = emit(warped, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            tall = self.cv2.resize(sharp, None, fx=1.0, fy=1.18,
                                   interpolation=self.cv2.INTER_CUBIC)
            item = emit(tall, 1.035, "tall")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        if hard_limit >= 12 and min(gray.shape[:2]) <= 92:
            try:
                border = int(self.np.median(sharp))
                for dx, dy, weight, tag in ((0.50, 0.0, 1.012, "subpx-x"),
                                            (0.0, 0.50, 1.008, "subpx-y")):
                    matrix = self.np.float32([[1, 0, dx], [0, 1, dy]])
                    shifted = self.cv2.warpAffine(
                        sharp, matrix, (sharp.shape[1], sharp.shape[0]),
                        flags=self.cv2.INTER_CUBIC, borderMode=self.cv2.BORDER_CONSTANT,
                        borderValue=border)
                    item = emit(shifted, weight, tag)
                    if item:
                        yield item
                    if yielded >= hard_limit:
                        return
            except Exception:
                pass

        if hard_limit >= 10 and min(gray.shape[:2]) >= 20:
            try:
                center = ((sharp.shape[1] - 1) * 0.5, (sharp.shape[0] - 1) * 0.5)
                border = int(self.np.median(sharp))
                for angle, weight, tag in ((-1.35, 0.995, "rot-"),
                                           (1.35, 0.995, "rot+")):
                    matrix = self.cv2.getRotationMatrix2D(center, angle, 1.0)
                    rotated = self.cv2.warpAffine(
                        sharp, matrix, (sharp.shape[1], sharp.shape[0]),
                        flags=self.cv2.INTER_CUBIC, borderMode=self.cv2.BORDER_CONSTANT,
                        borderValue=border)
                    item = emit(rotated, weight, tag)
                    if item:
                        yield item
                    if yielded >= hard_limit:
                        return
            except Exception:
                pass

        try:
            gamma = self.np.clip((sharp.astype("float32") / 255.0) ** 0.72 * 255.0,
                                 0, 255).astype("uint8")
            item = emit(gamma, 1.025, "gamma")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            inv = 255 - sharp
            item = emit(inv, 1.00, "invert")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            sigma = max(3.0, min(gray.shape) / 18.0)
            background = self.cv2.GaussianBlur(clahe, (0, 0), sigma)
            local = self.cv2.normalize(self.cv2.absdiff(clahe, background), None, 0, 255,
                                       self.cv2.NORM_MINMAX)
            item = emit(local, 1.015, "local")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            kx = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (2, 1))
            ky = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (1, 2))
            closed_x = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, kx)
            closed_y = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, ky)
            for data, weight, tag in ((closed_x, 1.01, "close-x"), (closed_y, 1.005, "close-y")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            kh = max(3, min(15, ((min(gray.shape) // 8) | 1)))
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (kh, kh))
            top = self.cv2.morphologyEx(clahe, self.cv2.MORPH_TOPHAT, kernel)
            black = self.cv2.morphologyEx(clahe, self.cv2.MORPH_BLACKHAT, kernel)
            top = self.cv2.normalize(top, None, 0, 255, self.cv2.NORM_MINMAX)
            black = self.cv2.normalize(black, None, 0, 255, self.cv2.NORM_MINMAX)
            for data, weight, tag in ((top, 0.99, "tophat"), (black, 0.99, "blackhat")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            for gamma, weight, tag in ((0.58, 0.985, "gamma-light"),
                                       (1.72, 0.975, "gamma-dark")):
                lut = self.np.array([((i / 255.0) ** gamma) * 255 for i in range(256)], dtype="uint8")
                item = emit(self.cv2.LUT(clahe, lut), weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            channels = list(self.cv2.split(arr))
            lab = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2LAB)
            hsv = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2HSV)
            chroma = (arr.max(axis=2).astype("int16") - arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            channels += [lab[:, :, 1], lab[:, :, 2], hsv[:, :, 1], chroma]
            ranked_channels = sorted(channels, key=lambda c: float(c.std()), reverse=True)[:2]
            for index, channel in enumerate(ranked_channels):
                channel = self.cv2.normalize(channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(channel, 0.985 if index == 0 else 0.965, f"color{index + 1}")
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

    def _temporal_fusion(self, rect, count=3):

        frames = []
        size = None
        for index in range(max(2, int(count))):
            try:
                image = self.capture.grab(rect).convert("RGB")
                if size is None:
                    size = image.size
                elif image.size != size:
                    image = image.resize(size, self.Image.Resampling.BICUBIC)
                frames.append(self.np.asarray(image, dtype="uint8"))
            except Exception:
                continue
            if index + 1 < count:
                time.sleep(0.008)
        if len(frames) < 2:
            return None
        try:
            base = frames[0]
            base_gray = self.cv2.cvtColor(base, self.cv2.COLOR_RGB2GRAY).astype("float32")
            aligned = [base]
            h, w = base_gray.shape[:2]
            window = self.cv2.createHanningWindow((w, h), self.cv2.CV_32F) if w >= 8 and h >= 8 else None
            for frame in frames[1:]:
                gray = self.cv2.cvtColor(frame, self.cv2.COLOR_RGB2GRAY).astype("float32")
                try:
                    shift, response = self.cv2.phaseCorrelate(base_gray, gray, window)
                    dx, dy = float(shift[0]), float(shift[1])
                    if response >= 0.08 and abs(dx) <= 3.5 and abs(dy) <= 3.5:
                        matrix = self.np.float32([[1, 0, -dx], [0, 1, -dy]])
                        frame = self.cv2.warpAffine(frame, matrix, (w, h), flags=self.cv2.INTER_LINEAR,
                                                    borderMode=self.cv2.BORDER_REPLICATE)
                except Exception:
                    pass
                aligned.append(frame)
            stack = self.np.stack(aligned, axis=0)
            median = self.np.median(stack, axis=0)
            if len(aligned) >= 3:

                sharpest = max(aligned, key=lambda f: float(self.cv2.Laplacian(
                    self.cv2.cvtColor(f, self.cv2.COLOR_RGB2GRAY), self.cv2.CV_32F).var()))
                median = median * 0.82 + sharpest.astype("float32") * 0.18
            fused = self.np.clip(median, 0, 255).astype("uint8")
            return self.Image.fromarray(fused, mode="RGB")
        except Exception:
            return None

    def _content_crops(self, image):

        try:
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            h, w = rgb.shape[:2]
            if h < 8 or w < 8:
                return []
            edge = self.np.concatenate((rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]), axis=0)
            background = self.np.median(edge.astype("float32"), axis=0)
            difference = self.np.max(self.np.abs(rgb.astype("float32") - background), axis=2)
            threshold = max(8.0, float(self.np.percentile(difference, 72)) * 0.66)
            masks = [(difference >= threshold).astype("uint8") * 255]

            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gradient = self.cv2.magnitude(
                self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3),
                self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3))
            grad_threshold = max(12.0, float(self.np.percentile(gradient, 78)) * 0.62)
            masks.append((gradient >= grad_threshold).astype("uint8") * 255)

            crops, seen = [], set()
            for mask in masks:
                kernel = self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (max(2, min(7, w // 45)), 2))
                mask = self.cv2.morphologyEx(mask, self.cv2.MORPH_CLOSE, kernel)
                contours, _hierarchy = self.cv2.findContours(
                    mask, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
                boxes = []
                for contour in contours:
                    x, y, bw, bh = self.cv2.boundingRect(contour)
                    if bw * bh < max(2, h * w * 0.00010):
                        continue
                    if bh < max(2, h * 0.055) and bw < max(2, w * 0.018):
                        continue
                    boxes.append((x, y, x + bw, y + bh))
                if not boxes:
                    continue
                x1 = min(box[0] for box in boxes)
                y1 = min(box[1] for box in boxes)
                x2 = max(box[2] for box in boxes)
                y2 = max(box[3] for box in boxes)
                px, py = max(2, int(h * 0.05)), max(2, int(h * 0.08))
                bounds = (max(0, x1 - px), max(0, y1 - py),
                          min(w, x2 + px), min(h, y2 + py))
                bw, bh = bounds[2] - bounds[0], bounds[3] - bounds[1]
                if bw < 5 or bh < 5 or (bw >= w * 0.97 and bh >= h * 0.97):
                    continue
                key = tuple(int(v // 2) for v in bounds)
                if key in seen:
                    continue
                seen.add(key)
                crops.append(image.crop(bounds))
            return crops[:2]
        except Exception:
            return []

    def _normalize_glyph(self, mask):

        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            points = self.cv2.findNonZero(binary)
            if points is None:
                return None
            x, y, w, h = self.cv2.boundingRect(points)
            if w < 1 or h < 2:
                return None
            crop = binary[y:y + h, x:x + w]
            target_w, target_h = 22, 30
            scale = min(target_w / max(1.0, float(w)),
                        target_h / max(1.0, float(h)))
            nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
            interpolation = self.cv2.INTER_AREA if scale < 1.0 else self.cv2.INTER_CUBIC
            resized = self.cv2.resize(crop, (nw, nh), interpolation=interpolation)
            canvas = self.np.zeros((34, 26), dtype="uint8")
            ox, oy = (canvas.shape[1] - nw) // 2, (canvas.shape[0] - nh) // 2
            canvas[oy:oy + nh, ox:ox + nw] = resized
            return canvas.astype("float32") / 255.0
        except Exception:
            return None

    def _ensure_digit_templates(self):

        if self._digit_templates is not None:
            return self._digit_templates
        templates = {str(i): [] for i in range(10)}

        letter_templates = {letter: [] for letter in "ABDGIKLMOQSTZ"}
        fonts = tuple(dict.fromkeys((
            self.cv2.FONT_HERSHEY_SIMPLEX, self.cv2.FONT_HERSHEY_DUPLEX,
            self.cv2.FONT_HERSHEY_COMPLEX_SMALL, self.cv2.FONT_HERSHEY_TRIPLEX,
            self.cv2.FONT_HERSHEY_PLAIN,
        )))
        for font in fonts:
            for thickness in (1, 2, 3):
                for digit in templates:
                    canvas = self.np.zeros((76, 58), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(digit, font, scale, thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, digit, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
                for letter in letter_templates:
                    canvas = self.np.zeros((76, 72), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(letter, font, scale, thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, letter, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        letter_templates[letter].append(normalized)

        try:
            from PIL import ImageDraw, ImageFont
            windir = Path(os.environ.get("WINDIR", r"C:\Windows"))
            font_dir = windir / "Fonts"
            font_names = (
                "segoeui.ttf", "segoeuib.ttf", "seguisb.ttf", "segoeuiz.ttf",
                "arial.ttf", "arialbd.ttf", "tahoma.ttf", "tahomabd.ttf",
                "verdana.ttf", "verdanab.ttf", "calibri.ttf", "calibrib.ttf",
                "consola.ttf", "consolab.ttf", "bahnschrift.ttf",
            )
            available = [font_dir / name for name in font_names if (font_dir / name).exists()]

            for font_path in available[:8]:
                for size in (54,):
                    try:
                        font = ImageFont.truetype(str(font_path), size=size)
                    except Exception:
                        continue
                    for char in "0123456789KMBTQ":
                        canvas = self.Image.new("L", (96, 96), 0)
                        draw = ImageDraw.Draw(canvas)
                        try:
                            box = draw.textbbox((0, 0), char, font=font, stroke_width=0)
                            tw, th = max(1, box[2] - box[0]), max(1, box[3] - box[1])
                            x = (96 - tw) // 2 - box[0]
                            y = (96 - th) // 2 - box[1]
                        except Exception:
                            x, y = 16, 12
                        draw.text((x, y), char, fill=255, font=font)
                        normalized = self._normalize_glyph(self.np.asarray(canvas))
                        if normalized is None:
                            continue
                        if char.isdigit():
                            templates[char].append(normalized)
                        else:
                            letter_templates[char].append(normalized)
        except Exception:
            pass

        segment_map = {
            "0": "abcdef", "1": "bc", "2": "abdeg", "3": "abcdg", "4": "bcfg",
            "5": "acdfg", "6": "acdefg", "7": "abc", "8": "abcdefg", "9": "abcdfg",
        }
        for thickness in (4, 6, 8):
            for segment_width in (28, 36):
                left = (48 - segment_width) // 2
                right = left + segment_width
                for digit, active in segment_map.items():
                    canvas = self.np.zeros((78, 48), dtype="uint8")
                    t = thickness
                    segments = {
                        "a": (left, 5, right, 5 + t),
                        "b": (right - t, 8, right, 38),
                        "c": (right - t, 40, right, 70),
                        "d": (left, 70 - t, right, 70),
                        "e": (left, 40, left + t, 70),
                        "f": (left, 8, left + t, 38),
                        "g": (left, 37 - t // 2, right, 38 + (t + 1) // 2),
                    }
                    for name in active:
                        x1, y1, x2, y2 = segments[name]
                        self.cv2.rectangle(canvas, (x1, y1), (x2, y2), 255, -1)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
        self._digit_templates = templates
        self._letter_templates = letter_templates

        try:
            arrays, labels = [], []
            for label, variants in list(templates.items()) + list(letter_templates.items()):
                for template in variants:
                    arrays.append(template.astype("float32", copy=False).reshape(-1))
                    labels.append(label)
            if arrays:
                bank = self.np.stack(arrays, axis=0).astype("float32", copy=False)
                centered = bank - bank.mean(axis=1, keepdims=True)
                norms = self.np.sqrt((centered * centered).sum(axis=1)) + 1e-6
                indices = {}
                for index, label in enumerate(labels):
                    indices.setdefault(label, []).append(index)
                self._glyph_bank = bank
                self._glyph_bank_centered = centered
                self._glyph_bank_norm = norms
                self._glyph_label_indices = {
                    label: self.np.asarray(items, dtype="int32")
                    for label, items in indices.items()
                }
        except Exception:
            self._glyph_bank = None
        return templates

    def _classify_digit_glyph(self, mask, allow_suffix=False):
        glyph = self._normalize_glyph(mask)
        if glyph is None or float(glyph.mean()) < 0.025:
            return None, 0.0
        self._ensure_digit_templates()
        try:
            bank = self._glyph_bank
            if bank is None or not len(bank):
                return None, 0.0
            flat = glyph.astype("float32", copy=False).reshape(-1)
            centered = flat - float(flat.mean())
            gnorm = math.sqrt(float((centered * centered).sum())) + 1e-6
            corr = (self._glyph_bank_centered @ centered) / (self._glyph_bank_norm * gnorm)
            corr = self.np.clip((corr + 1.0) * 0.5, 0.0, 1.0)
            overlap = self.np.minimum(bank, flat).sum(axis=1)
            union = self.np.maximum(bank, flat).sum(axis=1)
            iou = overlap / self.np.maximum(1e-6, union)
            pixel_similarity = 1.0 - self.np.abs(bank - flat).mean(axis=1)
            scores = 0.54 * corr + 0.30 * iou + 0.16 * pixel_similarity

            def label_score(label):
                indices = self._glyph_label_indices.get(label)
                if indices is None or not len(indices):
                    return 0.0
                return float(scores[indices].max())

            per_digit = sorted(((label_score(str(i)), str(i)) for i in range(10)), reverse=True)
            best, digit = per_digit[0]
            runner = per_digit[1][0]
            margin = best - runner
            letter_scores = sorted(((label_score(letter), letter)
                                    for letter in (self._letter_templates or {})), reverse=True)
            letter_best = letter_scores[0][0] if letter_scores else 0.0

            if allow_suffix:
                suffix_scores = sorted(((label_score(letter), letter) for letter in "KMBTQ"),
                                       reverse=True)
                suffix_best, suffix = suffix_scores[0]
                suffix_runner = suffix_scores[1][0] if len(suffix_scores) > 1 else 0.0

                if (suffix_best >= 0.59 and suffix_best >= best + 0.018 and
                        suffix_best - suffix_runner >= 0.010):
                    conf = min(0.93, 0.25 + suffix_best * 0.68 +
                               (suffix_best - max(best, suffix_runner)) * 1.30)
                    return suffix, max(0.64, conf)

            if letter_best > best + 0.012:
                return None, max(0.0, min(0.70, best))
            if letter_best > best - 0.018:
                margin -= (letter_best - best + 0.018) * 0.72
            confidence = max(0.0, min(0.95, 0.24 + best * 0.69 + margin * 1.60))
            if best < 0.515 or margin < 0.016 or confidence < 0.62:
                return None, confidence
            return digit, confidence
        except Exception:
            return None, 0.0

    def _classical_mask_token(self, mask):

        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            h, w = binary.shape[:2]
            ratio = float((binary > 0).mean())
            if h < 8 or w < 5 or not 0.012 <= ratio <= 0.54:
                return None
            border_ratio = float(self.np.concatenate((
                binary[0], binary[-1], binary[:, 0], binary[:, -1])).mean()) / 255.0
            if border_ratio > 0.58:
                return None
            contours, _ = self.cv2.findContours(
                binary, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            min_area = max(2.0, h * w * 0.00016)
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = float(self.cv2.contourArea(contour))
                if area >= min_area and bw >= 1 and bh >= 1:
                    boxes.append((x, y, bw, bh, area))
            if not boxes:
                return None
            y0 = min(y for _x, y, _bw, _bh, _a in boxes)
            y1 = max(y + bh for _x, y, _bw, bh, _a in boxes)
            line_h = max(1, y1 - y0)
            punctuation = []
            digit_mask = binary.copy()
            for x, y, bw, bh, area in boxes:
                cy = y + bh * 0.5
                small = bh <= line_h * 0.42 and bw <= line_h * 0.34
                if small and cy >= y0 + line_h * 0.62:
                    mark = "," if bh >= max(3, bw * 1.35) else "."
                    punctuation.append((x + bw * 0.5, mark, 0.82))
                    digit_mask[y:y + bh, x:x + bw] = 0
                elif (bh <= line_h * 0.24 and bw >= max(2, bh * 1.8) and
                      y0 + line_h * 0.28 <= cy <= y0 + line_h * 0.72):
                    punctuation.append((x + bw * 0.5, "-", 0.78))
                    digit_mask[y:y + bh, x:x + bw] = 0

            kx = max(1, int(round(line_h * 0.025)))
            ky = max(1, int(round(line_h * 0.025)))
            grouped = self.cv2.dilate(
                digit_mask, self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (kx * 2 + 1, ky * 2 + 1)), iterations=1)
            groups, _ = self.cv2.findContours(
                grouped, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            group_boxes = []
            for contour in groups:
                gx, gy, gw, gh = self.cv2.boundingRect(contour)
                if gh < line_h * 0.34 or gw < max(2, line_h * 0.052):
                    continue

                if gw > line_h * 1.52:
                    return None
                left = max(0, gx + kx - 2)
                top = max(0, gy + ky - 2)
                right = min(w, gx + gw - kx + 2)
                bottom = min(h, gy + gh - ky + 2)
                if right - left >= 1 and bottom - top >= 2:
                    group_boxes.append((left, top, right, bottom))
            group_boxes.sort(key=lambda box: box[0])
            if not group_boxes or len(group_boxes) > 18:
                return None

            glyphs = []
            suffix_seen = False
            for index, (left, top, right, bottom) in enumerate(group_boxes):
                allow_suffix = index == len(group_boxes) - 1 and len(group_boxes) >= 2
                symbol, confidence = self._classify_digit_glyph(
                    digit_mask[top:bottom, left:right], allow_suffix=allow_suffix)
                if symbol is None:
                    return None
                if symbol in "KMBTQ":
                    if not allow_suffix or suffix_seen:
                        return None
                    suffix_seen = True
                glyphs.append(((left + right) * 0.5, symbol, confidence))
            tokens = sorted(glyphs + punctuation, key=lambda item: item[0])
            text = "".join(item[1] for item in tokens)
            if text.count("-") > 1 or ("-" in text and not text.startswith("-")):
                return None
            if text.count(".") + text.count(",") > 2 or not any(
                    ch.isdigit() for ch in text):
                return None
            if any(ch in "KMBTQ" for ch in text[:-1]):
                return None
            if not parse_score_candidates(text):
                return None
            confidences = [item[2] for item in glyphs]
            confidence = min(confidences) * 0.56 + sum(confidences) / len(confidences) * 0.44
            return text, max(0.0, min(0.93, confidence))
        except Exception:
            return None

    def _classical_numeric_candidates(self, image):

        try:
            rgb = self.np.asarray(self._pad_and_scale(image), dtype="uint8")
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gray = self.cv2.GaussianBlur(gray, (3, 3), 0.35)
            masks = []
            threshold_value, otsu = self.cv2.threshold(
                gray, 0, 255, self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            masks.extend((otsu, 255 - otsu))
            threshold_step = max(6.0, float(gray.std()) * 0.16)
            for fixed_value in (threshold_value - threshold_step,
                                threshold_value + threshold_step):
                _fixed_threshold, fixed = self.cv2.threshold(
                    gray, max(1.0, min(254.0, fixed_value)), 255,
                    self.cv2.THRESH_BINARY)
                masks.extend((fixed, 255 - fixed))
            if min(gray.shape[:2]) >= 17:
                block = max(15, min(61, (min(gray.shape[:2]) // 3) | 1))
                adaptive = self.cv2.adaptiveThreshold(
                    gray, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    self.cv2.THRESH_BINARY, block, 5)
                masks.extend((adaptive, 255 - adaptive))
            votes = {}
            for mask in masks:
                recognized = self._classical_mask_token(mask)
                if recognized is None:
                    continue
                token, confidence = recognized
                votes.setdefault(token, []).append(confidence)
            candidates = []
            for token, confidences in votes.items():
                support = len(confidences)
                digits = sum(ch.isdigit() for ch in token)
                required = 3 if digits == 1 else 2
                mean_conf = sum(confidences) / support

                if support < required or mean_conf < (0.84 if digits == 1 else 0.81):
                    continue
                confidence = min(0.91, mean_conf + min(0.08, 0.025 * (support - 1)))
                source_weight = min(0.94, 0.74 + 0.045 * support)
                for value, parse_weight, _parsed_token in parse_score_candidates(token):
                    candidates.append((value, confidence, token,
                                       source_weight * parse_weight,
                                       "classical:digit-templates"))
            return candidates
        except Exception:
            return []

    @staticmethod
    def _tag_variants(variants, prefix):
        return [(array, weight, f"{prefix}-{tag}") for array, weight, tag in variants]

    @staticmethod
    def _same_value(a, b):
        return abs(a - b) <= max(1e-9, max(abs(a), abs(b), 1.0) * 1e-10)

    @staticmethod
    def _text_quality(text):
        norm = normalize_digits(text).strip()
        if not norm:
            return 0.60
        allowed_suffix = re.compile(
            r"(?:Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|a[a-z]|万亿|"
            r"[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)$",
            re.IGNORECASE)
        core = allowed_suffix.sub("", norm).strip()
        useful = sum(ch.isdigit() or ch in "+-., eE" for ch in core)
        noise = sum(ch.isalpha() for ch in core)
        ratio = useful / max(1, len(core))
        punctuation = sum(ch in "+-.,eE" for ch in core)
        punct_penalty = max(0, punctuation - 4) * 0.035
        return max(0.55, min(1.10, 0.80 + 0.34 * ratio - 0.075 * noise - punct_penalty))

    @staticmethod
    def _token_signature(text):
        text = normalize_digits(text)
        text = re.sub(r"\s+", "", text)
        dynamic_suffix = ""
        suffix_match = re.search(r"a[a-z]$", text, re.IGNORECASE)
        if suffix_match:
            dynamic_suffix = suffix_match.group(0).lower()
            text = text[:suffix_match.start()]
        allowed = set("0123456789+-.,eEkKmMbBtTqQinrG%百千万亿兆京垓秭穰沟涧正载QaQiSxSpOcNoDcKiMiGiTi")
        return ("".join(ch for ch in text if ch in allowed) + dynamic_suffix)[:48]

    @staticmethod
    def _format_signature(text):

        norm = normalize_digits(text)
        match = re.search(
            r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
            r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, norm, re.IGNORECASE)
        if not match:
            return None
        token = re.sub(r"\s+", "", match.group(0))
        suffix_match = re.search(
            r"(万亿|Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|a[a-z]|"
            r"[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)$",
            token, re.IGNORECASE)
        suffix = suffix_match.group(0).lower() if suffix_match else ""
        core = token[:suffix_match.start()] if suffix_match else token
        exponent = bool(re.search(r"[eE][-+]?\d+$", core))
        mantissa = re.split(r"[eE]", core, maxsplit=1)[0]
        digits = sum(ch.isdigit() for ch in mantissa)
        decimal = 1 if ("." in mantissa or "," in mantissa) else 0
        grouped = 1 if len(re.findall(r"[., ]", mantissa)) >= 2 else 0
        signed = 1 if mantissa[:1] in "+-" else 0
        fraction_digits = -1
        separator_at = max(mantissa.rfind("."), mantissa.rfind(","))
        if separator_at >= 0:
            tail_digits = sum(ch.isdigit() for ch in mantissa[separator_at + 1:])

            if 1 <= tail_digits <= 2 or (suffix and 1 <= tail_digits <= 3):
                fraction_digits = tail_digits
        return (suffix, exponent, decimal, grouped, signed, digits, fraction_digits)

    def _format_prior(self, text, value):

        signature = self._format_signature(text)
        history = [item for item in self.format_history[-14:] if item]
        if signature is None or len(history) < 3:
            return 0.0
        suffix, exponent, decimal, grouped, signed, digits, fraction_digits = signature
        score = 0.0

        def mode(index):
            counts = {}
            for item in history:
                key = item[index]
                counts[key] = counts.get(key, 0) + 1
            return max(counts.items(), key=lambda kv: kv[1]) if counts else (None, 0)

        suffix_mode, suffix_n = mode(0)
        exponent_mode, exponent_n = mode(1)
        decimal_mode, decimal_n = mode(2)
        grouped_mode, grouped_n = mode(3)
        signed_mode, signed_n = mode(4)
        fraction_mode, fraction_n = mode(6)
        digit_values = sorted(int(item[5]) for item in history)
        median_digits = digit_values[len(digit_values) // 2]
        stability = len(history)
        jump = 1.0
        if self.last_value is not None:
            jump = max(abs(value), abs(self.last_value), 1.0) / max(1e-9, min(
                max(abs(value), 1e-9), max(abs(self.last_value), 1e-9)))

        suffix_transition = False
        if suffix != suffix_mode and suffix and suffix_mode and self.last_value is not None:
            old_factor = SCORE_SUFFIX_FACTORS.get(str(suffix_mode).lower())
            new_factor = SCORE_SUFFIX_FACTORS.get(str(suffix).lower())
            if old_factor and new_factor:
                factor_ratio = max(old_factor, new_factor) / max(1e-12, min(old_factor, new_factor))
                continuity = max(abs(value), abs(self.last_value), 1.0) / max(
                    1e-9, min(max(abs(value), 1e-9), max(abs(self.last_value), 1e-9)))
                suffix_transition = factor_ratio <= 10000.0 and continuity <= 2.4
        if suffix_n >= max(3, int(stability * 0.64)):
            if suffix == suffix_mode:
                score += 0.075
            elif not suffix_transition and jump < 120.0:
                score -= 0.085
        if exponent_n >= max(3, int(stability * 0.72)):
            score += 0.040 if exponent == exponent_mode else (-0.045 if jump < 80.0 else 0.0)
        if decimal_n >= max(3, int(stability * 0.72)):
            score += 0.035 if decimal == decimal_mode else (
                -0.035 if jump < 30.0 and not suffix_transition else 0.0)
        if grouped_n >= max(3, int(stability * 0.78)):
            score += 0.018 if grouped == grouped_mode else -0.015
        if signed_n >= max(3, int(stability * 0.80)) and signed != signed_mode and jump < 20.0:
            score -= 0.025
        if fraction_n >= max(3, int(stability * 0.72)) and int(fraction_mode) >= 0:
            if int(signature[6]) == int(fraction_mode):
                score += 0.030
            elif not suffix_transition and jump < 40.0:
                score -= 0.030
        digit_gap = abs(int(digits) - int(median_digits))
        if digit_gap <= 1:
            score += 0.028
        elif digit_gap >= 3 and jump < 250.0:
            score -= min(0.080, 0.025 * digit_gap)
        return max(-0.16, min(0.14, score))

    def _format_repair_candidates(self, text, expected=None):

        history = [item for item in self.format_history[-14:] if item]
        if len(history) < 5:
            return []

        def mode(index):
            counts = {}
            for item in history:
                key = item[index]
                counts[key] = counts.get(key, 0) + 1
            return max(counts.items(), key=lambda kv: kv[1]) if counts else (None, 0)

        suffix_mode, suffix_n = mode(0)
        fraction_mode, fraction_n = mode(6)
        stable_suffix = str(suffix_mode or "") if suffix_n >= max(4, int(len(history) * 0.70)) else ""
        stable_fraction = (int(fraction_mode) if fraction_n >= max(4, int(len(history) * 0.70))
                           and int(fraction_mode) >= 1 else -1)
        if not stable_suffix and stable_fraction < 1:
            return []

        norm = normalize_digits(text)
        token_match = re.search(
            r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
            r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, norm, re.IGNORECASE)
        if not token_match:
            return []
        token = re.sub(r"\s+", "", token_match.group(0))
        suffix_match = re.search(
            r"(万亿|Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|a[a-z]|"
            r"[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)$",
            token, re.IGNORECASE)
        current_suffix = suffix_match.group(0) if suffix_match else ""
        body = token[:suffix_match.start()] if suffix_match else token
        exponent_match = re.search(r"[eE][-+]?\d+$", body)
        exponent = exponent_match.group(0) if exponent_match else ""
        mantissa = body[:exponent_match.start()] if exponent_match else body
        raw_digits = "".join(ch for ch in mantissa if ch.isdigit())

        repairs = []
        if stable_fraction >= 1 and not any(ch in mantissa for ch in ".,") and (
                len(raw_digits) > stable_fraction):
            sign = mantissa[:1] if mantissa[:1] in "+-" else ""
            digit_body = raw_digits
            repaired_mantissa = (sign + digit_body[:-stable_fraction] + "." +
                                 digit_body[-stable_fraction:])
            repairs.append(repaired_mantissa + exponent + current_suffix)
        if stable_suffix and not current_suffix:
            repairs.append(body + stable_suffix)
        if stable_suffix and not current_suffix and stable_fraction >= 1 and (
                not any(ch in mantissa for ch in ".,") and
                len(raw_digits) > stable_fraction):
            sign = mantissa[:1] if mantissa[:1] in "+-" else ""
            repaired_mantissa = (sign + raw_digits[:-stable_fraction] + "." +
                                 raw_digits[-stable_fraction:])
            repairs.append(repaired_mantissa + exponent + stable_suffix)

        base_values = parse_score_candidates(token)
        base_value = base_values[0][0] if base_values else None
        results, seen = [], set()
        for repaired in repairs:
            if repaired == token or repaired in seen:
                continue
            seen.add(repaired)
            for value, parse_weight, _parsed in parse_score_candidates(repaired):
                repair_weight = 0.64
                if expected is not None:
                    expected_scale = max(1.0, abs(expected))
                    repaired_distance = abs(value - expected) / expected_scale
                    if base_value is None:
                        base_distance = float("inf")
                    else:
                        base_distance = abs(base_value - expected) / expected_scale
                    if repaired_distance <= 0.035:
                        repair_weight = 0.94
                    elif repaired_distance < base_distance * 0.45:
                        repair_weight = 0.86
                    elif repaired_distance < base_distance * 0.72:
                        repair_weight = 0.76
                results.append((value, parse_weight * repair_weight, repaired))
        return results[:4]

    def _remember_format(self, text, confidence):
        if confidence < 0.82:
            return
        signature = self._format_signature(text)
        if signature is None:
            return
        self.format_history.append(signature)
        if len(self.format_history) > 18:
            self.format_history = self.format_history[-18:]

    @staticmethod
    def _edit_similarity(a, b):
        if not a or not b:
            return 0.0
        if a == b:
            return 1.0
        if abs(len(a) - len(b)) > max(3, int(max(len(a), len(b)) * 0.45)):
            return 0.0
        previous = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            current = [i]
            for j, cb in enumerate(b, 1):
                current.append(min(current[-1] + 1, previous[j] + 1,
                                   previous[j - 1] + (0 if ca == cb else 1)))
            previous = current
        distance = previous[-1]
        return max(0.0, 1.0 - distance / max(len(a), len(b), 1))

    def _source_multiplier(self, source):
        stat = self.source_skill.get(source, {})
        hit = float(stat.get("hit", 0.0))
        miss = float(stat.get("miss", 0.0))
        total = hit + miss
        if total < 1.5:
            return 1.0
        mean = (hit + 1.6) / (total + 3.2)
        confidence = min(1.0, total / 18.0)
        return max(0.72, min(1.30, 1.0 + (mean - 0.5) * 0.60 * confidence))

    def _learn_sources(self, candidates, chosen, confidence):
        if chosen is None or confidence < 0.58:
            return
        trust = max(0.10, min(1.0, (float(confidence) - 0.50) / 0.42))
        by_source = {}
        for value, _conf, _text, _weight, source in candidates:
            by_source.setdefault(source, []).append(value)
        for source, values in by_source.items():
            stat = self.source_skill.setdefault(source, {"hit": 0.0, "miss": 0.0})
            hit = any(self._same_value(value, chosen) for value in values)
            stat["hit" if hit else "miss"] = float(stat.get("hit" if hit else "miss", 0.0)) + trust
            total = float(stat.get("hit", 0.0)) + float(stat.get("miss", 0.0))
            if total > 80.0:
                stat["hit"] *= 0.72
                stat["miss"] *= 0.72
        if len(self.source_skill) > 140:
            ranked = sorted(self.source_skill.items(),
                            key=lambda kv: float(kv[1].get("hit", 0.0)) + float(kv[1].get("miss", 0.0)),
                            reverse=True)[:140]
            self.source_skill = dict(ranked)

    @staticmethod
    def _align_tokens(anchor, token):

        rows, cols = len(anchor) + 1, len(token) + 1
        gap = 0.78
        costs = [[0.0] * cols for _ in range(rows)]
        moves = [[None] * cols for _ in range(rows)]
        for i in range(1, rows):
            costs[i][0], moves[i][0] = i * gap, "up"
        for j in range(1, cols):
            costs[0][j], moves[0][j] = j * gap, "left"
        for i in range(1, rows):
            for j in range(1, cols):
                substitute = costs[i - 1][j - 1] + (0.0 if anchor[i - 1] == token[j - 1] else 1.0)
                delete = costs[i - 1][j] + gap
                insert = costs[i][j - 1] + gap
                best = min((substitute, 0, "diag"), (delete, 1, "up"),
                           (insert, 2, "left"))
                costs[i][j], moves[i][j] = best[0], best[2]
        aligned = []
        i, j = len(anchor), len(token)
        while i or j:
            move = moves[i][j]
            if move == "diag":
                aligned.append((anchor[i - 1], token[j - 1]))
                i, j = i - 1, j - 1
            elif move == "up":
                aligned.append((anchor[i - 1], None))
                i -= 1
            else:
                aligned.append((None, token[j - 1]))
                j -= 1
        aligned.reverse()
        return aligned

    def _aligned_consensus_tokens(self, candidates):

        unique = {}
        for _value, conf, text, weight, source in candidates:
            signature = self._token_signature(text)
            if len(signature) < 2 or conf < 0.28:
                continue
            score = (max(0.02, float(weight)) * (0.18 + float(conf) ** 2) *
                     self._source_multiplier(source))
            key = (signature, source)
            if score > unique.get(key, (0.0, ""))[0]:
                unique[key] = (score, source)
        items = [(signature, score, source)
                 for (signature, _source), (score, source) in unique.items()]
        items.sort(key=lambda item: item[1], reverse=True)
        items = items[:64]
        if len(items) < 3:
            return []

        best_cluster = []
        best_cluster_score = 0.0
        for anchor, anchor_score, _source in items[:24]:
            members = []
            cluster_score = 0.0
            for signature, score, source in items:
                if abs(len(signature) - len(anchor)) > 2:
                    continue
                similarity = self._edit_similarity(anchor, signature)
                if similarity < 0.52:
                    continue
                members.append((signature, score, source))
                cluster_score += score * (0.55 + 0.45 * similarity)
            diversity = len({source for _signature, _score, source in members})
            if len(members) >= 3 and diversity >= 2 and cluster_score > best_cluster_score:
                best_cluster, best_cluster_score = members, cluster_score
        if not best_cluster:
            return []

        anchor = max(
            best_cluster,
            key=lambda item: sum(other_score * self._edit_similarity(item[0], other)
                                 for other, other_score, _source in best_cluster),
        )[0]
        char_votes = [dict() for _ in anchor]
        insert_votes = [dict() for _ in range(len(anchor) + 1)]
        total_weight = sum(score for _signature, score, _source in best_cluster)
        for signature, score, _source in best_cluster:
            chars = [""] * len(anchor)
            inserts = [""] * (len(anchor) + 1)
            cursor = 0
            for left, right in self._align_tokens(anchor, signature):
                if left is None:
                    if right:
                        inserts[cursor] += right
                else:
                    chars[cursor] = right or ""
                    cursor += 1
            for index, value in enumerate(chars):
                char_votes[index][value] = char_votes[index].get(value, 0.0) + score
            for index, value in enumerate(inserts):
                insert_votes[index][value] = insert_votes[index].get(value, 0.0) + score

        slots = []
        top_agreements = []
        for index in range(len(anchor) + 1):
            insertion = sorted(insert_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            if insertion:
                insertion_options = []
                for rank, (value, vote) in enumerate(insertion[:2]):
                    probability = vote / max(1e-9, total_weight)
                    threshold = 0.0 if rank == 0 else (0.34 if value else 0.22)
                    if probability >= threshold:
                        insertion_options.append((value, probability))
                if insertion_options:

                    if insertion_options[0][0] and insertion_options[0][1] < 0.50:
                        insertion_options.insert(0, ("", 1.0 - insertion_options[0][1]))
                    slots.append(insertion_options[:2])
                    top_agreements.append(insertion_options[0][1])
            if index == len(anchor):
                break
            choices = sorted(char_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            options = []
            for rank, (value, vote) in enumerate(choices[:2]):
                probability = vote / max(1e-9, total_weight)
                if rank == 0 or probability >= 0.20:
                    options.append((value, probability))
            if options:
                slots.append(options)
                top_agreements.append(options[0][1])

        if not slots:
            return []
        agreement = sum(top_agreements) / len(top_agreements)
        if agreement < 0.57:
            return []
        beams = [("", 0.0)]
        for options in slots:
            expanded = []
            for prefix, log_score in beams:
                for value, probability in options:
                    expanded.append((prefix + value,
                                     log_score + math.log(max(1e-6, probability))))
            expanded.sort(key=lambda item: item[1], reverse=True)
            beams = expanded[:6]
        source_count = len({source for _signature, _score, source in best_cluster})
        results, seen = [], set()
        for token, log_score in beams:
            if token in seen or not any(ch.isdigit() for ch in token):
                continue
            seen.add(token)
            beam_agreement = math.exp(log_score / max(1, len(slots)))
            combined = max(0.0, min(1.0, agreement * 0.62 + beam_agreement * 0.38))
            results.append((token, combined, source_count))
        return results

    def _with_character_consensus(self, candidates):

        work = list(candidates)
        for token, agreement, source_count in self._aligned_consensus_tokens(candidates):
            conf = min(0.982, 0.40 + agreement * 0.53 + min(0.04, source_count * 0.006))
            weight = min(1.13, 0.70 + agreement * 0.40)
            for value, parse_weight, _token in parse_score_candidates(token):
                work.append((value, conf, token, weight * parse_weight,
                             f"consensus:aligned:{source_count}"))
        return work

    def _pick(self, candidates, expected=None):
        if not candidates:
            return None, 0.0, ""
        candidates = self._with_character_consensus(candidates)
        groups = []
        for value, conf, text, weight, source in candidates:
            group = next((g for g in groups if self._same_value(g[0], value)), None)
            evidence = (weight * self._source_multiplier(source) * self._text_quality(text) *
                        (0.16 + conf * conf))
            if group is None:
                groups.append([value, {source: evidence}, conf, text, 1])
            else:
                old = float(group[1].get(source, 0.0))
                if old:
                    group[1][source] = max(old, evidence) + min(old, evidence) * 0.18
                else:
                    group[1][source] = evidence
                if conf > group[2]:
                    group[2], group[3] = conf, text
                group[4] += 1

        scored = []
        for value, source_scores, conf, text, observations in groups:
            evidence = sum(source_scores.values())
            support = len(source_scores)
            evidence += self._format_prior(text, value)
            evidence += min(0.86, 0.205 * (support - 1))
            evidence += min(0.12, 0.018 * max(0, observations - support))

            signature = self._token_signature(text)
            if signature and len(groups) > 1:
                near = 0.0
                for other_value, _other_sources, other_conf, other_text, _obs in groups:
                    if self._same_value(value, other_value):
                        continue
                    other_sig = self._token_signature(other_text)
                    similarity = self._edit_similarity(signature, other_sig)
                    if similarity < 0.78:
                        continue
                    lo = max(1e-12, min(abs(value), abs(other_value)))
                    hi = max(abs(value), abs(other_value), 1e-12)
                    if hi / lo <= 20.0 or len(signature) == len(other_sig):
                        near += (similarity - 0.76) * (0.16 + 0.20 * other_conf)
                evidence += min(0.13, max(0.0, near))

            temporal = sum(c for v, c in self.recent[-6:] if self._same_value(v, value))
            if temporal:
                evidence += min(0.17, temporal * 0.034)

            if expected is not None and not self._same_value(value, expected):
                scale = max(abs(expected), 1.0)
                jump = abs(value - expected) / scale
                if jump > 100000 and support == 1 and conf < 0.90:
                    evidence -= 0.22
                elif jump > 1000 and support == 1 and conf < 0.76:
                    evidence -= 0.10
            elif expected is not None:
                evidence += 0.075

            if self.last_value is not None and self.last_confidence >= 0.68:
                if self._same_value(value, self.last_value):
                    evidence += 0.035
                elif support == 1 and conf < 0.60:
                    scale = max(abs(self.last_value), 1.0)
                    if abs(value - self.last_value) > scale * 100000:
                        evidence -= 0.08
            scored.append([value, evidence, conf, text, support, observations])

        scored.sort(key=lambda g: (g[1], g[2], g[4], g[5]), reverse=True)
        if expected is not None and len(scored) > 1:
            for index, group in enumerate(scored[1:], start=1):
                if (self._same_value(group[0], expected) and
                        group[1] >= scored[0][1] * 0.94 and
                        (group[4] >= 2 or
                         (scored[0][4] == 1 and scored[0][2] < 0.72))):
                    scored.insert(0, scored.pop(index))
                    break
        best = scored[0]
        runner = scored[1][1] if len(scored) > 1 else 0.0
        margin = best[1] - runner
        margin_bonus = min(0.13, max(0.0, margin) * 0.047) if best[4] >= 2 else 0.0
        source_bonus = min(0.12, 0.045 * (best[4] - 1))
        confidence = min(0.997, best[2] + 0.050 * (best[4] - 1) + margin_bonus + source_bonus)
        if runner > 0 and best[1] > 0:
            competition = runner / best[1]
            if competition > 0.50:
                confidence -= min(0.24, (competition - 0.50) * 0.48)
        confidence = max(0.08, min(0.997, confidence))
        return best[0], confidence, best[3]

    @staticmethod
    def _expanded_rect(rect, ratio=0.06, px=3):
        x1, y1, x2, y2 = map(float, rect)
        w, h = max(1.0, x2 - x1), max(1.0, y2 - y1)
        dx, dy = max(px, w * ratio), max(px, h * ratio)
        return (x1 - dx, y1 - dy, x2 + dx, y2 + dy)

    @staticmethod
    def _shifted_rect(rect, dx=0, dy=0):
        x1, y1, x2, y2 = map(float, rect)
        return (x1 + dx, y1 + dy, x2 + dx, y2 + dy)

    def _run_engine(self, engine_name, engine, variants, candidates, model_weight=1.0,
                    det=False, limit=None, expected=None):
        use = variants if limit is None else variants[:limit]
        for index, (arr, weight, tag) in enumerate(use):
            try:
                kwargs = {"use_det": bool(det), "use_cls": False, "use_rec": True}
                if not det and index < self.character_detail_variants:
                    kwargs.update(return_word_box=True, return_single_char_box=True)
                try:
                    result = engine(arr, **kwargs)
                except (TypeError, ValueError):
                    kwargs.pop("return_word_box", None)
                    kwargs.pop("return_single_char_box", None)
                    result = engine(arr, **kwargs)
                lines = self._extract_lines(result)
                character_lines = self._extract_character_lines(result)
                character_confidence = {
                    self._token_signature(text): conf for text, conf in character_lines
                    if self._token_signature(text)
                }
                for text, conf in lines:
                    signature = self._token_signature(text)
                    if signature in character_confidence:
                        conf = min(conf, conf * 0.42 + character_confidence[signature] * 0.58)
                    parsed = parse_score_candidates(text)
                    for value, parse_weight, _token in parsed:
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * (0.93 if det else 1.0),
                                           f"{engine_name}:{tag}:{'det' if det else 'rec'}"))
                    if not det:
                        for value, repair_weight, repaired in self._format_repair_candidates(
                                text, expected):
                            candidates.append((value, conf * 0.94, repaired,
                                               weight * model_weight * repair_weight,
                                               f"{engine_name}:{tag}:fmtfix"))
                for text, conf in character_lines:
                    if any(text == existing for existing, _confidence in lines):
                        continue
                    for value, parse_weight, _token in parse_score_candidates(text):
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * 1.035,
                                           f"{engine_name}:{tag}:chars"))
                    if not det:
                        for value, repair_weight, repaired in self._format_repair_candidates(
                                text, expected):
                            candidates.append((value, conf * 0.95, repaired,
                                               weight * model_weight * repair_weight * 1.015,
                                               f"{engine_name}:{tag}:chars-fmtfix"))

                if len(lines) > 1:
                    joined = "".join(t for t, _c in lines)
                    conf = sum(c for _t, c in lines) / len(lines)
                    for value, parse_weight, _token in parse_score_candidates(joined):
                        candidates.append((value, conf, joined,
                                           weight * model_weight * 0.82 * parse_weight,
                                           f"{engine_name}:{tag}:joined"))
                if not det and index >= 1:
                    tentative = self._pick(candidates, expected)
                    support = sum(1 for v, _c, _t, _w, _s in candidates
                                  if tentative[0] is not None and self._same_value(v, tentative[0]))
                    if support >= 3 and tentative[1] >= 0.95:
                        break
            except Exception:
                continue

    def _burst_candidates(self, rect, primary_name, primary_engine, primary_weight,
                          expected=None, budget=4, count=2):
        candidates = []
        frames = max(1, min(3, int(count)))
        for frame_index in range(frames):
            try:
                image = self.capture.grab(rect)

                view_limit = 3 if budget >= 7 else 2
                variants = self._tag_variants(
                    list(self._variants(image, view_limit)), f"burst{frame_index + 1}")
                self._run_engine(f"{primary_name}-f{frame_index + 1}", primary_engine,
                                 variants, candidates, primary_weight * 0.985,
                                 det=False, expected=expected)
                if frame_index + 1 < frames:
                    time.sleep(0.010)
            except Exception:
                continue
        return candidates

    def _dynamic_budget(self):
        budget = int(self.active_variants)
        target = self.latency_target
        if self.latency > target * 2.4:
            budget -= 3
        elif self.latency > target * 1.55:
            budget -= 2
        elif self.latency > target * 1.18:
            budget -= 1
        elif self.latency < target * 0.62 and self.confidence_ema < 0.90:
            budget += 1
        if self.fail_streak:
            budget += min(3, self.fail_streak)
        if self.confidence_ema < 0.68:
            budget += 1
        if self.hardware is not None:
            avail = _available_memory()
            if avail < max(1024 ** 3, self.hardware.ram * 0.10):
                budget = min(budget, self.min_variants)
            elif getattr(self.hardware, "cpu_load_ema", 0.0) > 0.90:
                budget = max(self.min_variants, budget - 2)
        return max(self.min_variants, min(self.max_variants, budget))

    def _retune(self, success, confidence):
        self.confidence_ema = self.confidence_ema * 0.86 + float(confidence) * 0.14
        if success:
            self.fail_streak = 0
        else:
            self.fail_streak = min(5, self.fail_streak + 1)
        target = self.latency_target
        if self.latency > target * 1.45 and self.active_variants > self.min_variants:
            self.active_variants -= 1
        elif (self.latency < target * 0.72 and self.confidence_ema < 0.88 and
              self.active_variants < self.max_variants):
            self.active_variants += 1
        elif self.fail_streak >= 2 and self.active_variants < self.max_variants:
            self.active_variants += 1

    def read_image(self, image, expected=None):
        if image is None or image.width < 4 or image.height < 4 or not self.engines:
            return None, 0.0, ""
        variants = list(self._variants(image, self.max_variants))
        candidates = []
        for engine_name, engine, model_weight in self.engines:
            self._run_engine(engine_name, engine, variants, candidates,
                             model_weight, det=False, expected=expected)
        try:
            candidates.extend(self._classical_numeric_candidates(image))
        except Exception:
            pass
        primary_name, primary_engine, primary_weight = self.engines[0]
        self._run_engine(primary_name, primary_engine, variants, candidates,
                         primary_weight, det=True, expected=expected)
        best = self._pick(candidates, expected)
        if best[0] is not None:
            self._learn_sources(candidates, best[0], best[1])
            self._remember_format(best[2], best[1])
        return best

    def read(self, rect, expected=None):
        started = time.perf_counter()
        best = (None, 0.0, "")
        try:
            image = self.capture.grab(rect)
            if image.width < 4 or image.height < 4:
                self._retune(False, 0.0)
                return best
            budget = self._dynamic_budget()
            variants = list(self._variants(image, budget))
            candidates = []
            if not self.engines:
                self._retune(False, 0.0)
                return best
            primary_name, primary_engine, primary_weight = self.engines[0]
            self._run_engine(primary_name, primary_engine, variants, candidates,
                             primary_weight, det=False, expected=expected)
            best = self._pick(candidates, expected)

            if best[0] is None or best[1] < 0.84:
                candidates.extend(self._classical_numeric_candidates(image))
                best = self._pick(candidates, expected)

            if best[0] is None or best[1] < 0.88:
                for ratio, weight in ((0.055, 0.96), (0.12, 0.90)):
                    try:
                        expanded = self.capture.grab(self._expanded_rect(rect, ratio=ratio,
                                                                         px=4 if ratio < 0.1 else 7))
                        more = self._tag_variants(
                            list(self._variants(expanded, max(2, min(budget, 5)))),
                            f"expand{int(ratio * 1000)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * weight, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.93:
                            break
                    except Exception:
                        continue

            if best[0] is None or best[1] < 0.89:
                for crop_index, tight in enumerate(self._content_crops(image), start=1):
                    try:
                        more = self._tag_variants(
                            list(self._variants(tight, max(2, min(budget, 5)))),
                            f"tight{crop_index}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.94:
                            break
                    except Exception:
                        continue

            if best[0] is None or best[1] < 0.86:
                iw, ih = image.size
                trims = ((0.02, 0.04), (0.05, 0.02), (0.07, 0.07))
                for tx, ty in trims:
                    try:
                        xpad, ypad = int(iw * tx), int(ih * ty)
                        if iw - 2 * xpad < 6 or ih - 2 * ypad < 6:
                            continue
                        inner = image.crop((xpad, ypad, iw - xpad, ih - ypad))
                        more = self._tag_variants(
                            list(self._variants(inner, max(2, min(budget, 4)))),
                            f"trim{int(tx * 100)}x{int(ty * 100)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.97, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.92:
                            break
                    except Exception:
                        continue

            if (best[0] is None or best[1] < 0.76) and budget >= 4:
                for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                    try:
                        shifted = self.capture.grab(self._shifted_rect(rect, dx, dy))
                        more = self._tag_variants(
                            list(self._variants(shifted, 2 if budget < 7 else 3)),
                            f"shift{dx:+d}{dy:+d}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.985, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.90:
                            break
                    except Exception:
                        continue

            burst_frames = (getattr(self.hardware, "uncertain_burst_frames", 2)
                            if self.hardware is not None else 2)
            burst_allowed = (self.hardware is None or
                             (_available_memory() >= max(1100 * 1024 ** 2, self.hardware.ram * 0.085) and
                              getattr(self.hardware, "cpu_load_ema", 0.0) < 0.91))
            if burst_allowed and (best[0] is None or best[1] < 0.86):
                try:
                    candidates.extend(self._burst_candidates(
                        rect, primary_name, primary_engine, primary_weight, expected,
                        budget, burst_frames))
                    best = self._pick(candidates, expected)
                except Exception:
                    pass

            if best[0] is None or best[1] < 0.82:
                try:
                    fused = self._temporal_fusion(rect, 3 if budget >= 4 else 2)
                    if fused is not None:
                        more = self._tag_variants(
                            list(self._variants(fused, max(2, min(budget, 5)))), "temporal")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        if best[0] is None or best[1] < 0.72:
                            candidates.extend(self._classical_numeric_candidates(fused))
                        best = self._pick(candidates, expected)
                except Exception:
                    pass

            ensemble_allowed = True
            if self.hardware is not None:
                ensemble_allowed = (_available_memory() >=
                                    max(1400 * 1024 ** 2, self.hardware.ram * 0.105) and
                                    getattr(self.hardware, "cpu_load_ema", 0.0) < 0.93)
            if (ensemble_allowed and len(self.engines) > 1 and
                    (best[0] is None or best[1] < 0.92)):
                for engine_name, engine, model_weight in self.engines[1:]:
                    self._run_engine(engine_name, engine, variants, candidates,
                                     model_weight, det=False, limit=max(2, min(5, budget)),
                                     expected=expected)
                    best = self._pick(candidates, expected)
                    if best[0] is not None and best[1] >= 0.94:
                        break

            if best[0] is None or best[1] < 0.64:
                self._run_engine(primary_name, primary_engine, variants, candidates,
                                 primary_weight, det=True, limit=max(1, min(3, budget)),
                                 expected=expected)
                best = self._pick(candidates, expected)

            if best[0] is not None and best[1] >= 0.44:
                self._learn_sources(candidates, best[0], best[1])
                self.last_value, self.last_confidence, self.last_text = best
                self._remember_format(best[2], best[1])
                self.recent.append((best[0], best[1]))
                if len(self.recent) > 8:
                    self.recent = self.recent[-8:]
                self._retune(True, best[1])
            else:
                self._retune(False, best[1])
            return best
        finally:
            elapsed = max(0.001, time.perf_counter() - started)
            self.latency = self.latency * 0.82 + elapsed * 0.18

class EscapeHook:
    def __init__(self, stop_event):
        self.stop_event = stop_event
        self.ready = threading.Event()
        self.hooked = False
        self.thread_id = 0
        self.thread = None
        self.hook = None
        self.callback = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.ready.wait(2)
        return self.hooked

    def _run(self):
        self.thread_id = kernel32.GetCurrentThreadId()
        proc_type = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM)

        def low_level_proc(code, message, data):
            if code >= 0:
                info = ctypes.cast(data, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if info.vkCode == VK_ESCAPE and message in (
                        WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP):
                    self.stop_event.set()
                    return 1
            return user32.CallNextHookEx(self.hook, code, message, data)

        self.callback = proc_type(low_level_proc)
        self.hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL,
                                             ctypes.cast(self.callback, ctypes.c_void_p),
                                             kernel32.GetModuleHandleW(None), 0)
        self.hooked = bool(self.hook)
        self.ready.set()
        if not self.hook:
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def close(self):
        deadline = time.monotonic() + 1.5
        while user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000 and time.monotonic() < deadline:
            time.sleep(0.03)
        if self.thread_id:
            user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)

NAMED_KEY_VKS = {
    "BACKSPACE": 0x08, "TAB": 0x09, "CLEAR": 0x0C, "ENTER": 0x0D,
    "SHIFT": 0x10, "CTRL": 0x11, "ALT": 0x12, "PAUSE": 0x13,
    "CAPSLOCK": 0x14, "IME_KANA": 0x15, "IME_ON": 0x16,
    "IME_JUNJA": 0x17, "IME_FINAL": 0x18, "IME_HANJA": 0x19,
    "IME_OFF": 0x1A, "CONVERT": 0x1C, "NONCONVERT": 0x1D,
    "ACCEPT": 0x1E, "MODECHANGE": 0x1F, "SPACE": 0x20,
    "PAGEUP": 0x21, "PAGEDOWN": 0x22, "END": 0x23, "HOME": 0x24,
    "LEFT": 0x25, "UP": 0x26, "RIGHT": 0x27, "DOWN": 0x28,
    "SELECT": 0x29, "PRINT": 0x2A, "EXECUTE": 0x2B,
    "PRINTSCREEN": 0x2C, "INSERT": 0x2D, "DELETE": 0x2E, "HELP": 0x2F,
    "LWIN": 0x5B, "RWIN": 0x5C, "APPS": 0x5D, "SLEEP": 0x5F,
    "MULTIPLY": 0x6A, "ADD": 0x6B, "SEPARATOR": 0x6C,
    "SUBTRACT": 0x6D, "DECIMAL": 0x6E, "DIVIDE": 0x6F,
    "NUMLOCK": 0x90, "SCROLLLOCK": 0x91,
    "LSHIFT": 0xA0, "RSHIFT": 0xA1, "LCTRL": 0xA2, "RCTRL": 0xA3,
    "LALT": 0xA4, "RALT": 0xA5, "BROWSER_BACK": 0xA6,
    "BROWSER_FORWARD": 0xA7, "BROWSER_REFRESH": 0xA8,
    "BROWSER_STOP": 0xA9, "BROWSER_SEARCH": 0xAA,
    "BROWSER_FAVORITES": 0xAB, "BROWSER_HOME": 0xAC,
    "VOLUME_MUTE": 0xAD, "VOLUME_DOWN": 0xAE, "VOLUME_UP": 0xAF,
    "MEDIA_NEXT": 0xB0, "MEDIA_PREVIOUS": 0xB1, "MEDIA_STOP": 0xB2,
    "MEDIA_PLAY_PAUSE": 0xB3, "LAUNCH_MAIL": 0xB4,
    "LAUNCH_MEDIA": 0xB5, "LAUNCH_APP1": 0xB6, "LAUNCH_APP2": 0xB7,
    "OEM_SEMICOLON": 0xBA, "OEM_PLUS": 0xBB, "OEM_COMMA": 0xBC,
    "OEM_MINUS": 0xBD, "OEM_PERIOD": 0xBE, "OEM_SLASH": 0xBF,
    "OEM_BACKTICK": 0xC0, "OEM_LBRACKET": 0xDB,
    "OEM_BACKSLASH": 0xDC, "OEM_RBRACKET": 0xDD,
    "OEM_QUOTE": 0xDE, "OEM_8": 0xDF, "OEM_102": 0xE2,
    "PROCESSKEY": 0xE5, "PACKET": 0xE7, "ATTN": 0xF6,
    "CRSEL": 0xF7, "EXSEL": 0xF8, "EREOF": 0xF9, "PLAY": 0xFA,
    "ZOOM": 0xFB, "NONAME": 0xFC, "PA1": 0xFD, "OEM_CLEAR": 0xFE,
}
NAMED_KEY_VKS.update({str(digit): 0x30 + digit for digit in range(10)})
NAMED_KEY_VKS.update({chr(code): code for code in range(0x41, 0x5B)})
NAMED_KEY_VKS.update({f"NUMPAD{digit}": 0x60 + digit for digit in range(10)})
NAMED_KEY_VKS.update({f"F{number}": 0x6F + number for number in range(1, 25)})
SAFE_BASE_KEY_NAMES = (
    "UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE",
    "ENTER", "TAB", "E", "F", "Q", "R",
) + tuple(str(digit) for digit in range(10))
SAFE_DYNAMIC_KEY_NAMES = tuple(chr(code) for code in range(ord("A"), ord("Z") + 1)) + tuple(
    str(digit) for digit in range(10))
SAFE_KEY_UNIVERSE = tuple(dict.fromkeys(SAFE_BASE_KEY_NAMES + SAFE_DYNAMIC_KEY_NAMES))
KEY_ACTIONS = {f"key:{name}": NAMED_KEY_VKS[name] for name in SAFE_KEY_UNIVERSE
               if name in NAMED_KEY_VKS and NAMED_KEY_VKS[name] != VK_ESCAPE}
KEY_NAME_TO_VK = {name.split(":", 1)[1]: vk for name, vk in KEY_ACTIONS.items()}

CORE_KEY_ACTIONS = tuple(f"key:{name}" for name in SAFE_BASE_KEY_NAMES if f"key:{name}" in KEY_ACTIONS)
SECONDARY_KEY_ACTIONS = ()
TERTIARY_KEY_ACTIONS = ()
HOLD_KEY_ACTIONS = tuple(
    f"hold:{name}:{milliseconds}"
    for milliseconds in (260, 720, 1500)
    for name in ("UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE")
)
CHORD_KEY_ACTIONS = tuple(
    f"chord:{left}+{right}"
    for left, right in (
        ("W", "A"), ("W", "D"), ("S", "A"), ("S", "D"),
        ("UP", "LEFT"), ("UP", "RIGHT"), ("DOWN", "LEFT"), ("DOWN", "RIGHT"),
        ("W", "SPACE"), ("A", "SPACE"), ("D", "SPACE"),
        ("UP", "SPACE"), ("LEFT", "SPACE"), ("RIGHT", "SPACE"),
    )
)
OBSERVE_ACTION = "wait:observe"
KEY_ACTION_PRIORS = {action: (0.61 if action in CORE_KEY_ACTIONS else 0.18)
                     for action in KEY_ACTIONS}
KEY_ACTION_PRIORS.update({action: 0.38 for action in HOLD_KEY_ACTIONS})
KEY_ACTION_PRIORS.update({action: 0.34 for action in CHORD_KEY_ACTIONS})
KEY_ACTION_PRIORS.update({"key:ENTER": 0.44, "key:TAB": 0.36, OBSERVE_ACTION: 0.26})

def _send_key_event(vk, up=False):
    if vk == VK_ESCAPE:
        return False
    extended = vk in {
        0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2C, 0x2D, 0x2E,
        0x5B, 0x5C, 0x5D, 0x6F, 0x90, 0xA3, 0xA5,
    } or 0xA6 <= vk <= 0xB7
    scan = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC))
    try:
        flags = KEYEVENTF_SCANCODE | (KEYEVENTF_EXTENDEDKEY if extended else 0)
        if up:
            flags |= KEYEVENTF_KEYUP
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.union.ki = KEYBDINPUT(0, scan, flags, 0, 0)
        if scan:
            if int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1:
                return True
    except Exception:
        pass
    try:
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP if up else 0, 0)
        return True
    except Exception:
        return False

def press_keys(vks, duration=0.075, stop_event=None):

    keys = []
    for vk in vks:
        vk = int(vk)
        if vk != VK_ESCAPE and vk not in keys:
            keys.append(vk)
    down = []
    try:
        for vk in keys:
            if _send_key_event(vk, False):
                down.append(vk)
        duration = float(duration)
        if not math.isfinite(duration):
            return
        end = time.monotonic() + max(0.018, duration)
        while time.monotonic() < end:
            if stop_event is not None and stop_event.is_set():
                break
            time.sleep(min(0.018, max(0.001, end - time.monotonic())))
    finally:
        for vk in reversed(down):
            _send_key_event(vk, True)

def tap_key(vk, duration=0.075):
    press_keys((vk,), duration)

MOUSE_BUTTONS = {
    "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP, 0),
    "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, 0),
    "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP, 0),
    "x1": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON1),
    "x2": (MOUSEEVENTF_XDOWN, MOUSEEVENTF_XUP, XBUTTON2),
}

def _mouse_event(flags, data=0):
    user32.mouse_event(int(flags), 0, 0, int(data) & 0xFFFFFFFF, 0)

def move_pointer(x, y):
    return bool(user32.SetCursorPos(int(round(x)), int(round(y))))

def click_point(x, y, button="left", clicks=1, stop_event=None):
    flags = MOUSE_BUTTONS.get(str(button).lower())
    if flags is None:
        return False
    move_pointer(x, y)
    down, up, data = flags
    for index in range(max(1, int(clicks))):
        if stop_event is not None and stop_event.is_set():
            break
        _mouse_event(down, data)
        try:
            end = time.monotonic() + 0.050
            while time.monotonic() < end:
                if stop_event is not None and stop_event.is_set():
                    break
                time.sleep(0.008)
        finally:
            _mouse_event(up, data)
        if index + 1 < clicks:
            time.sleep(0.065)
    return True

def scroll_point(x, y, amount, horizontal=False):
    move_pointer(x, y)
    _mouse_event(MOUSEEVENTF_HWHEEL if horizontal else MOUSEEVENTF_WHEEL,
                 int(amount))

def drag_pointer(x1, y1, x2, y2, button="left", duration=0.45, stop_event=None):
    flags = MOUSE_BUTTONS.get(str(button).lower())
    if flags is None:
        return False
    down, up, data = flags
    move_pointer(x1, y1)
    _mouse_event(down, data)
    try:
        duration = max(0.02, float(duration))
        steps = max(2, int(math.ceil(duration / 0.014)))
        started = time.monotonic()
        for step in range(1, steps + 1):
            if stop_event is not None and stop_event.is_set():
                break
            progress = step / steps
            eased = progress * progress * (3.0 - 2.0 * progress)
            move_pointer(x1 + (x2 - x1) * eased, y1 + (y2 - y1) * eased)
            target = started + duration * progress
            while time.monotonic() < target:
                if stop_event is not None and stop_event.is_set():
                    break
                time.sleep(min(0.006, target - time.monotonic()))
    finally:
        _mouse_event(up, data)
    return True

class Learner:

    DELAY_BOUNDS = (0.12, 0.28, 0.55, 0.95, 1.45, 2.20, 3.40, 5.20, 8.00, 12.00)

    INVERSES = {
        "key:UP": "key:DOWN", "key:DOWN": "key:UP",
        "key:LEFT": "key:RIGHT", "key:RIGHT": "key:LEFT",
        "key:W": "key:S", "key:S": "key:W", "key:A": "key:D", "key:D": "key:A",
        "key:Q": "key:E", "key:E": "key:Q",
    }

    def __init__(self, state_file):
        self.state_file = Path(state_file)
        self.stats = {}
        self.contexts = {}
        self.families = {}
        self.pairs = {}
        self.triples = {}
        self.sequences = {}
        self.sequence_contexts = {}
        self.aliases = {}
        self.models = {}
        self.steps = 0
        self.best = None
        self.last_action = None
        self.prev_action = None
        self.last_reward = 0.0
        self.positive = 0
        self.history = []
        self.atomic_trace = []
        self.recent = {}
        self.action_trace = []
        self.delays = {}
        self.passive = {}
        self.passive_families = {}
        self.outcomes = {}
        self.return_trace = []
        self.trajectory = []
        self.eligibility = []
        self.last_rate_signal = 0.0
        self.nstep = {}
        self.trajectory_sequences = {}
        self.rates = {}
        self.passive_rates = {}
        self.influence = {}
        self.effects = {}
        self._db = None
        self._table_specs = {
            "stats": "actions", "contexts": "contexts", "families": "families",
            "pairs": "pairs", "triples": "triples", "sequences": "sequences",
            "sequence_contexts": "sequence_contexts", "aliases": "aliases",
            "models": "transitions", "delays": "delays", "passive": "passive",
            "passive_families": "passive_families", "nstep": "nstep",
            "trajectory_sequences": "trajectory_sequences", "rates": "rates",
            "passive_rates": "passive_rates", "influence": "influence",
            "effects": "effects",
        }
        self._dirty = {table: set() for table in self._table_specs.values()}
        self._deleted = {table: set() for table in self._table_specs.values()}
        self._table_by_id = {}
        self._open_store()
        self._sync_table_refs()

    def _sync_table_refs(self):
        self._table_by_id = {id(getattr(self, attr)): table for attr, table in self._table_specs.items()}

    def _open_store(self):
        self.state_file.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(self.state_file), timeout=6.0)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=NORMAL")
        self._db.execute("PRAGMA temp_store=MEMORY")
        self._db.execute("PRAGMA busy_timeout=6000")
        for table in self._table_specs.values():
            self._db.execute(f'CREATE TABLE IF NOT EXISTS "{table}" (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID')
        self._db.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID')
        self._db.commit()
        for attr, table in self._table_specs.items():
            loaded = {}
            try:
                for key, value in self._db.execute(f'SELECT key, value FROM "{table}"'):
                    try:
                        loaded[str(key)] = json.loads(value)
                    except Exception:
                        continue
            except sqlite3.DatabaseError:
                loaded = {}
            setattr(self, attr, loaded)
        meta = {}
        try:
            for key, value in self._db.execute('SELECT key, value FROM meta'):
                try:
                    meta[str(key)] = json.loads(value)
                except Exception:
                    continue
        except sqlite3.DatabaseError:
            meta = {}
        self.steps = int(meta.get("steps", 0) or 0)
        self.best = meta.get("best")
        self.positive = int(meta.get("positive", 0) or 0)
        self.recent = meta.get("recent", {}) if isinstance(meta.get("recent", {}), dict) else {}
        self.outcomes = meta.get("outcomes", {}) if isinstance(meta.get("outcomes", {}), dict) else {}

    def _mark_dirty(self, table, key):
        table_name = self._table_by_id.get(id(table))
        if table_name:
            self._dirty[table_name].add(str(key))
            self._deleted[table_name].discard(str(key))

    def _delete_key(self, attr, key):
        table = getattr(self, attr)
        if key in table:
            del table[key]
            table_name = self._table_specs[attr]
            self._deleted[table_name].add(str(key))
            self._dirty[table_name].discard(str(key))

    @staticmethod
    def _value(stat):
        base_q = float(stat.get("long_q", stat.get("q", 0.0)))
        recent_q = float(stat.get("recent_q", base_q))
        drift = max(0.0, min(1.0, float(stat.get("drift", 0.0))))
        q = base_q * (1.0 - 0.72 * drift) + recent_q * (0.72 * drift)
        short_n = int(stat.get("short_n", 0))
        long_n = int(stat.get("return_n", 0))
        if short_n:
            short_q = float(stat.get("short_return", q))
            q = q * 0.82 + short_q * 0.18
        if long_n:
            long_return = float(stat.get("long_return", q))
            q = q * 0.86 + long_return * 0.14
        return q, int(stat.get("n", 0)), float(stat.get("v", 0.0))

    @staticmethod
    def _horizon_value(stat):
        return (float(stat.get("short_return", 0.0)), int(stat.get("short_n", 0)),
                float(stat.get("long_return", 0.0)), int(stat.get("return_n", 0)))

    def _update_return_stat(self, table, key, short_value, long_value):
        stat = table.setdefault(key, {"n": 0, "q": 0.0, "long_q": 0.0, "recent_q": 0.0,
                                      "drift": 0.0, "last_seen": 0, "v": 0.0,
                                      "good": 0, "bad": 0, "zero": 0, "up": 0.0, "down": 0.0})
        sn = int(stat.get("short_n", 0)) + 1
        ln = int(stat.get("return_n", 0)) + 1
        srate = max(0.06, 1.0 / min(18, sn))
        lrate = max(0.035, 1.0 / min(32, ln))
        stat["short_return"] = float(stat.get("short_return", short_value)) + srate * (
            float(short_value) - float(stat.get("short_return", short_value)))
        stat["long_return"] = float(stat.get("long_return", long_value)) + lrate * (
            float(long_value) - float(stat.get("long_return", long_value)))
        stat["short_n"], stat["return_n"] = sn, ln
        self._mark_dirty(table, key)

    def _update_horizon_trace(self, action, state, reward, observed_at=None):
        now = float(observed_at if observed_at is not None else time.monotonic())
        kept = []
        for entry in self.return_trace:
            age = max(0.0, now - float(entry["time"]))
            if age > 30.0:
                continue
            entry["short"] += math.exp(-age / 4.5) * float(reward)
            entry["long"] += math.exp(-age / 16.0) * float(reward)
            self._update_return_stat(self.stats, entry["action"], entry["short"], entry["long"])
            self._update_return_stat(self.contexts, self._context_key(entry["state"], entry["action"]),
                                     entry["short"], entry["long"])
            kept.append(entry)
        self.return_trace = kept[-96:]
        current = {"action": action, "state": state, "time": now,
                   "short": float(reward), "long": float(reward)}
        self.return_trace.append(current)
        self._update_return_stat(self.stats, action, current["short"], current["long"])
        self._update_return_stat(self.contexts, self._context_key(state, action),
                                 current["short"], current["long"])

    def _nstep_value(self, state, action):
        values = []
        for key, weight in ((f"global>{action}", 0.72),):
            q, n, v = self._value(self.nstep.get(key, {}))
            if n:
                values.append((q, n, v, weight))
        for family in self._state_families(state)[:4]:
            q, n, v = self._value(self.nstep.get(f"{family}>{action}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [w * min(3.5, 0.6 + math.log1p(n)) for _q, n, _v, w in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _base), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _w in values),
                sum(v * w for (_q, _n, v, _base), w in zip(values, weights)) / denom)

    def _sequence_value(self, action, state):
        parts = self._macro_parts(action)
        if len(parts) < 2:
            return 0.0, 0, 0.0
        key = "|".join(parts)
        values = []
        for table, base_w in ((self.sequences, 0.82), (self.trajectory_sequences, 1.12)):
            q, n, v = self._value(table.get(key, {}))
            if n:
                values.append((q, n, v, base_w))
        for family in self._state_families(state)[:4]:
            q, n, v = self._value(self.sequence_contexts.get(f"{family}>{key}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [base * min(3.6, 0.62 + math.log1p(n)) for _q, n, _v, base in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _b), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _b in values),
                sum(v * w for (_q, _n, v, _b), w in zip(values, weights)) / denom)

    def passive_rate_value(self, state):
        global_q, global_n, _v = self._value(self.passive_rates.get("global", {}))
        values = []
        for family in self._state_families(state)[:4]:
            q, n, _v = self._value(self.passive_rates.get(family, {}))
            if n:
                values.append((q, min(3.0, 0.65 + math.log1p(n))))
        if not values:
            return global_q if global_n else 0.0
        denom = max(1e-9, sum(w for _q, w in values))
        local = sum(q * w for q, w in values) / denom
        return 0.68 * local + 0.32 * global_q if global_n else local

    @staticmethod
    def _rate_signal(before, after, elapsed, confidence=1.0):
        elapsed = max(0.06, min(20.0, float(elapsed or 0.0)))
        delta = float(after) - float(before)
        reference = max(1e-6, abs(float(before)) * 0.0025, abs(float(after)) * 1e-9)
        signal = math.asinh(delta / (reference * elapsed)) if delta else 0.0
        conf = max(0.0, min(1.0, float(confidence)))
        reliability = max(0.03, min(1.0, (conf - 0.20) / 0.68))
        return max(-8.0, min(8.0, signal * reliability))

    @staticmethod
    def _influence_key(action, bins=8):
        point = Learner._mouse_point(action)
        if point is None:
            return None
        fx, fy = point
        x = max(0, min(bins - 1, int(fx * bins)))
        y = max(0, min(bins - 1, int(fy * bins)))
        return f"r{bins}:{x}:{y}"

    def influence_value(self, state, action):
        region = self._influence_key(action)
        if region is None:
            return 0.0, 0, 0.0
        values = []
        for key, base_w in ((f"global>{region}", 0.72), (f"action>{action}", 0.88)):
            q, n, v = self._value(self.influence.get(key, {}))
            if n:
                values.append((q, n, v, base_w))
        for family in self._state_families(state)[:3]:
            q, n, v = self._value(self.influence.get(f"{family}>{region}", {}))
            if n:
                values.append((q, n, v, 1.0))
        if not values:
            return 0.0, 0, 0.0
        weights = [base * min(3.0, 0.65 + math.log1p(n)) for _q, n, _v, base in values]
        denom = max(1e-9, sum(weights))
        return (sum(q * w for (q, _n, _v, _b), w in zip(values, weights)) / denom,
                sum(n for _q, n, _v, _b in values),
                sum(v * w for (_q, _n, v, _b), w in zip(values, weights)) / denom)

    def observe_influence(self, action, state, visual_change=0.0, reward=0.0):
        if action == OBSERVE_ACTION:
            return
        region = self._influence_key(action)
        if region is None:
            return
        change = max(0.0, min(2.0, float(visual_change)))
        payoff = max(-2.0, min(2.0, float(reward)))
        target = change * 0.95 + max(0.0, payoff) * 0.16
        if change < 0.025 and abs(payoff) < 0.035:
            target -= 0.18
        if payoff < -0.35:
            target -= min(0.30, abs(payoff) * 0.05)
        target = max(-0.65, min(2.2, target))
        self._update(self.influence, f"global>{region}", target, 0.88, record_outcome=False)
        self._update(self.influence, f"action>{action}", target, 0.72, record_outcome=False)
        for family in self._state_families(state)[:3]:
            self._update(self.influence, f"{family}>{region}", target, 0.80, record_outcome=False)

    def focus_actions(self, actions, state, stagnant, priors=None, limit=110):
        actions = list(dict.fromkeys(actions))
        if len(actions) <= limit or stagnant >= 34:
            return actions
        priors = priors or {}
        scored, unknown = [], []
        for action in actions:
            iq, inn, _iv = self.influence_value(state, action)
            if inn <= 0:
                unknown.append(action)
                continue
            quality = self.action_quality(action, state)
            prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
            score = quality * 0.58 + iq * 0.58 + (prior - 0.5) * 0.22
            scored.append((score, action))
        if len(scored) < max(12, len(actions) // 8):
            return actions[:max(limit, min(len(actions), limit + 24))]
        exploit_budget = max(12, int(limit * (0.82 if stagnant < 14 else 0.70)))
        explore_budget = max(6, limit - exploit_budget)
        kept = [a for _score, a in sorted(scored, reverse=True)[:exploit_budget]]
        if unknown:
            stride = max(1, len(unknown) // explore_budget)
            offset = self.steps % stride
            kept.extend(unknown[offset::stride][:explore_budget])
        if stagnant >= 18:
            extras = [a for _score, a in sorted(scored, key=lambda x: x[0])[:max(4, limit // 10)]]
            kept.extend(extras)
        return list(dict.fromkeys(kept))[:limit]

    def _trajectory_learning(self, action, state, reward, next_state, reliability,
                             before, after, best_before):
        transition = {
            "action": action, "state": state, "next": next_state,
            "reward": float(reward), "before": float(before), "after": float(after),
            "reliability": float(reliability), "step": int(self.steps),
        }
        self.trajectory.append(transition)
        if len(self.trajectory) > 72:
            self.trajectory = self.trajectory[-72:]

        gamma = LEARNING_CONFIG.discount_gamma
        lam = LEARNING_CONFIG.eligibility_lambda
        recent = self.trajectory[-14:]
        returns = [0.0] * len(recent)
        running = 0.0
        for idx in range(len(recent) - 1, -1, -1):
            running = float(recent[idx]["reward"]) + gamma * running
            returns[idx] = running

        breakout = best_before is not None and float(after) > float(best_before)
        for idx, (item, g_return) in enumerate(zip(recent, returns)):
            age = len(recent) - 1 - idx
            eligibility = lam ** age
            target = g_return
            if breakout and age > 0:
                ref = max(1e-6, abs(float(item["before"])) * 0.0025, abs(float(after)) * 1e-9)
                long_gain = math.asinh((float(after) - float(item["before"])) / ref)
                if long_gain > 0:
                    target += min(8.0, long_gain) * (0.78 + min(0.18, age * 0.018))
            target = max(-12.0, min(12.0, target))
            weight = max(0.14, min(1.0, float(item.get("reliability", 1.0)))) * eligibility
            old_action, old_state = item["action"], item["state"]
            self._update(self.nstep, f"global>{old_action}", target, 0.78 * weight,
                         record_outcome=False)
            for family in self._state_families(old_state)[:4]:
                self._update(self.nstep, f"{family}>{old_action}", target, 0.82 * weight,
                             record_outcome=False)

        atomic = []
        for item in recent[-8:]:
            atomic.extend(self._macro_parts(item["action"]))
        atomic = [part for part in atomic if part and part != OBSERVE_ACTION][-12:]
        if atomic:
            terminal_bonus = 0.0
            if breakout and recent:
                start_value = float(recent[max(0, len(recent) - 8)]["before"])
                ref = max(1e-6, abs(start_value) * 0.0025, abs(float(after)) * 1e-9)
                terminal_bonus = max(0.0, min(8.0, math.asinh((float(after) - start_value) / ref)))
            for length in range(2, min(6, len(atomic)) + 1):
                sequence = "|".join(atomic[-length:])
                local_rewards = [float(item["reward"]) for item in recent[-min(length, len(recent)):]]
                seq_return = 0.0
                for r in local_rewards:
                    seq_return = seq_return * gamma + r
                if breakout:
                    breakout_target = terminal_bonus * (0.82 + 0.06 * min(5, length - 1))
                    seq_return = max(seq_return + terminal_bonus * 0.34, breakout_target)
                self._update(self.trajectory_sequences, sequence,
                             max(-12.0, min(12.0, seq_return)),
                             0.72 if length <= 3 else 0.58, record_outcome=breakout)

        if breakout and len(recent) >= 3:
            # Replay successful trajectories so temporary losses can receive credit
            final_value = float(after)
            for item in recent[:-1]:
                ref = max(1e-6, abs(float(item["before"])) * 0.0025, abs(final_value) * 1e-9)
                goal_return = math.asinh((final_value - float(item["before"])) / ref)
                if goal_return <= 0:
                    continue
                replay_target = min(10.0, goal_return)
                old_action, old_state = item["action"], item["state"]
                self._update(self.nstep, f"global>{old_action}", replay_target, 0.42,
                             record_outcome=False)
                self._update(self.contexts, self._context_key(old_state, old_action),
                             replay_target, 0.28, record_outcome=False)

    def needs_isolation(self, action, state, confidence=1.0, scene_changed=False):
        if not action or action == OBSERVE_ACTION:
            return False
        stat = self.stats.get(action, {})
        _q, n, variance = self._value(stat)
        good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
        conflict = (float(stat.get("drift", 0.0)) >= 0.42 or
                    (n >= 3 and good > 0 and bad > 0 and min(good, bad) / max(1, good + bad) >= 0.24) or
                    variance > 0.55)
        return bool(n < 3 or float(confidence) < 0.72 or conflict or scene_changed)

    def _update(self, table, key, target, weight=1.0, record_outcome=True):
        stat = table.setdefault(
            key, {"n": 0, "q": 0.0, "long_q": 0.0, "recent_q": 0.0,
                  "drift": 0.0, "last_seen": 0, "v": 0.0, "good": 0, "bad": 0,
                  "zero": 0, "up": 0.0, "down": 0.0})
        stat["n"] = int(stat.get("n", 0)) + 1
        old = float(stat.get("long_q", stat.get("q", 0.0)))
        n = stat["n"]
        rate = max(0.035, 1.0 / min(n, 32))
        sample = float(target) * float(weight)
        if n >= 9 and old * sample < -0.055 and abs(sample - old) > 0.34:
            rate = max(rate, 0.17 if n < 40 else 0.12)
            stat["good"] = int(float(stat.get("good", 0)) * 0.91)
            stat["bad"] = int(float(stat.get("bad", 0)) * 0.91)
        new = old + rate * (sample - old)
        recent_old = float(stat.get("recent_q", old))
        recent_rate = 0.34 if n < 12 else 0.22
        recent_new = recent_old + recent_rate * (sample - recent_old)
        conflict = ((new * recent_new < -0.035 and abs(new - recent_new) > 0.22) or
                    abs(new - recent_new) > max(0.42, abs(new) * 0.85 + 0.12))
        drift_old = max(0.0, min(1.0, float(stat.get("drift", 0.0))))
        drift_target = 1.0 if conflict else max(0.0, min(1.0, abs(new - recent_new) / 0.9))
        drift = drift_old * (0.82 if conflict else 0.92) + drift_target * (0.18 if conflict else 0.08)
        if drift > 0.58 and n >= 8:
            new = new * 0.76 + recent_new * 0.24
            stat["good"] = int(float(stat.get("good", 0)) * 0.96)
            stat["bad"] = int(float(stat.get("bad", 0)) * 0.96)
            stat["zero"] = int(float(stat.get("zero", 0)) * 0.97)
        stat["q"] = new
        stat["long_q"] = new
        stat["recent_q"] = recent_new
        stat["drift"] = max(0.0, min(1.0, drift))
        stat["last_seen"] = int(time.time())
        err = sample - recent_new
        stat["v"] = float(stat.get("v", 0.0)) * 0.91 + err * err * 0.09
        if record_outcome:
            if sample > 0.035:
                stat["good"] = int(stat.get("good", 0)) + 1
                stat["up"] = float(stat.get("up", 0.0)) * 0.90 + sample * 0.10
                stat["down"] = float(stat.get("down", 0.0)) * 0.94
            elif sample < -0.035:
                stat["bad"] = int(stat.get("bad", 0)) + 1
                stat["down"] = float(stat.get("down", 0.0)) * 0.90 + abs(sample) * 0.10
                stat["up"] = float(stat.get("up", 0.0)) * 0.94
            else:
                stat["zero"] = int(stat.get("zero", 0)) + 1
                stat["up"] = float(stat.get("up", 0.0)) * 0.97
                stat["down"] = float(stat.get("down", 0.0)) * 0.97
        self._mark_dirty(table, key)

    @staticmethod
    def _context_key(state, action):
        return f"{state}>{action}"

    @staticmethod
    def _macro_parts(action):
        if not isinstance(action, str) or not action.startswith("macro:"):
            return (action,)
        parts = tuple(x for x in action[6:].split("|") if x and not x.startswith("macro:"))
        return parts if parts else ()

    @classmethod
    def _make_macro(cls, parts):
        flat = []
        for action in parts:
            flat.extend(cls._macro_parts(action))
        flat = [x for x in flat if x]
        if len(flat) < 2:
            return flat[0] if flat else None
        return "macro:" + "|".join(flat[:6])

    @staticmethod
    def _state_families(state):
        visual = re.search(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)", state)
        semantic = re.search(r":t([udf]):g(\d+):s(\d+):m(-?\d+)", state)
        if not semantic:
            return []
        trend, gap, stale, magnitude = semantic.groups()
        mag = int(magnitude)
        mag_bucket = max(-4, min(10, mag // 2))
        keys = [f"sem:t{trend}:g{gap}:m{mag_bucket}",
                f"stale:t{trend}:s{min(4, int(stale))}"]
        app = re.search(r":a([0-9a-f]{8})", state)
        controls = re.search(r":c([0-9a-f]{8})", state)
        if app:
            keys.append(f"L0:app:{app.group(1)}")
        if controls:
            keys.append(f"L2:controls:{controls.group(1)}:t{trend}")
        semantic_scene = re.search(r":h([0-9a-f]{8})", state)
        if semantic_scene:
            scene_hash = semantic_scene.group(1)
            keys.append(f"ui:{scene_hash[:4]}:t{trend}:g{min(3, int(gap))}")
            keys.append(f"ui2:{scene_hash[4:]}:s{min(4, int(stale))}")
        structured_scene = re.search(r":u([0-9a-f]{10})", state)
        if structured_scene:
            scene_hash = structured_scene.group(1)
            keys.append(f"scene:{scene_hash[:5]}:t{trend}:g{min(3, int(gap))}")
            keys.append(f"scene2:{scene_hash[5:]}:s{min(4, int(stale))}")
            keys.append(f"L1:scene:{scene_hash}:g{min(3, int(gap))}")
        if visual:
            phash, ehash, color, layout = visual.groups()
            for i in range(4):
                band = phash[i * 4:(i + 1) * 4]
                keys.append(f"p{i}:{band}:t{trend}:g{min(3, int(gap))}:c{color}")
            keys.append(f"e0:{ehash[:4]}:t{trend}:l{layout[:2]}")
            keys.append(f"e1:{ehash[4:]}:t{trend}:l{layout[-2:]}")
        feature_match = re.search(r":sf([01]{10}):", state)
        if feature_match:
            bits = feature_match.group(1)
            keys.append(f"features:{bits[:5]}:{bits[5:]}")
        number_match = re.search(r":nf([0-9a-f]{4})-([a-z]+)-i(-?\d+|x)-c(-?\d+|x)-l([01])-m([01]):", state)
        if number_match:
            structure, affordability, income_bucket, cost_bucket, level_changed, multiplier_changed = number_match.groups()
            keys.append(f"numbers:aff:{affordability}:i{income_bucket}:l{level_changed}:m{multiplier_changed}")
            keys.append(f"numbers2:{structure}:c{cost_bucket}:aff{affordability}")
        rate = re.search(r":v(-?\d+):a(-?\d+)", state)
        if rate:
            velocity, acceleration = rate.groups()
            keys.append(f"dyn:v{velocity}:a{acceleration}:t{trend}")
        motion = re.search(r":r([0-9a-f]{6})", state)
        if motion:
            raw_motion = motion.group(1)
            keys.append(f"motion:{raw_motion[:3]}:t{trend}")
            keys.append(f"motion2:{raw_motion[3:]}:g{min(3, int(gap))}")
        return keys

    @classmethod
    def _inverse_action(cls, action):
        direct = cls.INVERSES.get(action)
        if direct:
            return direct
        if not isinstance(action, str):
            return None
        if action.startswith("hold:"):
            parts = action.split(":")
            if len(parts) == 3:
                inverse = cls.INVERSES.get(f"key:{parts[1]}")
                if inverse:
                    return f"hold:{inverse.split(':', 1)[1]}:{parts[2]}"
        if action.startswith("pulse:"):
            parts = action.split(":")
            if len(parts) == 5:
                inverse = cls.INVERSES.get(f"key:{parts[1]}")
                if inverse:
                    return f"pulse:{inverse.split(':', 1)[1]}:{parts[2]}:{parts[3]}:{parts[4]}"
        if action.startswith("chord:"):
            names = action.split(":", 1)[1].split("+")
            changed = False
            mapped = []
            for name in names:
                inverse = cls.INVERSES.get(f"key:{name}")
                if inverse:
                    mapped.append(inverse.split(":", 1)[1])
                    changed = True
                else:
                    mapped.append(name)
            if changed:
                return "chord:" + "+".join(mapped)
        return None

    @classmethod
    def _model_state(cls, state):

        families = cls._state_families(state)
        if not families:
            return "unknown"
        return "~".join(families[:4])

    def _update_model(self, state, action, reward, next_state, reliability=1.0):
        current = self._model_state(state)
        following = self._model_state(next_state)
        key = f"{current}>{action}"
        self._update(self.models, key, reward, max(0.18, min(1.0, reliability)),
                     record_outcome=reliability >= 0.30)
        stat = self.models.get(key, {})
        if not isinstance(stat.get("next"), dict):
            stat["next"] = {}
        transitions = stat["next"]
        transitions[following] = float(transitions.get(following, 0.0)) + max(
            0.12, min(1.0, reliability))
        if len(transitions) > 9:
            keep = sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:9]
            stat["next"] = dict(keep)
            transitions = stat["next"]
        total = sum(float(value) for value in transitions.values())
        if total > 160.0:
            for name in tuple(transitions):
                transitions[name] = float(transitions[name]) * 0.72

    def _effect_value(self, state, action):
        values = []
        keys = [(f"global>{action}", 0.72)]
        keys.extend((f"{family}>{action}", 1.0) for family in self._state_families(state)[:4])
        for key, base_weight in keys:
            stat = self.effects.get(key, {})
            n = float(stat.get("n", 0.0)) if isinstance(stat, dict) else 0.0
            if n <= 0:
                continue
            utility = float(stat.get("utility", 0.0))
            uncertainty = float(stat.get("uncertainty", 0.0))
            weight = base_weight * min(4.0, 0.65 + math.log1p(n))
            values.append((utility, uncertainty, n, weight))
        if not values:
            return 0.0, 0.0, 0.0
        denom = max(1e-9, sum(item[3] for item in values))
        utility = sum(item[0] * item[3] for item in values) / denom
        uncertainty = sum(item[1] * item[3] for item in values) / denom
        n = sum(item[2] for item in values)
        return utility, n, uncertainty

    @staticmethod
    def _numeric_effect_utility(signals):
        if not isinstance(signals, dict):
            return 0.0
        weights = {
            "TARGET": 1.00, "RESOURCE": 0.62, "INCOME": 1.08, "RATE": 0.92,
            "LEVEL": 0.78, "MULTIPLIER": 1.02, "HEALTH": 0.45,
            "CAPACITY": 0.42, "PROGRESS": 0.42, "COUNT": 0.22,
            "COST": -0.18, "TIME": -0.10,
        }
        growth = 0.0
        resource = 0.0
        utility = 0.0
        for role, signal in signals.items():
            try:
                signal = max(-8.0, min(8.0, float(signal)))
            except Exception:
                continue
            role = str(role).upper()
            contribution = weights.get(role, 0.08) * signal
            utility += contribution
            if role in {"INCOME", "RATE", "LEVEL", "MULTIPLIER", "CAPACITY"}:
                growth += max(0.0, contribution)
            if role in {"TARGET", "RESOURCE"}:
                resource += contribution
        # A temporary resource loss is much less harmful when it buys persistent growth.
        if resource < 0.0 and growth > 0.0:
            utility += min(-resource * 0.80, growth * 0.72)
        return max(-10.0, min(10.0, utility))

    def record_numeric_effect(self, action, state, before_numbers, after_numbers,
                              reliability=1.0, delay=0.0):
        if not action or not isinstance(before_numbers, dict) or not isinstance(after_numbers, dict):
            return
        signals, deltas = {}, {}
        for role in set(before_numbers) & set(after_numbers):
            before_item, after_item = before_numbers.get(role), after_numbers.get(role)
            if not isinstance(before_item, dict) or not isinstance(after_item, dict):
                continue
            try:
                before_value = float(before_item.get("value"))
                after_value = float(after_item.get("value"))
                confidence = math.sqrt(max(0.0, float(before_item.get("confidence", 0.0))) *
                                       max(0.0, float(after_item.get("confidence", 0.0))))
            except Exception:
                continue
            if confidence < 0.28:
                continue
            delta = after_value - before_value
            reference = max(1e-6, abs(before_value) * 0.01, abs(after_value) * 1e-8, 1.0)
            signal = math.asinh(delta / reference) * confidence
            role = str(role).upper()
            signals[role] = max(-8.0, min(8.0, signal))
            deltas[role] = delta
        if not signals:
            return
        utility = self._numeric_effect_utility(signals)
        reliability = max(0.08, min(1.0, float(reliability)))
        for key in [f"global>{action}"] + [f"{family}>{action}" for family in self._state_families(state)[:4]]:
            stat = self.effects.setdefault(key, {"n": 0.0, "utility": 0.0, "m2": 0.0,
                                                  "uncertainty": 0.0, "signals": {}, "delay": 0.0})
            old_n = float(stat.get("n", 0.0))
            new_n = old_n + reliability
            old_mean = float(stat.get("utility", 0.0))
            diff = utility - old_mean
            new_mean = old_mean + diff * reliability / max(1e-9, new_n)
            m2 = float(stat.get("m2", 0.0)) + reliability * diff * (utility - new_mean)
            stat["n"], stat["utility"], stat["m2"] = new_n, new_mean, m2
            stat["uncertainty"] = math.sqrt(max(0.0, m2 / max(1.0, new_n)))
            stat["delay"] = float(stat.get("delay", 0.0)) * 0.84 + max(0.0, float(delay)) * 0.16
            signal_stats = stat.setdefault("signals", {})
            for role, signal in signals.items():
                role_stat = signal_stats.setdefault(role, {"n": 0.0, "mean": 0.0, "delta": 0.0})
                rn = float(role_stat.get("n", 0.0)) + reliability
                role_stat["mean"] = float(role_stat.get("mean", 0.0)) + (signal - float(role_stat.get("mean", 0.0))) * reliability / max(1e-9, rn)
                role_stat["delta"] = float(role_stat.get("delta", 0.0)) * 0.84 + float(deltas.get(role, 0.0)) * 0.16
                role_stat["n"] = rn
            self._mark_dirty(self.effects, key)

    def _model_lookahead(self, state, action, actions, cache=None):
        current = self._model_state(state)
        stat = self.models.get(f"{current}>{action}", {})
        q, n, variance = self._value(stat)
        effect_q, effect_n, effect_uncertainty = self._effect_value(state, action)
        if effect_n:
            effect_weight = min(0.34, 0.07 + math.log1p(effect_n) * 0.055)
            q += effect_q * effect_weight - min(0.22, effect_uncertainty * LEARNING_CONFIG.uncertainty_penalty)
        transitions = stat.get("next", {}) if isinstance(stat, dict) else {}
        if n < 2 or not isinstance(transitions, dict) or not transitions:
            return q, n, variance + effect_uncertainty * 0.15
        action_list = list(dict.fromkeys(actions))
        memo = cache if cache is not None else {}

        def best_from(model_state, depth):
            key = (model_state, depth)
            if key in memo:
                return memo[key]
            if depth <= 0:
                return 0.0
            ranked = []
            for candidate in action_list:
                cstat = self.models.get(f"{model_state}>{candidate}", {})
                cq, cn, cv = self._value(cstat)
                if cn <= 0:
                    continue
                # State-family causal effects are not exact for synthetic model states, so use global effects here.
                estat = self.effects.get(f"global>{candidate}", {})
                en = float(estat.get("n", 0.0)) if isinstance(estat, dict) else 0.0
                if en > 0:
                    cq += float(estat.get("utility", 0.0)) * min(0.26, 0.05 + math.log1p(en) * 0.045)
                    cq -= min(0.18, float(estat.get("uncertainty", 0.0)) * LEARNING_CONFIG.uncertainty_penalty)
                cq -= min(0.20, math.sqrt(max(0.0, cv)) * 0.025)
                ranked.append((cq, candidate, cstat, cn))
            if not ranked:
                memo[key] = 0.0
                return 0.0
            ranked.sort(reverse=True, key=lambda item: item[0])
            best = -float("inf")
            for immediate, candidate, cstat, cn in ranked[:LEARNING_CONFIG.beam_width]:
                future = 0.0
                next_map = cstat.get("next", {}) if isinstance(cstat, dict) else {}
                if depth > 1 and isinstance(next_map, dict) and next_map:
                    total = sum(max(0.0, float(v)) for v in next_map.values())
                    if total > 0:
                        for next_model_state, count in sorted(next_map.items(), key=lambda item: float(item[1]), reverse=True)[:LEARNING_CONFIG.transition_branches]:
                            future += max(0.0, float(count)) / total * best_from(next_model_state, depth - 1)
                value = immediate + LEARNING_CONFIG.model_discount * future
                if value > best:
                    best = value
            memo[key] = 0.0 if best == -float("inf") else best
            return memo[key]

        total = sum(max(0.0, float(value)) for value in transitions.values())
        if total <= 0:
            return q, n, variance + effect_uncertainty * 0.15
        expected_future = 0.0
        for following, count in sorted(transitions.items(), key=lambda item: float(item[1]), reverse=True)[:LEARNING_CONFIG.transition_branches]:
            expected_future += max(0.0, float(count)) / total * best_from(
                following, max(1, LEARNING_CONFIG.beam_depth - 1))
        return q + LEARNING_CONFIG.model_discount * expected_future, n, variance + effect_uncertainty * 0.15

    @staticmethod
    def _action_aliases(action):

        if not isinstance(action, str):
            return []
        if action.startswith("click:control:"):
            control_id = action.split(":", 2)[2]
            base_id = re.sub(r"_r\d+c\d+$", "", control_id)
            aliases = [f"control:{base_id}"]
            semantic_types = ("claim_reward", "permanent_upgrade", "upgrade", "temporary_boost",
                              "purchase", "prestige", "reset", "sell", "navigate", "continue", "start")
            matched_type = next((name for name in semantic_types if base_id.startswith(name + "_")), "")
            if matched_type:
                aliases.append(f"control:type:{matched_type}")
            if "upgrade" in base_id or "boost" in base_id or "increase" in base_id:
                aliases.append("control:positive_upgrade")
            return aliases
        if action.startswith(("mouse:", "pointer:", "click:", "wheel:", "drag:", "tap:")):
            try:
                point = Learner._mouse_point(action)
                if point is None:
                    return []
                fx, fy = point
                kind = action.split(":", 1)[0]
                family = "click:left" if kind == "mouse" else kind
                if kind == "click":
                    family += ":" + action.split(":")[1]
                elif kind == "wheel":
                    wheel_parts = action.split(":")
                    family += ":" + wheel_parts[1] + (":positive" if int(wheel_parts[2]) > 0 else ":negative")
                elif kind == "drag":
                    family += ":" + action.split(":")[1]
                elif kind == "tap":
                    tap_parts = action.split(":")
                    family += ":" + tap_parts[1] + f":r{tap_parts[5]}:i{tap_parts[6]}"
                aliases = ["mouse:" + family]
                for bins in (6, 12, 24):
                    qx = max(0, min(bins - 1, int(fx * bins)))
                    qy = max(0, min(bins - 1, int(fy * bins)))
                    aliases.append(f"{family}:m{bins}:{qx}:{qy}")
                    if kind == "mouse":
                        aliases.append(f"m{bins}:{qx}:{qy}")
                return aliases
            except Exception:
                return []

        direction = {
            "W": "up", "UP": "up", "S": "down", "DOWN": "down",
            "A": "left", "LEFT": "left", "D": "right", "RIGHT": "right",
        }
        try:
            if action.startswith("key:"):
                name = action.split(":", 1)[1]
                aliases = [f"kbd:key:{name}"]
                if name in direction:
                    aliases.append(f"kbd:dir:{direction[name]}")
                if len(name) == 1 and name.isalpha():
                    aliases.append("kbd:letter")
                elif len(name) == 1 and name.isdigit():
                    aliases.append("kbd:number")
                return aliases
            if action.startswith("hold:"):
                _kind, name, milliseconds = action.split(":")
                duration = int(milliseconds)
                aliases = [f"kbd:key:{name}",
                           f"kbd:hold:{name}:{'long' if duration >= 450 else 'short'}"]
                if name in direction:
                    aliases.append(f"kbd:dir:{direction[name]}")
                return aliases
            if action.startswith("pulse:"):
                _kind, name, milliseconds, repeats, interval = action.split(":")
                duration = int(milliseconds)
                count = int(repeats)
                gap = int(interval)
                aliases = [f"kbd:key:{name}", f"kbd:pulse:{name}:r{count}",
                           f"kbd:pulse:{name}:i{max(20, round(gap / 20) * 20)}",
                           f"kbd:hold:{name}:{'long' if duration >= 450 else 'short'}"]
                if name in direction:
                    aliases.append(f"kbd:dir:{direction[name]}")
                return aliases
            if action.startswith("chord:"):
                names = action.split(":", 1)[1].split("+")
                aliases = ["kbd:chord:" + "+".join(sorted(names))]
                aliases.extend(f"kbd:key:{name}" for name in names)
                return aliases
        except Exception:
            return []
        return []

    @staticmethod
    def _mouse_point(action):
        if not isinstance(action, str):
            return None
        try:
            parts = action.split(":")
            if parts[0] == "mouse" and len(parts) == 3:
                grid, sx, sy = 20, int(parts[1]), int(parts[2])
            elif parts[0] in {"mouse", "pointer"} and len(parts) == 4:
                grid, sx, sy = int(parts[1]), int(parts[2]), int(parts[3])
            elif parts[0] == "click" and len(parts) == 6:
                grid, sx, sy = int(parts[2]), int(parts[3]), int(parts[4])
            elif parts[0] == "wheel" and len(parts) == 6:
                grid, sx, sy = int(parts[3]), int(parts[4]), int(parts[5])
            elif parts[0] == "drag" and len(parts) == 8:
                grid = int(parts[2])
                sx = (int(parts[3]) + int(parts[5])) * 0.5
                sy = (int(parts[4]) + int(parts[6])) * 0.5
            elif parts[0] == "tap" and len(parts) == 8:
                grid, sx, sy = int(parts[2]), int(parts[3]), int(parts[4])
            else:
                return None
            grid = max(2, int(grid))
            return max(0.0, min(1.0, sx / grid)), max(0.0, min(1.0, sy / grid))
        except Exception:
            return None

    def _spatial_value(self, state, action):

        target = self._mouse_point(action)
        if target is None:
            return 0.0, 0, 0.0
        tx, ty = target
        weighted_q = variance = weight_sum = 0.0
        evidence_n = 0

        sigma2 = 0.070 ** 2
        for other, stat in self.stats.items():
            point = self._mouse_point(other)
            if point is None or other == action:
                continue
            dx, dy = point[0] - tx, point[1] - ty
            d2 = dx * dx + dy * dy
            if d2 > 0.20 ** 2:
                continue
            q, n, v = self._value(stat)
            if not n:
                continue
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, other), {}))
            local_q = (0.42 * q + 0.58 * cq) if cn else q
            local_v = (0.55 * v + 0.45 * cv) if cn else v
            kernel = math.exp(-0.5 * d2 / sigma2)
            sample_weight = kernel * min(3.6, 0.58 + math.log1p(n + cn))
            weighted_q += local_q * sample_weight
            variance += local_v * sample_weight
            weight_sum += sample_weight
            evidence_n += min(12, n + cn)
        if weight_sum < 0.20:
            return 0.0, 0, 0.0

        effective_n = max(1, min(48, int(round(evidence_n * min(1.0, weight_sum / 7.0)))))
        return weighted_q / weight_sum, effective_n, variance / weight_sum

    def _alias_value(self, state, action):
        aliases = self._action_aliases(action)
        if not aliases:
            return 0.0, 0, 0.0
        semantic = self._state_families(state)[:2]
        weighted_q = variance = weight_sum = 0.0
        total_n = 0
        for alias in aliases:
            keys = [(f"global>{alias}", 0.55)]
            keys.extend((f"{family}>{alias}", 1.0) for family in semantic)
            for key, scale in keys:
                stat = self.aliases.get(key, {})
                q, n, v = self._value(stat)
                if not n:
                    continue
                w = scale * min(3.4, 0.65 + math.log1p(n))
                weighted_q += q * w
                variance += v * w
                weight_sum += w
                total_n += n
        if not weight_sum:
            return 0.0, 0, 0.0
        return weighted_q / weight_sum, total_n, variance / weight_sum

    def _update_aliases(self, state, action, reward, contextual_target,
                        record_outcome=True):
        aliases = self._action_aliases(action)
        if not aliases:
            return
        semantic = self._state_families(state)[:2]
        for alias in aliases:
            self._update(self.aliases, f"global>{alias}", reward, 0.62,
                         record_outcome=record_outcome)
            for family in semantic:
                self._update(self.aliases, f"{family}>{alias}", contextual_target, 0.72,
                             record_outcome=record_outcome)

    def _family_value(self, state, action):
        weighted_q = 0.0
        weight_sum = 0.0
        variance = 0.0
        total_n = 0
        good = bad = 0
        for family in self._state_families(state):
            stat = self.families.get(f"{family}>{action}", {})
            q, n, v = self._value(stat)
            if not n:
                continue
            hierarchy = (1.22 if family.startswith("L2:") else
                         1.00 if family.startswith("L1:") else
                         0.76 if family.startswith("L0:") else 0.92)
            w = min(4.2, math.log1p(n) + 0.55) * hierarchy
            weighted_q += q * w
            variance += v * w
            weight_sum += w
            total_n += n
            good += int(stat.get("good", 0))
            bad += int(stat.get("bad", 0))
        if not weight_sum:
            return 0.0, 0, 0.0, 0, 0
        return weighted_q / weight_sum, total_n, variance / weight_sum, good, bad

    def _future_value(self, state, actions=None):
        best = 0.0
        iterable = actions or []
        if not iterable:
            prefix = f"{state}>"
            iterable = [k[len(prefix):] for k in self.contexts if k.startswith(prefix)]
        for action in iterable:
            q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, _fv, _fg, _fb = self._family_value(state, action)
            if n or fn:
                blended = q if n and not fn else fq if fn and not n else 0.70 * q + 0.30 * fq
                best = max(best, blended)
        return best

    @staticmethod
    def _success_posterior(stat):
        good = max(0.0, float(stat.get("good", 0)))
        bad = max(0.0, float(stat.get("bad", 0)))
        zero = max(0.0, float(stat.get("zero", 0)))
        alpha = good + 1.0
        beta = bad + 1.0 + zero * 0.58
        total = alpha + beta
        mean = alpha / max(1e-9, total)
        variance = alpha * beta / max(1e-9, total * total * (total + 1.0))
        lower = max(0.0, mean - 1.15 * math.sqrt(max(0.0, variance)))
        return mean, lower, alpha, beta

    @staticmethod
    def _raw_reward(before, after, confidence=1.0):
        delta = after - before
        reference = max(1e-6, abs(before) * 0.0025, abs(after) * 1e-9)
        reward = math.asinh(delta / reference) if delta else 0.0
        if before > 0 and after > 0 and delta:
            reward += max(-2.0, min(2.0, math.log(after / before) * 0.42))
        conf = max(0.0, min(1.0, float(confidence)))
        reliability = max(0.03, min(1.0, (conf - 0.20) / 0.68))
        return max(-8.0, min(8.0, reward * reliability)), reliability, reference

    def passive_value(self, state):
        global_q, global_n, _v = self._value(self.passive.get("global", {}))
        values = []
        for family in self._state_families(state)[:5]:
            q, n, _v = self._value(self.passive_families.get(family, {}))
            if n:
                values.append((q, min(3.0, 0.7 + math.log1p(n))))
        if not values:
            return global_q if global_n else 0.0
        denom = sum(w for _q, w in values)
        family_q = sum(q * w for q, w in values) / max(1e-9, denom)
        return 0.66 * family_q + 0.34 * global_q if global_n else family_q

    def observe_passive(self, before, after, state, confidence=1.0, elapsed_seconds=1.0):
        reward, _reliability, _reference = self._raw_reward(before, after, confidence)
        rate_signal = self._rate_signal(before, after, elapsed_seconds, confidence)
        self._update(self.passive, "global", reward, 0.96)
        self._update(self.passive_rates, "global", rate_signal, 1.0, record_outcome=False)
        for family in self._state_families(state)[:5]:
            self._update(self.passive_families, family, reward, 0.96)
            self._update(self.passive_rates, family, rate_signal, 1.0, record_outcome=False)
        return reward

    def _outcome_signal(self, action):

        trail = self.outcomes.get(action, [])
        values = []
        for item in trail[-10:] if isinstance(trail, list) else []:
            try:
                values.append(float(item[0] if isinstance(item, (list, tuple)) else item))
            except Exception:
                continue
        if not values:
            return 0.0, 0.0, 0.0
        ordered = sorted(values)
        median = ordered[len(ordered) // 2]
        downside = max(0.0, -ordered[max(0, len(ordered) // 5)])
        trend = 0.0
        if len(values) >= 4:
            split = max(2, len(values) // 2)
            old = sum(values[:split]) / split
            new = sum(values[split:]) / max(1, len(values) - split)
            trend = max(-2.5, min(2.5, new - old))
        return median, trend, downside

    def _outcome_distribution(self, action):

        trail = self.outcomes.get(action, [])
        values = []
        for item in trail[-12:] if isinstance(trail, list) else []:
            try:
                values.append(float(item[0] if isinstance(item, (list, tuple)) else item))
            except Exception:
                continue
        if not values:
            return 0.0, 0.0, 0.0, 0.5, 0
        ordered = sorted(values)
        n = len(ordered)
        q25 = ordered[max(0, int((n - 1) * 0.25))]
        q75 = ordered[min(n - 1, int((n - 1) * 0.75))]
        tail_n = max(1, int(math.ceil(n * 0.25)))
        cvar = sum(ordered[:tail_n]) / tail_n
        positive = sum(value > 0.035 for value in values) / n
        return q25, q75, cvar, positive, n

    def expand_actions(self, actions, state, stagnant, limit=5):

        base = list(dict.fromkeys(a for a in actions if a and not a.startswith("macro:")))
        if not base or limit <= 0:
            return base
        allowed = set(base)
        ranked = []

        for sequence, stat in self.sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 6 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            context_values = []
            for family in self._state_families(state)[:4]:
                sq, sn, sv = self._value(self.sequence_contexts.get(f"{family}>{sequence}", {}))
                if sn:
                    context_values.append((sq, sn, sv))
            if context_values:
                weights = [min(3.0, 0.65 + math.log1p(sn)) for _sq, sn, _sv in context_values]
                denom = max(1e-9, sum(weights))
                contextual_q = sum(sq * w for (sq, _sn, _sv), w in zip(context_values, weights)) / denom
                contextual_v = sum(sv * w for (_sq, _sn, sv), w in zip(context_values, weights)) / denom
                contextual_n = sum(sn for _sq, sn, _sv in context_values)
            else:
                contextual_q = contextual_v = 0.0
                contextual_n = 0
            success, lower, _a, _b = self._success_posterior(stat)
            threshold_n = 2 if stagnant > 24 else 3
            threshold_q = 0.02 if stagnant > 38 else 0.08
            blended_q = q if not contextual_n else 0.56 * q + 0.44 * contextual_q
            effective_n = n + min(8, contextual_n)
            if effective_n >= threshold_n and blended_q > threshold_q and success >= 0.51:
                score = blended_q + 0.16 * (success - 0.5) + 0.12 * (lower - 0.35)
                score += min(0.14, math.log1p(effective_n) * 0.026)
                score -= min(0.11, math.sqrt(max(0.0, v + contextual_v * 0.35)) * 0.025)
                ranked.append((score, self._make_macro(parts)))

        for sequence, stat in self.trajectory_sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 6 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            if n < (2 if stagnant > 18 else 3):
                continue
            success, lower, _a, _b = self._success_posterior(stat)
            # Trajectory replay may contain temporary-loss prefixes; long-return q is intentional.
            threshold = -0.04 if stagnant > 28 else 0.10
            if q > threshold or (stagnant > 20 and success >= 0.46):
                score = q + 0.10 * (success - 0.5) + 0.06 * (lower - 0.30)
                score -= min(0.10, math.sqrt(max(0.0, v)) * 0.018)
                ranked.append((score, self._make_macro(parts)))

        for action in base:
            q, n, v = self._value(self.stats.get(action, {}))
            stat = self.stats.get(action, {})
            success, lower, _a, _b = self._success_posterior(stat)
            if n >= 5 and q > 0.16 and success >= 0.62 and lower >= 0.42:
                score = q + 0.12 * success - min(0.08, math.sqrt(max(0.0, v)) * 0.02)
                ranked.append((score, self._make_macro((action, action))))
                if n >= 12 and q > 0.34 and success >= 0.72:
                    ranked.append((score * 0.94, self._make_macro((action, action, action))))

        out = list(base)
        seen = set(out)
        for _score, macro in sorted(ranked, reverse=True):
            if macro and macro not in seen:
                out.append(macro)
                seen.add(macro)
                if len(out) >= len(base) + limit:
                    break
        return out

    def choose_group(self, groups, state, stagnant, priors=None):
        priors = priors or {}
        available = {name: list(dict.fromkeys(actions)) for name, actions in groups.items() if actions}
        if not available:
            return None
        if len(available) == 1:
            return next(iter(available))
        epsilon = max(0.055, 0.22 * math.exp(-self.steps / 1200.0))
        if stagnant > 14:
            epsilon = max(epsilon, 0.24)
        if stagnant > 34:
            epsilon = max(epsilon, 0.38)
        scored = []
        for name, actions in available.items():
            ranked = []
            sample_n = 0
            for action in actions[:48]:
                quality = self.action_quality(action, state)
                stat = self.stats.get(action, {})
                _q, n, _v = self._value(stat)
                sample_n += min(8, n)
                prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
                ranked.append(quality + (prior - 0.50) * 0.13)
            ranked.sort(reverse=True)
            head = ranked[:min(6, len(ranked))]
            exploitation = (max(head) if head else 0.0) * 0.64
            exploitation += (sum(head) / len(head) if head else 0.0) * 0.36
            novelty = 0.34 / math.sqrt(1.0 + sample_n / max(1, len(actions)))
            breadth_penalty = min(0.10, math.log1p(len(actions)) * 0.012)
            scored.append((exploitation + novelty - breadth_penalty, name))
        if random.random() < epsilon:
            floor = min(score for score, _name in scored)
            weights = [max(0.05, score - floor + 0.18) for score, _name in scored]
            pick = random.random() * sum(weights)
            for weight, (_score, name) in zip(weights, scored):
                pick -= weight
                if pick <= 0:
                    return name
        return max(scored)[1]

    def choose(self, actions, state, stagnant, priors=None):
        priors = priors or {}
        if not actions:
            return None
        lookahead_cache = {}
        spatial_cache = {}

        def spatial_value(action):
            point = self._mouse_point(action)
            if point is None:
                return 0.0, 0, 0.0
            key = (round(point[0], 4), round(point[1], 4))
            if key not in spatial_cache:
                spatial_cache[key] = self._spatial_value(state, action)
            return spatial_cache[key]
        epsilon = max(LEARNING_CONFIG.exploration_min,
                      LEARNING_CONFIG.exploration_initial * math.exp(-self.steps / LEARNING_CONFIG.exploration_decay_steps))
        proven = False
        if stagnant < 10:
            for candidate in actions:
                stat = self.stats.get(candidate, {})
                q, n, _v = self._value(stat)
                good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
                zero = int(stat.get("zero", 0))
                success, lower, _a, _b = self._success_posterior(stat)
                if n >= 8 and q > 0.16 and success >= 0.64 and lower >= 0.47:
                    proven = True
                    break
            if proven:
                epsilon = max(0.018, epsilon * 0.42)
        if stagnant > LEARNING_CONFIG.stagnation_medium:
            epsilon = max(epsilon, LEARNING_CONFIG.exploration_medium)
        if stagnant > LEARNING_CONFIG.stagnation_high:
            epsilon = max(epsilon, LEARNING_CONFIG.exploration_high)
        if stagnant > LEARNING_CONFIG.stagnation_extreme:
            epsilon = max(epsilon, LEARNING_CONFIG.exploration_extreme)
        if random.random() < epsilon:
            weights = []
            for action in actions:
                _q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
                _fq, fn, _fv, _fg, _fb = self._family_value(state, action)
                _aq, an, _av = self._alias_value(state, action)
                sq, sn, _sv = spatial_value(action)
                gq, gn, _gv = self._value(self.stats.get(action, {}))
                mq, mn, _mv = self._model_lookahead(
                    state, action, actions, lookahead_cache)
                stat = self.stats.get(action, {})
                bad, good = int(stat.get("bad", 0)), int(stat.get("good", 0))
                zero = int(stat.get("zero", 0))
                _mean_success, lower_success, _a, _b = self._success_posterior(stat)
                recent_median, recent_trend, recent_downside = self._outcome_signal(action)
                q25, q75, cvar, positive_rate, distribution_n = self._outcome_distribution(action)
                risk = 0.72 + 0.56 * lower_success
                risk *= max(0.34, min(1.38, 1.0 + recent_median * 0.10 + recent_trend * 0.055
                                                   - recent_downside * 0.045))
                if distribution_n >= 4:

                    if stagnant < 18:
                        risk *= max(0.28, min(1.45, 0.84 + positive_rate * 0.36 + q25 * 0.045
                                                   + cvar * 0.028))
                    else:
                        risk *= max(0.34, min(1.65, 0.82 + positive_rate * 0.24 + q75 * 0.050
                                                   - max(0.0, -cvar) * 0.018))
                if gn >= 8 and bad > good * 2 + 2 and gq < -0.08:
                    risk = 0.20
                if gn >= 8 and zero / max(1, gn) > 0.78 and gq <= 0.02:
                    risk *= 0.46
                if action.startswith("macro:"):
                    risk *= 0.82
                if mn >= 4 and mq < -0.18:
                    risk *= max(0.24, 1.0 + mq * 0.30)
                if sn >= 3:

                    risk *= max(0.42, min(1.42, 1.0 + sq * 0.22))
                prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
                prior_weight = 0.76 + 0.48 * prior if (n + fn + an + gn + sn * 0.08) < 5 else 1.0
                weights.append(risk * prior_weight / math.sqrt(
                    n + fn * 0.12 + an * 0.10 + gn * 0.08 + mn * 0.10 + sn * 0.055 + 1.0))
            total = sum(weights)
            if total > 0:
                pick = random.random() * total
                for action, weight in zip(actions, weights):
                    pick -= weight
                    if pick <= 0:
                        return action
            return actions[-1]

        total = max(3, self.steps + 2)
        best_action, best_value = None, -float("inf")
        inverse = self._inverse_action(self.last_action) if self.last_reward < -0.08 else None
        for action in actions:
            gq, gn, gv = self._value(self.stats.get(action, {}))
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, fv, fgood, fbad = self._family_value(state, action)
            aq, an, av = self._alias_value(state, action)
            sq, sn, sv = spatial_value(action)
            nq, nn, nv = self._nstep_value(state, action)
            rq, rn, rv = self._value(self.rates.get(action, {}))
            iq, inn, iv = self.influence_value(state, action)
            xq, xn, xv = self._sequence_value(action, state)
            pq, pn, _ = self._value(self.pairs.get(f"{self.last_action}>{action}", {}))
            tq, tn, _ = self._value(
                self.triples.get(f"{self.prev_action}>{self.last_action}>{action}", {}))
            mq, mn, mv = self._model_lookahead(
                state, action, actions, lookahead_cache)

            if cn:
                base = 0.36 * gq + 0.44 * cq + 0.14 * fq + (0.06 * aq if an else 0.0)
            elif fn:
                base = 0.49 * gq + 0.39 * fq + (0.12 * aq if an else 0.0)
            elif an:

                base = 0.72 * gq + 0.28 * aq
            else:
                base = gq
            if sn:

                spatial_weight = 0.12 if cn else (0.18 if gn else 0.30)
                spatial_weight *= min(1.0, 0.45 + math.log1p(sn) / 3.8)
                base = base * (1.0 - spatial_weight) + sq * spatial_weight
            value = base
            stat = self.stats.get(action, {})
            short_return, short_n, long_return, return_n = self._horizon_value(stat)
            if return_n or short_n:
                horizon_signal = long_return if stagnant >= 12 else (0.58 * short_return + 0.42 * long_return)
                horizon_weight = min(0.34, 0.08 + max(0, stagnant) * 0.0065)
                value += horizon_signal * horizon_weight
            if nn:
                nstep_weight = min(0.46, 0.14 + math.log1p(nn) * 0.055)
                if stagnant >= 10:
                    nstep_weight = min(0.58, nstep_weight + stagnant * 0.004)
                value = value * (1.0 - nstep_weight) + nq * nstep_weight
            if rn:
                value += max(-0.38, min(0.42, rq * (0.10 if stagnant < 12 else 0.15)))
            if inn:
                value += max(-0.22, min(0.34, iq * 0.16))
            if xn:
                sequence_weight = min(0.62, 0.24 + math.log1p(xn) * 0.075)
                value = value * (1.0 - sequence_weight) + xq * sequence_weight
                if xq > 0.20:
                    value += min(0.34, xq * 0.055)
            if self.last_action:
                value += 0.22 * pq
            if self.prev_action and self.last_action:
                value += 0.10 * tq
            if mn:
                model_trust = min(0.30, 0.055 + math.log1p(mn) * 0.050)
                value = value * (1.0 - model_trust) + mq * model_trust

            stat = self.stats.get(action, {})
            good = int(stat.get("good", 0)) + fgood
            bad = int(stat.get("bad", 0)) + fbad
            zero = int(stat.get("zero", 0))
            success, lower_success, alpha, beta = self._success_posterior(stat)
            try:
                sampled_success = random.betavariate(alpha, beta)
            except Exception:
                sampled_success = success
            value += (0.15 * (success - 0.5) + 0.10 * (sampled_success - 0.5) +
                      0.14 * (lower_success - 0.35))
            recent_median, recent_trend, recent_downside = self._outcome_signal(action)
            value += max(-0.34, min(0.34, recent_median * 0.11 + recent_trend * 0.075
                                    - recent_downside * 0.065))
            q25, q75, cvar, positive_rate, distribution_n = self._outcome_distribution(action)
            if distribution_n >= 4:
                spread = max(0.0, q75 - q25)
                if stagnant < 16:
                    value += max(-0.32, min(0.28, q25 * 0.070 + cvar * 0.050 +
                                             (positive_rate - 0.50) * 0.16 - spread * 0.016))
                else:
                    value += max(-0.20, min(0.38, q75 * 0.080 +
                                             (positive_rate - 0.45) * 0.12 -
                                             max(0.0, -cvar) * 0.026))

            n_eff = (gn * 0.30 + cn + fn * 0.13 + an * 0.10 + sn * 0.07 +
                     pn * 0.15 + tn * 0.07 + mn * 0.14 + nn * 0.16 + rn * 0.08 +
                     inn * 0.05 + xn * 0.18)
            prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
            value += (prior - 0.50) * 0.18 / (1.0 + math.sqrt(max(0.0, n_eff)))
            ucb_scale = 0.25 if proven else 0.48
            value += ucb_scale * math.sqrt(math.log(total + 1.0) / (n_eff + 1.0))
            variance = max(0.0, gv + cv + fv + av * 0.35 + sv * 0.20 + mv * 0.28 +
                           nv * 0.24 + rv * 0.12 + iv * 0.08 + xv * 0.18)
            value += min(0.16, 0.052 * math.sqrt(variance))
            if n_eff > 8:
                value -= min(0.15, 0.025 * math.sqrt(variance))

            if gn >= 6:
                neutral_rate = zero / max(1, gn)
                if neutral_rate > 0.62 and gq <= 0.04:
                    value -= min(0.34, (neutral_rate - 0.62) * 0.72)
                downside = float(stat.get("down", 0.0))
                if downside > 0.0:
                    value -= min(0.24, downside * 0.035)

            recent = self.recent.get(action, {})
            if recent:
                age = max(0, self.steps - int(recent.get("step", self.steps)))
                value += float(recent.get("r", 0.0)) * 0.27 * math.exp(-age / 105.0)

            if gn >= 7 and bad > good * 2 + 2 and gq < -0.10:
                value -= min(1.05, 0.080 * (bad - good))
            if cn == 0 and fn == 0 and an == 0:
                value += 0.085
            if inverse and action == inverse:
                value += min(0.42, 0.15 + abs(self.last_reward) * 0.08)
            if action.startswith("macro:") and gn < 2:
                value -= 0.06

            recent_count = self.action_trace[-7:].count(action)
            recent_reward = float(recent.get("r", 0.0)) if recent else 0.0
            if recent_count >= 3 and recent_reward <= 0.02:
                value -= 0.10 * (recent_count - 2)
            elif action == self.last_action and self.last_reward > 0.14 and recent_reward > 0.08:

                value += min(0.30, 0.09 + self.last_reward * 0.055)
            value += random.random() * 1e-6
            if value > best_value:
                best_action, best_value = action, value
        return best_action

    def learn(self, action, before, after, state, next_state, confidence=1.0, actions=None,
              action_started=None, observed_at=None, elapsed_seconds=None, visual_change=0.0):
        delta = after - before
        reward, reliability, reference = self._raw_reward(before, after, confidence)
        if elapsed_seconds is None:
            if action_started is not None and observed_at is not None:
                elapsed_seconds = max(0.06, float(observed_at) - float(action_started))
            else:
                elapsed_seconds = 1.0
        rate_signal = self._rate_signal(before, after, elapsed_seconds, confidence)
        passive_rate = self.passive_rate_value(state)
        rate_advantage = max(-5.0, min(5.0, rate_signal - passive_rate))
        acceleration = max(-5.0, min(5.0, rate_signal - float(self.last_rate_signal)))
        if action != OBSERVE_ACTION:
            reward += rate_advantage * 0.24 * reliability
            if abs(rate_signal) > 0.04:
                reward += acceleration * 0.075 * reliability
        if reliability < 0.30:
            reward *= max(0.025, (reliability / 0.30) ** 1.5)
        best_before = self.best
        if best_before is not None and after > best_before:
            best_gain = math.asinh((after - best_before) / reference)
            best_bonus = min(1.15, max(0.0, best_gain) * 0.16) * reliability
            if action != OBSERVE_ACTION:
                causal_gate = max(0.12, min(1.0, 0.18 + max(0.0, rate_advantage) * 0.24))
                best_bonus *= causal_gate
            reward += best_bonus
        if action == OBSERVE_ACTION:
            self._update(self.passive, "global", reward, 0.96)
            self._update(self.passive_rates, "global", rate_signal, 1.0, record_outcome=False)
            for family in self._state_families(state)[:5]:
                self._update(self.passive_families, family, reward, 0.96)
                self._update(self.passive_rates, family, rate_signal, 1.0, record_outcome=False)
            assignments = [(action, state, 1.0, 0.0)]
        else:
            baseline = self.passive_value(state)
            if abs(baseline) > 0.012:
                reward -= max(-5.0, min(5.0, baseline * 0.95))
            observed_at = float(observed_at if observed_at is not None else time.monotonic())
            action_started = float(action_started if action_started is not None else observed_at)
            candidates = [(action, state, action_started)]
            for item in reversed(self.history[-18:]):
                try:
                    old_action, old_state = item[0], item[1]
                    old_started = float(item[2]) if len(item) >= 3 else observed_at - 0.8
                except Exception:
                    continue
                elapsed = observed_at - old_started
                if elapsed > 12.0:
                    break
                if elapsed >= 0:
                    candidates.append((old_action, old_state, old_started))
            weighted = []
            current_scene = state.split(":x", 1)[0]
            current_families = set(self._state_families(state))
            for index, (candidate_action, candidate_state, started) in enumerate(candidates):
                elapsed = max(0.0, observed_at - started)
                probability = self.delay_probability(candidate_action, elapsed)
                candidate_scene = candidate_state.split(":x", 1)[0]
                if candidate_scene == current_scene:
                    state_weight = 1.0
                else:
                    candidate_families = set(self._state_families(candidate_state))
                    overlap = len(current_families & candidate_families) / max(1, len(current_families | candidate_families))
                    state_weight = 0.52 + 0.38 * overlap
                if index == 0:
                    probability *= 1.08
                weighted.append((candidate_action, candidate_state, elapsed, max(1e-5, probability * state_weight)))
            total_weight = sum(item[3] for item in weighted) or 1.0
            assignments = [(a, st, w / total_weight, elapsed) for a, st, elapsed, w in weighted]
        reward = max(-8.0, min(8.0, reward))
        trusted_outcome = reliability >= 0.30
        current_share = assignments[0][2] if assignments else 1.0
        current_reward = reward * current_share
        future = self._future_value(next_state, actions)
        contextual_target = current_reward + 0.32 * future
        if action != OBSERVE_ACTION:
            self._update(self.rates, action, rate_advantage, max(0.20, reliability),
                         record_outcome=trusted_outcome)
        self._update(self.stats, action, current_reward, record_outcome=trusted_outcome)
        self._update(self.contexts, self._context_key(state, action), contextual_target,
                     record_outcome=trusted_outcome)
        self._update_aliases(state, action, current_reward, contextual_target, trusted_outcome)
        for family in self._state_families(state):
            self._update(self.families, f"{family}>{action}", contextual_target, 0.80,
                         record_outcome=trusted_outcome)
        self._update_model(state, action, current_reward, next_state, reliability)
        if self.last_action:
            self._update(self.pairs, f"{self.last_action}>{action}", current_reward, 0.90,
                         record_outcome=trusted_outcome)
        if self.prev_action and self.last_action:
            self._update(self.triples, f"{self.prev_action}>{self.last_action}>{action}",
                         current_reward, 0.78, record_outcome=trusted_outcome)
        parts = self._macro_parts(action)
        if len(parts) > 1:
            for part in parts:
                self._update(self.stats, part, current_reward / max(1.0, math.sqrt(len(parts))),
                             0.48, record_outcome=trusted_outcome)
        if abs(reward) > 0.035 and action != OBSERVE_ACTION:
            for old_action, old_state, share, elapsed in assignments[1:]:
                if share < 0.025:
                    continue
                credit = reward * share
                self._update(self.stats, old_action, credit, 0.92,
                             record_outcome=trusted_outcome)
                self._update(self.contexts, self._context_key(old_state, old_action), credit, 0.88,
                             record_outcome=trusted_outcome)
                for family in self._state_families(old_state):
                    self._update(self.families, f"{family}>{old_action}", credit, 0.62,
                                 record_outcome=trusted_outcome)
                self.record_delay(old_action, elapsed, effect=True, weight=min(1.0, share * 2.4))
                old_recent = self.recent.get(old_action, {})
                old_recent_r = float(old_recent.get("r", 0.0))
                self.recent[old_action] = {"r": old_recent_r * 0.72 + credit * 0.28,
                                           "step": self.steps}
                old_trail = self.outcomes.setdefault(old_action, [])
                if not isinstance(old_trail, list):
                    old_trail = self.outcomes[old_action] = []
                old_trail.append([round(float(credit), 7), int(self.steps)])
                if len(old_trail) > 10:
                    del old_trail[:-10]
            if assignments:
                self.record_delay(action, assignments[0][3], effect=True,
                                  weight=min(1.0, assignments[0][2] * 2.0))
        for part in parts:
            if part:
                self.atomic_trace.append(part)
        if len(self.atomic_trace) > 28:
            self.atomic_trace = self.atomic_trace[-28:]
        if abs(current_reward) > 0.035:
            for length in range(2, min(6, len(self.atomic_trace)) + 1):
                if len(self.atomic_trace) >= length:
                    sequence = "|".join(self.atomic_trace[-length:])
                    weight = 0.92 if length == 2 else (0.78 if length == 3 else max(0.46, 0.72 - length * 0.045))
                    self._update(self.sequences, sequence, current_reward, weight,
                                 record_outcome=trusted_outcome)
                    for family in self._state_families(state)[:4]:
                        self._update(self.sequence_contexts, f"{family}>{sequence}",
                                     contextual_target, weight * 0.78,
                                     record_outcome=trusted_outcome)
        started = float(action_started if action_started is not None else time.monotonic())
        self.history.append((action, state, started))
        if len(self.history) > 24:
            self.history = self.history[-24:]
        self.prev_action = self.last_action
        self.last_action = action
        self.last_reward = current_reward
        self.steps += 1
        self.action_trace.append(action)
        if len(self.action_trace) > 36:
            self.action_trace = self.action_trace[-36:]
        old_recent = self.recent.get(action, {})
        old_r = float(old_recent.get("r", 0.0))
        self.recent[action] = {"r": old_r * 0.66 + current_reward * 0.34, "step": self.steps}
        trail = self.outcomes.setdefault(action, [])
        if not isinstance(trail, list):
            trail = self.outcomes[action] = []
        trail.append([round(float(current_reward), 7), int(self.steps)])
        if len(trail) > 10:
            del trail[:-10]
        if len(self.outcomes) > 260:
            ranked_outcomes = sorted(
                self.outcomes.items(),
                key=lambda kv: int(kv[1][-1][1]) if isinstance(kv[1], list) and kv[1] else -1,
                reverse=True)[:220]
            self.outcomes = dict(ranked_outcomes)
        if len(self.recent) > 150:
            keep = sorted(self.recent.items(), key=lambda kv: int(kv[1].get("step", 0)),
                          reverse=True)[:150]
            self.recent = dict(keep)
        self._update_horizon_trace(action, state, current_reward, observed_at)
        self.observe_influence(action, state, visual_change, current_reward)
        self._trajectory_learning(action, state, current_reward, next_state, reliability,
                                  before, after, best_before)
        self.last_rate_signal = rate_signal
        if delta > 0:
            self.positive += 1
        if self.best is None or after > self.best:
            self.best = after
        return delta, current_reward
    def delay_hint(self, action):
        hints = []
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            bins = stat.get("bins", []) if isinstance(stat, dict) else []
            if isinstance(bins, list) and sum(float(x) for x in bins) >= 1.2:
                total = sum(float(x) for x in bins)
                acc = 0.0
                for index, count in enumerate(bins[:len(self.DELAY_BOUNDS)]):
                    acc += float(count)
                    if acc >= total * 0.62:
                        hints.append(min(0.95, self.DELAY_BOUNDS[index] * 0.52))
                        break
            else:
                late = float(stat.get("late", 0.0)) if isinstance(stat, dict) else 0.0
                if late > 0.12:
                    hints.append(min(0.42, 0.055 + late * 0.30))
        return max(hints, default=0.0)
    def delay_probability(self, action, elapsed):
        elapsed = max(0.0, float(elapsed))
        values = []
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            bins = stat.get("bins", []) if isinstance(stat, dict) else []
            total = sum(float(x) for x in bins) if isinstance(bins, list) else 0.0
            index = 0
            while index + 1 < len(self.DELAY_BOUNDS) and elapsed > self.DELAY_BOUNDS[index]:
                index += 1
            if total >= 1.5 and bins:
                count = float(bins[min(index, len(bins) - 1)])
                probability = (count + 0.18) / (total + 0.18 * len(self.DELAY_BOUNDS))
                evidence = 1.05 + min(0.72, math.log1p(total) * 0.24)
                probability *= evidence
                probability *= 1.0 / max(0.62, self.DELAY_BOUNDS[min(index, len(self.DELAY_BOUNDS)-1)] ** 0.12)
            else:
                probability = 0.56 * math.exp(-elapsed / 0.58) + 0.10 * math.exp(-elapsed / 2.5) + 0.025
            values.append(max(0.004, probability))
        return max(values, default=max(0.004, 0.92 * math.exp(-elapsed / 0.72)))

    def delay_probe_window(self, action, stagnant=0):
        learned = 0.0
        samples = 0.0
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            bins = stat.get("bins", []) if isinstance(stat, dict) else []
            total = sum(float(x) for x in bins) if isinstance(bins, list) else 0.0
            samples += total
            if total >= 1.5:
                acc = 0.0
                for index, count in enumerate(bins[:len(self.DELAY_BOUNDS)]):
                    acc += float(count)
                    if acc >= total * 0.82:
                        learned = max(learned, self.DELAY_BOUNDS[index] + 0.18)
                        break
        if learned > 0:
            return max(0.28, min(5.8, learned))
        if stagnant >= 52 and self.steps % 7 == 0:
            return 4.8
        if stagnant >= 36 and self.steps % 5 == 0:
            return 3.2
        if stagnant >= 14 and self.steps % 6 == 0:
            return 1.55
        return 0.78

    def record_delay(self, action, delay_seconds=None, effect=False, weight=1.0):
        delay = max(0.0, float(delay_seconds or 0.0))
        weight = max(0.05, min(1.0, float(weight)))
        for part in self._macro_parts(action):
            stat = self.delays.setdefault(part, {"n": 0, "late": 0.0, "bins": [0.0] * len(self.DELAY_BOUNDS), "miss": 0.0})
            if not isinstance(stat.get("bins"), list) or len(stat.get("bins", [])) != len(self.DELAY_BOUNDS):
                stat["bins"] = [0.0] * len(self.DELAY_BOUNDS)
            stat["n"] = int(stat.get("n", 0)) + 1
            late_value = 1.0 if effect and delay > 0.42 else 0.0
            rate = 0.22 if stat["n"] < 10 else 0.09
            stat["late"] = float(stat.get("late", 0.0)) * (1.0 - rate) + late_value * rate
            if effect:
                index = 0
                while index + 1 < len(self.DELAY_BOUNDS) and delay > self.DELAY_BOUNDS[index]:
                    index += 1
                stat["bins"][index] = float(stat["bins"][index]) + weight
                stat["miss"] = float(stat.get("miss", 0.0)) * 0.96
            else:
                stat["miss"] = min(30.0, float(stat.get("miss", 0.0)) + weight)
                if stat["miss"] > 4.0:
                    decay = 0.994 if stat["miss"] < 10.0 else 0.982
                    stat["bins"] = [float(x) * decay for x in stat["bins"]]
            if sum(float(x) for x in stat["bins"]) > 80.0:
                stat["bins"] = [float(x) * 0.72 for x in stat["bins"]]
            self._mark_dirty(self.delays, part)
        if len(self.delays) > 220:
            keep = {key for key, _value in sorted(self.delays.items(),
                          key=lambda kv: int(kv[1].get("n", 0)), reverse=True)[:200]}
            for key in list(self.delays):
                if key not in keep:
                    self._delete_key("delays", key)
    def action_quality(self, action, state=None):
        gq = self._value(self.stats.get(action, {}))[0]
        median, trend, downside = self._outcome_signal(action)
        recent_adjust = max(-0.35, min(0.35, median * 0.10 + trend * 0.07 - downside * 0.06))
        if not state:
            return gq + recent_adjust
        cq, cn, _ = self._value(self.contexts.get(self._context_key(state, action), {}))
        fq, fn, _fv, _fg, _fb = self._family_value(state, action)
        aq, an, _av = self._alias_value(state, action)
        nq, nn, _nv = self._nstep_value(state, action)
        rq, rn, _rv = self._value(self.rates.get(action, {}))
        iq, inn, _iv = self.influence_value(state, action)
        xq, xn, _xv = self._sequence_value(action, state)
        if cn:
            base = 0.46 * cq + 0.22 * gq + 0.12 * fq + (0.05 * aq if an else 0.0)
        elif fn:
            base = 0.47 * gq + 0.31 * fq + (0.07 * aq if an else 0.0)
        elif an:
            base = 0.66 * gq + 0.19 * aq
        else:
            base = gq
        if nn:
            weight = min(0.40, 0.16 + math.log1p(nn) * 0.045)
            base = base * (1.0 - weight) + nq * weight
        if rn:
            base += max(-0.28, min(0.32, rq * 0.11))
        if inn:
            base += max(-0.16, min(0.24, iq * 0.12))
        if xn:
            weight = min(0.56, 0.22 + math.log1p(xn) * 0.065)
            base = base * (1.0 - weight) + xq * weight
        return base + recent_adjust

    def preferred_actions(self, prefix="", limit=8):
        ranked = []
        for action, stat in self.stats.items():
            if action.startswith("macro:"):
                continue
            if prefix and not action.startswith(prefix):
                continue
            q, n, _ = self._value(stat)
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            zero = int(stat.get("zero", 0))
            success = (good + 1) / (good + bad + zero + 2)
            if n >= 6 and zero / max(1, n) > 0.78 and q <= 0.02:
                continue
            if n >= 2 and q > -0.08 and success >= 0.28:
                downside = float(stat.get("down", 0.0))
                ranked.append((q + min(0.2, math.log1p(n) * 0.02) + success * 0.07
                               - min(0.12, downside * 0.025), action))
        ranked.sort(reverse=True)
        return [action for _score, action in ranked[:limit]]

    @staticmethod
    def _trim(table, limit):
        if len(table) <= limit:
            return table
        ranked = sorted(table.items(),
                        key=lambda kv: (int(kv[1].get("n", 0)),
                                        abs(float(kv[1].get("q", 0.0)))), reverse=True)
        return dict(ranked[:limit])

    def _trim_attr(self, attr, limit):
        table = getattr(self, attr)
        if len(table) <= limit:
            return
        ranked = sorted(table.items(),
                        key=lambda kv: (int(kv[1].get("n", 0)),
                                        abs(float(kv[1].get("q", 0.0)))), reverse=True)
        keep = {key for key, _value in ranked[:limit]}
        for key in list(table):
            if key not in keep:
                self._delete_key(attr, key)

    def save(self):
        if self._db is None:
            return
        for attr, limit in (("contexts", 18000), ("families", 14000), ("pairs", 5200),
                            ("triples", 6200), ("sequences", 6000),
                            ("sequence_contexts", 9000), ("aliases", 9000),
                            ("models", 12000), ("passive_families", 3000),
                            ("nstep", 16000), ("trajectory_sequences", 9000),
                            ("rates", 5000), ("passive_rates", 3500),
                            ("influence", 10000), ("effects", 12000)):
            self._trim_attr(attr, limit)
        dirty_snapshot = {name: set(values) for name, values in self._dirty.items()}
        deleted_snapshot = {name: set(values) for name, values in self._deleted.items()}
        with self._db:
            for attr, table_name in self._table_specs.items():
                table = getattr(self, attr)
                deleted = deleted_snapshot[table_name]
                if deleted:
                    self._db.executemany(f'DELETE FROM "{table_name}" WHERE key=?',
                                         ((key,) for key in deleted))
                rows = []
                for key in dirty_snapshot[table_name]:
                    if key in table:
                        rows.append((key, json.dumps(table[key], ensure_ascii=False, separators=(",", ":"))))
                if rows:
                    self._db.executemany(
                        f'INSERT INTO "{table_name}"(key,value) VALUES(?,?) '
                        'ON CONFLICT(key) DO UPDATE SET value=excluded.value', rows)
            meta = {
                "version": 24, "steps": self.steps, "best": self.best,
                "positive": self.positive, "recent": self.recent, "outcomes": self.outcomes,
            }
            self._db.executemany(
                'INSERT INTO meta(key,value) VALUES(?,?) '
                'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                ((key, json.dumps(value, ensure_ascii=False, separators=(",", ":")))
                 for key, value in meta.items()))
        for table_name in self._dirty:
            self._dirty[table_name].difference_update(dirty_snapshot[table_name])
            self._deleted[table_name].difference_update(deleted_snapshot[table_name])

    def close(self):
        try:
            self.save()
        finally:
            if self._db is not None:
                try:
                    self._db.close()
                finally:
                    self._db = None

class ValueAI:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.storage = None
        self.data_dir = None
        self.runtime_dir = None
        self.runtime_version = ""
        self.hardware = None
        self.reader = None
        self.capture = None
        self.cv2 = None
        self.np = None
        self.ImageTk = None
        self.window_roi = None
        self.target_hwnd = 0
        self.target_pid = 0
        self.target_identity = None
        self._target_lost_since = None
        self._controls = {}
        self._control_graph_hash = "c00000000"
        self._dynamic_key_actions = set()
        self._last_isolation_scene = None
        self._log_once_keys = set()
        self._selection_snapshot = None
        self._selection_screen = None
        self._selection_overlay = None
        self._key_cursor = 0
        self._mouse_cursor = 0
        self.stop_event = threading.Event()
        self.hook = None
        self.worker = None
        self.last_summary = ""
        self._visual_cache = "v0"
        self._semantic_scene = "h00000000"
        self._semantic_tokens = ()
        self._semantic_features = {}
        self._scene_revision = 0
        self.target_entity = None
        self.scene_numbers = {}
        self._scene_number_entities = []
        self._number_change_flags = {}
        self._number_structure_hash = "n00000000"
        self._last_semantic_scan_at = 0.0
        self._last_semantic_scan_step = -999999
        self._vlm_last_call = 0.0
        self._vlm_last_signature = ""
        self._vlm_plan = {}
        self._danger_regions = []
        self._recognized_actions = set()
        self._controls = {}
        self._last_control_count = 0
        self._last_danger_count = 0
        self._environment_cache = None
        self._environment_cache_at = 0.0
        self._last_decision_family = ""
        self._state_velocity = 0.0
        self._state_acceleration = 0.0
        self._motion_mask = 0
        self.action_priors = dict(KEY_ACTION_PRIORS)
        self._build_ui()
        self.root.after(80, self._choose_storage)
        self.root.after(100, self._poll)

    def _build_ui(self):
        self.root.title(APP_NAME)
        self.root.geometry("640x430")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        outer = ttk.Frame(self.root, padding=28)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=APP_NAME, font=("Microsoft YaHei UI", 22, "bold")).pack()
        ttk.Label(outer, text="把屏幕上的数值作为奖励，让 AI 自主学习有效操作",
                  font=("Microsoft YaHei UI", 10)).pack(pady=(6, 22))
        self.path_var = tk.StringVar(value="等待选择 D 盘文件夹")
        ttk.Label(outer, textvariable=self.path_var, wraplength=570,
                  foreground="#555555").pack(fill="x")
        self.progress = ttk.Progressbar(outer, mode="indeterminate", length=550)
        self.progress.pack(pady=(12, 18))
        row = ttk.Frame(outer)
        row.pack(pady=4)
        self.value_button = ttk.Button(row, text="数值", state="disabled",
                                       command=self._select_value, width=18)
        self.value_button.pack(side="left", padx=8, ipady=13)
        self.confirm_button = ttk.Button(row, text="确认", state="disabled",
                                         command=self._start, width=18)
        self.confirm_button.pack(side="left", padx=8, ipady=13)
        self.selection_var = tk.StringVar(value="尚未选择数值")
        ttk.Label(outer, textvariable=self.selection_var,
                  font=("Microsoft YaHei UI", 11, "bold")).pack(pady=(20, 8))
        self.status_var = tk.StringVar(value="")
        ttk.Label(outer, textvariable=self.status_var, wraplength=570,
                  justify="center").pack()
        ttk.Label(outer,
                  text="运行后按 ESC 立即停止。AI 仅操作所选数值所属程序窗口；请勿在含支付或不可逆操作的界面运行。",
                  wraplength=570, foreground="#8a3b12", justify="center").pack(
                      side="bottom", pady=(18, 0))

    def _choose_storage(self):
        dialog = DFolderDialog(self.root)
        self.root.wait_window(dialog)
        if not dialog.result:
            self.root.destroy()
            return
        self.storage = dialog.result
        try:
            self.data_dir = self.storage / DATA_DIR_NAME
            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.hardware = HardwareProfile(self.data_dir)
            arch = re.sub(r"[^a-z0-9_-]", "", self.hardware.architecture) or "64bit"
            version = f"py{sys.version_info.major}{sys.version_info.minor}-{arch}"
            self.runtime_version = version
            self.runtime_dir = self.data_dir / f"runtime-{version}-{self.hardware.tag}"
            for path in (self.runtime_dir, self.data_dir / "缓存",
                         self.data_dir / "临时文件", self.data_dir / "日志"):
                path.mkdir(parents=True, exist_ok=True)
            os.chdir(self.data_dir)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法在所选文件夹写入数据：\n{exc}", parent=self.root)
            self.root.destroy()
            return
        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{self.hardware.summary()}")
        self.status_var.set("正在按本机硬件准备视觉识别组件，请稍候……")
        self.progress.start(12)
        threading.Thread(target=self._prepare_runtime, daemon=True).start()

    def _prepare_runtime(self):
        cache = self.data_dir / "缓存"
        temp = self.data_dir / "临时文件"
        marker = self.runtime_dir / f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}"
        try:
            env = os.environ.copy()
            directed = {
                "PIP_CACHE_DIR": cache / "pip", "TMP": temp, "TEMP": temp,
                "XDG_CACHE_HOME": cache, "HF_HOME": cache / "huggingface",
                "RAPIDOCR_HOME": cache / "rapidocr",
                "MPLCONFIGDIR": cache / "matplotlib", "NUMBA_CACHE_DIR": cache / "numba",
                "PYTHONPYCACHEPREFIX": cache / "pycache",
            }
            for key, value in directed.items():
                Path(value).mkdir(parents=True, exist_ok=True)
                env[key] = str(value)
                os.environ[key] = str(value)
            model_root = cache / "rapidocr_models"
            model_root.mkdir(parents=True, exist_ok=True)
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            env["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)
            env["OMP_WAIT_POLICY"] = "PASSIVE"
            env["ORT_LOG_SEVERITY_LEVEL"] = "3"
            sys.pycache_prefix = str(cache / "pycache")
            if str(self.runtime_dir) not in sys.path:
                sys.path.insert(0, str(self.runtime_dir))

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            if marker.exists():
                required = ("rapidocr", "onnxruntime", "cv2", "PIL", "mss")
                if not all((self.runtime_dir / name).exists() for name in required):
                    try:
                        marker.unlink()
                    except OSError as exc:
                        self._log_once("runtime_marker_unlink", "runtime_marker_unlink_error", type(exc).__name__)
                else:

                    probe_code = ("import sys;sys.path.insert(0," +
                                  repr(str(self.runtime_dir)) +
                                  ");import rapidocr,onnxruntime,cv2,PIL,mss")
                    probe_env = env.copy()
                    probe_env["PYTHONNOUSERSITE"] = "1"
                    try:
                        probe = subprocess.run(
                            [sys.executable, "-c", probe_code], env=probe_env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            timeout=24, creationflags=creationflags)
                        if probe.returncode:
                            marker.unlink(missing_ok=True)
                    except Exception:
                        marker.unlink(missing_ok=True)

            def install(packages, no_deps=False):
                command = [sys.executable, "-m", "pip", "install", "--upgrade",
                           "--prefer-binary", "--disable-pip-version-check",
                           "--no-warn-script-location", "--target", str(self.runtime_dir)]
                if no_deps:
                    command.append("--no-deps")
                if self.hardware.disk_free < 5 * GIB:
                    command.append("--no-cache-dir")
                command += list(packages)
                last = None
                for attempt in range(2):
                    run = subprocess.run(command, env=env, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True,
                                         encoding="utf-8", errors="replace",
                                         creationflags=creationflags)
                    last = run
                    if run.returncode == 0:
                        return
                    if attempt == 0:
                        time.sleep(0.8)
                tail = "\n".join((last.stdout if last else "").splitlines()[-18:])
                raise RuntimeError(tail or "pip 安装失败")

            if not marker.exists():
                backend_pkg = ("onnxruntime-directml>=1.18,<2" if self.hardware.want_dml
                               else "onnxruntime>=1.18,<2")
                try:
                    install([f"rapidocr=={RAPIDOCR_VERSION}", backend_pkg, MSS_SPEC])
                except Exception:
                    if not self.hardware.want_dml:
                        raise

                    shutil.rmtree(self.runtime_dir, ignore_errors=True)
                    self.hardware.want_dml = False
                    self.hardware.backend = "cpu"
                    self.hardware.dml_tested_at = time.time()
                    self.runtime_dir = self.data_dir / (
                        f"runtime-{self.runtime_version}-{self.hardware.tag}")
                    self.runtime_dir.mkdir(parents=True, exist_ok=True)
                    marker = self.runtime_dir / (
                        f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}")
                    if str(self.runtime_dir) not in sys.path:
                        sys.path.insert(0, str(self.runtime_dir))
                    install([f"rapidocr=={RAPIDOCR_VERSION}", "onnxruntime>=1.18,<2", MSS_SPEC])

            importlib.invalidate_caches()
            try:
                import onnxruntime as ort
            except Exception:
                if not self.hardware.want_dml:
                    raise

                for module_name in tuple(sys.modules):
                    if module_name == "onnxruntime" or module_name.startswith("onnxruntime."):
                        sys.modules.pop(module_name, None)
                self.hardware.want_dml = False
                self.hardware.backend = "cpu"
                self.hardware.dml_tested_at = time.time()
                self.runtime_dir = self.data_dir / (
                    f"runtime-{self.runtime_version}-{self.hardware.tag}")
                self.runtime_dir.mkdir(parents=True, exist_ok=True)
                marker = self.runtime_dir / (
                    f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}")
                if str(self.runtime_dir) not in sys.path:
                    sys.path.insert(0, str(self.runtime_dir))
                install([f"rapidocr=={RAPIDOCR_VERSION}",
                         "onnxruntime>=1.18,<2", MSS_SPEC])
                importlib.invalidate_caches()
                import onnxruntime as ort
            from PIL import Image, ImageGrab, ImageOps, ImageTk
            import cv2
            import numpy as np
            try:
                cv_threads = (1 if self.hardware.tier == "low" else
                              min(4, max(1, self.hardware.physical_cores // 2)))
                cv2.setUseOptimized(True)
                cv2.setNumThreads(cv_threads)
            except Exception as exc:
                self._log_once("opencv_tuning", "opencv_tuning_error", type(exc).__name__)
            try:
                import mss
            except Exception:
                mss = None
            dxcam = None
            if self.hardware.dxcam_eligible and self.hardware.tier != "low":
                try:
                    import dxcam as _dxcam
                    dxcam = _dxcam
                except Exception:
                    try:
                        install([COMTYPES_SPEC, DXCAM_SPEC], no_deps=True)
                        importlib.invalidate_caches()
                        import dxcam as _dxcam
                        dxcam = _dxcam
                    except Exception:
                        dxcam = None
            from rapidocr import (EngineType, LangDet, LangRec, ModelType,
                                  OCRVersion, RapidOCR)

            model_map = {"tiny": ModelType.TINY, "small": ModelType.SMALL,
                         "medium": ModelType.MEDIUM}
            rec_model = model_map.get(self.hardware.rec_model, ModelType.SMALL)
            det_model = model_map.get(self.hardware.det_model, ModelType.SMALL)

            def make_params(use_dml=False, version=OCRVersion.PPOCRV6,
                            rec_size=None, det_size=None, threads=None,
                            rec_lang=None, det_lang=None):
                thread_count = max(1, int(threads or self.hardware.ocr_threads))
                return {
                    "Global.text_score": 0.14,
                    "Global.use_preprocess_img": True,
                    "Global.use_vertical_padding": True,
                    "Global.min_height": 26,
                    "Global.width_height_ratio": 18,
                    "Global.min_side_len": 26,
                    "Global.max_side_len": 2200,
                    "Global.model_root_dir": str(model_root),
                    "Det.engine_type": EngineType.ONNXRUNTIME,
                    "Det.lang_type": det_lang or LangDet.CH,
                    "Det.model_type": det_size or det_model,
                    "Det.ocr_version": version,
                    "Rec.engine_type": EngineType.ONNXRUNTIME,
                    "Rec.lang_type": rec_lang or LangRec.CH,
                    "Rec.model_type": rec_size or rec_model,
                    "Rec.ocr_version": version,
                    "EngineConfig.onnxruntime.intra_op_num_threads": thread_count,
                    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                    "EngineConfig.onnxruntime.enable_cpu_mem_arena": self.hardware.ram >= 8 * GIB,
                    "EngineConfig.onnxruntime.use_dml": bool(use_dml),
                }

            probes = []
            probe1 = np.full((96, 360, 3), 248, dtype="uint8")
            cv2.putText(probe1, "987654.321K", (10, 68), cv2.FONT_HERSHEY_SIMPLEX,
                        1.65, (18, 18, 18), 3, cv2.LINE_AA)
            probes.append((probe1, 987654321.0))
            probe2 = np.full((62, 248, 3), 24, dtype="uint8")
            cv2.putText(probe2, "12,345.67", (5, 45), cv2.FONT_HERSHEY_SIMPLEX,
                        1.05, (242, 242, 242), 2, cv2.LINE_AA)
            probes.append((probe2, 12345.67))
            if self.hardware.tier != "low":
                probe3 = np.full((74, 290, 3), 215, dtype="uint8")
                cv2.putText(probe3, "8.91e7", (10, 53), cv2.FONT_HERSHEY_SIMPLEX,
                            1.35, (45, 45, 45), 2, cv2.LINE_AA)
                probes.append((probe3, 8.91e7))

            def probe_accuracy(result, expected_value):
                texts = getattr(result, "txts", None)
                if texts is None:
                    return 0.0
                try:
                    text = "".join(str(x[0] if isinstance(x, (tuple, list)) and x else x)
                                   for x in list(texts))
                except Exception:
                    text = str(texts)
                value = parse_score(text)
                if value is None:
                    return 0.0
                rel = abs(value - expected_value) / max(1.0, abs(expected_value))
                return 1.0 if rel <= 1e-7 else (0.55 if rel <= 1e-4 else 0.0)

            def build_and_benchmark(use_dml, threads=None, params=None):
                engine = RapidOCR(params=params or make_params(use_dml=use_dml, threads=threads))
                warmups = 1 if self.hardware.tier == "low" else 2
                for _ in range(warmups):
                    engine(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                timings = []
                accuracy = []
                repeats = 1 if self.hardware.tier == "low" else 2
                for image_probe, expected_value in probes:
                    best_result = None
                    local_times = []
                    for _ in range(repeats):
                        t0 = time.perf_counter()
                        result = engine(image_probe, use_det=False, use_cls=False, use_rec=True)
                        local_times.append(time.perf_counter() - t0)
                        best_result = result
                    local_times.sort()
                    timings.append(local_times[len(local_times) // 2])
                    accuracy.append(probe_accuracy(best_result, expected_value))
                timings.sort()
                median_latency = timings[len(timings) // 2]
                correctness = sum(accuracy) / max(1, len(accuracy))
                composite = median_latency * (1.0 + max(0.0, 0.98 - correctness) * 4.0)
                return engine, median_latency, correctness, composite

            if not self.hardware.cached_rec_model:
                if self.hardware.tier == "high":
                    model_candidates = ["small", "medium"]
                elif self.hardware.tier == "low":
                    model_candidates = ["tiny", "small"] if self.hardware.ram >= 7 * GIB else ["tiny"]
                else:
                    model_candidates = ["small", "medium"] if self.hardware.ram >= 14 * GIB else ["small"]
                model_results = []
                for model_name in model_candidates:
                    try:
                        params = make_params(False, rec_size=model_map[model_name],
                                             threads=self.hardware.ocr_threads)
                        engine, elapsed, accuracy, composite = build_and_benchmark(
                            False, self.hardware.ocr_threads, params=params)
                        model_results.append((model_name, engine, elapsed, accuracy, composite))
                    except Exception:
                        continue
                if model_results:
                    best_accuracy_seen = max(item[3] for item in model_results)
                    viable = [item for item in model_results if item[3] + 0.01 >= best_accuracy_seen]
                    if self.hardware.tier == "high":

                        medium_items = [item for item in viable if item[0] == "medium"]
                        small_items = [item for item in viable if item[0] == "small"]
                        if medium_items and (not small_items or
                                medium_items[0][2] <= max(0.34, small_items[0][2] * 1.48)):
                            selected = medium_items[0]
                        else:
                            selected = min(viable, key=lambda item: item[4])
                    elif self.hardware.tier == "low":
                        small_items = [item for item in viable if item[0] == "small"]
                        tiny_items = [item for item in viable if item[0] == "tiny"]
                        if small_items and (not tiny_items or
                                small_items[0][2] <= max(0.60, tiny_items[0][2] * 1.34)):
                            selected = small_items[0]
                        else:
                            selected = min(viable, key=lambda item: item[4])
                    else:
                        selected = min(viable, key=lambda item: item[4] *
                                       (0.94 if item[0] == "medium" else 1.0))
                    selected_name = selected[0]
                    self.hardware.rec_model = selected_name
                    rec_model = model_map[selected_name]
                    self.hardware.model_tested_at = time.time()

                    selected = None
                    viable.clear()
                    model_results.clear()

            thread_candidates = {1, self.hardware.ocr_threads}
            if self.hardware.cached_threads:
                thread_candidates.add(self.hardware.cached_threads)
                thread_candidates.add(max(1, self.hardware.cached_threads - 1))
                thread_candidates.add(min(self.hardware.logical_cpus,
                                          self.hardware.cached_threads + 1))
            if self.hardware.logical_cpus >= 4:
                thread_candidates.add(min(2, self.hardware.logical_cpus))
            if self.hardware.logical_cpus >= 8:
                thread_candidates.add(max(2, min(self.hardware.ocr_threads,
                                                  self.hardware.logical_cpus // 3)))
            if self.hardware.tier == "low":
                thread_candidates = {1, self.hardware.ocr_threads}
            best_cpu = None
            best_cpu_time = float("inf")
            best_cpu_accuracy = 0.0
            best_cpu_composite = float("inf")
            best_threads = self.hardware.ocr_threads
            for threads in sorted(thread_candidates):
                try:
                    engine, elapsed, accuracy, composite = build_and_benchmark(False, threads)
                    if composite < best_cpu_composite:
                        if best_cpu is not None:
                            del best_cpu
                        best_cpu = engine
                        best_cpu_time = elapsed
                        best_cpu_accuracy = accuracy
                        best_cpu_composite = composite
                        best_threads = threads
                    else:
                        del engine
                except Exception:
                    continue
            if best_cpu is None:
                best_cpu, best_cpu_time, best_cpu_accuracy, best_cpu_composite = build_and_benchmark(
                    False, self.hardware.ocr_threads)
            self.hardware.ocr_threads = int(best_threads)
            os.environ["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)

            available = set(ort.get_available_providers())
            dml_possible = self.hardware.want_dml and "DmlExecutionProvider" in available
            if self.hardware.want_dml:
                self.hardware.dml_tested_at = time.time()
            primary = best_cpu
            chosen_ocr_time = best_cpu_time
            self.hardware.backend = "cpu"
            if dml_possible:
                try:
                    dml_engine, dml_time, dml_accuracy, dml_composite = build_and_benchmark(
                        True, max(1, min(2, best_threads)))

                    if (dml_accuracy + 0.01 >= best_cpu_accuracy and
                            dml_composite <= best_cpu_composite * 1.06):
                        primary = dml_engine
                        chosen_ocr_time = dml_time
                        self.hardware.backend = "dml"
                        del best_cpu
                    else:
                        del dml_engine
                except Exception as exc:
                    self._log_once("dml_probe", "dml_probe_error", type(exc).__name__)

            engines = [("ocrv6-ch", primary, 1.0)]
            if self.hardware.ensemble:

                try:
                    en_lang = getattr(LangRec, "EN", LangRec.CH)
                    en_det = getattr(LangDet, "EN", LangDet.CH)
                    en_params = make_params(
                        use_dml=(self.hardware.backend == "dml"),
                        version=OCRVersion.PPOCRV4, rec_size=ModelType.MOBILE,
                        det_size=ModelType.MOBILE, rec_lang=en_lang, det_lang=en_det)
                    en_engine = RapidOCR(params=en_params)
                    en_engine(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                    engines.append(("ocrv4-en", en_engine, 1.025))
                except Exception as exc:
                    self._log_once("ocr_en_ensemble", "ocr_en_ensemble_error", type(exc).__name__)

                if self.hardware.tier == "high" and self.hardware.ram >= 16 * GIB:
                    try:
                        alt_params = make_params(
                            use_dml=(self.hardware.backend == "dml"),
                            version=OCRVersion.PPOCRV5,
                            rec_size=ModelType.MOBILE, det_size=ModelType.MOBILE)
                        alt = RapidOCR(params=alt_params)
                        alt(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                        engines.append(("ocrv5", alt, 0.955))
                    except Exception as exc:
                        self._log_once("ocr_alt_ensemble", "ocr_alt_ensemble_error", type(exc).__name__)

            marker.write_text("ok", encoding="ascii")
            self.capture = ScreenCapture(
                mss, ImageGrab, Image, dxcam_module=dxcam,
                preferred=self.hardware.preferred_capture)
            try:
                self.capture.benchmark()
            except Exception as exc:
                self._log_once("capture_initial_benchmark", "capture_initial_benchmark_error", type(exc).__name__)
            self.hardware.capture_backend = self.capture.backend
            self.hardware.calibrate_runtime(chosen_ocr_time, self.capture.latency)
            self.cv2, self.np, self.ImageTk = cv2, np, ImageTk
            self.reader = ScoreReader(engines, self.capture, ImageOps, Image, np, cv2,
                                      max_variants=self.hardware.ocr_variants,
                                      hardware=self.hardware)
            self.events.put(("runtime_ready", self.hardware.summary()))
        except Exception as exc:
            try:
                marker.unlink(missing_ok=True)
            except Exception as cleanup_exc:
                self._log_runtime("runtime_marker_cleanup_error", type(cleanup_exc).__name__)
            self.events.put(("error", "视觉识别组件准备失败", str(exc)))

    def _select_value(self):
        if not self.reader or not self.capture or not self.ImageTk:
            return
        self.target_entity = None
        self.scene_numbers = {}
        self._scene_number_entities = []
        self._number_change_flags = {}
        self._number_structure_hash = "n00000000"
        self._semantic_features = {}
        self._semantic_scene = "h00000000"
        self._semantic_tokens = ()
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.selection_var.set("正在截图并查找整个屏幕上的数值……")
        self.status_var.set("请稍候，程序只截取当前整个屏幕一次。")
        self.root.update_idletasks()
        self.root.withdraw()
        self.root.after(
            220, lambda: threading.Thread(target=self._scan_screen_numbers,
                                          daemon=True).start())

    def _scan_screen_numbers(self):
        try:
            screen = virtual_screen_rect()
            image = self.capture.grab(screen)
            self.events.put(("number_scan_progress",))
            candidates = self._detect_screen_numbers(image, screen)
            self.events.put(("number_scan", image, candidates, screen))
        except Exception as exc:
            self.events.put(("number_scan_error", str(exc)))

    def _detect_screen_numbers(self, image, screen):
        rgb = self.np.asarray(image.convert("RGB"))
        height, width = rgb.shape[:2]
        if width < 4 or height < 4 or not self.reader.engines:
            return []
        number_pattern = re.compile(
            r"[-+−＋]?(?:(?:\d{1,3}(?:[.,，．'’ ]\d{3})+|\d+)"
            r"(?:[.,，．]\d+)?|[.,，．]\d+)(?:[eE][-+−＋]?\d+)?\s*" +
            SCORE_SUFFIX_RE, re.IGNORECASE)
        found = []
        _engine_name, primary_engine, _engine_weight = self.reader.engines[0]

        def add_result(view, offset_x, offset_y, scale_x, scale_y, active_engine=None):
            try:
                engine = active_engine or primary_engine
                try:
                    result = engine(view, use_det=True, use_cls=False, use_rec=True)
                except TypeError:
                    result = engine(view)
                texts = (result.get("txts") if isinstance(result, dict) else
                         getattr(result, "txts", None))
                boxes = (result.get("boxes") if isinstance(result, dict) else
                         getattr(result, "boxes", None))
                scores = (result.get("scores") if isinstance(result, dict) else
                          getattr(result, "scores", None))
                if texts is None or boxes is None:
                    return
                texts, boxes = list(texts), list(boxes)
                try:
                    scores = list(scores) if scores is not None else []
                except TypeError:
                    scores = []
                for index, raw in enumerate(texts):
                    if index >= len(boxes):
                        continue
                    if isinstance(raw, dict):
                        text = raw.get("text") or raw.get("txt") or ""
                    elif isinstance(raw, (tuple, list)):
                        text = raw[0] if raw else ""
                    else:
                        text = raw
                    text = unicodedata.normalize("NFKC", str(text)).strip()
                    if not text:
                        continue
                    try:
                        points = self.np.asarray(boxes[index], dtype="float32").reshape(-1, 2)
                        if len(points) < 2:
                            continue
                        local_x1 = float(points[:, 0].min())
                        local_y1 = float(points[:, 1].min())
                        local_x2 = float(points[:, 0].max())
                        local_y2 = float(points[:, 1].max())
                    except Exception:
                        continue
                    if local_x2 - local_x1 < 2 or local_y2 - local_y1 < 2:
                        continue
                    confidence = self.reader._as_float(
                        scores[index] if index < len(scores) else 0.65)
                    spans = list(number_pattern.finditer(text))
                    if not spans and parse_score_candidates(text):
                        spans = [None]
                    for match in spans:
                        token = match.group(0) if match else text
                        parsed = parse_score_candidates(token)
                        if not parsed:
                            continue
                        value, _weight, parsed_token = max(
                            parsed,
                            key=lambda item: (item[1],
                                              sum(ch.isdigit() for ch in item[2]),
                                              len(item[2])))
                        bx1, by1, bx2, by2 = local_x1, local_y1, local_x2, local_y2
                        if match and len(text) > 1:
                            start = max(0.0, min(1.0, match.start() / len(text)))
                            end = max(start, min(1.0, match.end() / len(text)))
                            if local_x2 - local_x1 >= (local_y2 - local_y1) * 0.72:
                                bx1 = local_x1 + (local_x2 - local_x1) * start
                                bx2 = local_x1 + (local_x2 - local_x1) * end
                            else:
                                by1 = local_y1 + (local_y2 - local_y1) * start
                                by2 = local_y1 + (local_y2 - local_y1) * end
                        x1 = screen[0] + offset_x + bx1 * scale_x
                        y1 = screen[1] + offset_y + by1 * scale_y
                        x2 = screen[0] + offset_x + bx2 * scale_x
                        y2 = screen[1] + offset_y + by2 * scale_y
                        pad_x = max(3.0, (x2 - x1) * 0.055)
                        pad_y = max(3.0, (y2 - y1) * 0.16)
                        rect = (max(screen[0], x1 - pad_x),
                                max(screen[1], y1 - pad_y),
                                min(screen[2], x2 + pad_x),
                                min(screen[3], y2 + pad_y))
                        found.append((rect, value, confidence, parsed_token))
            except Exception:
                return

        max_overview = 2200.0
        overview_scale = min(1.0, max_overview / max(width, height))
        if overview_scale < 0.995:
            overview = self.cv2.resize(rgb, None, fx=overview_scale, fy=overview_scale,
                                       interpolation=self.cv2.INTER_AREA)
        else:
            overview = rgb
        for _name, overview_engine, _weight in self.reader.engines:
            add_result(overview, 0, 0, width / overview.shape[1],
                       height / overview.shape[0], overview_engine)

        tile_width = min(width, 1700)
        tile_height = min(height, 1150)

        def starts(length, span):
            if length <= span:
                return [0]
            step = max(1, span - max(96, span // 10))
            values = list(range(0, max(1, length - span + 1), step))
            last = length - span
            if not values or values[-1] != last:
                values.append(last)
            return values

        tile_starts = [(x, y) for y in starts(height, tile_height)
                       for x in starts(width, tile_width)]
        if len(tile_starts) > 1 or overview_scale < 0.90:
            for x, y in tile_starts:
                tile = rgb[y:y + tile_height, x:x + tile_width]
                add_result(tile, x, y, 1.0, 1.0)

        def area(candidate):
            rect = candidate[0]
            return max(1.0, (rect[2] - rect[0]) * (rect[3] - rect[1]))

        def overlap(a, b):
            x1, y1 = max(a[0], b[0]), max(a[1], b[1])
            x2, y2 = min(a[2], b[2]), min(a[3], b[3])
            intersection = max(0.0, x2 - x1) * max(0.0, y2 - y1)
            if not intersection:
                return 0.0
            aa = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
            ab = max(1.0, (b[2] - b[0]) * (b[3] - b[1]))
            return intersection / max(1.0, aa + ab - intersection)

        deduplicated = []
        for candidate in sorted(found, key=lambda item: (-item[2], area(item))):
            duplicate = False
            for existing in deduplicated:
                same_value = ScoreReader._same_value(candidate[1], existing[1])
                if overlap(candidate[0], existing[0]) >= (0.48 if same_value else 0.82):
                    duplicate = True
                    break
            if not duplicate:
                deduplicated.append(candidate)
        deduplicated.sort(key=lambda item: (item[0][1], item[0][0], -item[2]))
        return deduplicated

    def _selection_done(self, selection):
        self._selection_overlay = None
        if not selection:
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            self.status_var.set("点击“数值”重新扫描整个屏幕。")
            self.value_button.configure(state="normal")
            return
        rect, detected_value, detected_confidence, detected_text = selection
        screen = virtual_screen_rect()
        x1 = max(screen[0], min(screen[2], int(rect[0])))
        y1 = max(screen[1], min(screen[3], int(rect[1])))
        x2 = max(screen[0], min(screen[2], int(rect[2])))
        y2 = max(screen[1], min(screen[3], int(rect[3])))
        rect = (min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2))
        if rect[2] - rect[0] < 4 or rect[3] - rect[1] < 4:
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            self.value_button.configure(state="normal")
            return
        if not self._bind_target_window(rect):
            self._selection_snapshot = None
            self._selection_screen = None
            self.root.deiconify()
            self.selection_var.set("无法绑定目标程序窗口，请重新选择程序内的数值")
            self.status_var.set("数值必须位于可操作程序的客户区内。")
            self.value_button.configure(state="normal")
            self.confirm_button.configure(state="disabled")
            return
        snapshot = self._selection_snapshot
        snapshot_screen = self._selection_screen or screen
        self.selection_var.set("正在精确核验所选数值……")
        threading.Thread(
            target=self._recognize_selection,
            args=(rect, snapshot, snapshot_screen, detected_value,
                  detected_confidence, detected_text), daemon=True).start()

    def _recognize_selection(self, rect, snapshot, screen, detected_value,
                             detected_confidence, detected_text):
        try:
            self.hardware.calibrate_selection(rect, virtual_screen_rect())
            roi_h = max(1, int(rect[3] - rect[1]))
            if roi_h <= 28 and self.hardware.tier != "low":
                self.reader.character_detail_variants = max(
                    self.reader.character_detail_variants, 3)
        except Exception as exc:
            self._log_once("selection_calibration", "selection_calibration_error", type(exc).__name__)
        value, confidence, text = None, 0.0, ""
        if snapshot is not None:
            crop = (max(0, int(math.floor(rect[0] - screen[0]))),
                    max(0, int(math.floor(rect[1] - screen[1]))),
                    min(snapshot.width, int(math.ceil(rect[2] - screen[0]))),
                    min(snapshot.height, int(math.ceil(rect[3] - screen[1]))))
            if crop[2] - crop[0] >= 4 and crop[3] - crop[1] >= 4:
                try:
                    value, confidence, text = self.reader.read_image(
                        snapshot.crop(crop), expected=detected_value)
                except Exception:
                    value, confidence, text = None, 0.0, ""
        if detected_value is not None:
            agrees = value is not None and ScoreReader._same_value(value, detected_value)
            if value is None or (not agrees and confidence < detected_confidence + 0.12):
                value, confidence, text = (detected_value, detected_confidence,
                                           detected_text)
            elif agrees:
                confidence = min(0.997, max(confidence, detected_confidence) + 0.035)
        if value is not None:
            try:
                self._bootstrap_target_semantics(rect, snapshot, screen, value, confidence, text)
            except Exception as exc:
                self._log_runtime("target_semantic_bootstrap_error", type(exc).__name__)
        self.events.put(("selection", value, confidence, text))

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        self.stop_event.clear()
        self._visual_cache = "v0"
        self._danger_regions = []
        self._recognized_actions = set()
        self._controls = {}
        self._control_graph_hash = "c00000000"
        self._dynamic_key_actions = set()
        self._last_isolation_scene = None
        self._last_control_count = 0
        self._last_danger_count = 0
        self._environment_cache = None
        self._environment_cache_at = 0.0
        self._state_velocity = 0.0
        self._state_acceleration = 0.0
        self._motion_mask = 0
        self.action_priors = dict(KEY_ACTION_PRIORS)
        self.hook = EscapeHook(self.stop_event)
        if not self.hook.start():
            messagebox.showerror(APP_NAME, "无法启用 ESC 紧急停止，因此未启动 AI。",
                                 parent=self.root)
            return
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.status_var.set("AI 已开启；按 ESC 立即停止")
        self.root.withdraw()
        self.worker = threading.Thread(target=self._run_ai, daemon=True)
        self.worker.start()

    def _log_runtime(self, event, detail=""):
        if not self.data_dir:
            return
        try:
            log_dir = self.data_dir / "日志"
            log_dir.mkdir(parents=True, exist_ok=True)
            stamp = time.strftime("%Y-%m-%d %H:%M:%S")
            line = f"[{stamp}] {event}"
            if detail:
                line += " | " + str(detail).replace("\r", " ").replace("\n", " ")[:900]
            with (log_dir / "运行日志.txt").open("a", encoding="utf-8") as handle:
                handle.write(line + "\n")
        except Exception:
            pass

    def _log_once(self, key, event, detail=""):
        token = str(key)
        if token in self._log_once_keys:
            return
        self._log_once_keys.add(token)
        self._log_runtime(event, detail)

    def _bind_target_window(self, rect):
        cx = (float(rect[0]) + float(rect[2])) * 0.5
        cy = (float(rect[1]) + float(rect[3])) * 0.5
        hwnd = top_level_window_at(cx, cy)
        client = client_screen_rect(hwnd)
        if not hwnd or not client:
            return False
        if not (client[0] <= cx <= client[2] and client[1] <= cy <= client[3]):
            return False
        cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
        self.target_hwnd = int(hwnd)
        self.target_identity = environment_identity_for_window(hwnd)
        self.target_pid = int(self.target_identity.get("pid", 0) or 0)
        self.window_roi = (
            max(0.0, min(1.0, (rect[0] - client[0]) / cw)),
            max(0.0, min(1.0, (rect[1] - client[1]) / ch)),
            max(0.0, min(1.0, (rect[2] - client[0]) / cw)),
            max(0.0, min(1.0, (rect[3] - client[1]) / ch)),
        )
        self._environment_cache = self.target_identity
        self._environment_cache_at = time.monotonic()
        self._target_lost_since = None
        self._log_runtime("target_bound",
                          f"hwnd={self.target_hwnd} pid={self.target_pid} exe={self.target_identity.get('exe')}")
        return True

    def _target_client_rect(self):
        rect = client_screen_rect(self.target_hwnd)
        if rect:
            self._target_lost_since = None
            return rect
        if self._target_lost_since is None:
            self._target_lost_since = time.monotonic()
            self._log_once("target_window_unavailable", "target_window_unavailable", f"hwnd={self.target_hwnd}")
        return None

    def _current_roi(self):
        client = self._target_client_rect()
        if client and self.window_roi:
            cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
            x1 = client[0] + self.window_roi[0] * cw
            y1 = client[1] + self.window_roi[1] * ch
            x2 = client[0] + self.window_roi[2] * cw
            y2 = client[1] + self.window_roi[3] * ch
            if x2 - x1 >= 4 and y2 - y1 >= 4:
                return (x1, y1, x2, y2)
        return None

    def _target_input_ready(self, restore=False):
        if os.name != "nt" or user32 is None or not self.target_hwnd:
            return False
        client = self._target_client_rect()
        if not client:
            return False
        try:
            fg = int(user32.GetForegroundWindow() or 0)
            fg_root = int(user32.GetAncestor(wintypes.HWND(fg), 2) or fg) if fg else 0
            if fg_root == self.target_hwnd:
                return True
            if fg_root and self.target_pid:
                fg_identity = environment_identity_for_window(fg_root)
                if int(fg_identity.get("pid", 0) or 0) == self.target_pid:
                    return True
            if not restore:
                return False
            if user32.IsIconic(wintypes.HWND(self.target_hwnd)):
                user32.ShowWindow(wintypes.HWND(self.target_hwnd), 9)  # SW_RESTORE
            user32.SetForegroundWindow(wintypes.HWND(self.target_hwnd))
            time.sleep(0.055)
            fg = int(user32.GetForegroundWindow() or 0)
            fg_root = int(user32.GetAncestor(wintypes.HWND(fg), 2) or fg) if fg else 0
            return fg_root == self.target_hwnd
        except Exception as exc:
            self._log_runtime("target_focus_error", type(exc).__name__)
            return False

    def _environment_identity(self, force=False):
        now = time.monotonic()
        if (not force and self._environment_cache and
                now - self._environment_cache_at < 1.5):
            return self._environment_cache
        identity = (environment_identity_for_window(self.target_hwnd)
                    if self.target_hwnd else foreground_environment_identity())
        self._environment_cache = identity
        self._environment_cache_at = now
        return identity

    def _profile_file(self):
        nr = self.window_roi or (0, 0, 0, 0)
        cx, cy = (nr[0] + nr[2]) * 0.5, (nr[1] + nr[3]) * 0.5
        rw, rh = max(0.0, nr[2] - nr[0]), max(0.0, nr[3] - nr[1])
        quantized_roi = tuple(round(v * 100) for v in (cx, cy, rw, rh))
        env = self._environment_identity(force=True)
        raw = (f"env|{env.get('exe','unknown')}|{env.get('exe_hash','unknown')}|"
               f"{env.get('class','unknown')}|roi|{quantized_roi}")
        key = hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:20]
        self._log_runtime("environment",
                          f"exe={env.get('exe')} class={env.get('class')} title={env.get('title')} profile={key}")
        return self.data_dir / f"学习状态-{key}.db"

    @staticmethod
    def _action_point_fraction(action):
        try:
            parts = str(action).split(":")
            if parts[0] in {"mouse", "pointer"}:
                if len(parts) == 3:
                    grid, x, y = 20.0, float(parts[1]), float(parts[2])
                else:
                    grid, x, y = float(parts[1]), float(parts[2]), float(parts[3])
            elif parts[0] == "click":
                grid, x, y = float(parts[2]), float(parts[3]), float(parts[4])
            elif parts[0] == "wheel":
                grid, x, y = float(parts[3]), float(parts[4]), float(parts[5])
            elif parts[0] == "drag":
                grid, x, y = float(parts[2]), float(parts[3]), float(parts[4])
            elif parts[0] == "tap" and len(parts) == 8:
                grid, x, y = float(parts[2]), float(parts[3]), float(parts[4])
            else:
                return None
            grid = max(1.0, grid)
            return max(0.0, min(1.0, x / grid)), max(0.0, min(1.0, y / grid))
        except Exception:
            return None

    def _point_is_dangerous(self, fx, fy):
        for x1, y1, x2, y2 in self._danger_regions:
            if x1 <= fx <= x2 and y1 <= fy <= y2:
                return True
        return False

    def _action_is_dangerous(self, action):
        for part in Learner._macro_parts(action):
            if part.startswith(("key:", "hold:", "pulse:", "chord:")) and not self._keyboard_action_allowed(part):
                return True
            if part.startswith("click:control:"):
                control_id = part.split(":", 2)[2]
                control = self._controls.get(control_id, {})
                if not control or control.get("danger") or not control.get("enabled", True):
                    return True
                continue
            point = self._action_fraction(part)
            if point and self._point_is_dangerous(*point):
                return True
        return False

    def _screen_ready(self):
        client = self._target_client_rect()
        roi = self._current_roi()
        return bool(client and client[2] - client[0] >= 80 and client[3] - client[1] >= 80 and roi)

    def _keyboard_candidates(self, learner, stagnant):
        allowed_atomic = list(CORE_KEY_ACTIONS)
        allowed_atomic.extend(sorted(a for a in self._dynamic_key_actions if a in KEY_ACTIONS))
        allowed_atomic = list(dict.fromkeys(allowed_atomic))
        remembered = (learner.preferred_actions("key:", limit=24) +
                      learner.preferred_actions("hold:", limit=14) +
                      learner.preferred_actions("pulse:", limit=16) +
                      learner.preferred_actions("chord:", limit=14))
        remembered = [a for a in remembered if self._keyboard_action_allowed(a)]
        hinted = sorted(
            (action for action in self._dynamic_key_actions
             if action in KEY_ACTIONS and self.action_priors.get(action, 0.0) >= 0.64),
            key=lambda action: self.action_priors.get(action, 0.0), reverse=True)[:18]
        actions = list(dict.fromkeys(remembered + hinted + allowed_atomic))
        seed_names = []
        for action in actions:
            if action.startswith("key:"):
                name = action.split(":", 1)[1]
                if name in {"UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE"}:
                    seed_names.append(name)
        durations = (160, 420, 900)
        if stagnant >= 12:
            durations += (1200,)
        if stagnant >= 28:
            durations += (1800,)
        seed_names = list(dict.fromkeys(seed_names))
        for name in seed_names:
            for duration in durations:
                actions.append(f"hold:{name}:{duration}")
        # Learn action frequency directly: press duration, repeat count and interval are parameters.
        pulse_profiles = [(70, 2, 80), (55, 3, 65), (95, 3, 110)]
        if stagnant >= 12:
            pulse_profiles += [(55, 5, 80), (130, 2, 180)]
        if stagnant >= 28:
            pulse_profiles += [(45, 6, 55), (180, 3, 240)]
        for index, name in enumerate(seed_names[:10]):
            rotate = (learner.steps + index) % max(1, len(pulse_profiles))
            profiles = pulse_profiles[rotate:] + pulse_profiles[:rotate]
            for duration, repeats, interval in profiles[:3 if stagnant >= 12 else 2]:
                actions.append(f"pulse:{name}:{duration}:{repeats}:{interval}")
        if stagnant >= 10:
            actions.extend(CHORD_KEY_ACTIONS)
        return [a for a in dict.fromkeys(actions) if self._keyboard_action_allowed(a)][:96]

    def _keyboard_action_allowed(self, action):
        raw = str(action or "")
        allowed_names = {a.split(":", 1)[1] for a in CORE_KEY_ACTIONS}
        allowed_names.update(a.split(":", 1)[1] for a in self._dynamic_key_actions
                             if a.startswith("key:") and a in KEY_ACTIONS)
        if raw.startswith("key:"):
            return raw in KEY_ACTIONS and raw.split(":", 1)[1] in allowed_names
        if raw.startswith("hold:"):
            try:
                _kind, name, milliseconds = raw.split(":")
                return (name in allowed_names and name in KEY_NAME_TO_VK and
                        name in {"UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE"} and
                        40 <= int(milliseconds) <= 3000)
            except Exception:
                return False
        if raw.startswith("pulse:"):
            try:
                _kind, name, milliseconds, repeats, interval = raw.split(":")
                return (name in allowed_names and name in KEY_NAME_TO_VK and
                        name in {"UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE"} and
                        25 <= int(milliseconds) <= 1200 and 2 <= int(repeats) <= 10 and
                        25 <= int(interval) <= 900)
            except Exception:
                return False
        if raw.startswith("chord:"):
            names = raw.split(":", 1)[1].split("+")
            return (2 <= len(names) <= 3 and all(name in allowed_names and name in KEY_NAME_TO_VK
                                                 for name in names) and
                    all(name not in {"SHIFT", "CTRL", "ALT", "LWIN", "RWIN"} for name in names))
        return True

    @staticmethod
    def _keyboard_category(action):
        raw = str(action)
        if raw.startswith(("hold:", "pulse:", "chord:")):
            return "combo"
        name = raw.split(":", 1)[1] if ":" in raw else raw
        if name in {"UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D", "SPACE"}:
            return "move"
        if re.fullmatch(r"F(?:[1-9]|1[0-9]|2[0-4])", name) or name in {
                "ENTER", "TAB", "BACK", "HOME", "END", "PRIOR", "NEXT", "INSERT"}:
            return "function"
        if re.fullmatch(r"[A-Z]", name):
            return "letters"
        if re.fullmatch(r"(?:[0-9]|NUMPAD[0-9])", name):
            return "digits"
        return "other"
    def _mouse_input_candidates(self, learner, click_actions, stagnant):
        remembered = []
        for prefix in ("mouse:", "pointer:", "click:", "tap:", "wheel:", "drag:"):
            remembered.extend(learner.preferred_actions(prefix, limit=14))
        base_clicks = [a for a in click_actions if not self._action_is_dangerous(a)][:80]
        actions = list(dict.fromkeys(a for a in remembered + base_clicks
                                     if not self._action_is_dangerous(a)))
        if not base_clicks:
            return actions[:140]
        variant_count = min(len(base_clicks), 8 + min(8, stagnant // 7))
        start = (learner.steps * max(1, variant_count)) % len(base_clicks)
        sample = (base_clicks + base_clicks)[start:start + variant_count]
        for action in sample:
            try:
                parts = action.split(":")
                if len(parts) == 3:
                    grid, qx, qy = 20, int(parts[1]), int(parts[2])
                elif len(parts) == 4:
                    grid, qx, qy = int(parts[1]), int(parts[2]), int(parts[3])
                else:
                    continue
                grid = max(2, grid)
                parent_prior = self.action_priors.get(action, 0.50)
                variants = [
                    f"pointer:{grid}:{qx}:{qy}",
                    f"click:left:{grid}:{qx}:{qy}:2",
                    f"tap:left:{grid}:{qx}:{qy}:3:80:42",
                    f"tap:left:{grid}:{qx}:{qy}:5:80:38",
                    f"wheel:v:{WHEEL_DELTA}:{grid}:{qx}:{qy}",
                    f"wheel:v:{-WHEEL_DELTA}:{grid}:{qx}:{qy}",
                ]
                if stagnant >= 14:
                    variants.extend((
                        f"tap:left:{grid}:{qx}:{qy}:3:140:55",
                        f"tap:left:{grid}:{qx}:{qy}:6:55:32",
                    ))
                if stagnant >= 10:
                    variants.append(f"click:right:{grid}:{qx}:{qy}:1")
                distance = max(8, int(round(grid * (0.045 + min(0.055, stagnant * 0.001)))) )
                endpoints = (
                    (max(0, qx - distance), qy), (min(grid, qx + distance), qy),
                    (qx, max(0, qy - distance)), (qx, min(grid, qy + distance)),
                )
                if stagnant >= 12:
                    for ex, ey in endpoints:
                        variants.append(f"drag:left:{grid}:{qx}:{qy}:{ex}:{ey}:520")
                if stagnant >= 28:
                    variants.extend((
                        f"wheel:h:{WHEEL_DELTA}:{grid}:{qx}:{qy}",
                        f"wheel:h:{-WHEEL_DELTA}:{grid}:{qx}:{qy}",
                        f"wheel:v:{WHEEL_DELTA * 4}:{grid}:{qx}:{qy}",
                        f"wheel:v:{-WHEEL_DELTA * 4}:{grid}:{qx}:{qy}",
                    ))
                for variant in variants:
                    if self._action_is_dangerous(variant):
                        continue
                    actions.append(variant)
                    factor = (0.94 if variant.startswith("click:left") else
                              0.91 if variant.startswith("tap:left") else
                              0.86 if variant.startswith("pointer:") else 0.72)
                    self.action_priors.setdefault(variant, parent_prior * factor)
            except Exception as exc:
                self._log_runtime("mouse_candidate_error", type(exc).__name__)
        return list(dict.fromkeys(actions))[:240]

    @staticmethod
    def _action_semantic_from_text(raw_text):
        text = unicodedata.normalize("NFKC", str(raw_text or "")).strip().lower()
        compact = re.sub(r"\s+", "", text)
        if not compact:
            return ActionSemantic()

        def has_any(words):
            return any(word in text for word in words)

        action_type = "unknown"
        target = ""
        expected = "unknown"
        risk = 0.18
        confidence = 0.42
        if has_any(("领取", "收集", "奖励", "claim", "collect", "reward", "bonus")):
            action_type, expected, confidence = "claim_reward", "increase_resource", 0.92
        elif has_any(("永久升级", "permanent upgrade", "permanent", "永久")) and has_any(("升级", "upgrade", "强化", "enhance")):
            action_type, expected, confidence = "permanent_upgrade", "increase_long_term_growth", 0.91
        elif has_any(("升级", "upgrade", "强化", "enhance", "level up", "levelup", "提高", "improve")):
            action_type, expected, confidence = "upgrade", "increase_rate", 0.88
        elif has_any(("加速", "boost", "speed up", "power up", "临时", "temporary")):
            action_type, expected, confidence = "temporary_boost", "increase_rate_temporarily", 0.84
        elif has_any(("转生", "rebirth", "prestige", "声望")):
            action_type, expected, confidence, risk = "prestige", "reset_for_long_term_growth", 0.90, 0.86
        elif has_any(("重置", "reset", "清除", "wipe", "factory reset")):
            action_type, expected, confidence, risk = "reset", "reset_state", 0.93, 0.96
        elif has_any(("出售", "sell")):
            action_type, expected, confidence, risk = "sell", "exchange_resource", 0.86, 0.58
        elif has_any(("购买", "purchase", "buy")):
            action_type, expected, confidence, risk = "purchase", "spend_resource", 0.82, 0.62
        elif has_any(("继续", "continue", "下一", "next")):
            action_type, expected, confidence = "continue", "navigate", 0.80
        elif has_any(("开始", "start", "play")):
            action_type, expected, confidence = "start", "start_process", 0.82
        elif has_any(("切换", "tab", "page", "页面", "menu", "菜单")):
            action_type, expected, confidence = "navigate", "change_view", 0.68

        if has_any(("收入", "收益", "产量", "产出", "income", "production", "profit", "每秒", "/s", "per second")):
            target = "income_rate"
            if action_type in {"upgrade", "permanent_upgrade", "temporary_boost"}:
                expected = "increase_rate" if action_type != "temporary_boost" else "increase_rate_temporarily"
        elif has_any(("倍率", "倍数", "multiplier", "multiply", "double", "翻倍")):
            target = "multiplier"
            if action_type in {"upgrade", "permanent_upgrade"}:
                expected = "increase_multiplier"
        elif has_any(("等级", "level", "lv")):
            target = "level"
            if action_type in {"upgrade", "permanent_upgrade"}:
                expected = "increase_level"
        elif has_any(("容量", "capacity", "上限", "limit")):
            target = "capacity"

        parsed = parse_score_candidates(text)
        cost = None
        if parsed and (has_any(("花费", "成本", "价格", "cost", "price", "需要", "requires")) or
                       action_type in {"upgrade", "permanent_upgrade", "purchase"}):
            try:
                cost = float(max(parsed, key=lambda item: item[1])[0])
            except Exception:
                cost = None
        if has_any(("支付", "付款", "结账", "checkout", "payment", "pay now", "订购", "order now")):
            risk = 1.0
            action_type = "real_money_purchase"
            confidence = max(confidence, 0.96)
        return ActionSemantic(type=action_type, target=target, cost=cost,
                              expected_effect=expected, risk=risk, confidence=confidence)

    def _update_semantic_features_from_action(self, semantic):
        if not isinstance(semantic, ActionSemantic):
            return
        mapping = {
            "upgrade": "has_upgrade", "permanent_upgrade": "has_upgrade",
            "claim_reward": "has_reward", "purchase": "has_purchase",
            "real_money_purchase": "has_purchase", "reset": "has_reset",
            "prestige": "has_reset", "temporary_boost": "has_boost",
            "sell": "has_sell", "navigate": "has_navigation",
            "start": "has_start", "continue": "has_continue",
        }
        feature = mapping.get(semantic.type)
        if feature:
            self._semantic_features[feature] = True
        if semantic.cost is not None:
            self._semantic_features["has_cost"] = True
        if semantic.target == "multiplier":
            self._semantic_features["has_multiplier"] = True
        if semantic.target == "income_rate":
            self._semantic_features["has_income_rate"] = True

    def _ocr_scene_items(self, image, screen_rect, max_side=None):
        if image is None or not self.reader or not self.reader.engines:
            return []
        try:
            rgb = self.np.asarray(image.convert("RGB"))
            h, w = rgb.shape[:2]
            if h < 8 or w < 8:
                return []
            max_side = int(max_side or (1180 if getattr(self.hardware, "tier", "balanced") != "low" else 760))
            scale = min(1.0, max(420, max_side) / max(w, h))
            view = (self.cv2.resize(rgb, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
                    if scale < 0.995 else rgb)
            _name, engine, _weight = self.reader.engines[0]
            try:
                result = engine(view, use_det=True, use_cls=False, use_rec=True)
            except TypeError:
                result = engine(view)
            texts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
            boxes = result.get("boxes") if isinstance(result, dict) else getattr(result, "boxes", None)
            scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
            if texts is None or boxes is None:
                return []
            texts, boxes = list(texts), list(boxes)
            try:
                scores = list(scores) if scores is not None else []
            except TypeError:
                scores = []
            sx = (screen_rect[2] - screen_rect[0]) / max(1.0, float(view.shape[1]))
            sy = (screen_rect[3] - screen_rect[1]) / max(1.0, float(view.shape[0]))
            items = []
            for index, raw in enumerate(texts):
                if index >= len(boxes):
                    continue
                if isinstance(raw, dict):
                    text = raw.get("text") or raw.get("txt") or ""
                elif isinstance(raw, (tuple, list)):
                    text = raw[0] if raw else ""
                else:
                    text = raw
                text = unicodedata.normalize("NFKC", str(text)).strip()
                if not text:
                    continue
                try:
                    pts = self.np.asarray(boxes[index], dtype="float32").reshape(-1, 2)
                    if len(pts) < 2:
                        continue
                    x1, y1 = float(pts[:, 0].min()), float(pts[:, 1].min())
                    x2, y2 = float(pts[:, 0].max()), float(pts[:, 1].max())
                    bbox = (screen_rect[0] + x1 * sx, screen_rect[1] + y1 * sy,
                            screen_rect[0] + x2 * sx, screen_rect[1] + y2 * sy)
                    conf = self.reader._as_float(scores[index] if index < len(scores) else 0.68)
                    if bbox[2] - bbox[0] >= 2 and bbox[3] - bbox[1] >= 2:
                        items.append({"text": text, "bbox": bbox, "confidence": conf})
                except Exception:
                    continue
            return items
        except Exception as exc:
            self._log_runtime("scene_ocr_error", type(exc).__name__)
            return []

    @staticmethod
    def _bbox_overlap_ratio(a, b):
        try:
            ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
            ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
            inter = max(0.0, ix2 - ix1) * max(0.0, iy2 - iy1)
            area = max(1.0, (a[2] - a[0]) * (a[3] - a[1]))
            return inter / area
        except Exception:
            return 0.0

    @staticmethod
    def _number_unit(text, label):
        raw = unicodedata.normalize("NFKC", f"{label} {text}").lower()
        if "%" in raw or "百分" in raw:
            return "%"
        if any(token in raw for token in ("/s", "/sec", "每秒", "per second", "秒收益")):
            return "/s"
        if any(token in raw for token in ("ms", "毫秒")):
            return "ms"
        if any(token in raw for token in ("秒", " sec", "second")):
            return "s"
        return ""

    @staticmethod
    def _number_role(label, text, is_target=False):
        raw = unicodedata.normalize("NFKC", f"{label} {text}").lower()
        if any(token in raw for token in ("每秒", "/s", "/sec", "per second", "收入", "收益", "产量", "产出", "income", "production", "profit", "earning")):
            return "INCOME"
        if any(token in raw for token in ("成本", "花费", "价格", "售价", "cost", "price", "requires", "需要")):
            return "COST"
        if any(token in raw for token in ("倍率", "倍数", "multiplier", "multiply", " x", "×")):
            return "MULTIPLIER"
        if re.search(r"(?:^|\b)(?:lv|lvl|level)(?:\b|\.)", raw) or "等级" in raw:
            return "LEVEL"
        if any(token in raw for token in ("生命", "血量", "health", " hp", "hp ")):
            return "HEALTH"
        if any(token in raw for token in ("容量", "上限", "capacity", "maximum", " max")):
            return "CAPACITY"
        if "%" in raw or any(token in raw for token in ("进度", "progress")):
            return "PROGRESS"
        if any(token in raw for token in ("倒计时", "剩余时间", "time", "timer", " sec", "秒", "分钟", " minute")):
            return "TIME"
        if any(token in raw for token in ("金币", "金钱", "硬币", "钻石", "宝石", "现金", "余额", "资源", "gold", "coin", "money", "cash", "gem", "resource", "balance")):
            return "RESOURCE"
        if any(token in raw for token in ("数量", "个数", "count", "quantity", "qty")):
            return "COUNT"
        if any(token in raw for token in ("速度", "速率", "rate", "speed")):
            return "RATE"
        return "TARGET" if is_target else "UNKNOWN"

    @staticmethod
    def _clean_numeric_label(text):
        text = unicodedata.normalize("NFKC", str(text or "")).strip()
        text = re.sub(r"[-+−＋]?(?:\d{1,3}(?:[.,，．'’ ]\d{3})+|\d+)(?:[.,，．]\d+)?(?:[eE][-+−＋]?\d+)?", " ", text)
        text = re.sub(r"[=:：|/\-]+$", "", text).strip(" \t:：=-|[]()（）")
        return re.sub(r"\s+", " ", text)[:80]

    def _best_label_for_number(self, number_item, items):
        nb = number_item["bbox"]
        nx1, ny1, nx2, ny2 = nb
        nw, nh = max(1.0, nx2 - nx1), max(1.0, ny2 - ny1)
        ncy = (ny1 + ny2) * 0.5
        candidates = []
        own = self._clean_numeric_label(number_item.get("text", ""))
        if own and re.search(r"[A-Za-z\u4e00-\u9fff]", own):
            candidates.append((5.4, own))
        for item in items:
            if item is number_item:
                continue
            label = self._clean_numeric_label(item.get("text", ""))
            if not label or not re.search(r"[A-Za-z\u4e00-\u9fff]", label):
                continue
            bx1, by1, bx2, by2 = item["bbox"]
            bcy = (by1 + by2) * 0.5
            same_row = abs(bcy - ncy) <= max(nh, by2 - by1) * 0.82
            if same_row and bx2 <= nx1 + nw * 0.20:
                gap = max(0.0, nx1 - bx2)
                score = 4.8 - gap / max(36.0, nw * 5.0)
                candidates.append((score, label))
                continue
            horizontal_overlap = max(0.0, min(nx2, bx2) - max(nx1, bx1)) / max(1.0, min(nw, bx2 - bx1))
            if by2 <= ny1 + nh * 0.12 and horizontal_overlap >= 0.20:
                gap = max(0.0, ny1 - by2)
                score = 3.9 - gap / max(28.0, nh * 4.0)
                candidates.append((score, label))
                continue
            if same_row and bx1 >= nx2 - nw * 0.12:
                gap = max(0.0, bx1 - nx2)
                score = 3.0 - gap / max(36.0, nw * 5.0)
                candidates.append((score, label))
        if not candidates:
            return ""
        candidates.sort(reverse=True, key=lambda item: item[0])
        return candidates[0][1] if candidates[0][0] > 1.25 else ""

    def _number_entities_from_items(self, items, target_rect=None, target_value=None):
        entities = []
        number_items = []
        for item in items:
            parsed = parse_score_candidates(item.get("text", ""))
            if not parsed:
                continue
            value, _weight, parsed_text = max(parsed, key=lambda x: (x[1], len(x[2])))
            number_items.append((item, float(value), str(parsed_text)))
        target_index = None
        target_score = -1e9
        for index, (item, value, parsed_text) in enumerate(number_items):
            overlap = self._bbox_overlap_ratio(target_rect, item["bbox"]) if target_rect else 0.0
            same_value = (target_value is not None and ScoreReader._same_value(value, target_value))
            if target_rect:
                tx = (target_rect[0] + target_rect[2]) * 0.5
                ty = (target_rect[1] + target_rect[3]) * 0.5
                bx = (item["bbox"][0] + item["bbox"][2]) * 0.5
                by = (item["bbox"][1] + item["bbox"][3]) * 0.5
                distance = math.hypot(tx - bx, ty - by)
            else:
                distance = 0.0
            score = overlap * 8.0 + (3.0 if same_value else 0.0) - distance / 180.0
            if score > target_score:
                target_score, target_index = score, index
        for index, (item, value, parsed_text) in enumerate(number_items):
            is_target = target_rect is not None and index == target_index and target_score > -2.0
            label = self._best_label_for_number(item, items)
            role = self._number_role(label, item.get("text", ""), is_target=is_target)
            direction = "maximize" if is_target else ("minimize" if role in {"COST", "TIME"} else "unknown")
            entities.append(NumberEntity(
                value=value, text=str(item.get("text", ""))[:100], bbox=tuple(item["bbox"]),
                confidence=float(item.get("confidence", 0.0)), label=label,
                unit=self._number_unit(item.get("text", ""), label), role=role,
                direction=direction, is_target=is_target, source="ocr"))
        return entities

    def _update_scene_numbers(self, entities, target_value=None):
        previous = {key: entity.snapshot() if isinstance(entity, NumberEntity) else dict(entity)
                    for key, entity in self.scene_numbers.items() if isinstance(entity, (NumberEntity, dict))}
        target = next((entity for entity in entities if entity.is_target), None)
        if target is None and self.target_entity is not None:
            target = self.target_entity
        if target is not None and target_value is not None:
            target.value = float(target_value)
            target.is_target = True
            if target.role == "UNKNOWN":
                target.role = "TARGET"
        if target is not None:
            self.target_entity = target

        scene = {}
        if self.target_entity is not None:
            scene["target"] = self.target_entity
            if self.target_entity.role not in {"TARGET", "UNKNOWN"}:
                scene[self.target_entity.role.lower()] = self.target_entity
        for entity in entities:
            if entity.is_target:
                continue
            key = entity.role.lower()
            if key == "unknown":
                continue
            existing = scene.get(key)
            if existing is None or entity.confidence > existing.confidence + 0.04:
                scene[key] = entity
            elif key == "cost" and entity.value > 0 and existing.value > 0 and entity.value < existing.value:
                scene[key] = entity
        self.scene_numbers = scene
        self._scene_number_entities = list(entities)

        flags = {}
        for key in ("level", "multiplier", "income", "rate", "capacity", "resource"):
            old, new = previous.get(key), scene.get(key)
            if isinstance(new, NumberEntity):
                new_value = new.value
            elif isinstance(new, dict):
                new_value = new.get("value")
            else:
                new_value = None
            old_value = old.get("value") if isinstance(old, dict) else None
            if old_value is not None and new_value is not None:
                threshold = max(1e-9, abs(float(old_value)) * 1e-7)
                flags[f"{key}_changed"] = abs(float(new_value) - float(old_value)) > threshold
        self._number_change_flags = flags
        for role in ("cost", "multiplier", "income", "rate", "level", "capacity", "progress"):
            if role in scene:
                feature = "has_income_rate" if role in {"income", "rate"} else f"has_{role}"
                self._semantic_features[feature] = True
        structure_tokens = []
        for key, entity in sorted(scene.items()):
            if not isinstance(entity, NumberEntity):
                continue
            folded = re.sub(r"\d+(?:[.,]\d+)?", "#", unicodedata.normalize("NFKC", entity.label.lower()))
            structure_tokens.append(f"{key}:{entity.role}:{folded[:24]}:{entity.unit}")
        self._number_structure_hash = "n" + hashlib.sha1("|".join(structure_tokens).encode("utf-8", "replace")).hexdigest()[:8]

    def _bootstrap_target_semantics(self, rect, snapshot, screen, value, confidence, text):
        fallback = NumberEntity(float(value), str(text or value), tuple(rect), float(confidence),
                                role="TARGET", direction="maximize", is_target=True, source="selection")
        self.target_entity = fallback
        if snapshot is None:
            self._update_scene_numbers([fallback], target_value=value)
            return
        client = self._target_client_rect()
        if not client:
            self._update_scene_numbers([fallback], target_value=value)
            return
        crop = (max(0, int(math.floor(client[0] - screen[0]))),
                max(0, int(math.floor(client[1] - screen[1]))),
                min(snapshot.width, int(math.ceil(client[2] - screen[0]))),
                min(snapshot.height, int(math.ceil(client[3] - screen[1]))))
        if crop[2] - crop[0] < 8 or crop[3] - crop[1] < 8:
            self._update_scene_numbers([fallback], target_value=value)
            return
        image = snapshot.crop(crop)
        items = self._ocr_scene_items(image, client, max_side=1320)
        entities = self._number_entities_from_items(items, target_rect=rect, target_value=value)
        if not any(entity.is_target for entity in entities):
            entities.append(fallback)
        self._semantic_features = {}
        self._update_scene_numbers(entities, target_value=value)
        semantic_tokens = [f"num:{entity.role}:{hashlib.sha1(entity.label.encode('utf-8', 'replace')).hexdigest()[:4]}"
                           for entity in entities if entity.role != "UNKNOWN"]
        for item in items:
            semantic = self._action_semantic_from_text(item.get("text", ""))
            self._update_semantic_features_from_action(semantic)
            if semantic.type != "unknown":
                semantic_tokens.append(f"act:{semantic.type}:{semantic.target or 'any'}")
        if semantic_tokens:
            self._remember_semantic_scene(semantic_tokens)
        self._last_semantic_scan_at = time.monotonic()

    def _number_snapshot(self, score_override=None):
        snapshot = {}
        for key, entity in self.scene_numbers.items():
            if not isinstance(entity, NumberEntity):
                continue
            if key != "target" and entity is self.target_entity:
                continue
            role = "TARGET" if key == "target" else entity.role.upper()
            item = entity.snapshot()
            snapshot[role] = item
        if score_override is not None:
            target = snapshot.setdefault("TARGET", {"confidence": 1.0, "label": "", "role": "TARGET"})
            target["value"] = float(score_override)
            target["confidence"] = max(0.75, float(target.get("confidence", 0.0)))
        return snapshot

    def _number_state_signature(self, score):
        resource = self.scene_numbers.get("resource") or self.scene_numbers.get("target")
        cost = self.scene_numbers.get("cost")
        affordability = "x"
        if isinstance(resource, NumberEntity) and isinstance(cost, NumberEntity):
            ratio = float(cost.value) / max(1e-9, float(resource.value)) if resource.value > 0 else float("inf")
            if ratio <= 0.25:
                affordability = "vc"
            elif ratio <= 0.75:
                affordability = "ok"
            elif ratio <= 1.0:
                affordability = "ba"
            else:
                affordability = "no"
        income = self.scene_numbers.get("income") or self.scene_numbers.get("rate")
        income_bucket = "x"
        if isinstance(income, NumberEntity):
            value = abs(float(income.value))
            income_bucket = str(max(-3, min(12, int(math.floor(math.log10(max(1e-9, value)))))))
        cost_bucket = "x"
        if isinstance(cost, NumberEntity):
            cost_bucket = str(max(-3, min(12, int(math.floor(math.log10(max(1e-9, abs(cost.value))))))))
        level_changed = int(bool(self._number_change_flags.get("level_changed")))
        multiplier_changed = int(bool(self._number_change_flags.get("multiplier_changed")))
        structure = self._number_structure_hash[1:5] if re.fullmatch(r"n[0-9a-f]{8}", self._number_structure_hash or "") else "0000"
        return f"nf{structure}-{affordability}-i{income_bucket}-c{cost_bucket}-l{level_changed}-m{multiplier_changed}"

    def _semantic_feature_signature(self):
        names = ("has_upgrade", "has_reward", "has_cost", "has_multiplier", "has_reset",
                 "has_purchase", "has_income_rate", "has_level", "has_boost", "has_sell")
        bits = "".join("1" if self._semantic_features.get(name) else "0" for name in names)
        return "sf" + bits

    def _bind_control_number_semantics(self):
        if not self._controls or not self._scene_number_entities:
            return
        client = self._target_client_rect()
        if not client:
            return
        cw, ch = max(1.0, client[2] - client[0]), max(1.0, client[3] - client[1])
        resource = self.scene_numbers.get("resource") or self.scene_numbers.get("target")
        resource_label = resource.label if isinstance(resource, NumberEntity) else ""
        for control in self._controls.values():
            action_type = str(control.get("action_type", "unknown"))
            if action_type not in {"upgrade", "permanent_upgrade", "purchase", "temporary_boost"}:
                continue
            x1, y1, x2, y2 = control.get("bbox", (0.0, 0.0, 0.0, 0.0))
            cx, cy = control.get("center", ((x1+x2)*0.5, (y1+y2)*0.5))
            ranked = []
            for entity in self._scene_number_entities:
                if entity.is_target:
                    continue
                bx1 = (entity.bbox[0] - client[0]) / cw
                by1 = (entity.bbox[1] - client[1]) / ch
                bx2 = (entity.bbox[2] - client[0]) / cw
                by2 = (entity.bbox[3] - client[1]) / ch
                ex, ey = (bx1 + bx2) * 0.5, (by1 + by2) * 0.5
                inside = (x1 - 0.02 <= ex <= x2 + 0.02 and y1 - 0.02 <= ey <= y2 + 0.02)
                below = (x1 - 0.03 <= ex <= x2 + 0.03 and y2 <= ey <= y2 + 0.075)
                right = (x2 <= ex <= x2 + 0.09 and y1 - 0.02 <= ey <= y2 + 0.02)
                distance = math.hypot(ex - cx, ey - cy)
                role_bonus = 2.4 if entity.role == "COST" else 0.0
                spatial_bonus = 3.0 if inside else (2.0 if below else (1.5 if right else 0.0))
                score = role_bonus + spatial_bonus + entity.confidence - distance * 5.0
                if score > 0.55 and entity.value >= 0:
                    ranked.append((score, entity))
            if ranked:
                ranked.sort(reverse=True, key=lambda item: item[0])
                best = ranked[0][1]
                control["cost"] = float(best.value)
                control["cost_confidence"] = float(best.confidence)
                control["cost_resource"] = resource_label
                self._semantic_features["has_cost"] = True
            target_label = str(getattr(self.target_entity, "label", "") or "").lower()
            control_text = str(control.get("text", "")).lower()
            if target_label and target_label in control_text:
                control["target"] = target_label
                if action_type in {"upgrade", "permanent_upgrade"} and control.get("expected_effect") == "unknown":
                    control["expected_effect"] = "increase_target_or_rate"

    def _scan_scene_semantics(self, score=None, reason="periodic", force=False):
        now = time.monotonic()
        if not force and now - self._last_semantic_scan_at < LEARNING_CONFIG.semantic_refresh_seconds:
            return False
        client = self._target_client_rect()
        if not client:
            return False
        try:
            image = self.capture.grab(client)
            items = self._ocr_scene_items(image, client)
            if not items:
                return False
            target_rect = self._current_roi()
            target_value = score if score is not None else (self.target_entity.value if self.target_entity else None)
            old_hash = self._number_structure_hash
            entities = self._number_entities_from_items(items, target_rect=target_rect, target_value=target_value)
            self._semantic_features = {}
            self._update_scene_numbers(entities, target_value=target_value)
            self._bind_control_number_semantics()
            semantic_tokens = [f"num:{entity.role}:{hashlib.sha1(entity.label.encode('utf-8', 'replace')).hexdigest()[:4]}"
                               for entity in entities if entity.role != "UNKNOWN"]
            for item in items:
                semantic = self._action_semantic_from_text(item.get("text", ""))
                self._update_semantic_features_from_action(semantic)
                if semantic.type != "unknown":
                    semantic_tokens.append(f"act:{semantic.type}:{semantic.target or 'any'}")
            if semantic_tokens:
                self._remember_semantic_scene(semantic_tokens)
            self._last_semantic_scan_at = now
            changed = old_hash != self._number_structure_hash
            self._maybe_vlm_semantic_plan(image, items, changed=changed, reason=reason)
            return True
        except Exception as exc:
            self._log_runtime("semantic_scan_error", f"{reason}:{type(exc).__name__}")
            return False

    def _should_semantic_refresh(self, action, stagnant, learner_steps=0):
        if stagnant >= 12:
            return True
        if learner_steps - self._last_semantic_scan_step >= LEARNING_CONFIG.semantic_refresh_steps:
            return True
        if str(action).startswith("click:control:"):
            control = self._controls.get(str(action).split(":", 2)[2], {})
            if control.get("action_type") not in {None, "", "unknown", "navigate", "continue"}:
                return True
        return False

    def _maybe_vlm_semantic_plan(self, image, items, changed=False, reason=""):
        # Optional low-frequency VLM hook. It is completely dormant unless the runtime already
        # provides SCREEN_AI_VLM_URL; normal operation never asks the user for credentials.
        url = os.environ.get("SCREEN_AI_VLM_URL", "").strip()
        if not url:
            return
        now = time.monotonic()
        unknown = not self.target_entity or not self.target_entity.label or self.target_entity.role in {"TARGET", "UNKNOWN"}
        if not (changed or unknown or reason in {"stagnant", "new_controls", "selection"}):
            return
        if now - self._vlm_last_call < LEARNING_CONFIG.vlm_min_interval:
            return
        signature = f"{self._semantic_scene}|{self._number_structure_hash}|{self._control_graph_hash}"
        if signature == self._vlm_last_signature and not unknown:
            return
        try:
            import io
            buffer = io.BytesIO()
            image.resize((min(960, image.width), max(1, round(image.height * min(960, image.width) / max(1, image.width))))).save(buffer, format="JPEG", quality=72)
            payload = {
                "target": self.target_entity.snapshot() if self.target_entity else {},
                "numbers": [entity.snapshot() for entity in self._scene_number_entities[:28]],
                "controls": [{k: v for k, v in control.items() if k in {"id", "text", "role", "action_type", "expected_effect", "cost", "center"}}
                             for control in list(self._controls.values())[:36]],
                "ocr": [{"text": item.get("text", ""), "bbox": item.get("bbox"), "confidence": item.get("confidence", 0.0)} for item in items[:80]],
                "image_jpeg_base64": base64.b64encode(buffer.getvalue()).decode("ascii"),
                "request": "Return JSON only: target meaning, number roles, action types/effects/costs/confidence.",
            }
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            key = os.environ.get("SCREEN_AI_VLM_KEY", "").strip()
            if key:
                headers["Authorization"] = "Bearer " + key
            req = urllib.request.Request(url, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=8.0) as response:
                result = json.loads(response.read(1024 * 1024).decode("utf-8", "replace"))
            if isinstance(result, dict):
                self._vlm_plan = result
                self._apply_vlm_plan(result)
                self._vlm_last_signature = signature
                self._vlm_last_call = now
        except Exception as exc:
            self._vlm_last_call = now
            self._log_once("vlm_hook_error", "vlm_hook_error", type(exc).__name__)

    def _apply_vlm_plan(self, plan):
        if not isinstance(plan, dict):
            return
        target = plan.get("target")
        if isinstance(target, dict) and self.target_entity:
            label = str(target.get("label") or target.get("meaning") or "").strip()[:80]
            role = str(target.get("role") or "").upper().strip()
            if label:
                self.target_entity.label = label
            if role in NUMBER_ROLES and role not in {"UNKNOWN"}:
                self.target_entity.role = role
        planned_numbers = plan.get("numbers")
        if isinstance(planned_numbers, list):
            for proposed in planned_numbers[:40]:
                if not isinstance(proposed, dict):
                    continue
                role = str(proposed.get("role") or "").upper().strip()
                if role not in NUMBER_ROLES or role == "UNKNOWN":
                    continue
                label = str(proposed.get("label") or "").strip().lower()
                try:
                    proposed_value = float(proposed.get("value")) if proposed.get("value") is not None else None
                except Exception:
                    proposed_value = None
                candidates = []
                for entity in self._scene_number_entities:
                    label_score = 2.0 if label and label in str(entity.label or entity.text).lower() else 0.0
                    value_score = 0.0
                    if proposed_value is not None and ScoreReader._same_value(entity.value, proposed_value):
                        value_score = 1.5
                    if label_score + value_score > 0:
                        candidates.append((label_score + value_score + entity.confidence, entity))
                if candidates:
                    candidates.sort(reverse=True, key=lambda item: item[0])
                    candidates[0][1].role = role
            if self._scene_number_entities:
                target_value = self.target_entity.value if self.target_entity else None
                self._update_scene_numbers(self._scene_number_entities, target_value=target_value)
                self._bind_control_number_semantics()
        actions = plan.get("actions")
        if isinstance(actions, list):
            for proposed in actions[:40]:
                if not isinstance(proposed, dict):
                    continue
                control_id = str(proposed.get("control_id") or proposed.get("control") or "")
                match = self._controls.get(control_id)
                if match is None:
                    text = str(proposed.get("text") or proposed.get("control") or "").strip().lower()
                    match = next((c for c in self._controls.values() if text and text in str(c.get("text", "")).lower()), None)
                if match is None:
                    continue
                action_type = str(proposed.get("type") or proposed.get("action_type") or "").strip().lower()
                if action_type:
                    match["action_type"] = action_type[:40]
                effect = str(proposed.get("expected_effect") or "").strip().lower()
                if effect:
                    match["expected_effect"] = effect[:80]
                try:
                    confidence = float(proposed.get("confidence", 0.0))
                    match["semantic_confidence"] = max(float(match.get("semantic_confidence", 0.0)), confidence)
                except Exception:
                    pass

    @staticmethod
    def _semantic_text_features(raw_text):

        text = unicodedata.normalize("NFKC", str(raw_text or "")).strip().lower()
        compact = re.sub(r"\s+", "", text)
        if not compact:
            return 0.0, False, None
        dangerous = (
            "delete", "remove", "erase", "format", "uninstall", "exit", "quit",
            "logout", "sign out", "checkout", "pay", "payment", "pay now",
            "删除", "清空", "抹除", "格式化", "卸载", "退出", "注销", "支付",
            "付款", "结账", "订购",
        )
        destructive_progression = ("reset", "factory reset", "rebirth", "prestige",
                                   "wipe", "clear data", "drop", "destroy", "confirm purchase",
                                   "重置", "恢复出厂", "转生", "声望重置", "清除数据", "销毁")
        def has_sensitive_term(term):
            term = str(term).lower()
            if any(ord(ch) > 127 for ch in term):
                return term in text
            return re.search(r"(?<![a-z0-9_])" + re.escape(term) + r"(?![a-z0-9_])", text) is not None
        sensitive = any(has_sensitive_term(word) for word in dangerous + destructive_progression)

        strong_positive = (
            "increase", "upgrade", "boost", "gain", "level up", "levelup", "claim",
            "collect", "reward", "bonus", "double", "multiply", "multiplier", "enhance",
            "improve", "raise", "grow", "earn", "income", "production", "profit",
            "speed up", "power up", "more", "continue", "next", "start", "play",
            "add", "auto", "automate", "提升", "升级", "增加", "领取", "收集",
            "奖励", "加成", "翻倍", "倍数", "增强", "强化", "提高", "增长",
            "收益", "产量", "产出", "速度", "效率", "更多", "继续", "下一",
            "开始", "自动", "加速",
        )
        weak_positive = ("score", "points", "rate", "power", "level", "xp", "exp",
                         "value", "total", "最高", "分数", "积分", "倍率", "等级",
                         "经验", "数值", "总计")
        negative = ("decrease", "reduce", "lower", "downgrade", "minus", "spend",
                    "cost", "consume", "sacrifice", "sell", "降低", "减少", "下降",
                    "降级", "减", "花费", "消耗", "成本", "出售", "牺牲")

        intent = -0.62 if sensitive else 0.0
        if any(word in text for word in strong_positive):
            intent += 0.76
        elif any(word in text for word in weak_positive):
            intent += 0.30
        if any(word in text for word in negative):
            intent -= 0.48

        if compact in {"+", "＋", "↑", "▲", "△", "➕", "十"} or compact.startswith("+"):
            intent = max(intent, 0.88)
        mult = re.search(r"(?:x\s*(\d+(?:[.,]\d+)?)|(\d+(?:[.,]\d+)?)\s*x)", text, re.I)
        if mult:
            try:
                factor = float((mult.group(1) or mult.group(2)).replace(",", "."))
                if factor > 1.0:
                    intent = max(intent, min(0.96, 0.68 + math.log1p(factor - 1.0) * 0.12))
            except Exception:
                intent = max(intent, 0.72)
        pct = re.search(r"\+\s*(\d+(?:[.,]\d+)?)\s*%", text)
        if pct:
            try:
                amount = float(pct.group(1).replace(",", "."))
                intent = max(intent, min(0.96, 0.70 + math.log1p(amount) * 0.045))
            except Exception:
                intent = max(intent, 0.74)

        category = ("pos" if intent >= 0.45 else "neg" if intent <= -0.25 else "neutral")
        folded = re.sub(r"\d+(?:[.,]\d+)?", "#", compact)[:48]
        token = category + ":" + hashlib.sha1(folded.encode("utf-8", "replace")).hexdigest()[:6]
        return max(-1.0, min(1.0, intent)), sensitive, token

    def _remember_semantic_scene(self, tokens):
        cleaned = sorted({str(x) for x in tokens if x})[:32]
        if not cleaned:
            return self._semantic_scene
        digest = hashlib.sha1("|".join(cleaned).encode("utf-8", "replace")).hexdigest()[:8]
        candidate = "h" + digest
        if candidate != self._semantic_scene:
            self._scene_revision += 1
        self._semantic_scene = candidate
        self._semantic_tokens = tuple(cleaned)
        return candidate

    @staticmethod
    def _key_hints_from_text(raw_text):

        text = unicodedata.normalize("NFKC", str(raw_text or "")).strip().lower()
        if not text:
            return []
        aliases = {
            "space": "SPACE", "spacebar": "SPACE", "空格": "SPACE", "空格键": "SPACE",
            "enter": "ENTER", "return": "ENTER", "回车": "ENTER", "回车键": "ENTER",
            "tab": "TAB", "tab键": "TAB",
            "up": "UP", "uparrow": "UP", "上": "UP", "上键": "UP", "↑": "UP",
            "down": "DOWN", "downarrow": "DOWN", "下": "DOWN", "下键": "DOWN", "↓": "DOWN",
            "left": "LEFT", "leftarrow": "LEFT", "左": "LEFT", "左键": "LEFT", "←": "LEFT",
            "right": "RIGHT", "rightarrow": "RIGHT", "右": "RIGHT", "右键": "RIGHT", "→": "RIGHT",
            "backspace": "BACKSPACE", "退格": "BACKSPACE", "退格键": "BACKSPACE",
            "delete": "DELETE", "del": "DELETE", "删除键": "DELETE",
            "insert": "INSERT", "ins": "INSERT", "home": "HOME", "end": "END",
            "pageup": "PAGEUP", "pgup": "PAGEUP", "pagedown": "PAGEDOWN",
            "pgdn": "PAGEDOWN", "shift": "SHIFT", "ctrl": "CTRL",
            "control": "CTRL", "alt": "ALT", "win": "LWIN", "windows": "LWIN",
        }
        hints = []
        key_token = (r"spacebar|backspace|delete|insert|pageup|pagedown|uparrow|downarrow|"
                     r"leftarrow|rightarrow|windows|control|return|enter|space|tab|del|ins|"
                     r"home|end|pgup|pgdn|shift|ctrl|alt|win|up|down|left|right|"
                     r"空格键?|回车键?|tab键|退格键?|删除键|上键|下键|左键|右键|↑|↓|←|→|"
                     r"f(?:[1-9]|1\d|2[0-4])|[a-z0-9]")
        patterns = [
            rf"(?:press|tap|hit|key|按下?|按键|键)\s*[:：]?\s*[\[(【]?\s*({key_token})\s*[\])】]?",
            rf"[\[(【]\s*({key_token})\s*[\])】]",
            rf"\b({key_token})\s*key\b",
            rf"({key_token})\s*键\b",
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, text, re.I):
                token = match.group(1).lower().replace(" ", "")
                name = aliases.get(token, token.upper())
                action = f"key:{name}"
                if action in KEY_ACTIONS and action not in hints:
                    hints.append(action)
        combo_pattern = re.compile(
            rf"(ctrl|control|shift|alt|win|windows)\s*\+\s*({key_token})", re.I)
        for match in combo_pattern.finditer(text):
            left = aliases.get(match.group(1).lower(), match.group(1).upper())
            right = aliases.get(match.group(2).lower(), match.group(2).upper())
            action = f"chord:{left}+{right}"
            if left != "ESC" and right != "ESC" and action not in hints:
                hints.append(action)
        return hints

    @staticmethod
    def _control_slug(text, role, semantic):
        normalized = unicodedata.normalize("NFKC", str(text or "")).strip().lower()
        normalized = re.sub(r"\d+(?:[.,]\d+)?", "#", normalized)
        ascii_slug = re.sub(r"[^a-z0-9]+", "_", normalized).strip("_")[:34]
        if ascii_slug:
            return ascii_slug
        seed = f"{role}|{semantic}|{normalized}"
        return f"{role}_{hashlib.sha1(seed.encode('utf-8', 'replace')).hexdigest()[:10]}"

    def _register_control(self, role, text, bbox, semantic="neutral", enabled=True,
                          source="vision", score=0.0, danger=False):
        try:
            x1, y1, x2, y2 = [max(0.0, min(1.0, float(v))) for v in bbox]
            if x2 <= x1 or y2 <= y1:
                return None
            role = re.sub(r"[^a-z0-9_]+", "_", str(role or "control").lower()).strip("_") or "control"
            semantic = str(semantic or "neutral")
            action_semantic = self._action_semantic_from_text(text)
            base = self._control_slug(text, role, semantic)
            if action_semantic.type != "unknown":
                base = f"{action_semantic.type}_{base}"[:72]
            control_id = base
            center = ((x1 + x2) * 0.5, (y1 + y2) * 0.5)
            existing = self._controls.get(control_id)
            if existing:
                old = existing.get("center", center)
                if abs(old[0] - center[0]) > 0.12 or abs(old[1] - center[1]) > 0.12:
                    control_id = f"{base}_r{min(3,int(center[1]*4))}c{min(5,int(center[0]*6))}"
            self._update_semantic_features_from_action(action_semantic)
            danger = bool(danger or action_semantic.risk >= 0.92)
            item = {
                "id": control_id, "role": role, "text": str(text or "")[:120],
                "bbox": (x1, y1, x2, y2), "center": center,
                "semantic": semantic, "enabled": bool(enabled), "source": str(source),
                "score": float(score), "danger": bool(danger),
                "action": f"click:control:{control_id}",
                "action_type": action_semantic.type, "target": action_semantic.target,
                "cost_resource": action_semantic.cost_resource, "cost": action_semantic.cost,
                "expected_effect": action_semantic.expected_effect, "risk": action_semantic.risk,
                "semantic_confidence": action_semantic.confidence,
            }
            previous = self._controls.get(control_id)
            if previous is None or float(previous.get("score", -1e9)) <= float(score):
                self._controls[control_id] = item
            return self._controls.get(control_id)
        except Exception as exc:
            self._log_runtime("control_register_error", type(exc).__name__)
            return None

    def _control_graph_update(self):
        tokens = []
        for control in self._controls.values():
            if control.get("danger"):
                continue
            x, y = control.get("center", (0.5, 0.5))
            tokens.append(f"{control.get('role')}|{control.get('semantic')}|{control.get('action_type', 'unknown')}|"
                          f"{self._control_slug(control.get('text'), control.get('role'), control.get('semantic'))}|"
                          f"{int(bool(control.get('enabled', True)))}|r{min(3,int(y*4))}c{min(5,int(x*6))}")
        digest = hashlib.sha1("|".join(sorted(tokens)[:64]).encode("utf-8", "replace")).hexdigest()[:8]
        self._control_graph_hash = "c" + digest
        return self._control_graph_hash

    def _control_action_point_fraction(self, action):
        raw = str(action or "")
        if not raw.startswith("click:control:"):
            return None
        control = self._controls.get(raw.split(":", 2)[2])
        if not control or control.get("danger") or not control.get("enabled", True):
            return None
        return control.get("center")

    def _action_fraction(self, action):
        return self._control_action_point_fraction(action) or self._action_point_fraction(action)

    def _native_control_candidates(self, screen):
        if os.name != "nt" or not screen or not self.target_hwnd:
            return []
        sw, sh = screen[2] - screen[0], screen[3] - screen[1]
        if sw < 1 or sh < 1:
            return []
        controls, scene_tokens = [], []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def visit(hwnd, _lparam=0):
            try:
                if not user32.IsWindowVisible(hwnd) or not user32.IsWindowEnabled(hwnd):
                    return True
                rect = RECT()
                if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                    return True
                left, top = max(screen[0], rect.left), max(screen[1], rect.top)
                right, bottom = min(screen[2], rect.right), min(screen[3], rect.bottom)
                width, height = right - left, bottom - top
                area = width * height
                if width < 8 or height < 8 or area > sw * sh * 0.35:
                    return True
                cls = window_class(hwnd).lower()
                style = int(user32.GetWindowLongPtrW(hwnd, -16))
                known = any(token in cls for token in (
                    "button", "toolbar", "link", "listview", "treeview", "tabcontrol",
                    "combobox", "scrollbar", "trackbar", "windowsforms10"))
                notified_static = "static" in cls and bool(style & 0x0100)
                tab_stop = bool(style & 0x00010000) and "edit" not in cls
                if not (known or notified_static or tab_stop):
                    return True
                label = unicodedata.normalize("NFKC", window_title(hwnd)).strip().lower()
                intent, danger, semantic_token = self._semantic_text_features(label)
                semantic = "positive" if intent >= 0.45 else "negative" if intent <= -0.25 else "neutral"
                if semantic_token:
                    scene_tokens.append(("danger:" if danger else "") + semantic_token)
                fx1 = max(0.0, min(1.0, (left - screen[0]) / sw))
                fy1 = max(0.0, min(1.0, (top - screen[1]) / sh))
                fx2 = max(0.0, min(1.0, (right - screen[0]) / sw))
                fy2 = max(0.0, min(1.0, (bottom - screen[1]) / sh))
                if danger:
                    margin_x = min(0.025, max(0.004, (fx2 - fx1) * 0.16))
                    margin_y = min(0.025, max(0.004, (fy2 - fy1) * 0.20))
                    self._danger_regions.append((max(0.0, fx1 - margin_x), max(0.0, fy1 - margin_y),
                                                 min(1.0, fx2 + margin_x), min(1.0, fy2 + margin_y)))
                    return True
                for hinted_action in self._key_hints_from_text(label):
                    if hinted_action in KEY_ACTIONS:
                        self._dynamic_key_actions.add(hinted_action)
                        self.action_priors[hinted_action] = max(self.action_priors.get(hinted_action, 0.0), 0.76)
                        scene_tokens.append("hint:" + hinted_action)
                role = ("button" if "button" in cls else "link" if "link" in cls else
                        "tab" if "tabcontrol" in cls else "control")
                score = 650.0 + max(-0.55, intent) * 520.0 + (70.0 if role == "button" else 0.0)
                item = self._register_control(role, label, (fx1, fy1, fx2, fy2), semantic,
                                              enabled=True, source="native", score=score, danger=False)
                if item:
                    controls.append(item)
            except Exception as exc:
                self._log_runtime("native_control_error", type(exc).__name__)
            return True

        child_callback = callback_type(visit)
        try:
            visit(self.target_hwnd, 0)
            user32.EnumChildWindows(wintypes.HWND(self.target_hwnd), child_callback, 0)
        except Exception as exc:
            self._log_runtime("native_enum_error", type(exc).__name__)
            return []
        if scene_tokens:
            self._remember_semantic_scene(scene_tokens)
        return sorted(controls, key=lambda item: float(item.get("score", 0.0)), reverse=True)
    def _ocr_control_candidates(self, image, screen, force=False):
        enabled = getattr(self.hardware, "control_text_scan", False)
        if (not enabled and not force) or not self.reader or not self.reader.engines:
            return []
        available = _available_memory()
        cpu_load = getattr(self.hardware, "cpu_load_ema", 0.0)
        if available < max(850 * 1024 ** 2, self.hardware.ram * 0.065) or cpu_load > 0.93:
            return []
        if getattr(self.hardware, "on_battery", False) and not force:
            return []
        try:
            rgb = self.np.asarray(image.convert("RGB"))
            h, w = rgb.shape[:2]
            if h < 20 or w < 20:
                return []
            max_side = max(520, int(getattr(self.hardware, "control_scan_side", 1080)))
            if force and not enabled:
                max_side = min(max_side, 660)
            scale = min(1.0, max_side / max(w, h))
            work = (self.cv2.resize(rgb, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
                    if scale < 0.995 else rgb)
            _engine_name, engine, _weight = self.reader.engines[0]
            out, scene_tokens = [], []

            def run_view(view, view_weight=1.0):
                try:
                    try:
                        result = engine(view, use_det=True, use_cls=False, use_rec=True)
                    except TypeError:
                        result = engine(view)
                    txts = result.get("txts") if isinstance(result, dict) else getattr(result, "txts", None)
                    boxes = result.get("boxes") if isinstance(result, dict) else getattr(result, "boxes", None)
                    scores = result.get("scores") if isinstance(result, dict) else getattr(result, "scores", None)
                    if txts is None or boxes is None:
                        return
                    texts, box_list = list(txts), list(boxes)
                    try:
                        score_list = list(scores) if scores is not None else []
                    except TypeError:
                        score_list = []
                    wh = float(view.shape[0] * view.shape[1])
                    for index, raw_text in enumerate(texts):
                        if index >= len(box_list):
                            continue
                        text = unicodedata.normalize("NFKC", str(raw_text)).strip().lower()
                        if not text:
                            continue
                        try:
                            pts = self.np.asarray(box_list[index], dtype="float32").reshape(-1, 2)
                            if len(pts) < 2:
                                continue
                            x1, y1 = float(pts[:, 0].min()), float(pts[:, 1].min())
                            x2, y2 = float(pts[:, 0].max()), float(pts[:, 1].max())
                            bw, bh = x2 - x1, y2 - y1
                            area = max(1.0, bw * bh)
                            if bw < 4 or bh < 4 or area > wh * 0.18:
                                continue
                            fx1, fy1 = x1 / view.shape[1], y1 / view.shape[0]
                            fx2, fy2 = x2 / view.shape[1], y2 / view.shape[0]
                            conf = self.reader._as_float(score_list[index] if index < len(score_list) else 0.72)
                            intent, is_danger, semantic_token = self._semantic_text_features(text)
                            semantic = "positive" if intent >= 0.45 else "negative" if intent <= -0.25 else "neutral"
                            if semantic_token and conf >= 0.34:
                                scene_tokens.append(("danger:" if is_danger else "") + semantic_token)
                            if is_danger and conf >= 0.30:
                                margin_x = min(0.028, max(0.005, (fx2 - fx1) * 0.24))
                                margin_y = min(0.030, max(0.006, (fy2 - fy1) * 0.42))
                                self._danger_regions.append((max(0.0, fx1 - margin_x), max(0.0, fy1 - margin_y),
                                                             min(1.0, fx2 + margin_x), min(1.0, fy2 + margin_y)))
                                continue
                            if conf >= 0.42:
                                for hinted_action in self._key_hints_from_text(text):
                                    if hinted_action in KEY_ACTIONS:
                                        self._dynamic_key_actions.add(hinted_action)
                                        hint_prior = min(0.96, 0.66 + conf * 0.30)
                                        self.action_priors[hinted_action] = max(self.action_priors.get(hinted_action, 0.0), hint_prior)
                                        scene_tokens.append("hint:" + hinted_action)
                            score = (760.0 + intent * 520.0 + conf * 260.0 +
                                     min(150.0, math.log1p(area) * 17.0)) * view_weight
                            role = "button" if intent >= 0.45 else "text_control"
                            item = self._register_control(role, text, (fx1, fy1, fx2, fy2), semantic,
                                                          enabled=True, source="ocr", score=score, danger=False)
                            if item:
                                out.append(item)
                        except Exception as exc:
                            self._log_runtime("ocr_control_item_error", type(exc).__name__)
                except Exception as exc:
                    self._log_runtime("ocr_control_view_error", type(exc).__name__)

            run_view(work, 1.0)
            runtime_class = getattr(self.hardware, "runtime_class", "")
            if (len(out) < 2 and runtime_class in {"极速", "快速"} and
                    getattr(self.hardware, "cpu_load_ema", 0.0) < 0.76):
                try:
                    gray = self.cv2.cvtColor(work, self.cv2.COLOR_RGB2GRAY)
                    clahe = self.cv2.createCLAHE(clipLimit=2.6, tileGridSize=(6, 6)).apply(gray)
                    enhanced = self.cv2.cvtColor(clahe, self.cv2.COLOR_GRAY2RGB)
                    run_view(enhanced, 0.96)
                except Exception as exc:
                    self._log_runtime("ocr_control_enhance_error", type(exc).__name__)
            if scene_tokens:
                self._remember_semantic_scene(scene_tokens)
            dedup = {}
            for item in out:
                key = item.get("id")
                if key and float(item.get("score", 0.0)) > float(dedup.get(key, {}).get("score", -1e9)):
                    dedup[key] = item
            return sorted(dedup.values(), key=lambda item: float(item.get("score", 0.0)), reverse=True)
        except Exception as exc:
            self._log_runtime("ocr_control_error", type(exc).__name__)
            return []
    def _click_candidates(self, roi, stagnant=0):
        if not roi:
            return []
        cr = self._target_client_rect()
        if not cr or cr[2] - cr[0] < 80 or cr[3] - cr[1] < 80:
            return []
        self._danger_regions = []
        self._recognized_actions = set()
        self._controls = {}
        self._semantic_features = {}
        for role in ("cost", "multiplier", "income", "rate", "level", "capacity", "progress"):
            if role in self.scene_numbers:
                feature = "has_income_rate" if role in {"income", "rate"} else f"has_{role}"
                self._semantic_features[feature] = True
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"))
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
        except Exception as exc:
            self._log_runtime("candidate_capture_error", type(exc).__name__)
            return []
        h, w = gray.shape
        if not h or not w:
            return []
        native_controls = self._native_control_candidates(cr)
        force_semantics = (not self._semantic_tokens or
                           stagnant >= (18 if self.hardware.tier == "low" else 28))
        ocr_controls = self._ocr_control_candidates(image, cr, force=force_semantics)
        recognized_controls = list(native_controls) + list(ocr_controls)
        recognized_points = [(float(item.get("score", 0.0)), *item.get("center", (0.5, 0.5)))
                             for item in recognized_controls]
        points = list(recognized_points)
        self._bind_control_number_semantics()
        self._control_graph_update()
        self._last_control_count = len(self._controls)
        self._last_danger_count = len(self._danger_regions)
        memory_tight = _available_memory() < max(900 * 1024 ** 2, self.hardware.ram * 0.075)
        if memory_tight:
            rows, cols = 4, 6
        elif getattr(self.hardware, "runtime_class", "") == "极速":
            rows, cols = 7, 10
        elif self.hardware.tier == "high":
            rows, cols = 6, 9
        elif self.hardware.tier == "low":
            rows, cols = 4, 6
        else:
            rows, cols = 5, 8
        fgray = gray.astype("float32")
        for row in range(rows):
            for col in range(cols):
                x1, x2 = col * w // cols, (col + 1) * w // cols
                y1, y2 = row * h // rows, (row + 1) * h // rows
                cell = fgray[y1:y2, x1:x2]
                if cell.size < 16:
                    continue
                fx, fy = (x1 + x2) / 2 / w, (y1 + y2) / 2 / h
                if self._point_is_dangerous(fx, fy):
                    continue
                edge = (self.np.abs(self.np.diff(cell, axis=0)).mean() +
                        self.np.abs(self.np.diff(cell, axis=1)).mean())
                contrast = float(cell.std())
                points.append((contrast * 0.62 + float(edge) * 1.38, fx, fy))
        candidates = list(points)
        try:
            if memory_tight:
                max_side = 560
            elif getattr(self.hardware, "runtime_class", "") == "极速":
                max_side = 1100
            else:
                max_side = 980 if self.hardware.tier == "high" else (780 if self.hardware.tier == "balanced" else 620)
            scale = min(1.0, max_side / max(w, h))
            small = self.cv2.resize(gray, None, fx=scale, fy=scale, interpolation=self.cv2.INTER_AREA)
            blur = self.cv2.GaussianBlur(small, (3, 3), 0)
            median = float(self.np.median(blur))
            low = max(24, int(median * 0.45))
            high = min(220, max(low + 40, int(median * 1.25)))
            edges = self.cv2.Canny(blur, low, high)
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (3, 3))
            closed = self.cv2.morphologyEx(edges, self.cv2.MORPH_CLOSE, kernel)
            contours, _ = self.cv2.findContours(closed, self.cv2.RETR_LIST, self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            sh, sw = small.shape
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = bw * bh
                if not (42 <= area <= sw * sh * 0.15 and bw >= 7 and bh >= 7):
                    continue
                aspect = bw / max(1.0, bh)
                if not (0.20 <= aspect <= 9.0):
                    continue
                fx, fy = (x + bw / 2) / sw, (y + bh / 2) / sh
                if self._point_is_dangerous(fx, fy):
                    continue
                rectangularity = self.cv2.contourArea(contour) / max(1.0, area)
                perimeter = self.cv2.arcLength(contour, True)
                compact = min(1.0, perimeter / max(1.0, 2.0 * (bw + bh)))
                score = min(1.2, rectangularity * 1.4 + compact * 0.35) * 2.5 + min(2.2, math.log1p(area) / 3.8)
                boxes.append((score, fx, fy))
            boxes.sort(reverse=True)
            candidates.extend(boxes[:100])
        except Exception as exc:
            self._log_runtime("visual_candidate_error", type(exc).__name__)
        if self.hardware.tier != "low":
            try:
                corner_limit = 80 if self.hardware.tier == "high" else 52
                corners = self.cv2.goodFeaturesToTrack(gray, maxCorners=corner_limit,
                                                       qualityLevel=0.04, minDistance=max(10, min(w, h) // 48))
                if corners is not None:
                    for pt in corners.reshape(-1, 2):
                        fx, fy = float(pt[0]) / w, float(pt[1]) / h
                        if not self._point_is_dangerous(fx, fy):
                            candidates.append((0.85, fx, fy))
            except Exception as exc:
                self._log_runtime("corner_candidate_error", type(exc).__name__)
        grid = 1000
        recognized_keys = {(max(1, min(grid - 1, round(fx * grid))),
                            max(1, min(grid - 1, round(fy * grid))))
                           for _score, fx, fy in recognized_points
                           if not self._point_is_dangerous(fx, fy)}
        semantic_actions = []
        for control in sorted(self._controls.values(), key=lambda item: float(item.get("score", 0.0)), reverse=True):
            action = control.get("action")
            if action and not control.get("danger") and control.get("enabled", True):
                prior = max(0.54, min(0.99, 0.58 + float(control.get("score", 0.0)) / 2600.0))
                action_type = str(control.get("action_type", "unknown"))
                if action_type == "claim_reward":
                    prior = max(prior, 0.95)
                elif action_type in {"upgrade", "permanent_upgrade"}:
                    prior = max(prior, 0.88)
                    resource = self.scene_numbers.get("resource") or self.scene_numbers.get("target")
                    cost_value = control.get("cost")
                    if cost_value is None and isinstance(self.scene_numbers.get("cost"), NumberEntity):
                        cost_value = self.scene_numbers["cost"].value
                    if isinstance(resource, NumberEntity) and cost_value is not None and resource.value >= 0:
                        try:
                            ratio = float(cost_value) / max(1e-9, float(resource.value))
                            if ratio > 1.0:
                                prior = min(prior, 0.24)
                            elif ratio <= 0.75:
                                prior = max(prior, 0.93)
                        except Exception:
                            pass
                elif action_type in {"reset", "prestige", "real_money_purchase"}:
                    prior = min(prior, 0.10)
                elif control.get("semantic") == "positive":
                    prior = max(prior, 0.82)
                self.action_priors[action] = prior
                self._recognized_actions.add(action)
                semantic_actions.append(action)
        all_actions, seen = [], set()
        ranked_candidates = sorted(candidates, reverse=True)
        score_hi = float(ranked_candidates[0][0]) if ranked_candidates else 1.0
        score_lo = float(ranked_candidates[-1][0]) if ranked_candidates else 0.0
        span = max(1e-6, score_hi - score_lo)
        for score, fx, fy in ranked_candidates:
            if self._point_is_dangerous(fx, fy):
                continue
            qx = max(1, min(grid - 1, round(fx * grid)))
            qy = max(1, min(grid - 1, round(fy * grid)))
            action = f"mouse:{grid}:{qx}:{qy}"
            if action in seen:
                continue
            seen.add(action)
            prior = max(0.12, min(0.98, 0.12 + 0.86 * ((float(score) - score_lo) / span)))
            if (qx, qy) in recognized_keys:
                prior = max(prior, 0.78)
                self._recognized_actions.add(action)
            all_actions.append((action, prior))
        if memory_tight:
            budget = 72
        elif self.hardware.tier == "high":
            budget = 160
        elif self.hardware.tier == "balanced":
            budget = 128
        else:
            budget = 88
        budget += min(32, stagnant // 3)
        budget = min(192, budget)
        chosen = all_actions[:budget]
        result = list(dict.fromkeys(semantic_actions + [action for action, _prior in chosen]))
        self.action_priors.update(dict(chosen))
        return result[:max(budget, len(semantic_actions))]
    def _mouse_neighborhood(self, actions, radius=1, limit=18):

        out, seen = [], set()
        for action in actions:
            if not isinstance(action, str) or not action.startswith("mouse:"):
                continue
            try:
                parts = action.split(":")
                if len(parts) == 3:
                    grid, qx, qy = 20, int(parts[1]), int(parts[2])
                elif len(parts) == 4:
                    grid, qx, qy = int(parts[1]), int(parts[2]), int(parts[3])
                else:
                    continue
                grid = max(2, grid)
                parent_prior = float(self.action_priors.get(action, 0.50))
                for dy in range(-radius, radius + 1):
                    for dx in range(-radius, radius + 1):
                        if dx == 0 and dy == 0:
                            continue
                        x = max(1, min(grid - 1, qx + dx))
                        y = max(1, min(grid - 1, qy + dy))
                        candidate = f"mouse:{grid}:{x}:{y}"
                        if candidate not in seen:
                            seen.add(candidate)
                            out.append(candidate)
                            self.action_priors.setdefault(candidate, max(0.40, parent_prior * 0.92))
                            if len(out) >= limit:
                                return out

                if grid < 1000 and len(out) < limit:
                    fine_grid = min(1000, max(grid + 8, int(round(grid * 1.55))))
                    fx, fy = qx / grid, qy / grid
                    fqx = max(1, min(fine_grid - 1, round(fx * fine_grid)))
                    fqy = max(1, min(fine_grid - 1, round(fy * fine_grid)))
                    fine_radius = 2 if fine_grid - grid >= 14 else 1
                    for fdy in range(-fine_radius, fine_radius + 1):
                        for fdx in range(-fine_radius, fine_radius + 1):
                            candidate = (f"mouse:{fine_grid}:"
                                         f"{max(1, min(fine_grid - 1, fqx + fdx))}:"
                                         f"{max(1, min(fine_grid - 1, fqy + fdy))}")
                            if candidate in seen:
                                continue
                            seen.add(candidate)
                            out.append(candidate)
                            self.action_priors.setdefault(candidate,
                                                          max(0.44, parent_prior * 0.95))
                            if len(out) >= limit:
                                return out
            except Exception:
                continue
        return out

    def _visual_effect_probe(self):
        cr = self._target_client_rect()
        if not cr or self.capture is None or self.cv2 is None or self.np is None:
            return None
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            tiny = self.cv2.resize(gray, (8, 6), interpolation=self.cv2.INTER_AREA).astype("float32")
            return tiny
        except Exception:
            return None

    def _visual_effect_change(self, before_probe, after_probe):
        if before_probe is None or after_probe is None:
            return 0.0
        try:
            diff = self.np.abs(after_probe.astype("float32") - before_probe.astype("float32"))
            median = float(self.np.median(diff))
            mad = float(self.np.median(self.np.abs(diff - median)))
            threshold = max(3.5, median + 2.2 * max(1.0, mad))
            bits = diff >= threshold
            mask = 0
            # Compress 8x6 changes into a stable 6x4 regional signature.
            compact = self.cv2.resize(diff, (6, 4), interpolation=self.cv2.INTER_AREA)
            cmedian = float(self.np.median(compact))
            cmad = float(self.np.median(self.np.abs(compact - cmedian)))
            cthreshold = max(3.2, cmedian + 1.9 * max(1.0, cmad))
            for bit in (compact >= cthreshold).reshape(-1):
                mask = (mask << 1) | int(bool(bit))
            if int(bits.sum()) == 0:
                mask = 0
            self._motion_mask = int(mask) & 0xFFFFFF
            magnitude = float(diff.mean()) / 24.0 + float(self.np.percentile(diff, 85)) / 80.0
            return max(0.0, min(2.0, magnitude))
        except Exception:
            return 0.0

    def _visual_signature(self, refresh=False):
        if not refresh and self._visual_cache and self._visual_cache != "v0":
            return self._visual_cache
        cr = self._target_client_rect()
        if not cr or cr[2] - cr[0] < 1 or cr[3] - cr[1] < 1:
            return self._visual_cache or "v0"
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8").copy()

            roi = self._current_roi()
            if roi:
                x1 = max(0, int(roi[0] - cr[0] - 7))
                y1 = max(0, int(roi[1] - cr[1] - 7))
                x2 = min(rgb.shape[1], int(roi[2] - cr[0] + 7))
                y2 = min(rgb.shape[0], int(roi[3] - cr[1] + 7))
                if x2 > x1 and y2 > y1:
                    fill = self.np.median(rgb.reshape(-1, 3), axis=0).astype("uint8")
                    rgb[y1:y2, x1:x2] = fill
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY).astype("float32")

            ph = self.cv2.resize(gray, (9, 8), interpolation=self.cv2.INTER_AREA)
            pdiff = ph[:, 1:] - ph[:, :-1]

            p_deadband = max(1.6, float(ph.std()) * 0.032)
            pbits = pdiff >= p_deadband
            pvalue = 0
            for bit in pbits.reshape(-1):
                pvalue = (pvalue << 1) | int(bool(bit))

            sobelx = self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3)
            sobely = self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3)
            edge = self.cv2.magnitude(sobelx, sobely)
            eh = self.cv2.resize(edge, (9, 4), interpolation=self.cv2.INTER_AREA)
            ediff = eh[:, 1:] - eh[:, :-1]
            e_deadband = max(0.9, float(eh.std()) * 0.026)
            ebits = ediff >= e_deadband
            evalue = 0
            for bit in ebits.reshape(-1):
                evalue = (evalue << 1) | int(bool(bit))

            tiny_rgb = self.cv2.resize(rgb, (4, 3), interpolation=self.cv2.INTER_AREA).astype("float32")
            colorfulness = float((tiny_rgb.max(axis=2) - tiny_rgb.min(axis=2)).mean())
            color_bucket = max(0, min(7, int(colorfulness / 18.0)))

            layout = self.cv2.resize(gray, (4, 3), interpolation=self.cv2.INTER_AREA)
            lm = float(layout.mean())
            l_deadband = max(1.4, float(layout.std()) * 0.055)
            layout_value = 0
            for bit in (layout >= lm + l_deadband).reshape(-1):
                layout_value = (layout_value << 1) | int(bool(bit))

            candidate = (f"p{pvalue:016x}e{evalue:08x}"
                         f"c{color_bucket}l{layout_value:03x}")

            previous = self._visual_cache
            match = re.fullmatch(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)",
                                 previous or "")
            if match:
                old_p, old_e, old_c, old_l = match.groups()
                try:
                    p_distance = bin(int(old_p, 16) ^ int(f"{pvalue:016x}", 16)).count("1")
                    e_distance = bin(int(old_e, 16) ^ int(f"{evalue:08x}", 16)).count("1")
                    l_distance = bin(int(old_l, 16) ^ int(f"{layout_value:03x}", 16)).count("1")
                    color_distance = abs(int(old_c) - int(color_bucket))
                    if (p_distance <= 8 and e_distance <= 6 and l_distance <= 3 and
                            color_distance <= 1):
                        candidate = previous
                except Exception as exc:
                    self._log_once("visual_signature_compare", "visual_signature_compare_error", type(exc).__name__)
            self._visual_cache = candidate
        except Exception as exc:
            self._log_once("visual_signature", "visual_signature_error", type(exc).__name__)
        return self._visual_cache or "v0"

    def _structured_scene_signature(self, score):
        env = self._environment_identity()
        cursor_bucket = "x"
        if os.name == "nt" and user32 is not None:
            try:
                pt = POINT()
                if user32.GetCursorPos(ctypes.byref(pt)):
                    cr = self._target_client_rect() or virtual_screen_rect()
                    sw, sh = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
                    cx = max(0, min(5, int((pt.x - cr[0]) / sw * 6)))
                    cy = max(0, min(3, int((pt.y - cr[1]) / sh * 4)))
                    cursor_bucket = f"{cx}{cy}"
            except Exception as exc:
                self._log_once("cursor_bucket", "cursor_bucket_error", type(exc).__name__)
        title = env.get("title", "unknown")
        cls = env.get("class", "unknown")
        modal = int(any(token in (title + " " + cls) for token in (
            "dialog", "popup", "modal", "messagebox", "确认", "提示", "警告")))
        semantic = ",".join(sorted(self._semantic_tokens)[:18])
        features = self._semantic_feature_signature()
        raw = (f"{env.get('exe_hash')}|{cls}|{title}|controls={min(31,self._last_control_count)}|"
               f"danger={min(15,self._last_danger_count)}|modal={modal}|sem={semantic}|"
               f"features={features}|numbers={self._number_structure_hash}")
        scene_hash = hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:10]
        return f"u{scene_hash}:x{cursor_bucket}"

    def _state_key(self, score, previous, stagnant, best, refresh_visual=False):
        visual = self._visual_signature(refresh_visual)
        threshold = max(1e-9, abs(previous) * 0.0005)
        delta = score - previous
        trend = "u" if delta > threshold else ("d" if delta < -threshold else "f")
        if best is None or score >= best:
            gap = 0
        else:
            relative_gap = (best - score) / max(1.0, abs(best) * 0.002)
            gap = max(1, min(5, int(math.log1p(max(0.0, relative_gap))) + 1))
        stale = min(6, stagnant // 7)
        magnitude = 0 if score == 0 else max(-6, min(15, int(math.floor(math.log10(abs(score))))))
        semantic = self._semantic_scene or "h00000000"
        structured = self._structured_scene_signature(score)
        env = self._environment_identity()
        app_hash = str(env.get("exe_hash", "unknown"))[:8]
        if not re.fullmatch(r"[0-9a-f]{8}", app_hash):
            app_hash = hashlib.sha1(app_hash.encode("utf-8", "replace")).hexdigest()[:8]
        control_hash = self._control_graph_hash if re.fullmatch(r"c[0-9a-f]{8}", self._control_graph_hash or "") else "c00000000"
        velocity_bucket = max(-5, min(5, int(round(float(self._state_velocity) / 1.35))))
        acceleration_bucket = max(-5, min(5, int(round(float(self._state_acceleration) / 1.55))))
        motion = int(self._motion_mask) & 0xFFFFFF
        number_features = self._number_state_signature(score)
        semantic_features = self._semantic_feature_signature()
        return (f"{visual}:{semantic}:{structured}:a{app_hash}:{control_hash}:"
                f"{semantic_features}:{number_features}:"
                f"t{trend}:g{gap}:s{stale}:m{magnitude}:v{velocity_bucket}:"
                f"a{acceleration_bucket}:r{motion:06x}")
    def _perform(self, action, quality):
        if action != OBSERVE_ACTION and not self._target_input_ready(restore=True):
            self._log_runtime("input_paused", "目标程序不是前台窗口或窗口不可用")
            return False
        if self._action_is_dangerous(action):
            self._log_runtime("danger_action_blocked", action)
            return False

        def point(grid, sx, sy):
            cr = self._target_client_rect()
            if not cr:
                return None
            grid = max(2, int(grid))
            if cr[2] - cr[0] < 1 or cr[3] - cr[1] < 1:
                return None
            fx = max(0.0, min(1.0, float(sx) / grid))
            fy = max(0.0, min(1.0, float(sy) / grid))
            return (cr[0] + fx * (cr[2] - cr[0]),
                    cr[1] + fy * (cr[3] - cr[1]))

        def perform_atomic(item, allow_repeat=True):
            repeatable = item in KEY_ACTIONS or item.startswith(("mouse:", "click:"))
            repeats = (2 if allow_repeat and repeatable and quality > 1.35 else 1)
            for _ in range(repeats):
                if self.stop_event.is_set():
                    return
                if item == OBSERVE_ACTION:
                    pass
                elif item in KEY_ACTIONS:
                    duration = 0.058
                    if quality > 0.35:
                        duration = 0.090
                    if quality > 1.15:
                        duration = 0.128
                    press_keys((KEY_ACTIONS[item],), duration, self.stop_event)
                elif item.startswith("hold:"):
                    try:
                        _kind, name, milliseconds = item.split(":")
                        vk = KEY_NAME_TO_VK.get(name)
                        if vk is None:
                            return
                        duration = max(0.018, int(milliseconds) / 1000.0)
                        if quality > 0.65:
                            duration *= 1.10
                        press_keys((vk,), duration, self.stop_event)
                    except Exception:
                        return
                elif item.startswith("pulse:"):
                    try:
                        _kind, name, milliseconds, repeat_count, interval_ms = item.split(":")
                        vk = KEY_NAME_TO_VK.get(name)
                        if vk is None:
                            return
                        duration = max(0.025, min(1.2, int(milliseconds) / 1000.0))
                        count = max(2, min(10, int(repeat_count)))
                        interval = max(0.025, min(0.9, int(interval_ms) / 1000.0))
                        for pulse_index in range(count):
                            if self.stop_event.is_set():
                                break
                            press_keys((vk,), duration, self.stop_event)
                            if pulse_index + 1 < count:
                                end = time.monotonic() + interval
                                while time.monotonic() < end and not self.stop_event.is_set():
                                    time.sleep(min(0.012, max(0.002, end - time.monotonic())))
                    except Exception:
                        return
                elif item.startswith("chord:"):
                    try:
                        names = item.split(":", 1)[1].split("+")
                        vks = [KEY_NAME_TO_VK[name] for name in names
                               if name in KEY_NAME_TO_VK]
                        if len(vks) != len(names) or len(vks) < 2:
                            return
                        duration = 0.115 if quality <= 0.35 else (
                            0.175 if quality <= 1.05 else 0.235)
                        press_keys(vks, duration, self.stop_event)
                    except Exception:
                        return
                elif item.startswith("mouse:"):
                    try:
                        parts = item.split(":")
                        if len(parts) == 3:
                            grid, sx, sy = 20, parts[1], parts[2]
                        elif len(parts) == 4:
                            grid, sx, sy = int(parts[1]), parts[2], parts[3]
                        else:
                            return
                        target = point(grid, sx, sy)
                        if target:
                            click_point(*target, button="left", clicks=1,
                                        stop_event=self.stop_event)
                    except Exception:
                        return
                elif item.startswith("pointer:"):
                    try:
                        _kind, grid, sx, sy = item.split(":")
                        target = point(grid, sx, sy)
                        if target:
                            move_pointer(*target)
                    except Exception:
                        return
                elif item.startswith("click:control:"):
                    try:
                        control_id = item.split(":", 2)[2]
                        control = self._controls.get(control_id)
                        target_fraction = control.get("center") if control else None
                        if target_fraction and control.get("enabled", True) and not control.get("danger"):
                            target = point(1000, round(target_fraction[0] * 1000), round(target_fraction[1] * 1000))
                            if target:
                                click_point(*target, button="left", clicks=1, stop_event=self.stop_event)
                    except Exception as exc:
                        self._log_runtime("control_click_error", type(exc).__name__)
                        return
                elif item.startswith("click:"):
                    try:
                        _kind, button, grid, sx, sy, clicks = item.split(":")
                        target = point(grid, sx, sy)
                        if target:
                            click_point(*target, button=button, clicks=int(clicks),
                                        stop_event=self.stop_event)
                    except Exception:
                        return
                elif item.startswith("tap:"):
                    try:
                        _kind, button, grid, sx, sy, repeat_count, interval_ms, press_ms = item.split(":")
                        target = point(grid, sx, sy)
                        flags = MOUSE_BUTTONS.get(button.lower())
                        if target and flags:
                            move_pointer(*target)
                            down, up, data = flags
                            count = max(2, min(12, int(repeat_count)))
                            interval = max(0.025, min(0.9, int(interval_ms) / 1000.0))
                            press_time = max(0.018, min(0.35, int(press_ms) / 1000.0))
                            for tap_index in range(count):
                                if self.stop_event.is_set():
                                    break
                                _mouse_event(down, data)
                                end = time.monotonic() + press_time
                                try:
                                    while time.monotonic() < end and not self.stop_event.is_set():
                                        time.sleep(min(0.008, max(0.001, end - time.monotonic())))
                                finally:
                                    _mouse_event(up, data)
                                if tap_index + 1 < count:
                                    end = time.monotonic() + interval
                                    while time.monotonic() < end and not self.stop_event.is_set():
                                        time.sleep(min(0.010, max(0.002, end - time.monotonic())))
                    except Exception:
                        return
                elif item.startswith("wheel:"):
                    try:
                        _kind, axis, amount, grid, sx, sy = item.split(":")
                        target = point(grid, sx, sy)
                        if target:
                            scroll_point(*target, int(amount), horizontal=axis.lower() == "h")
                    except Exception:
                        return
                elif item.startswith("drag:"):
                    try:
                        (_kind, button, grid, sx, sy, ex, ey,
                         milliseconds) = item.split(":")
                        start = point(grid, sx, sy)
                        end = point(grid, ex, ey)
                        if start and end:
                            drag_pointer(*start, *end, button=button,
                                         duration=max(0.02, int(milliseconds) / 1000.0),
                                         stop_event=self.stop_event)
                    except Exception:
                        return
                if repeats > 1:
                    time.sleep(0.055)

        if action.startswith("macro:"):
            parts = Learner._macro_parts(action)
            for index, item in enumerate(parts):
                if self.stop_event.is_set() or not self._screen_ready():
                    break
                perform_atomic(item, allow_repeat=False)
                if index + 1 < len(parts):
                    pause = 0.045 if self.hardware.tier == "high" else 0.075
                    end = time.monotonic() + pause
                    while time.monotonic() < end and not self.stop_event.is_set():
                        time.sleep(0.012)
            return True
        perform_atomic(action, allow_repeat=True)
        return True

    def _read_current(self, verify_low_confidence=True, expected=None):
        roi = self._current_roi()
        if not roi:
            return None, 0.0
        value, confidence, _text = self.reader.read(roi, expected=expected)
        min_conf = 0.28 if self.hardware.verify_reads else 0.34
        if value is None or confidence < min_conf:
            return None, confidence

        catastrophic = False
        suspicious = False
        if expected is not None:
            scale = max(1.0, abs(expected))
            ratio = abs(value - expected) / scale
            catastrophic = ratio > 100000

            suspicious = ratio > 24 or (expected > 0 and value >= 0 and value < expected * 0.08)
        mandatory_verify = catastrophic or suspicious
        should_verify = (verify_low_confidence and
                         (mandatory_verify or
                          (self.hardware.verify_reads and confidence < 0.78)) and
                         not self.stop_event.is_set())
        if should_verify:
            reads = [(value, confidence)]
            extra = max(1 if mandatory_verify else 0, self.hardware.verify_reads)
            if catastrophic:
                extra += 1
            for _ in range(extra):
                value2, confidence2, _text2 = self.reader.read(roi, expected=expected)
                if value2 is not None and confidence2 >= min_conf:
                    reads.append((value2, confidence2))
                if self.stop_event.is_set():
                    break
                if confidence2 >= 0.90 and any(
                        ScoreReader._same_value(value2, v) for v, _c in reads[:-1]):
                    break
            ranked = []
            for candidate, conf in reads:
                support = [c for v, c in reads if ScoreReader._same_value(v, candidate)]
                ranked.append((sum(support) + 0.12 * len(support), max(support),
                               len(support), candidate))
            ranked.sort(reverse=True)
            _weight, best_conf, support, best_value = ranked[0]
            if expected is not None and support == 1:
                scale = max(1.0, abs(expected))
                if abs(best_value - expected) > scale * 100000 and best_conf < 0.94:
                    return None, best_conf
            value = best_value
            confidence = min(0.997, best_conf + 0.065 * max(0, support - 1))
        return value, confidence

    def _mouse_region_key(self, action, rows=4, cols=6):
        point = self._action_fraction(action)
        if not point:
            return "unknown"
        fx, fy = point
        col = max(0, min(cols - 1, int(fx * cols)))
        row = max(0, min(rows - 1, int(fy * rows)))
        return f"r{row}c{col}"

    def _rank_leaf_actions(self, learner, actions, state, limit=28):
        ranked = []
        for action in dict.fromkeys(actions):
            if not action or self._action_is_dangerous(action):
                continue
            quality = learner.action_quality(action, state)
            _q, n, _v = learner._value(learner.stats.get(action, {}))
            prior = max(0.0, min(1.0, float(self.action_priors.get(action, 0.50))))
            novelty = 0.16 / math.sqrt(n + 1.0)
            ranked.append((quality + (prior - 0.5) * 0.16 + novelty, action))
        ranked.sort(reverse=True)
        if len(ranked) <= limit:
            return [a for _score, a in ranked]
        proven = [a for _score, a in ranked[:max(8, limit * 2 // 3)]]
        tail = [a for _score, a in ranked[max(8, limit * 2 // 3):]]
        rotate = []
        if tail:
            start = learner.steps % len(tail)
            rotate = (tail + tail)[start:start + max(0, limit - len(proven))]
        return list(dict.fromkeys(proven + rotate))[:limit]

    def _choose_hierarchical_action(self, learner, state, stagnant, key_actions, mouse_actions):
        safe_mouse = [a for a in mouse_actions if not self._action_is_dangerous(a)]
        protected = [a for a in safe_mouse if a in self._recognized_actions or
                     self.action_priors.get(a, 0.0) >= 0.82]
        focus_limit = 78 if stagnant < 12 else (110 if stagnant < 26 else 150)
        focused = learner.focus_actions(safe_mouse, state, stagnant, self.action_priors, focus_limit)
        safe_mouse = list(dict.fromkeys(protected + focused))
        top = {
            "keyboard": list(key_actions),
            "click": [a for a in safe_mouse if a.startswith(("mouse:", "click:", "tap:", "pointer:"))],
            "wheel": [a for a in safe_mouse if a.startswith("wheel:")],
            "drag": [a for a in safe_mouse if a.startswith("drag:")],
            "wait": [OBSERVE_ACTION],
        }
        family = learner.choose_group(top, state, stagnant, self.action_priors)
        if not family:
            return None, [], "none"
        leaf = top[family]
        path = family
        if family == "keyboard":
            sub = {}
            for action in leaf:
                sub.setdefault(self._keyboard_category(action), []).append(action)
            category = learner.choose_group(sub, state, stagnant, self.action_priors)
            if category:
                leaf = sub[category]
                path += "/" + category
        elif family == "click":
            recognized_points = [self._action_fraction(a) for a in self._recognized_actions]
            recognized_points = [p for p in recognized_points if p]
            remembered = []
            for prefix in ("mouse:", "click:", "tap:", "pointer:"):
                remembered.extend(learner.preferred_actions(prefix, limit=24))
            remembered_points = [self._action_fraction(a) for a in remembered]
            remembered_points = [p for p in remembered_points if p]
            sources = {"recognized": [], "history": [], "new": []}
            for action in leaf:
                point = self._action_fraction(action)
                if not point:
                    sources["new"].append(action)
                    continue
                if any(abs(point[0]-p[0]) <= 0.018 and abs(point[1]-p[1]) <= 0.018 for p in recognized_points):
                    sources["recognized"].append(action)
                elif any(abs(point[0]-p[0]) <= 0.022 and abs(point[1]-p[1]) <= 0.022 for p in remembered_points):
                    sources["history"].append(action)
                else:
                    sources["new"].append(action)
            source = learner.choose_group(sources, state, stagnant, self.action_priors)
            if source:
                leaf = sources[source]
                path += "/" + source
        if family in {"click", "wheel", "drag"} and len(leaf) > 1:
            regions = {}
            for action in leaf:
                regions.setdefault(self._mouse_region_key(action), []).append(action)
            region = learner.choose_group(regions, state, stagnant, self.action_priors)
            if region:
                leaf = regions[region]
                path += "/" + region
        leaf = self._rank_leaf_actions(learner, leaf, state, limit=28)
        if family != "wait":
            leaf = learner.expand_actions(leaf, state, stagnant, limit=min(8, max(2, len(leaf) // 5)))
            leaf = [a for a in leaf if not self._action_is_dangerous(a)]
        action = learner.choose(leaf, state, stagnant, priors=self.action_priors) if leaf else None
        self._last_decision_family = path
        return action, leaf, path

    def _adaptive_wait(self, quality=0.0, delay_hint=0.0):
        base = self.hardware.settle
        latency = self.reader.latency if self.reader else 0.25
        capture = self.capture.latency if self.capture else 0.02
        delay = base + min(0.34, latency * 0.34 + capture * 0.45) + max(0.0, min(0.92, delay_hint))
        if quality > 0.9:
            delay += 0.045
        floor = 0.18 if self.hardware.tier == "high" else 0.22
        end = time.monotonic() + max(floor, min(1.65, delay))
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(0.022)

    def _isolation_observe(self, before, value, confidence, action_started, duration=1.5):
        current, current_conf = value, confidence
        deadline = max(time.monotonic(), float(action_started) + max(0.55, float(duration)))
        last_read = 0.0
        while time.monotonic() < deadline and not self.stop_event.is_set():
            now = time.monotonic()
            if now - last_read < 0.16:
                time.sleep(min(0.045, deadline - now))
                continue
            last_read = now
            candidate, candidate_conf = self._read_current(False, expected=current if current is not None else before)
            if candidate is None:
                continue
            if current is None:
                current, current_conf = candidate, candidate_conf
                continue
            old_delta, new_delta = current - before, candidate - before
            same_direction = (old_delta == 0 or new_delta == 0 or old_delta * new_delta >= 0)
            if same_direction or candidate_conf >= current_conf + 0.08:
                current, current_conf = candidate, max(current_conf * 0.88, candidate_conf)
        return current, current_conf, time.monotonic()

    def _run_ai(self):
        learner = None
        last_save = time.monotonic()
        last_capture_check = time.monotonic()
        reason = "用户按下 ESC，AI 已关闭"
        try:
            time.sleep(0.60)
            if self.stop_event.is_set():
                return
            learner = Learner(self._profile_file())
            score, score_conf = None, 0.0
            while not self.stop_event.is_set() and score is None:
                if self._screen_ready():
                    score, score_conf = self._read_current()
                if score is None:
                    time.sleep(0.16)
            if self.stop_event.is_set():
                return
            if learner.best is None:
                learner.best = score
            stagnant = 0
            click_actions = []
            failures = 0
            previous_score = score
            try:
                if self._scan_scene_semantics(score, reason="selection", force=True):
                    self._last_semantic_scan_step = learner.steps
            except Exception as exc:
                self._log_runtime("initial_semantic_scan_error", type(exc).__name__)
            state = self._state_key(score, score, stagnant, learner.best, True)

            if not self.stop_event.is_set():
                passive_started = time.monotonic()
                end = time.monotonic() + max(0.16, min(0.38, self.hardware.settle * 0.70))
                while time.monotonic() < end and not self.stop_event.is_set():
                    time.sleep(0.020)
                passive_score, passive_conf = self._read_current(False, expected=score)
                if passive_score is not None and passive_conf >= 0.50:
                    passive_reliability = math.sqrt(max(0.0, score_conf) * max(0.0, passive_conf))
                    passive_elapsed = max(0.06, time.monotonic() - passive_started)
                    passive_rate = Learner._rate_signal(score, passive_score, passive_elapsed, passive_reliability)
                    self._state_acceleration = passive_rate - self._state_velocity
                    self._state_velocity = passive_rate
                    learner.observe_passive(score, passive_score, state, passive_reliability, passive_elapsed)
                    previous_score, score, score_conf = score, passive_score, passive_conf
                    if learner.best is None or score > learner.best:
                        learner.best = score
            loop_count = 0
            failure_window = []
            while not self.stop_event.is_set():
                loop_count += 1
                if not self._screen_ready():
                    time.sleep(0.12)
                    continue
                roi = self._current_roi()
                refresh_every = self.hardware.candidate_refresh
                if stagnant > 18:
                    refresh_every = max(3, refresh_every // 3)
                if (learner.steps % refresh_every == 0 or not click_actions):
                    discovered = self._click_candidates(roi, stagnant=stagnant)
                    remembered = learner.preferred_actions("mouse:", limit=40)
                    refine_limit = max(24, min(96, len(remembered) * 5))
                    refine_radius = 2 if stagnant > 18 else 1
                    refined = self._mouse_neighborhood(remembered, radius=refine_radius, limit=refine_limit)
                    click_actions = list(dict.fromkeys(remembered + refined + discovered))[:240]
                if (learner.steps - self._last_semantic_scan_step >= LEARNING_CONFIG.semantic_refresh_steps or
                        (stagnant >= 12 and time.monotonic() - self._last_semantic_scan_at >= 1.6)):
                    reason_hint = "stagnant" if stagnant >= 12 else "periodic"
                    if self._scan_scene_semantics(score, reason=reason_hint, force=False):
                        self._last_semantic_scan_step = learner.steps
                key_actions = self._keyboard_candidates(learner, stagnant)
                mouse_actions = self._mouse_input_candidates(learner, click_actions, stagnant)
                refresh_state = learner.steps % self.hardware.state_every == 0
                state = self._state_key(score, previous_score, stagnant, learner.best,
                                        refresh_visual=refresh_state)
                passive_interval = 22 if self.hardware.tier == "high" else (
                    28 if self.hardware.tier == "balanced" else 36)
                scheduled_observation = (loop_count > 2 and
                                         loop_count % passive_interval == 0 and
                                         stagnant < 42)
                if scheduled_observation:
                    action, decision_actions, decision_path = OBSERVE_ACTION, [OBSERVE_ACTION], "scheduled/wait"
                else:
                    action, decision_actions, decision_path = self._choose_hierarchical_action(
                        learner, state, stagnant, key_actions, mouse_actions)
                if not action:
                    time.sleep(0.05)
                    continue
                if loop_count % 32 == 0:
                    self._log_runtime(
                        "decision",
                        f"path={decision_path} keyboard={len(key_actions)} mouse={len(mouse_actions)} "
                        f"leaf={len(decision_actions)} stagnant={stagnant} controls={self._last_control_count} "
                        f"danger={self._last_danger_count} ocr={self.reader.latency:.3f}s capture={self.capture.latency:.3f}s")
                before = score
                semantic_probe = False
                if (action != OBSERVE_ACTION and self._should_semantic_refresh(action, stagnant, learner.steps) and
                        time.monotonic() - self._last_semantic_scan_at >= 1.0):
                    semantic_probe = self._scan_scene_semantics(before, reason="action_probe", force=True)
                    if semantic_probe:
                        self._last_semantic_scan_step = learner.steps
                        state = self._state_key(score, previous_score, stagnant, learner.best, refresh_visual=False)
                numbers_before = self._number_snapshot(score_override=before)
                quality = learner.action_quality(action, state)
                delay_hint = learner.delay_hint(action)
                scene_changed = (self._last_isolation_scene != self._control_graph_hash)
                isolation_mode = learner.needs_isolation(action, state, score_conf, scene_changed)
                self._last_isolation_scene = self._control_graph_hash
                _influence_q, influence_n, _influence_v = learner.influence_value(state, action)
                probe_visual = (action != OBSERVE_ACTION and
                                (influence_n < 3 or stagnant >= 10 or learner.steps % 4 == 0))
                visual_before = self._visual_effect_probe() if probe_visual else None
                action_started = time.monotonic()
                performed = self._perform(action, quality)
                if performed is False and action != OBSERVE_ACTION:
                    time.sleep(0.12)
                    continue
                self._adaptive_wait(quality, delay_hint)
                if self.stop_event.is_set():
                    break
                new_score, new_conf = self._read_current(expected=before)
                if new_score is not None and isolation_mode and not self.stop_event.is_set():
                    new_score, new_conf, _isolated_at = self._isolation_observe(
                        before, new_score, new_conf, action_started, duration=1.5)
                if new_score is None:
                    failures += 1
                    failure_window.append(1)
                    if len(failure_window) > 24:
                        failure_window = failure_window[-24:]
                    if failures % 3 == 0:
                        try:
                            live_roi = self._current_roi()
                            self.capture.benchmark(live_roi)
                            self.hardware.capture_backend = self.capture.backend
                            self.hardware.save_tuning()
                        except Exception as exc:
                            self._log_runtime("capture_rebenchmark_error", type(exc).__name__)
                    if learner is not None:
                        learner.history.append((action, state, action_started))
                        if len(learner.history) > 14:
                            learner.history = learner.history[-14:]
                    score = before
                    previous_score = before
                    time.sleep(min(0.8, 0.08 + failures * 0.035))
                    continue
                failures = 0
                failure_window.append(0)
                if len(failure_window) > 24:
                    failure_window = failure_window[-24:]
                delayed_effect = False
                effect_observed_at = time.monotonic()
                tiny = max(1e-9, abs(before) * 1e-10)
                if abs(new_score - before) <= tiny and not self.stop_event.is_set():
                    probe_window = learner.delay_probe_window(action, stagnant)
                    target = action_started + probe_window
                    while time.monotonic() < target and not self.stop_event.is_set():
                        time.sleep(min(0.055, max(0.012, target - time.monotonic())))
                    if not self.stop_event.is_set() and time.monotonic() >= target - 0.02:
                        delayed, delayed_conf = self._read_current(False, expected=before)
                        if delayed is not None and (delayed != before or delayed_conf > new_conf):
                            delayed_effect = abs(delayed - before) > tiny
                            new_score, new_conf = delayed, delayed_conf
                            if delayed_effect:
                                effect_observed_at = time.monotonic()
                if action != OBSERVE_ACTION and abs(new_score - before) <= tiny:
                    elapsed_effect = max(0.0, effect_observed_at - action_started)
                    learner.record_delay(action, elapsed_effect, effect=False, weight=0.12)

                if abs(new_score - before) > tiny and not self.stop_event.is_set():
                    _q, action_samples, _variance = learner._value(
                        learner.stats.get(action, {}))
                    relative_change = abs(new_score - before) / max(1.0, abs(before))
                    if relative_change > 0.24 and not isolation_mode:
                        new_score, new_conf, effect_observed_at = self._isolation_observe(
                            before, new_score, new_conf, action_started, duration=1.5)
                        relative_change = abs(new_score - before) / max(1.0, abs(before))
                    needs_confirmation = (action_samples < 5 or new_conf < 0.90 or
                                          relative_change > 0.24)
                    if needs_confirmation:
                        end = time.monotonic() + min(0.18, 0.045 + self.reader.latency * 0.16)
                        while time.monotonic() < end and not self.stop_event.is_set():
                            time.sleep(0.018)
                        confirmed, confirmed_conf = self._read_current(False, expected=new_score)
                        if confirmed is not None:
                            same_direction = ((new_score - before) * (confirmed - before) > 0 or
                                              abs(confirmed - before) <= tiny)
                            if same_direction and new_score > before and confirmed > before:
                                new_score = min(new_score, confirmed)
                            elif same_direction and new_score < before and confirmed < before:

                                new_score = max(new_score, confirmed)
                            elif confirmed_conf >= new_conf - 0.03:
                                new_score = confirmed
                            new_conf = math.sqrt(max(0.0, new_conf) *
                                                 max(0.0, confirmed_conf))
                        else:
                            new_conf *= 0.72

                observation_conf = math.sqrt(max(0.0, score_conf) * max(0.0, new_conf))
                measurement_elapsed = max(0.06, time.monotonic() - action_started)
                if (action != OBSERVE_ACTION and
                        (semantic_probe or str(action).startswith("click:control:") or
                         learner.steps - self._last_semantic_scan_step >= LEARNING_CONFIG.semantic_refresh_steps) and
                        time.monotonic() - self._last_semantic_scan_at >= 0.55):
                    if self._scan_scene_semantics(new_score, reason="effect", force=True):
                        self._last_semantic_scan_step = learner.steps
                numbers_after = self._number_snapshot(score_override=new_score)
                visual_after = self._visual_effect_probe() if visual_before is not None else None
                visual_change = self._visual_effect_change(visual_before, visual_after)
                if visual_before is None:
                    self._motion_mask = 0
                transition_rate = Learner._rate_signal(before, new_score, measurement_elapsed, observation_conf)
                self._state_acceleration = transition_rate - self._state_velocity
                self._state_velocity = transition_rate
                long_q, long_n, _long_v = learner._nstep_value(state, action)
                strategic_loss = new_score < before and long_n >= 3 and long_q > 0.18
                next_stagnant = (0 if new_score > before else
                                 stagnant + (1 if strategic_loss or new_score == before else 2))
                next_state = self._state_key(
                    new_score, before, next_stagnant, learner.best,
                    refresh_visual=((learner.steps + 1) % self.hardware.state_every == 0))
                delta, reward = learner.learn(
                    action, before, new_score, state, next_state,
                    confidence=observation_conf, actions=decision_actions,
                    action_started=action_started, observed_at=effect_observed_at,
                    elapsed_seconds=measurement_elapsed, visual_change=visual_change)
                if action != OBSERVE_ACTION:
                    learner.record_numeric_effect(
                        action, state, numbers_before, numbers_after,
                        reliability=observation_conf, delay=measurement_elapsed)
                previous_score, score, score_conf = before, new_score, new_conf
                stagnant = 0 if delta > 0 else next_stagnant

                old_scene = state.split(":x", 1)[0]
                new_scene = next_state.split(":x", 1)[0]
                if old_scene != new_scene:
                    click_actions = []

                if delta > 0:
                    hot = [p for p in Learner._macro_parts(action) if p.startswith("mouse:")]
                    if hot:
                        local = self._mouse_neighborhood(hot, radius=1, limit=max(20, len(hot) * 12))
                        click_actions = list(dict.fromkeys(hot + local + click_actions))[:240]

                if (loop_count % 24 == 0 and
                        time.monotonic() - last_capture_check >= 18.0 and
                        self.capture.should_rebenchmark(self.hardware.capture_recheck_interval)):
                    try:
                        live_roi = self._current_roi()
                        old_backend = self.capture.backend
                        self.capture.benchmark(live_roi)
                        self.hardware.capture_backend = self.capture.backend
                        if self.capture.backend != old_backend:
                            self.hardware.save_tuning(force=True)
                        last_capture_check = time.monotonic()
                    except Exception as exc:
                        self._log_runtime("capture_health_error", type(exc).__name__)

                if loop_count % 16 == 0:
                    fail_rate = sum(failure_window) / max(1, len(failure_window))
                    self.hardware.live_tune(self.reader.latency, self.capture.latency,
                                            self.reader.confidence_ema, fail_rate)
                    self.reader.latency_target = self.hardware.latency_target
                    target_variants = max(self.reader.min_variants,
                                          min(self.reader.max_variants, self.hardware.ocr_variants))
                    if abs(self.reader.active_variants - target_variants) > 1:
                        self.reader.active_variants += 1 if target_variants > self.reader.active_variants else -1

                if time.monotonic() - last_save > self.hardware.save_interval:
                    try:
                        learner.save()
                    except (OSError, sqlite3.Error) as exc:
                        self._log_runtime("learner_save_error", f"{type(exc).__name__}: {exc}")
                    last_save = time.monotonic()
            if self.stop_event.is_set():
                reason = "用户按下 ESC，AI 已关闭"
        except Exception as exc:
            reason = f"AI 因错误停止：{exc}"
            self._log_runtime("ai_fatal_error", f"{type(exc).__name__}: {exc}")
        finally:
            if learner is not None:
                try:
                    learner.close()
                except Exception as exc:
                    self._log_runtime("learner_final_save_error", f"{type(exc).__name__}: {exc}")
            if self.hook:
                self.hook.close()
            summary = (f"{reason}\n当前数值：{score:g}　最高数值：{learner.best:g}　"
                       f"累计学习：{learner.steps} 步　有效提升：{learner.positive} 次") \
                if learner is not None and 'score' in locals() and score is not None else reason
            self.events.put(("stopped", summary))

    def _poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "runtime_ready":
                    self.progress.stop()
                    self.progress.configure(mode="determinate", value=100)
                    if self.data_dir:
                        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{event[1]}")
                    self.status_var.set("准备完成。点击“数值”扫描整个屏幕并选择荧光框。")
                    self.value_button.configure(state="normal")
                elif kind == "number_scan":
                    image, candidates, screen = event[1:]
                    self.root.withdraw()
                    self._selection_snapshot = image
                    self._selection_screen = screen
                    self._selection_overlay = SelectionOverlay(
                        self.root, image, candidates, screen, self.ImageTk,
                        self._selection_done)
                elif kind == "number_scan_progress":
                    self.root.deiconify()
                    self.root.lift()
                    self.selection_var.set("正在识别整张截图中的全部数值……")
                    self.status_var.set("正在分块扫描多显示器与高分辨率画面，请稍候。")
                elif kind == "number_scan_error":
                    self._selection_snapshot = None
                    self._selection_screen = None
                    self.root.deiconify()
                    self.root.lift()
                    self.selection_var.set("全屏数值扫描失败")
                    self.status_var.set(event[1])
                    self.value_button.configure(state="normal")
                elif kind == "selection":
                    value, _confidence, _text = event[1:]
                    self._selection_snapshot = None
                    self._selection_screen = None
                    self.root.deiconify()
                    self.root.lift()
                    self.value_button.configure(state="normal")
                    if value is None:
                        self.selection_var.set("未识别到数值，请重新扫描或拖框")
                        self.status_var.set("拖框范围应只包含目标数字，并留少量边距。")
                        self.confirm_button.configure(state="disabled")
                    else:
                        target_label = str(getattr(self.target_entity, "label", "") or "").strip()
                        target_role = str(getattr(self.target_entity, "role", "") or "").strip()
                        identity = f"{target_label} / {target_role}" if target_label else target_role
                        suffix = f"　语义：{identity}" if identity else ""
                        self.selection_var.set(f"已选择：{value:g}{suffix}　AI范围：目标程序窗口")
                        self.status_var.set("点击“确认”后 AI 自动开始；按 ESC 停止。")
                        self.confirm_button.configure(state="normal")
                elif kind == "stopped":
                    self.last_summary = event[1]
                    self.root.deiconify()
                    self.root.lift()
                    self.status_var.set(self.last_summary)
                    self.value_button.configure(state="normal")
                    self.confirm_button.configure(state="normal")
                elif kind == "error":
                    self.progress.stop()
                    self.status_var.set(event[1])
                    messagebox.showerror(event[1], event[2], parent=self.root)
        except queue.Empty:
            pass
        if self.root.winfo_exists():
            self.root.after(100, self._poll)

    def _close(self):
        self.stop_event.set()
        if self.hook:
            self.hook.close()
        self.root.destroy()

def main():
    if os.name != "nt" or sys.maxsize <= 2 ** 32:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "本程序仅支持 64 位 Windows 11。")
        root.destroy()
        return
    set_dpi_awareness()
    configure_winapi()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    ValueAI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
