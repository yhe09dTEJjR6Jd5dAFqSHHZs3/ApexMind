import ctypes
import hashlib
import importlib
import json
import math
import os
import platform
import queue
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
from ctypes import wintypes
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk


APP_NAME = "屏幕数值 AI"
DATA_DIR_NAME = "屏幕数值AI数据"
RAPIDOCR_VERSION = "3.9.2"
RUNTIME_SCHEMA = 8
AUTOTUNE_SCHEMA = 3
MSS_SPEC = "mss>=10.2,<12"
DXCAM_SPEC = "dxcam==0.3.0"
COMTYPES_SPEC = "comtypes>=1.4,<2"
VK_ESCAPE = 0x1B
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WH_KEYBOARD_LL = 13
GA_ROOT = 2
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_SCANCODE = 0x0008
MAPVK_VK_TO_VSC = 0
INPUT_KEYBOARD = 1
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
SM_REMOTESESSION = 0x1000
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


if os.name == "nt":
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
else:
    user32 = None
    kernel32 = None


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


ULONG_PTR = wintypes.WPARAM


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD)]


class INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]


def set_dpi_awareness():
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass


def configure_winapi():
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                                ctypes.POINTER(wintypes.DWORD)]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p,
                                         wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT,
                                          wintypes.WPARAM, wintypes.LPARAM]
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
    user32.MapVirtualKeyW.restype = wintypes.UINT
    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
    user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.IsWindowEnabled.argtypes = [wintypes.HWND]
    user32.GetWindowLongPtrW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
    user32.EnumChildWindows.restype = wintypes.BOOL
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                    wintypes.LPWSTR,
                                                    ctypes.POINTER(wintypes.DWORD)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]


def d_drive_path(value):
    try:
        resolved = os.path.realpath(os.path.abspath(str(value)))
        return resolved if os.path.splitdrive(resolved)[0].upper() == "D:" else None
    except Exception:
        return None


GIB = 1024 ** 3


_CPU_SAMPLE_LOCK = threading.Lock()
_CPU_SAMPLE = None


def _filetime_value(value):
    return (int(value.dwHighDateTime) << 32) | int(value.dwLowDateTime)


def _cpu_load():
    """Return smoothed-system-load input without WMI, psutil or a blocking sample."""
    global _CPU_SAMPLE
    if os.name != "nt":
        return None
    try:
        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        if not ctypes.windll.kernel32.GetSystemTimes(
                ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
            return None
        current = (_filetime_value(idle), _filetime_value(kernel), _filetime_value(user))
        with _CPU_SAMPLE_LOCK:
            previous, _CPU_SAMPLE = _CPU_SAMPLE, current
        if previous is None:
            return None
        idle_delta = max(0, current[0] - previous[0])
        total_delta = max(1, current[1] - previous[1] + current[2] - previous[2])
        return max(0.0, min(1.0, 1.0 - idle_delta / total_delta))
    except Exception:
        return None


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def _total_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullTotalPhys)
    except Exception:
        pass
    return 8 * GIB


def _available_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullAvailPhys)
    except Exception:
        pass
    return 4 * GIB


class SYSTEM_POWER_STATUS(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]


def _power_state():
    """Return (on_battery, battery_percent). Unknown power state is treated as AC."""
    if os.name != "nt":
        return False, None
    try:
        status = SYSTEM_POWER_STATUS()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(status)):
            on_battery = int(status.ACLineStatus) == 0
            percent = int(status.BatteryLifePercent)
            if percent > 100:
                percent = None
            return on_battery, percent
    except Exception:
        pass
    return False, None


def _cpu_topology():
    """Best-effort physical-core/clock discovery for initial OCR parallelism."""
    logical = max(1, os.cpu_count() or 1)
    if os.name != "nt":
        return max(1, logical // 2), logical, 0
    script = (
        "Get-CimInstance Win32_Processor | "
        "Select-Object NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed | "
        "ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        data = json.loads(run.stdout.strip()) if run.returncode == 0 and run.stdout.strip() else []
        if isinstance(data, dict):
            data = [data]
        physical = 0
        reported_logical = 0
        clock = 0
        for item in data if isinstance(data, list) else []:
            try:
                physical += max(0, int(item.get("NumberOfCores") or 0))
                reported_logical += max(0, int(item.get("NumberOfLogicalProcessors") or 0))
                clock = max(clock, int(item.get("MaxClockSpeed") or 0))
            except Exception:
                continue
        return max(1, physical or logical // 2), max(logical, reported_logical), max(0, clock)
    except Exception:
        return max(1, logical // 2), logical, 0


def _gpu_info():
    if os.name != "nt":
        return [], 0
    script = (
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM | ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        if run.returncode or not run.stdout.strip():
            return [], 0
        data = json.loads(run.stdout.strip())
        if isinstance(data, dict):
            data = [data]
        names, vram = [], 0
        for item in data if isinstance(data, list) else []:
            name = str(item.get("Name") or "").strip()
            lower = name.lower()
            if not name or "microsoft basic" in lower or "remote display" in lower:
                continue
            names.append(name)
            try:
                vram = max(vram, int(item.get("AdapterRAM") or 0))
            except Exception:
                pass
        return names, vram
    except Exception:
        return [], 0


def _fmt_gib(value):
    return f"{value / GIB:.1f} GB"


class HardwareProfile:
    def __init__(self, storage):
        self.storage = Path(storage)
        self.tuning_path = self.storage / "硬件自适应.json"
        self.architecture = (platform.machine() or
                             os.environ.get("PROCESSOR_ARCHITECTURE") or "unknown").lower()
        self.physical_cores, self.logical_cpus, self.max_clock_mhz = _cpu_topology()
        self.ram = _total_memory()
        self.on_battery, self.battery_percent = _power_state()
        try:
            self.disk_free = shutil.disk_usage(storage).free
        except Exception:
            self.disk_free = 8 * GIB
        self.gpu_names, self.gpu_vram = _gpu_info()
        self.has_gpu = bool(self.gpu_names)
        gpu_text = " ".join(self.gpu_names).lower()
        self.gpu_vendor = ("nvidia" if "nvidia" in gpu_text else
                           "amd" if any(x in gpu_text for x in ("amd", "radeon")) else
                           "intel" if "intel" in gpu_text else "other")
        self.cpu_text = (os.environ.get("PROCESSOR_IDENTIFIER") or "").lower()
        try:
            self.virtual_left = int(user32.GetSystemMetrics(76))
            self.virtual_top = int(user32.GetSystemMetrics(77))
            self.screen_w = max(1, int(user32.GetSystemMetrics(78)))
            self.screen_h = max(1, int(user32.GetSystemMetrics(79)))
            self.monitor_count = max(1, int(user32.GetSystemMetrics(80)))
            self.remote_session = bool(user32.GetSystemMetrics(SM_REMOTESESSION))
        except Exception:
            self.virtual_left, self.virtual_top = 0, 0
            self.screen_w, self.screen_h, self.monitor_count = 1920, 1080, 1
            self.remote_session = False
        self.dxcam_eligible = (
            self.monitor_count == 1 and self.virtual_left == 0 and self.virtual_top == 0
            and not self.remote_session and (3, 10) <= sys.version_info[:2] <= (3, 14)
        )
        screen_load = self.screen_w * self.screen_h

        # The tier drives model size, OCR redundancy, visual-state resolution and
        # action-search breadth.  RAM is deliberately weighted more heavily than the
        # nominal GPU VRAM because integrated GPUs often report misleading AdapterRAM.
        score = 0
        score += 2 if self.logical_cpus >= 12 and self.physical_cores >= 6 else (1 if self.logical_cpus >= 8 else 0)
        score += 1 if self.physical_cores >= 8 else 0
        if self.max_clock_mhz >= 3600 and self.physical_cores >= 6:
            score += 1
        elif 0 < self.max_clock_mhz < 1800:
            score -= 1
        score += 2 if self.ram >= 24 * GIB else (1 if self.ram >= 12 * GIB else 0)
        if self.on_battery:
            score -= 1
        score += 1 if self.disk_free >= 10 * GIB else 0
        score += 1 if self.has_gpu else 0
        if screen_load >= 28_000_000:
            score -= 2
        elif screen_load >= 15_000_000:
            score -= 1
        if self.ram < 6 * GIB or self.logical_cpus <= 2 or self.disk_free < 2 * GIB:
            score = -2
        if score >= 5:
            self.tier = "high"
        elif score <= 0:
            self.tier = "low"
        else:
            self.tier = "balanced"

        # DirectML is only a candidate here.  _prepare_runtime benchmarks a real OCR
        # session against CPU and keeps whichever is faster and stable on this machine.
        self.want_dml = (self.has_gpu and not self.remote_session and self.ram >= 8 * GIB
                         and self.disk_free >= 2 * GIB)
        self.backend = "dml?" if self.want_dml else "cpu"
        self.capture_backend = "mss"

        if self.tier == "high":
            self.ocr_threads = min(12, max(3, min(self.logical_cpus, self.physical_cores + 2)))
            self.settle = 0.24
            self.state_every = 1
            self.candidate_refresh = 8
            self.candidate_limit = 38
            self.ocr_variants = 11
            self.verify_reads = 2
            self.visual_shape = (22, 13)
            self.save_interval = 7
            self.rec_model = "medium"
            self.det_model = "small"
            self.ensemble = self.ram >= 12 * GIB and self.disk_free >= 4 * GIB
            self.mouse_grid = 36
            self.min_ocr_variants = 4
            self.max_ocr_variants = 16
            self.macro_limit = 8
            self.latency_target = 0.42
        elif self.tier == "low":
            self.ocr_threads = min(2, max(1, self.physical_cores))
            self.settle = 0.55
            self.state_every = 4
            self.candidate_refresh = 26
            self.candidate_limit = 14
            self.ocr_variants = 5
            self.verify_reads = 0
            self.visual_shape = (11, 7)
            self.save_interval = 22
            self.rec_model = "tiny" if self.ram < 8 * GIB else "small"
            self.det_model = "tiny"
            self.ensemble = False
            self.mouse_grid = 18
            self.min_ocr_variants = 2
            self.max_ocr_variants = 7
            self.macro_limit = 2
            self.latency_target = 0.82
        else:
            self.ocr_threads = min(8, max(2, min(self.logical_cpus, self.physical_cores + 1)))
            self.settle = 0.34
            self.state_every = 2
            self.candidate_refresh = 14
            self.candidate_limit = 26
            self.ocr_variants = 8
            self.verify_reads = 1
            self.visual_shape = (16, 10)
            self.save_interval = 11
            self.rec_model = "small"
            self.det_model = "small"
            self.ensemble = self.ram >= 10 * GIB and self.disk_free >= 4 * GIB
            self.mouse_grid = 26
            self.min_ocr_variants = 3
            self.max_ocr_variants = 13
            self.macro_limit = 5
            self.latency_target = 0.58

        # Resolution-aware click precision: a 4K/ultrawide desktop needs finer normalized
        # coordinates, while a small display benefits more from fewer, better-tested actions.
        pixels = max(1, self.screen_w * self.screen_h)
        density = math.sqrt(pixels / float(1920 * 1080))
        if density >= 1.75:
            self.mouse_grid = min(56, self.mouse_grid + 10)
            self.candidate_limit = min(50, self.candidate_limit + 6)
        elif density >= 1.30:
            self.mouse_grid = min(48, self.mouse_grid + 5)
        elif density < 0.78:
            self.mouse_grid = max(14, self.mouse_grid - 4)
            self.candidate_limit = max(12, self.candidate_limit - 3)
        self.nominal_state_every = self.state_every
        self.nominal_verify_reads = self.verify_reads
        self.nominal_candidate_limit = self.candidate_limit
        self.nominal_candidate_refresh = self.candidate_refresh
        self.nominal_ocr_variants = self.ocr_variants
        self.nominal_settle = self.settle
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        self.live_adjusted_at = 0.0
        self.cpu_load_ema = 0.45
        self.resource_pressure_ema = 0.35
        self.resource_recovery = 0
        self.cached_threads = None
        self.preferred_capture = None
        self.dml_tested_at = 0.0
        self._last_persist = 0.0
        identity = "|".join((self.architecture, self.cpu_text,
                             str(self.physical_cores), str(self.logical_cpus),
                             ";".join(self.gpu_names), str(self.monitor_count),
                             f"{self.screen_w}x{self.screen_h}",
                             f"py{sys.version_info.major}.{sys.version_info.minor}"))
        self.profile_key = hashlib.sha256(identity.encode("utf-8", "replace")).hexdigest()[:20]
        self._load_tuning()
        # A machine-specific benchmark is a better baseline than the coarse tier.  Live
        # throttling may move away from it temporarily, then converges back after load,
        # battery and memory pressure recover.
        self.nominal_ocr_variants = self.ocr_variants

    def _load_tuning(self):
        """Reuse a recent machine-specific benchmark while still revalidating at startup."""
        try:
            data = json.loads(self.tuning_path.read_text(encoding="utf-8"))
            if (int(data.get("schema", 0)) != AUTOTUNE_SCHEMA or
                    data.get("profile") != self.profile_key):
                return
            age = max(0.0, time.time() - float(data.get("saved_at", 0.0)))
            if age > 45 * 86400:
                return
            threads = int(data.get("ocr_threads", 0))
            if 1 <= threads <= self.logical_cpus:
                self.cached_threads = threads
                self.ocr_threads = threads
            capture = str(data.get("capture", "")).lower()
            if capture in {"dxcam", "mss", "pillow"}:
                self.preferred_capture = capture
            variants = int(data.get("ocr_variants", 0))
            if variants:
                self.ocr_variants = max(self.min_ocr_variants,
                                        min(self.max_ocr_variants, variants))
            self.dml_tested_at = max(0.0, float(data.get("dml_tested_at", 0.0)))
            dml_age = max(0.0, time.time() - self.dml_tested_at) if self.dml_tested_at else float("inf")
            # A failed GPU benchmark is remembered briefly. Driver/OS updates get a
            # fresh chance after two weeks without making every launch reinstall ORT.
            if data.get("backend") == "cpu" and dml_age < 14 * 86400:
                self.want_dml = False
                self.backend = "cpu"
        except Exception:
            pass

    def save_tuning(self, force=False):
        now = time.monotonic()
        if not force and now - self._last_persist < 30.0:
            return
        self._last_persist = now
        data = {
            "schema": AUTOTUNE_SCHEMA,
            "profile": self.profile_key,
            "saved_at": time.time(),
            "ocr_threads": int(self.ocr_threads),
            "ocr_variants": int(self.ocr_variants),
            "capture": str(self.capture_backend or "mss"),
            "backend": str(self.backend if self.backend in {"cpu", "dml"} else "cpu"),
            "dml_tested_at": float(self.dml_tested_at),
        }
        try:
            temp = self.tuning_path.with_suffix(".tmp")
            temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                            encoding="utf-8")
            os.replace(temp, self.tuning_path)
        except OSError:
            pass

    @property
    def tag(self):
        gpu = self.gpu_vendor if self.want_dml else "cpu"
        return f"{gpu}-{self.tier}-{self.rec_model}"

    def calibrate_runtime(self, ocr_latency, capture_latency):
        """Retune workload from measured performance instead of hardware labels alone."""
        self.ocr_latency = max(0.001, float(ocr_latency or 0.25))
        self.capture_latency = max(0.0005, float(capture_latency or 0.02))
        avail = _available_memory()
        pressure = avail / max(1.0, float(self.ram))
        self.on_battery, self.battery_percent = _power_state()
        if self.on_battery:
            self.ocr_variants = min(self.ocr_variants,
                                    min(self.max_ocr_variants, self.min_ocr_variants + 4))
            self.candidate_limit = min(self.candidate_limit, 28)
            self.verify_reads = min(self.verify_reads, 1)
        if self.ocr_latency <= 0.16 and self.capture_latency <= 0.035 and pressure >= 0.18 and not self.on_battery:
            self.runtime_class = "极速"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 4))
            self.verify_reads = max(self.verify_reads, 2)
            self.candidate_limit = min(48, max(self.candidate_limit, 34))
            self.candidate_refresh = min(self.candidate_refresh, 8)
            self.state_every = 1
            self.settle = min(self.settle, 0.20)
        elif self.ocr_latency <= 0.34 and pressure >= 0.12:
            self.runtime_class = "快速"
            self.ocr_variants = min(self.max_ocr_variants, max(self.ocr_variants, self.min_ocr_variants + 2))
            self.verify_reads = max(self.verify_reads, 1)
            self.candidate_limit = min(40, max(self.candidate_limit, 24))
            self.candidate_refresh = min(self.candidate_refresh, 13)
            self.settle = min(self.settle, 0.30)
        elif self.ocr_latency >= 0.85 or pressure < 0.08:
            self.runtime_class = "节能"
            self.ocr_variants = max(self.min_ocr_variants, min(self.ocr_variants, self.min_ocr_variants + 1))
            self.verify_reads = min(self.verify_reads, 1)
            self.candidate_limit = max(12, min(self.candidate_limit, 18))
            self.candidate_refresh = max(self.candidate_refresh, 20)
            self.state_every = max(self.state_every, 3)
            self.settle = max(self.settle, min(0.62, self.ocr_latency * 0.46))
        else:
            self.runtime_class = "均衡"
        # A live target controls ScoreReader's adaptive preprocessing budget.
        self.latency_target = max(0.24, min(1.15, self.ocr_latency * 1.75 + self.capture_latency * 1.8))
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        if not self.on_battery and pressure >= 0.10:
            self.nominal_state_every = self.state_every
            self.nominal_verify_reads = self.verify_reads
            self.nominal_candidate_limit = self.candidate_limit
            self.nominal_candidate_refresh = self.candidate_refresh
            self.nominal_ocr_variants = self.ocr_variants
            self.nominal_settle = self.settle
        self.save_tuning(force=True)

    def live_tune(self, ocr_latency, capture_latency, confidence, fail_rate=0.0):
        """Continuously retune workload from real target performance and memory pressure."""
        now = time.monotonic()
        if now - self.live_adjusted_at < 2.5:
            return False
        self.live_adjusted_at = now
        ocr_latency = max(0.002, float(ocr_latency or self.ocr_latency if hasattr(self, "ocr_latency") else 0.25))
        capture_latency = max(0.0005, float(capture_latency or self.capture_latency if hasattr(self, "capture_latency") else 0.02))
        confidence = max(0.0, min(1.0, float(confidence)))
        fail_rate = max(0.0, min(1.0, float(fail_rate)))
        pressure = _available_memory() / max(1.0, float(self.ram))
        measured_cpu = _cpu_load()
        if measured_cpu is not None:
            self.cpu_load_ema = self.cpu_load_ema * 0.72 + measured_cpu * 0.28
        self.on_battery, self.battery_percent = _power_state()
        changed = False

        memory_stress = max(0.0, min(1.0, (0.16 - pressure) / 0.12))
        cpu_stress = max(0.0, min(1.0, (self.cpu_load_ema - 0.68) / 0.30))
        battery_stress = 0.52 if self.on_battery else 0.0
        instantaneous_stress = max(memory_stress, cpu_stress, battery_stress)
        self.resource_pressure_ema = (self.resource_pressure_ema * 0.76 +
                                      instantaneous_stress * 0.24)
        if self.resource_pressure_ema < 0.30 and not self.on_battery:
            self.resource_recovery = min(12, self.resource_recovery + 1)
        else:
            self.resource_recovery = 0

        measured_target = max(0.22, min(1.25, ocr_latency * 1.70 + capture_latency * 1.7))
        if self.on_battery:
            measured_target = max(measured_target, 0.46)
            self.verify_reads = min(self.verify_reads, 1)
            cap = min(self.max_ocr_variants, self.min_ocr_variants + 4)
            if self.ocr_variants > cap:
                self.ocr_variants -= 1
                changed = True
        self.latency_target = self.latency_target * 0.82 + measured_target * 0.18

        if pressure < 0.065 or self.cpu_load_ema > 0.94:
            new_variants = max(self.min_ocr_variants,
                               min(self.ocr_variants, self.min_ocr_variants + 1))
            if new_variants != self.ocr_variants:
                self.ocr_variants = new_variants
                changed = True
            self.candidate_limit = max(10, min(self.candidate_limit, 14))
            self.candidate_refresh = max(self.candidate_refresh, 22)
            self.state_every = max(self.state_every, 3)
            self.verify_reads = min(self.verify_reads, 1)
        elif self.cpu_load_ema > 0.84:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.candidate_limit = max(12, self.candidate_limit - 1)
            self.state_every = min(5, self.state_every + 1)
        elif fail_rate >= 0.20 or confidence < 0.62:
            if ocr_latency < self.latency_target * 1.45 and self.ocr_variants < self.max_ocr_variants:
                self.ocr_variants += 1
                changed = True
            if ocr_latency < 0.58 and pressure > 0.12:
                self.verify_reads = max(self.verify_reads, 1)
            self.candidate_refresh = max(5, self.candidate_refresh - 1)
        elif ocr_latency > self.latency_target * 1.65:
            if self.ocr_variants > self.min_ocr_variants:
                self.ocr_variants -= 1
                changed = True
            self.candidate_limit = max(12, self.candidate_limit - 2)
            self.state_every = min(5, self.state_every + 1)
        elif confidence > 0.90 and fail_rate < 0.04 and pressure > 0.14:
            if ocr_latency < self.latency_target * 0.72:
                self.candidate_limit = min(52, self.candidate_limit + 1)
                self.candidate_refresh = max(6, self.candidate_refresh - 1)
                if self.cpu_load_ema < 0.70:
                    self.state_every = max(self.nominal_state_every, self.state_every - 1)
                    if not self.on_battery:
                        self.verify_reads = max(self.verify_reads,
                                                self.nominal_verify_reads)
                if self.ocr_variants < self.max_ocr_variants and confidence < 0.965:
                    self.ocr_variants += 1
                    changed = True
        # Load shedding must be reversible.  Restore one knob at a time only after a
        # sustained healthy window so the controller does not oscillate on hybrid CPUs.
        if self.resource_recovery >= 3:
            if self.candidate_limit < self.nominal_candidate_limit:
                self.candidate_limit += 1
                changed = True
            elif self.candidate_refresh > self.nominal_candidate_refresh:
                self.candidate_refresh -= 1
                changed = True
            elif self.state_every > self.nominal_state_every:
                self.state_every -= 1
                changed = True
            elif self.verify_reads < self.nominal_verify_reads and confidence < 0.94:
                self.verify_reads += 1
                changed = True
            elif (self.ocr_variants < self.nominal_ocr_variants and
                  self.cpu_load_ema < 0.70):
                self.ocr_variants += 1
                changed = True
            elif self.settle > self.nominal_settle:
                self.settle = max(self.nominal_settle, self.settle - 0.015)
                changed = True
            if changed:
                self.resource_recovery = max(0, self.resource_recovery - 2)
        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))
        if changed:
            self.save_tuning()
        return changed

    def summary(self):
        gpu = self.gpu_names[0] if self.gpu_names else "无可用 GPU"
        if len(gpu) > 34:
            gpu = gpu[:33] + "…"
        mode = ("GPU/DirectML" if self.backend == "dml" else
                "CPU" if self.backend == "cpu" else "自动测速 GPU/CPU")
        model = {"tiny": "PP-OCRv6 Tiny", "small": "PP-OCRv6 Small",
                 "medium": "PP-OCRv6 Medium"}.get(self.rec_model, self.rec_model)
        capture = (self.capture_backend or "auto").upper()
        measured = ""
        if hasattr(self, "ocr_latency"):
            measured = (f" · 实测OCR {self.ocr_latency * 1000:.0f}ms"
                        f"/{getattr(self, 'runtime_class', '自适应')}")
        if self.on_battery:
            power = f" · 电池{self.battery_percent}%" if self.battery_percent is not None else " · 电池"
        else:
            power = ""
        core_text = f"{self.physical_cores}核/{self.logical_cpus}线程 CPU"
        session = " · 远程会话" if self.remote_session else ""
        return (f"{core_text} · 内存 {_fmt_gib(self.ram)} · "
                f"D盘可用 {_fmt_gib(self.disk_free)} · {gpu}{power}{session} · {mode} · "
                f"OCR {self.ocr_threads}线程 · {model} · 截图 {capture}{measured}")


class ScreenCapture:
    """Thread-local capture with measured DXGI/MSS/Pillow selection and failover."""
    def __init__(self, mss_module, image_grab, image_module, dxcam_module=None,
                 preferred=None):
        self.mss_module = mss_module
        self.dxcam_module = dxcam_module
        self.ImageGrab = image_grab
        self.Image = image_module
        self.local = threading.local()
        available = {"pillow"}
        if mss_module is not None:
            available.add("mss")
        if dxcam_module is not None:
            available.add("dxcam")
        default = "mss" if mss_module is not None else "pillow"
        self.backend = preferred if preferred in available else default
        self.preferred = self.backend
        self.latency = 0.02
        self.failures = {name: 0 for name in available}
        self.cooldown_until = {name: 0.0 for name in available}

    def _instance(self):
        if self.mss_module is None:
            return None
        obj = getattr(self.local, "mss", None)
        if obj is None:
            obj = self.mss_module.MSS(with_cursor=False)
            self.local.mss = obj
        return obj

    def _dx_instance(self):
        if self.dxcam_module is None:
            return None
        obj = getattr(self.local, "dxcam", None)
        if obj is None:
            try:
                obj = self.dxcam_module.create(output_color="RGB", processor_backend="cv2")
            except TypeError:
                obj = self.dxcam_module.create(output_color="RGB")
            self.local.dxcam = obj
        return obj

    def _grab_dxcam(self, rect):
        obj = self._dx_instance()
        if obj is None:
            raise RuntimeError("DXCam unavailable")
        frame = None
        try:
            frame = obj.grab(region=rect, new_frame_only=False)
        except TypeError:
            frame = obj.grab(region=rect)
        if frame is None:
            time.sleep(0.004)
            try:
                frame = obj.grab(region=rect, new_frame_only=False)
            except TypeError:
                frame = obj.grab(region=rect)
        if frame is None or getattr(frame, "size", 0) == 0:
            raise RuntimeError("DXCam capture failed")
        return self.Image.fromarray(frame, mode="RGB")

    def _grab_mss(self, rect):
        obj = self._instance()
        if obj is None:
            raise RuntimeError("MSS unavailable")
        shot = obj.grab(rect)
        try:
            return shot.to_pil("RGB")
        except Exception:
            return self.Image.frombytes("RGB", shot.size, shot.rgb)

    def _grab_pillow(self, rect):
        try:
            return self.ImageGrab.grab(bbox=rect, all_screens=True)
        except TypeError:
            return self.ImageGrab.grab(bbox=rect)

    def _grab_backend(self, name, rect):
        if name == "dxcam":
            return self._grab_dxcam(rect)
        if name == "mss":
            return self._grab_mss(rect)
        return self._grab_pillow(rect)

    def _record_failure(self, name):
        count = min(7, int(self.failures.get(name, 0)) + 1)
        self.failures[name] = count
        # Broken DXGI/display drivers should not be retried on every OCR view, but a
        # transient desktop switch or monitor wake-up gets another chance later.
        self.cooldown_until[name] = time.monotonic() + min(45.0, 0.7 * (2 ** count))

    def _record_success(self, name):
        self.failures[name] = max(0, int(self.failures.get(name, 0)) - 1)
        self.cooldown_until[name] = 0.0

    def benchmark(self, rect=None):
        """Benchmark real capture paths; optionally use the exact selected score ROI."""
        if rect is None:
            left = int(user32.GetSystemMetrics(76)) if user32 else 0
            top = int(user32.GetSystemMetrics(77)) if user32 else 0
            width = max(320, int(user32.GetSystemMetrics(78))) if user32 else 1920
            height = max(240, int(user32.GetSystemMetrics(79))) if user32 else 1080
            w, h = min(640, width), min(360, height)
            x = left + max(0, (width - w) // 2)
            y = top + max(0, (height - h) // 2)
            rect = (x, y, x + w, y + h)
        rect = tuple(int(round(v)) for v in rect)
        timings = {}
        for name in ("dxcam", "mss", "pillow"):
            if name == "dxcam" and self.dxcam_module is None:
                continue
            if name == "mss" and self.mss_module is None:
                continue
            samples = []
            try:
                self._grab_backend(name, rect)
                for _ in range(4):
                    t0 = time.perf_counter()
                    image = self._grab_backend(name, rect)
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("capture failed")
                    samples.append(time.perf_counter() - t0)
                samples.sort()
                timings[name] = (samples[1] + samples[2]) * 0.5 if len(samples) >= 4 else samples[len(samples) // 2]
                self._record_success(name)
            except Exception:
                self._record_failure(name)
                continue
        if timings:
            fastest = min(timings, key=timings.get)
            # Avoid switching for a microscopic win; stability is worth a few percent.
            old = self.preferred if self.preferred in timings else fastest
            if timings.get(old, float("inf")) <= timings[fastest] * 1.08:
                fastest = old
            self.preferred = fastest
            self.backend = fastest
            self.latency = timings[fastest]
        return self.backend

    def grab(self, rect):
        rect = tuple(int(round(v)) for v in rect)
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            raise ValueError("截图区域无效")
        started = time.perf_counter()
        order = [self.preferred] + [x for x in ("dxcam", "mss", "pillow") if x != self.preferred]
        last_error = None
        try:
            for name in order:
                if name == "dxcam" and self.dxcam_module is None:
                    continue
                if name == "mss" and self.mss_module is None:
                    continue
                if (name != self.preferred and
                        time.monotonic() < self.cooldown_until.get(name, 0.0)):
                    continue
                try:
                    image = self._grab_backend(name, rect)
                    if image.width != rect[2] - rect[0] or image.height != rect[3] - rect[1]:
                        # A backend returning a stale/full-monitor frame is worse than a
                        # slightly slower correct capture on mixed-DPI and display changes.
                        expected_w, expected_h = rect[2] - rect[0], rect[3] - rect[1]
                        if image.width >= expected_w and image.height >= expected_h:
                            image = image.crop((0, 0, expected_w, expected_h))
                        else:
                            raise RuntimeError("截图后端返回了错误尺寸")
                    if image.width <= 0 or image.height <= 0:
                        raise RuntimeError("截图后端返回空画面")
                    self._record_success(name)
                    self.backend = name
                    self.preferred = name
                    return image
                except Exception as exc:
                    last_error = exc
                    self._record_failure(name)
            raise last_error or RuntimeError("没有可用的截图后端")
        finally:
            elapsed = max(0.0005, time.perf_counter() - started)
            self.latency = self.latency * 0.88 + elapsed * 0.12


class DFolderDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.current = Path("D:/")
        self.title("选择 D 盘文件夹")
        self.geometry("620x470")
        self.minsize(520, 380)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text="运行数据保存位置（仅限 D 盘）",
                  font=("Microsoft YaHei UI", 14, "bold")).grid(
                      row=0, column=0, sticky="w", padx=18, pady=(18, 8))
        self.path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.path_var, state="readonly").grid(
            row=1, column=0, sticky="ew", padx=18, pady=(0, 8))
        frame = ttk.Frame(self)
        frame.grid(row=2, column=0, sticky="nsew", padx=18)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.listbox = tk.Listbox(frame, font=("Microsoft YaHei UI", 11),
                                  activestyle="dotbox")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.listbox.bind("<Double-Button-1>", self._open_selected)
        self.listbox.bind("<Return>", self._open_selected)
        buttons = ttk.Frame(self)
        buttons.grid(row=3, column=0, sticky="ew", padx=18, pady=18)
        ttk.Button(buttons, text="上一级", command=self._up).pack(side="left")
        ttk.Button(buttons, text="新建文件夹", command=self._new_folder).pack(
            side="left", padx=8)
        ttk.Button(buttons, text="取消", command=self._cancel).pack(side="right")
        ttk.Button(buttons, text="选择当前文件夹", command=self._choose).pack(
            side="right", padx=8)
        if not Path("D:/").is_dir():
            self.after(50, self._no_drive)
        else:
            self._refresh()
        self.grab_set()
        self.focus_force()

    def _no_drive(self):
        messagebox.showerror(APP_NAME, "未检测到 D 盘。", parent=self)
        self._cancel()

    def _refresh(self):
        valid = d_drive_path(self.current)
        if not valid:
            self.current = Path("D:/")
        else:
            self.current = Path(valid)
        self.path_var.set(str(self.current))
        self.listbox.delete(0, "end")
        try:
            names = sorted((e.name for e in os.scandir(self.current)
                            if e.is_dir(follow_symlinks=False)), key=str.lower)
            for name in names:
                self.listbox.insert("end", name)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法读取该文件夹：\n{exc}", parent=self)

    def _open_selected(self, _event=None):
        selected = self.listbox.curselection()
        if not selected:
            return
        candidate = d_drive_path(self.current / self.listbox.get(selected[0]))
        if candidate and Path(candidate).is_dir():
            self.current = Path(candidate)
            self._refresh()

    def _up(self):
        parent = d_drive_path(self.current.parent)
        if parent:
            self.current = Path(parent)
            self._refresh()

    def _new_folder(self):
        name = simpledialog.askstring("新建文件夹", "文件夹名称：", parent=self)
        if not name:
            return
        name = name.strip()
        if (not name or name.endswith((" ", ".")) or
                any(ch in '<>:"/\\|?*' for ch in name)):
            messagebox.showerror(APP_NAME, "文件夹名称无效。", parent=self)
            return
        target = self.current / name
        if not d_drive_path(target):
            return
        try:
            target.mkdir()
            self.current = target
            self._refresh()
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法创建文件夹：\n{exc}", parent=self)

    def _choose(self):
        chosen = d_drive_path(self.current)
        if chosen:
            self.result = Path(chosen)
            self.grab_release()
            self.destroy()

    def _cancel(self):
        self.result = None
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class SelectionOverlay(tk.Toplevel):
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.callback = callback
        self.start = None
        self.rect_id = None
        left = user32.GetSystemMetrics(76)
        top = user32.GetSystemMetrics(77)
        width = user32.GetSystemMetrics(78)
        height = user32.GetSystemMetrics(79)
        self.left, self.top = left, top
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.attributes("-alpha", 0.34)
        self.configure(bg="black", cursor="crosshair")
        self.geometry(f"{width}x{height}{left:+d}{top:+d}")
        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0,
                                cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_text(width // 2, 42,
                                text="拖动鼠标，框住要提高的数值",
                                fill="white", font=("Microsoft YaHei UI", 18, "bold"))
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.bind("<Escape>", lambda _e: self._finish(None))
        self.focus_force()

    def _press(self, event):
        self.start = (event.x, event.y)
        if self.rect_id:
            self.canvas.delete(self.rect_id)
        self.rect_id = self.canvas.create_rectangle(event.x, event.y, event.x, event.y,
                                                    outline="#00ff88", width=3)

    def _drag(self, event):
        if self.start:
            self.canvas.coords(self.rect_id, self.start[0], self.start[1],
                               event.x, event.y)

    def _release(self, event):
        if not self.start:
            return
        x1, y1 = self.start
        x2, y2 = event.x, event.y
        if abs(x2 - x1) < 8 or abs(y2 - y1) < 8:
            return
        rect = (min(x1, x2) + self.left, min(y1, y2) + self.top,
                max(x1, x2) + self.left, max(y1, y2) + self.top)
        self._finish(rect)

    def _finish(self, rect):
        self.withdraw()
        self.update_idletasks()
        self.destroy()
        self.callback(rect)


def client_rect(hwnd):
    rect = RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
        return None
    p1, p2 = POINT(rect.left, rect.top), POINT(rect.right, rect.bottom)
    if not user32.ClientToScreen(hwnd, ctypes.byref(p1)):
        return None
    if not user32.ClientToScreen(hwnd, ctypes.byref(p2)):
        return None
    return p1.x, p1.y, p2.x, p2.y


def window_at(x, y):
    hwnd = user32.WindowFromPoint(POINT(x, y))
    return user32.GetAncestor(hwnd, GA_ROOT) if hwnd else None


def window_title(hwnd):
    length = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, len(buf))
    return buf.value or "未命名窗口"


def window_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, len(buf))
    return buf.value


def window_pid(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def process_name(pid):
    """Return a stable executable basename without leaking or persisting its full path."""
    if not pid or os.name != "nt":
        return ""
    handle = None
    try:
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, int(pid))
        if not handle:
            return ""
        size = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
            return Path(buffer.value).name.lower()[:160]
    except Exception:
        pass
    finally:
        if handle:
            try:
                kernel32.CloseHandle(handle)
            except Exception:
                pass
    return ""


def current_roi(hwnd, relative_roi, normalized_roi=None):
    cr = client_rect(hwnd)
    if not cr:
        return None
    cw, ch = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
    if normalized_roi:
        x1 = cr[0] + normalized_roi[0] * cw
        y1 = cr[1] + normalized_roi[1] * ch
        x2 = cr[0] + normalized_roi[2] * cw
        y2 = cr[1] + normalized_roi[3] * ch
    else:
        x1, y1 = cr[0] + relative_roi[0], cr[1] + relative_roi[1]
        x2, y2 = cr[0] + relative_roi[2], cr[1] + relative_roi[3]
    # Clamp to the live client rectangle. This keeps OCR valid if the target is resized
    # or moves between monitors with different DPI scaling.
    x1, x2 = max(cr[0], x1), min(cr[2], x2)
    y1, y2 = max(cr[1], y1), min(cr[3], y2)
    if x2 - x1 < 4 or y2 - y1 < 4:
        return None
    return (x1, y1, x2, y2)


def normalize_digits(text):
    text = str(text)
    superscript = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻", "0123456789+-")

    def expand_superscript(match):
        return "^" + match.group(1).translate(superscript)

    # Preserve exponent semantics before NFKC turns 10⁶ into the misleading 106.
    text = re.sub(r"(?<=10)([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)", expand_superscript, text)
    out = []
    for ch in text:
        try:
            out.append(str(unicodedata.digit(ch)))
        except (TypeError, ValueError):
            out.append(ch)
    text = "".join(out)
    text = unicodedata.normalize("NFKC", text)
    suffix_tokens = {"Qa": "\ue000", "Qi": "\ue001", "Sx": "\ue002",
                     "Sp": "\ue003", "Oc": "\ue004", "No": "\ue005",
                     "Dc": "\ue006", "Ki": "\ue007", "Mi": "\ue008",
                     "Gi": "\ue009", "Ti": "\ue00a"}
    for suffix, token in suffix_tokens.items():
        text = re.sub(rf"(?<=\d)\s*{suffix}\b", token, text, flags=re.IGNORECASE)
    text = (text.replace("−", "-").replace("—", "-").replace("–", "-")
                .replace("＋", "+").replace("，", ",").replace("．", ".")
                .replace("。", ".").replace("·", ".").replace("٫", ".")
                .replace("٬", ",").replace("％", "%").replace("﹪", "%")
                .replace("'", ",").replace("’", ",").replace("`", ",")
                .replace("\u2009", " ").replace("\u202f", " ").replace("\u00a0", " "))
    text = text.translate(str.maketrans({
        "О": "0", "о": "0", "Ο": "0", "ο": "0", "〇": "0", "Ø": "0",
        "Ι": "1", "і": "1", "ı": "1", "ⅼ": "1", "Ƽ": "2", "З": "3",
        "Ч": "4", "б": "6", "Ϭ": "6", "Ց": "9", "﹒": ".", "∙": ".",
    }))
    text = re.sub(r"(?<=\d)[:;](?=\d)", ".", text)
    # OCR confusions that are unusually common inside numeric strings.  Context guards
    # prevent a final B/M/K/T/Q suffix from being destroyed.
    for _ in range(3):
        before = text
        text = re.sub(r"(?<=\d)[OoＤD](?=\d|[.,])|(?<=[.,])[OoＤD](?=\d)", "0", text)
        text = re.sub(r"(?<=\d)[Il|](?=\d|[.,])|(?<=[.,])[Il|](?=\d)", "1", text)
        text = re.sub(r"(?<=\d)[Ss](?=\d)|(?<=[.,])[Ss](?=\d)", "5", text)
        text = re.sub(r"(?<=\d)[Zz](?=\d)|(?<=[.,])[Zz](?=\d)", "2", text)
        text = re.sub(r"(?<=\d)[Gg](?=\d)|(?<=[.,])[Gg](?=\d)", "6", text)
        text = re.sub(r"(?<=\d)[Bb](?=\d)|(?<=[.,])[Bb](?=\d)", "8", text)
        text = re.sub(r"(?<=\d)[Qq](?=\d)|(?<=[.,])[Qq](?=\d)", "9", text)
        if text == before:
            break

    def fix_numeric_run(match):
        run = match.group(0)
        if not any(ch.isdigit() for ch in run):
            return run
        mapping = {"O": "0", "o": "0", "D": "0", "I": "1", "l": "1", "L": "1", "|": "1",
                   "S": "5", "s": "5", "Z": "2", "z": "2", "G": "6", "g": "6",
                   "B": "8", "b": "8", "Q": "9", "q": "9", "A": "4", "a": "4"}
        chars = list(run)
        for i, ch in enumerate(chars):
            if ch not in mapping:
                continue
            if ch in "BbQq" and i == len(chars) - 1:
                continue
            chars[i] = mapping[ch]
        return "".join(chars)

    text = re.sub(r"[0-9OoDIlL|SsZzGgBbQqAa.,]+", fix_numeric_run, text)
    text = re.sub(r"(?<=\d)\s+(?=\d)", "", text)
    for suffix, token in suffix_tokens.items():
        text = text.replace(token, suffix)
    return text


SCORE_SUFFIX_FACTORS = {
    "": 1.0,
    "k": 1e3, "m": 1e6, "b": 1e9, "t": 1e12, "q": 1e15,
    "qa": 1e15, "qi": 1e18, "sx": 1e21, "sp": 1e24,
    "oc": 1e27, "no": 1e30, "dc": 1e33,
    "mn": 1e6, "bn": 1e9, "tn": 1e12, "tr": 1e12,
    "ki": 1024.0, "mi": 1024.0 ** 2, "gi": 1024.0 ** 3,
    "ti": 1024.0 ** 4,
    "百": 1e2, "千": 1e3, "万": 1e4, "亿": 1e8,
    "万亿": 1e12, "兆": 1e12, "京": 1e16, "垓": 1e20,
    "秭": 1e24, "穰": 1e28, "沟": 1e32, "涧": 1e36,
    "正": 1e40, "载": 1e44, "%": 1.0,
}
SCORE_SUFFIXES = tuple(sorted((x for x in SCORE_SUFFIX_FACTORS if x),
                              key=len, reverse=True))
SCORE_SUFFIX_RE = (r"(?:万亿|Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|"
                   r"[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)?")


def _mantissa_hypotheses(mantissa, suffix=""):
    raw = mantissa.replace(" ", "")
    if not raw:
        return []
    sign = ""
    if raw[:1] in "+-":
        sign, raw = raw[0], raw[1:]
    if not raw or not any(ch.isdigit() for ch in raw):
        return []
    hypotheses = []

    def add(body, weight):
        body = sign + body
        try:
            value = float(body)
        except ValueError:
            return
        if math.isfinite(value):
            hypotheses.append((value, float(weight)))

    comma, dot = raw.count(","), raw.count(".")
    if comma and dot:
        decimal = "," if raw.rfind(",") > raw.rfind(".") else "."
        grouping = "." if decimal == "," else ","
        add(raw.replace(grouping, "").replace(decimal, "."), 1.00)
        parts = re.split(r"[.,]", raw)
        if len(parts) > 1 and all(len(x) == 3 for x in parts[1:]):
            add("".join(parts), 0.82)
    elif comma or dot:
        sep = "," if comma else "."
        parts = raw.split(sep)
        if len(parts) == 2:
            left, right = parts
            if not right:
                add(left, 0.70)
            elif len(right) <= 2:
                add(left + "." + right, 1.00)
                if sep == "," and len(right) == 2 and len(left) >= 4:
                    add(left + right, 0.68)
            elif len(right) == 3:
                # A suffix strongly suggests a decimal mantissa (1.234K). Without a
                # suffix, dot is mildly decimal-biased while comma is grouping-biased.
                if suffix:
                    add(left + "." + right, 1.00)
                    add(left + right, 0.82)
                elif sep == ".":
                    add(left + "." + right, 1.00)
                    add(left + right, 0.93)
                else:
                    add(left + right, 1.00)
                    add(left + "." + right, 0.91)
            else:
                add(left + "." + right, 0.90)
                add(left + right, 0.78)
        else:
            tail3 = all(len(x) == 3 for x in parts[1:])
            if tail3:
                add("".join(parts), 1.00)
                # 1.234.567 is almost certainly grouped, but retaining a weak
                # last-separator decimal hypothesis helps unusual dashboards.
                if len(parts) <= 3:
                    add("".join(parts[:-1]) + "." + parts[-1], 0.69)
            else:
                add("".join(parts[:-1]) + "." + parts[-1], 0.93)
                add("".join(parts), 0.75)
    else:
        add(raw, 1.00)
    unique = {}
    for value, weight in hypotheses:
        key = float(value)
        if weight > unique.get(key, 0.0):
            unique[key] = weight
    return [(value, weight) for value, weight in unique.items()]


def parse_score_candidates(text):
    text = normalize_digits(text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*\^\s*([-+]?\d+)", r"e\1", text)
    text = re.sub(r"(?<=\d)\s*[xX×*]\s*10\s*([-+]\d+)", r"e\1", text)
    text = re.sub(r"(?<![\dxX×*])10\s*\^\s*([-+]?\d+)", r"1e\1", text)
    pattern = re.compile(
        r"[-+]?(?:(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?|[.,]\d+)"
        r"(?:[eE][-+]?\d+)?\s*" + SCORE_SUFFIX_RE, re.IGNORECASE)
    results = []

    # Chinese counters can contain descending additive units, for example
    # 1亿2345万. Treat the complete run as one value in addition to its substrings.
    compound_re = re.compile(
        r"[-+]?(?:\d+(?:[.,]\d+)?)\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
        r"(?:\s*\d+(?:[.,]\d+)?\s*(?:载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百))+"
    )
    unit_re = re.compile(
        r"([-+]?\d+(?:[.,]\d+)?)\s*(载|正|涧|沟|穰|秭|垓|京|兆|万亿|亿|万|千|百)"
    )
    for compound in compound_re.finditer(text):
        parts = unit_re.findall(compound.group(0))
        factors = [SCORE_SUFFIX_FACTORS.get(unit, 1.0) for _number, unit in parts]
        if len(parts) < 2 or any(a <= b for a, b in zip(factors, factors[1:])):
            continue
        total = 0.0
        valid = True
        for (number, unit), factor in zip(parts, factors):
            hypotheses = _mantissa_hypotheses(number, unit)
            if not hypotheses:
                valid = False
                break
            base, _weight = max(hypotheses, key=lambda item: item[1])
            total += base * factor
        if valid and math.isfinite(total):
            results.append((total, 1.075, compound.group(0)))

    for match in pattern.finditer(text):
        token = match.group(0).strip()
        if not token:
            continue
        clean = token.replace(" ", "")
        suffix = ""
        lower_clean = clean.lower()
        for candidate in SCORE_SUFFIXES:
            if lower_clean.endswith(candidate.lower()):
                suffix = candidate
                clean = clean[:-len(candidate)]
                break
        exp_match = re.search(r"[eE][-+]?\d+$", clean)
        exponent = exp_match.group(0) if exp_match else ""
        mantissa = clean[:-len(exponent)] if exponent else clean
        factor = SCORE_SUFFIX_FACTORS.get(suffix,
                    SCORE_SUFFIX_FACTORS.get(suffix.lower(), 1.0))
        digit_count = sum(ch.isdigit() for ch in token)
        token_weight = min(1.08, 0.91 + digit_count * 0.018)
        for base, parse_weight in _mantissa_hypotheses(mantissa, suffix):
            try:
                if exponent:
                    base *= 10.0 ** int(exponent[1:])
                value = base * factor
            except (OverflowError, ValueError):
                continue
            # Accounting/dashboard notation commonly renders negatives in parentheses.
            prefix = text[max(0, match.start() - 2):match.start()]
            suffix_text = text[match.end():match.end() + 2]
            if "(" in prefix and ")" in suffix_text and value > 0:
                value = -value
            if math.isfinite(value):
                results.append((value, parse_weight * token_weight, token))
    # Preserve distinct punctuation interpretations but deduplicate duplicate regex paths.
    dedup = {}
    for value, weight, token in results:
        key = float(value)
        old = dedup.get(key)
        if old is None or weight > old[0]:
            dedup[key] = (weight, token)
    return [(value, weight, token) for value, (weight, token) in dedup.items()]


def parse_score(text):
    candidates = parse_score_candidates(text)
    if not candidates:
        return None
    value, _weight, _token = max(
        candidates, key=lambda item: (item[1], sum(ch.isdigit() for ch in item[2]), len(item[2])))
    return value


class ScoreReader:
    """Hardware-adaptive OCR ensemble specialized for numeric UI text.

    It combines preprocessing diversity, crop diversity, model diversity, numeric grammar,
    temporal evidence and an expected-value prior. Strong contradictory OCR evidence always
    wins, so legitimate large jumps are not suppressed.
    """
    def __init__(self, engines, capture, image_ops, image_module, np_module,
                 cv2_module, max_variants=6, hardware=None):
        self.engines = list(engines)
        self.capture = capture
        self.ImageOps = image_ops
        self.Image = image_module
        self.np = np_module
        self.cv2 = cv2_module
        self.hardware = hardware
        self.max_variants = max(2, int(max_variants))
        if hardware is not None:
            self.max_variants = max(self.max_variants, int(hardware.max_ocr_variants))
            self.min_variants = int(hardware.min_ocr_variants)
            self.latency_target = float(hardware.latency_target)
        else:
            self.min_variants = 2
            self.latency_target = 0.60
        self.active_variants = max(self.min_variants, min(self.max_variants, int(max_variants)))
        self.latency = 0.25
        self.confidence_ema = 0.78
        self.fail_streak = 0
        self.last_value = None
        self.last_confidence = 0.0
        self.last_text = ""
        self.recent = []
        self.source_skill = {}
        self._digit_templates = None
        self._letter_templates = None
        self.character_detail_variants = (0 if hardware is not None and hardware.tier == "low"
                                          else (3 if hardware is not None and hardware.tier == "high"
                                                else 2))

    @staticmethod
    def _as_float(value, default=0.5):
        try:
            if isinstance(value, (list, tuple)):
                value = value[0] if value else default
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return default

    def _extract_lines(self, result):
        lines = []
        txts = (result.get("txts") if isinstance(result, dict) else
                getattr(result, "txts", None))
        scores = (result.get("scores") if isinstance(result, dict) else
                  getattr(result, "scores", None))
        if txts is not None:
            try:
                texts = list(txts)
            except TypeError:
                texts = [txts]
            try:
                score_list = list(scores) if scores is not None and not isinstance(
                    scores, (str, bytes, float, int)) else []
            except TypeError:
                score_list = []
            for i, item in enumerate(texts):
                conf = score_list[i] if i < len(score_list) else scores
                if isinstance(item, (tuple, list)):
                    text = item[0] if item else ""
                    if len(item) > 1 and (conf is None or not score_list):
                        conf = item[1]
                elif isinstance(item, dict):
                    text = item.get("text") or item.get("txt") or ""
                    conf = item.get("score", conf)
                else:
                    text = item
                if str(text).strip():
                    lines.append((str(text), self._as_float(conf)))
            if lines:
                return lines
        body = result[0] if isinstance(result, (tuple, list)) and len(result) == 2 else result
        if isinstance(body, (tuple, list)):
            for item in body:
                if isinstance(item, (tuple, list)) and len(item) >= 2:
                    text = item[1]
                    conf = item[2] if len(item) > 2 else 0.5
                    if str(text).strip():
                        lines.append((str(text), self._as_float(conf)))
        return lines

    def _extract_character_lines(self, result):
        """Recover per-character output when RapidOCR exposes it, across v3 shapes."""
        body = (result.get("word_results") if isinstance(result, dict) else
                getattr(result, "word_results", None))
        if not body:
            return []
        rows = []

        def collect(node, parts):
            if isinstance(node, dict):
                token = node.get("text") or node.get("txt") or node.get("word")
                confidence = node.get("score", node.get("confidence"))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
                for child in node.values():
                    collect(child, parts)
                return
            if not isinstance(node, (str, bytes, tuple, list)):
                token = (getattr(node, "text", None) or getattr(node, "txt", None) or
                         getattr(node, "word", None))
                confidence = getattr(node, "score", getattr(node, "confidence", None))
                if token is not None and confidence is not None:
                    token = str(token)
                    if token:
                        parts.append((token, self._as_float(confidence)))
                    return
            if (isinstance(node, (tuple, list)) and len(node) >= 2 and
                    isinstance(node[0], str) and
                    not isinstance(node[1], (str, bytes, tuple, list, dict))):
                token = str(node[0])
                if token:
                    parts.append((token, self._as_float(node[1])))
                return
            if isinstance(node, (tuple, list)):
                for child in node:
                    collect(child, parts)

        try:
            outer = list(body) if isinstance(body, (tuple, list)) else [body]
            def is_leaf(node):
                return (isinstance(node, (tuple, list)) and len(node) >= 2 and
                        isinstance(node[0], str) and
                        not isinstance(node[1], (str, bytes, tuple, list, dict)))
            if outer and all(is_leaf(item) for item in outer):
                outer = [outer]
            for row in outer:
                parts = []
                collect(row, parts)
                if parts:
                    text = "".join(token for token, _confidence in parts)
                    # A weak character should lower the line more than a plain average,
                    # because one wrong digit changes the numeric reward dramatically.
                    mean = sum(conf for _token, conf in parts) / len(parts)
                    floor = min(conf for _token, conf in parts)
                    rows.append((text, max(0.0, min(1.0, mean * 0.72 + floor * 0.28))))
        except Exception:
            return []
        return rows

    def _pad_and_scale(self, image):
        rgb = image.convert("RGB")
        arr = self.np.asarray(rgb)
        if arr.size:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            fill = tuple(int(x) for x in self.np.median(edge, axis=0))
        else:
            fill = (255, 255, 255)
        border = max(4, min(24, int(round(min(rgb.width, rgb.height) * 0.15))))
        rgb = self.ImageOps.expand(rgb, border=border, fill=fill)
        # Tiny UI glyphs benefit from larger normalization than normal document OCR.
        target_h = 96 if rgb.height < 42 else (112 if rgb.height < 72 else
                   128 if rgb.height < 92 else rgb.height)
        scale = max(1.0, min(8.5, target_h / max(1, rgb.height)))
        if scale > 1.03:
            rgb = rgb.resize((max(12, int(round(rgb.width * scale))),
                              max(12, int(round(rgb.height * scale)))),
                             self.Image.Resampling.LANCZOS)
        return rgb

    def _variants(self, image, limit=None):
        """Yield OCR views in accuracy-first order, then spend extra budget on diversity."""
        rgb = self._pad_and_scale(image)
        hard_limit = self.max_variants if limit is None else max(1, min(self.max_variants, int(limit)))
        yielded = 0

        def emit(arr_or_img, weight, tag):
            nonlocal yielded
            if yielded >= hard_limit:
                return None
            yielded += 1
            if hasattr(arr_or_img, "convert"):
                arr = self.np.asarray(arr_or_img.convert("RGB"))
            else:
                arr = self.np.asarray(arr_or_img)
                if len(arr.shape) == 2:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_GRAY2RGB)
                elif arr.shape[2] == 4:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_RGBA2RGB)
            return arr, weight, tag

        arr = self.np.asarray(rgb)
        gray = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2GRAY)
        try:
            clahe = self.cv2.createCLAHE(clipLimit=2.8, tileGridSize=(4, 4)).apply(gray)
        except Exception:
            clahe = self.cv2.equalizeHist(gray)
        blur = self.cv2.GaussianBlur(clahe, (0, 0), 0.82)
        sharp = self.cv2.addWeighted(clahe, 2.10, blur, -1.10, 0)

        # The first four are intentionally the most generally useful. This matters on
        # slower machines where the adaptive budget may stop here.
        primary = [(rgb, 1.00, "rgb"), (clahe, 1.10, "clahe"), (sharp, 1.11, "sharp")]
        try:
            _t, otsu = self.cv2.threshold(sharp, 0, 255,
                                          self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            if float(otsu.mean()) < 127:
                otsu = 255 - otsu
            primary.append((otsu, 1.08, "otsu"))
        except Exception:
            otsu = None
        for data, weight, tag in primary:
            item = emit(data, weight, tag)
            if item:
                yield item
            if yielded >= hard_limit:
                return

        try:
            block = max(15, (min(gray.shape) // 4) | 1)
            block = min(71, block if block % 2 else block + 1)
            adaptive = self.cv2.adaptiveThreshold(
                clahe, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                self.cv2.THRESH_BINARY, block, 7)
            if float(adaptive.mean()) < 127:
                adaptive = 255 - adaptive
            item = emit(adaptive, 1.02, "adaptive")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        # ClearType and colored HUD glyphs can have little luminance contrast. Promote
        # the most informative color/chroma projection early instead of leaving it only
        # to the expensive tail of the ensemble.
        try:
            rgb_channels = list(self.cv2.split(arr))
            chroma = (arr.max(axis=2).astype("int16") -
                      arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            best_channel = max(rgb_channels + [chroma], key=lambda channel: float(channel.std()))
            if float(best_channel.std()) >= max(4.0, float(gray.std()) * 1.08):
                projected = self.cv2.normalize(best_channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(projected, 1.035, "chroma-best")
                if item:
                    yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        # Horizontal resampling is highly effective for condensed/expanded game fonts
        # and costs much less than loading another OCR model.
        try:
            for fx, weight, tag in ((1.20, 1.035, "wide"), (0.84, 1.015, "narrow")):
                warped = self.cv2.resize(sharp, None, fx=fx, fy=1.0,
                                         interpolation=self.cv2.INTER_CUBIC if fx > 1 else self.cv2.INTER_AREA)
                item = emit(warped, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        # Small geometric/font-rendering changes are common across GPUs, DPI scaling,
        # browser zoom and game engines. These cheap views make rec-only OCR much less
        # sensitive to condensed digits and ClearType/subpixel rendering.
        try:
            tall = self.cv2.resize(sharp, None, fx=1.0, fy=1.18,
                                   interpolation=self.cv2.INTER_CUBIC)
            item = emit(tall, 1.035, "tall")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            gamma = self.np.clip((sharp.astype("float32") / 255.0) ** 0.72 * 255.0,
                                 0, 255).astype("uint8")
            item = emit(gamma, 1.025, "gamma")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            inv = 255 - sharp
            item = emit(inv, 1.00, "invert")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        # Local-contrast normalization is especially effective for glossy HUDs and
        # gradients where global thresholding makes one side of a digit disappear.
        try:
            sigma = max(3.0, min(gray.shape) / 18.0)
            background = self.cv2.GaussianBlur(clahe, (0, 0), sigma)
            local = self.cv2.normalize(self.cv2.absdiff(clahe, background), None, 0, 255,
                                       self.cv2.NORM_MINMAX)
            item = emit(local, 1.015, "local")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        # Repair one-pixel gaps/broken anti-aliased strokes. Open/close are deliberately
        # small so decimal points and thin 1s survive.
        try:
            kx = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (2, 1))
            ky = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (1, 2))
            closed_x = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, kx)
            closed_y = self.cv2.morphologyEx(sharp, self.cv2.MORPH_CLOSE, ky)
            for data, weight, tag in ((closed_x, 1.01, "close-x"), (closed_y, 1.005, "close-y")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        # Morphology comes after canonical OCR views so low-end PCs never spend their
        # entire budget on specialized transforms.
        try:
            kh = max(3, min(15, ((min(gray.shape) // 8) | 1)))
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (kh, kh))
            top = self.cv2.morphologyEx(clahe, self.cv2.MORPH_TOPHAT, kernel)
            black = self.cv2.morphologyEx(clahe, self.cv2.MORPH_BLACKHAT, kernel)
            top = self.cv2.normalize(top, None, 0, 255, self.cv2.NORM_MINMAX)
            black = self.cv2.normalize(black, None, 0, 255, self.cv2.NORM_MINMAX)
            for data, weight, tag in ((top, 0.99, "tophat"), (black, 0.99, "blackhat")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        try:
            for gamma, weight, tag in ((0.58, 0.985, "gamma-light"),
                                       (1.72, 0.975, "gamma-dark")):
                lut = self.np.array([((i / 255.0) ** gamma) * 255 for i in range(256)], dtype="uint8")
                item = emit(self.cv2.LUT(clahe, lut), weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        # Color projection is a last-resort rescue for text whose luminance is close to
        # the background but whose hue/saturation differs strongly.
        try:
            channels = list(self.cv2.split(arr))
            lab = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2LAB)
            hsv = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2HSV)
            chroma = (arr.max(axis=2).astype("int16") - arr.min(axis=2).astype("int16")).clip(0, 255).astype("uint8")
            channels += [lab[:, :, 1], lab[:, :, 2], hsv[:, :, 1], chroma]
            ranked_channels = sorted(channels, key=lambda c: float(c.std()), reverse=True)[:2]
            for index, channel in enumerate(ranked_channels):
                channel = self.cv2.normalize(channel, None, 0, 255, self.cv2.NORM_MINMAX)
                item = emit(channel, 0.985 if index == 0 else 0.965, f"color{index + 1}")
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

    def _temporal_fusion(self, rect, count=3):
        """Align and median-combine frames to suppress animation, ClearType and 1px jitter."""
        frames = []
        size = None
        for index in range(max(2, int(count))):
            try:
                image = self.capture.grab(rect).convert("RGB")
                if size is None:
                    size = image.size
                elif image.size != size:
                    image = image.resize(size, self.Image.Resampling.BICUBIC)
                frames.append(self.np.asarray(image, dtype="uint8"))
            except Exception:
                continue
            if index + 1 < count:
                time.sleep(0.008)
        if len(frames) < 2:
            return None
        try:
            base = frames[0]
            base_gray = self.cv2.cvtColor(base, self.cv2.COLOR_RGB2GRAY).astype("float32")
            aligned = [base]
            h, w = base_gray.shape[:2]
            window = self.cv2.createHanningWindow((w, h), self.cv2.CV_32F) if w >= 8 and h >= 8 else None
            for frame in frames[1:]:
                gray = self.cv2.cvtColor(frame, self.cv2.COLOR_RGB2GRAY).astype("float32")
                try:
                    shift, response = self.cv2.phaseCorrelate(base_gray, gray, window)
                    dx, dy = float(shift[0]), float(shift[1])
                    if response >= 0.08 and abs(dx) <= 3.5 and abs(dy) <= 3.5:
                        matrix = self.np.float32([[1, 0, -dx], [0, 1, -dy]])
                        frame = self.cv2.warpAffine(frame, matrix, (w, h), flags=self.cv2.INTER_LINEAR,
                                                    borderMode=self.cv2.BORDER_REPLICATE)
                except Exception:
                    pass
                aligned.append(frame)
            stack = self.np.stack(aligned, axis=0)
            median = self.np.median(stack, axis=0)
            if len(aligned) >= 3:
                # Preserve thin decimal points/strokes that a pure median can erase.
                sharpest = max(aligned, key=lambda f: float(self.cv2.Laplacian(
                    self.cv2.cvtColor(f, self.cv2.COLOR_RGB2GRAY), self.cv2.CV_32F).var()))
                median = median * 0.82 + sharpest.astype("float32") * 0.18
            fused = self.np.clip(median, 0, 255).astype("uint8")
            return self.Image.fromarray(fused, mode="RGB")
        except Exception:
            return None

    def _content_crops(self, image):
        """Find tight text bands while retaining tiny decimal points and suffixes."""
        try:
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8")
            h, w = rgb.shape[:2]
            if h < 8 or w < 8:
                return []
            edge = self.np.concatenate((rgb[0], rgb[-1], rgb[:, 0], rgb[:, -1]), axis=0)
            background = self.np.median(edge.astype("float32"), axis=0)
            difference = self.np.max(self.np.abs(rgb.astype("float32") - background), axis=2)
            threshold = max(8.0, float(self.np.percentile(difference, 72)) * 0.66)
            masks = [(difference >= threshold).astype("uint8") * 255]

            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gradient = self.cv2.magnitude(
                self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3),
                self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3))
            grad_threshold = max(12.0, float(self.np.percentile(gradient, 78)) * 0.62)
            masks.append((gradient >= grad_threshold).astype("uint8") * 255)

            crops, seen = [], set()
            for mask in masks:
                kernel = self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (max(2, min(7, w // 45)), 2))
                mask = self.cv2.morphologyEx(mask, self.cv2.MORPH_CLOSE, kernel)
                contours, _hierarchy = self.cv2.findContours(
                    mask, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
                boxes = []
                for contour in contours:
                    x, y, bw, bh = self.cv2.boundingRect(contour)
                    if bw * bh < max(2, h * w * 0.00010):
                        continue
                    if bh < max(2, h * 0.055) and bw < max(2, w * 0.018):
                        continue
                    boxes.append((x, y, x + bw, y + bh))
                if not boxes:
                    continue
                x1 = min(box[0] for box in boxes)
                y1 = min(box[1] for box in boxes)
                x2 = max(box[2] for box in boxes)
                y2 = max(box[3] for box in boxes)
                px, py = max(2, int(h * 0.05)), max(2, int(h * 0.08))
                bounds = (max(0, x1 - px), max(0, y1 - py),
                          min(w, x2 + px), min(h, y2 + py))
                bw, bh = bounds[2] - bounds[0], bounds[3] - bounds[1]
                if bw < 5 or bh < 5 or (bw >= w * 0.97 and bh >= h * 0.97):
                    continue
                key = tuple(int(v // 2) for v in bounds)
                if key in seen:
                    continue
                seen.add(key)
                crops.append(image.crop(bounds))
            return crops[:2]
        except Exception:
            return []

    def _normalize_glyph(self, mask):
        """Normalize one connected glyph without destroying its aspect ratio."""
        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            points = self.cv2.findNonZero(binary)
            if points is None:
                return None
            x, y, w, h = self.cv2.boundingRect(points)
            if w < 1 or h < 2:
                return None
            crop = binary[y:y + h, x:x + w]
            target_w, target_h = 22, 30
            scale = min(target_w / max(1.0, float(w)),
                        target_h / max(1.0, float(h)))
            nw, nh = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
            interpolation = self.cv2.INTER_AREA if scale < 1.0 else self.cv2.INTER_CUBIC
            resized = self.cv2.resize(crop, (nw, nh), interpolation=interpolation)
            canvas = self.np.zeros((34, 26), dtype="uint8")
            ox, oy = (canvas.shape[1] - nw) // 2, (canvas.shape[0] - nh) // 2
            canvas[oy:oy + nh, ox:ox + nw] = resized
            return canvas.astype("float32") / 255.0
        except Exception:
            return None

    def _ensure_digit_templates(self):
        """Build a tiny offline digit bank for a neural-OCR-independent rescue path."""
        if self._digit_templates is not None:
            return self._digit_templates
        templates = {str(i): [] for i in range(10)}
        letter_templates = []
        fonts = tuple(dict.fromkeys((
            self.cv2.FONT_HERSHEY_SIMPLEX, self.cv2.FONT_HERSHEY_DUPLEX,
            self.cv2.FONT_HERSHEY_COMPLEX_SMALL, self.cv2.FONT_HERSHEY_TRIPLEX,
            self.cv2.FONT_HERSHEY_PLAIN,
        )))
        for font in fonts:
            for thickness in (1, 2, 3):
                for digit in templates:
                    canvas = self.np.zeros((76, 58), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(digit, font, scale, thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, digit, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
                for letter in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
                    canvas = self.np.zeros((76, 72), dtype="uint8")
                    scale = 2.05 if font != self.cv2.FONT_HERSHEY_PLAIN else 2.55
                    (tw, th), baseline = self.cv2.getTextSize(letter, font, scale,
                                                              thickness)
                    x = max(1, (canvas.shape[1] - tw) // 2)
                    y = max(th + 1, (canvas.shape[0] + th - baseline) // 2)
                    self.cv2.putText(canvas, letter, (x, y), font, scale, 255,
                                     thickness, self.cv2.LINE_AA)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        letter_templates.append(normalized)

        # Digital counters are common reward displays.  Seven-segment prototypes cover a
        # font family on which document OCR often confuses 1/7, 3/9 and 5/6.
        segment_map = {
            "0": "ab cdef".replace(" ", ""), "1": "bc", "2": "abdeg",
            "3": "abcdg", "4": "bcfg", "5": "acdfg", "6": "acdefg",
            "7": "abc", "8": "abcdefg", "9": "abcdfg",
        }
        for thickness in (4, 6, 8):
            for segment_width in (28, 36):
                left = (48 - segment_width) // 2
                right = left + segment_width
                for digit, active in segment_map.items():
                    canvas = self.np.zeros((78, 48), dtype="uint8")
                    t = thickness
                    segments = {
                        "a": (left, 5, right, 5 + t),
                        "b": (right - t, 8, right, 38),
                        "c": (right - t, 40, right, 70),
                        "d": (left, 70 - t, right, 70),
                        "e": (left, 40, left + t, 70),
                        "f": (left, 8, left + t, 38),
                        "g": (left, 37 - t // 2, right, 38 + (t + 1) // 2),
                    }
                    for name in active:
                        x1, y1, x2, y2 = segments[name]
                        self.cv2.rectangle(canvas, (x1, y1), (x2, y2), 255, -1)
                    normalized = self._normalize_glyph(canvas)
                    if normalized is not None:
                        templates[digit].append(normalized)
        self._digit_templates = templates
        self._letter_templates = letter_templates
        return templates

    def _classify_digit_glyph(self, mask):
        glyph = self._normalize_glyph(mask)
        if glyph is None or float(glyph.mean()) < 0.025:
            return None, 0.0
        per_digit = []

        def similarity(template):
            try:
                corr = float(self.cv2.matchTemplate(
                    glyph, template, self.cv2.TM_CCOEFF_NORMED)[0, 0])
            except Exception:
                corr = 0.0
            overlap = float(self.np.minimum(glyph, template).sum())
            union = float(self.np.maximum(glyph, template).sum())
            iou = overlap / max(1e-6, union)
            pixel_similarity = 1.0 - float(self.np.abs(glyph - template).mean())
            return (0.54 * max(0.0, (corr + 1.0) * 0.5) +
                    0.30 * iou + 0.16 * pixel_similarity)

        for digit, variants in self._ensure_digit_templates().items():
            best = 0.0
            for template in variants:
                best = max(best, similarity(template))
            per_digit.append((best, digit))
        per_digit.sort(reverse=True)
        if len(per_digit) < 2:
            return None, 0.0
        best, digit = per_digit[0]
        runner = per_digit[1][0]
        margin = best - runner
        letter_best = max((similarity(template)
                           for template in (self._letter_templates or ())), default=0.0)
        if letter_best > best + 0.012:
            return None, max(0.0, min(0.70, best))
        if letter_best > best - 0.018:
            margin -= (letter_best - best + 0.018) * 0.72
        confidence = max(0.0, min(0.94, 0.24 + best * 0.68 + margin * 1.55))
        if best < 0.52 or margin < 0.018 or confidence < 0.62:
            return None, confidence
        return digit, confidence

    def _classical_mask_token(self, mask):
        """Segment a thresholded numeric line and classify every glyph conservatively."""
        try:
            binary = (self.np.asarray(mask) > 0).astype("uint8") * 255
            h, w = binary.shape[:2]
            ratio = float((binary > 0).mean())
            if h < 8 or w < 5 or not 0.012 <= ratio <= 0.54:
                return None
            border_ratio = float(self.np.concatenate((
                binary[0], binary[-1], binary[:, 0], binary[:, -1])).mean()) / 255.0
            if border_ratio > 0.58:
                return None
            contours, _ = self.cv2.findContours(
                binary, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            min_area = max(2.0, h * w * 0.00016)
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = float(self.cv2.contourArea(contour))
                if area >= min_area and bw >= 1 and bh >= 1:
                    boxes.append((x, y, bw, bh, area))
            if not boxes:
                return None
            y0 = min(y for _x, y, _bw, _bh, _a in boxes)
            y1 = max(y + bh for _x, y, _bw, bh, _a in boxes)
            line_h = max(1, y1 - y0)
            punctuation = []
            digit_mask = binary.copy()
            for x, y, bw, bh, area in boxes:
                cy = y + bh * 0.5
                small = bh <= line_h * 0.42 and bw <= line_h * 0.34
                if small and cy >= y0 + line_h * 0.62:
                    mark = "," if bh >= max(3, bw * 1.35) else "."
                    punctuation.append((x + bw * 0.5, mark, 0.82))
                    digit_mask[y:y + bh, x:x + bw] = 0
                elif (bh <= line_h * 0.24 and bw >= max(2, bh * 1.8) and
                      y0 + line_h * 0.28 <= cy <= y0 + line_h * 0.72):
                    punctuation.append((x + bw * 0.5, "-", 0.78))
                    digit_mask[y:y + bh, x:x + bw] = 0

            # Bridge detached seven-segment strokes within a glyph.  The kernel remains
            # smaller than a normal inter-character gap, so adjacent digits stay separate.
            kx = max(1, int(round(line_h * 0.025)))
            ky = max(1, int(round(line_h * 0.025)))
            grouped = self.cv2.dilate(
                digit_mask, self.cv2.getStructuringElement(
                    self.cv2.MORPH_RECT, (kx * 2 + 1, ky * 2 + 1)), iterations=1)
            groups, _ = self.cv2.findContours(
                grouped, self.cv2.RETR_EXTERNAL, self.cv2.CHAIN_APPROX_SIMPLE)
            glyphs = []
            for contour in groups:
                gx, gy, gw, gh = self.cv2.boundingRect(contour)
                if gh < line_h * 0.36 or gw < max(2, line_h * 0.055):
                    continue
                if gw > line_h * 1.18:
                    return None
                left = max(0, gx + kx - 2)
                top = max(0, gy + ky - 2)
                right = min(w, gx + gw - kx + 2)
                bottom = min(h, gy + gh - ky + 2)
                if right - left < 1 or bottom - top < 2:
                    continue
                digit, confidence = self._classify_digit_glyph(
                    digit_mask[top:bottom, left:right])
                if digit is None:
                    return None
                glyphs.append(((left + right) * 0.5, digit, confidence))
            if not glyphs or len(glyphs) > 18:
                return None
            tokens = sorted(glyphs + punctuation, key=lambda item: item[0])
            text = "".join(item[1] for item in tokens)
            if text.count("-") > 1 or ("-" in text and not text.startswith("-")):
                return None
            if text.count(".") + text.count(",") > 2 or not any(
                    ch.isdigit() for ch in text):
                return None
            if not parse_score_candidates(text):
                return None
            confidences = [item[2] for item in glyphs]
            confidence = min(confidences) * 0.56 + sum(confidences) / len(confidences) * 0.44
            return text, max(0.0, min(0.92, confidence))
        except Exception:
            return None

    def _classical_numeric_candidates(self, image):
        """Return consensus from several classical digit views when neural OCR is unsure."""
        try:
            rgb = self.np.asarray(self._pad_and_scale(image), dtype="uint8")
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
            gray = self.cv2.GaussianBlur(gray, (3, 3), 0.35)
            masks = []
            threshold_value, otsu = self.cv2.threshold(
                gray, 0, 255, self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            masks.extend((otsu, 255 - otsu))
            threshold_step = max(6.0, float(gray.std()) * 0.16)
            for fixed_value in (threshold_value - threshold_step,
                                threshold_value + threshold_step):
                _fixed_threshold, fixed = self.cv2.threshold(
                    gray, max(1.0, min(254.0, fixed_value)), 255,
                    self.cv2.THRESH_BINARY)
                masks.extend((fixed, 255 - fixed))
            if min(gray.shape[:2]) >= 17:
                block = max(15, min(61, (min(gray.shape[:2]) // 3) | 1))
                adaptive = self.cv2.adaptiveThreshold(
                    gray, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                    self.cv2.THRESH_BINARY, block, 5)
                masks.extend((adaptive, 255 - adaptive))
            votes = {}
            for mask in masks:
                recognized = self._classical_mask_token(mask)
                if recognized is None:
                    continue
                token, confidence = recognized
                votes.setdefault(token, []).append(confidence)
            candidates = []
            for token, confidences in votes.items():
                support = len(confidences)
                digits = sum(ch.isdigit() for ch in token)
                required = 3 if digits == 1 else 2
                mean_conf = sum(confidences) / support
                # Letter-only labels such as SCORE can resemble 80086 in generic fonts.
                # A rescue path is allowed to abstain: require a much stronger glyph-bank
                # match than the neural ensemble requires from an independent model.
                if support < required or mean_conf < (0.84 if digits == 1 else 0.81):
                    continue
                confidence = min(0.91, mean_conf + min(0.08, 0.025 * (support - 1)))
                source_weight = min(0.94, 0.74 + 0.045 * support)
                for value, parse_weight, _parsed_token in parse_score_candidates(token):
                    candidates.append((value, confidence, token,
                                       source_weight * parse_weight,
                                       "classical:digit-templates"))
            return candidates
        except Exception:
            return []

    @staticmethod
    def _tag_variants(variants, prefix):
        return [(array, weight, f"{prefix}-{tag}") for array, weight, tag in variants]

    @staticmethod
    def _same_value(a, b):
        return abs(a - b) <= max(1e-9, max(abs(a), abs(b), 1.0) * 1e-10)

    @staticmethod
    def _text_quality(text):
        norm = normalize_digits(text).strip()
        if not norm:
            return 0.60
        allowed_suffix = re.compile(
            r"(?:Qa|Qi|Sx|Sp|Oc|No|Dc|Ki|Mi|Gi|Ti|mn|bn|tn|tr|万亿|"
            r"[kKmMbBtTqQ]|百|千|万|亿|兆|京|垓|秭|穰|沟|涧|正|载|%)$",
            re.IGNORECASE)
        core = allowed_suffix.sub("", norm).strip()
        useful = sum(ch.isdigit() or ch in "+-., eE" for ch in core)
        noise = sum(ch.isalpha() for ch in core)
        ratio = useful / max(1, len(core))
        punctuation = sum(ch in "+-.,eE" for ch in core)
        punct_penalty = max(0, punctuation - 4) * 0.035
        return max(0.55, min(1.10, 0.80 + 0.34 * ratio - 0.075 * noise - punct_penalty))

    @staticmethod
    def _token_signature(text):
        text = normalize_digits(text)
        text = re.sub(r"\s+", "", text)
        allowed = set("0123456789+-.,eEkKmMbBtTqQinrG%百千万亿兆京垓秭穰沟涧正载QaQiSxSpOcNoDcKiMiGiTi")
        return "".join(ch for ch in text if ch in allowed)[:48]

    @staticmethod
    def _edit_similarity(a, b):
        if not a or not b:
            return 0.0
        if a == b:
            return 1.0
        if abs(len(a) - len(b)) > max(3, int(max(len(a), len(b)) * 0.45)):
            return 0.0
        previous = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            current = [i]
            for j, cb in enumerate(b, 1):
                current.append(min(current[-1] + 1, previous[j] + 1,
                                   previous[j - 1] + (0 if ca == cb else 1)))
            previous = current
        distance = previous[-1]
        return max(0.0, 1.0 - distance / max(len(a), len(b), 1))

    def _source_multiplier(self, source):
        stat = self.source_skill.get(source, {})
        hit = float(stat.get("hit", 0.0))
        miss = float(stat.get("miss", 0.0))
        total = hit + miss
        if total < 1.5:
            return 1.0
        mean = (hit + 1.6) / (total + 3.2)
        confidence = min(1.0, total / 18.0)
        return max(0.72, min(1.30, 1.0 + (mean - 0.5) * 0.60 * confidence))

    def _learn_sources(self, candidates, chosen, confidence):
        if chosen is None or confidence < 0.58:
            return
        trust = max(0.10, min(1.0, (float(confidence) - 0.50) / 0.42))
        by_source = {}
        for value, _conf, _text, _weight, source in candidates:
            by_source.setdefault(source, []).append(value)
        for source, values in by_source.items():
            stat = self.source_skill.setdefault(source, {"hit": 0.0, "miss": 0.0})
            hit = any(self._same_value(value, chosen) for value in values)
            stat["hit" if hit else "miss"] = float(stat.get("hit" if hit else "miss", 0.0)) + trust
            total = float(stat.get("hit", 0.0)) + float(stat.get("miss", 0.0))
            if total > 80.0:
                stat["hit"] *= 0.72
                stat["miss"] *= 0.72
        if len(self.source_skill) > 140:
            ranked = sorted(self.source_skill.items(),
                            key=lambda kv: float(kv[1].get("hit", 0.0)) + float(kv[1].get("miss", 0.0)),
                            reverse=True)[:140]
            self.source_skill = dict(ranked)

    @staticmethod
    def _align_tokens(anchor, token):
        """Needleman-Wunsch alignment tolerant of OCR insertions and dropped glyphs."""
        rows, cols = len(anchor) + 1, len(token) + 1
        gap = 0.78
        costs = [[0.0] * cols for _ in range(rows)]
        moves = [[None] * cols for _ in range(rows)]
        for i in range(1, rows):
            costs[i][0], moves[i][0] = i * gap, "up"
        for j in range(1, cols):
            costs[0][j], moves[0][j] = j * gap, "left"
        for i in range(1, rows):
            for j in range(1, cols):
                substitute = costs[i - 1][j - 1] + (0.0 if anchor[i - 1] == token[j - 1] else 1.0)
                delete = costs[i - 1][j] + gap
                insert = costs[i][j - 1] + gap
                best = min((substitute, 0, "diag"), (delete, 1, "up"),
                           (insert, 2, "left"))
                costs[i][j], moves[i][j] = best[0], best[2]
        aligned = []
        i, j = len(anchor), len(token)
        while i or j:
            move = moves[i][j]
            if move == "diag":
                aligned.append((anchor[i - 1], token[j - 1]))
                i, j = i - 1, j - 1
            elif move == "up":
                aligned.append((anchor[i - 1], None))
                i -= 1
            else:
                aligned.append((None, token[j - 1]))
                j -= 1
        aligned.reverse()
        return aligned

    def _aligned_consensus_tokens(self, candidates):
        """Build a small character lattice across reads of unequal length."""
        unique = {}
        for _value, conf, text, weight, source in candidates:
            signature = self._token_signature(text)
            if len(signature) < 2 or conf < 0.28:
                continue
            score = (max(0.02, float(weight)) * (0.18 + float(conf) ** 2) *
                     self._source_multiplier(source))
            key = (signature, source)
            if score > unique.get(key, (0.0, ""))[0]:
                unique[key] = (score, source)
        items = [(signature, score, source)
                 for (signature, _source), (score, source) in unique.items()]
        items.sort(key=lambda item: item[1], reverse=True)
        items = items[:64]
        if len(items) < 3:
            return []

        best_cluster = []
        best_cluster_score = 0.0
        for anchor, anchor_score, _source in items[:24]:
            members = []
            cluster_score = 0.0
            for signature, score, source in items:
                if abs(len(signature) - len(anchor)) > 2:
                    continue
                similarity = self._edit_similarity(anchor, signature)
                if similarity < 0.52:
                    continue
                members.append((signature, score, source))
                cluster_score += score * (0.55 + 0.45 * similarity)
            diversity = len({source for _signature, _score, source in members})
            if len(members) >= 3 and diversity >= 2 and cluster_score > best_cluster_score:
                best_cluster, best_cluster_score = members, cluster_score
        if not best_cluster:
            return []

        anchor = max(
            best_cluster,
            key=lambda item: sum(other_score * self._edit_similarity(item[0], other)
                                 for other, other_score, _source in best_cluster),
        )[0]
        char_votes = [dict() for _ in anchor]
        insert_votes = [dict() for _ in range(len(anchor) + 1)]
        total_weight = sum(score for _signature, score, _source in best_cluster)
        for signature, score, _source in best_cluster:
            chars = [""] * len(anchor)
            inserts = [""] * (len(anchor) + 1)
            cursor = 0
            for left, right in self._align_tokens(anchor, signature):
                if left is None:
                    if right:
                        inserts[cursor] += right
                else:
                    chars[cursor] = right or ""
                    cursor += 1
            for index, value in enumerate(chars):
                char_votes[index][value] = char_votes[index].get(value, 0.0) + score
            for index, value in enumerate(inserts):
                insert_votes[index][value] = insert_votes[index].get(value, 0.0) + score

        slots = []
        top_agreements = []
        for index in range(len(anchor) + 1):
            insertion = sorted(insert_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            if insertion:
                insertion_options = []
                for rank, (value, vote) in enumerate(insertion[:2]):
                    probability = vote / max(1e-9, total_weight)
                    threshold = 0.0 if rank == 0 else (0.34 if value else 0.22)
                    if probability >= threshold:
                        insertion_options.append((value, probability))
                if insertion_options:
                    # Do not invent an insertion unless at least half the evidence saw it.
                    if insertion_options[0][0] and insertion_options[0][1] < 0.50:
                        insertion_options.insert(0, ("", 1.0 - insertion_options[0][1]))
                    slots.append(insertion_options[:2])
                    top_agreements.append(insertion_options[0][1])
            if index == len(anchor):
                break
            choices = sorted(char_votes[index].items(), key=lambda kv: kv[1], reverse=True)
            options = []
            for rank, (value, vote) in enumerate(choices[:2]):
                probability = vote / max(1e-9, total_weight)
                if rank == 0 or probability >= 0.20:
                    options.append((value, probability))
            if options:
                slots.append(options)
                top_agreements.append(options[0][1])

        if not slots:
            return []
        agreement = sum(top_agreements) / len(top_agreements)
        if agreement < 0.57:
            return []
        beams = [("", 0.0)]
        for options in slots:
            expanded = []
            for prefix, log_score in beams:
                for value, probability in options:
                    expanded.append((prefix + value,
                                     log_score + math.log(max(1e-6, probability))))
            expanded.sort(key=lambda item: item[1], reverse=True)
            beams = expanded[:6]
        source_count = len({source for _signature, _score, source in best_cluster})
        results, seen = [], set()
        for token, log_score in beams:
            if token in seen or not any(ch.isdigit() for ch in token):
                continue
            seen.add(token)
            beam_agreement = math.exp(log_score / max(1, len(slots)))
            combined = max(0.0, min(1.0, agreement * 0.62 + beam_agreement * 0.38))
            results.append((token, combined, source_count))
        return results

    def _with_character_consensus(self, candidates):
        """Synthesize aligned character-level hypotheses before numeric parsing."""
        work = list(candidates)
        for token, agreement, source_count in self._aligned_consensus_tokens(candidates):
            conf = min(0.982, 0.40 + agreement * 0.53 + min(0.04, source_count * 0.006))
            weight = min(1.13, 0.70 + agreement * 0.40)
            for value, parse_weight, _token in parse_score_candidates(token):
                work.append((value, conf, token, weight * parse_weight,
                             f"consensus:aligned:{source_count}"))
        return work

    def _pick(self, candidates, expected=None):
        if not candidates:
            return None, 0.0, ""
        candidates = self._with_character_consensus(candidates)
        groups = []
        for value, conf, text, weight, source in candidates:
            group = next((g for g in groups if self._same_value(g[0], value)), None)
            evidence = (weight * self._source_multiplier(source) * self._text_quality(text) *
                        (0.16 + conf * conf))
            if group is None:
                groups.append([value, {source: evidence}, conf, text, 1])
            else:
                old = float(group[1].get(source, 0.0))
                if old:
                    group[1][source] = max(old, evidence) + min(old, evidence) * 0.18
                else:
                    group[1][source] = evidence
                if conf > group[2]:
                    group[2], group[3] = conf, text
                group[4] += 1

        scored = []
        for value, source_scores, conf, text, observations in groups:
            evidence = sum(source_scores.values())
            support = len(source_scores)
            evidence += min(0.86, 0.205 * (support - 1))
            evidence += min(0.12, 0.018 * max(0, observations - support))

            # OCR engines often disagree by one dropped/merged glyph. A weak medoid-style
            # bonus lets the candidate whose token is closest to several independent reads
            # win, without forcing numerically different hypotheses to be treated as equal.
            signature = self._token_signature(text)
            if signature and len(groups) > 1:
                near = 0.0
                for other_value, _other_sources, other_conf, other_text, _obs in groups:
                    if self._same_value(value, other_value):
                        continue
                    other_sig = self._token_signature(other_text)
                    similarity = self._edit_similarity(signature, other_sig)
                    if similarity < 0.78:
                        continue
                    lo = max(1e-12, min(abs(value), abs(other_value)))
                    hi = max(abs(value), abs(other_value), 1e-12)
                    if hi / lo <= 20.0 or len(signature) == len(other_sig):
                        near += (similarity - 0.76) * (0.16 + 0.20 * other_conf)
                evidence += min(0.13, max(0.0, near))

            temporal = sum(c for v, c in self.recent[-6:] if self._same_value(v, value))
            if temporal:
                evidence += min(0.17, temporal * 0.034)

            if expected is not None and not self._same_value(value, expected):
                scale = max(abs(expected), 1.0)
                jump = abs(value - expected) / scale
                if jump > 100000 and support == 1 and conf < 0.90:
                    evidence -= 0.22
                elif jump > 1000 and support == 1 and conf < 0.76:
                    evidence -= 0.10
            elif expected is not None:
                evidence += 0.075

            if self.last_value is not None and self.last_confidence >= 0.68:
                if self._same_value(value, self.last_value):
                    evidence += 0.035
                elif support == 1 and conf < 0.60:
                    scale = max(abs(self.last_value), 1.0)
                    if abs(value - self.last_value) > scale * 100000:
                        evidence -= 0.08
            scored.append([value, evidence, conf, text, support, observations])

        scored.sort(key=lambda g: (g[1], g[2], g[4], g[5]), reverse=True)
        if expected is not None and len(scored) > 1:
            for index, group in enumerate(scored[1:], start=1):
                if (self._same_value(group[0], expected) and
                        group[1] >= scored[0][1] * 0.94 and
                        (group[4] >= 2 or
                         (scored[0][4] == 1 and scored[0][2] < 0.72))):
                    scored.insert(0, scored.pop(index))
                    break
        best = scored[0]
        runner = scored[1][1] if len(scored) > 1 else 0.0
        margin = best[1] - runner
        margin_bonus = min(0.13, max(0.0, margin) * 0.047) if best[4] >= 2 else 0.0
        source_bonus = min(0.12, 0.045 * (best[4] - 1))
        confidence = min(0.997, best[2] + 0.050 * (best[4] - 1) + margin_bonus + source_bonus)
        if runner > 0 and best[1] > 0:
            competition = runner / best[1]
            if competition > 0.50:
                confidence -= min(0.24, (competition - 0.50) * 0.48)
        confidence = max(0.08, min(0.997, confidence))
        return best[0], confidence, best[3]

    @staticmethod
    def _expanded_rect(rect, ratio=0.06, px=3):
        x1, y1, x2, y2 = map(float, rect)
        w, h = max(1.0, x2 - x1), max(1.0, y2 - y1)
        dx, dy = max(px, w * ratio), max(px, h * ratio)
        return (x1 - dx, y1 - dy, x2 + dx, y2 + dy)

    @staticmethod
    def _shifted_rect(rect, dx=0, dy=0):
        x1, y1, x2, y2 = map(float, rect)
        return (x1 + dx, y1 + dy, x2 + dx, y2 + dy)

    def _run_engine(self, engine_name, engine, variants, candidates, model_weight=1.0,
                    det=False, limit=None, expected=None):
        use = variants if limit is None else variants[:limit]
        for index, (arr, weight, tag) in enumerate(use):
            try:
                kwargs = {"use_det": bool(det), "use_cls": False, "use_rec": True}
                if not det and index < self.character_detail_variants:
                    kwargs.update(return_word_box=True, return_single_char_box=True)
                try:
                    result = engine(arr, **kwargs)
                except (TypeError, ValueError):
                    kwargs.pop("return_word_box", None)
                    kwargs.pop("return_single_char_box", None)
                    result = engine(arr, **kwargs)
                lines = self._extract_lines(result)
                character_lines = self._extract_character_lines(result)
                character_confidence = {
                    self._token_signature(text): conf for text, conf in character_lines
                    if self._token_signature(text)
                }
                for text, conf in lines:
                    signature = self._token_signature(text)
                    if signature in character_confidence:
                        conf = min(conf, conf * 0.42 + character_confidence[signature] * 0.58)
                    parsed = parse_score_candidates(text)
                    for value, parse_weight, _token in parsed:
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * (0.93 if det else 1.0),
                                           f"{engine_name}:{tag}:{'det' if det else 'rec'}"))
                for text, conf in character_lines:
                    if any(text == existing for existing, _confidence in lines):
                        continue
                    for value, parse_weight, _token in parse_score_candidates(text):
                        candidates.append((value, conf, text,
                                           weight * model_weight * parse_weight * 1.035,
                                           f"{engine_name}:{tag}:chars"))
                # Detection can split a single counter into several boxes. Re-join in
                # reading order as an additional hypothesis instead of discarding pieces.
                if len(lines) > 1:
                    joined = "".join(t for t, _c in lines)
                    conf = sum(c for _t, c in lines) / len(lines)
                    for value, parse_weight, _token in parse_score_candidates(joined):
                        candidates.append((value, conf, joined,
                                           weight * model_weight * 0.82 * parse_weight,
                                           f"{engine_name}:{tag}:joined"))
                if not det and index >= 1:
                    tentative = self._pick(candidates, expected)
                    support = sum(1 for v, _c, _t, _w, _s in candidates
                                  if tentative[0] is not None and self._same_value(v, tentative[0]))
                    if support >= 3 and tentative[1] >= 0.95:
                        break
            except Exception:
                continue

    def _dynamic_budget(self):
        budget = int(self.active_variants)
        target = self.latency_target
        if self.latency > target * 2.4:
            budget -= 3
        elif self.latency > target * 1.55:
            budget -= 2
        elif self.latency > target * 1.18:
            budget -= 1
        elif self.latency < target * 0.62 and self.confidence_ema < 0.90:
            budget += 1
        if self.fail_streak:
            budget += min(3, self.fail_streak)
        if self.confidence_ema < 0.68:
            budget += 1
        if self.hardware is not None:
            avail = _available_memory()
            if avail < max(1024 ** 3, self.hardware.ram * 0.10):
                budget = min(budget, self.min_variants)
            elif getattr(self.hardware, "cpu_load_ema", 0.0) > 0.90:
                budget = max(self.min_variants, budget - 2)
        return max(self.min_variants, min(self.max_variants, budget))

    def _retune(self, success, confidence):
        self.confidence_ema = self.confidence_ema * 0.86 + float(confidence) * 0.14
        if success:
            self.fail_streak = 0
        else:
            self.fail_streak = min(5, self.fail_streak + 1)
        target = self.latency_target
        if self.latency > target * 1.45 and self.active_variants > self.min_variants:
            self.active_variants -= 1
        elif (self.latency < target * 0.72 and self.confidence_ema < 0.88 and
              self.active_variants < self.max_variants):
            self.active_variants += 1
        elif self.fail_streak >= 2 and self.active_variants < self.max_variants:
            self.active_variants += 1

    def read(self, rect, expected=None):
        started = time.perf_counter()
        best = (None, 0.0, "")
        try:
            image = self.capture.grab(rect)
            if image.width < 4 or image.height < 4:
                self._retune(False, 0.0)
                return best
            budget = self._dynamic_budget()
            variants = list(self._variants(image, budget))
            candidates = []
            if not self.engines:
                self._retune(False, 0.0)
                return best
            primary_name, primary_engine, primary_weight = self.engines[0]
            self._run_engine(primary_name, primary_engine, variants, candidates,
                             primary_weight, det=False, expected=expected)
            best = self._pick(candidates, expected)

            # A small classical digit bank is deliberately independent of the neural
            # model.  Requiring agreement across threshold views makes it a useful rescue
            # for tiny HUD digits and seven-segment displays without letting one noisy
            # contour override confident OCR.
            if best[0] is None or best[1] < 0.84:
                candidates.extend(self._classical_numeric_candidates(image))
                best = self._pick(candidates, expected)

            # Progressive crop expansion handles selections that clip a leading sign,
            # suffix, decimal point, or anti-aliased edge. Wider passes are uncertainty-only.
            if best[0] is None or best[1] < 0.88:
                for ratio, weight in ((0.055, 0.96), (0.12, 0.90)):
                    try:
                        expanded = self.capture.grab(self._expanded_rect(rect, ratio=ratio,
                                                                         px=4 if ratio < 0.1 else 7))
                        more = self._tag_variants(
                            list(self._variants(expanded, max(2, min(budget, 5)))),
                            f"expand{int(ratio * 1000)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * weight, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.93:
                            break
                    except Exception:
                        continue

            # Projection/edge-based tight crops remove labels, glow and oversized
            # selection margins more precisely than fixed-percentage trimming.
            if best[0] is None or best[1] < 0.89:
                for crop_index, tight in enumerate(self._content_crops(image), start=1):
                    try:
                        more = self._tag_variants(
                            list(self._variants(tight, max(2, min(budget, 5)))),
                            f"tight{crop_index}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.94:
                            break
                    except Exception:
                        continue

            # If the user included a little border/glow/label around the number, search a
            # few conservative inner crops. This is especially effective on stylized game HUDs.
            if best[0] is None or best[1] < 0.86:
                iw, ih = image.size
                trims = ((0.02, 0.04), (0.05, 0.02), (0.07, 0.07))
                for tx, ty in trims:
                    try:
                        xpad, ypad = int(iw * tx), int(ih * ty)
                        if iw - 2 * xpad < 6 or ih - 2 * ypad < 6:
                            continue
                        inner = image.crop((xpad, ypad, iw - xpad, ih - ypad))
                        more = self._tag_variants(
                            list(self._variants(inner, max(2, min(budget, 4)))),
                            f"trim{int(tx * 100)}x{int(ty * 100)}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.97, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.92:
                            break
                    except Exception:
                        continue

            # One or two clipped edge pixels can turn 8 into 3 or erase a decimal point.
            # Probe tiny crop shifts only when confidence is poor.
            if (best[0] is None or best[1] < 0.76) and budget >= 4:
                for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
                    try:
                        shifted = self.capture.grab(self._shifted_rect(rect, dx, dy))
                        more = self._tag_variants(
                            list(self._variants(shifted, 2 if budget < 7 else 3)),
                            f"shift{dx:+d}{dy:+d}")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 0.985, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.90:
                            break
                    except Exception:
                        continue

            # Animated counters, bloom and ClearType can make every single frame slightly
            # different. A temporal median creates a cleaner glyph image only when needed.
            if best[0] is None or best[1] < 0.82:
                try:
                    fused = self._temporal_fusion(rect, 3 if budget >= 4 else 2)
                    if fused is not None:
                        more = self._tag_variants(
                            list(self._variants(fused, max(2, min(budget, 5)))), "temporal")
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * 1.015, det=False, expected=expected)
                        if best[0] is None or best[1] < 0.72:
                            candidates.extend(self._classical_numeric_candidates(fused))
                        best = self._pick(candidates, expected)
                except Exception:
                    pass

            ensemble_allowed = True
            if self.hardware is not None:
                ensemble_allowed = (_available_memory() >=
                                    max(1400 * 1024 ** 2, self.hardware.ram * 0.105) and
                                    getattr(self.hardware, "cpu_load_ema", 0.0) < 0.93)
            if (ensemble_allowed and len(self.engines) > 1 and
                    (best[0] is None or best[1] < 0.92)):
                for engine_name, engine, model_weight in self.engines[1:]:
                    self._run_engine(engine_name, engine, variants, candidates,
                                     model_weight, det=False, limit=max(2, min(5, budget)),
                                     expected=expected)
                    best = self._pick(candidates, expected)
                    if best[0] is not None and best[1] >= 0.94:
                        break

            if best[0] is None or best[1] < 0.64:
                self._run_engine(primary_name, primary_engine, variants, candidates,
                                 primary_weight, det=True, limit=max(1, min(3, budget)),
                                 expected=expected)
                best = self._pick(candidates, expected)

            if best[0] is not None and best[1] >= 0.44:
                self._learn_sources(candidates, best[0], best[1])
                self.last_value, self.last_confidence, self.last_text = best
                self.recent.append((best[0], best[1]))
                if len(self.recent) > 8:
                    self.recent = self.recent[-8:]
                self._retune(True, best[1])
            else:
                self._retune(False, best[1])
            return best
        finally:
            elapsed = max(0.001, time.perf_counter() - started)
            self.latency = self.latency * 0.82 + elapsed * 0.18

class EscapeHook:
    def __init__(self, stop_event):
        self.stop_event = stop_event
        self.ready = threading.Event()
        self.hooked = False
        self.thread_id = 0
        self.thread = None
        self.hook = None
        self.callback = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.ready.wait(2)
        return self.hooked

    def _run(self):
        self.thread_id = kernel32.GetCurrentThreadId()
        proc_type = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM)

        def low_level_proc(code, message, data):
            if code >= 0:
                info = ctypes.cast(data, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if info.vkCode == VK_ESCAPE and message in (
                        WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP):
                    self.stop_event.set()
                    return 1
            return user32.CallNextHookEx(self.hook, code, message, data)

        self.callback = proc_type(low_level_proc)
        self.hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL,
                                             ctypes.cast(self.callback, ctypes.c_void_p),
                                             kernel32.GetModuleHandleW(None), 0)
        self.hooked = bool(self.hook)
        self.ready.set()
        if not self.hook:
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def close(self):
        deadline = time.monotonic() + 1.5
        while user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000 and time.monotonic() < deadline:
            time.sleep(0.03)
        if self.thread_id:
            user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)


KEY_ACTIONS = {
    "key:UP": 0x26, "key:DOWN": 0x28, "key:LEFT": 0x25, "key:RIGHT": 0x27,
    "key:W": 0x57, "key:A": 0x41, "key:S": 0x53, "key:D": 0x44,
    "key:SPACE": 0x20, "key:E": 0x45, "key:F": 0x46,
    "key:Q": 0x51, "key:R": 0x52, "key:T": 0x54, "key:Y": 0x59,
    "key:Z": 0x5A, "key:X": 0x58, "key:C": 0x43, "key:V": 0x56,
    "key:ENTER": 0x0D, "key:TAB": 0x09,
}
KEY_NAME_TO_VK = {name.split(":", 1)[1]: vk for name, vk in KEY_ACTIONS.items()}

CORE_KEY_ACTIONS = (
    "key:UP", "key:DOWN", "key:LEFT", "key:RIGHT",
    "key:W", "key:A", "key:S", "key:D", "key:SPACE", "key:E", "key:F",
)
SECONDARY_KEY_ACTIONS = ("key:Q", "key:R", "key:T", "key:Y", "key:Z", "key:X", "key:C", "key:V")
HOLD_KEY_ACTIONS = tuple(
    f"hold:{name}:{milliseconds}"
    for milliseconds in (260, 520)
    for name in ("UP", "DOWN", "LEFT", "RIGHT", "W", "A", "S", "D")
)
CHORD_KEY_ACTIONS = tuple(
    f"chord:{left}+{right}"
    for left, right in (
        ("W", "A"), ("W", "D"), ("S", "A"), ("S", "D"),
        ("UP", "LEFT"), ("UP", "RIGHT"), ("DOWN", "LEFT"), ("DOWN", "RIGHT"),
        ("W", "SPACE"), ("A", "SPACE"), ("D", "SPACE"),
        ("UP", "SPACE"), ("LEFT", "SPACE"), ("RIGHT", "SPACE"),
    )
)
OBSERVE_ACTION = "wait:observe"
KEY_ACTION_PRIORS = {action: 0.61 for action in CORE_KEY_ACTIONS}
KEY_ACTION_PRIORS.update({action: 0.48 for action in SECONDARY_KEY_ACTIONS})
KEY_ACTION_PRIORS.update({action: 0.37 for action in HOLD_KEY_ACTIONS})
KEY_ACTION_PRIORS.update({action: 0.31 for action in CHORD_KEY_ACTIONS})
KEY_ACTION_PRIORS.update({"key:ENTER": 0.34, "key:TAB": 0.32, OBSERVE_ACTION: 0.26})


def _send_key_event(vk, up=False):
    if vk == VK_ESCAPE:
        return False
    # Scan-code SendInput works with more DirectInput/game/browser surfaces than the
    # legacy keybd_event path. The legacy API remains a fallback for unusual drivers.
    extended = vk in {0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E}
    scan = int(user32.MapVirtualKeyW(vk, MAPVK_VK_TO_VSC))
    try:
        flags = KEYEVENTF_SCANCODE | (KEYEVENTF_EXTENDEDKEY if extended else 0)
        if up:
            flags |= KEYEVENTF_KEYUP
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.union.ki = KEYBDINPUT(0, scan, flags, 0, 0)
        if scan:
            if int(user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))) == 1:
                return True
    except Exception:
        pass
    try:
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP if up else 0, 0)
        return True
    except Exception:
        return False


def press_keys(vks, duration=0.075, stop_event=None):
    """Press one or more non-ESC keys and guarantee release on every exit path."""
    keys = []
    for vk in vks:
        vk = int(vk)
        if vk != VK_ESCAPE and vk not in keys:
            keys.append(vk)
    down = []
    try:
        for vk in keys:
            if _send_key_event(vk, False):
                down.append(vk)
        end = time.monotonic() + max(0.018, min(1.25, float(duration)))
        while time.monotonic() < end:
            if stop_event is not None and stop_event.is_set():
                break
            time.sleep(min(0.018, max(0.001, end - time.monotonic())))
    finally:
        for vk in reversed(down):
            _send_key_event(vk, True)


def tap_key(vk, duration=0.075):
    press_keys((vk,), duration)


def click_point(x, y):
    old = POINT()
    user32.GetCursorPos(ctypes.byref(old))
    user32.SetCursorPos(int(x), int(y))
    user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    try:
        time.sleep(0.055)
    finally:
        user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(0.025)
    user32.SetCursorPos(old.x, old.y)


class Learner:
    """Contextual reinforcement learner with transfer, sequence planning and uncertainty."""
    INVERSES = {
        "key:UP": "key:DOWN", "key:DOWN": "key:UP",
        "key:LEFT": "key:RIGHT", "key:RIGHT": "key:LEFT",
        "key:W": "key:S", "key:S": "key:W", "key:A": "key:D", "key:D": "key:A",
        "key:Q": "key:E", "key:E": "key:Q",
    }

    def __init__(self, state_file):
        self.state_file = state_file
        self.stats = {}
        self.contexts = {}
        self.families = {}
        self.pairs = {}
        self.triples = {}
        self.sequences = {}
        self.sequence_contexts = {}
        self.aliases = {}
        self.models = {}
        self.steps = 0
        self.best = None
        self.last_action = None
        self.prev_action = None
        self.last_reward = 0.0
        self.positive = 0
        self.history = []
        self.atomic_trace = []
        self.recent = {}
        self.action_trace = []
        self.delays = {}
        self.passive = {}
        self.passive_families = {}
        try:
            data = json.loads(state_file.read_text(encoding="utf-8"))
            self.stats = data.get("stats", {})
            self.contexts = data.get("contexts", {})
            self.families = data.get("families", {})
            self.pairs = data.get("pairs", {})
            self.triples = data.get("triples", {})
            self.sequences = data.get("sequences", {}) if isinstance(data.get("sequences", {}), dict) else {}
            self.sequence_contexts = data.get("sequence_contexts", {}) if isinstance(data.get("sequence_contexts", {}), dict) else {}
            self.aliases = data.get("aliases", {}) if isinstance(data.get("aliases", {}), dict) else {}
            self.models = data.get("models", {}) if isinstance(data.get("models", {}), dict) else {}
            self.steps = int(data.get("steps", 0))
            self.best = data.get("best")
            self.positive = int(data.get("positive", 0))
            self.recent = data.get("recent", {}) if isinstance(data.get("recent", {}), dict) else {}
            self.delays = data.get("delays", {}) if isinstance(data.get("delays", {}), dict) else {}
            self.passive = data.get("passive", {}) if isinstance(data.get("passive", {}), dict) else {}
            self.passive_families = data.get("passive_families", {}) if isinstance(data.get("passive_families", {}), dict) else {}
        except Exception:
            pass

    @staticmethod
    def _value(stat):
        return float(stat.get("q", 0.0)), int(stat.get("n", 0)), float(stat.get("v", 0.0))

    @staticmethod
    def _update(table, key, target, weight=1.0):
        stat = table.setdefault(
            key, {"n": 0, "q": 0.0, "v": 0.0, "good": 0, "bad": 0,
                  "zero": 0, "up": 0.0, "down": 0.0})
        stat["n"] = int(stat.get("n", 0)) + 1
        old = float(stat.get("q", 0.0))
        n = stat["n"]
        # Keep adapting after long sessions; UI rules can change while the app is running.
        rate = max(0.035, 1.0 / min(n, 32))
        sample = float(target) * float(weight)
        # Change-point acceleration: when new evidence strongly contradicts an established
        # rule, forget stale experience faster instead of spending dozens of steps relearning.
        if n >= 9 and old * sample < -0.055 and abs(sample - old) > 0.34:
            rate = max(rate, 0.17 if n < 40 else 0.12)
            stat["good"] = int(float(stat.get("good", 0)) * 0.94)
            stat["bad"] = int(float(stat.get("bad", 0)) * 0.94)
        new = old + rate * (sample - old)
        stat["q"] = new
        err = sample - new
        stat["v"] = float(stat.get("v", 0.0)) * 0.91 + err * err * 0.09
        if sample > 0.035:
            stat["good"] = int(stat.get("good", 0)) + 1
            stat["up"] = float(stat.get("up", 0.0)) * 0.90 + sample * 0.10
            stat["down"] = float(stat.get("down", 0.0)) * 0.94
        elif sample < -0.035:
            stat["bad"] = int(stat.get("bad", 0)) + 1
            stat["down"] = float(stat.get("down", 0.0)) * 0.90 + abs(sample) * 0.10
            stat["up"] = float(stat.get("up", 0.0)) * 0.94
        else:
            stat["zero"] = int(stat.get("zero", 0)) + 1
            stat["up"] = float(stat.get("up", 0.0)) * 0.97
            stat["down"] = float(stat.get("down", 0.0)) * 0.97

    @staticmethod
    def _context_key(state, action):
        return f"{state}>{action}"

    @staticmethod
    def _macro_parts(action):
        if not isinstance(action, str) or not action.startswith("macro:"):
            return (action,)
        parts = tuple(x for x in action[6:].split("|") if x and not x.startswith("macro:"))
        return parts if parts else ()

    @classmethod
    def _make_macro(cls, parts):
        flat = []
        for action in parts:
            flat.extend(cls._macro_parts(action))
        flat = [x for x in flat if x]
        if len(flat) < 2:
            return flat[0] if flat else None
        return "macro:" + "|".join(flat[:3])

    @staticmethod
    def _state_families(state):
        visual = re.search(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)", state)
        semantic = re.search(r":t([udf]):g(\d+):s(\d+):m(-?\d+)", state)
        if not semantic:
            return []
        trend, gap, stale, magnitude = semantic.groups()
        mag = int(magnitude)
        mag_bucket = max(-4, min(10, mag // 2))
        keys = [f"sem:t{trend}:g{gap}:m{mag_bucket}",
                f"stale:t{trend}:s{min(4, int(stale))}"]
        if visual:
            phash, ehash, color, layout = visual.groups()
            for i in range(4):
                band = phash[i * 4:(i + 1) * 4]
                keys.append(f"p{i}:{band}:t{trend}:g{min(3, int(gap))}:c{color}")
            keys.append(f"e0:{ehash[:4]}:t{trend}:l{layout[:2]}")
            keys.append(f"e1:{ehash[4:]}:t{trend}:l{layout[-2:]}")
        return keys

    @classmethod
    def _inverse_action(cls, action):
        direct = cls.INVERSES.get(action)
        if direct:
            return direct
        if not isinstance(action, str):
            return None
        if action.startswith("hold:"):
            parts = action.split(":")
            if len(parts) == 3:
                inverse = cls.INVERSES.get(f"key:{parts[1]}")
                if inverse:
                    return f"hold:{inverse.split(':', 1)[1]}:{parts[2]}"
        if action.startswith("chord:"):
            names = action.split(":", 1)[1].split("+")
            changed = False
            mapped = []
            for name in names:
                inverse = cls.INVERSES.get(f"key:{name}")
                if inverse:
                    mapped.append(inverse.split(":", 1)[1])
                    changed = True
                else:
                    mapped.append(name)
            if changed:
                return "chord:" + "+".join(mapped)
        return None

    @classmethod
    def _model_state(cls, state):
        """Compact visual-semantic state used by the learned transition model."""
        families = cls._state_families(state)
        if not families:
            return "unknown"
        return "~".join(families[:4])

    def _update_model(self, state, action, reward, next_state, reliability=1.0):
        current = self._model_state(state)
        following = self._model_state(next_state)
        key = f"{current}>{action}"
        self._update(self.models, key, reward, max(0.18, min(1.0, reliability)))
        stat = self.models.get(key, {})
        if not isinstance(stat.get("next"), dict):
            stat["next"] = {}
        transitions = stat["next"]
        transitions[following] = float(transitions.get(following, 0.0)) + max(
            0.12, min(1.0, reliability))
        if len(transitions) > 9:
            keep = sorted(transitions.items(), key=lambda item: item[1], reverse=True)[:9]
            stat["next"] = dict(keep)
            transitions = stat["next"]
        total = sum(float(value) for value in transitions.values())
        if total > 160.0:
            for name in tuple(transitions):
                transitions[name] = float(transitions[name]) * 0.72

    def _model_lookahead(self, state, action, actions):
        current = self._model_state(state)
        stat = self.models.get(f"{current}>{action}", {})
        q, n, variance = self._value(stat)
        transitions = stat.get("next", {}) if isinstance(stat, dict) else {}
        if n < 2 or not isinstance(transitions, dict) or not transitions:
            return q, n, variance
        total = sum(max(0.0, float(value)) for value in transitions.values())
        if total <= 0:
            return q, n, variance
        expected_future = 0.0
        for following, count in sorted(
                transitions.items(), key=lambda item: float(item[1]), reverse=True)[:6]:
            best = -float("inf")
            for candidate in actions:
                future_q, future_n, _future_v = self._value(
                    self.models.get(f"{following}>{candidate}", {}))
                if future_n:
                    best = max(best, future_q)
            if best == -float("inf"):
                best = 0.0
            expected_future += max(0.0, float(count)) / total * best
        return q + 0.30 * expected_future, n, variance

    @staticmethod
    def _action_aliases(action):
        """Canonicalize nearby mouse actions so knowledge transfers across grid sizes."""
        if not isinstance(action, str) or not action.startswith("mouse:"):
            return []
        try:
            parts = action.split(":")
            if len(parts) == 3:
                grid, sx, sy = 20, int(parts[1]), int(parts[2])
            elif len(parts) == 4:
                grid, sx, sy = int(parts[1]), int(parts[2]), int(parts[3])
            else:
                return []
            grid = max(2, int(grid))
            fx, fy = sx / grid, sy / grid
            aliases = []
            for bins in (6, 12, 24):
                qx = max(0, min(bins - 1, int(fx * bins)))
                qy = max(0, min(bins - 1, int(fy * bins)))
                aliases.append(f"m{bins}:{qx}:{qy}")
            return aliases
        except Exception:
            return []

    def _alias_value(self, state, action):
        aliases = self._action_aliases(action)
        if not aliases:
            return 0.0, 0, 0.0
        semantic = self._state_families(state)[:2]
        weighted_q = variance = weight_sum = 0.0
        total_n = 0
        for alias in aliases:
            keys = [(f"global>{alias}", 0.55)]
            keys.extend((f"{family}>{alias}", 1.0) for family in semantic)
            for key, scale in keys:
                stat = self.aliases.get(key, {})
                q, n, v = self._value(stat)
                if not n:
                    continue
                w = scale * min(3.4, 0.65 + math.log1p(n))
                weighted_q += q * w
                variance += v * w
                weight_sum += w
                total_n += n
        if not weight_sum:
            return 0.0, 0, 0.0
        return weighted_q / weight_sum, total_n, variance / weight_sum

    def _update_aliases(self, state, action, reward, contextual_target):
        aliases = self._action_aliases(action)
        if not aliases:
            return
        semantic = self._state_families(state)[:2]
        for alias in aliases:
            self._update(self.aliases, f"global>{alias}", reward, 0.62)
            for family in semantic:
                self._update(self.aliases, f"{family}>{alias}", contextual_target, 0.72)

    def _family_value(self, state, action):
        weighted_q = 0.0
        weight_sum = 0.0
        variance = 0.0
        total_n = 0
        good = bad = 0
        for family in self._state_families(state):
            stat = self.families.get(f"{family}>{action}", {})
            q, n, v = self._value(stat)
            if not n:
                continue
            w = min(4.2, math.log1p(n) + 0.55)
            weighted_q += q * w
            variance += v * w
            weight_sum += w
            total_n += n
            good += int(stat.get("good", 0))
            bad += int(stat.get("bad", 0))
        if not weight_sum:
            return 0.0, 0, 0.0, 0, 0
        return weighted_q / weight_sum, total_n, variance / weight_sum, good, bad

    def _future_value(self, state, actions=None):
        best = 0.0
        iterable = actions or []
        if not iterable:
            prefix = f"{state}>"
            iterable = [k[len(prefix):] for k in self.contexts if k.startswith(prefix)]
        for action in iterable:
            q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, _fv, _fg, _fb = self._family_value(state, action)
            if n or fn:
                blended = q if n and not fn else fq if fn and not n else 0.70 * q + 0.30 * fq
                best = max(best, blended)
        return best

    @staticmethod
    def _success_posterior(stat):
        good = max(0.0, float(stat.get("good", 0)))
        bad = max(0.0, float(stat.get("bad", 0)))
        zero = max(0.0, float(stat.get("zero", 0)))
        alpha = good + 1.0
        beta = bad + 1.0 + zero * 0.58
        total = alpha + beta
        mean = alpha / max(1e-9, total)
        variance = alpha * beta / max(1e-9, total * total * (total + 1.0))
        lower = max(0.0, mean - 1.15 * math.sqrt(max(0.0, variance)))
        return mean, lower, alpha, beta

    @staticmethod
    def _raw_reward(before, after, confidence=1.0):
        delta = after - before
        reference = max(1e-6, abs(before) * 0.0025, abs(after) * 1e-9)
        reward = math.asinh(delta / reference) if delta else 0.0
        if before > 0 and after > 0 and delta:
            reward += max(-2.0, min(2.0, math.log(after / before) * 0.42))
        conf = max(0.0, min(1.0, float(confidence)))
        reliability = max(0.08, min(1.0, (conf - 0.20) / 0.68))
        return max(-8.0, min(8.0, reward * reliability)), reliability, reference

    def passive_value(self, state):
        global_q, global_n, _v = self._value(self.passive.get("global", {}))
        values = []
        for family in self._state_families(state)[:5]:
            q, n, _v = self._value(self.passive_families.get(family, {}))
            if n:
                values.append((q, min(3.0, 0.7 + math.log1p(n))))
        if not values:
            return global_q if global_n else 0.0
        denom = sum(w for _q, w in values)
        family_q = sum(q * w for q, w in values) / max(1e-9, denom)
        return 0.66 * family_q + 0.34 * global_q if global_n else family_q

    def observe_passive(self, before, after, state, confidence=1.0):
        reward, _reliability, _reference = self._raw_reward(before, after, confidence)
        self._update(self.passive, "global", reward, 0.78)
        for family in self._state_families(state)[:5]:
            self._update(self.passive_families, family, reward, 0.84)
        return reward

    def expand_actions(self, actions, state, stagnant, limit=5):
        """Add proven short plans, prioritizing plans proven in the current state family."""
        base = list(dict.fromkeys(a for a in actions if a and not a.startswith("macro:")))
        if not base or limit <= 0:
            return base
        allowed = set(base)
        ranked = []

        for sequence, stat in self.sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 3 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            context_values = []
            for family in self._state_families(state)[:4]:
                sq, sn, sv = self._value(self.sequence_contexts.get(f"{family}>{sequence}", {}))
                if sn:
                    context_values.append((sq, sn, sv))
            if context_values:
                weights = [min(3.0, 0.65 + math.log1p(sn)) for _sq, sn, _sv in context_values]
                denom = max(1e-9, sum(weights))
                contextual_q = sum(sq * w for (sq, _sn, _sv), w in zip(context_values, weights)) / denom
                contextual_v = sum(sv * w for (_sq, _sn, sv), w in zip(context_values, weights)) / denom
                contextual_n = sum(sn for _sq, sn, _sv in context_values)
            else:
                contextual_q = contextual_v = 0.0
                contextual_n = 0
            success, lower, _a, _b = self._success_posterior(stat)
            threshold_n = 2 if stagnant > 24 else 3
            threshold_q = 0.02 if stagnant > 38 else 0.08
            blended_q = q if not contextual_n else 0.56 * q + 0.44 * contextual_q
            effective_n = n + min(8, contextual_n)
            if effective_n >= threshold_n and blended_q > threshold_q and success >= 0.51:
                score = blended_q + 0.16 * (success - 0.5) + 0.12 * (lower - 0.35)
                score += min(0.14, math.log1p(effective_n) * 0.026)
                score -= min(0.11, math.sqrt(max(0.0, v + contextual_v * 0.35)) * 0.025)
                ranked.append((score, self._make_macro(parts)))

        # If a single action is very reliable, planning a repeat can beat re-deciding
        # after every frame and handles games that reward sustained/tapped inputs.
        for action in base:
            q, n, v = self._value(self.stats.get(action, {}))
            stat = self.stats.get(action, {})
            success, lower, _a, _b = self._success_posterior(stat)
            if n >= 5 and q > 0.16 and success >= 0.62 and lower >= 0.42:
                score = q + 0.12 * success - min(0.08, math.sqrt(max(0.0, v)) * 0.02)
                ranked.append((score, self._make_macro((action, action))))
                if n >= 12 and q > 0.34 and success >= 0.72:
                    ranked.append((score * 0.94, self._make_macro((action, action, action))))

        out = list(base)
        seen = set(out)
        for _score, macro in sorted(ranked, reverse=True):
            if macro and macro not in seen:
                out.append(macro)
                seen.add(macro)
                if len(out) >= len(base) + limit:
                    break
        return out

    def choose(self, actions, state, stagnant, priors=None):
        priors = priors or {}
        if not actions:
            return None
        epsilon = max(0.030, 0.24 * math.exp(-self.steps / 1450.0))
        proven = False
        if stagnant < 10:
            for candidate in actions:
                stat = self.stats.get(candidate, {})
                q, n, _v = self._value(stat)
                good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
                zero = int(stat.get("zero", 0))
                success, lower, _a, _b = self._success_posterior(stat)
                if n >= 8 and q > 0.16 and success >= 0.64 and lower >= 0.47:
                    proven = True
                    break
            if proven:
                epsilon = max(0.018, epsilon * 0.42)
        if stagnant > 15:
            epsilon = max(epsilon, 0.20)
        if stagnant > 32:
            epsilon = max(epsilon, 0.36)
        if stagnant > 54:
            epsilon = max(epsilon, 0.54)
        if random.random() < epsilon:
            weights = []
            for action in actions:
                _q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
                _fq, fn, _fv, _fg, _fb = self._family_value(state, action)
                _aq, an, _av = self._alias_value(state, action)
                gq, gn, _gv = self._value(self.stats.get(action, {}))
                mq, mn, _mv = self._model_lookahead(state, action, actions)
                stat = self.stats.get(action, {})
                bad, good = int(stat.get("bad", 0)), int(stat.get("good", 0))
                zero = int(stat.get("zero", 0))
                _mean_success, lower_success, _a, _b = self._success_posterior(stat)
                risk = 0.72 + 0.56 * lower_success
                if gn >= 8 and bad > good * 2 + 2 and gq < -0.08:
                    risk = 0.20
                if gn >= 8 and zero / max(1, gn) > 0.78 and gq <= 0.02:
                    risk *= 0.46
                if action.startswith("macro:"):
                    risk *= 0.82
                if mn >= 4 and mq < -0.18:
                    risk *= max(0.24, 1.0 + mq * 0.30)
                prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
                prior_weight = 0.76 + 0.48 * prior if (n + fn + an + gn) < 5 else 1.0
                weights.append(risk * prior_weight / math.sqrt(
                    n + fn * 0.12 + an * 0.10 + gn * 0.08 + mn * 0.10 + 1.0))
            total = sum(weights)
            if total > 0:
                pick = random.random() * total
                for action, weight in zip(actions, weights):
                    pick -= weight
                    if pick <= 0:
                        return action
            return actions[-1]

        total = max(3, self.steps + 2)
        best_action, best_value = None, -float("inf")
        inverse = self._inverse_action(self.last_action) if self.last_reward < -0.08 else None
        for action in actions:
            gq, gn, gv = self._value(self.stats.get(action, {}))
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, fv, fgood, fbad = self._family_value(state, action)
            aq, an, av = self._alias_value(state, action)
            pq, pn, _ = self._value(self.pairs.get(f"{self.last_action}>{action}", {}))
            tq, tn, _ = self._value(
                self.triples.get(f"{self.prev_action}>{self.last_action}>{action}", {}))
            mq, mn, mv = self._model_lookahead(state, action, actions)

            if cn:
                base = 0.36 * gq + 0.44 * cq + 0.14 * fq + (0.06 * aq if an else 0.0)
            elif fn:
                base = 0.49 * gq + 0.39 * fq + (0.12 * aq if an else 0.0)
            elif an:
                # Nearby normalized clicks provide a useful prior when this exact grid
                # coordinate is new on the current display/hardware profile.
                base = 0.72 * gq + 0.28 * aq
            else:
                base = gq
            value = base
            if self.last_action:
                value += 0.22 * pq
            if self.prev_action and self.last_action:
                value += 0.10 * tq
            if mn:
                model_trust = min(0.30, 0.055 + math.log1p(mn) * 0.050)
                value = value * (1.0 - model_trust) + mq * model_trust

            stat = self.stats.get(action, {})
            good = int(stat.get("good", 0)) + fgood
            bad = int(stat.get("bad", 0)) + fbad
            zero = int(stat.get("zero", 0))
            success, lower_success, alpha, beta = self._success_posterior(stat)
            try:
                sampled_success = random.betavariate(alpha, beta)
            except Exception:
                sampled_success = success
            value += (0.15 * (success - 0.5) + 0.10 * (sampled_success - 0.5) +
                      0.14 * (lower_success - 0.35))

            n_eff = (gn * 0.30 + cn + fn * 0.13 + an * 0.10 +
                     pn * 0.15 + tn * 0.07 + mn * 0.14)
            prior = max(0.0, min(1.0, float(priors.get(action, 0.50))))
            value += (prior - 0.50) * 0.18 / (1.0 + math.sqrt(max(0.0, n_eff)))
            ucb_scale = 0.25 if proven else 0.48
            value += ucb_scale * math.sqrt(math.log(total + 1.0) / (n_eff + 1.0))
            variance = max(0.0, gv + cv + fv + av * 0.35 + mv * 0.28)
            value += min(0.16, 0.052 * math.sqrt(variance))
            if n_eff > 8:
                value -= min(0.15, 0.025 * math.sqrt(variance))

            # Explicitly model actions that mostly do nothing and actions with a large
            # negative tail. This prevents noisy exploration from repeatedly wasting steps.
            if gn >= 6:
                neutral_rate = zero / max(1, gn)
                if neutral_rate > 0.62 and gq <= 0.04:
                    value -= min(0.34, (neutral_rate - 0.62) * 0.72)
                downside = float(stat.get("down", 0.0))
                if downside > 0.0:
                    value -= min(0.24, downside * 0.035)

            recent = self.recent.get(action, {})
            if recent:
                age = max(0, self.steps - int(recent.get("step", self.steps)))
                value += float(recent.get("r", 0.0)) * 0.27 * math.exp(-age / 105.0)

            if gn >= 7 and bad > good * 2 + 2 and gq < -0.10:
                value -= min(1.05, 0.080 * (bad - good))
            if cn == 0 and fn == 0 and an == 0:
                value += 0.085
            if inverse and action == inverse:
                value += min(0.42, 0.15 + abs(self.last_reward) * 0.08)
            if action.startswith("macro:") and gn < 2:
                value -= 0.06

            recent_count = self.action_trace[-7:].count(action)
            recent_reward = float(recent.get("r", 0.0)) if recent else 0.0
            if recent_count >= 3 and recent_reward <= 0.02:
                value -= 0.10 * (recent_count - 2)
            elif action == self.last_action and self.last_reward > 0.14 and recent_reward > 0.08:
                # Positive persistence matters for controls that reward repeated taps/holds.
                value += min(0.30, 0.09 + self.last_reward * 0.055)
            value += random.random() * 1e-6
            if value > best_value:
                best_action, best_value = action, value
        return best_action

    def learn(self, action, before, after, state, next_state, confidence=1.0, actions=None):
        delta = after - before
        reward, reliability, reference = self._raw_reward(before, after, confidence)
        best_before = self.best
        if best_before is not None and after > best_before:
            best_gain = math.asinh((after - best_before) / reference)
            reward += min(1.15, max(0.0, best_gain) * 0.16) * reliability
        if action == OBSERVE_ACTION:
            self._update(self.passive, "global", reward, 0.78)
            for family in self._state_families(state)[:5]:
                self._update(self.passive_families, family, reward, 0.84)
        else:
            # Learn causal advantage over natural/passive score drift, not mere correlation.
            baseline = self.passive_value(state)
            if abs(baseline) > 0.012:
                reward -= max(-2.2, min(2.2, baseline * 0.68))
        reward = max(-8.0, min(8.0, reward))
        future = self._future_value(next_state, actions)
        contextual_target = reward + 0.32 * future
        self._update(self.stats, action, reward)
        self._update(self.contexts, self._context_key(state, action), contextual_target)
        self._update_aliases(state, action, reward, contextual_target)
        for family in self._state_families(state):
            self._update(self.families, f"{family}>{action}", contextual_target, 0.80)
        self._update_model(state, action, reward, next_state, reliability)
        if self.last_action:
            self._update(self.pairs, f"{self.last_action}>{action}", reward, 0.90)
        if self.prev_action and self.last_action:
            self._update(self.triples,
                         f"{self.prev_action}>{self.last_action}>{action}", reward, 0.78)

        parts = self._macro_parts(action)
        if len(parts) > 1:
            for part in parts:
                self._update(self.stats, part, reward / max(1.0, math.sqrt(len(parts))), 0.48)

        # Eligibility-style credit assignment handles delayed gains and losses. Negative
        # credit decays faster so one bad delayed observation does not poison a whole plan.
        if abs(reward) > 0.045:
            decay = 0.43 if reward > 0 else 0.29
            for age, item in enumerate(reversed(self.history[-6:]), start=1):
                old_action, old_state = item
                credit = reward * (decay ** age)
                self._update(self.stats, old_action, credit, 0.58)
                self._update(self.contexts, self._context_key(old_state, old_action), credit, 0.64)
                for family in self._state_families(old_state):
                    self._update(self.families, f"{family}>{old_action}", credit, 0.46)

        # Mine short successful/failed trajectories. Only atomic actions are stored so
        # macros never recursively contain other macros.
        for part in parts:
            if part:
                self.atomic_trace.append(part)
        if len(self.atomic_trace) > 14:
            self.atomic_trace = self.atomic_trace[-14:]
        if abs(reward) > 0.035:
            for length in (2, 3):
                if len(self.atomic_trace) >= length:
                    sequence = "|".join(self.atomic_trace[-length:])
                    weight = 0.92 if length == 2 else 0.78
                    self._update(self.sequences, sequence, reward, weight)
                    for family in self._state_families(state)[:4]:
                        self._update(self.sequence_contexts, f"{family}>{sequence}",
                                     contextual_target, weight * 0.78)

        self.history.append((action, state))
        if len(self.history) > 12:
            self.history = self.history[-12:]
        self.prev_action = self.last_action
        self.last_action = action
        self.last_reward = reward
        self.steps += 1
        self.action_trace.append(action)
        if len(self.action_trace) > 20:
            self.action_trace = self.action_trace[-20:]
        old_recent = self.recent.get(action, {})
        old_r = float(old_recent.get("r", 0.0))
        self.recent[action] = {"r": old_r * 0.66 + reward * 0.34, "step": self.steps}
        if len(self.recent) > 150:
            keep = sorted(self.recent.items(), key=lambda kv: int(kv[1].get("step", 0)),
                          reverse=True)[:150]
            self.recent = dict(keep)
        if delta > 0:
            self.positive += 1
        if self.best is None or after > self.best:
            self.best = after
        return delta, reward

    def delay_hint(self, action):
        hints = []
        for part in self._macro_parts(action):
            stat = self.delays.get(part, {})
            n = int(stat.get("n", 0))
            late = float(stat.get("late", 0.0))
            if n >= 2 and late > 0.12:
                hints.append(min(0.34, 0.055 + late * 0.28))
        return max(hints, default=0.0)

    def record_delay(self, action, delayed_effect):
        value = 1.0 if delayed_effect else 0.0
        for part in self._macro_parts(action):
            stat = self.delays.setdefault(part, {"n": 0, "late": 0.0})
            n = int(stat.get("n", 0)) + 1
            rate = 0.24 if n < 8 else 0.10
            stat["n"] = n
            stat["late"] = float(stat.get("late", 0.0)) * (1.0 - rate) + value * rate
        if len(self.delays) > 180:
            keep = sorted(self.delays.items(), key=lambda kv: int(kv[1].get("n", 0)),
                          reverse=True)[:180]
            self.delays = dict(keep)

    def action_quality(self, action, state=None):
        gq = self._value(self.stats.get(action, {}))[0]
        if not state:
            return gq
        cq, cn, _ = self._value(self.contexts.get(self._context_key(state, action), {}))
        fq, fn, _fv, _fg, _fb = self._family_value(state, action)
        aq, an, _av = self._alias_value(state, action)
        if cn:
            return 0.53 * cq + 0.27 * gq + 0.14 * fq + (0.06 * aq if an else 0.0)
        if fn:
            return 0.53 * gq + 0.39 * fq + (0.08 * aq if an else 0.0)
        if an:
            return 0.74 * gq + 0.26 * aq
        return gq

    def preferred_actions(self, prefix="", limit=8):
        ranked = []
        for action, stat in self.stats.items():
            if action.startswith("macro:"):
                continue
            if prefix and not action.startswith(prefix):
                continue
            q, n, _ = self._value(stat)
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            zero = int(stat.get("zero", 0))
            success = (good + 1) / (good + bad + zero + 2)
            if n >= 6 and zero / max(1, n) > 0.78 and q <= 0.02:
                continue
            if n >= 2 and q > -0.08 and success >= 0.28:
                downside = float(stat.get("down", 0.0))
                ranked.append((q + min(0.2, math.log1p(n) * 0.02) + success * 0.07
                               - min(0.12, downside * 0.025), action))
        ranked.sort(reverse=True)
        return [action for _score, action in ranked[:limit]]

    @staticmethod
    def _trim(table, limit):
        if len(table) <= limit:
            return table
        ranked = sorted(table.items(),
                        key=lambda kv: (int(kv[1].get("n", 0)),
                                        abs(float(kv[1].get("q", 0.0)))), reverse=True)
        return dict(ranked[:limit])

    def save(self):
        self.contexts = self._trim(self.contexts, 18000)
        self.families = self._trim(self.families, 14000)
        self.pairs = self._trim(self.pairs, 5200)
        self.triples = self._trim(self.triples, 6200)
        self.sequences = self._trim(self.sequences, 6000)
        self.sequence_contexts = self._trim(self.sequence_contexts, 9000)
        self.aliases = self._trim(self.aliases, 9000)
        self.models = self._trim(self.models, 12000)
        self.passive_families = self._trim(self.passive_families, 3000)
        data = {"version": 13, "steps": self.steps, "best": self.best,
                "positive": self.positive, "stats": self.stats,
                "contexts": self.contexts, "families": self.families,
                "pairs": self.pairs, "triples": self.triples,
                "sequences": self.sequences, "sequence_contexts": self.sequence_contexts,
                "aliases": self.aliases, "models": self.models,
                "recent": self.recent, "delays": self.delays,
                "passive": self.passive, "passive_families": self.passive_families}
        temp = self.state_file.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                        encoding="utf-8")
        os.replace(temp, self.state_file)

class ValueAI:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.storage = None
        self.data_dir = None
        self.runtime_dir = None
        self.runtime_version = ""
        self.hardware = None
        self.reader = None
        self.capture = None
        self.cv2 = None
        self.np = None
        self.target_hwnd = None
        self.target_pid = None
        self.target_process = ""
        self.target_title = ""
        self.relative_roi = None
        self.normalized_roi = None
        self.stop_event = threading.Event()
        self.hook = None
        self.worker = None
        self.last_summary = ""
        self._visual_cache = "v0"
        self.action_priors = dict(KEY_ACTION_PRIORS)
        self._build_ui()
        self.root.after(80, self._choose_storage)
        self.root.after(100, self._poll)

    def _build_ui(self):
        self.root.title(APP_NAME)
        self.root.geometry("640x430")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        outer = ttk.Frame(self.root, padding=28)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=APP_NAME, font=("Microsoft YaHei UI", 22, "bold")).pack()
        ttk.Label(outer, text="把屏幕上的数值作为奖励，让 AI 自主学习有效操作",
                  font=("Microsoft YaHei UI", 10)).pack(pady=(6, 22))
        self.path_var = tk.StringVar(value="等待选择 D 盘文件夹")
        ttk.Label(outer, textvariable=self.path_var, wraplength=570,
                  foreground="#555555").pack(fill="x")
        self.progress = ttk.Progressbar(outer, mode="indeterminate", length=550)
        self.progress.pack(pady=(12, 18))
        row = ttk.Frame(outer)
        row.pack(pady=4)
        self.value_button = ttk.Button(row, text="数值", state="disabled",
                                       command=self._select_value, width=18)
        self.value_button.pack(side="left", padx=8, ipady=13)
        self.confirm_button = ttk.Button(row, text="确认", state="disabled",
                                         command=self._start, width=18)
        self.confirm_button.pack(side="left", padx=8, ipady=13)
        self.selection_var = tk.StringVar(value="尚未选择数值")
        ttk.Label(outer, textvariable=self.selection_var,
                  font=("Microsoft YaHei UI", 11, "bold")).pack(pady=(20, 8))
        self.status_var = tk.StringVar(value="")
        ttk.Label(outer, textvariable=self.status_var, wraplength=570,
                  justify="center").pack()
        ttk.Label(outer,
                  text="运行后按 ESC 立即停止。AI 仅操作数值所属窗口；请勿用于含支付或不可逆操作的窗口。",
                  wraplength=570, foreground="#8a3b12", justify="center").pack(
                      side="bottom", pady=(18, 0))

    def _choose_storage(self):
        dialog = DFolderDialog(self.root)
        self.root.wait_window(dialog)
        if not dialog.result:
            self.root.destroy()
            return
        self.storage = dialog.result
        try:
            self.data_dir = self.storage / DATA_DIR_NAME
            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.hardware = HardwareProfile(self.data_dir)
            arch = re.sub(r"[^a-z0-9_-]", "", self.hardware.architecture) or "64bit"
            version = f"py{sys.version_info.major}{sys.version_info.minor}-{arch}"
            self.runtime_version = version
            self.runtime_dir = self.data_dir / f"runtime-{version}-{self.hardware.tag}"
            for path in (self.runtime_dir, self.data_dir / "缓存",
                         self.data_dir / "临时文件"):
                path.mkdir(parents=True, exist_ok=True)
            os.chdir(self.data_dir)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法在所选文件夹写入数据：\n{exc}", parent=self.root)
            self.root.destroy()
            return
        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{self.hardware.summary()}")
        self.status_var.set("正在按本机硬件准备视觉识别组件，请稍候……")
        self.progress.start(12)
        threading.Thread(target=self._prepare_runtime, daemon=True).start()

    def _prepare_runtime(self):
        cache = self.data_dir / "缓存"
        temp = self.data_dir / "临时文件"
        marker = self.runtime_dir / f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}"
        try:
            env = os.environ.copy()
            directed = {
                "PIP_CACHE_DIR": cache / "pip", "TMP": temp, "TEMP": temp,
                "XDG_CACHE_HOME": cache, "HF_HOME": cache / "huggingface",
                "RAPIDOCR_HOME": cache / "rapidocr",
                "MPLCONFIGDIR": cache / "matplotlib", "NUMBA_CACHE_DIR": cache / "numba",
                "PYTHONPYCACHEPREFIX": cache / "pycache",
            }
            for key, value in directed.items():
                Path(value).mkdir(parents=True, exist_ok=True)
                env[key] = str(value)
                os.environ[key] = str(value)
            model_root = cache / "rapidocr_models"
            model_root.mkdir(parents=True, exist_ok=True)
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            env["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)
            env["OMP_WAIT_POLICY"] = "PASSIVE"
            env["ORT_LOG_SEVERITY_LEVEL"] = "3"
            sys.pycache_prefix = str(cache / "pycache")
            if str(self.runtime_dir) not in sys.path:
                sys.path.insert(0, str(self.runtime_dir))

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            if marker.exists():
                required = ("rapidocr", "onnxruntime", "cv2", "PIL", "mss")
                if not all((self.runtime_dir / name).exists() for name in required):
                    try:
                        marker.unlink()
                    except OSError:
                        pass
                else:
                    # A marker can outlive a partially removed DLL, a Python update or a
                    # security product quarantine. Validate imports and self-repair now.
                    probe_code = ("import sys;sys.path.insert(0," +
                                  repr(str(self.runtime_dir)) +
                                  ");import rapidocr,onnxruntime,cv2,PIL,mss")
                    probe_env = env.copy()
                    probe_env["PYTHONNOUSERSITE"] = "1"
                    try:
                        probe = subprocess.run(
                            [sys.executable, "-c", probe_code], env=probe_env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            timeout=24, creationflags=creationflags)
                        if probe.returncode:
                            marker.unlink(missing_ok=True)
                    except Exception:
                        marker.unlink(missing_ok=True)

            def install(packages, no_deps=False):
                command = [sys.executable, "-m", "pip", "install", "--upgrade",
                           "--prefer-binary", "--disable-pip-version-check",
                           "--no-warn-script-location", "--target", str(self.runtime_dir)]
                if no_deps:
                    command.append("--no-deps")
                if self.hardware.disk_free < 5 * GIB:
                    command.append("--no-cache-dir")
                command += list(packages)
                last = None
                for attempt in range(2):
                    run = subprocess.run(command, env=env, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True,
                                         encoding="utf-8", errors="replace",
                                         creationflags=creationflags)
                    last = run
                    if run.returncode == 0:
                        return
                    if attempt == 0:
                        time.sleep(0.8)
                tail = "\n".join((last.stdout if last else "").splitlines()[-18:])
                raise RuntimeError(tail or "pip 安装失败")

            if not marker.exists():
                backend_pkg = ("onnxruntime-directml>=1.18,<2" if self.hardware.want_dml
                               else "onnxruntime>=1.18,<2")
                try:
                    install([f"rapidocr=={RAPIDOCR_VERSION}", backend_pkg, MSS_SPEC])
                except Exception:
                    if not self.hardware.want_dml:
                        raise
                    # Some older/virtual/remote Windows GPU stacks cannot load the DML
                    # wheel. Recreate the isolated runtime and continue on CPU.
                    shutil.rmtree(self.runtime_dir, ignore_errors=True)
                    self.hardware.want_dml = False
                    self.hardware.backend = "cpu"
                    self.hardware.dml_tested_at = time.time()
                    self.runtime_dir = self.data_dir / (
                        f"runtime-{self.runtime_version}-{self.hardware.tag}")
                    self.runtime_dir.mkdir(parents=True, exist_ok=True)
                    marker = self.runtime_dir / (
                        f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}")
                    if str(self.runtime_dir) not in sys.path:
                        sys.path.insert(0, str(self.runtime_dir))
                    install([f"rapidocr=={RAPIDOCR_VERSION}", "onnxruntime>=1.18,<2", MSS_SPEC])

            importlib.invalidate_caches()
            try:
                import onnxruntime as ort
            except Exception:
                if not self.hardware.want_dml:
                    raise
                # A DirectML wheel may install successfully yet fail to load against an
                # older driver/runtime. Rebuild the isolated runtime on CPU immediately.
                for module_name in tuple(sys.modules):
                    if module_name == "onnxruntime" or module_name.startswith("onnxruntime."):
                        sys.modules.pop(module_name, None)
                self.hardware.want_dml = False
                self.hardware.backend = "cpu"
                self.hardware.dml_tested_at = time.time()
                self.runtime_dir = self.data_dir / (
                    f"runtime-{self.runtime_version}-{self.hardware.tag}")
                self.runtime_dir.mkdir(parents=True, exist_ok=True)
                marker = self.runtime_dir / (
                    f".ready-runtime-v{RUNTIME_SCHEMA}-{RAPIDOCR_VERSION}")
                if str(self.runtime_dir) not in sys.path:
                    sys.path.insert(0, str(self.runtime_dir))
                install([f"rapidocr=={RAPIDOCR_VERSION}",
                         "onnxruntime>=1.18,<2", MSS_SPEC])
                importlib.invalidate_caches()
                import onnxruntime as ort
            from PIL import Image, ImageGrab, ImageOps
            import cv2
            import numpy as np
            try:
                import mss
            except Exception:
                mss = None
            dxcam = None
            if self.hardware.dxcam_eligible and self.hardware.tier != "low":
                try:
                    import dxcam as _dxcam
                    dxcam = _dxcam
                except Exception:
                    try:
                        install([COMTYPES_SPEC, DXCAM_SPEC], no_deps=True)
                        importlib.invalidate_caches()
                        import dxcam as _dxcam
                        dxcam = _dxcam
                    except Exception:
                        dxcam = None
            from rapidocr import (EngineType, LangDet, LangRec, ModelType,
                                  OCRVersion, RapidOCR)

            model_map = {"tiny": ModelType.TINY, "small": ModelType.SMALL,
                         "medium": ModelType.MEDIUM}
            rec_model = model_map.get(self.hardware.rec_model, ModelType.SMALL)
            det_model = model_map.get(self.hardware.det_model, ModelType.SMALL)

            def make_params(use_dml=False, version=OCRVersion.PPOCRV6,
                            rec_size=None, det_size=None, threads=None,
                            rec_lang=None, det_lang=None):
                thread_count = max(1, int(threads or self.hardware.ocr_threads))
                return {
                    "Global.text_score": 0.14,
                    "Global.use_preprocess_img": True,
                    "Global.use_vertical_padding": True,
                    "Global.min_height": 26,
                    "Global.width_height_ratio": 18,
                    "Global.min_side_len": 26,
                    "Global.max_side_len": 2200,
                    "Global.model_root_dir": str(model_root),
                    "Det.engine_type": EngineType.ONNXRUNTIME,
                    "Det.lang_type": det_lang or LangDet.CH,
                    "Det.model_type": det_size or det_model,
                    "Det.ocr_version": version,
                    "Rec.engine_type": EngineType.ONNXRUNTIME,
                    "Rec.lang_type": rec_lang or LangRec.CH,
                    "Rec.model_type": rec_size or rec_model,
                    "Rec.ocr_version": version,
                    "EngineConfig.onnxruntime.intra_op_num_threads": thread_count,
                    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                    "EngineConfig.onnxruntime.enable_cpu_mem_arena": self.hardware.ram >= 8 * GIB,
                    "EngineConfig.onnxruntime.use_dml": bool(use_dml),
                }

            probes = []
            probe1 = np.full((96, 360, 3), 248, dtype="uint8")
            cv2.putText(probe1, "987654.321K", (10, 68), cv2.FONT_HERSHEY_SIMPLEX,
                        1.65, (18, 18, 18), 3, cv2.LINE_AA)
            probes.append((probe1, 987654321.0))
            probe2 = np.full((62, 248, 3), 24, dtype="uint8")
            cv2.putText(probe2, "12,345.67", (5, 45), cv2.FONT_HERSHEY_SIMPLEX,
                        1.05, (242, 242, 242), 2, cv2.LINE_AA)
            probes.append((probe2, 12345.67))
            if self.hardware.tier != "low":
                probe3 = np.full((74, 290, 3), 215, dtype="uint8")
                cv2.putText(probe3, "8.91e7", (10, 53), cv2.FONT_HERSHEY_SIMPLEX,
                            1.35, (45, 45, 45), 2, cv2.LINE_AA)
                probes.append((probe3, 8.91e7))

            def probe_accuracy(result, expected_value):
                texts = getattr(result, "txts", None)
                if texts is None:
                    return 0.0
                try:
                    text = "".join(str(x[0] if isinstance(x, (tuple, list)) and x else x)
                                   for x in list(texts))
                except Exception:
                    text = str(texts)
                value = parse_score(text)
                if value is None:
                    return 0.0
                rel = abs(value - expected_value) / max(1.0, abs(expected_value))
                return 1.0 if rel <= 1e-7 else (0.55 if rel <= 1e-4 else 0.0)

            def build_and_benchmark(use_dml, threads=None, params=None):
                engine = RapidOCR(params=params or make_params(use_dml=use_dml, threads=threads))
                warmups = 1 if self.hardware.tier == "low" else 2
                for _ in range(warmups):
                    engine(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                timings = []
                accuracy = []
                repeats = 1 if self.hardware.tier == "low" else 2
                for image_probe, expected_value in probes:
                    best_result = None
                    local_times = []
                    for _ in range(repeats):
                        t0 = time.perf_counter()
                        result = engine(image_probe, use_det=False, use_cls=False, use_rec=True)
                        local_times.append(time.perf_counter() - t0)
                        best_result = result
                    local_times.sort()
                    timings.append(local_times[len(local_times) // 2])
                    accuracy.append(probe_accuracy(best_result, expected_value))
                timings.sort()
                median_latency = timings[len(timings) // 2]
                correctness = sum(accuracy) / max(1, len(accuracy))
                composite = median_latency * (1.0 + max(0.0, 0.98 - correctness) * 4.0)
                return engine, median_latency, correctness, composite

            # Tune ORT CPU parallelism on the actual machine. More threads are often
            # slower for tiny recognition models, especially on hybrid-core CPUs.
            thread_candidates = {1, self.hardware.ocr_threads}
            if self.hardware.cached_threads:
                thread_candidates.add(self.hardware.cached_threads)
                thread_candidates.add(max(1, self.hardware.cached_threads - 1))
                thread_candidates.add(min(self.hardware.logical_cpus,
                                          self.hardware.cached_threads + 1))
            if self.hardware.logical_cpus >= 4:
                thread_candidates.add(min(2, self.hardware.logical_cpus))
            if self.hardware.logical_cpus >= 8:
                thread_candidates.add(max(2, min(self.hardware.ocr_threads,
                                                  self.hardware.logical_cpus // 3)))
            if self.hardware.tier == "low":
                thread_candidates = {1, self.hardware.ocr_threads}
            best_cpu = None
            best_cpu_time = float("inf")
            best_cpu_accuracy = 0.0
            best_cpu_composite = float("inf")
            best_threads = self.hardware.ocr_threads
            for threads in sorted(thread_candidates):
                try:
                    engine, elapsed, accuracy, composite = build_and_benchmark(False, threads)
                    if composite < best_cpu_composite:
                        if best_cpu is not None:
                            del best_cpu
                        best_cpu = engine
                        best_cpu_time = elapsed
                        best_cpu_accuracy = accuracy
                        best_cpu_composite = composite
                        best_threads = threads
                    else:
                        del engine
                except Exception:
                    continue
            if best_cpu is None:
                best_cpu, best_cpu_time, best_cpu_accuracy, best_cpu_composite = build_and_benchmark(
                    False, self.hardware.ocr_threads)
            self.hardware.ocr_threads = int(best_threads)
            os.environ["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)

            available = set(ort.get_available_providers())
            dml_possible = self.hardware.want_dml and "DmlExecutionProvider" in available
            if self.hardware.want_dml:
                self.hardware.dml_tested_at = time.time()
            primary = best_cpu
            chosen_ocr_time = best_cpu_time
            self.hardware.backend = "cpu"
            if dml_possible:
                try:
                    dml_engine, dml_time, dml_accuracy, dml_composite = build_and_benchmark(
                        True, max(1, min(2, best_threads)))
                    # Keep DirectML only when it is at least as reliable and wins the
                    # correctness-adjusted benchmark on this exact machine.
                    if (dml_accuracy + 0.01 >= best_cpu_accuracy and
                            dml_composite <= best_cpu_composite * 1.06):
                        primary = dml_engine
                        chosen_ocr_time = dml_time
                        self.hardware.backend = "dml"
                        del best_cpu
                    else:
                        del dml_engine
                except Exception:
                    pass

            engines = [("ocrv6-ch", primary, 1.0)]
            if self.hardware.ensemble:
                # PP-OCRv4 has a distinct English recognition model. Its narrower
                # alphabet complements the multilingual PP-OCRv6 model on digit/decimal/
                # scientific/K-M-B counters, while PP-OCRv6 stays primary for 万/亿/兆.
                try:
                    en_lang = getattr(LangRec, "EN", LangRec.CH)
                    en_det = getattr(LangDet, "EN", LangDet.CH)
                    en_params = make_params(
                        use_dml=(self.hardware.backend == "dml"),
                        version=OCRVersion.PPOCRV4, rec_size=ModelType.MOBILE,
                        det_size=ModelType.MOBILE, rec_lang=en_lang, det_lang=en_det)
                    en_engine = RapidOCR(params=en_params)
                    en_engine(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                    engines.append(("ocrv4-en", en_engine, 1.025))
                except Exception:
                    pass

                if self.hardware.tier == "high" and self.hardware.ram >= 16 * GIB:
                    try:
                        alt_params = make_params(
                            use_dml=(self.hardware.backend == "dml"),
                            version=OCRVersion.PPOCRV5,
                            rec_size=ModelType.MOBILE, det_size=ModelType.MOBILE)
                        alt = RapidOCR(params=alt_params)
                        alt(probes[0][0], use_det=False, use_cls=False, use_rec=True)
                        engines.append(("ocrv5", alt, 0.955))
                    except Exception:
                        pass

            marker.write_text("ok", encoding="ascii")
            self.capture = ScreenCapture(
                mss, ImageGrab, Image, dxcam_module=dxcam,
                preferred=self.hardware.preferred_capture)
            try:
                self.capture.benchmark()
            except Exception:
                pass
            self.hardware.capture_backend = self.capture.backend
            self.hardware.calibrate_runtime(chosen_ocr_time, self.capture.latency)
            self.cv2, self.np = cv2, np
            self.reader = ScoreReader(engines, self.capture, ImageOps, Image, np, cv2,
                                      max_variants=self.hardware.ocr_variants,
                                      hardware=self.hardware)
            self.events.put(("runtime_ready", self.hardware.summary()))
        except Exception as exc:
            try:
                marker.unlink(missing_ok=True)
            except Exception:
                pass
            self.events.put(("error", "视觉识别组件准备失败", str(exc)))

    def _select_value(self):
        self.confirm_button.configure(state="disabled")
        self.selection_var.set("请在屏幕上框选数值")
        self.root.withdraw()
        self.root.after(180, lambda: SelectionOverlay(self.root, self._selection_done))

    def _selection_done(self, rect):
        if not rect:
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            return
        self.root.after(140, lambda: self._identify_target(rect))

    def _identify_target(self, rect):
        center = ((rect[0] + rect[2]) // 2, (rect[1] + rect[3]) // 2)
        hwnd = window_at(*center)
        cr = client_rect(hwnd) if hwnd else None
        if (not hwnd or not cr or window_pid(hwnd) == os.getpid() or
                not (cr[0] <= center[0] < cr[2] and cr[1] <= center[1] < cr[3])):
            self.root.deiconify()
            messagebox.showerror(APP_NAME, "无法确定该数值所属的目标窗口，请重新框选。",
                                 parent=self.root)
            self.selection_var.set("尚未选择数值")
            return
        self.target_hwnd = hwnd
        self.target_pid = window_pid(hwnd)
        self.target_process = process_name(self.target_pid)
        self.target_title = window_title(hwnd)
        if window_class(hwnd) in {"Progman", "WorkerW", "Shell_TrayWnd",
                                   "Shell_SecondaryTrayWnd"}:
            self.root.deiconify()
            messagebox.showerror(APP_NAME, "不能把 Windows 桌面或任务栏作为目标窗口。",
                                 parent=self.root)
            self.selection_var.set("尚未选择数值")
            return
        self.relative_roi = (rect[0] - cr[0], rect[1] - cr[1],
                             rect[2] - cr[0], rect[3] - cr[1])
        cw, ch = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
        self.normalized_roi = (
            max(0.0, min(1.0, (rect[0] - cr[0]) / cw)),
            max(0.0, min(1.0, (rect[1] - cr[1]) / ch)),
            max(0.0, min(1.0, (rect[2] - cr[0]) / cw)),
            max(0.0, min(1.0, (rect[3] - cr[1]) / ch)),
        )
        threading.Thread(target=self._recognize_selection, args=(rect,), daemon=True).start()

    def _recognize_selection(self, rect):
        try:
            self.capture.benchmark(rect)
            self.hardware.capture_backend = self.capture.backend
            self.hardware.live_tune(self.reader.latency, self.capture.latency,
                                    self.reader.confidence_ema, 0.0)
            self.reader.latency_target = self.hardware.latency_target
        except Exception:
            pass
        value, confidence, text = self.reader.read(rect)
        reads = [(value, confidence, text)] if value is not None else []
        extra = 2 if self.hardware.tier == "high" else (1 if self.hardware.tier == "balanced" else 0)
        for _ in range(extra):
            if value is not None and confidence >= 0.93:
                break
            value2, confidence2, text2 = self.reader.read(rect)
            if value2 is not None:
                reads.append((value2, confidence2, text2))
        if reads:
            ranked = []
            for candidate, conf, txt in reads:
                agreement = sum(c for v, c, _t in reads if ScoreReader._same_value(v, candidate))
                ranked.append((agreement + conf * 0.25, conf, candidate, txt))
            ranked.sort(reverse=True)
            _weight, confidence, value, text = ranked[0]
            support = sum(1 for v, _c, _t in reads if ScoreReader._same_value(v, value))
            confidence = min(0.997, confidence + max(0, support - 1) * 0.07)
        else:
            value, confidence, text = None, 0.0, ""
        self.events.put(("selection", value, confidence, text))

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        self.stop_event.clear()
        self.hook = EscapeHook(self.stop_event)
        if not self.hook.start():
            messagebox.showerror(APP_NAME, "无法启用 ESC 紧急停止，因此未启动 AI。",
                                 parent=self.root)
            return
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.status_var.set("AI 已开启；按 ESC 立即停止")
        self.root.withdraw()
        user32.ShowWindow(self.target_hwnd, 9)
        user32.SetForegroundWindow(self.target_hwnd)
        self.worker = threading.Thread(target=self._run_ai, daemon=True)
        self.worker.start()

    def _profile_file(self):
        # Normalized coordinates make learned experience survive window resizing and
        # moving the same app between displays with different resolutions/DPI.
        quantized_roi = tuple(round(v * 100) for v in (self.normalized_roi or (0, 0, 0, 0)))
        # Window titles often contain a score, level or timer. Normalize volatile numeric
        # fragments so learned experience survives title changes and future sessions.
        stable_title = unicodedata.normalize("NFKC", self.target_title or "").lower()
        stable_title = re.sub(r"[-+]?\d+(?:[.,:]\d+)*(?:[kKmMbBtTqQ%])?", "#", stable_title)
        stable_title = re.sub(r"\s+", " ", stable_title).strip()[:160]
        cls = window_class(self.target_hwnd)
        raw = f"{self.target_process}|{stable_title}|{cls}|{quantized_roi}"
        key = hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:16]
        path = self.data_dir / f"学习状态-{key}.json"
        # One-time migration keeps experience created by older builds while the new
        # executable identity prevents unrelated apps with similar titles from sharing it.
        if not path.exists():
            legacy_raw = f"{stable_title}|{cls}|{quantized_roi}"
            legacy_key = hashlib.sha256(
                legacy_raw.encode("utf-8", "replace")).hexdigest()[:16]
            legacy = self.data_dir / f"学习状态-{legacy_key}.json"
            if legacy.exists():
                try:
                    os.replace(legacy, path)
                except OSError:
                    return legacy
        return path

    def _target_ready(self):
        if not user32.IsWindow(self.target_hwnd) or not user32.IsWindowVisible(self.target_hwnd):
            return False
        foreground = user32.GetForegroundWindow()
        return foreground == self.target_hwnd and window_pid(foreground) == self.target_pid

    def _native_control_candidates(self, client):
        """Discover real Win32 controls before falling back to visual guessing."""
        if os.name != "nt" or not self.target_hwnd or not client:
            return []
        cw, ch = client[2] - client[0], client[3] - client[1]
        if cw < 1 or ch < 1:
            return []
        controls = []
        positive_words = ("+", "up", "increase", "upgrade", "boost", "gain", "more",
                          "start", "play", "continue", "next", "claim", "collect",
                          "加", "升", "提升", "升级", "增加", "继续", "开始", "领取", "收集")
        dangerous_words = ("delete", "remove", "reset", "erase", "exit", "quit", "pay",
                           "checkout", "purchase", "format", "uninstall", "删除", "清空",
                           "重置", "退出", "支付", "付款", "购买", "卸载", "格式化")
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        def visit(hwnd, _lparam):
            try:
                if not user32.IsWindowVisible(hwnd) or not user32.IsWindowEnabled(hwnd):
                    return True
                rect = RECT()
                if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
                    return True
                left, top = max(client[0], rect.left), max(client[1], rect.top)
                right, bottom = min(client[2], rect.right), min(client[3], rect.bottom)
                width, height = right - left, bottom - top
                area = width * height
                if width < 8 or height < 8 or area > cw * ch * 0.24:
                    return True
                cls = window_class(hwnd).lower()
                style = int(user32.GetWindowLongPtrW(hwnd, -16))
                known = any(token in cls for token in (
                    "button", "toolbar", "link", "listview", "treeview", "tabcontrol",
                    "combobox", "scrollbar", "trackbar", "windowsforms10"))
                notified_static = "static" in cls and bool(style & 0x0100)
                tab_stop = bool(style & 0x00010000) and "edit" not in cls
                if not (known or notified_static or tab_stop):
                    return True
                label = unicodedata.normalize("NFKC", window_title(hwnd)).strip().lower()
                if any(word in label for word in dangerous_words):
                    return True
                score = 980.0 if any(word in label for word in positive_words) else 620.0
                if "button" in cls:
                    score += 55.0
                controls.append((score,
                                 ((left + right) * 0.5 - client[0]) / cw,
                                 ((top + bottom) * 0.5 - client[1]) / ch))
            except Exception:
                pass
            return True

        callback = callback_type(visit)
        try:
            user32.EnumChildWindows(self.target_hwnd, callback, 0)
        except Exception:
            return []
        controls.sort(reverse=True)
        return controls[:48]

    def _click_candidates(self, roi):
        if not roi:
            return []
        cr = client_rect(self.target_hwnd)
        if not cr or cr[2] - cr[0] < 80 or cr[3] - cr[1] < 80:
            return []
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"))
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
        except Exception:
            return []
        h, w = gray.shape
        if not h or not w:
            return []
        points = self._native_control_candidates(cr)
        memory_tight = _available_memory() < max(900 * 1024 ** 2, self.hardware.ram * 0.075)
        if memory_tight:
            rows, cols = 4, 6
        elif getattr(self.hardware, "runtime_class", "") == "极速":
            rows, cols = 10, 14
        elif self.hardware.tier == "high":
            rows, cols = 9, 13
        elif self.hardware.tier == "low":
            rows, cols = 4, 6
        else:
            rows, cols = 7, 10
        fgray = gray.astype("float32")

        # Region salience finds controls even when their borders are subtle.
        for row in range(rows):
            for col in range(cols):
                x1, x2 = col * w // cols, (col + 1) * w // cols
                y1, y2 = row * h // rows, (row + 1) * h // rows
                cell = fgray[y1:y2, x1:x2]
                if cell.size < 16:
                    continue
                edge = (self.np.abs(self.np.diff(cell, axis=0)).mean() +
                        self.np.abs(self.np.diff(cell, axis=1)).mean())
                contrast = float(cell.std())
                points.append((contrast * 0.62 + float(edge) * 1.38,
                               (x1 + x2) / 2 / w, (y1 + y2) / 2 / h))
        points.sort(reverse=True)
        candidates = points[:self.hardware.candidate_limit]

        # Contours target button/input/icon-shaped areas instead of blindly clicking a grid.
        try:
            if memory_tight:
                max_side = 560
            elif getattr(self.hardware, "runtime_class", "") == "极速":
                max_side = 1320
            else:
                max_side = 1180 if self.hardware.tier == "high" else (860 if self.hardware.tier == "balanced" else 680)
            scale = min(1.0, max_side / max(w, h))
            small = self.cv2.resize(gray, None, fx=scale, fy=scale,
                                    interpolation=self.cv2.INTER_AREA)
            blur = self.cv2.GaussianBlur(small, (3, 3), 0)
            median = float(self.np.median(blur))
            low = max(24, int(median * 0.45))
            high = min(220, max(low + 40, int(median * 1.25)))
            edges = self.cv2.Canny(blur, low, high)
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (3, 3))
            closed = self.cv2.morphologyEx(edges, self.cv2.MORPH_CLOSE, kernel)
            contours, _ = self.cv2.findContours(closed, self.cv2.RETR_LIST,
                                                 self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            sh, sw = small.shape
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = bw * bh
                if not (42 <= area <= sw * sh * 0.15 and bw >= 7 and bh >= 7):
                    continue
                aspect = bw / max(1.0, bh)
                if not (0.20 <= aspect <= 9.0):
                    continue
                rectangularity = self.cv2.contourArea(contour) / max(1.0, area)
                perimeter = self.cv2.arcLength(contour, True)
                compact = min(1.0, perimeter / max(1.0, 2.0 * (bw + bh)))
                border_score = min(1.2, rectangularity * 1.4 + compact * 0.35)
                score = border_score * 2.5 + min(2.2, math.log1p(area) / 3.8)
                boxes.append((score, (x + bw / 2) / sw, (y + bh / 2) / sh))
            boxes.sort(reverse=True)
            candidates.extend(boxes[:self.hardware.candidate_limit * 2])
        except Exception:
            pass

        # On capable machines, corner density adds icon-like controls that do not have a
        # clean rectangular outline. Corners are quantized later, keeping action count bounded.
        if self.hardware.tier != "low":
            try:
                corners = self.cv2.goodFeaturesToTrack(gray, maxCorners=self.hardware.candidate_limit * 3,
                                                       qualityLevel=0.035, minDistance=max(8, min(w, h) // 55))
                if corners is not None:
                    for pt in corners.reshape(-1, 2):
                        fx, fy = float(pt[0]) / w, float(pt[1]) / h
                        candidates.append((0.85, fx, fy))
            except Exception:
                pass

        # Spatial diversity plus a hardware-dependent coordinate grid gives high-end
        # systems more click precision while preserving old 20x20 learned actions.
        grid = int(self.hardware.mouse_grid)
        result, seen, coarse = [], set(), set()
        ranked_candidates = sorted(candidates, reverse=True)
        score_hi = float(ranked_candidates[0][0]) if ranked_candidates else 1.0
        score_lo = float(ranked_candidates[min(len(ranked_candidates) - 1, max(0, self.hardware.candidate_limit - 1))][0]) if ranked_candidates else 0.0
        span = max(1e-6, score_hi - score_lo)
        fresh_priors = {}
        for _score, fx, fy in ranked_candidates:
            qx = max(1, min(grid - 1, round(fx * grid)))
            qy = max(1, min(grid - 1, round(fy * grid)))
            x = cr[0] + qx / grid * (cr[2] - cr[0])
            y = cr[1] + qy / grid * (cr[3] - cr[1])
            if roi[0] - 20 <= x <= roi[2] + 20 and roi[1] - 20 <= y <= roi[3] + 20:
                continue
            action = f"mouse:{grid}:{qx}:{qy}"
            cell = (round(qx * 10 / grid), round(qy * 10 / grid))
            if action in seen or (cell in coarse and len(result) >= self.hardware.candidate_limit // 2):
                continue
            result.append(action)
            seen.add(action)
            coarse.add(cell)
            fresh_priors[action] = max(0.18, min(0.96, 0.18 + 0.78 * ((float(_score) - score_lo) / span)))
            if len(result) >= self.hardware.candidate_limit:
                break
        self.action_priors.update(fresh_priors)
        if len(self.action_priors) > 260:
            keep = set(result) | set(KEY_ACTION_PRIORS)
            trimmed = {k: v for k, v in self.action_priors.items() if k in keep}
            if len(trimmed) < 180:
                for k, v in list(self.action_priors.items())[-(180 - len(trimmed)):]:
                    trimmed.setdefault(k, v)
            self.action_priors = trimmed
        return result

    def _mouse_neighborhood(self, actions, radius=1, limit=18):
        """Refine successful normalized click locations without losing cross-resolution transfer."""
        out, seen = [], set()
        for action in actions:
            if not isinstance(action, str) or not action.startswith("mouse:"):
                continue
            try:
                parts = action.split(":")
                if len(parts) == 3:
                    grid, qx, qy = 20, int(parts[1]), int(parts[2])
                elif len(parts) == 4:
                    grid, qx, qy = int(parts[1]), int(parts[2]), int(parts[3])
                else:
                    continue
                grid = max(8, min(64, grid))
                parent_prior = float(self.action_priors.get(action, 0.50))
                for dy in range(-radius, radius + 1):
                    for dx in range(-radius, radius + 1):
                        if dx == 0 and dy == 0:
                            continue
                        x = max(1, min(grid - 1, qx + dx))
                        y = max(1, min(grid - 1, qy + dy))
                        candidate = f"mouse:{grid}:{x}:{y}"
                        if candidate not in seen:
                            seen.add(candidate)
                            out.append(candidate)
                            self.action_priors.setdefault(candidate, max(0.40, parent_prior * 0.92))
                            if len(out) >= limit:
                                return out
            except Exception:
                continue
        return out

    def _visual_signature(self, refresh=False):
        if not refresh and self._visual_cache and self._visual_cache != "v0":
            return self._visual_cache
        cr = client_rect(self.target_hwnd)
        if not cr:
            return self._visual_cache or "v0"
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8").copy()
            # Reward pixels are masked so changing the selected number does not itself
            # create a new environment identity.
            roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
            if roi:
                x1 = max(0, int(roi[0] - cr[0] - 7))
                y1 = max(0, int(roi[1] - cr[1] - 7))
                x2 = min(rgb.shape[1], int(roi[2] - cr[0] + 7))
                y2 = min(rgb.shape[0], int(roi[3] - cr[1] + 7))
                if x2 > x1 and y2 > y1:
                    fill = self.np.median(rgb.reshape(-1, 3), axis=0).astype("uint8")
                    rgb[y1:y2, x1:x2] = fill
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY).astype("float32")

            # 64-bit difference hash: unlike a cryptographic digest, Hamming-near values
            # remain visually similar. Learner._state_families uses hash bands as LSH.
            ph = self.cv2.resize(gray, (9, 8), interpolation=self.cv2.INTER_AREA)
            pbits = ph[:, 1:] >= ph[:, :-1]
            pvalue = 0
            for bit in pbits.reshape(-1):
                pvalue = (pvalue << 1) | int(bool(bit))

            # Independent 32-bit edge-layout hash separates screens with similar average
            # brightness but different control/menu geometry.
            sobelx = self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3)
            sobely = self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3)
            edge = self.cv2.magnitude(sobelx, sobely)
            eh = self.cv2.resize(edge, (9, 4), interpolation=self.cv2.INTER_AREA)
            ebits = eh[:, 1:] >= eh[:, :-1]
            evalue = 0
            for bit in ebits.reshape(-1):
                evalue = (evalue << 1) | int(bool(bit))

            tiny_rgb = self.cv2.resize(rgb, (4, 3), interpolation=self.cv2.INTER_AREA).astype("float32")
            colorfulness = float((tiny_rgb.max(axis=2) - tiny_rgb.min(axis=2)).mean())
            color_bucket = max(0, min(7, int(colorfulness / 18.0)))

            layout = self.cv2.resize(gray, (4, 3), interpolation=self.cv2.INTER_AREA)
            lm = float(layout.mean())
            layout_value = 0
            for bit in (layout >= lm).reshape(-1):
                layout_value = (layout_value << 1) | int(bool(bit))

            self._visual_cache = (f"p{pvalue:016x}e{evalue:08x}"
                                  f"c{color_bucket}l{layout_value:03x}")
        except Exception:
            pass
        return self._visual_cache or "v0"

    def _state_key(self, score, previous, stagnant, best, refresh_visual=False):
        visual = self._visual_signature(refresh_visual)
        threshold = max(1e-9, abs(previous) * 0.0005)
        delta = score - previous
        trend = "u" if delta > threshold else ("d" if delta < -threshold else "f")
        if best is None or score >= best:
            gap = 0
        else:
            relative_gap = (best - score) / max(1.0, abs(best) * 0.002)
            gap = max(1, min(5, int(math.log1p(max(0.0, relative_gap))) + 1))
        stale = min(6, stagnant // 7)
        magnitude = 0 if score == 0 else max(-6, min(15, int(math.floor(math.log10(abs(score))))))
        return f"{visual}:t{trend}:g{gap}:s{stale}:m{magnitude}"

    def _perform(self, action, quality):
        def perform_atomic(item, allow_repeat=True):
            repeatable = item in KEY_ACTIONS or item.startswith("mouse:")
            repeats = (2 if allow_repeat and repeatable and quality > 1.35 else 1)
            for _ in range(repeats):
                if self.stop_event.is_set():
                    return
                if item == OBSERVE_ACTION:
                    pass
                elif item in KEY_ACTIONS:
                    duration = 0.058
                    if quality > 0.35:
                        duration = 0.090
                    if quality > 1.15:
                        duration = 0.128
                    tap_key(KEY_ACTIONS[item], duration)
                elif item.startswith("hold:"):
                    try:
                        _kind, name, milliseconds = item.split(":")
                        vk = KEY_NAME_TO_VK.get(name)
                        if vk is None:
                            return
                        duration = max(0.08, min(0.90, int(milliseconds) / 1000.0))
                        if quality > 0.65:
                            duration = min(1.0, duration * 1.10)
                        press_keys((vk,), duration, self.stop_event)
                    except Exception:
                        return
                elif item.startswith("chord:"):
                    try:
                        names = item.split(":", 1)[1].split("+")
                        vks = [KEY_NAME_TO_VK[name] for name in names
                               if name in KEY_NAME_TO_VK]
                        if len(vks) != len(names) or len(vks) < 2:
                            return
                        duration = 0.115 if quality <= 0.35 else (
                            0.175 if quality <= 1.05 else 0.235)
                        press_keys(vks, duration, self.stop_event)
                    except Exception:
                        return
                elif item.startswith("mouse:"):
                    try:
                        parts = item.split(":")
                        if len(parts) == 3:  # backward-compatible learned action
                            grid, sx, sy = 20, parts[1], parts[2]
                        elif len(parts) == 4:
                            grid, sx, sy = int(parts[1]), parts[2], parts[3]
                        else:
                            return
                        grid = max(8, min(64, int(grid)))
                        cr = client_rect(self.target_hwnd)
                        if not cr:
                            return
                        x = cr[0] + int(sx) / grid * (cr[2] - cr[0])
                        y = cr[1] + int(sy) / grid * (cr[3] - cr[1])
                        roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
                        if roi and not (roi[0] - 15 <= x <= roi[2] + 15 and
                                        roi[1] - 15 <= y <= roi[3] + 15):
                            click_point(x, y)
                    except Exception:
                        return
                if repeats > 1:
                    time.sleep(0.055)

        if action.startswith("macro:"):
            parts = Learner._macro_parts(action)
            for index, item in enumerate(parts):
                if self.stop_event.is_set() or not self._target_ready():
                    break
                perform_atomic(item, allow_repeat=False)
                if index + 1 < len(parts):
                    pause = 0.045 if self.hardware.tier == "high" else 0.075
                    end = time.monotonic() + pause
                    while time.monotonic() < end and not self.stop_event.is_set():
                        time.sleep(0.012)
            return
        perform_atomic(action, allow_repeat=True)

    def _read_current(self, verify_low_confidence=True, expected=None):
        roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
        if not roi:
            return None, 0.0
        value, confidence, _text = self.reader.read(roi, expected=expected)
        min_conf = 0.28 if self.hardware.verify_reads else 0.34
        if value is None or confidence < min_conf:
            return None, confidence

        catastrophic = False
        suspicious = False
        if expected is not None:
            scale = max(1.0, abs(expected))
            ratio = abs(value - expected) / scale
            catastrophic = ratio > 100000
            # High-confidence OCR can still hallucinate a dropped digit or suffix. Verify
            # unusually large transitions before they become reinforcement-learning truth.
            suspicious = ratio > 24 or (expected > 0 and value >= 0 and value < expected * 0.08)
        should_verify = (verify_low_confidence and self.hardware.verify_reads and
                         (confidence < 0.72 or catastrophic or suspicious) and
                         not self.stop_event.is_set())
        if should_verify:
            reads = [(value, confidence)]
            extra = self.hardware.verify_reads + (1 if catastrophic or suspicious else 0)
            for _ in range(extra):
                value2, confidence2, _text2 = self.reader.read(roi, expected=expected)
                if value2 is not None and confidence2 >= min_conf:
                    reads.append((value2, confidence2))
                if self.stop_event.is_set():
                    break
                if confidence2 >= 0.90 and any(
                        ScoreReader._same_value(value2, v) for v, _c in reads[:-1]):
                    break
            ranked = []
            for candidate, conf in reads:
                support = [c for v, c in reads if ScoreReader._same_value(v, candidate)]
                ranked.append((sum(support) + 0.12 * len(support), max(support),
                               len(support), candidate))
            ranked.sort(reverse=True)
            _weight, best_conf, support, best_value = ranked[0]
            if expected is not None and support == 1:
                scale = max(1.0, abs(expected))
                if abs(best_value - expected) > scale * 100000 and best_conf < 0.94:
                    return None, best_conf
            value = best_value
            confidence = min(0.997, best_conf + 0.065 * max(0, support - 1))
        return value, confidence

    def _adaptive_wait(self, quality=0.0, delay_hint=0.0):
        base = self.hardware.settle
        latency = self.reader.latency if self.reader else 0.25
        capture = self.capture.latency if self.capture else 0.02
        delay = base + min(0.34, latency * 0.34 + capture * 0.45) + max(0.0, min(0.34, delay_hint))
        if quality > 0.9:
            delay += 0.045
        floor = 0.18 if self.hardware.tier == "high" else 0.22
        end = time.monotonic() + max(floor, min(1.12, delay))
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(0.022)

    def _run_ai(self):
        learner = Learner(self._profile_file())
        last_save = time.monotonic()
        reason = "用户按下 ESC，AI 已关闭"
        try:
            time.sleep(0.60)
            if not self._target_ready():
                reason = "目标窗口未处于前台，AI 已安全停止"
                return
            score, score_conf = self._read_current()
            if score is None:
                reason = "无法读取所选数值，AI 已停止"
                return
            if learner.best is None:
                learner.best = score
            stagnant = 0
            click_actions = []
            failures = 0
            previous_score = score
            state = self._state_key(score, score, stagnant, learner.best, True)
            # One no-input observation estimates natural score drift and prevents the learner
            # from crediting random actions for changes that would have happened anyway.
            if not self.stop_event.is_set():
                end = time.monotonic() + max(0.16, min(0.38, self.hardware.settle * 0.70))
                while time.monotonic() < end and not self.stop_event.is_set():
                    time.sleep(0.020)
                passive_score, passive_conf = self._read_current(False, expected=score)
                if passive_score is not None and passive_conf >= 0.50:
                    passive_reliability = math.sqrt(max(0.0, score_conf) * max(0.0, passive_conf))
                    learner.observe_passive(score, passive_score, state, passive_reliability)
                    previous_score, score, score_conf = score, passive_score, passive_conf
                    if learner.best is None or score > learner.best:
                        learner.best = score
            loop_count = 0
            failure_window = []
            while not self.stop_event.is_set():
                loop_count += 1
                if not self._target_ready():
                    reason = "目标窗口失去前台焦点，AI 已安全停止"
                    break
                roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
                refresh_every = self.hardware.candidate_refresh
                if stagnant > 18:
                    refresh_every = max(3, refresh_every // 3)
                if (learner.steps % refresh_every == 0 or not click_actions):
                    discovered = self._click_candidates(roi)
                    remembered = learner.preferred_actions("mouse:",
                                                           limit=12 if self.hardware.tier == "high" else 8)
                    refine_limit = 22 if self.hardware.tier == "high" else (14 if self.hardware.tier == "balanced" else 6)
                    refine_radius = 2 if stagnant > 26 and self.hardware.tier != "low" else 1
                    refined = self._mouse_neighborhood(remembered, radius=refine_radius, limit=refine_limit)
                    click_actions = list(dict.fromkeys(remembered + refined + discovered))
                    click_actions = click_actions[:max(10, self.hardware.candidate_limit)]
                # Hierarchical action curriculum: try common controls first, but always
                # keep proven keys from earlier sessions. Broaden only when progress stalls.
                remembered_keys = learner.preferred_actions("key:", limit=10)
                remembered_extended = (
                    learner.preferred_actions("hold:", limit=8) +
                    learner.preferred_actions("chord:", limit=6))
                if stagnant < 11 and learner.steps < 90:
                    key_actions = list(dict.fromkeys(
                        remembered_keys + remembered_extended + list(CORE_KEY_ACTIONS)))
                elif stagnant < 27:
                    extended = list(HOLD_KEY_ACTIONS[:8]) if stagnant >= 14 else []
                    key_actions = list(dict.fromkeys(
                        remembered_keys + remembered_extended + list(CORE_KEY_ACTIONS) +
                        list(SECONDARY_KEY_ACTIONS) + extended))
                else:
                    key_actions = list(dict.fromkeys(
                        remembered_keys + remembered_extended + list(KEY_ACTIONS) +
                        list(HOLD_KEY_ACTIONS) + list(CHORD_KEY_ACTIONS)))
                actions = list(dict.fromkeys(key_actions + click_actions + [OBSERVE_ACTION]))
                # After enough evidence, temporarily suppress globally destructive actions.
                # They can re-enter during heavy stagnation so the AI can still adapt if
                # the interface changes later.
                if stagnant < 36:
                    filtered = []
                    for candidate in actions:
                        q, n, _v = learner._value(learner.stats.get(candidate, {}))
                        stat = learner.stats.get(candidate, {})
                        bad = int(stat.get("bad", 0))
                        good = int(stat.get("good", 0))
                        zero = int(stat.get("zero", 0))
                        if n >= 10 and q < -0.45 and bad > good * 2 + 3:
                            continue
                        if n >= 14 and zero / max(1, n) > 0.86 and q <= 0.01:
                            continue
                        filtered.append(candidate)
                    if filtered:
                        actions = filtered
                refresh_state = learner.steps % self.hardware.state_every == 0
                state = self._state_key(score, previous_score, stagnant, learner.best,
                                        refresh_visual=refresh_state)
                actions = learner.expand_actions(actions, state, stagnant,
                                                 limit=self.hardware.macro_limit)
                # Re-sample the no-input baseline throughout long runs so causal credit
                # stays correct when timers, idle income or game rules change.
                passive_interval = 22 if self.hardware.tier == "high" else (
                    28 if self.hardware.tier == "balanced" else 36)
                scheduled_observation = (loop_count > 2 and
                                         loop_count % passive_interval == 0 and
                                         stagnant < 42)
                action = (OBSERVE_ACTION if scheduled_observation else
                          learner.choose(actions, state, stagnant, priors=self.action_priors))
                if not action:
                    reason = "没有可用操作，AI 已停止"
                    break
                before = score
                quality = learner.action_quality(action, state)
                delay_hint = learner.delay_hint(action)
                self._perform(action, quality)
                self._adaptive_wait(quality, delay_hint)
                if self.stop_event.is_set():
                    break
                new_score, new_conf = self._read_current(expected=before)
                if new_score is None:
                    failures += 1
                    failure_window.append(1)
                    if len(failure_window) > 24:
                        failure_window = failure_window[-24:]
                    if failures == 3:
                        try:
                            live_roi = current_roi(self.target_hwnd, self.relative_roi,
                                                   self.normalized_roi)
                            self.capture.benchmark(live_roi)
                            self.hardware.capture_backend = self.capture.backend
                            self.hardware.save_tuning()
                        except Exception:
                            pass
                    if failures >= (8 if self.hardware.tier != "low" else 6):
                        reason = "连续无法读取所选数值，AI 已停止"
                        break
                    score = before
                    previous_score = before
                    continue
                failures = 0
                failure_window.append(0)
                if len(failure_window) > 24:
                    failure_window = failure_window[-24:]
                delayed_effect = False

                # Some interfaces apply an input with a short delay. On faster machines,
                # a second observation avoids incorrectly teaching the AI that it did nothing.
                tiny = max(1e-9, abs(before) * 1e-10)
                if (abs(new_score - before) <= tiny and self.hardware.tier != "low" and
                        not self.stop_event.is_set()):
                    end = time.monotonic() + min(0.36, 0.12 + self.reader.latency * 0.30)
                    while time.monotonic() < end and not self.stop_event.is_set():
                        time.sleep(0.025)
                    if not self.stop_event.is_set():
                        delayed, delayed_conf = self._read_current(False, expected=before)
                        if delayed is not None and (delayed != before or delayed_conf > new_conf):
                            delayed_effect = abs(delayed - before) > tiny and abs(new_score - before) <= tiny
                            new_score, new_conf = delayed, delayed_conf
                learner.record_delay(action, delayed_effect)

                # Confirm early wins before reinforcing them. Animated counters and OCR
                # transitions can otherwise teach a highly confident but false rule.
                if new_score > before and not self.stop_event.is_set():
                    _q, action_samples, _variance = learner._value(
                        learner.stats.get(action, {}))
                    relative_gain = (new_score - before) / max(1.0, abs(before))
                    needs_confirmation = (action_samples < 5 or new_conf < 0.90 or
                                          relative_gain > 0.30)
                    if needs_confirmation:
                        end = time.monotonic() + min(0.18, 0.045 + self.reader.latency * 0.16)
                        while time.monotonic() < end and not self.stop_event.is_set():
                            time.sleep(0.018)
                        confirmed, confirmed_conf = self._read_current(
                            False, expected=new_score)
                        if confirmed is not None:
                            # Be conservative when the counter keeps rising naturally:
                            # credit only the persistent portion seen in both frames.
                            if confirmed > before:
                                new_score = min(new_score, confirmed)
                            else:
                                new_score = confirmed
                            new_conf = math.sqrt(max(0.0, new_conf) *
                                                 max(0.0, confirmed_conf))
                        else:
                            new_conf *= 0.72

                next_stagnant = 0 if new_score > before else stagnant + (2 if new_score < before else 1)
                next_state = self._state_key(
                    new_score, before, next_stagnant, learner.best,
                    refresh_visual=((learner.steps + 1) % self.hardware.state_every == 0))
                observation_conf = math.sqrt(max(0.0, score_conf) * max(0.0, new_conf))
                delta, reward = learner.learn(
                    action, before, new_score, state, next_state,
                    confidence=observation_conf, actions=actions)
                previous_score, score, score_conf = before, new_score, new_conf
                stagnant = 0 if delta > 0 else next_stagnant

                if delta > 0:
                    hot = [p for p in Learner._macro_parts(action) if p.startswith("mouse:")]
                    if hot:
                        local = self._mouse_neighborhood(hot, radius=1,
                                                         limit=12 if self.hardware.tier != "low" else 5)
                        click_actions = list(dict.fromkeys(hot + local + click_actions))
                        click_actions = click_actions[:max(10, self.hardware.candidate_limit)]

                if loop_count % 16 == 0:
                    fail_rate = sum(failure_window) / max(1, len(failure_window))
                    self.hardware.live_tune(self.reader.latency, self.capture.latency,
                                            self.reader.confidence_ema, fail_rate)
                    self.reader.latency_target = self.hardware.latency_target
                    target_variants = max(self.reader.min_variants,
                                          min(self.reader.max_variants, self.hardware.ocr_variants))
                    if abs(self.reader.active_variants - target_variants) > 1:
                        self.reader.active_variants += 1 if target_variants > self.reader.active_variants else -1

                if time.monotonic() - last_save > self.hardware.save_interval:
                    try:
                        learner.save()
                    except OSError:
                        pass
                    last_save = time.monotonic()
            if self.stop_event.is_set():
                reason = "用户按下 ESC，AI 已关闭"
        except Exception as exc:
            reason = f"AI 因错误停止：{exc}"
        finally:
            try:
                learner.save()
            except Exception:
                pass
            if self.hook:
                self.hook.close()
            summary = (f"{reason}\n当前数值：{score:g}　最高数值：{learner.best:g}　"
                       f"累计学习：{learner.steps} 步　有效提升：{learner.positive} 次") \
                if 'score' in locals() and score is not None else reason
            self.events.put(("stopped", summary))

    def _poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "runtime_ready":
                    self.progress.stop()
                    self.progress.configure(mode="determinate", value=100)
                    if self.data_dir:
                        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{event[1]}")
                    self.status_var.set("准备完成。点击“数值”并框选屏幕上的数字。")
                    self.value_button.configure(state="normal")
                elif kind == "selection":
                    value, _confidence, _text = event[1:]
                    self.root.deiconify()
                    self.root.lift()
                    if value is None:
                        self.selection_var.set("未识别到数值，请重新框选")
                        self.status_var.set("框选范围应只包含数字，并留少量边距。")
                        self.confirm_button.configure(state="disabled")
                    else:
                        shown_title = (self.target_title if len(self.target_title) <= 34
                                       else self.target_title[:33] + "…")
                        self.selection_var.set(f"已选择：{value:g}　目标窗口：{shown_title}")
                        self.status_var.set("点击“确认”后 AI 自动开始；按 ESC 停止。")
                        self.confirm_button.configure(state="normal")
                elif kind == "stopped":
                    self.last_summary = event[1]
                    self.root.deiconify()
                    self.root.lift()
                    self.status_var.set(self.last_summary)
                    self.value_button.configure(state="normal")
                    self.confirm_button.configure(state="normal")
                elif kind == "error":
                    self.progress.stop()
                    self.status_var.set(event[1])
                    messagebox.showerror(event[1], event[2], parent=self.root)
        except queue.Empty:
            pass
        if self.root.winfo_exists():
            self.root.after(100, self._poll)

    def _close(self):
        self.stop_event.set()
        if self.hook:
            self.hook.close()
        self.root.destroy()


def main():
    if os.name != "nt" or sys.maxsize <= 2 ** 32:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "本程序仅支持 64 位 Windows 11。")
        root.destroy()
        return
    set_dpi_awareness()
    configure_winapi()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    ValueAI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
