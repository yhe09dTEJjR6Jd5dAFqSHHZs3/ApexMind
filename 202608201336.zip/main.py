import sys

sys.dont_write_bytecode = True

import ctypes
from ctypes import wintypes
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import threading
import time


CAPTURE_W = 128
CAPTURE_H = 96
GRID_W = 8
GRID_H = 6
ACTION_COUNT = GRID_W * GRID_H
FEATURE_COUNT = 10
MAX_REPLAY = 720
MIN_SLEEP_EXPERIENCE = 6
MAX_WAKE_EXPERIENCE = 18
PROVISIONAL_TRIALS = 6
STATE_FILE = "agent_state.json"
STATE_BACKUP_FILE = "agent_state.backup.json"
STATE_VERSION = 3


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class RGBQUAD(ctypes.Structure):
    _fields_ = [
        ("rgbBlue", ctypes.c_ubyte),
        ("rgbGreen", ctypes.c_ubyte),
        ("rgbRed", ctypes.c_ubyte),
        ("rgbReserved", ctypes.c_ubyte),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", RGBQUAD * 1)]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", wintypes.POINT),
        ("lPrivate", wintypes.DWORD),
    ]


def enable_dpi_awareness():
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        return
    except Exception:
        pass
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
        return
    except Exception:
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass


class WinAPI:
    def __init__(self):
        self.user32 = ctypes.windll.user32
        self.gdi32 = ctypes.windll.gdi32
        self.kernel32 = ctypes.windll.kernel32
        self.dwmapi = getattr(ctypes.windll, "dwmapi", None)
        self.EnumProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        self._capture = None
        self._bind()

    def _bind(self):
        u = self.user32
        g = self.gdi32
        k = self.kernel32
        u.EnumWindows.argtypes = [self.EnumProc, wintypes.LPARAM]
        u.EnumWindows.restype = wintypes.BOOL
        u.IsWindow.argtypes = [wintypes.HWND]
        u.IsWindow.restype = wintypes.BOOL
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.IsWindowVisible.restype = wintypes.BOOL
        u.IsIconic.argtypes = [wintypes.HWND]
        u.IsIconic.restype = wintypes.BOOL
        u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        u.ShowWindow.restype = wintypes.BOOL
        u.SetForegroundWindow.argtypes = [wintypes.HWND]
        u.SetForegroundWindow.restype = wintypes.BOOL
        u.GetForegroundWindow.restype = wintypes.HWND
        u.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        u.GetAncestor.restype = wintypes.HWND
        u.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        u.GetWindowTextLengthW.restype = ctypes.c_int
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextW.restype = ctypes.c_int
        u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetClassNameW.restype = ctypes.c_int
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        u.GetWindowThreadProcessId.restype = wintypes.DWORD
        u.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        u.GetClientRect.restype = wintypes.BOOL
        u.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
        u.ClientToScreen.restype = wintypes.BOOL
        u.ChildWindowFromPointEx.argtypes = [wintypes.HWND, wintypes.POINT, wintypes.UINT]
        u.ChildWindowFromPointEx.restype = wintypes.HWND
        u.MapWindowPoints.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.POINTER(wintypes.POINT), wintypes.UINT]
        u.MapWindowPoints.restype = ctypes.c_int
        u.SendMessageTimeoutW.argtypes = [
            wintypes.HWND,
            wintypes.UINT,
            wintypes.WPARAM,
            wintypes.LPARAM,
            wintypes.UINT,
            wintypes.UINT,
            ctypes.POINTER(ctypes.c_size_t),
        ]
        u.SendMessageTimeoutW.restype = ctypes.c_ssize_t
        u.PrintWindow.argtypes = [wintypes.HWND, wintypes.HDC, wintypes.UINT]
        u.PrintWindow.restype = wintypes.BOOL
        u.GetAsyncKeyState.argtypes = [ctypes.c_int]
        u.GetAsyncKeyState.restype = wintypes.SHORT
        u.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p, wintypes.HINSTANCE, wintypes.DWORD]
        u.SetWindowsHookExW.restype = wintypes.HHOOK
        u.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
        u.CallNextHookEx.restype = ctypes.c_ssize_t
        u.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
        u.UnhookWindowsHookEx.restype = wintypes.BOOL
        u.PeekMessageW.argtypes = [ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
        u.PeekMessageW.restype = wintypes.BOOL
        u.TranslateMessage.argtypes = [ctypes.POINTER(MSG)]
        u.TranslateMessage.restype = wintypes.BOOL
        u.DispatchMessageW.argtypes = [ctypes.POINTER(MSG)]
        u.DispatchMessageW.restype = ctypes.c_ssize_t
        u.SetPropW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.HANDLE]
        u.SetPropW.restype = wintypes.BOOL
        u.GetPropW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
        u.GetPropW.restype = wintypes.HANDLE
        u.RemovePropW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
        u.RemovePropW.restype = wintypes.HANDLE
        u.GetDC.argtypes = [wintypes.HWND]
        u.GetDC.restype = wintypes.HDC
        u.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        u.ReleaseDC.restype = ctypes.c_int
        g.CreateCompatibleDC.argtypes = [wintypes.HDC]
        g.CreateCompatibleDC.restype = wintypes.HDC
        g.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        g.CreateCompatibleBitmap.restype = wintypes.HBITMAP
        g.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
        g.SelectObject.restype = wintypes.HGDIOBJ
        g.DeleteObject.argtypes = [wintypes.HGDIOBJ]
        g.DeleteObject.restype = wintypes.BOOL
        g.DeleteDC.argtypes = [wintypes.HDC]
        g.DeleteDC.restype = wintypes.BOOL
        g.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        g.SetStretchBltMode.restype = ctypes.c_int
        g.StretchBlt.argtypes = [
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.HDC,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.DWORD,
        ]
        g.StretchBlt.restype = wintypes.BOOL
        g.GetDIBits.argtypes = [
            wintypes.HDC,
            wintypes.HBITMAP,
            wintypes.UINT,
            wintypes.UINT,
            wintypes.LPVOID,
            ctypes.POINTER(BITMAPINFO),
            wintypes.UINT,
        ]
        g.GetDIBits.restype = ctypes.c_int
        k.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
        k.GetModuleHandleW.restype = wintypes.HMODULE
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.OpenProcess.restype = wintypes.HANDLE
        k.QueryFullProcessImageNameW.argtypes = [
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPWSTR,
            ctypes.POINTER(wintypes.DWORD),
        ]
        k.QueryFullProcessImageNameW.restype = wintypes.BOOL
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.CloseHandle.restype = wintypes.BOOL
        if self.dwmapi is not None:
            self.dwmapi.DwmGetWindowAttribute.argtypes = [
                wintypes.HWND,
                wintypes.DWORD,
                wintypes.LPVOID,
                wintypes.DWORD,
            ]
            self.dwmapi.DwmGetWindowAttribute.restype = ctypes.c_long

    @staticmethod
    def _handle_value(handle):
        if isinstance(handle, int):
            return handle
        return int(getattr(handle, "value", 0) or 0)

    def _title(self, hwnd):
        length = self.user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(length + 1)
        self.user32.GetWindowTextW(hwnd, buf, len(buf))
        return buf.value.strip()

    def _class_name(self, hwnd):
        buf = ctypes.create_unicode_buffer(256)
        self.user32.GetClassNameW(hwnd, buf, len(buf))
        return buf.value

    def _process_path(self, hwnd):
        pid = wintypes.DWORD()
        thread_id = int(self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid)))
        handle = self.kernel32.OpenProcess(0x1000, False, pid.value)
        if not handle:
            return "", pid.value, thread_id
        try:
            buf = ctypes.create_unicode_buffer(32768)
            size = wintypes.DWORD(len(buf))
            if self.kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                return buf.value, pid.value, thread_id
            return "", pid.value, thread_id
        finally:
            self.kernel32.CloseHandle(handle)

    def _is_cloaked(self, hwnd):
        if self.dwmapi is None:
            return False
        cloaked = wintypes.DWORD()
        result = self.dwmapi.DwmGetWindowAttribute(
            hwnd, 14, ctypes.byref(cloaked), ctypes.sizeof(cloaked)
        )
        return result == 0 and cloaked.value != 0

    def client_box(self, hwnd):
        if not self.user32.IsWindow(hwnd):
            return None
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(hwnd, ctypes.byref(rect)):
            return None
        p1 = wintypes.POINT(rect.left, rect.top)
        p2 = wintypes.POINT(rect.right, rect.bottom)
        if not self.user32.ClientToScreen(hwnd, ctypes.byref(p1)):
            return None
        if not self.user32.ClientToScreen(hwnd, ctypes.byref(p2)):
            return None
        if p2.x - p1.x < 40 or p2.y - p1.y < 40:
            return None
        return p1.x, p1.y, p2.x, p2.y

    def list_windows(self):
        own_pid = os.getpid()
        rows = []

        def visit(hwnd, _):
            try:
                if not self.user32.IsWindowVisible(hwnd) or self._is_cloaked(hwnd):
                    return True
                title = self._title(hwnd)
                if not title:
                    return True
                box = self.client_box(hwnd)
                if box is None:
                    return True
                process_path, pid, thread_id = self._process_path(hwnd)
                if pid == own_pid:
                    return True
                app = os.path.basename(process_path) if process_path else self._class_name(hwnd)
                rows.append(
                    {
                        "hwnd": self._handle_value(hwnd),
                        "title": title,
                        "app": app or "未知应用",
                        "process_path": process_path,
                        "class_name": self._class_name(hwnd),
                        "pid": pid,
                        "thread_id": thread_id,
                        "size": f"{box[2] - box[0]}×{box[3] - box[1]}",
                    }
                )
            except Exception:
                pass
            return True

        callback = self.EnumProc(visit)
        self.user32.EnumWindows(callback, 0)
        rows.sort(key=lambda row: (row["app"].lower(), row["title"].lower()))
        return rows

    def startup_target_matches(self, target):
        if not self.target_matches(target):
            return False
        expected = normalized_title(target.get("title", ""))
        current = normalized_title(self._title(target["hwnd"]))
        return not expected or not current or expected == current

    def attach_target_guard(self, target):
        hwnd = target["hwnd"]
        if not self.target_matches(target):
            return False
        name = f"SleepMouseAI_{os.getpid()}_{time.time_ns()}_{random.getrandbits(32):08x}"
        value = (time.time_ns() ^ random.getrandbits(62) ^ os.getpid()) & ((1 << 62) - 1)
        value = value or 1
        try:
            if self.user32.SetPropW(hwnd, name, ctypes.c_void_p(value)):
                target["guard_name"] = name
                target["guard_value"] = value
                return True
        except Exception:
            pass
        target["guard_name"] = ""
        target["guard_value"] = 0
        return False

    def detach_target_guard(self, target):
        name = target.get("guard_name")
        if not name:
            return
        try:
            if self.user32.IsWindow(target["hwnd"]):
                self.user32.RemovePropW(target["hwnd"], name)
        except Exception:
            pass

    def target_matches(self, target):
        hwnd = target["hwnd"]
        if not self.user32.IsWindow(hwnd) or not self.user32.IsWindowVisible(hwnd):
            return False
        if self.client_box(hwnd) is None:
            return False
        try:
            path, pid, thread_id = self._process_path(hwnd)
            if pid != int(target.get("pid", -1)):
                return False
            if thread_id != int(target.get("thread_id", -1)):
                return False
            if self._class_name(hwnd) != target.get("class_name", ""):
                return False
            expected_path = target.get("process_path", "")
            if expected_path and path and os.path.normcase(path) != os.path.normcase(expected_path):
                return False
            guard_name = target.get("guard_name")
            if guard_name:
                current = self._handle_value(self.user32.GetPropW(hwnd, guard_name))
                if current != int(target.get("guard_value", 0)):
                    return False
            return True
        except Exception:
            return False

    def _root_of(self, hwnd):
        root = self.user32.GetAncestor(hwnd, 2)
        return self._handle_value(root) or self._handle_value(hwnd)

    def foreground_is_target(self, target):
        foreground = self.user32.GetForegroundWindow()
        return self._root_of(foreground) == self._handle_value(target["hwnd"])

    def focus_window(self, target, stop_event=None):
        hwnd = target["hwnd"]
        if not self.target_matches(target):
            return False
        if self.user32.IsIconic(hwnd):
            self.user32.ShowWindow(hwnd, 9)
        self.user32.SetForegroundWindow(hwnd)
        deadline = time.monotonic() + 0.55
        while time.monotonic() < deadline:
            if stop_event is not None and stop_event.is_set():
                return False
            if not self.target_matches(target):
                return False
            if self.foreground_is_target(target):
                return True
            time.sleep(0.025)
        return False

    def _client_point_is_safe(self, target, x, y):
        if not self.target_matches(target) or not self.foreground_is_target(target):
            return False
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(target["hwnd"], ctypes.byref(rect)):
            return False
        return 0 <= x < rect.right - rect.left and 0 <= y < rect.bottom - rect.top

    def _message_target(self, target, x, y):
        root = self._handle_value(target["hwnd"])
        current = root
        for _ in range(12):
            point = wintypes.POINT(x, y)
            if current != root:
                self.user32.MapWindowPoints(root, current, ctypes.byref(point), 1)
            child = self.user32.ChildWindowFromPointEx(current, point, 0x0007)
            child_value = self._handle_value(child)
            if not child_value or child_value == current:
                break
            if self._root_of(child_value) != root:
                break
            current = child_value
        point = wintypes.POINT(x, y)
        if current != root:
            self.user32.MapWindowPoints(root, current, ctypes.byref(point), 1)
        if not (-32768 <= point.x <= 32767 and -32768 <= point.y <= 32767):
            return None
        return current, point.x, point.y

    def _send_mouse_message(self, hwnd, message, w_param, x, y):
        packed = ((y & 0xFFFF) << 16) | (x & 0xFFFF)
        result = ctypes.c_size_t()
        try:
            return bool(
                self.user32.SendMessageTimeoutW(
                    hwnd, message, w_param, packed, 0x0002, 120, ctypes.byref(result)
                )
            )
        except Exception:
            return False

    def click_client(self, target, nx, ny, stop_event):
        if stop_event.is_set() or not self.focus_window(target, stop_event):
            return False
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(target["hwnd"], ctypes.byref(rect)):
            return False
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width < 4 or height < 4:
            return False
        x = min(width - 2, max(1, int(width * min(0.985, max(0.015, nx)))))
        y = min(height - 2, max(1, int(height * min(0.985, max(0.015, ny)))))
        if not self._client_point_is_safe(target, x, y):
            return False
        destination = self._message_target(target, x, y)
        if destination is None:
            return False
        hwnd, child_x, child_y = destination
        if not self._send_mouse_message(hwnd, 0x0200, 0, child_x, child_y):
            return False
        if stop_event.is_set() or not self._client_point_is_safe(target, x, y):
            return False
        if not self._send_mouse_message(hwnd, 0x0201, 0x0001, child_x, child_y):
            return False
        if stop_event.wait(0.035):
            if self.target_matches(target) and self._root_of(hwnd) == self._handle_value(target["hwnd"]):
                self._send_mouse_message(hwnd, 0x0202, 0, child_x, child_y)
            return False
        if not self._client_point_is_safe(target, x, y):
            if self.target_matches(target) and self._root_of(hwnd) == self._handle_value(target["hwnd"]):
                self._send_mouse_message(hwnd, 0x0202, 0, child_x, child_y)
            return False
        if self._root_of(hwnd) != self._handle_value(target["hwnd"]):
            return False
        return self._send_mouse_message(hwnd, 0x0202, 0, child_x, child_y)

    def release_capture_buffer(self):
        capture = self._capture
        self._capture = None
        if not capture:
            return
        try:
            if capture.get("source_old") and capture.get("source_dc"):
                self.gdi32.SelectObject(capture["source_dc"], capture["source_old"])
            if capture.get("output_old") and capture.get("output_dc"):
                self.gdi32.SelectObject(capture["output_dc"], capture["output_old"])
        except Exception:
            pass
        for key in ("source_bitmap", "output_bitmap"):
            handle = capture.get(key)
            if handle:
                self.gdi32.DeleteObject(handle)
        for key in ("source_dc", "output_dc"):
            handle = capture.get(key)
            if handle:
                self.gdi32.DeleteDC(handle)

    def _ensure_capture_buffer(self, width, height):
        capture = self._capture
        if capture and capture["width"] == width and capture["height"] == height:
            return capture
        self.release_capture_buffer()
        reference_dc = self.user32.GetDC(0)
        if not reference_dc:
            return None
        source_dc = output_dc = source_bitmap = output_bitmap = None
        source_old = output_old = None
        try:
            source_dc = self.gdi32.CreateCompatibleDC(reference_dc)
            output_dc = self.gdi32.CreateCompatibleDC(reference_dc)
            if not source_dc or not output_dc:
                return None
            source_bitmap = self.gdi32.CreateCompatibleBitmap(reference_dc, width, height)
            output_bitmap = self.gdi32.CreateCompatibleBitmap(reference_dc, CAPTURE_W, CAPTURE_H)
            if not source_bitmap or not output_bitmap:
                return None
            source_old = self.gdi32.SelectObject(source_dc, source_bitmap)
            output_old = self.gdi32.SelectObject(output_dc, output_bitmap)
            self.gdi32.SetStretchBltMode(output_dc, 4)
            info = BITMAPINFO()
            info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            info.bmiHeader.biWidth = CAPTURE_W
            info.bmiHeader.biHeight = -CAPTURE_H
            info.bmiHeader.biPlanes = 1
            info.bmiHeader.biBitCount = 32
            info.bmiHeader.biCompression = 0
            info.bmiHeader.biSizeImage = CAPTURE_W * CAPTURE_H * 4
            capture = {
                "width": width,
                "height": height,
                "source_dc": source_dc,
                "output_dc": output_dc,
                "source_bitmap": source_bitmap,
                "output_bitmap": output_bitmap,
                "source_old": source_old,
                "output_old": output_old,
                "pixels": (ctypes.c_ubyte * (CAPTURE_W * CAPTURE_H * 4))(),
                "info": info,
            }
            self._capture = capture
            return capture
        finally:
            self.user32.ReleaseDC(0, reference_dc)
            if self._capture is None:
                if source_old and source_dc:
                    self.gdi32.SelectObject(source_dc, source_old)
                if output_old and output_dc:
                    self.gdi32.SelectObject(output_dc, output_old)
                if source_bitmap:
                    self.gdi32.DeleteObject(source_bitmap)
                if output_bitmap:
                    self.gdi32.DeleteObject(output_bitmap)
                if source_dc:
                    self.gdi32.DeleteDC(source_dc)
                if output_dc:
                    self.gdi32.DeleteDC(output_dc)

    def capture_client(self, target):
        if not self.target_matches(target):
            return None
        rect = wintypes.RECT()
        if not self.user32.GetClientRect(target["hwnd"], ctypes.byref(rect)):
            return None
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width < 40 or height < 40:
            return None
        capture = self._ensure_capture_buffer(width, height)
        if capture is None:
            return None
        rendered = False
        try:
            rendered = bool(self.user32.PrintWindow(target["hwnd"], capture["source_dc"], 0x00000003))
            if not rendered:
                rendered = bool(self.user32.PrintWindow(target["hwnd"], capture["source_dc"], 0x00000001))
        except Exception:
            rendered = False
        if rendered:
            copied = self.gdi32.StretchBlt(
                capture["output_dc"], 0, 0, CAPTURE_W, CAPTURE_H,
                capture["source_dc"], 0, 0, width, height, 0x00CC0020
            )
        else:
            client_dc = self.user32.GetDC(target["hwnd"])
            if not client_dc:
                return None
            try:
                copied = self.gdi32.StretchBlt(
                    capture["output_dc"], 0, 0, CAPTURE_W, CAPTURE_H,
                    client_dc, 0, 0, width, height, 0x00CC0020
                )
            finally:
                self.user32.ReleaseDC(target["hwnd"], client_dc)
        if not copied or not self.target_matches(target):
            return None
        self.gdi32.SelectObject(capture["output_dc"], capture["output_old"])
        try:
            lines = self.gdi32.GetDIBits(
                capture["output_dc"], capture["output_bitmap"], 0, CAPTURE_H,
                capture["pixels"], ctypes.byref(capture["info"]), 0
            )
        finally:
            self.gdi32.SelectObject(capture["output_dc"], capture["output_bitmap"])
        if lines != CAPTURE_H:
            return None
        pixels = capture["pixels"]
        gray = [0] * (CAPTURE_W * CAPTURE_H)
        for index in range(len(gray)):
            offset = index * 4
            gray[index] = (29 * pixels[offset] + 150 * pixels[offset + 1] + 77 * pixels[offset + 2]) >> 8
        return gray

    def any_keyboard_key_down(self):
        for virtual_key in range(8, 256):
            if self.user32.GetAsyncKeyState(virtual_key) & 0x8000:
                return True
        return False


def finite_number(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def normalized_title(title):
    text = str(title or "").strip().lower()
    text = re.sub(r"^\(\d+\)\s*", "", text)
    text = re.sub(r"\b\d{1,2}:\d{2}(?::\d{2})?\b", "#:#", text)
    text = re.sub(r"\b\d+\b", "#", text)
    text = re.sub(r"\b[0-9a-f]{8,}\b", "#", text)
    text = re.sub(r"\s+", " ", text)
    return text[:180]


def new_profile(label):
    return {
        "label": label,
        "weights": [[0.05] + [0.0] * (FEATURE_COUNT - 1) for _ in range(ACTION_COUNT)],
        "attempts": [0] * ACTION_COUNT,
        "replay": [],
        "sleep_cycles": 0,
        "accepted_sleeps": 0,
        "training_steps": 0,
        "iq": 100.0,
        "holdout_score": 0.0,
        "online_reward_score": 0.0,
        "learning_rate_scale": 1.0,
        "last_used": time.time(),
    }


def _legacy_sample_id(action, features, reward, ordinal):
    token = f"legacy|{ordinal}|{action}|{reward:.8f}|" + ",".join(f"{v:.8f}" for v in features)
    return hashlib.sha256(token.encode("ascii", "replace")).hexdigest()[:32]


def make_experience(action, features, reward):
    token = (
        f"{time.time_ns()}|{os.getpid()}|{random.getrandbits(64)}|{action}|{reward:.8f}|"
        + ",".join(f"{v:.8f}" for v in features)
    )
    sample_id = hashlib.sha256(token.encode("ascii", "replace")).hexdigest()[:32]
    return [sample_id, action, features, reward]


def clean_profile(raw, label):
    profile = new_profile(label)
    if not isinstance(raw, dict):
        return profile
    weights = raw.get("weights")
    if isinstance(weights, list) and len(weights) == ACTION_COUNT:
        cleaned = []
        for row in weights:
            if not isinstance(row, list) or len(row) != FEATURE_COUNT:
                break
            cleaned.append([max(-3.0, min(3.0, finite_number(v))) for v in row])
        if len(cleaned) == ACTION_COUNT:
            profile["weights"] = cleaned
    attempts = raw.get("attempts")
    if isinstance(attempts, list) and len(attempts) == ACTION_COUNT:
        profile["attempts"] = [max(0, min(10**9, int(finite_number(v)))) for v in attempts]
    replay = []
    source_replay = raw.get("replay")
    if isinstance(source_replay, list):
        for ordinal, item in enumerate(source_replay[-MAX_REPLAY:]):
            if not isinstance(item, list) or len(item) not in (3, 4):
                continue
            if len(item) == 4:
                sample_id = str(item[0] or "")[:64]
                action = int(finite_number(item[1], -1))
                features = item[2]
                reward = finite_number(item[3], -1.0)
            else:
                action = int(finite_number(item[0], -1))
                features = item[1]
                reward = finite_number(item[2], -1.0)
                sample_id = ""
            if (
                0 <= action < ACTION_COUNT
                and isinstance(features, list)
                and len(features) == FEATURE_COUNT
                and 0.0 <= reward <= 1.0
            ):
                cleaned_features = [max(-1.0, min(1.0, finite_number(v))) for v in features]
                if not sample_id:
                    sample_id = _legacy_sample_id(action, cleaned_features, reward, ordinal)
                replay.append([sample_id, action, cleaned_features, reward])
    profile["replay"] = replay
    profile["sleep_cycles"] = max(0, int(finite_number(raw.get("sleep_cycles"))))
    profile["accepted_sleeps"] = max(0, int(finite_number(raw.get("accepted_sleeps"))))
    profile["training_steps"] = max(0, int(finite_number(raw.get("training_steps"))))
    profile["iq"] = max(100.0, finite_number(raw.get("iq"), 100.0))
    profile["holdout_score"] = max(
        0.0, min(1.0, finite_number(raw.get("holdout_score", raw.get("validation_score", 0.0))))
    )
    profile["online_reward_score"] = max(
        0.0, min(1.0, finite_number(raw.get("online_reward_score"), 0.0))
    )
    profile["learning_rate_scale"] = max(
        0.08, min(1.5, finite_number(raw.get("learning_rate_scale"), 1.0))
    )
    profile["last_used"] = max(0.0, finite_number(raw.get("last_used"), time.time()))
    return profile


def _read_state_file(path):
    if not path.exists() or path.stat().st_size > 12 * 1024 * 1024:
        raise ValueError
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    if not isinstance(data, dict) or not isinstance(data.get("profiles"), dict):
        raise ValueError
    return {"version": STATE_VERSION, "profiles": data["profiles"]}


def _quarantine_corrupt(path):
    if not path.exists():
        return None
    stamp = time.strftime("%Y%m%d_%H%M%S") + f"_{time.time_ns() % 1000000000:09d}"
    destination = path.with_name(f"{path.name}.corrupt.{stamp}")
    try:
        os.replace(path, destination)
        return destination
    except Exception:
        return None


def load_state(path, backup_path):
    found_corruption = False
    for candidate in (path, backup_path):
        if not candidate.exists():
            continue
        try:
            state = _read_state_file(candidate)
            if found_corruption:
                safe_status(f"警告：已从可用备份恢复学习状态：{candidate}")
            return state
        except Exception:
            found_corruption = True
            preserved = _quarantine_corrupt(candidate)
            if preserved is not None:
                safe_status(f"警告：损坏的学习状态已保留为：{preserved.name}")
            else:
                safe_status(f"警告：检测到损坏的学习状态，但无法重命名保留：{candidate.name}")
    if found_corruption:
        safe_status("警告：主状态与备份均不可用，将创建新的空学习状态；损坏文件不会被覆盖。")
    return {"version": STATE_VERSION, "profiles": {}}


def _atomic_write_json(path, state):
    temporary = path.with_name(f"{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    try:
        with temporary.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(state, handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        return True
    except Exception:
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def save_state(path, backup_path, state):
    profiles = state.get("profiles", {})
    if len(profiles) > 16:
        newest = sorted(
            profiles.items(),
            key=lambda item: finite_number(
                item[1].get("last_used") if isinstance(item[1], dict) else 0
            ),
            reverse=True,
        )[:16]
        state["profiles"] = dict(newest)
    state["version"] = STATE_VERSION
    if not _atomic_write_json(path, state):
        return False
    _atomic_write_json(backup_path, state)
    return True

def frame_change(first, second):
    if not first or not second or len(first) != len(second):
        return 0.0
    total = 0
    changed = 0
    for a, b in zip(first, second):
        difference = abs(a - b)
        total += difference
        if difference >= 14:
            changed += 1
    mean_change = total / len(first) / 255.0
    changed_ratio = changed / len(first)
    return min(1.0, 4.0 * mean_change + 0.55 * changed_ratio)


def image_features(image, previous_image=None):
    global_mean = sum(image) / (len(image) * 255.0)
    global_delta = frame_change(previous_image, image) if previous_image else 0.0
    edge_total = 0
    edge_count = 0
    for y in range(CAPTURE_H):
        base = y * CAPTURE_W
        for x in range(CAPTURE_W):
            value = image[base + x]
            if x + 1 < CAPTURE_W:
                edge_total += abs(value - image[base + x + 1])
                edge_count += 1
            if y + 1 < CAPTURE_H:
                edge_total += abs(value - image[base + CAPTURE_W + x])
                edge_count += 1
    global_edge = edge_total / max(1, edge_count) / 255.0
    cell_w = CAPTURE_W // GRID_W
    cell_h = CAPTURE_H // GRID_H
    result = []
    for cell_y in range(GRID_H):
        for cell_x in range(GRID_W):
            values = []
            local_edges = 0
            local_edge_count = 0
            local_delta_total = 0
            x0 = cell_x * cell_w
            y0 = cell_y * cell_h
            for y in range(y0, y0 + cell_h):
                base = y * CAPTURE_W
                for x in range(x0, x0 + cell_w):
                    value = image[base + x]
                    values.append(value)
                    if previous_image is not None:
                        local_delta_total += abs(value - previous_image[base + x])
                    if x + 1 < x0 + cell_w:
                        local_edges += abs(value - image[base + x + 1])
                        local_edge_count += 1
                    if y + 1 < y0 + cell_h:
                        local_edges += abs(value - image[base + CAPTURE_W + x])
                        local_edge_count += 1
            mean = sum(values) / len(values)
            variance = sum((value - mean) ** 2 for value in values) / len(values)
            local_delta = local_delta_total / len(values) / 255.0 if previous_image else 0.0
            x_position = ((cell_x + 0.5) / GRID_W) * 2.0 - 1.0
            y_position = ((cell_y + 0.5) / GRID_H) * 2.0 - 1.0
            result.append(
                [
                    1.0,
                    mean / 255.0,
                    min(1.0, math.sqrt(variance) / 96.0),
                    local_edges / max(1, local_edge_count) / 255.0,
                    global_mean,
                    global_edge,
                    x_position,
                    y_position,
                    min(1.0, local_delta * 3.0),
                    global_delta,
                ]
            )
    return result


def salient_point(image, action):
    cell_x = action % GRID_W
    cell_y = action // GRID_W
    cell_w = CAPTURE_W // GRID_W
    cell_h = CAPTURE_H // GRID_H
    x0 = cell_x * cell_w
    y0 = cell_y * cell_h
    best_x = x0 + cell_w // 2
    best_y = y0 + cell_h // 2
    best_score = -1
    for y in range(y0 + 1, y0 + cell_h - 1):
        base = y * CAPTURE_W
        for x in range(x0 + 1, x0 + cell_w - 1):
            value = image[base + x]
            score = (
                abs(value - image[base + x - 1])
                + abs(value - image[base + x + 1])
                + abs(value - image[base - CAPTURE_W + x])
                + abs(value - image[base + CAPTURE_W + x])
            )
            if score > best_score:
                best_score = score
                best_x = x
                best_y = y
    center_x = x0 + (cell_w - 1) / 2.0
    center_y = y0 + (cell_h - 1) / 2.0
    best_x = 0.75 * best_x + 0.25 * center_x
    best_y = 0.75 * best_y + 0.25 * center_y
    return (best_x + 0.5) / CAPTURE_W, (best_y + 0.5) / CAPTURE_H


def predict(weights, features):
    raw = sum(weight * feature for weight, feature in zip(weights, features))
    return max(0.0, min(1.0, raw))


def choose_action(profile, features_by_action):
    attempts = profile["attempts"]
    accepted_sleeps = profile["accepted_sleeps"]
    epsilon = max(0.055, 0.30 * math.exp(-accepted_sleeps / 45.0))
    total = sum(attempts) + 1
    uncertainty_by_action = [
        min(1.0, math.sqrt(math.log(total + 1.0) / (attempts[i] + 1.0)))
        for i in range(ACTION_COUNT)
    ]
    if random.random() < epsilon:
        minimum = min(attempts)
        candidates = [i for i, count in enumerate(attempts) if count <= minimum + 1]
        action = max(
            candidates,
            key=lambda i: features_by_action[i][2]
            + features_by_action[i][3]
            + uncertainty_by_action[i]
            + random.random() * 0.25,
        )
        return action, uncertainty_by_action[action]
    best_action = 0
    best_score = -1e9
    for action in range(ACTION_COUNT):
        expected = predict(profile["weights"][action], features_by_action[action])
        uncertainty = uncertainty_by_action[action]
        salience = 0.5 * features_by_action[action][2] + 0.5 * features_by_action[action][3]
        score = expected + 0.24 * uncertainty + 0.07 * salience + random.random() * 0.012
        if score > best_score:
            best_score = score
            best_action = action
    return best_action, uncertainty_by_action[best_action]


def state_signature(image):
    sig_w = 8
    sig_h = 6
    cell_w = CAPTURE_W // sig_w
    cell_h = CAPTURE_H // sig_h
    signature = []
    for sy in range(sig_h):
        for sx in range(sig_w):
            total = 0
            count = 0
            for y in range(sy * cell_h, (sy + 1) * cell_h):
                base = y * CAPTURE_W
                for x in range(sx * cell_w, (sx + 1) * cell_w):
                    total += image[base + x]
                    count += 1
            signature.append(total / max(1, count) / 255.0)
    return signature


def signature_distance(first, second):
    if not first or not second or len(first) != len(second):
        return 1.0
    return sum(abs(a - b) for a, b in zip(first, second)) / len(first)


def exploration_reward(before, short_frame, mid_frame, long_frame, action, recent_actions, recent_states):
    short_change = frame_change(before, short_frame)
    mid_change = frame_change(before, mid_frame)
    long_change = frame_change(before, long_frame)
    settle_change = frame_change(mid_frame, long_frame)
    stability = max(0.0, 1.0 - min(1.0, settle_change * 2.8))
    stable_change = min(mid_change, long_change) * stability
    transient = max(0.0, short_change - long_change) + 0.5 * max(0.0, settle_change - long_change)
    new_signature = state_signature(long_frame)
    if recent_states:
        novelty_distance = min(signature_distance(new_signature, state) for state in recent_states)
        novelty = min(1.0, novelty_distance / 0.14)
    else:
        novelty = 1.0
    same_action_penalty = 0.0
    if recent_actions:
        if recent_actions[-1] == action:
            same_action_penalty += 0.16
        same_action_penalty += 0.035 * max(0, recent_actions[-5:].count(action) - 1)
    rapid_repeat_penalty = 0.08 if len(recent_actions) >= 2 and recent_actions[-2:] == [action, action] else 0.0
    state_cycle_penalty = 0.0
    if len(recent_states) >= 2:
        older_states = recent_states[:-1]
        cycle_distance = min(signature_distance(new_signature, state) for state in older_states)
        if cycle_distance < 0.045:
            state_cycle_penalty = 0.22 * (1.0 - cycle_distance / 0.045)
    reward = (
        0.46 * stable_change
        + 0.24 * novelty * min(1.0, 0.25 + long_change * 2.0)
        + 0.17 * long_change
        + 0.08 * stability * min(1.0, long_change * 3.0)
        - 0.24 * transient
        - same_action_penalty
        - rapid_repeat_penalty
        - state_cycle_penalty
    )
    reward = max(0.0, min(1.0, reward))
    return reward, {
        "stable_change": stable_change,
        "novelty": novelty,
        "transient": transient,
        "same_action_penalty": same_action_penalty,
        "state_cycle_penalty": state_cycle_penalty,
        "signature": new_signature,
    }


def replay_loss(weights, replay):
    if not replay:
        return 1.0
    error = 0.0
    for _, action, features, reward in replay:
        difference = predict(weights[action], features) - reward
        error += difference * difference
    return error / len(replay)


def validation_score(weights, replay):
    return max(0.0, 1.0 - replay_loss(weights, replay))


def split_train_selection_holdout(replay):
    training = []
    selection = []
    holdout = []
    for item in replay:
        sample_id = str(item[0])
        bucket = int(hashlib.sha256(sample_id.encode("utf-8", "replace")).hexdigest()[:8], 16) % 10
        if bucket < 2:
            holdout.append(item)
        elif bucket < 4:
            selection.append(item)
        else:
            training.append(item)
    return training, selection, holdout


def train_candidate(old_weights, training, learning_rate, epochs, stop_event):
    candidate = [row[:] for row in old_weights]
    order = list(range(len(training)))
    completed_steps = 0
    for _ in range(epochs):
        if stop_event.is_set():
            return None, completed_steps
        random.shuffle(order)
        for position, index in enumerate(order):
            if position % 24 == 0 and stop_event.is_set():
                return None, completed_steps
            _, action, features, reward = training[index]
            row = candidate[action]
            estimate = predict(row, features)
            error = estimate - reward
            for feature_index in range(FEATURE_COUNT):
                gradient = 2.0 * error * features[feature_index] + 0.00018 * row[feature_index]
                row[feature_index] = max(
                    -3.0,
                    min(3.0, row[feature_index] - learning_rate * gradient),
                )
            completed_steps += 1
    return candidate, completed_steps


def improvement_to_ability(delta, evidence_count):
    if delta <= 0.0:
        return 0.0
    confidence = min(1.0, 0.45 + math.log1p(evidence_count) / 4.0)
    return min(2.5, delta * 28.0 * confidence)


def sleep_and_learn(profile, pending, baseline_rewards, stop_event):
    if len(pending) < MIN_SLEEP_EXPERIENCE:
        return {"status": "insufficient"}
    profile["replay"].extend(pending)
    profile["replay"] = profile["replay"][-MAX_REPLAY:]
    training, selection, holdout = split_train_selection_holdout(profile["replay"])
    counts = (len(training), len(selection), len(holdout))
    if len(training) < 4 or len(selection) < 2 or len(holdout) < 2:
        return {"status": "insufficient_split", "counts": counts}
    old_weights = [row[:] for row in profile["weights"]]
    before_selection = validation_score(old_weights, selection)
    best_weights = old_weights
    best_selection = before_selection
    scale = profile["learning_rate_scale"]
    base_rate = max(0.006, 0.052 * scale / math.sqrt(1.0 + len(training) / 180.0))
    epochs = 7
    completed_steps = 0
    profile["sleep_cycles"] += 1
    for rate_factor in (1.0, 0.5, 0.25):
        if stop_event.is_set():
            profile["training_steps"] += completed_steps
            return {"status": "stopped", "old_weights": old_weights}
        candidate, steps = train_candidate(
            old_weights, training, base_rate * rate_factor, epochs, stop_event
        )
        completed_steps += steps
        if candidate is None:
            profile["training_steps"] += completed_steps
            return {"status": "stopped", "old_weights": old_weights}
        candidates = [candidate]
        for amount in (0.75, 0.5, 0.25):
            candidates.append(
                [
                    [old * (1.0 - amount) + new * amount for old, new in zip(old_row, new_row)]
                    for old_row, new_row in zip(old_weights, candidate)
                ]
            )
        for weights in candidates:
            if stop_event.is_set():
                profile["training_steps"] += completed_steps
                return {"status": "stopped", "old_weights": old_weights}
            score = validation_score(weights, selection)
            if score > best_selection:
                best_selection = score
                best_weights = weights
    profile["training_steps"] += completed_steps
    profile["last_used"] = time.time()
    old_holdout = validation_score(old_weights, holdout)
    if best_selection <= before_selection + 1e-6:
        profile["weights"] = old_weights
        profile["holdout_score"] = old_holdout
        profile["learning_rate_scale"] = max(0.08, scale * 0.65)
        return {
            "status": "no_candidate",
            "selection_before": before_selection,
            "selection_after": before_selection,
            "holdout_old": old_holdout,
            "counts": counts,
        }
    candidate_holdout = validation_score(best_weights, holdout)
    profile["weights"] = best_weights
    baseline = sum(baseline_rewards) / max(1, len(baseline_rewards))
    return {
        "status": "provisional",
        "old_weights": old_weights,
        "selection_before": before_selection,
        "selection_after": best_selection,
        "holdout_old": old_holdout,
        "holdout_candidate": candidate_holdout,
        "baseline_reward": baseline,
        "baseline_count": len(baseline_rewards),
        "counts": counts,
        "learning_rate_scale": scale,
    }


def finalize_provisional(profile, provisional, fresh_rewards):
    fresh_mean = sum(fresh_rewards) / max(1, len(fresh_rewards))
    baseline = provisional["baseline_reward"]
    delta = fresh_mean - baseline
    accepted = len(fresh_rewards) >= PROVISIONAL_TRIALS and delta > 1e-6
    scale = provisional["learning_rate_scale"]
    if accepted:
        profile["accepted_sleeps"] += 1
        profile["iq"] += improvement_to_ability(delta, len(fresh_rewards))
        profile["holdout_score"] = provisional["holdout_candidate"]
        profile["online_reward_score"] = fresh_mean
        profile["learning_rate_scale"] = min(1.25, scale * 1.03)
    else:
        profile["weights"] = [row[:] for row in provisional["old_weights"]]
        profile["holdout_score"] = provisional["holdout_old"]
        profile["online_reward_score"] = baseline
        profile["learning_rate_scale"] = max(0.08, scale * 0.65)
    profile["last_used"] = time.time()
    return accepted, baseline, fresh_mean


def profile_identity(window):
    identity = "|".join(
        [
            window.get("process_path", ""),
            window.get("class_name", ""),
            normalized_title(window.get("title", "")),
        ]
    ).lower()
    key = hashlib.sha256(identity.encode("utf-8", "replace")).hexdigest()[:24]
    return key, identity


def safe_status(message):
    try:
        print(message, flush=True)
    except Exception:
        pass


def keyboard_watcher(api, stop_event, ready_event):
    while not stop_event.is_set() and api.any_keyboard_key_down():
        stop_event.wait(0.02)
    if stop_event.is_set():
        ready_event.set()
        return
    HookProc = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    WM_KEYDOWN = 0x0100
    WM_SYSKEYDOWN = 0x0104
    PM_REMOVE = 0x0001

    @HookProc
    def hook_callback(code, w_param, l_param):
        if code >= 0 and int(w_param) in (WM_KEYDOWN, WM_SYSKEYDOWN):
            stop_event.set()
        return api.user32.CallNextHookEx(None, code, w_param, l_param)

    try:
        module = api.kernel32.GetModuleHandleW(None)
        hook = api.user32.SetWindowsHookExW(13, hook_callback, module, 0)
    except Exception:
        hook = None
    if hook:
        ready_event.set()
        message = MSG()
        try:
            while not stop_event.is_set():
                while api.user32.PeekMessageW(ctypes.byref(message), None, 0, 0, PM_REMOVE):
                    api.user32.TranslateMessage(ctypes.byref(message))
                    api.user32.DispatchMessageW(ctypes.byref(message))
                stop_event.wait(0.01)
        finally:
            api.user32.UnhookWindowsHookEx(hook)
        return
    ready_event.set()
    previous = {key for key in range(8, 256) if api.user32.GetAsyncKeyState(key) & 0x8000}
    while not stop_event.is_set():
        current = {key for key in range(8, 256) if api.user32.GetAsyncKeyState(key) & 0x8000}
        if current - previous:
            stop_event.set()
            return
        previous = current
        stop_event.wait(0.012)


def wait_and_capture(api, target, stop_event, delay):
    if stop_event.wait(delay):
        return None
    if not api.target_matches(target):
        return None
    return api.capture_client(target)


def should_sleep(pending, fatigue, rewards, uncertainties, novelties):
    if len(pending) < MIN_SLEEP_EXPERIENCE:
        return False, ""
    if len(pending) >= MAX_WAKE_EXPERIENCE:
        return True, "有效经验已足够"
    recent_novelty = sum(novelties[-4:]) / max(1, len(novelties[-4:]))
    fatigue_limit = 9.0 + 4.0 * recent_novelty
    if fatigue >= fatigue_limit:
        return True, "疲劳度达到睡眠阈值"
    if len(rewards) >= 8:
        earlier = sum(rewards[-8:-4]) / 4.0
        later = sum(rewards[-4:]) / 4.0
        if later + 0.045 < earlier:
            return True, "近期收益持续下降"
    if len(uncertainties) >= 8:
        uncertainty = sum(uncertainties[-4:]) / 4.0
        if uncertainty >= 0.72:
            return True, "策略不确定性过高"
    return False, ""


def run_agent(api, window, data_dir, stop_event, done_event):
    state_path = data_dir / STATE_FILE
    backup_path = data_dir / STATE_BACKUP_FILE
    state = load_state(state_path, backup_path)
    key, label = profile_identity(window)
    profile = clean_profile(state["profiles"].get(key), label)
    state["profiles"][key] = profile
    pending = []
    provisional = None
    if not api.startup_target_matches(window):
        safe_status("目标窗口在启动前已变化，AI 未开始控制鼠标。")
        stop_event.set()
        done_event.set()
        return
    if not api.attach_target_guard(window):
        safe_status("无法建立目标窗口身份保护，AI 已停止。")
        stop_event.set()
        done_event.set()
        return
    try:
        while not stop_event.is_set():
            if not api.target_matches(window):
                safe_status("目标窗口身份已变化或窗口已关闭，AI 已停止。")
                stop_event.set()
                break
            if provisional is None:
                safe_status(
                    f"状态：清醒｜睡眠轮次 {profile['sleep_cycles']}｜能力评估分数 {profile['iq']:.2f}"
                )
            else:
                safe_status(
                    f"状态：清醒｜候选策略试运行｜将用 {PROVISIONAL_TRIALS} 次全新交互决定接受或回滚"
                )
            pending = []
            recent_actions = []
            recent_states = []
            reward_history = []
            uncertainty_history = []
            novelty_history = []
            evaluation_rewards = []
            fatigue = 0.0
            previous_frame = None
            idle_failures = 0
            sleep_reason = ""
            while not stop_event.is_set():
                if not api.target_matches(window):
                    stop_event.set()
                    break
                if not api.focus_window(window, stop_event):
                    idle_failures += 1
                    stop_event.wait(0.12)
                    if idle_failures >= 12 and not pending:
                        idle_failures = 0
                        stop_event.wait(0.25)
                    continue
                before = api.capture_client(window)
                if before is None:
                    idle_failures += 1
                    stop_event.wait(0.12)
                    continue
                idle_failures = 0
                if not recent_states:
                    recent_states.append(state_signature(before))
                features = image_features(before, previous_frame)
                action, uncertainty = choose_action(profile, features)
                point = salient_point(before, action)
                if not api.click_client(window, point[0], point[1], stop_event):
                    continue
                short_frame = wait_and_capture(api, window, stop_event, 0.15)
                if short_frame is None:
                    continue
                mid_frame = wait_and_capture(api, window, stop_event, 0.45)
                if mid_frame is None:
                    continue
                long_frame = wait_and_capture(api, window, stop_event, 0.90)
                if long_frame is None:
                    continue
                reward, metrics = exploration_reward(
                    before,
                    short_frame,
                    mid_frame,
                    long_frame,
                    action,
                    recent_actions,
                    recent_states,
                )
                profile["attempts"][action] += 1
                pending.append(make_experience(action, features[action], reward))
                recent_actions.append(action)
                recent_actions = recent_actions[-8:]
                recent_states.append(metrics["signature"])
                recent_states = recent_states[-12:]
                reward_history.append(reward)
                reward_history = reward_history[-12:]
                uncertainty_history.append(uncertainty)
                uncertainty_history = uncertainty_history[-12:]
                novelty_history.append(metrics["novelty"])
                novelty_history = novelty_history[-12:]
                fatigue += 1.0 + 0.28 * uncertainty + 0.15 * max(0.0, 0.45 - reward)
                previous_frame = long_frame
                if provisional is not None:
                    evaluation_rewards.append(reward)
                    if len(evaluation_rewards) >= PROVISIONAL_TRIALS:
                        break
                else:
                    sleep_now, sleep_reason = should_sleep(
                        pending,
                        fatigue,
                        reward_history,
                        uncertainty_history,
                        novelty_history,
                    )
                    if sleep_now:
                        break
                stop_event.wait(0.05)
            if stop_event.is_set():
                break
            if provisional is not None:
                profile["replay"].extend(pending)
                profile["replay"] = profile["replay"][-MAX_REPLAY:]
                pending = []
                accepted, baseline, fresh_mean = finalize_provisional(
                    profile, provisional, evaluation_rewards
                )
                train_count, selection_count, holdout_count = provisional["counts"]
                state["profiles"][key] = profile
                if not save_state(state_path, backup_path, state):
                    safe_status("警告：候选策略验收结果无法写入数据文件夹。")
                if accepted:
                    safe_status(
                        f"候选策略验收通过：全新交互平均探索收益 {baseline:.5f} → {fresh_mean:.5f}｜正式接受新策略｜能力评估分数 {profile['iq']:.2f}｜训练/选择/留出 {train_count}/{selection_count}/{holdout_count}"
                    )
                else:
                    safe_status(
                        f"候选策略验收失败：全新交互平均探索收益 {baseline:.5f} → {fresh_mean:.5f}｜已回滚旧策略｜能力评估分数保持 {profile['iq']:.2f}"
                    )
                provisional = None
                stop_event.wait(0.35)
                continue
            if len(pending) < MIN_SLEEP_EXPERIENCE:
                stop_event.wait(0.18)
                continue
            safe_status(f"状态：意识到该睡觉了｜原因：{sleep_reason or '经验需要整合'}")
            safe_status("状态：睡觉｜train 用于训练，selection 只挑候选，holdout 不参与候选选择")
            baseline_rewards = reward_history[-PROVISIONAL_TRIALS:]
            result = sleep_and_learn(profile, pending, baseline_rewards, stop_event)
            pending = []
            if result.get("status") == "stopped":
                if result.get("old_weights") is not None:
                    profile["weights"] = [row[:] for row in result["old_weights"]]
                break
            state["profiles"][key] = profile
            if result.get("status") == "insufficient_split":
                train_count, selection_count, holdout_count = result["counts"]
                safe_status(
                    f"睡眠跳过：固定 sample_id 分组后样本仍不足｜训练/选择/留出 {train_count}/{selection_count}/{holdout_count}。经验已保留，继续清醒收集。"
                )
                save_state(state_path, backup_path, state)
                stop_event.wait(0.25)
                continue
            if result.get("status") in ("insufficient", "no_candidate"):
                if result.get("status") == "no_candidate":
                    safe_status("睡眠完成：selection 未发现更好的候选策略，已保留旧模型并降低学习率。")
                else:
                    safe_status("睡眠跳过：有效经验不足，模型与能力分数均未改变。")
                save_state(state_path, backup_path, state)
                stop_event.wait(0.25)
                continue
            provisional = result
            train_count, selection_count, holdout_count = provisional["counts"]
            safe_status(
                f"睡眠训练完成：selection {provisional['selection_before']:.5f} → {provisional['selection_after']:.5f}｜holdout 仅作独立诊断 {provisional['holdout_old']:.5f} → {provisional['holdout_candidate']:.5f}｜候选策略暂不计入能力分数｜训练/选择/留出 {train_count}/{selection_count}/{holdout_count}"
            )
            safe_status("候选策略已设为 provisional；醒来后必须用此前从未见过的新交互实际提升才正式接受，否则自动回滚。")
            stop_event.wait(0.35)
    except Exception as error:
        safe_status(f"AI 已因错误停止：{error}")
        stop_event.set()
    finally:
        if pending:
            profile["replay"].extend(pending)
            profile["replay"] = profile["replay"][-MAX_REPLAY:]
        if provisional is not None:
            profile["weights"] = [row[:] for row in provisional["old_weights"]]
            safe_status("AI 在候选策略验收完成前停止，已回滚到正式旧策略。")
        profile["last_used"] = time.time()
        state["profiles"][key] = profile
        if save_state(state_path, backup_path, state):
            safe_status("AI 已停止，学习状态已保存。")
        else:
            safe_status("AI 已停止，但学习状态保存失败。")
        api.release_capture_buffer()
        api.detach_target_guard(window)
        done_event.set()

def ensure_data_directory(text):
    if not text:
        raise ValueError("文件夹路径不能为空")
    path = Path(text).expanduser().resolve()
    path.mkdir(parents=True, exist_ok=True)
    probe = path / f".write_test_{os.getpid()}_{time.time_ns()}"
    created = False
    try:
        with probe.open("x", encoding="utf-8") as handle:
            handle.write("ok")
        created = True
    finally:
        if created:
            probe.unlink(missing_ok=True)
    return path


def run_gui():
    if os.name != "nt":
        raise SystemExit("此程序仅支持 Windows 11。")
    enable_dpi_awareness()
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    api = WinAPI()
    root = tk.Tk()
    root.title("睡眠学习鼠标 AI")
    root.geometry("820x520")
    root.minsize(700, 440)
    root.columnconfigure(0, weight=1)
    root.rowconfigure(1, weight=1)

    ttk.Label(
        root,
        text="选择允许 AI 操作的窗口",
        font=("Microsoft YaHei UI", 14, "bold"),
    ).grid(row=0, column=0, sticky="w", padx=18, pady=(16, 8))

    columns = ("app", "title", "size")
    tree = ttk.Treeview(root, columns=columns, show="headings", selectmode="browse")
    tree.heading("app", text="应用")
    tree.heading("title", text="窗口标题")
    tree.heading("size", text="客户区")
    tree.column("app", width=170, minwidth=100)
    tree.column("title", width=470, minwidth=220)
    tree.column("size", width=100, minwidth=80, anchor="center")
    tree.grid(row=1, column=0, sticky="nsew", padx=(18, 0))
    scrollbar = ttk.Scrollbar(root, orient="vertical", command=tree.yview)
    scrollbar.grid(row=1, column=1, sticky="ns", padx=(0, 18))
    tree.configure(yscrollcommand=scrollbar.set)

    controls = ttk.Frame(root)
    controls.grid(row=2, column=0, columnspan=2, sticky="ew", padx=18, pady=12)
    controls.columnconfigure(1, weight=1)
    ttk.Label(controls, text="学习数据文件夹：").grid(row=0, column=0, sticky="w")
    script_dir = Path(sys.argv[0]).resolve().parent
    folder_var = tk.StringVar(value=str(script_dir / "AI_data"))
    folder_entry = ttk.Entry(controls, textvariable=folder_var)
    folder_entry.grid(row=0, column=1, sticky="ew", padx=(5, 8))

    def browse_folder():
        chosen = filedialog.askdirectory(initialdir=folder_var.get() or str(script_dir))
        if chosen:
            folder_var.set(chosen)

    browse_button = ttk.Button(controls, text="选择…", command=browse_folder)
    browse_button.grid(row=0, column=2)

    ttk.Label(
        controls,
        text="启动后 AI 只向所选窗口客户区发送鼠标移动/单击输入；按键盘任意键立即停止。请勿选择含有不可逆操作的窗口。",
        foreground="#9a3d00",
        wraplength=740,
    ).grid(row=1, column=0, columnspan=3, sticky="w", pady=(10, 0))

    bottom = ttk.Frame(root)
    bottom.grid(row=3, column=0, columnspan=2, sticky="ew", padx=18, pady=(0, 16))
    bottom.columnconfigure(0, weight=1)
    status_var = tk.StringVar(value="正在读取窗口…")
    ttk.Label(bottom, textvariable=status_var).grid(row=0, column=0, sticky="w")

    window_rows = {}

    def refresh_windows():
        selected = tree.selection()
        old_handle = window_rows.get(selected[0], {}).get("hwnd") if selected else None
        for item in tree.get_children():
            tree.delete(item)
        window_rows.clear()
        for row in api.list_windows():
            item = f"w{row['hwnd']:x}"
            tree.insert("", "end", iid=item, values=(row["app"], row["title"], row["size"]))
            window_rows[item] = row
            if row["hwnd"] == old_handle:
                tree.selection_set(item)
                tree.see(item)
        status_var.set(f"找到 {len(window_rows)} 个可选窗口")

    refresh_button = ttk.Button(bottom, text="刷新", command=refresh_windows)
    refresh_button.grid(row=0, column=1, padx=(8, 8))

    controller = {"stop": None, "done": None, "started": False}

    def start_ai():
        selected = tree.selection()
        if not selected or selected[0] not in window_rows:
            messagebox.showwarning("请选择窗口", "请先在列表中选择一个目标窗口。", parent=root)
            return
        window = dict(window_rows[selected[0]])
        if not api.target_matches(window):
            messagebox.showerror("窗口不可用", "目标窗口已关闭或客户区不可用，请刷新后重选。", parent=root)
            return
        try:
            data_dir = ensure_data_directory(folder_var.get().strip())
        except Exception as error:
            messagebox.showerror("文件夹不可用", f"无法使用该数据文件夹：\n{error}", parent=root)
            return
        start_button.configure(state="disabled")
        refresh_button.configure(state="disabled")
        browse_button.configure(state="disabled")
        folder_entry.configure(state="disabled")
        status_var.set("正在启动…")
        root.update_idletasks()
        root.withdraw()
        if not api.focus_window(window):
            root.deiconify()
            start_button.configure(state="normal")
            refresh_button.configure(state="normal")
            browse_button.configure(state="normal")
            folder_entry.configure(state="normal")
            messagebox.showerror("无法启动", "无法将目标窗口置于前台，请重试。", parent=root)
            return
        stop_event = threading.Event()
        done_event = threading.Event()
        keyboard_ready = threading.Event()
        controller.update({"stop": stop_event, "done": done_event, "started": True})
        threading.Thread(
            target=keyboard_watcher,
            args=(api, stop_event, keyboard_ready),
            name="keyboard-stop-watcher",
            daemon=True,
        ).start()

        def run_after_keyboard_ready():
            keyboard_ready.wait()
            if stop_event.is_set():
                done_event.set()
                return
            run_agent(api, window, data_dir, stop_event, done_event)

        threading.Thread(
            target=run_after_keyboard_ready,
            name="sleep-mouse-ai",
            daemon=True,
        ).start()

        def wait_for_finish():
            if done_event.is_set():
                root.destroy()
            else:
                root.after(50, wait_for_finish)

        root.after(50, wait_for_finish)

    start_button = ttk.Button(bottom, text="确认并开启 AI", command=start_ai)
    start_button.grid(row=0, column=2)

    def close_program():
        if controller["started"]:
            controller["stop"].set()
        else:
            root.destroy()

    root.protocol("WM_DELETE_WINDOW", close_program)
    refresh_windows()
    try:
        root.mainloop()
    except KeyboardInterrupt:
        if controller["stop"] is not None:
            controller["stop"].set()
            controller["done"].wait(2.0)


if __name__ == "__main__":
    run_gui()
