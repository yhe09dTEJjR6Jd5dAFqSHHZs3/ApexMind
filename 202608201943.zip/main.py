import ctypes
import hashlib
import importlib
import json
import math
import os
import queue
import random
import re
import shutil
import subprocess
import sys
import threading
import time
import unicodedata
from ctypes import wintypes
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk


APP_NAME = "屏幕数值 AI"
DATA_DIR_NAME = "屏幕数值AI数据"
RAPIDOCR_VERSION = "3.9.2"
MSS_SPEC = "mss>=10.2,<12"
VK_ESCAPE = 0x1B
WM_QUIT = 0x0012
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WH_KEYBOARD_LL = 13
GA_ROOT = 2
KEYEVENTF_KEYUP = 0x0002
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004


if os.name == "nt":
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
else:
    user32 = None
    kernel32 = None


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG),
                ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


ULONG_PTR = wintypes.WPARAM


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]


def set_dpi_awareness():
    try:
        user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            try:
                user32.SetProcessDPIAware()
            except Exception:
                pass


def configure_winapi():
    user32.WindowFromPoint.argtypes = [POINT]
    user32.WindowFromPoint.restype = wintypes.HWND
    user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    user32.GetAncestor.restype = wintypes.HWND
    user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                                ctypes.POINTER(wintypes.DWORD)]
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.IsWindow.argtypes = [wintypes.HWND]
    user32.IsWindowVisible.argtypes = [wintypes.HWND]
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetForegroundWindow.argtypes = [wintypes.HWND]
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, ctypes.c_void_p,
                                         wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT,
                                          wintypes.WPARAM, wintypes.LPARAM]
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE


def d_drive_path(value):
    try:
        resolved = os.path.realpath(os.path.abspath(str(value)))
        return resolved if os.path.splitdrive(resolved)[0].upper() == "D:" else None
    except Exception:
        return None


GIB = 1024 ** 3


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


def _total_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullTotalPhys)
    except Exception:
        pass
    return 8 * GIB


def _available_memory():
    try:
        status = MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
            return int(status.ullAvailPhys)
    except Exception:
        pass
    return 4 * GIB


def _gpu_info():
    if os.name != "nt":
        return [], 0
    script = (
        "Get-CimInstance Win32_VideoController | "
        "Select-Object Name,AdapterRAM | ConvertTo-Json -Compress"
    )
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        run = subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive",
                              "-ExecutionPolicy", "Bypass", "-Command", script],
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                             text=True, encoding="utf-8", errors="replace",
                             timeout=8, creationflags=flags)
        if run.returncode or not run.stdout.strip():
            return [], 0
        data = json.loads(run.stdout.strip())
        if isinstance(data, dict):
            data = [data]
        names, vram = [], 0
        for item in data if isinstance(data, list) else []:
            name = str(item.get("Name") or "").strip()
            lower = name.lower()
            if not name or "microsoft basic" in lower or "remote display" in lower:
                continue
            names.append(name)
            try:
                vram = max(vram, int(item.get("AdapterRAM") or 0))
            except Exception:
                pass
        return names, vram
    except Exception:
        return [], 0


def _fmt_gib(value):
    return f"{value / GIB:.1f} GB"


class HardwareProfile:
    def __init__(self, storage):
        self.logical_cpus = max(1, os.cpu_count() or 1)
        self.ram = _total_memory()
        try:
            self.disk_free = shutil.disk_usage(storage).free
        except Exception:
            self.disk_free = 8 * GIB
        self.gpu_names, self.gpu_vram = _gpu_info()
        self.has_gpu = bool(self.gpu_names)
        gpu_text = " ".join(self.gpu_names).lower()
        self.gpu_vendor = ("nvidia" if "nvidia" in gpu_text else
                           "amd" if any(x in gpu_text for x in ("amd", "radeon")) else
                           "intel" if "intel" in gpu_text else "other")
        self.cpu_text = (os.environ.get("PROCESSOR_IDENTIFIER") or "").lower()
        try:
            self.screen_w = max(1, int(user32.GetSystemMetrics(78)))
            self.screen_h = max(1, int(user32.GetSystemMetrics(79)))
        except Exception:
            self.screen_w, self.screen_h = 1920, 1080
        screen_load = self.screen_w * self.screen_h

        # The tier drives model size, OCR redundancy, visual-state resolution and
        # action-search breadth.  RAM is deliberately weighted more heavily than the
        # nominal GPU VRAM because integrated GPUs often report misleading AdapterRAM.
        score = 0
        score += 2 if self.logical_cpus >= 12 else (1 if self.logical_cpus >= 8 else 0)
        score += 2 if self.ram >= 24 * GIB else (1 if self.ram >= 12 * GIB else 0)
        score += 1 if self.disk_free >= 10 * GIB else 0
        score += 1 if self.has_gpu else 0
        if screen_load >= 28_000_000:
            score -= 2
        elif screen_load >= 15_000_000:
            score -= 1
        if self.ram < 6 * GIB or self.logical_cpus <= 2 or self.disk_free < 2 * GIB:
            score = -2
        if score >= 5:
            self.tier = "high"
        elif score <= 0:
            self.tier = "low"
        else:
            self.tier = "balanced"

        # DirectML is only a candidate here.  _prepare_runtime benchmarks a real OCR
        # session against CPU and keeps whichever is faster and stable on this machine.
        self.want_dml = self.has_gpu and self.ram >= 8 * GIB and self.disk_free >= 2 * GIB
        self.backend = "dml?" if self.want_dml else "cpu"
        self.capture_backend = "mss"

        if self.tier == "high":
            self.ocr_threads = min(12, max(4, self.logical_cpus // 2))
            self.settle = 0.24
            self.state_every = 1
            self.candidate_refresh = 8
            self.candidate_limit = 38
            self.ocr_variants = 9
            self.verify_reads = 2
            self.visual_shape = (22, 13)
            self.save_interval = 7
            self.rec_model = "medium"
            self.det_model = "small"
            self.ensemble = self.ram >= 16 * GIB and self.disk_free >= 5 * GIB
            self.mouse_grid = 36
            self.min_ocr_variants = 4
            self.max_ocr_variants = 12
            self.macro_limit = 8
            self.latency_target = 0.42
        elif self.tier == "low":
            self.ocr_threads = min(2, self.logical_cpus)
            self.settle = 0.55
            self.state_every = 4
            self.candidate_refresh = 26
            self.candidate_limit = 14
            self.ocr_variants = 4
            self.verify_reads = 0
            self.visual_shape = (11, 7)
            self.save_interval = 22
            self.rec_model = "tiny" if self.ram < 8 * GIB else "small"
            self.det_model = "tiny"
            self.ensemble = False
            self.mouse_grid = 18
            self.min_ocr_variants = 2
            self.max_ocr_variants = 5
            self.macro_limit = 2
            self.latency_target = 0.82
        else:
            self.ocr_threads = min(7, max(2, self.logical_cpus // 2))
            self.settle = 0.34
            self.state_every = 2
            self.candidate_refresh = 14
            self.candidate_limit = 26
            self.ocr_variants = 7
            self.verify_reads = 1
            self.visual_shape = (16, 10)
            self.save_interval = 11
            self.rec_model = "small"
            self.det_model = "small"
            self.ensemble = self.ram >= 14 * GIB and self.disk_free >= 5 * GIB
            self.mouse_grid = 26
            self.min_ocr_variants = 3
            self.max_ocr_variants = 9
            self.macro_limit = 5
            self.latency_target = 0.58

        self.ocr_variants = max(self.min_ocr_variants, min(self.max_ocr_variants, self.ocr_variants))

    @property
    def tag(self):
        gpu = self.gpu_vendor if self.want_dml else "cpu"
        return f"{gpu}-{self.tier}-{self.rec_model}"

    def summary(self):
        gpu = self.gpu_names[0] if self.gpu_names else "无可用 GPU"
        if len(gpu) > 34:
            gpu = gpu[:33] + "…"
        mode = ("GPU/DirectML" if self.backend == "dml" else
                "CPU" if self.backend == "cpu" else "自动测速 GPU/CPU")
        model = {"tiny": "PP-OCRv6 Tiny", "small": "PP-OCRv6 Small",
                 "medium": "PP-OCRv6 Medium"}.get(self.rec_model, self.rec_model)
        capture = (self.capture_backend or "auto").upper()
        return (f"{self.logical_cpus} 线程 CPU · 内存 {_fmt_gib(self.ram)} · "
                f"D盘可用 {_fmt_gib(self.disk_free)} · {gpu} · {mode} · "
                f"OCR {self.ocr_threads}线程 · {model} · 截图 {capture}")


class ScreenCapture:
    """Thread-local screen capture that benchmarks MSS against Pillow on this PC."""
    def __init__(self, mss_module, image_grab, image_module):
        self.mss_module = mss_module
        self.ImageGrab = image_grab
        self.Image = image_module
        self.local = threading.local()
        self.backend = "mss" if mss_module is not None else "pillow"
        self.preferred = self.backend
        self.latency = 0.02

    def _instance(self):
        if self.mss_module is None:
            return None
        obj = getattr(self.local, "mss", None)
        if obj is None:
            obj = self.mss_module.MSS(with_cursor=False)
            self.local.mss = obj
        return obj

    def _grab_mss(self, rect):
        obj = self._instance()
        if obj is None:
            raise RuntimeError("MSS unavailable")
        shot = obj.grab(rect)
        try:
            return shot.to_pil("RGB")
        except Exception:
            return self.Image.frombytes("RGB", shot.size, shot.rgb)

    def _grab_pillow(self, rect):
        try:
            return self.ImageGrab.grab(bbox=rect, all_screens=True)
        except TypeError:
            return self.ImageGrab.grab(bbox=rect)

    def benchmark(self):
        """Select the faster stable capture path instead of assuming MSS always wins."""
        left = int(user32.GetSystemMetrics(76)) if user32 else 0
        top = int(user32.GetSystemMetrics(77)) if user32 else 0
        width = max(320, int(user32.GetSystemMetrics(78))) if user32 else 1920
        height = max(240, int(user32.GetSystemMetrics(79))) if user32 else 1080
        w, h = min(640, width), min(360, height)
        x = left + max(0, (width - w) // 2)
        y = top + max(0, (height - h) // 2)
        rect = (x, y, x + w, y + h)
        timings = {}
        for name in ("mss", "pillow"):
            if name == "mss" and self.mss_module is None:
                continue
            samples = []
            try:
                for _ in range(3):
                    t0 = time.perf_counter()
                    image = self._grab_mss(rect) if name == "mss" else self._grab_pillow(rect)
                    if image.width <= 0:
                        raise RuntimeError("capture failed")
                    samples.append(time.perf_counter() - t0)
                samples.sort()
                timings[name] = samples[len(samples) // 2]
            except Exception:
                continue
        if timings:
            self.preferred = min(timings, key=timings.get)
            self.backend = self.preferred
            self.latency = timings[self.preferred]
        return self.backend

    def grab(self, rect):
        rect = tuple(int(round(v)) for v in rect)
        if rect[2] <= rect[0] or rect[3] <= rect[1]:
            raise ValueError("截图区域无效")
        started = time.perf_counter()
        primary = self.preferred
        try:
            if primary == "mss":
                image = self._grab_mss(rect)
            else:
                image = self._grab_pillow(rect)
            self.backend = primary
            return image
        except Exception:
            fallback = "pillow" if primary == "mss" else "mss"
            try:
                image = self._grab_pillow(rect) if fallback == "pillow" else self._grab_mss(rect)
                self.backend = fallback
                self.preferred = fallback
                return image
            except Exception:
                raise
        finally:
            elapsed = max(0.0005, time.perf_counter() - started)
            self.latency = self.latency * 0.88 + elapsed * 0.12


class DFolderDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.current = Path("D:/")
        self.title("选择 D 盘文件夹")
        self.geometry("620x470")
        self.minsize(520, 380)
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        ttk.Label(self, text="运行数据保存位置（仅限 D 盘）",
                  font=("Microsoft YaHei UI", 14, "bold")).grid(
                      row=0, column=0, sticky="w", padx=18, pady=(18, 8))
        self.path_var = tk.StringVar()
        ttk.Entry(self, textvariable=self.path_var, state="readonly").grid(
            row=1, column=0, sticky="ew", padx=18, pady=(0, 8))
        frame = ttk.Frame(self)
        frame.grid(row=2, column=0, sticky="nsew", padx=18)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        self.listbox = tk.Listbox(frame, font=("Microsoft YaHei UI", 11),
                                  activestyle="dotbox")
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=scroll.set)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.listbox.bind("<Double-Button-1>", self._open_selected)
        self.listbox.bind("<Return>", self._open_selected)
        buttons = ttk.Frame(self)
        buttons.grid(row=3, column=0, sticky="ew", padx=18, pady=18)
        ttk.Button(buttons, text="上一级", command=self._up).pack(side="left")
        ttk.Button(buttons, text="新建文件夹", command=self._new_folder).pack(
            side="left", padx=8)
        ttk.Button(buttons, text="取消", command=self._cancel).pack(side="right")
        ttk.Button(buttons, text="选择当前文件夹", command=self._choose).pack(
            side="right", padx=8)
        if not Path("D:/").is_dir():
            self.after(50, self._no_drive)
        else:
            self._refresh()
        self.grab_set()
        self.focus_force()

    def _no_drive(self):
        messagebox.showerror(APP_NAME, "未检测到 D 盘。", parent=self)
        self._cancel()

    def _refresh(self):
        valid = d_drive_path(self.current)
        if not valid:
            self.current = Path("D:/")
        else:
            self.current = Path(valid)
        self.path_var.set(str(self.current))
        self.listbox.delete(0, "end")
        try:
            names = sorted((e.name for e in os.scandir(self.current)
                            if e.is_dir(follow_symlinks=False)), key=str.lower)
            for name in names:
                self.listbox.insert("end", name)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法读取该文件夹：\n{exc}", parent=self)

    def _open_selected(self, _event=None):
        selected = self.listbox.curselection()
        if not selected:
            return
        candidate = d_drive_path(self.current / self.listbox.get(selected[0]))
        if candidate and Path(candidate).is_dir():
            self.current = Path(candidate)
            self._refresh()

    def _up(self):
        parent = d_drive_path(self.current.parent)
        if parent:
            self.current = Path(parent)
            self._refresh()

    def _new_folder(self):
        name = simpledialog.askstring("新建文件夹", "文件夹名称：", parent=self)
        if not name:
            return
        name = name.strip()
        if (not name or name.endswith((" ", ".")) or
                any(ch in '<>:"/\\|?*' for ch in name)):
            messagebox.showerror(APP_NAME, "文件夹名称无效。", parent=self)
            return
        target = self.current / name
        if not d_drive_path(target):
            return
        try:
            target.mkdir()
            self.current = target
            self._refresh()
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法创建文件夹：\n{exc}", parent=self)

    def _choose(self):
        chosen = d_drive_path(self.current)
        if chosen:
            self.result = Path(chosen)
            self.grab_release()
            self.destroy()

    def _cancel(self):
        self.result = None
        try:
            self.grab_release()
        except tk.TclError:
            pass
        self.destroy()


class SelectionOverlay(tk.Toplevel):
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.callback = callback
        self.start = None
        self.rect_id = None
        left = user32.GetSystemMetrics(76)
        top = user32.GetSystemMetrics(77)
        width = user32.GetSystemMetrics(78)
        height = user32.GetSystemMetrics(79)
        self.left, self.top = left, top
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.attributes("-alpha", 0.34)
        self.configure(bg="black", cursor="crosshair")
        self.geometry(f"{width}x{height}{left:+d}{top:+d}")
        self.canvas = tk.Canvas(self, bg="black", highlightthickness=0,
                                cursor="crosshair")
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_text(width // 2, 42,
                                text="拖动鼠标，框住要提高的数值",
                                fill="white", font=("Microsoft YaHei UI", 18, "bold"))
        self.canvas.bind("<ButtonPress-1>", self._press)
        self.canvas.bind("<B1-Motion>", self._drag)
        self.canvas.bind("<ButtonRelease-1>", self._release)
        self.bind("<Escape>", lambda _e: self._finish(None))
        self.focus_force()

    def _press(self, event):
        self.start = (event.x, event.y)
        if self.rect_id:
            self.canvas.delete(self.rect_id)
        self.rect_id = self.canvas.create_rectangle(event.x, event.y, event.x, event.y,
                                                    outline="#00ff88", width=3)

    def _drag(self, event):
        if self.start:
            self.canvas.coords(self.rect_id, self.start[0], self.start[1],
                               event.x, event.y)

    def _release(self, event):
        if not self.start:
            return
        x1, y1 = self.start
        x2, y2 = event.x, event.y
        if abs(x2 - x1) < 8 or abs(y2 - y1) < 8:
            return
        rect = (min(x1, x2) + self.left, min(y1, y2) + self.top,
                max(x1, x2) + self.left, max(y1, y2) + self.top)
        self._finish(rect)

    def _finish(self, rect):
        self.withdraw()
        self.update_idletasks()
        self.destroy()
        self.callback(rect)


def client_rect(hwnd):
    rect = RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
        return None
    p1, p2 = POINT(rect.left, rect.top), POINT(rect.right, rect.bottom)
    if not user32.ClientToScreen(hwnd, ctypes.byref(p1)):
        return None
    if not user32.ClientToScreen(hwnd, ctypes.byref(p2)):
        return None
    return p1.x, p1.y, p2.x, p2.y


def window_at(x, y):
    hwnd = user32.WindowFromPoint(POINT(x, y))
    return user32.GetAncestor(hwnd, GA_ROOT) if hwnd else None


def window_title(hwnd):
    length = user32.GetWindowTextLengthW(hwnd)
    buf = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, buf, len(buf))
    return buf.value or "未命名窗口"


def window_class(hwnd):
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, len(buf))
    return buf.value


def window_pid(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return int(pid.value)


def current_roi(hwnd, relative_roi, normalized_roi=None):
    cr = client_rect(hwnd)
    if not cr:
        return None
    cw, ch = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
    if normalized_roi:
        x1 = cr[0] + normalized_roi[0] * cw
        y1 = cr[1] + normalized_roi[1] * ch
        x2 = cr[0] + normalized_roi[2] * cw
        y2 = cr[1] + normalized_roi[3] * ch
    else:
        x1, y1 = cr[0] + relative_roi[0], cr[1] + relative_roi[1]
        x2, y2 = cr[0] + relative_roi[2], cr[1] + relative_roi[3]
    # Clamp to the live client rectangle. This keeps OCR valid if the target is resized
    # or moves between monitors with different DPI scaling.
    x1, x2 = max(cr[0], x1), min(cr[2], x2)
    y1, y2 = max(cr[1], y1), min(cr[3], y2)
    if x2 - x1 < 4 or y2 - y1 < 4:
        return None
    return (x1, y1, x2, y2)


def normalize_digits(text):
    out = []
    for ch in str(text):
        try:
            out.append(str(unicodedata.digit(ch)))
        except (TypeError, ValueError):
            out.append(ch)
    text = "".join(out)
    text = unicodedata.normalize("NFKC", text)
    suffix_tokens = {"Qa": "\ue000", "Qi": "\ue001", "Sx": "\ue002",
                     "Sp": "\ue003", "Oc": "\ue004", "No": "\ue005",
                     "Dc": "\ue006"}
    for suffix, token in suffix_tokens.items():
        text = re.sub(rf"(?<=\d)\s*{suffix}\b", token, text)
    text = (text.replace("−", "-").replace("—", "-").replace("–", "-")
                .replace("＋", "+").replace("，", ",").replace("．", ".")
                .replace("。", ".").replace("·", ".").replace("٫", ".")
                .replace("٬", ",").replace("％", "%").replace("﹪", "%")
                .replace("'", ",").replace("’", ",").replace("`", ",")
                .replace("\u2009", " ").replace("\u202f", " ").replace("\u00a0", " "))
    # OCR confusions that are unusually common inside numeric strings.  Context guards
    # prevent a final B/M/K/T/Q suffix from being destroyed.
    for _ in range(3):
        before = text
        text = re.sub(r"(?<=\d)[OoＤD](?=\d|[.,])|(?<=[.,])[OoＤD](?=\d)", "0", text)
        text = re.sub(r"(?<=\d)[Il|](?=\d|[.,])|(?<=[.,])[Il|](?=\d)", "1", text)
        text = re.sub(r"(?<=\d)[Ss](?=\d)|(?<=[.,])[Ss](?=\d)", "5", text)
        text = re.sub(r"(?<=\d)[Zz](?=\d)|(?<=[.,])[Zz](?=\d)", "2", text)
        text = re.sub(r"(?<=\d)[Gg](?=\d)|(?<=[.,])[Gg](?=\d)", "6", text)
        text = re.sub(r"(?<=\d)[Bb](?=\d)|(?<=[.,])[Bb](?=\d)", "8", text)
        text = re.sub(r"(?<=\d)[Qq](?=\d)|(?<=[.,])[Qq](?=\d)", "9", text)
        if text == before:
            break

    def fix_numeric_run(match):
        run = match.group(0)
        if not any(ch.isdigit() for ch in run):
            return run
        mapping = {"O": "0", "o": "0", "D": "0", "I": "1", "l": "1", "|": "1",
                   "S": "5", "s": "5", "Z": "2", "z": "2", "G": "6", "g": "6",
                   "B": "8", "b": "8", "Q": "9", "q": "9"}
        chars = list(run)
        for i, ch in enumerate(chars):
            if ch not in mapping:
                continue
            if ch in "BbQq" and i == len(chars) - 1:
                continue
            chars[i] = mapping[ch]
        return "".join(chars)

    text = re.sub(r"[0-9OoDIl|SsZzGgBbQq.,]+", fix_numeric_run, text)
    text = re.sub(r"(?<=\d)\s+(?=\d)", "", text)
    for suffix, token in suffix_tokens.items():
        text = text.replace(token, suffix)
    return text


def parse_score(text):
    text = normalize_digits(text)
    # Common short-scale suffixes used by games/dashboards are included in addition to
    # Chinese units.  Long suffixes are ordered first so "Qa" is not consumed as "Q".
    suffix_re = r"(?:Qa|Qi|Sx|Sp|Oc|No|Dc|[kKmMbBtTqQ]|百|千|万|亿|兆)?"
    pattern = re.compile(
        r"[-+]?(?:\d{1,3}(?:[., ]\d{3})+|\d+)(?:[.,]\d+)?"
        r"(?:[eE][-+]?\d+)?\s*" + suffix_re)
    matches = pattern.findall(text)
    if not matches:
        return None
    token = max(matches, key=lambda x: (sum(c.isdigit() for c in x), len(x)))
    clean = token.replace(" ", "")
    suffix = ""
    for candidate in ("Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc",
                      "k", "K", "m", "M", "b", "B", "t", "T", "q", "Q",
                      "百", "千", "万", "亿", "兆"):
        if clean.endswith(candidate):
            suffix = candidate
            clean = clean[:-len(candidate)]
            break
    exp_match = re.search(r"[eE][-+]?\d+$", clean)
    exponent = exp_match.group(0) if exp_match else ""
    mantissa = clean[:-len(exponent)] if exponent else clean
    if "," in mantissa and "." in mantissa:
        decimal = "," if mantissa.rfind(",") > mantissa.rfind(".") else "."
        grouping = "." if decimal == "," else ","
        mantissa = mantissa.replace(grouping, "").replace(decimal, ".")
    elif "," in mantissa:
        parts = mantissa.split(",")
        if len(parts) == 2 and 1 <= len(parts[1]) <= 2:
            mantissa = ".".join(parts)
        elif len(parts) > 2 and not all(len(part) == 3 for part in parts[1:]):
            mantissa = "".join(parts[:-1]) + "." + parts[-1]
        else:
            mantissa = "".join(parts)
    elif mantissa.count(".") > 1:
        parts = mantissa.split(".")
        if all(len(part) == 3 for part in parts[1:]):
            mantissa = "".join(parts)
        else:
            mantissa = "".join(parts[:-1]) + "." + parts[-1]
    try:
        value = float(mantissa + exponent)
    except ValueError:
        return None
    factor = {
        "k": 1e3, "K": 1e3, "m": 1e6, "M": 1e6, "b": 1e9, "B": 1e9,
        "t": 1e12, "T": 1e12, "q": 1e15, "Q": 1e15,
        "Qa": 1e15, "Qi": 1e18, "Sx": 1e21, "Sp": 1e24,
        "Oc": 1e27, "No": 1e30, "Dc": 1e33,
        "百": 1e2, "千": 1e3, "万": 1e4, "亿": 1e8, "兆": 1e12,
    }.get(suffix, 1.0)
    value *= factor
    return value if math.isfinite(value) else None


class ScoreReader:
    """Hardware-adaptive OCR ensemble specialized for numeric UI text.

    It combines preprocessing diversity, crop diversity, model diversity, numeric grammar,
    temporal evidence and an expected-value prior. Strong contradictory OCR evidence always
    wins, so legitimate large jumps are not suppressed.
    """
    def __init__(self, engines, capture, image_ops, image_module, np_module,
                 cv2_module, max_variants=6, hardware=None):
        self.engines = list(engines)
        self.capture = capture
        self.ImageOps = image_ops
        self.Image = image_module
        self.np = np_module
        self.cv2 = cv2_module
        self.hardware = hardware
        self.max_variants = max(2, int(max_variants))
        if hardware is not None:
            self.max_variants = max(self.max_variants, int(hardware.max_ocr_variants))
            self.min_variants = int(hardware.min_ocr_variants)
            self.latency_target = float(hardware.latency_target)
        else:
            self.min_variants = 2
            self.latency_target = 0.60
        self.active_variants = max(self.min_variants, min(self.max_variants, int(max_variants)))
        self.latency = 0.25
        self.confidence_ema = 0.78
        self.fail_streak = 0
        self.last_value = None
        self.last_confidence = 0.0
        self.last_text = ""
        self.recent = []

    @staticmethod
    def _as_float(value, default=0.5):
        try:
            if isinstance(value, (list, tuple)):
                value = value[0] if value else default
            return max(0.0, min(1.0, float(value)))
        except Exception:
            return default

    def _extract_lines(self, result):
        lines = []
        txts = getattr(result, "txts", None)
        scores = getattr(result, "scores", None)
        if txts is not None:
            try:
                texts = list(txts)
            except TypeError:
                texts = [txts]
            try:
                score_list = list(scores) if scores is not None and not isinstance(
                    scores, (str, bytes, float, int)) else []
            except TypeError:
                score_list = []
            for i, item in enumerate(texts):
                conf = score_list[i] if i < len(score_list) else scores
                if isinstance(item, (tuple, list)):
                    text = item[0] if item else ""
                    if len(item) > 1 and (conf is None or not score_list):
                        conf = item[1]
                elif isinstance(item, dict):
                    text = item.get("text") or item.get("txt") or ""
                    conf = item.get("score", conf)
                else:
                    text = item
                if str(text).strip():
                    lines.append((str(text), self._as_float(conf)))
            if lines:
                return lines
        body = result[0] if isinstance(result, (tuple, list)) and len(result) == 2 else result
        if isinstance(body, (tuple, list)):
            for item in body:
                if isinstance(item, (tuple, list)) and len(item) >= 2:
                    text = item[1]
                    conf = item[2] if len(item) > 2 else 0.5
                    if str(text).strip():
                        lines.append((str(text), self._as_float(conf)))
        return lines

    def _pad_and_scale(self, image):
        rgb = image.convert("RGB")
        arr = self.np.asarray(rgb)
        if arr.size:
            edge = self.np.concatenate((arr[0].reshape(-1, 3), arr[-1].reshape(-1, 3),
                                        arr[:, 0].reshape(-1, 3), arr[:, -1].reshape(-1, 3)))
            fill = tuple(int(x) for x in self.np.median(edge, axis=0))
        else:
            fill = (255, 255, 255)
        border = max(4, min(24, int(round(min(rgb.width, rgb.height) * 0.15))))
        rgb = self.ImageOps.expand(rgb, border=border, fill=fill)
        # Tiny UI glyphs benefit from larger normalization than normal document OCR.
        target_h = 96 if rgb.height < 42 else (112 if rgb.height < 72 else
                   128 if rgb.height < 92 else rgb.height)
        scale = max(1.0, min(8.5, target_h / max(1, rgb.height)))
        if scale > 1.03:
            rgb = rgb.resize((max(12, int(round(rgb.width * scale))),
                              max(12, int(round(rgb.height * scale)))),
                             self.Image.Resampling.LANCZOS)
        return rgb

    def _variants(self, image, limit=None):
        rgb = self._pad_and_scale(image)
        hard_limit = self.max_variants if limit is None else max(1, min(self.max_variants, int(limit)))
        yielded = 0

        def emit(arr_or_img, weight, tag):
            nonlocal yielded
            if yielded >= hard_limit:
                return None
            yielded += 1
            if hasattr(arr_or_img, "convert"):
                arr = self.np.asarray(arr_or_img.convert("RGB"))
            else:
                arr = self.np.asarray(arr_or_img)
                if len(arr.shape) == 2:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_GRAY2RGB)
                elif arr.shape[2] == 4:
                    arr = self.cv2.cvtColor(arr, self.cv2.COLOR_RGBA2RGB)
            return arr, weight, tag

        arr = self.np.asarray(rgb)
        gray = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2GRAY)
        try:
            clahe = self.cv2.createCLAHE(clipLimit=2.8, tileGridSize=(4, 4)).apply(gray)
        except Exception:
            clahe = self.cv2.equalizeHist(gray)

        for candidate in (
            emit(rgb, 1.00, "rgb"),
            emit(clahe, 1.10, "clahe"),
        ):
            if candidate:
                yield candidate
        if yielded >= hard_limit:
            return

        blur = self.cv2.GaussianBlur(clahe, (0, 0), 0.85)
        sharp = self.cv2.addWeighted(clahe, 2.05, blur, -1.05, 0)
        item = emit(sharp, 1.09, "sharp")
        if item:
            yield item
        if yielded >= hard_limit:
            return

        # Morphological top-hat / black-hat isolate glowing light text and dark text
        # with outlines or textured backgrounds.
        try:
            kh = max(3, min(15, ((min(gray.shape) // 8) | 1)))
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (kh, kh))
            top = self.cv2.morphologyEx(clahe, self.cv2.MORPH_TOPHAT, kernel)
            black = self.cv2.morphologyEx(clahe, self.cv2.MORPH_BLACKHAT, kernel)
            top = self.cv2.normalize(top, None, 0, 255, self.cv2.NORM_MINMAX)
            black = self.cv2.normalize(black, None, 0, 255, self.cv2.NORM_MINMAX)
            for data, weight, tag in ((top, 1.02, "tophat"), (black, 1.02, "blackhat")):
                item = emit(data, weight, tag)
                if item:
                    yield item
                if yielded >= hard_limit:
                    return
        except Exception:
            pass

        for gamma, weight, tag in ((0.58, 1.01, "gamma-light"),
                                   (1.72, 0.99, "gamma-dark")):
            try:
                lut = self.np.array([((i / 255.0) ** gamma) * 255 for i in range(256)],
                                    dtype="uint8")
                item = emit(self.cv2.LUT(clahe, lut), weight, tag)
                if item:
                    yield item
            except Exception:
                pass
            if yielded >= hard_limit:
                return

        try:
            _t, otsu = self.cv2.threshold(sharp, 0, 255,
                                          self.cv2.THRESH_BINARY + self.cv2.THRESH_OTSU)
            if float(otsu.mean()) < 127:
                otsu = 255 - otsu
            item = emit(otsu, 1.01, "otsu")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            block = max(15, (min(gray.shape) // 4) | 1)
            block = min(71, block if block % 2 else block + 1)
            adaptive = self.cv2.adaptiveThreshold(
                clahe, 255, self.cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                self.cv2.THRESH_BINARY, block, 7)
            if float(adaptive.mean()) < 127:
                adaptive = 255 - adaptive
            item = emit(adaptive, 0.97, "adaptive")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        # Color-aware projections rescue counters that have similar luminance to their
        # background but strong chroma contrast.
        try:
            channels = list(self.cv2.split(arr))
            lab = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2LAB)
            channels += [lab[:, :, 1], lab[:, :, 2]]
            channel = max(channels, key=lambda c: float(c.std()))
            channel = self.cv2.normalize(channel, None, 0, 255, self.cv2.NORM_MINMAX)
            item = emit(channel, 0.98, "color")
            if item:
                yield item
        except Exception:
            pass
        if yielded >= hard_limit:
            return

        try:
            hsv = self.cv2.cvtColor(arr, self.cv2.COLOR_RGB2HSV)
            contrast = max((hsv[:, :, 1], hsv[:, :, 2]), key=lambda c: float(c.std()))
            contrast = self.cv2.normalize(contrast, None, 0, 255, self.cv2.NORM_MINMAX)
            item = emit(contrast, 0.95, "hsv")
            if item:
                yield item
        except Exception:
            pass

    @staticmethod
    def _same_value(a, b):
        return abs(a - b) <= max(1e-9, max(abs(a), abs(b), 1.0) * 1e-10)

    @staticmethod
    def _text_quality(text):
        norm = normalize_digits(text).strip()
        if not norm:
            return 0.60
        allowed_suffix = re.compile(r"(?:Qa|Qi|Sx|Sp|Oc|No|Dc|[kKmMbBtTqQ]|百|千|万|亿|兆|%)$")
        core = allowed_suffix.sub("", norm).strip()
        useful = sum(ch.isdigit() or ch in "+-., eE" for ch in core)
        noise = sum(ch.isalpha() for ch in core)
        ratio = useful / max(1, len(core))
        punctuation = sum(ch in "+-.,eE" for ch in core)
        punct_penalty = max(0, punctuation - 4) * 0.035
        return max(0.55, min(1.10, 0.80 + 0.34 * ratio - 0.075 * noise - punct_penalty))

    def _pick(self, candidates, expected=None):
        if not candidates:
            return None, 0.0, ""
        groups = []
        for value, conf, text, weight, source in candidates:
            group = next((g for g in groups if self._same_value(g[0], value)), None)
            evidence = weight * self._text_quality(text) * (0.16 + conf * conf)
            if group is None:
                groups.append([value, evidence, conf, text, 1, {source}])
            else:
                group[1] += evidence
                if conf > group[2]:
                    group[2], group[3] = conf, text
                group[4] += 1
                group[5].add(source)
        for g in groups:
            g[1] += min(0.92, 0.19 * (g[4] - 1))
            g[1] += min(0.34, 0.14 * (len(g[5]) - 1))

            # Temporal history is only a weak prior. It helps resolve 3/8, 5/6 etc. on
            # static counters, but cannot defeat strong multi-view evidence for a real jump.
            temporal = sum(c for v, c in self.recent[-5:] if self._same_value(v, g[0]))
            if temporal:
                g[1] += min(0.16, temporal * 0.035)

            if expected is not None and not self._same_value(g[0], expected):
                scale = max(abs(expected), 1.0)
                jump = abs(g[0] - expected) / scale
                if jump > 100000 and g[4] == 1 and g[2] < 0.88:
                    g[1] -= 0.18
                elif jump > 1000 and g[4] == 1 and g[2] < 0.72:
                    g[1] -= 0.08
            elif expected is not None:
                g[1] += 0.035

            if self.last_value is not None and self.last_confidence >= 0.68:
                if self._same_value(g[0], self.last_value):
                    g[1] += 0.035
                elif g[4] == 1 and g[2] < 0.60:
                    scale = max(abs(self.last_value), 1.0)
                    if abs(g[0] - self.last_value) > scale * 100000:
                        g[1] -= 0.08
        groups.sort(key=lambda g: (g[1], g[2], g[4], len(g[5])), reverse=True)
        best = groups[0]
        margin = best[1] - (groups[1][1] if len(groups) > 1 else 0.0)
        margin_bonus = min(0.13, max(0.0, margin) * 0.047) if best[4] >= 2 else 0.0
        source_bonus = min(0.10, 0.04 * (len(best[5]) - 1))
        confidence = min(0.997, best[2] + 0.055 * (best[4] - 1) + margin_bonus + source_bonus)
        return best[0], confidence, best[3]

    @staticmethod
    def _expanded_rect(rect, ratio=0.06, px=3):
        x1, y1, x2, y2 = map(float, rect)
        w, h = max(1.0, x2 - x1), max(1.0, y2 - y1)
        dx, dy = max(px, w * ratio), max(px, h * ratio)
        return (x1 - dx, y1 - dy, x2 + dx, y2 + dy)

    def _run_engine(self, engine_name, engine, variants, candidates, model_weight=1.0,
                    det=False, limit=None, expected=None):
        use = variants if limit is None else variants[:limit]
        for index, (arr, weight, tag) in enumerate(use):
            try:
                result = engine(arr, use_det=bool(det), use_cls=False, use_rec=True)
                lines = self._extract_lines(result)
                for text, conf in lines:
                    value = parse_score(text)
                    if value is not None:
                        candidates.append((value, conf, text,
                                           weight * model_weight * (0.93 if det else 1.0),
                                           f"{engine_name}:{tag}:{'det' if det else 'rec'}"))
                # Detection can split a single counter into several boxes. Re-join in
                # reading order as an additional hypothesis instead of discarding pieces.
                if len(lines) > 1:
                    joined = "".join(t for t, _c in lines)
                    value = parse_score(joined)
                    if value is not None:
                        conf = sum(c for _t, c in lines) / len(lines)
                        candidates.append((value, conf, joined, weight * model_weight * 0.82,
                                           f"{engine_name}:{tag}:joined"))
                if not det and index >= 1:
                    tentative = self._pick(candidates, expected)
                    support = sum(1 for v, _c, _t, _w, _s in candidates
                                  if tentative[0] is not None and self._same_value(v, tentative[0]))
                    if support >= 3 and tentative[1] >= 0.95:
                        break
            except Exception:
                continue

    def _dynamic_budget(self):
        budget = int(self.active_variants)
        target = self.latency_target
        if self.latency > target * 2.4:
            budget -= 3
        elif self.latency > target * 1.55:
            budget -= 2
        elif self.latency > target * 1.18:
            budget -= 1
        elif self.latency < target * 0.62 and self.confidence_ema < 0.90:
            budget += 1
        if self.fail_streak:
            budget += min(3, self.fail_streak)
        if self.confidence_ema < 0.68:
            budget += 1
        if self.hardware is not None:
            avail = _available_memory()
            if avail < max(1024 ** 3, self.hardware.ram * 0.10):
                budget = min(budget, self.min_variants)
        return max(self.min_variants, min(self.max_variants, budget))

    def _retune(self, success, confidence):
        self.confidence_ema = self.confidence_ema * 0.86 + float(confidence) * 0.14
        if success:
            self.fail_streak = 0
        else:
            self.fail_streak = min(5, self.fail_streak + 1)
        target = self.latency_target
        if self.latency > target * 1.45 and self.active_variants > self.min_variants:
            self.active_variants -= 1
        elif (self.latency < target * 0.72 and self.confidence_ema < 0.88 and
              self.active_variants < self.max_variants):
            self.active_variants += 1
        elif self.fail_streak >= 2 and self.active_variants < self.max_variants:
            self.active_variants += 1

    def read(self, rect, expected=None):
        started = time.perf_counter()
        best = (None, 0.0, "")
        try:
            image = self.capture.grab(rect)
            if image.width < 4 or image.height < 4:
                self._retune(False, 0.0)
                return best
            budget = self._dynamic_budget()
            variants = list(self._variants(image, budget))
            candidates = []
            if not self.engines:
                self._retune(False, 0.0)
                return best
            primary_name, primary_engine, primary_weight = self.engines[0]
            self._run_engine(primary_name, primary_engine, variants, candidates,
                             primary_weight, det=False, expected=expected)
            best = self._pick(candidates, expected)

            # Progressive crop expansion handles selections that clip a leading sign,
            # suffix, decimal point, or anti-aliased edge. Wider passes are uncertainty-only.
            if best[0] is None or best[1] < 0.88:
                for ratio, weight in ((0.055, 0.96), (0.12, 0.90)):
                    try:
                        expanded = self.capture.grab(self._expanded_rect(rect, ratio=ratio,
                                                                         px=4 if ratio < 0.1 else 7))
                        more = list(self._variants(expanded, max(2, min(budget, 5))))
                        self._run_engine(primary_name, primary_engine, more, candidates,
                                         primary_weight * weight, det=False, expected=expected)
                        best = self._pick(candidates, expected)
                        if best[0] is not None and best[1] >= 0.93:
                            break
                    except Exception:
                        continue

            if len(self.engines) > 1 and (best[0] is None or best[1] < 0.92):
                for engine_name, engine, model_weight in self.engines[1:]:
                    self._run_engine(engine_name, engine, variants, candidates,
                                     model_weight, det=False, limit=max(2, min(5, budget)),
                                     expected=expected)
                    best = self._pick(candidates, expected)
                    if best[0] is not None and best[1] >= 0.94:
                        break

            if best[0] is None or best[1] < 0.64:
                self._run_engine(primary_name, primary_engine, variants, candidates,
                                 primary_weight, det=True, limit=max(1, min(3, budget)),
                                 expected=expected)
                best = self._pick(candidates, expected)

            if best[0] is not None and best[1] >= 0.44:
                self.last_value, self.last_confidence, self.last_text = best
                self.recent.append((best[0], best[1]))
                if len(self.recent) > 8:
                    self.recent = self.recent[-8:]
                self._retune(True, best[1])
            else:
                self._retune(False, best[1])
            return best
        finally:
            elapsed = max(0.001, time.perf_counter() - started)
            self.latency = self.latency * 0.82 + elapsed * 0.18

class EscapeHook:
    def __init__(self, stop_event):
        self.stop_event = stop_event
        self.ready = threading.Event()
        self.hooked = False
        self.thread_id = 0
        self.thread = None
        self.hook = None
        self.callback = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        self.ready.wait(2)
        return self.hooked

    def _run(self):
        self.thread_id = kernel32.GetCurrentThreadId()
        proc_type = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM)

        def low_level_proc(code, message, data):
            if code >= 0:
                info = ctypes.cast(data, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                if info.vkCode == VK_ESCAPE and message in (
                        WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP):
                    self.stop_event.set()
                    return 1
            return user32.CallNextHookEx(self.hook, code, message, data)

        self.callback = proc_type(low_level_proc)
        self.hook = user32.SetWindowsHookExW(WH_KEYBOARD_LL,
                                             ctypes.cast(self.callback, ctypes.c_void_p),
                                             kernel32.GetModuleHandleW(None), 0)
        self.hooked = bool(self.hook)
        self.ready.set()
        if not self.hook:
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def close(self):
        deadline = time.monotonic() + 1.5
        while user32.GetAsyncKeyState(VK_ESCAPE) & 0x8000 and time.monotonic() < deadline:
            time.sleep(0.03)
        if self.thread_id:
            user32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
        if self.thread and self.thread is not threading.current_thread():
            self.thread.join(timeout=1)


KEY_ACTIONS = {
    "key:UP": 0x26, "key:DOWN": 0x28, "key:LEFT": 0x25, "key:RIGHT": 0x27,
    "key:W": 0x57, "key:A": 0x41, "key:S": 0x53, "key:D": 0x44,
    "key:SPACE": 0x20, "key:E": 0x45, "key:F": 0x46,
    "key:Q": 0x51, "key:R": 0x52, "key:T": 0x54, "key:Y": 0x59,
    "key:Z": 0x5A, "key:X": 0x58, "key:C": 0x43, "key:V": 0x56,
    "key:ENTER": 0x0D, "key:TAB": 0x09,
}


def tap_key(vk, duration=0.075):
    if vk == VK_ESCAPE:
        return
    user32.keybd_event(vk, 0, 0, 0)
    try:
        time.sleep(duration)
    finally:
        user32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)


def click_point(x, y):
    old = POINT()
    user32.GetCursorPos(ctypes.byref(old))
    user32.SetCursorPos(int(x), int(y))
    user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    try:
        time.sleep(0.055)
    finally:
        user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    time.sleep(0.025)
    user32.SetCursorPos(old.x, old.y)


class Learner:
    """Contextual reinforcement learner with transfer, sequence planning and uncertainty."""
    INVERSES = {
        "key:UP": "key:DOWN", "key:DOWN": "key:UP",
        "key:LEFT": "key:RIGHT", "key:RIGHT": "key:LEFT",
        "key:W": "key:S", "key:S": "key:W", "key:A": "key:D", "key:D": "key:A",
        "key:Q": "key:E", "key:E": "key:Q",
    }

    def __init__(self, state_file):
        self.state_file = state_file
        self.stats = {}
        self.contexts = {}
        self.families = {}
        self.pairs = {}
        self.triples = {}
        self.sequences = {}
        self.steps = 0
        self.best = None
        self.last_action = None
        self.prev_action = None
        self.last_reward = 0.0
        self.positive = 0
        self.history = []
        self.atomic_trace = []
        self.recent = {}
        self.action_trace = []
        try:
            data = json.loads(state_file.read_text(encoding="utf-8"))
            self.stats = data.get("stats", {})
            self.contexts = data.get("contexts", {})
            self.families = data.get("families", {})
            self.pairs = data.get("pairs", {})
            self.triples = data.get("triples", {})
            self.sequences = data.get("sequences", {}) if isinstance(data.get("sequences", {}), dict) else {}
            self.steps = int(data.get("steps", 0))
            self.best = data.get("best")
            self.positive = int(data.get("positive", 0))
            self.recent = data.get("recent", {}) if isinstance(data.get("recent", {}), dict) else {}
        except Exception:
            pass

    @staticmethod
    def _value(stat):
        return float(stat.get("q", 0.0)), int(stat.get("n", 0)), float(stat.get("v", 0.0))

    @staticmethod
    def _update(table, key, target, weight=1.0):
        stat = table.setdefault(key, {"n": 0, "q": 0.0, "v": 0.0, "good": 0, "bad": 0})
        stat["n"] = int(stat.get("n", 0)) + 1
        old = float(stat.get("q", 0.0))
        n = stat["n"]
        # Keep adapting after long sessions; UI rules can change while the app is running.
        rate = max(0.035, 1.0 / min(n, 32))
        sample = float(target) * float(weight)
        new = old + rate * (sample - old)
        stat["q"] = new
        err = sample - new
        stat["v"] = float(stat.get("v", 0.0)) * 0.91 + err * err * 0.09
        if sample > 0.035:
            stat["good"] = int(stat.get("good", 0)) + 1
        elif sample < -0.035:
            stat["bad"] = int(stat.get("bad", 0)) + 1

    @staticmethod
    def _context_key(state, action):
        return f"{state}>{action}"

    @staticmethod
    def _macro_parts(action):
        if not isinstance(action, str) or not action.startswith("macro:"):
            return (action,)
        parts = tuple(x for x in action[6:].split("|") if x and not x.startswith("macro:"))
        return parts if parts else ()

    @classmethod
    def _make_macro(cls, parts):
        flat = []
        for action in parts:
            flat.extend(cls._macro_parts(action))
        flat = [x for x in flat if x]
        if len(flat) < 2:
            return flat[0] if flat else None
        return "macro:" + "|".join(flat[:3])

    @staticmethod
    def _state_families(state):
        visual = re.search(r"p([0-9a-f]{16})e([0-9a-f]{8})c(\d+)l([0-9a-f]+)", state)
        semantic = re.search(r":t([udf]):g(\d+):s(\d+):m(-?\d+)", state)
        if not semantic:
            return []
        trend, gap, stale, magnitude = semantic.groups()
        mag = int(magnitude)
        mag_bucket = max(-4, min(10, mag // 2))
        keys = [f"sem:t{trend}:g{gap}:m{mag_bucket}",
                f"stale:t{trend}:s{min(4, int(stale))}"]
        if visual:
            phash, ehash, color, layout = visual.groups()
            for i in range(4):
                band = phash[i * 4:(i + 1) * 4]
                keys.append(f"p{i}:{band}:t{trend}:g{min(3, int(gap))}:c{color}")
            keys.append(f"e0:{ehash[:4]}:t{trend}:l{layout[:2]}")
            keys.append(f"e1:{ehash[4:]}:t{trend}:l{layout[-2:]}")
        return keys

    def _family_value(self, state, action):
        weighted_q = 0.0
        weight_sum = 0.0
        variance = 0.0
        total_n = 0
        good = bad = 0
        for family in self._state_families(state):
            stat = self.families.get(f"{family}>{action}", {})
            q, n, v = self._value(stat)
            if not n:
                continue
            w = min(4.2, math.log1p(n) + 0.55)
            weighted_q += q * w
            variance += v * w
            weight_sum += w
            total_n += n
            good += int(stat.get("good", 0))
            bad += int(stat.get("bad", 0))
        if not weight_sum:
            return 0.0, 0, 0.0, 0, 0
        return weighted_q / weight_sum, total_n, variance / weight_sum, good, bad

    def _future_value(self, state, actions=None):
        best = 0.0
        iterable = actions or []
        if not iterable:
            prefix = f"{state}>"
            iterable = [k[len(prefix):] for k in self.contexts if k.startswith(prefix)]
        for action in iterable:
            q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, _fv, _fg, _fb = self._family_value(state, action)
            if n or fn:
                blended = q if n and not fn else fq if fn and not n else 0.70 * q + 0.30 * fq
                best = max(best, blended)
        return best

    def expand_actions(self, actions, state, stagnant, limit=5):
        """Add proven short plans without exploding the action search space."""
        base = list(dict.fromkeys(a for a in actions if a and not a.startswith("macro:")))
        if not base or limit <= 0:
            return base
        allowed = set(base)
        ranked = []

        for sequence, stat in self.sequences.items():
            parts = tuple(sequence.split("|"))
            if not 2 <= len(parts) <= 3 or not all(p in allowed for p in parts):
                continue
            q, n, v = self._value(stat)
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            success = (good + 1.0) / (good + bad + 2.0)
            threshold_n = 2 if stagnant > 24 else 3
            threshold_q = 0.02 if stagnant > 38 else 0.08
            if n >= threshold_n and q > threshold_q and success >= 0.53:
                score = q + 0.18 * (success - 0.5) + min(0.12, math.log1p(n) * 0.025)
                score -= min(0.10, math.sqrt(max(0.0, v)) * 0.025)
                ranked.append((score, self._make_macro(parts)))

        # If a single action is very reliable, planning a repeat can beat re-deciding
        # after every frame and handles games that reward sustained/tapped inputs.
        for action in base:
            q, n, v = self._value(self.stats.get(action, {}))
            stat = self.stats.get(action, {})
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            success = (good + 1.0) / (good + bad + 2.0)
            if n >= 5 and q > 0.16 and success >= 0.62:
                score = q + 0.12 * success - min(0.08, math.sqrt(max(0.0, v)) * 0.02)
                ranked.append((score, self._make_macro((action, action))))
                if n >= 12 and q > 0.34 and success >= 0.72:
                    ranked.append((score * 0.94, self._make_macro((action, action, action))))

        out = list(base)
        seen = set(out)
        for _score, macro in sorted(ranked, reverse=True):
            if macro and macro not in seen:
                out.append(macro)
                seen.add(macro)
                if len(out) >= len(base) + limit:
                    break
        return out

    def choose(self, actions, state, stagnant):
        if not actions:
            return None
        epsilon = max(0.035, 0.25 * math.exp(-self.steps / 1350.0))
        if stagnant > 15:
            epsilon = max(epsilon, 0.22)
        if stagnant > 32:
            epsilon = max(epsilon, 0.38)
        if stagnant > 54:
            epsilon = max(epsilon, 0.56)
        if random.random() < epsilon:
            weights = []
            for action in actions:
                _q, n, _v = self._value(self.contexts.get(self._context_key(state, action), {}))
                _fq, fn, _fv, _fg, _fb = self._family_value(state, action)
                gq, gn, _gv = self._value(self.stats.get(action, {}))
                stat = self.stats.get(action, {})
                bad, good = int(stat.get("bad", 0)), int(stat.get("good", 0))
                risk = 1.0
                if gn >= 8 and bad > good * 2 + 2 and gq < -0.08:
                    risk = 0.22
                if action.startswith("macro:"):
                    risk *= 0.82
                weights.append(risk / math.sqrt(n + fn * 0.12 + gn * 0.08 + 1.0))
            total = sum(weights)
            if total > 0:
                pick = random.random() * total
                for action, weight in zip(actions, weights):
                    pick -= weight
                    if pick <= 0:
                        return action
            return actions[-1]

        total = max(3, self.steps + 2)
        best_action, best_value = None, -float("inf")
        inverse = self.INVERSES.get(self.last_action) if self.last_reward < -0.08 else None
        for action in actions:
            gq, gn, gv = self._value(self.stats.get(action, {}))
            cq, cn, cv = self._value(self.contexts.get(self._context_key(state, action), {}))
            fq, fn, fv, fgood, fbad = self._family_value(state, action)
            pq, pn, _ = self._value(self.pairs.get(f"{self.last_action}>{action}", {}))
            tq, tn, _ = self._value(
                self.triples.get(f"{self.prev_action}>{self.last_action}>{action}", {}))

            if cn:
                base = 0.39 * gq + 0.46 * cq + 0.15 * fq
            elif fn:
                base = 0.53 * gq + 0.47 * fq
            else:
                base = gq
            value = base
            if self.last_action:
                value += 0.22 * pq
            if self.prev_action and self.last_action:
                value += 0.10 * tq

            stat = self.stats.get(action, {})
            good = int(stat.get("good", 0)) + fgood
            bad = int(stat.get("bad", 0)) + fbad
            success = (good + 1.0) / (good + bad + 2.0)
            # Thompson sample makes uncertainty useful without permanently preferring
            # noisy actions, unlike a pure optimistic UCB rule.
            try:
                sampled_success = random.betavariate(good + 1.0, bad + 1.0)
            except Exception:
                sampled_success = success
            value += 0.18 * (success - 0.5) + 0.10 * (sampled_success - 0.5)

            n_eff = gn * 0.30 + cn + fn * 0.13 + pn * 0.15 + tn * 0.07
            value += 0.49 * math.sqrt(math.log(total + 1.0) / (n_eff + 1.0))
            variance = max(0.0, gv + cv + fv)
            value += min(0.17, 0.055 * math.sqrt(variance))
            # But heavily sampled high-variance actions get a small robustness penalty.
            if n_eff > 8:
                value -= min(0.14, 0.024 * math.sqrt(variance))

            recent = self.recent.get(action, {})
            if recent:
                age = max(0, self.steps - int(recent.get("step", self.steps)))
                value += float(recent.get("r", 0.0)) * 0.26 * math.exp(-age / 105.0)

            if gn >= 7 and bad > good * 2 + 2 and gq < -0.10:
                value -= min(1.05, 0.080 * (bad - good))
            if cn == 0 and fn == 0:
                value += 0.085
            if inverse and action == inverse:
                value += min(0.42, 0.15 + abs(self.last_reward) * 0.08)
            if action.startswith("macro:") and gn < 2:
                value -= 0.06

            recent_count = self.action_trace[-7:].count(action)
            if recent_count >= 3 and float(recent.get("r", 0.0)) <= 0.02:
                value -= 0.10 * (recent_count - 2)
            value += random.random() * 1e-6
            if value > best_value:
                best_action, best_value = action, value
        return best_action

    def learn(self, action, before, after, state, next_state, confidence=1.0, actions=None):
        delta = after - before
        reference = max(1.0, abs(before) * 0.0025)
        reward = math.asinh(delta / reference) if delta else 0.0
        reward *= max(0.36, min(1.0, float(confidence)))
        reward = max(-8.0, min(8.0, reward))
        future = self._future_value(next_state, actions)
        contextual_target = reward + 0.32 * future
        self._update(self.stats, action, reward)
        self._update(self.contexts, self._context_key(state, action), contextual_target)
        for family in self._state_families(state):
            self._update(self.families, f"{family}>{action}", contextual_target, 0.80)
        if self.last_action:
            self._update(self.pairs, f"{self.last_action}>{action}", reward, 0.90)
        if self.prev_action and self.last_action:
            self._update(self.triples,
                         f"{self.prev_action}>{self.last_action}>{action}", reward, 0.78)

        parts = self._macro_parts(action)
        if len(parts) > 1:
            for part in parts:
                self._update(self.stats, part, reward / max(1.0, math.sqrt(len(parts))), 0.48)

        # Eligibility-style credit assignment handles delayed gains and losses. Negative
        # credit decays faster so one bad delayed observation does not poison a whole plan.
        if abs(reward) > 0.045:
            decay = 0.43 if reward > 0 else 0.29
            for age, item in enumerate(reversed(self.history[-6:]), start=1):
                old_action, old_state = item
                credit = reward * (decay ** age)
                self._update(self.stats, old_action, credit, 0.58)
                self._update(self.contexts, self._context_key(old_state, old_action), credit, 0.64)
                for family in self._state_families(old_state):
                    self._update(self.families, f"{family}>{old_action}", credit, 0.46)

        # Mine short successful/failed trajectories. Only atomic actions are stored so
        # macros never recursively contain other macros.
        for part in parts:
            if part:
                self.atomic_trace.append(part)
        if len(self.atomic_trace) > 14:
            self.atomic_trace = self.atomic_trace[-14:]
        if abs(reward) > 0.035:
            for length in (2, 3):
                if len(self.atomic_trace) >= length:
                    sequence = "|".join(self.atomic_trace[-length:])
                    weight = 0.92 if length == 2 else 0.78
                    self._update(self.sequences, sequence, reward, weight)

        self.history.append((action, state))
        if len(self.history) > 12:
            self.history = self.history[-12:]
        self.prev_action = self.last_action
        self.last_action = action
        self.last_reward = reward
        self.steps += 1
        self.action_trace.append(action)
        if len(self.action_trace) > 20:
            self.action_trace = self.action_trace[-20:]
        old_recent = self.recent.get(action, {})
        old_r = float(old_recent.get("r", 0.0))
        self.recent[action] = {"r": old_r * 0.66 + reward * 0.34, "step": self.steps}
        if len(self.recent) > 150:
            keep = sorted(self.recent.items(), key=lambda kv: int(kv[1].get("step", 0)),
                          reverse=True)[:150]
            self.recent = dict(keep)
        if delta > 0:
            self.positive += 1
        if self.best is None or after > self.best:
            self.best = after
        return delta, reward

    def action_quality(self, action, state=None):
        gq = self._value(self.stats.get(action, {}))[0]
        if not state:
            return gq
        cq, cn, _ = self._value(self.contexts.get(self._context_key(state, action), {}))
        fq, fn, _fv, _fg, _fb = self._family_value(state, action)
        if cn:
            return 0.56 * cq + 0.29 * gq + 0.15 * fq
        if fn:
            return 0.57 * gq + 0.43 * fq
        return gq

    def preferred_actions(self, prefix="", limit=8):
        ranked = []
        for action, stat in self.stats.items():
            if action.startswith("macro:"):
                continue
            if prefix and not action.startswith(prefix):
                continue
            q, n, _ = self._value(stat)
            good, bad = int(stat.get("good", 0)), int(stat.get("bad", 0))
            success = (good + 1) / (good + bad + 2)
            if n >= 2 and q > -0.08 and success >= 0.32:
                ranked.append((q + min(0.2, math.log1p(n) * 0.02) + success * 0.05, action))
        ranked.sort(reverse=True)
        return [action for _score, action in ranked[:limit]]

    @staticmethod
    def _trim(table, limit):
        if len(table) <= limit:
            return table
        ranked = sorted(table.items(),
                        key=lambda kv: (int(kv[1].get("n", 0)),
                                        abs(float(kv[1].get("q", 0.0)))), reverse=True)
        return dict(ranked[:limit])

    def save(self):
        self.contexts = self._trim(self.contexts, 18000)
        self.families = self._trim(self.families, 14000)
        self.pairs = self._trim(self.pairs, 5200)
        self.triples = self._trim(self.triples, 6200)
        self.sequences = self._trim(self.sequences, 6000)
        data = {"version": 6, "steps": self.steps, "best": self.best,
                "positive": self.positive, "stats": self.stats,
                "contexts": self.contexts, "families": self.families,
                "pairs": self.pairs, "triples": self.triples,
                "sequences": self.sequences, "recent": self.recent}
        temp = self.state_file.with_suffix(".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                        encoding="utf-8")
        os.replace(temp, self.state_file)

class ValueAI:
    def __init__(self, root):
        self.root = root
        self.events = queue.Queue()
        self.storage = None
        self.data_dir = None
        self.runtime_dir = None
        self.hardware = None
        self.reader = None
        self.capture = None
        self.cv2 = None
        self.np = None
        self.target_hwnd = None
        self.target_pid = None
        self.target_title = ""
        self.relative_roi = None
        self.normalized_roi = None
        self.stop_event = threading.Event()
        self.hook = None
        self.worker = None
        self.last_summary = ""
        self._visual_cache = "v0"
        self._build_ui()
        self.root.after(80, self._choose_storage)
        self.root.after(100, self._poll)

    def _build_ui(self):
        self.root.title(APP_NAME)
        self.root.geometry("640x430")
        self.root.resizable(False, False)
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        outer = ttk.Frame(self.root, padding=28)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text=APP_NAME, font=("Microsoft YaHei UI", 22, "bold")).pack()
        ttk.Label(outer, text="把屏幕上的数值作为奖励，让 AI 自主学习有效操作",
                  font=("Microsoft YaHei UI", 10)).pack(pady=(6, 22))
        self.path_var = tk.StringVar(value="等待选择 D 盘文件夹")
        ttk.Label(outer, textvariable=self.path_var, wraplength=570,
                  foreground="#555555").pack(fill="x")
        self.progress = ttk.Progressbar(outer, mode="indeterminate", length=550)
        self.progress.pack(pady=(12, 18))
        row = ttk.Frame(outer)
        row.pack(pady=4)
        self.value_button = ttk.Button(row, text="数值", state="disabled",
                                       command=self._select_value, width=18)
        self.value_button.pack(side="left", padx=8, ipady=13)
        self.confirm_button = ttk.Button(row, text="确认", state="disabled",
                                         command=self._start, width=18)
        self.confirm_button.pack(side="left", padx=8, ipady=13)
        self.selection_var = tk.StringVar(value="尚未选择数值")
        ttk.Label(outer, textvariable=self.selection_var,
                  font=("Microsoft YaHei UI", 11, "bold")).pack(pady=(20, 8))
        self.status_var = tk.StringVar(value="")
        ttk.Label(outer, textvariable=self.status_var, wraplength=570,
                  justify="center").pack()
        ttk.Label(outer,
                  text="运行后按 ESC 立即停止。AI 仅操作数值所属窗口；请勿用于含支付或不可逆操作的窗口。",
                  wraplength=570, foreground="#8a3b12", justify="center").pack(
                      side="bottom", pady=(18, 0))

    def _choose_storage(self):
        dialog = DFolderDialog(self.root)
        self.root.wait_window(dialog)
        if not dialog.result:
            self.root.destroy()
            return
        self.storage = dialog.result
        try:
            self.data_dir = self.storage / DATA_DIR_NAME
            self.data_dir.mkdir(parents=True, exist_ok=True)
            self.hardware = HardwareProfile(self.storage)
            arch = (os.environ.get("PROCESSOR_ARCHITECTURE") or "64bit").lower().replace(" ", "")
            version = f"py{sys.version_info.major}{sys.version_info.minor}-{arch}"
            self.runtime_dir = self.data_dir / f"runtime-{version}-{self.hardware.tag}"
            for path in (self.runtime_dir, self.data_dir / "缓存",
                         self.data_dir / "临时文件"):
                path.mkdir(parents=True, exist_ok=True)
            os.chdir(self.data_dir)
        except OSError as exc:
            messagebox.showerror(APP_NAME, f"无法在所选文件夹写入数据：\n{exc}", parent=self.root)
            self.root.destroy()
            return
        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{self.hardware.summary()}")
        self.status_var.set("正在按本机硬件准备视觉识别组件，请稍候……")
        self.progress.start(12)
        threading.Thread(target=self._prepare_runtime, daemon=True).start()

    def _prepare_runtime(self):
        cache = self.data_dir / "缓存"
        temp = self.data_dir / "临时文件"
        marker = self.runtime_dir / f".ready-runtime-v6-{RAPIDOCR_VERSION}"
        try:
            env = os.environ.copy()
            directed = {
                "PIP_CACHE_DIR": cache / "pip", "TMP": temp, "TEMP": temp,
                "XDG_CACHE_HOME": cache, "HF_HOME": cache / "huggingface",
                "RAPIDOCR_HOME": cache / "rapidocr",
                "MPLCONFIGDIR": cache / "matplotlib", "NUMBA_CACHE_DIR": cache / "numba",
                "PYTHONPYCACHEPREFIX": cache / "pycache",
            }
            for key, value in directed.items():
                Path(value).mkdir(parents=True, exist_ok=True)
                env[key] = str(value)
                os.environ[key] = str(value)
            model_root = cache / "rapidocr_models"
            model_root.mkdir(parents=True, exist_ok=True)
            env["PYTHONUTF8"] = "1"
            env["PYTHONIOENCODING"] = "utf-8"
            env["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)
            env["OMP_WAIT_POLICY"] = "PASSIVE"
            env["ORT_LOG_SEVERITY_LEVEL"] = "3"
            sys.pycache_prefix = str(cache / "pycache")
            if str(self.runtime_dir) not in sys.path:
                sys.path.insert(0, str(self.runtime_dir))

            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            if marker.exists():
                required = ("rapidocr", "onnxruntime", "cv2", "PIL", "mss")
                if not all((self.runtime_dir / name).exists() for name in required):
                    try:
                        marker.unlink()
                    except OSError:
                        pass

            def install(packages):
                command = [sys.executable, "-m", "pip", "install", "--upgrade",
                           "--prefer-binary", "--disable-pip-version-check",
                           "--no-warn-script-location", "--target", str(self.runtime_dir)]
                if self.hardware.disk_free < 5 * GIB:
                    command.append("--no-cache-dir")
                command += list(packages)
                last = None
                for attempt in range(2):
                    run = subprocess.run(command, env=env, stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True,
                                         encoding="utf-8", errors="replace",
                                         creationflags=creationflags)
                    last = run
                    if run.returncode == 0:
                        return
                    if attempt == 0:
                        time.sleep(0.8)
                tail = "\n".join((last.stdout if last else "").splitlines()[-18:])
                raise RuntimeError(tail or "pip 安装失败")

            if not marker.exists():
                backend_pkg = ("onnxruntime-directml>=1.18,<2" if self.hardware.want_dml
                               else "onnxruntime>=1.18,<2")
                try:
                    install([f"rapidocr=={RAPIDOCR_VERSION}", backend_pkg, MSS_SPEC])
                except Exception:
                    if not self.hardware.want_dml:
                        raise
                    # Some older/virtual/remote Windows GPU stacks cannot load the DML
                    # wheel. Recreate the isolated runtime and continue on CPU.
                    shutil.rmtree(self.runtime_dir, ignore_errors=True)
                    self.runtime_dir.mkdir(parents=True, exist_ok=True)
                    self.hardware.want_dml = False
                    self.hardware.backend = "cpu"
                    install([f"rapidocr=={RAPIDOCR_VERSION}", "onnxruntime>=1.18,<2", MSS_SPEC])

            importlib.invalidate_caches()
            from PIL import Image, ImageGrab, ImageOps
            import cv2
            import numpy as np
            import onnxruntime as ort
            try:
                import mss
            except Exception:
                mss = None
            from rapidocr import (EngineType, LangDet, LangRec, ModelType,
                                  OCRVersion, RapidOCR)

            model_map = {"tiny": ModelType.TINY, "small": ModelType.SMALL,
                         "medium": ModelType.MEDIUM}
            rec_model = model_map.get(self.hardware.rec_model, ModelType.SMALL)
            det_model = model_map.get(self.hardware.det_model, ModelType.SMALL)

            def make_params(use_dml=False, version=OCRVersion.PPOCRV6,
                            rec_size=None, det_size=None, threads=None):
                thread_count = max(1, int(threads or self.hardware.ocr_threads))
                return {
                    "Global.text_score": 0.14,
                    "Global.use_preprocess_img": True,
                    "Global.use_vertical_padding": True,
                    "Global.min_height": 26,
                    "Global.width_height_ratio": 18,
                    "Global.min_side_len": 26,
                    "Global.max_side_len": 2200,
                    "Global.model_root_dir": str(model_root),
                    "Det.engine_type": EngineType.ONNXRUNTIME,
                    "Det.lang_type": LangDet.CH,
                    "Det.model_type": det_size or det_model,
                    "Det.ocr_version": version,
                    "Rec.engine_type": EngineType.ONNXRUNTIME,
                    "Rec.lang_type": LangRec.CH,
                    "Rec.model_type": rec_size or rec_model,
                    "Rec.ocr_version": version,
                    "EngineConfig.onnxruntime.intra_op_num_threads": thread_count,
                    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
                    "EngineConfig.onnxruntime.enable_cpu_mem_arena": self.hardware.ram >= 8 * GIB,
                    "EngineConfig.onnxruntime.use_dml": bool(use_dml),
                }

            probe = np.full((96, 360, 3), 248, dtype="uint8")
            cv2.putText(probe, "987654.321K", (10, 68), cv2.FONT_HERSHEY_SIMPLEX,
                        1.65, (18, 18, 18), 3, cv2.LINE_AA)

            def build_and_benchmark(use_dml, threads=None):
                engine = RapidOCR(params=make_params(use_dml=use_dml, threads=threads))
                # Warm-up includes graph optimization and provider initialization.
                warmups = 1 if self.hardware.tier == "low" else 2
                for _ in range(warmups):
                    engine(probe, use_det=False, use_cls=False, use_rec=True)
                timings = []
                samples = 2 if self.hardware.tier == "low" else 3
                for _ in range(samples):
                    t0 = time.perf_counter()
                    engine(probe, use_det=False, use_cls=False, use_rec=True)
                    timings.append(time.perf_counter() - t0)
                timings.sort()
                return engine, timings[len(timings) // 2]

            # Tune ORT CPU parallelism on the actual machine. More threads are often
            # slower for tiny recognition models, especially on hybrid-core CPUs.
            thread_candidates = {1, self.hardware.ocr_threads}
            if self.hardware.logical_cpus >= 4:
                thread_candidates.add(min(2, self.hardware.logical_cpus))
            if self.hardware.logical_cpus >= 8:
                thread_candidates.add(max(2, min(self.hardware.ocr_threads,
                                                  self.hardware.logical_cpus // 3)))
            if self.hardware.tier == "low":
                thread_candidates = {1, self.hardware.ocr_threads}
            best_cpu = None
            best_cpu_time = float("inf")
            best_threads = self.hardware.ocr_threads
            for threads in sorted(thread_candidates):
                try:
                    engine, elapsed = build_and_benchmark(False, threads)
                    if elapsed < best_cpu_time:
                        if best_cpu is not None:
                            del best_cpu
                        best_cpu, best_cpu_time, best_threads = engine, elapsed, threads
                    else:
                        del engine
                except Exception:
                    continue
            if best_cpu is None:
                best_cpu, best_cpu_time = build_and_benchmark(False, self.hardware.ocr_threads)
            self.hardware.ocr_threads = int(best_threads)
            os.environ["OMP_NUM_THREADS"] = str(self.hardware.ocr_threads)

            available = set(ort.get_available_providers())
            dml_possible = self.hardware.want_dml and "DmlExecutionProvider" in available
            primary = best_cpu
            self.hardware.backend = "cpu"
            if dml_possible:
                try:
                    dml_engine, dml_time = build_and_benchmark(True, max(1, min(2, best_threads)))
                    # Keep DirectML only when it wins a real recognition benchmark.
                    if dml_time <= best_cpu_time * 1.06:
                        primary = dml_engine
                        self.hardware.backend = "dml"
                        del best_cpu
                    else:
                        del dml_engine
                except Exception:
                    pass

            engines = [("ocrv6", primary, 1.0)]
            if self.hardware.ensemble:
                try:
                    # A second OCR generation is deliberately different rather than a
                    # duplicate model. It is queried only when OCRv6 evidence is weak.
                    alt_params = make_params(
                        use_dml=(self.hardware.backend == "dml"),
                        version=OCRVersion.PPOCRV5,
                        rec_size=ModelType.MOBILE,
                        det_size=ModelType.MOBILE)
                    alt = RapidOCR(params=alt_params)
                    alt(probe, use_det=False, use_cls=False, use_rec=True)
                    engines.append(("ocrv5", alt, 0.96))
                except Exception:
                    pass

            marker.write_text("ok", encoding="ascii")
            self.capture = ScreenCapture(mss, ImageGrab, Image)
            try:
                self.capture.benchmark()
            except Exception:
                pass
            self.hardware.capture_backend = self.capture.backend
            self.cv2, self.np = cv2, np
            self.reader = ScoreReader(engines, self.capture, ImageOps, Image, np, cv2,
                                      max_variants=self.hardware.ocr_variants,
                                      hardware=self.hardware)
            self.events.put(("runtime_ready", self.hardware.summary()))
        except Exception as exc:
            try:
                marker.unlink(missing_ok=True)
            except Exception:
                pass
            self.events.put(("error", "视觉识别组件准备失败", str(exc)))

    def _select_value(self):
        self.confirm_button.configure(state="disabled")
        self.selection_var.set("请在屏幕上框选数值")
        self.root.withdraw()
        self.root.after(180, lambda: SelectionOverlay(self.root, self._selection_done))

    def _selection_done(self, rect):
        if not rect:
            self.root.deiconify()
            self.selection_var.set("尚未选择数值")
            return
        self.root.after(140, lambda: self._identify_target(rect))

    def _identify_target(self, rect):
        center = ((rect[0] + rect[2]) // 2, (rect[1] + rect[3]) // 2)
        hwnd = window_at(*center)
        cr = client_rect(hwnd) if hwnd else None
        if (not hwnd or not cr or window_pid(hwnd) == os.getpid() or
                not (cr[0] <= center[0] < cr[2] and cr[1] <= center[1] < cr[3])):
            self.root.deiconify()
            messagebox.showerror(APP_NAME, "无法确定该数值所属的目标窗口，请重新框选。",
                                 parent=self.root)
            self.selection_var.set("尚未选择数值")
            return
        self.target_hwnd = hwnd
        self.target_pid = window_pid(hwnd)
        self.target_title = window_title(hwnd)
        if window_class(hwnd) in {"Progman", "WorkerW", "Shell_TrayWnd",
                                   "Shell_SecondaryTrayWnd"}:
            self.root.deiconify()
            messagebox.showerror(APP_NAME, "不能把 Windows 桌面或任务栏作为目标窗口。",
                                 parent=self.root)
            self.selection_var.set("尚未选择数值")
            return
        self.relative_roi = (rect[0] - cr[0], rect[1] - cr[1],
                             rect[2] - cr[0], rect[3] - cr[1])
        cw, ch = max(1, cr[2] - cr[0]), max(1, cr[3] - cr[1])
        self.normalized_roi = (
            max(0.0, min(1.0, (rect[0] - cr[0]) / cw)),
            max(0.0, min(1.0, (rect[1] - cr[1]) / ch)),
            max(0.0, min(1.0, (rect[2] - cr[0]) / cw)),
            max(0.0, min(1.0, (rect[3] - cr[1]) / ch)),
        )
        threading.Thread(target=self._recognize_selection, args=(rect,), daemon=True).start()

    def _recognize_selection(self, rect):
        value, confidence, text = self.reader.read(rect)
        reads = [(value, confidence, text)] if value is not None else []
        extra = 2 if self.hardware.tier == "high" else (1 if self.hardware.tier == "balanced" else 0)
        for _ in range(extra):
            if value is not None and confidence >= 0.93:
                break
            value2, confidence2, text2 = self.reader.read(rect)
            if value2 is not None:
                reads.append((value2, confidence2, text2))
        if reads:
            ranked = []
            for candidate, conf, txt in reads:
                agreement = sum(c for v, c, _t in reads if ScoreReader._same_value(v, candidate))
                ranked.append((agreement + conf * 0.25, conf, candidate, txt))
            ranked.sort(reverse=True)
            _weight, confidence, value, text = ranked[0]
            support = sum(1 for v, _c, _t in reads if ScoreReader._same_value(v, value))
            confidence = min(0.997, confidence + max(0, support - 1) * 0.07)
        else:
            value, confidence, text = None, 0.0, ""
        self.events.put(("selection", value, confidence, text))

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        self.stop_event.clear()
        self.hook = EscapeHook(self.stop_event)
        if not self.hook.start():
            messagebox.showerror(APP_NAME, "无法启用 ESC 紧急停止，因此未启动 AI。",
                                 parent=self.root)
            return
        self.value_button.configure(state="disabled")
        self.confirm_button.configure(state="disabled")
        self.status_var.set("AI 已开启；按 ESC 立即停止")
        self.root.withdraw()
        user32.ShowWindow(self.target_hwnd, 9)
        user32.SetForegroundWindow(self.target_hwnd)
        self.worker = threading.Thread(target=self._run_ai, daemon=True)
        self.worker.start()

    def _profile_file(self):
        # Normalized coordinates make learned experience survive window resizing and
        # moving the same app between displays with different resolutions/DPI.
        quantized_roi = tuple(round(v * 100) for v in (self.normalized_roi or (0, 0, 0, 0)))
        raw = f"{self.target_title}|{window_class(self.target_hwnd)}|{quantized_roi}"
        key = hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:16]
        return self.data_dir / f"学习状态-{key}.json"

    def _target_ready(self):
        if not user32.IsWindow(self.target_hwnd) or not user32.IsWindowVisible(self.target_hwnd):
            return False
        foreground = user32.GetForegroundWindow()
        return foreground == self.target_hwnd and window_pid(foreground) == self.target_pid

    def _click_candidates(self, roi):
        if not roi:
            return []
        cr = client_rect(self.target_hwnd)
        if not cr or cr[2] - cr[0] < 80 or cr[3] - cr[1] < 80:
            return []
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"))
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY)
        except Exception:
            return []
        h, w = gray.shape
        if not h or not w:
            return []
        points = []
        if self.hardware.tier == "high":
            rows, cols = 9, 13
        elif self.hardware.tier == "low":
            rows, cols = 4, 6
        else:
            rows, cols = 7, 10
        fgray = gray.astype("float32")

        # Region salience finds controls even when their borders are subtle.
        for row in range(rows):
            for col in range(cols):
                x1, x2 = col * w // cols, (col + 1) * w // cols
                y1, y2 = row * h // rows, (row + 1) * h // rows
                cell = fgray[y1:y2, x1:x2]
                if cell.size < 16:
                    continue
                edge = (self.np.abs(self.np.diff(cell, axis=0)).mean() +
                        self.np.abs(self.np.diff(cell, axis=1)).mean())
                contrast = float(cell.std())
                points.append((contrast * 0.62 + float(edge) * 1.38,
                               (x1 + x2) / 2 / w, (y1 + y2) / 2 / h))
        points.sort(reverse=True)
        candidates = points[:self.hardware.candidate_limit]

        # Contours target button/input/icon-shaped areas instead of blindly clicking a grid.
        try:
            max_side = 1180 if self.hardware.tier == "high" else (860 if self.hardware.tier == "balanced" else 680)
            scale = min(1.0, max_side / max(w, h))
            small = self.cv2.resize(gray, None, fx=scale, fy=scale,
                                    interpolation=self.cv2.INTER_AREA)
            blur = self.cv2.GaussianBlur(small, (3, 3), 0)
            median = float(self.np.median(blur))
            low = max(24, int(median * 0.45))
            high = min(220, max(low + 40, int(median * 1.25)))
            edges = self.cv2.Canny(blur, low, high)
            kernel = self.cv2.getStructuringElement(self.cv2.MORPH_RECT, (3, 3))
            closed = self.cv2.morphologyEx(edges, self.cv2.MORPH_CLOSE, kernel)
            contours, _ = self.cv2.findContours(closed, self.cv2.RETR_LIST,
                                                 self.cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            sh, sw = small.shape
            for contour in contours:
                x, y, bw, bh = self.cv2.boundingRect(contour)
                area = bw * bh
                if not (42 <= area <= sw * sh * 0.15 and bw >= 7 and bh >= 7):
                    continue
                aspect = bw / max(1.0, bh)
                if not (0.20 <= aspect <= 9.0):
                    continue
                rectangularity = self.cv2.contourArea(contour) / max(1.0, area)
                perimeter = self.cv2.arcLength(contour, True)
                compact = min(1.0, perimeter / max(1.0, 2.0 * (bw + bh)))
                border_score = min(1.2, rectangularity * 1.4 + compact * 0.35)
                score = border_score * 2.5 + min(2.2, math.log1p(area) / 3.8)
                boxes.append((score, (x + bw / 2) / sw, (y + bh / 2) / sh))
            boxes.sort(reverse=True)
            candidates.extend(boxes[:self.hardware.candidate_limit * 2])
        except Exception:
            pass

        # On capable machines, corner density adds icon-like controls that do not have a
        # clean rectangular outline. Corners are quantized later, keeping action count bounded.
        if self.hardware.tier != "low":
            try:
                corners = self.cv2.goodFeaturesToTrack(gray, maxCorners=self.hardware.candidate_limit * 3,
                                                       qualityLevel=0.035, minDistance=max(8, min(w, h) // 55))
                if corners is not None:
                    for pt in corners.reshape(-1, 2):
                        fx, fy = float(pt[0]) / w, float(pt[1]) / h
                        candidates.append((0.85, fx, fy))
            except Exception:
                pass

        # Spatial diversity plus a hardware-dependent coordinate grid gives high-end
        # systems more click precision while preserving old 20x20 learned actions.
        grid = int(self.hardware.mouse_grid)
        result, seen, coarse = [], set(), set()
        for _score, fx, fy in sorted(candidates, reverse=True):
            qx = max(1, min(grid - 1, round(fx * grid)))
            qy = max(1, min(grid - 1, round(fy * grid)))
            x = cr[0] + qx / grid * (cr[2] - cr[0])
            y = cr[1] + qy / grid * (cr[3] - cr[1])
            if roi[0] - 20 <= x <= roi[2] + 20 and roi[1] - 20 <= y <= roi[3] + 20:
                continue
            action = f"mouse:{grid}:{qx}:{qy}"
            cell = (round(qx * 10 / grid), round(qy * 10 / grid))
            if action in seen or (cell in coarse and len(result) >= self.hardware.candidate_limit // 2):
                continue
            result.append(action)
            seen.add(action)
            coarse.add(cell)
            if len(result) >= self.hardware.candidate_limit:
                break
        return result

    def _visual_signature(self, refresh=False):
        if not refresh and self._visual_cache and self._visual_cache != "v0":
            return self._visual_cache
        cr = client_rect(self.target_hwnd)
        if not cr:
            return self._visual_cache or "v0"
        try:
            image = self.capture.grab(cr)
            rgb = self.np.asarray(image.convert("RGB"), dtype="uint8").copy()
            # Reward pixels are masked so changing the selected number does not itself
            # create a new environment identity.
            roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
            if roi:
                x1 = max(0, int(roi[0] - cr[0] - 7))
                y1 = max(0, int(roi[1] - cr[1] - 7))
                x2 = min(rgb.shape[1], int(roi[2] - cr[0] + 7))
                y2 = min(rgb.shape[0], int(roi[3] - cr[1] + 7))
                if x2 > x1 and y2 > y1:
                    fill = self.np.median(rgb.reshape(-1, 3), axis=0).astype("uint8")
                    rgb[y1:y2, x1:x2] = fill
            gray = self.cv2.cvtColor(rgb, self.cv2.COLOR_RGB2GRAY).astype("float32")

            # 64-bit difference hash: unlike a cryptographic digest, Hamming-near values
            # remain visually similar. Learner._state_families uses hash bands as LSH.
            ph = self.cv2.resize(gray, (9, 8), interpolation=self.cv2.INTER_AREA)
            pbits = ph[:, 1:] >= ph[:, :-1]
            pvalue = 0
            for bit in pbits.reshape(-1):
                pvalue = (pvalue << 1) | int(bool(bit))

            # Independent 32-bit edge-layout hash separates screens with similar average
            # brightness but different control/menu geometry.
            sobelx = self.cv2.Sobel(gray, self.cv2.CV_32F, 1, 0, ksize=3)
            sobely = self.cv2.Sobel(gray, self.cv2.CV_32F, 0, 1, ksize=3)
            edge = self.cv2.magnitude(sobelx, sobely)
            eh = self.cv2.resize(edge, (9, 4), interpolation=self.cv2.INTER_AREA)
            ebits = eh[:, 1:] >= eh[:, :-1]
            evalue = 0
            for bit in ebits.reshape(-1):
                evalue = (evalue << 1) | int(bool(bit))

            tiny_rgb = self.cv2.resize(rgb, (4, 3), interpolation=self.cv2.INTER_AREA).astype("float32")
            colorfulness = float((tiny_rgb.max(axis=2) - tiny_rgb.min(axis=2)).mean())
            color_bucket = max(0, min(7, int(colorfulness / 18.0)))

            layout = self.cv2.resize(gray, (4, 3), interpolation=self.cv2.INTER_AREA)
            lm = float(layout.mean())
            layout_value = 0
            for bit in (layout >= lm).reshape(-1):
                layout_value = (layout_value << 1) | int(bool(bit))

            self._visual_cache = (f"p{pvalue:016x}e{evalue:08x}"
                                  f"c{color_bucket}l{layout_value:03x}")
        except Exception:
            pass
        return self._visual_cache or "v0"

    def _state_key(self, score, previous, stagnant, best, refresh_visual=False):
        visual = self._visual_signature(refresh_visual)
        threshold = max(1e-9, abs(previous) * 0.0005)
        delta = score - previous
        trend = "u" if delta > threshold else ("d" if delta < -threshold else "f")
        if best is None or score >= best:
            gap = 0
        else:
            relative_gap = (best - score) / max(1.0, abs(best) * 0.002)
            gap = max(1, min(5, int(math.log1p(max(0.0, relative_gap))) + 1))
        stale = min(6, stagnant // 7)
        magnitude = 0 if score == 0 else max(-6, min(15, int(math.floor(math.log10(abs(score))))))
        return f"{visual}:t{trend}:g{gap}:s{stale}:m{magnitude}"

    def _perform(self, action, quality):
        def perform_atomic(item, allow_repeat=True):
            repeats = 2 if allow_repeat and quality > 1.35 else 1
            for _ in range(repeats):
                if self.stop_event.is_set():
                    return
                if item in KEY_ACTIONS:
                    duration = 0.058
                    if quality > 0.35:
                        duration = 0.090
                    if quality > 1.15:
                        duration = 0.128
                    tap_key(KEY_ACTIONS[item], duration)
                elif item.startswith("mouse:"):
                    try:
                        parts = item.split(":")
                        if len(parts) == 3:  # backward-compatible learned action
                            grid, sx, sy = 20, parts[1], parts[2]
                        elif len(parts) == 4:
                            grid, sx, sy = int(parts[1]), parts[2], parts[3]
                        else:
                            return
                        grid = max(8, min(64, int(grid)))
                        cr = client_rect(self.target_hwnd)
                        if not cr:
                            return
                        x = cr[0] + int(sx) / grid * (cr[2] - cr[0])
                        y = cr[1] + int(sy) / grid * (cr[3] - cr[1])
                        roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
                        if roi and not (roi[0] - 15 <= x <= roi[2] + 15 and
                                        roi[1] - 15 <= y <= roi[3] + 15):
                            click_point(x, y)
                    except Exception:
                        return
                if repeats > 1:
                    time.sleep(0.055)

        if action.startswith("macro:"):
            parts = Learner._macro_parts(action)
            for index, item in enumerate(parts):
                if self.stop_event.is_set() or not self._target_ready():
                    break
                perform_atomic(item, allow_repeat=False)
                if index + 1 < len(parts):
                    pause = 0.045 if self.hardware.tier == "high" else 0.075
                    end = time.monotonic() + pause
                    while time.monotonic() < end and not self.stop_event.is_set():
                        time.sleep(0.012)
            return
        perform_atomic(action, allow_repeat=True)

    def _read_current(self, verify_low_confidence=True, expected=None):
        roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
        if not roi:
            return None, 0.0
        value, confidence, _text = self.reader.read(roi, expected=expected)
        min_conf = 0.28 if self.hardware.verify_reads else 0.34
        if value is None or confidence < min_conf:
            return None, confidence

        catastrophic = False
        if expected is not None:
            scale = max(1.0, abs(expected))
            catastrophic = abs(value - expected) > scale * 100000
        should_verify = (verify_low_confidence and self.hardware.verify_reads and
                         (confidence < 0.72 or catastrophic) and
                         not self.stop_event.is_set())
        if should_verify:
            reads = [(value, confidence)]
            extra = self.hardware.verify_reads + (1 if catastrophic else 0)
            for _ in range(extra):
                value2, confidence2, _text2 = self.reader.read(roi, expected=expected)
                if value2 is not None and confidence2 >= min_conf:
                    reads.append((value2, confidence2))
                if self.stop_event.is_set():
                    break
                if confidence2 >= 0.90 and any(
                        ScoreReader._same_value(value2, v) for v, _c in reads[:-1]):
                    break
            ranked = []
            for candidate, conf in reads:
                support = [c for v, c in reads if ScoreReader._same_value(v, candidate)]
                ranked.append((sum(support) + 0.12 * len(support), max(support),
                               len(support), candidate))
            ranked.sort(reverse=True)
            _weight, best_conf, support, best_value = ranked[0]
            if expected is not None and support == 1:
                scale = max(1.0, abs(expected))
                if abs(best_value - expected) > scale * 100000 and best_conf < 0.94:
                    return None, best_conf
            value = best_value
            confidence = min(0.997, best_conf + 0.065 * max(0, support - 1))
        return value, confidence

    def _adaptive_wait(self, quality=0.0):
        base = self.hardware.settle
        latency = self.reader.latency if self.reader else 0.25
        capture = self.capture.latency if self.capture else 0.02
        delay = base + min(0.34, latency * 0.34 + capture * 0.45)
        if quality > 0.9:
            delay += 0.045
        floor = 0.18 if self.hardware.tier == "high" else 0.22
        end = time.monotonic() + max(floor, min(1.12, delay))
        while time.monotonic() < end and not self.stop_event.is_set():
            time.sleep(0.022)

    def _run_ai(self):
        learner = Learner(self._profile_file())
        last_save = time.monotonic()
        reason = "用户按下 ESC，AI 已关闭"
        try:
            time.sleep(0.60)
            if not self._target_ready():
                reason = "目标窗口未处于前台，AI 已安全停止"
                return
            score, score_conf = self._read_current()
            if score is None:
                reason = "无法读取所选数值，AI 已停止"
                return
            if learner.best is None:
                learner.best = score
            stagnant = 0
            click_actions = []
            failures = 0
            previous_score = score
            state = self._state_key(score, score, stagnant, learner.best, True)
            while not self.stop_event.is_set():
                if not self._target_ready():
                    reason = "目标窗口失去前台焦点，AI 已安全停止"
                    break
                roi = current_roi(self.target_hwnd, self.relative_roi, self.normalized_roi)
                refresh_every = self.hardware.candidate_refresh
                if stagnant > 18:
                    refresh_every = max(3, refresh_every // 3)
                if (learner.steps % refresh_every == 0 or not click_actions):
                    discovered = self._click_candidates(roi)
                    remembered = learner.preferred_actions("mouse:",
                                                           limit=12 if self.hardware.tier == "high" else 8)
                    click_actions = list(dict.fromkeys(remembered + discovered))
                    click_actions = click_actions[:max(10, self.hardware.candidate_limit)]
                actions = list(dict.fromkeys(list(KEY_ACTIONS) + click_actions))
                # After enough evidence, temporarily suppress globally destructive actions.
                # They can re-enter during heavy stagnation so the AI can still adapt if
                # the interface changes later.
                if stagnant < 36:
                    filtered = []
                    for candidate in actions:
                        q, n, _v = learner._value(learner.stats.get(candidate, {}))
                        stat = learner.stats.get(candidate, {})
                        bad = int(stat.get("bad", 0))
                        good = int(stat.get("good", 0))
                        if n >= 10 and q < -0.45 and bad > good * 2 + 3:
                            continue
                        filtered.append(candidate)
                    if filtered:
                        actions = filtered
                refresh_state = learner.steps % self.hardware.state_every == 0
                state = self._state_key(score, previous_score, stagnant, learner.best,
                                        refresh_visual=refresh_state)
                actions = learner.expand_actions(actions, state, stagnant,
                                                 limit=self.hardware.macro_limit)
                action = learner.choose(actions, state, stagnant)
                if not action:
                    reason = "没有可用操作，AI 已停止"
                    break
                before = score
                quality = learner.action_quality(action, state)
                self._perform(action, quality)
                self._adaptive_wait(quality)
                if self.stop_event.is_set():
                    break
                new_score, new_conf = self._read_current(expected=before)
                if new_score is None:
                    failures += 1
                    if failures >= (8 if self.hardware.tier != "low" else 6):
                        reason = "连续无法读取所选数值，AI 已停止"
                        break
                    score = before
                    previous_score = before
                    continue
                failures = 0

                # Some interfaces apply an input with a short delay. On faster machines,
                # a second observation avoids incorrectly teaching the AI that it did nothing.
                tiny = max(1e-9, abs(before) * 1e-10)
                if (abs(new_score - before) <= tiny and self.hardware.tier != "low" and
                        not self.stop_event.is_set()):
                    end = time.monotonic() + min(0.36, 0.12 + self.reader.latency * 0.30)
                    while time.monotonic() < end and not self.stop_event.is_set():
                        time.sleep(0.025)
                    if not self.stop_event.is_set():
                        delayed, delayed_conf = self._read_current(False, expected=before)
                        if delayed is not None and (delayed != before or delayed_conf > new_conf):
                            new_score, new_conf = delayed, delayed_conf

                next_stagnant = 0 if new_score > before else stagnant + (2 if new_score < before else 1)
                next_state = self._state_key(
                    new_score, before, next_stagnant, learner.best,
                    refresh_visual=((learner.steps + 1) % self.hardware.state_every == 0))
                delta, reward = learner.learn(
                    action, before, new_score, state, next_state,
                    confidence=new_conf, actions=actions)
                previous_score, score, score_conf = before, new_score, new_conf
                stagnant = 0 if delta > 0 else next_stagnant

                if time.monotonic() - last_save > self.hardware.save_interval:
                    try:
                        learner.save()
                    except OSError:
                        pass
                    last_save = time.monotonic()
            if self.stop_event.is_set():
                reason = "用户按下 ESC，AI 已关闭"
        except Exception as exc:
            reason = f"AI 因错误停止：{exc}"
        finally:
            try:
                learner.save()
            except Exception:
                pass
            if self.hook:
                self.hook.close()
            summary = (f"{reason}\n当前数值：{score:g}　最高数值：{learner.best:g}　"
                       f"累计学习：{learner.steps} 步　有效提升：{learner.positive} 次") \
                if 'score' in locals() and score is not None else reason
            self.events.put(("stopped", summary))

    def _poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                kind = event[0]
                if kind == "runtime_ready":
                    self.progress.stop()
                    self.progress.configure(mode="determinate", value=100)
                    if self.data_dir:
                        self.path_var.set(f"数据位置：{self.data_dir}\n硬件：{event[1]}")
                    self.status_var.set("准备完成。点击“数值”并框选屏幕上的数字。")
                    self.value_button.configure(state="normal")
                elif kind == "selection":
                    value, _confidence, _text = event[1:]
                    self.root.deiconify()
                    self.root.lift()
                    if value is None:
                        self.selection_var.set("未识别到数值，请重新框选")
                        self.status_var.set("框选范围应只包含数字，并留少量边距。")
                        self.confirm_button.configure(state="disabled")
                    else:
                        shown_title = (self.target_title if len(self.target_title) <= 34
                                       else self.target_title[:33] + "…")
                        self.selection_var.set(f"已选择：{value:g}　目标窗口：{shown_title}")
                        self.status_var.set("点击“确认”后 AI 自动开始；按 ESC 停止。")
                        self.confirm_button.configure(state="normal")
                elif kind == "stopped":
                    self.last_summary = event[1]
                    self.root.deiconify()
                    self.root.lift()
                    self.status_var.set(self.last_summary)
                    self.value_button.configure(state="normal")
                    self.confirm_button.configure(state="normal")
                elif kind == "error":
                    self.progress.stop()
                    self.status_var.set(event[1])
                    messagebox.showerror(event[1], event[2], parent=self.root)
        except queue.Empty:
            pass
        if self.root.winfo_exists():
            self.root.after(100, self._poll)

    def _close(self):
        self.stop_event.set()
        if self.hook:
            self.hook.close()
        self.root.destroy()


def main():
    if os.name != "nt" or sys.maxsize <= 2 ** 32:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(APP_NAME, "本程序仅支持 64 位 Windows 11。")
        root.destroy()
        return
    configure_winapi()
    set_dpi_awareness()
    root = tk.Tk()
    style = ttk.Style(root)
    if "vista" in style.theme_names():
        style.theme_use("vista")
    ValueAI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
