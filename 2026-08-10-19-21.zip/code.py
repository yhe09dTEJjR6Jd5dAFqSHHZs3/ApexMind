import ctypes
from ctypes import wintypes
from array import array
import base64
from collections import Counter, OrderedDict, deque
from dataclasses import dataclass, field
from html.parser import HTMLParser
import hashlib
import ipaddress
import json
import math
import multiprocessing
import os
from pathlib import Path
import queue
import random
import re
import secrets
import shutil
import socket
import sqlite3
import struct
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox
from urllib import parse as urllib_parse
from urllib import request as urllib_request
import uuid
import zlib

# 可选计算加速器：NumPy 只是矩阵计算库，不是第三方 AI 模型；从不自动下载。
# 未安装时完整回退到标准库 array/Python 实现。
try:
    import numpy as _np
except Exception:
    _np = None


APP_NAME = "本地无固定容量上限 AI"
FORMAT_VERSION = 8

# 单文件交付 ≠ 内部耦合。九层架构契约（依赖尽量向下，通过 dataclass/字典快照传递）：
# Platform   : ResourceBudget / Win32 原语 / SharedInputGate
# Perception : AccessibilitySnapshot / AccessibilityReader / Observation / WinIO.capture
# Goal       : TaskDSLNode / GoalCompiler / GoalEngine
# Safety     : SessionCapabilityDomain / SafetyPolicy / hard input gate
# Planner    : WorldModel / ActionPlanner（先生成合法候选，再由 Q 网络排序）
# Learning   : DoubleQNetwork / RewardEngine / MetaCognitiveSleep / SkillManager
# Memory     : LongTermMemory / SQLite tiers / SleepReport / strategy memory
# Runtime    : AgentRuntime / LocalAgent / EscapeWatchdog / worker supervisor
# GUI        : Application

                                      
GLOBAL_W = 24
GLOBAL_H = 14
# 全局保持低分辨率；ROI 本身提高到可辨认 UI 细节的基础分辨率，并可按资源继续建立更高分辨率金字塔。
PATCH_W = 32
PATCH_H = 20
PATCH_COUNT = 3
GLOBAL_FEATURES = GLOBAL_W * GLOBAL_H * 4
PATCH_FEATURES = PATCH_W * PATCH_H * 4 * PATCH_COUNT
UI_FEATURES = 128
OBS_EXTRA = 32
GOAL_FEATURES = 64
MEMORY_FEATURES = 32
BASE_FEATURE_COUNT = GLOBAL_FEATURES + PATCH_FEATURES + UI_FEATURES + OBS_EXTRA + GOAL_FEATURES + MEMORY_FEATURES
# 兼容旧模型/旧经验的基础输入宽度。运行时模型可在此基础上继续扩展输入维度。
FEATURE_COUNT = BASE_FEATURE_COUNT

WAIT, SLEEP, MOVE, CLICK, SCROLL, KEY, TYPE, SKILL = range(8)
ACTION_NAMES = ("等待", "睡眠", "移动", "点击", "滚动", "按键", "输入文本", "调用技能")
ACTION_COUNT = len(ACTION_NAMES)
PARAM_COUNT = 3
PARAM_HEAD_SIZES = (1, 0, 2, 3, 1, 1, 1, 1)
SCHEMA_VERSION = 9
SESSION_LOG_KEEP = 40
SESSION_LOG_SOFT_BYTES = 32 * 1024 * 1024
N_STEP = 3
CHECKPOINT_KEEP = 8
TARGET_SYNC_INTERVAL = 64
MODEL_FILE_NAME = "model.bin"
DATABASE_FILE_NAME = "memory.sqlite3"
MODEL_MAGIC = b"LAI7BIN\0"

# 容量没有设计时的“最终值”。下列只是各类热数据的资源占比和近似字节成本；
# ResourceBudget 会按当时可用 RAM、磁盘和实际延迟持续重算本轮可用容量。
HOT_MEMORY_PROFILE = {
    "episodic_memory": (0.34, 11000), "state_memory": (0.12, 5600),
    "skill_memory": (0.10, 6200), "failure_memory": (0.05, 1500),
    "text_memory": (0.04, 1000), "semantic_knowledge": (0.12, 2600),
    "world_transition": (0.15, 10500), "sleep_report": (0.03, 3600),
    "strategy_memory": (0.05, 2800),
}
SLEEP_ENTER_THRESHOLD = 0.68
SLEEP_WAKE_THRESHOLD = 0.34


def clamp(value, low, high):
    return low if value < low else high if value > high else value


def safe_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


class MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class ResourceBudget:
    """把所有可增长能力绑定到当前资源，而不是绑定到代码中的最终常量。"""

    def __init__(self, data_dir, decision_latency_target=0.16, perception_latency_target=0.28):
        self.data_dir = Path(data_dir)
        self.decision_latency_target = float(decision_latency_target)
        self.perception_latency_target = float(perception_latency_target)
        self.total_ram = 0
        self.available_ram = 0
        self.free_disk = 0
        self.total_disk = 0
        self.decision_latency = 0.0
        self.perception_latency = 0.0
        self.updated_at = 0.0
        self.refresh()

    @staticmethod
    def _ram_status():
        if os.name == "nt":
            try:
                status = MemoryStatusEx()
                status.dwLength = ctypes.sizeof(MemoryStatusEx)
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MemoryStatusEx)]
                kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL
                if kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return int(status.ullTotalPhys), int(status.ullAvailPhys)
            except Exception:
                pass
        try:
            page = int(os.sysconf("SC_PAGE_SIZE"))
            total = page * int(os.sysconf("SC_PHYS_PAGES"))
            available = page * int(os.sysconf("SC_AVPHYS_PAGES"))
            return total, available
        except Exception:
            # 无法读取时只给出保守的本轮预算；这不是容量上限，下次成功读取会自动扩展。
            return 2 * 1024 ** 3, 512 * 1024 ** 2

    def refresh(self, decision_latency=None, perception_latency=None):
        self.total_ram, self.available_ram = self._ram_status()
        try:
            disk = shutil.disk_usage(str(self.data_dir.resolve().anchor or self.data_dir))
            self.total_disk, self.free_disk = int(disk.total), int(disk.free)
        except Exception:
            self.total_disk, self.free_disk = 8 * 1024 ** 3, 512 * 1024 ** 2
        if decision_latency is not None:
            self.decision_latency = max(0.0, safe_float(decision_latency))
        if perception_latency is not None:
            self.perception_latency = max(0.0, safe_float(perception_latency))
        self.updated_at = time.time()
        return self

    def _latency_factor(self, kind="decision"):
        observed = self.perception_latency if kind == "perception" else self.decision_latency
        target = self.perception_latency_target if kind == "perception" else self.decision_latency_target
        if observed <= 1e-9:
            return 1.0
        return clamp(target / observed, 0.08, 2.0)

    @property
    def disk_reserve_bytes(self):
        """资源型磁盘安全线：不限制知识条数，只保证 Windows 始终有可用空间。"""
        return max(10 * 1024 ** 3, int(self.total_disk * 0.08))

    @property
    def storage_pressure(self):
        reserve = max(1, self.disk_reserve_bytes)
        return clamp((reserve - self.free_disk) / float(reserve), 0.0, 1.0)

    def storage_writes_allowed(self, margin_bytes=64 * 1024 ** 2):
        self.refresh()
        return self.free_disk > self.disk_reserve_bytes + max(0, int(margin_bytes))

    def cleanup_regenerable_storage(self):
        """逼近安全线时仅清理可再生成内容：旧日志、旧 checkpoint、临时文件；归档知识不自动删除。"""
        self.refresh()
        if self.free_disk > self.disk_reserve_bytes + 512 * 1024 ** 2:
            return 0
        removed = 0
        candidates = []
        for directory, pattern, keep in ((self.data_dir / "logs", "session_*.jsonl", 4), (self.data_dir / "checkpoints", "model_*.bin", 2)):
            try:
                files = sorted(directory.glob(pattern), key=lambda path: path.stat().st_mtime, reverse=True)
                candidates.extend(files[keep:])
            except Exception:
                pass
        try:
            candidates.extend(self.data_dir.glob("*.tmp"))
        except Exception:
            pass
        for path in candidates:
            try:
                size = path.stat().st_size
                path.unlink()
                removed += int(size)
            except OSError:
                pass
            self.refresh()
            if self.free_disk > self.disk_reserve_bytes + 768 * 1024 ** 2:
                break
        return removed

    def visual_roi_scale(self):
        """按当前资源计算可承担的 ROI 倍率；随资源增长，没有代码写死的最终倍率。"""
        headroom_gib = max(0.0, self.available_ram / float(1024 ** 3))
        latency = self._latency_factor("perception")
        # 对数增长避免一次采样吞掉全部 RAM；更大硬件仍会得到更高倍率。
        return max(1, int(1.0 + math.log2(1.0 + headroom_gib) * max(0.20, latency) * 0.72))

    @property
    def hot_memory_bytes(self):
        ram_budget = max(8 * 1024 ** 2, int(self.available_ram * 0.075))
        disk_budget = max(8 * 1024 ** 2, int(self.free_disk * 0.035))
        return min(ram_budget, disk_budget)

    def memory_limits(self):
        budget = self.hot_memory_bytes
        limits = {}
        for table, (share, estimated_bytes) in HOT_MEMORY_PROFILE.items():
            limits[table] = max(32, int(budget * float(share) / max(1, int(estimated_bytes))))
        # 压缩层随磁盘增加而增大；归档层不自动淘汰。
        compressed_bytes = max(8 * 1024 ** 2, int(self.free_disk * 0.018))
        limits["memory_compressed"] = max(128, int(compressed_bytes / 2400.0))
        limits["recent_working_set"] = max(128, int(math.sqrt(max(1, budget // 1024)) * 5.0))
        return limits

    def growth_amount(self, capability, current, kind="decision"):
        current = max(0, int(current))
        headroom_mib = max(1.0, self.available_ram / float(1024 ** 2))
        disk_gib = max(0.25, self.free_disk / float(1024 ** 3))
        resource_units = max(1, int(math.log2(1.0 + headroom_mib) * math.sqrt(disk_gib)))
        factor = self._latency_factor(kind)
        if factor < 0.45:
            return 0
        scales = {
            "uia_nodes": 3.0, "uia_depth": 0.10, "attention_candidates": 0.35,
            "memory_horizon": 0.50, "planner_breadth": 1.2, "skill_attention": 2.0,
            "adaptive_input": 1.5, "visual_roi_scale": 0.18, "forward_cache_entries": 1.0,
        }
        scale = float(scales.get(str(capability), 1.0))
        proportional = math.sqrt(max(1, current)) * 0.12
        return max(1, int((resource_units * scale + proportional) * min(1.5, factor)))

    def network_document_bytes(self):
        # 用户明确允许的单个文档，大小只由当时资源决定。
        return max(64 * 1024, int(min(self.available_ram * 0.0025, self.free_disk * 0.0008)))

    def forward_cache_entries(self, input_count, hidden_count):
        bytes_per_entry = max(1024, (int(input_count) + int(hidden_count) * 2 + ACTION_COUNT * 4) * 4)
        return max(8, int(self.available_ram * 0.012 / bytes_per_entry))

    def training_batch_size(self, experience_count, evaluation=False):
        base = math.sqrt(max(1, int(experience_count))) * (2.0 if evaluation else 10.0)
        resource_scale = max(0.5, math.log2(1.0 + self.available_ram / float(1024 ** 2)) / 8.0)
        return max(8, int(base * resource_scale))

    def training_updates(self, experience_count):
        latency = self._latency_factor("decision")
        return max(16, int(math.sqrt(max(1, int(experience_count))) * 4.8 * latency))

    def as_dict(self):
        return {
            "total_ram": int(self.total_ram), "available_ram": int(self.available_ram),
            "total_disk": int(self.total_disk), "free_disk": int(self.free_disk),
            "decision_latency": float(self.decision_latency), "perception_latency": float(self.perception_latency),
            "hot_memory_bytes": int(self.hot_memory_bytes), "disk_reserve_bytes": int(self.disk_reserve_bytes),
            "storage_pressure": float(self.storage_pressure), "updated_at": float(self.updated_at),
        }


def compact_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with open(temporary, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def pack_state(values):
    raw = bytes(int(clamp(round(value * 255.0), 0, 255)) for value in values)
    return zlib.compress(raw, 1)


def unpack_state(blob):
    raw = zlib.decompress(blob)
    if len(raw) < BASE_FEATURE_COUNT:
        raise ValueError("长期记忆中的状态维度过短")
    return [value / 255.0 for value in raw]


def normalize_state(values, count, neutral=0.5):
    values = list(values)
    count = int(count)
    if len(values) < count:
        values.extend([float(neutral)] * (count - len(values)))
    elif len(values) > count:
        values = values[:count]
    return values


def pack_parameters(values, mask):
    values = list(values)[:PARAM_COUNT] + [0.5] * max(0, PARAM_COUNT - len(values))
    raw = bytes([int(mask) & 0xFF] + [int(clamp(round(value * 255.0), 0, 255)) for value in values[:PARAM_COUNT]])
    return raw


def unpack_parameters(blob):
    if not blob or len(blob) != PARAM_COUNT + 1:
        return [0.5] * PARAM_COUNT, 0
    return [value / 255.0 for value in blob[1:]], int(blob[0])


def mask_actions(actions):
    mask = 0
    for action in actions:
        mask |= 1 << int(action)
    return mask


def actions_from_mask(mask):
    return [index for index in range(ACTION_COUNT) if int(mask) & (1 << index)]


def semantic_units(text):
    text = str(text or "").lower()
    units = []
    for token in re.findall(r"[a-z0-9][a-z0-9_.:/@+\-]*|[\u3400-\u9fff]+", text):
        if token not in units:
            units.append(token)
        if re.fullmatch(r"[\u3400-\u9fff]+", token):
            if len(token) <= 8:
                units.extend(token)
            for size in (2, 3):
                if len(token) >= size:
                    units.extend(token[index:index + size] for index in range(len(token) - size + 1))
    result = []
    seen = set()
    for unit in units:
        if unit and unit not in seen:
            seen.add(unit)
            result.append(unit)
    return result


def hashed_features(items, count):
    values = [0.0] * count
    for position, item in enumerate(items):
        for token in semantic_units(item):
            digest = hashlib.blake2s(token.encode("utf-8", "ignore"), digest_size=8).digest()
            index = int.from_bytes(digest[:4], "little") % count
            sign = 1.0 if digest[4] & 1 else -1.0
            weight = 1.0 / math.sqrt(1.0 + position * 0.15)
            values[index] += sign * weight
    return [0.5 + 0.5 * math.tanh(value * 0.7) for value in values]


def similarity(first, second):
    left = set(semantic_units(first))
    right = set(semantic_units(second))
    if not left or not right:
        return 0.0
    return len(left & right) / max(1, len(left | right))


def control_locator(record):
    if not record:
        return {}
    locator = {
        "control_type": str(record.get("control_type", "")),
        "automation_id": str(record.get("automation_id", "")),
        "name": str(record.get("name", "")),
        "class_name": str(record.get("class_name", "")),
    }
    runtime_id = record.get("runtime_id")
    if runtime_id:
        try:
            locator["runtime_id"] = [int(value) for value in runtime_id]
        except Exception:
            pass
    return {key: value for key, value in locator.items() if value not in ("", [], None)}


def locator_score(locator, record):
    if not locator or not record or record.get("offscreen") or not record.get("enabled"):
        return -1.0
    expected_type = str(locator.get("control_type", ""))
    current_type = str(record.get("control_type", ""))
    if expected_type and current_type and expected_type != current_type:
        return -1.0
    score = 0.0
    expected_runtime = tuple(locator.get("runtime_id") or ())
    current_runtime = tuple(record.get("runtime_id") or ())
    if expected_runtime and current_runtime and expected_runtime == current_runtime:
        score += 2.8
    expected_id = str(locator.get("automation_id", ""))
    current_id = str(record.get("automation_id", ""))
    if expected_id and current_id:
        score += 2.2 if expected_id == current_id else similarity(expected_id, current_id) * 0.35
    expected_name = str(locator.get("name", ""))
    current_name = str(record.get("name", ""))
    if expected_name and current_name:
        score += similarity(expected_name, current_name) * 1.8
        if expected_name.lower() == current_name.lower():
            score += 1.2
    expected_class = str(locator.get("class_name", ""))
    current_class = str(record.get("class_name", ""))
    if expected_class and current_class and expected_class == current_class:
        score += 0.7
    if expected_type and current_type == expected_type:
        score += 0.8
    return score


def resolve_control(observation, locator, minimum=1.0):
    if observation is None or not locator:
        return None
    best = None
    best_score = float(minimum)
    for record in observation.accessibility.records:
        score = locator_score(locator, record)
        if score > best_score:
            best_score, best = score, record
    return best


def control_at_point(observation, x, y, radius=0.11):
    best = None
    best_distance = float(radius)
    for record in observation.accessibility.records:
        if record.get("offscreen") or not record.get("enabled") or record.get("password"):
            continue
        distance = math.hypot(float(record.get("x_norm", 0.5)) - float(x), float(record.get("y_norm", 0.5)) - float(y))
        if distance < best_distance:
            best_distance, best = distance, record
    return best


@dataclass
class ActionCommand:
    kind: int
    parameters: dict = field(default_factory=dict)
    label: str = ""
    parameter_targets: list = field(default_factory=lambda: [0.5] * PARAM_COUNT)
    parameter_mask: int = 0
    required_capabilities: list = field(default_factory=list)
    capability_reason: str = ""

    def payload(self):
        payload = {"kind": int(self.kind), "parameters": self.parameters, "label": self.label}
        if self.required_capabilities:
            payload["required_capabilities"] = sorted(set(str(value) for value in self.required_capabilities if value))
        if self.capability_reason:
            payload["capability_reason"] = str(self.capability_reason)
        return payload

    @classmethod
    def from_payload(cls, source):
        kind = int(source.get("kind", WAIT))
        if kind < 0 or kind >= ACTION_COUNT:
            raise ValueError("技能包含未知动作类型")
        return cls(
            kind, dict(source.get("parameters", {})), str(source.get("label", "")),
            required_capabilities=list(source.get("required_capabilities") or []),
            capability_reason=str(source.get("capability_reason", "")),
        )

    def declare(self, capabilities=None, reason=""):
        self.required_capabilities = sorted(set(
            list(self.required_capabilities) + [str(value) for value in (capabilities or []) if value]
        ))
        if reason:
            self.capability_reason = str(reason)
        return self

    def fingerprint(self):
        return hashlib.blake2s(compact_json(self.payload()).encode("utf-8"), digest_size=10).hexdigest()


class DoubleQNetwork:
    def __init__(self, input_count=FEATURE_COUNT, layer_sizes=None, capacities=None):
        self.input_count = int(input_count)
        self.layer_sizes = [int(value) for value in (layer_sizes or [48, 32]) if int(value) > 0]
        if not self.layer_sizes:
            self.layer_sizes = [48, 32]
        self.action_count = ACTION_COUNT
        self.parameter_count = PARAM_COUNT
        self.param_head_sizes = list(PARAM_HEAD_SIZES)
        self.sleep_count = 0
        self.training_steps = 0
        self.target_syncs = 0
        self.accepted_growth = 0
        self.rejected_growth = 0
        self.reward_average = 0.0
        self.loss_average = 0.0
        self.progress_average = 0.0
        self.safety_average = 0.0
        self.capacities = {
            "uia_depth": 4, "uia_nodes": 128, "attention_candidates": 8,
            "memory_horizon": 16, "planner_breadth": 48, "skill_attention": 128,
            "adaptive_input": max(0, self.input_count - BASE_FEATURE_COUNT),
            "visual_roi_scale": 2, "forward_cache_entries": 32, "observation_cache_ms": 120,
        }
        if capacities:
            for key, value in capacities.items():
                if key in self.capacities:
                    # adaptive_input=0 是合法状态；其余容量至少为 1。
                    minimum = 0 if key == "adaptive_input" else 1
                    self.capacities[key] = max(minimum, int(value))
        source = random.Random(secrets.randbits(256))
        self.layers = []
        self.biases = []
        self.layer_modes = []
        previous = self.input_count
        for size in self.layer_sizes:
            scale = math.sqrt(2.0 / max(1, previous))
            self.layers.append([array("f", (source.uniform(-scale, scale) for _ in range(previous))) for _ in range(size)])
            self.biases.append(array("f", (source.uniform(-0.01, 0.01) for _ in range(size))))
            self.layer_modes.append("tanh")
            previous = size
        output_size = self.layer_sizes[-1]
        scale = math.sqrt(2.0 / max(1, output_size))
        self.wq = [array("f", (source.uniform(-scale, scale) for _ in range(output_size))) for _ in range(self.action_count)]
        self.bq = array("f", [0.0] * self.action_count)
        self.wp = []
        self.bp = []
        for action, count in enumerate(self.param_head_sizes):
            local_scale = scale * 0.35
            self.wp.append([array("f", (source.uniform(-local_scale, local_scale) for _ in range(output_size))) for _ in range(count)])
            self.bp.append(array("f", [0.0] * count))
        self._np_cache = {}
        self._forward_cache = OrderedDict()
        self._training_mode = False
        self.compute_backend = "numpy" if _np is not None else "stdlib-array"
        # 初始化目标网络不是一次训练同步，不计入统计。
        self.sync_target(count_stat=False)

    @property
    def hidden_count(self):
        return sum(self.layer_sizes)

    @property
    def depth(self):
        return len(self.layer_sizes)

    @staticmethod
    def _activate(inputs, rows, biases):
        result = []
        for row, bias in zip(rows, biases):
            total = float(bias)
            for weight, value in zip(row, inputs):
                total += float(weight) * value
            result.append(math.tanh(total))
        return result

    @staticmethod
    def _linear(inputs, rows, biases):
        result = []
        for row, bias in zip(rows, biases):
            total = float(bias)
            for weight, value in zip(row, inputs):
                total += float(weight) * value
            result.append(total)
        return result

    def _invalidate_accelerator(self, target=None):
        if not hasattr(self, "_np_cache"):
            self._np_cache = {}
        if not hasattr(self, "_forward_cache"):
            self._forward_cache = OrderedDict()
        self._forward_cache.clear()
        if target is None:
            self._np_cache.clear()
        else:
            self._np_cache.pop("target" if target else "online", None)

    def _numpy_pack(self, target=False):
        if _np is None:
            return None
        key = "target" if target else "online"
        cached = self._np_cache.get(key)
        if cached is not None:
            return cached
        layers = self.tlayers if target else self.layers
        biases = self.tbiases if target else self.biases
        modes = self.tlayer_modes if target else self.layer_modes
        qrows = self.twq if target else self.wq
        qbias = self.tbq if target else self.bq
        packed = {
            "layers": [_np.asarray(rows, dtype=_np.float32) for rows in layers],
            "biases": [_np.asarray(values, dtype=_np.float32) for values in biases],
            "modes": list(modes),
            "q": _np.asarray(qrows, dtype=_np.float32),
            "qb": _np.asarray(qbias, dtype=_np.float32),
        }
        if not target:
            packed["p"] = [(_np.asarray(self.wp[action], dtype=_np.float32) if self.param_head_sizes[action] else None) for action in range(self.action_count)]
            packed["pb"] = [(_np.asarray(self.bp[action], dtype=_np.float32) if self.param_head_sizes[action] else None) for action in range(self.action_count)]
        self._np_cache[key] = packed
        return packed

    def _forward_numpy(self, state, target=False):
        packed = self._numpy_pack(target)
        value = _np.asarray(normalize_state(state, self.input_count), dtype=_np.float32)
        activations = [value.tolist()]
        for matrix, bias, mode in zip(packed["layers"], packed["biases"], packed["modes"]):
            value = matrix @ value + bias
            if mode != "identity":
                value = _np.tanh(value)
            activations.append(value.tolist())
        q = (packed["q"] @ value + packed["qb"]).tolist()
        if target:
            return activations, [float(x) for x in q], {}
        parameters = {}
        for action, count in enumerate(self.param_head_sizes):
            if not count:
                parameters[action] = []
                continue
            raw = packed["p"][action] @ value + packed["pb"][action]
            raw = _np.clip(raw, -20.0, 20.0)
            parameters[action] = (1.0 / (1.0 + _np.exp(-raw))).astype(float).tolist()
        return activations, [float(x) for x in q], parameters

    def _encode(self, state, target=False):
        state = normalize_state(state, self.input_count)
        rows_list = self.tlayers if target else self.layers
        bias_list = self.tbiases if target else self.biases
        modes = self.tlayer_modes if target else self.layer_modes
        activations = [state]
        value = state
        for rows, biases, mode in zip(rows_list, bias_list, modes):
            linear = self._linear(value, rows, biases)
            value = linear if mode == "identity" else [math.tanh(total) for total in linear]
            activations.append(value)
        return activations

    def forward(self, state, target=False):
        training = bool(getattr(self, "_training_mode", False))
        normalized = normalize_state(state, self.input_count)
        cache_key = None
        if not training:
            raw = array("f", normalized)
            if sys.byteorder != "little":
                raw.byteswap()
            cache_key = (bool(target), hashlib.blake2s(raw.tobytes(), digest_size=12).digest())
            cached = self._forward_cache.get(cache_key)
            if cached is not None:
                self._forward_cache.move_to_end(cache_key)
                return cached
        if _np is not None and not training:
            result = self._forward_numpy(normalized, target)
        else:
            activations = self._encode(normalized, target)
            hidden = activations[-1]
            if target:
                result = (activations, self._linear(hidden, self.twq, self.tbq), {})
            else:
                q_values = self._linear(hidden, self.wq, self.bq)
                parameters = {}
                for action, count in enumerate(self.param_head_sizes):
                    if not count:
                        parameters[action] = []
                        continue
                    raw_values = self._linear(hidden, self.wp[action], self.bp[action])
                    parameters[action] = [1.0 / (1.0 + math.exp(-clamp(value, -20.0, 20.0))) for value in raw_values]
                result = (activations, q_values, parameters)
        if cache_key is not None:
            self._forward_cache[cache_key] = result
            limit = max(1, int(self.capacities.get("forward_cache_entries", 32)))
            while len(self._forward_cache) > limit:
                self._forward_cache.popitem(last=False)
        return result

    def parameters_for(self, state, action):
        return self.forward(state)[2].get(int(action), [])

    def choose(self, state, allowed, exploration, action_bias=None):
        if not allowed:
            return WAIT, [0.5] * self.param_head_sizes[WAIT]
        _, values, parameters = self.forward(state)
        biases = action_bias or {}
        adjusted = {index: values[index] + float(biases.get(index, 0.0)) for index in allowed}
        if random.random() < exploration:
            action = random.choice(list(allowed))
        else:
            best = max(adjusted.values())
            action = random.choice([index for index in allowed if adjusted[index] >= best - 1e-12])
        return action, list(parameters.get(action, []))

    def sync_target(self, count_stat=True):
        self.tlayers = [[array("f", row) for row in rows] for rows in self.layers]
        self.tbiases = [array("f", values) for values in self.biases]
        self.tlayer_modes = list(self.layer_modes)
        self.twq = [array("f", row) for row in self.wq]
        self.tbq = array("f", self.bq)
        self._invalidate_accelerator(target=True)
        if count_stat:
            self.target_syncs += 1

    def train_one(self, item, learning_rate=0.0011, gamma=0.94, allow_target_sync=True):
        # 无论训练是否抛错都恢复快速推理；否则一次坏样本会永久关闭 NumPy 路径。
        self._training_mode = True
        try:
            return self._train_one_impl(item, learning_rate, gamma, allow_target_sync)
        finally:
            self._training_mode = False
            self._invalidate_accelerator(target=False)

    def _train_one_impl(self, item, learning_rate=0.0011, gamma=0.94, allow_target_sync=True):
        # 训练修改 Python array 权重；训练期使用标准库路径。
        state = item["state"]
        next_state = item["next_state"]
        action = int(item["action"])
        importance = clamp(float(item.get("importance", 1.0)), 0.15, 1.5)
        activations, outputs, parameter_map = self.forward(state)
        hidden = activations[-1]
        next_allowed = actions_from_mask(item.get("next_mask", 0))
        future = 0.0
        if next_allowed:
            _, online_next, _ = self.forward(next_state)
            selected = max(next_allowed, key=lambda index: online_next[index])
            _, target_next, _ = self.forward(next_state, target=True)
            future = target_next[selected]
        target_value = float(item["reward"]) + gamma ** max(1, int(item.get("n_steps", 1))) * future
        error = outputs[action] - target_value
        q_gradient = clamp(error, -1.0, 1.0) * importance
        old_q_weights = array("f", self.wq[action])
        for index in range(len(hidden)):
            self.wq[action][index] -= learning_rate * q_gradient * hidden[index]
        self.bq[action] -= learning_rate * q_gradient
        hidden_gradients = [q_gradient * float(old_q_weights[index]) for index in range(len(hidden))]
        targets = list(item.get("parameters", []))
        mask = int(item.get("parameter_mask", 0))
        positive_signal = clamp(float(item.get("goal_reward", 0.0)) * 1.6 + max(0.0, float(item["reward"])), 0.0, 1.0)
        parameter_loss = 0.0
        predictions = parameter_map.get(action, [])
        if positive_signal > 0.015:
            for parameter_index in range(min(len(predictions), len(targets))):
                if not mask & (1 << parameter_index):
                    continue
                prediction = predictions[parameter_index]
                local_error = prediction - clamp(float(targets[parameter_index]), 0.0, 1.0)
                raw_gradient = clamp(local_error * prediction * (1.0 - prediction) * positive_signal * importance, -0.5, 0.5)
                old_weights = array("f", self.wp[action][parameter_index])
                for hidden_index in range(len(hidden)):
                    self.wp[action][parameter_index][hidden_index] -= learning_rate * raw_gradient * hidden[hidden_index]
                    hidden_gradients[hidden_index] += raw_gradient * float(old_weights[hidden_index])
                self.bp[action][parameter_index] -= learning_rate * raw_gradient
                parameter_loss += abs(local_error)
        gradient = hidden_gradients
        for layer_index in range(len(self.layers) - 1, -1, -1):
            current = activations[layer_index + 1]
            previous = activations[layer_index]
            previous_gradient = [0.0] * len(previous)
            rows = self.layers[layer_index]
            for neuron_index in range(len(rows)):
                derivative = 1.0 if self.layer_modes[layer_index] == "identity" else (1.0 - current[neuron_index] * current[neuron_index])
                local = clamp(gradient[neuron_index] * derivative, -1.0, 1.0)
                row = rows[neuron_index]
                old_row = array("f", row)
                for input_index, value in enumerate(previous):
                    row[input_index] -= learning_rate * local * value
                    previous_gradient[input_index] += local * float(old_row[input_index])
                self.biases[layer_index][neuron_index] -= learning_rate * local
            gradient = previous_gradient
        self.training_steps += 1
        absolute = abs(error) + parameter_loss * 0.08
        self.loss_average = absolute if self.training_steps == 1 else self.loss_average * 0.995 + absolute * 0.005
        if allow_target_sync and self.training_steps % TARGET_SYNC_INTERVAL == 0:
            self.sync_target()
        return absolute

    def td_error(self, item, gamma=0.94):
        _, outputs, _ = self.forward(item["state"])
        next_allowed = actions_from_mask(item.get("next_mask", 0))
        future = 0.0
        if next_allowed:
            _, online_next, _ = self.forward(item["next_state"])
            selected = max(next_allowed, key=lambda index: online_next[index])
            _, target_next, _ = self.forward(item["next_state"], target=True)
            future = target_next[selected]
        expected = float(item["reward"]) + gamma ** max(1, int(item.get("n_steps", 1))) * future
        return abs(outputs[int(item["action"])] - expected)

    def validation_loss(self, items):
        return 0.0 if not items else sum(self.td_error(item) for item in items) / len(items)

    def benchmark(self, items):
        if not items:
            return {"score": 0.5, "td": 0.5, "action": 0.5, "parameter": 0.5, "safety": 0.5, "preference": 0.5}
        loss = self.validation_loss(items)
        td_score = 1.0 / (1.0 + loss)
        action_scores = []
        parameter_scores = []
        safety_scores = []
        positive_values = []
        negative_values = []
        for item in items:
            _, q_values, parameter_map = self.forward(item["state"])
            action = int(item["action"])
            allowed = actions_from_mask(item.get("current_mask", 0))
            candidates = list(dict.fromkeys(([action] + allowed)))
            if float(item.get("goal_reward", 0.0)) > 0.08 or float(item.get("reward", 0.0)) > 0.18:
                best = max(q_values[index] for index in candidates)
                gap = best - q_values[action]
                action_scores.append(clamp(1.0 - gap, 0.0, 1.0))
                targets = list(item.get("parameters", []))
                predictions = parameter_map.get(action, [])
                mask = int(item.get("parameter_mask", 0))
                local = []
                for index in range(min(len(targets), len(predictions))):
                    if mask & (1 << index):
                        local.append(1.0 - abs(float(targets[index]) - float(predictions[index])))
                if local:
                    parameter_scores.append(sum(local) / len(local))
                positive_values.append(max(q_values[index] for index in candidates))
            if float(item.get("safety_penalty", 0.0)) > 0.18 or float(item.get("reward", 0.0)) < -0.30:
                alternatives = [q_values[index] for index in candidates if index != action]
                margin = (max(alternatives) if alternatives else 0.0) - q_values[action]
                safety_scores.append(clamp(0.5 + margin * 0.5, 0.0, 1.0))
                negative_values.append(q_values[action])
        action_score = sum(action_scores) / len(action_scores) if action_scores else 0.5
        parameter_score = sum(parameter_scores) / len(parameter_scores) if parameter_scores else 0.5
        safety_score = sum(safety_scores) / len(safety_scores) if safety_scores else 0.5
        if positive_values and negative_values:
            preference_score = clamp(0.5 + (sum(positive_values) / len(positive_values) - sum(negative_values) / len(negative_values)) * 0.15, 0.0, 1.0)
        else:
            preference_score = 0.5
        score = td_score * 0.28 + action_score * 0.26 + parameter_score * 0.16 + safety_score * 0.20 + preference_score * 0.10
        return {"score": score, "td": td_score, "action": action_score, "parameter": parameter_score, "safety": safety_score, "preference": preference_score}

    def snapshot(self):
        return {
            "input_count": self.input_count, "layer_sizes": list(self.layer_sizes), "layer_modes": list(self.layer_modes),
            "layers": [[array("f", row) for row in rows] for rows in self.layers],
            "biases": [array("f", values) for values in self.biases],
            "wq": [array("f", row) for row in self.wq], "bq": array("f", self.bq),
            "wp": [[array("f", row) for row in heads] for heads in self.wp],
            "bp": [array("f", values) for values in self.bp],
            "capacities": dict(self.capacities), "stats": self.stats_payload(),
        }

    def restore(self, snapshot):
        self.input_count = int(snapshot.get("input_count", self.input_count))
        self.layer_sizes = [int(value) for value in snapshot["layer_sizes"]]
        self.layer_modes = list(snapshot.get("layer_modes", ["tanh"] * len(self.layer_sizes)))
        self.layers = [[array("f", row) for row in rows] for rows in snapshot["layers"]]
        self.biases = [array("f", values) for values in snapshot["biases"]]
        self.wq = [array("f", row) for row in snapshot["wq"]]
        self.bq = array("f", snapshot["bq"])
        self.wp = [[array("f", row) for row in heads] for heads in snapshot["wp"]]
        self.bp = [array("f", values) for values in snapshot["bp"]]
        restored_capacities = dict(self.capacities)
        restored_capacities.update(dict(snapshot.get("capacities", {})))
        restored_capacities["adaptive_input"] = max(0, int(restored_capacities.get("adaptive_input", 0)))
        self.capacities = restored_capacities
        self.load_stats(snapshot.get("stats", {}))
        # 回滚只恢复参数，不虚增“目标网络同步次数”。
        self.sync_target(count_stat=False)

    def grow_width(self, layer_index=None, amount=2, sync=True):
        if layer_index is None:
            layer_index = min(range(len(self.layer_sizes)), key=lambda index: self.layer_sizes[index])
        layer_index = int(clamp(int(layer_index), 0, len(self.layer_sizes) - 1))
        amount = max(1, int(amount))
        source = random.Random(secrets.randbits(256))
        previous_size = self.input_count if layer_index == 0 else self.layer_sizes[layer_index - 1]
        scale = math.sqrt(2.0 / max(1, previous_size))
        for _ in range(amount):
            self.layers[layer_index].append(array("f", (source.uniform(-scale, scale) for _ in range(previous_size))))
            self.biases[layer_index].append(source.uniform(-0.01, 0.01))
            if layer_index + 1 < len(self.layers):
                for row in self.layers[layer_index + 1]:
                    row.append(0.0)
            else:
                for row in self.wq:
                    row.append(0.0)
                for heads in self.wp:
                    for row in heads:
                        row.append(0.0)
            self.layer_sizes[layer_index] += 1
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()

    def grow_depth(self, size=None, sync=True):
        # 功能保持式加深：在线性 identity 层中插入精确单位映射，输出头完全保留。
        # 对 tanh 网络而言直接插入 tanh(Ix) 也会改变函数，因此这里显式支持 identity 隐层。
        previous = self.layer_sizes[-1]
        size = previous if size is None else int(size)
        if size < previous:
            raise ValueError("功能保持式加深不能把新层缩到上一层以下")
        rows = []
        for row_index in range(size):
            row = array("f", [0.0] * previous)
            if row_index < previous:
                row[row_index] = 1.0
            rows.append(row)
        self.layers.append(rows)
        self.biases.append(array("f", [0.0] * size))
        self.layer_sizes.append(size)
        self.layer_modes.append("identity")
        # 新增的零通道不改变原输出；输出头宽度随 size 真正扩展。
        extra = size - previous
        if extra:
            for row in self.wq:
                row.extend([0.0] * extra)
            for heads in self.wp:
                for row in heads:
                    row.extend([0.0] * extra)
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()
        return size

    def grow_input(self, amount=128, sync=True):
        amount = max(1, int(amount))
        for row in self.layers[0]:
            row.extend([0.0] * amount)
        self.input_count += amount
        self.capacities["adaptive_input"] = max(int(self.capacities.get("adaptive_input", 0)), self.input_count - BASE_FEATURE_COUNT)
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()
        return self.input_count

    def grow_capabilities(self, memory_count, skill_count, bottleneck="none", resource_budget=None):
        """按瓶颈和实时资源扩容；任何字段都没有代码写死的最终容量。"""
        changed = []
        bottleneck = str(bottleneck or "none")

        def grow(name, kind="decision"):
            current = max(0, int(self.capacities.get(name, 0)))
            if resource_budget is not None:
                amount = resource_budget.growth_amount(name, current, kind=kind)
            else:
                amount = max(1, int(math.sqrt(max(1, current)) * 0.18))
            if amount <= 0:
                return 0
            self.capacities[name] = current + int(amount)
            return int(amount)

        if bottleneck == "perception":
            amounts = (grow("uia_nodes", "perception"), grow("uia_depth", "perception"), grow("attention_candidates", "perception"))
            roi_growth = grow("visual_roi_scale", "perception")
            if any(amounts) or roi_growth:
                changed.append("感知容量+{}/{}/{}（节点/深度/候选），ROI 金字塔+{}".format(*amounts, roi_growth))
            elif resource_budget is not None:
                # 扫描已经超过延迟预算时增加复用窗口，而不是继续堆 UIA 节点。
                gain = resource_budget.growth_amount("memory_horizon", self.capacities.get("observation_cache_ms", 120), "decision")
                self.capacities["observation_cache_ms"] = int(self.capacities.get("observation_cache_ms", 120)) + max(1, gain)
                changed.append("感知缓存窗口按延迟预算扩大")
        elif bottleneck == "knowledge":
            amount = grow("memory_horizon")
            if amount: changed.append("知识检索窗口+{}".format(amount))
        elif bottleneck == "skill":
            attention = grow("skill_attention"); horizon = grow("memory_horizon")
            if attention or horizon: changed.append("技能注意/组合窗口+{}/{}".format(attention, horizon))
        elif bottleneck == "planning":
            breadth = grow("planner_breadth"); horizon = grow("memory_horizon")
            if breadth or horizon: changed.append("策略宽度/规划记忆窗+{}/{}".format(breadth, horizon))
        elif bottleneck == "model_capacity":
            # 这里只开放“模型相关能力”的许可；真正增宽/加深仍需永久 eval 与延迟预算验证。
            self.capacities["adaptive_input"] = max(int(self.capacities.get("adaptive_input", 0)), self.input_count - BASE_FEATURE_COUNT)
            cache_growth = grow("forward_cache_entries")
            if resource_budget is not None:
                target_cache = resource_budget.forward_cache_entries(self.input_count, self.hidden_count)
                self.capacities["forward_cache_entries"] = max(self.capacities["forward_cache_entries"], target_cache)
            changed.append("模型容量扩张许可；推理缓存+{}".format(cache_growth))
        return changed

    def stats_payload(self):
        return {
            "sleep_count": self.sleep_count, "training_steps": self.training_steps,
            "target_syncs": self.target_syncs, "accepted_growth": self.accepted_growth,
            "rejected_growth": self.rejected_growth, "reward_average": self.reward_average,
            "loss_average": self.loss_average, "progress_average": self.progress_average,
            "safety_average": self.safety_average,
        }

    def load_stats(self, stats):
        for name in ("sleep_count", "training_steps", "target_syncs", "accepted_growth", "rejected_growth"):
            setattr(self, name, int(stats.get(name, getattr(self, name))))
        for name in ("reward_average", "loss_average", "progress_average", "safety_average"):
            setattr(self, name, safe_float(stats.get(name, getattr(self, name))))

    def to_bytes(self):
        metadata = compact_json({
            "format": FORMAT_VERSION, "input_count": self.input_count, "layer_sizes": self.layer_sizes, "layer_modes": self.layer_modes,
            "action_count": self.action_count, "param_head_sizes": self.param_head_sizes,
            "capacities": self.capacities, "stats": self.stats_payload(),
        }).encode("utf-8")
        floats = array("f")
        for rows, biases in zip(self.layers, self.biases):
            for row in rows:
                floats.extend(row)
            floats.extend(biases)
        for row in self.wq:
            floats.extend(row)
        floats.extend(self.bq)
        for heads, biases in zip(self.wp, self.bp):
            for row in heads:
                floats.extend(row)
            floats.extend(biases)
        if sys.byteorder != "little":
            floats.byteswap()
        body = struct.pack("<I", len(metadata)) + metadata + floats.tobytes()
        return MODEL_MAGIC + hashlib.sha256(body).digest() + body

    @classmethod
    def from_bytes(cls, data):
        if not data.startswith(MODEL_MAGIC) or len(data) < len(MODEL_MAGIC) + 36:
            raise ValueError("模型文件头无效")
        start = len(MODEL_MAGIC)
        checksum = data[start:start + 32]
        body = data[start + 32:]
        if hashlib.sha256(body).digest() != checksum:
            raise ValueError("模型校验失败")
        metadata_size = struct.unpack("<I", body[:4])[0]
        if metadata_size < 2 or metadata_size > len(body) - 4:
            raise ValueError("模型元数据长度无效")
        metadata = json.loads(body[4:4 + metadata_size].decode("utf-8"))
        if int(metadata.get("format", -1)) != FORMAT_VERSION:
            raise ValueError("模型版本不兼容")
        input_count = int(metadata.get("input_count", -1))
        if input_count < BASE_FEATURE_COUNT or int(metadata.get("action_count", -1)) != ACTION_COUNT:
            raise ValueError("模型结构不兼容")
        if list(metadata.get("param_head_sizes", [])) != list(PARAM_HEAD_SIZES):
            raise ValueError("动作参数头结构不兼容")
        layer_sizes = [int(value) for value in metadata.get("layer_sizes", [])]
        if not layer_sizes or any(value < 1 for value in layer_sizes):
            raise ValueError("模型层结构无效")
        values = array("f")
        values.frombytes(body[4 + metadata_size:])
        if sys.byteorder != "little":
            values.byteswap()
        layer_modes = list(metadata.get("layer_modes", ["tanh"] * len(layer_sizes)))
        if len(layer_modes) != len(layer_sizes) or any(mode not in ("tanh", "identity") for mode in layer_modes):
            raise ValueError("模型激活层结构无效")
        expected = 0
        previous = input_count
        for size in layer_sizes:
            expected += size * previous + size
            previous = size
        expected += ACTION_COUNT * previous + ACTION_COUNT
        expected += sum(count * previous + count for count in PARAM_HEAD_SIZES)
        if len(values) != expected or not all(math.isfinite(float(value)) for value in values):
            raise ValueError("模型权重损坏")
        # 先用文件实际权重数量验证结构，再分配网络，避免损坏元数据触发超大内存分配。
        model = cls(input_count, layer_sizes, metadata.get("capacities", {}))
        model.layer_modes = layer_modes
        offset = 0
        model.layers = []
        model.biases = []
        previous = input_count
        for size in layer_sizes:
            rows = []
            for _ in range(size):
                rows.append(array("f", values[offset:offset + previous])); offset += previous
            model.layers.append(rows)
            model.biases.append(array("f", values[offset:offset + size])); offset += size
            previous = size
        model.wq = []
        for _ in range(ACTION_COUNT):
            model.wq.append(array("f", values[offset:offset + previous])); offset += previous
        model.bq = array("f", values[offset:offset + ACTION_COUNT]); offset += ACTION_COUNT
        model.wp = []
        model.bp = []
        for count in PARAM_HEAD_SIZES:
            heads = []
            for _ in range(count):
                heads.append(array("f", values[offset:offset + previous])); offset += previous
            model.wp.append(heads)
            model.bp.append(array("f", values[offset:offset + count])); offset += count
        model.load_stats(metadata.get("stats", {}))
        # 从磁盘恢复目标参数不属于一次训练同步。
        model.sync_target(count_stat=False)
        return model

    def save(self, path):
        atomic_write(path, self.to_bytes())

    @classmethod
    def load(cls, path):
        with open(path, "rb") as stream:
            return cls.from_bytes(stream.read())


class LongTermMemory:

    def __init__(self, path, resource_budget=None):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.resource_budget = resource_budget or ResourceBudget(path.parent)
        self.lock = threading.RLock()
        self.connection = sqlite3.connect(str(path), timeout=20.0, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        with self.lock:
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.execute("PRAGMA synchronous=NORMAL")
            self.connection.execute("PRAGMA foreign_keys=ON")
            self._migrate_schema()
            self.connection.commit()
        self.recent = deque()
        self.recent_limit = int(self.resource_budget.memory_limits().get("recent_working_set", 128))
        self.storage_paused = False
        self.storage_pause_reason = ""
        self._storage_checked_at = 0.0

    def _write_allowed(self, essential=False):
        # 不设置“最多多少条”知识。低于资源安全线时暂停可增长经验写入，并先清理可再生成缓存。
        now = time.monotonic()
        if now - self._storage_checked_at >= (0.20 if self.storage_paused else 1.0):
            self.resource_budget.refresh()
            self._storage_checked_at = now
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + 512 * 1024 ** 2:
            self.resource_budget.cleanup_regenerable_storage()
            self.resource_budget.refresh()
        allowed = essential or self.resource_budget.free_disk > self.resource_budget.disk_reserve_bytes + 64 * 1024 ** 2
        self.storage_paused = not allowed
        self.storage_pause_reason = "磁盘已接近安全线，经验写入暂停" if not allowed else ""
        return allowed

    def _column_names(self, table):
        return {str(row[1]) for row in self.connection.execute("PRAGMA table_info(" + table + ")").fetchall()}

    def _migrate_0_to_1(self):
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                created_at REAL NOT NULL,
                last_seen REAL NOT NULL,
                state BLOB NOT NULL,
                action_kind INTEGER NOT NULL,
                action_json TEXT NOT NULL,
                parameter_blob BLOB NOT NULL,
                reward REAL NOT NULL,
                goal_reward REAL NOT NULL,
                curiosity_reward REAL NOT NULL,
                efficiency_reward REAL NOT NULL,
                safety_penalty REAL NOT NULL,
                next_state BLOB NOT NULL,
                next_mask INTEGER NOT NULL,
                priority REAL NOT NULL,
                state_signature TEXT NOT NULL,
                next_signature TEXT NOT NULL,
                n_steps INTEGER NOT NULL,
                sample_count INTEGER NOT NULL DEFAULT 1,
                goal_text TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_episode_priority ON episodic_memory(priority DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_recent ON episodic_memory(last_seen DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_signature ON episodic_memory(state_signature);
            CREATE TABLE IF NOT EXISTS state_memory (
                signature TEXT PRIMARY KEY,
                visual_signature TEXT NOT NULL,
                representative BLOB NOT NULL,
                visits INTEGER NOT NULL,
                successes INTEGER NOT NULL,
                failures INTEGER NOT NULL,
                value REAL NOT NULL,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_state_value ON state_memory(value DESC);
            CREATE TABLE IF NOT EXISTS skill_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                level INTEGER NOT NULL,
                steps_json TEXT NOT NULL,
                precondition_json TEXT NOT NULL,
                expected_json TEXT NOT NULL,
                uses INTEGER NOT NULL DEFAULT 0,
                successes INTEGER NOT NULL DEFAULT 0,
                average_seconds REAL NOT NULL DEFAULT 0,
                score REAL NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_skill_score ON skill_memory(score DESC, successes DESC);
            CREATE TABLE IF NOT EXISTS failure_memory (
                fingerprint TEXT PRIMARY KEY,
                action_json TEXT NOT NULL,
                state_signature TEXT NOT NULL,
                reason TEXT NOT NULL,
                occurrences INTEGER NOT NULL,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_failure_recent ON failure_memory(last_seen DESC);
            CREATE TABLE IF NOT EXISTS text_memory (
                text TEXT PRIMARY KEY,
                uses INTEGER NOT NULL,
                successes INTEGER NOT NULL,
                score REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        self.connection.execute("PRAGMA user_version=1")

    def _migrate_1_to_2(self):
        columns = self._column_names("failure_memory")
        if "action_kind" not in columns:
            self.connection.execute("ALTER TABLE failure_memory ADD COLUMN action_kind INTEGER NOT NULL DEFAULT -1")
        if "risk" not in columns:
            self.connection.execute("ALTER TABLE failure_memory ADD COLUMN risk REAL NOT NULL DEFAULT 0")
        rows = self.connection.execute("SELECT fingerprint,action_json FROM failure_memory WHERE action_kind<0").fetchall()
        for row in rows:
            try:
                kind = int(json.loads(row["action_json"]).get("kind", -1))
            except Exception:
                kind = -1
            self.connection.execute("UPDATE failure_memory SET action_kind=? WHERE fingerprint=?", (kind, row["fingerprint"]))
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_failure_state_action ON failure_memory(state_signature,action_kind)")
        self.connection.execute("PRAGMA user_version=2")

    def _migrate_2_to_3(self):
        columns = self._column_names("episodic_memory")
        if "current_mask" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN current_mask INTEGER NOT NULL DEFAULT 0")
        # 旧记录没有当前状态动作掩码，只能做保守迁移：至少包含实际动作；next_mask 仅用于补充历史兼容。
        self.connection.execute("UPDATE episodic_memory SET current_mask=(current_mask | next_mask | (1 << action_kind)) WHERE current_mask=0")
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_state_action ON episodic_memory(state_signature,action_kind,priority DESC)")
        self.connection.execute("PRAGMA user_version=3")

    def _migrate_3_to_4(self):
        columns = self._column_names("episodic_memory")
        if "state_key" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN state_key TEXT NOT NULL DEFAULT ''")
        if "next_state_key" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN next_state_key TEXT NOT NULL DEFAULT ''")
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_state_key_action ON episodic_memory(state_key,action_kind,priority DESC)")
        self.connection.execute("PRAGMA user_version=4")

    def _migrate_4_to_5(self):
        columns = self._column_names("episodic_memory")
        if "partition" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN partition TEXT NOT NULL DEFAULT 'train'")
        rows = self.connection.execute("SELECT id,fingerprint FROM episodic_memory").fetchall()
        for row in rows:
            fingerprint = str(row["fingerprint"] or "")
            try:
                partition = "eval" if int(fingerprint[:4], 16) % 5 == 0 else "train"
            except ValueError:
                partition = "train"
            self.connection.execute("UPDATE episodic_memory SET partition=? WHERE id=?", (partition, int(row["id"])))
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_partition_priority ON episodic_memory(partition,priority DESC)")
        self.connection.execute("PRAGMA user_version=5")

    def _migrate_5_to_6(self):
        columns = self._column_names("episodic_memory")
        additions = {
            "importance": "REAL NOT NULL DEFAULT 0.5",
            "novelty": "REAL NOT NULL DEFAULT 0.5",
            "reuse_count": "INTEGER NOT NULL DEFAULT 0",
            "last_used": "REAL NOT NULL DEFAULT 0",
            "confidence": "REAL NOT NULL DEFAULT 0.35",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN {} {}".format(name, declaration))
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS world_transition (
                fingerprint TEXT PRIMARY KEY,
                action_kind INTEGER NOT NULL,
                state_key TEXT NOT NULL,
                state BLOB NOT NULL,
                next_state BLOB NOT NULL,
                next_signature TEXT NOT NULL DEFAULT '',
                next_state_key TEXT NOT NULL DEFAULT '',
                next_mask INTEGER NOT NULL DEFAULT 0,
                mean_reward REAL NOT NULL DEFAULT 0,
                mean_safety REAL NOT NULL DEFAULT 0,
                prediction_error REAL NOT NULL DEFAULT 0,
                confidence REAL NOT NULL DEFAULT 0.25,
                observations INTEGER NOT NULL DEFAULT 1,
                created_at REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_world_action ON world_transition(action_kind,last_seen DESC);
            CREATE TABLE IF NOT EXISTS semantic_knowledge (
                fingerprint TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                key_text TEXT NOT NULL,
                value_json TEXT NOT NULL,
                confidence REAL NOT NULL DEFAULT 0.35,
                observations INTEGER NOT NULL DEFAULT 1,
                reuse_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                last_used REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_knowledge_kind ON semantic_knowledge(kind,confidence DESC,last_seen DESC);
            CREATE TABLE IF NOT EXISTS sleep_report (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at REAL NOT NULL,
                reason TEXT NOT NULL,
                findings_json TEXT NOT NULL,
                improvements_json TEXT NOT NULL,
                regressions_json TEXT NOT NULL,
                repeated_errors_json TEXT NOT NULL,
                bottleneck TEXT NOT NULL,
                structural_growth_json TEXT NOT NULL,
                before_metrics_json TEXT NOT NULL,
                after_metrics_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_sleep_report_recent ON sleep_report(created_at DESC);
        """)
        self.connection.execute("PRAGMA user_version=6")

    def _migrate_6_to_7(self):
        columns = self._column_names("skill_memory")
        additions = {
            "parameters_json": "TEXT NOT NULL DEFAULT '{}'",
            "success_json": "TEXT NOT NULL DEFAULT '{}'",
            "recovery_json": "TEXT NOT NULL DEFAULT '[]'",
            "program_version": "INTEGER NOT NULL DEFAULT 1",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self.connection.execute("ALTER TABLE skill_memory ADD COLUMN {} {}".format(name, declaration))
        self.connection.execute("PRAGMA user_version=7")

    def _migrate_7_to_8(self):
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS strategy_memory (
                fingerprint TEXT PRIMARY KEY,
                operation TEXT NOT NULL,
                app_key TEXT NOT NULL,
                precondition_json TEXT NOT NULL,
                recovery_json TEXT NOT NULL,
                subgoals_json TEXT NOT NULL,
                successes INTEGER NOT NULL DEFAULT 1,
                failures INTEGER NOT NULL DEFAULT 0,
                confidence REAL NOT NULL DEFAULT 0.35,
                reuse_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                last_used REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_strategy_lookup ON strategy_memory(operation,app_key,confidence DESC,last_seen DESC);
        """)
        self.connection.execute("PRAGMA user_version=8")

    def _migrate_8_to_9(self):
        columns = self._column_names("skill_memory")
        if "capabilities_json" not in columns:
            self.connection.execute("ALTER TABLE skill_memory ADD COLUMN capabilities_json TEXT NOT NULL DEFAULT '[]'")
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS memory_compressed (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_table TEXT NOT NULL,
                source_key TEXT NOT NULL,
                search_text TEXT NOT NULL DEFAULT '',
                payload BLOB NOT NULL,
                codec TEXT NOT NULL,
                importance REAL NOT NULL DEFAULT 0,
                original_created REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL DEFAULT 0,
                moved_at REAL NOT NULL,
                UNIQUE(source_table,source_key)
            );
            CREATE INDEX IF NOT EXISTS idx_compressed_lookup ON memory_compressed(source_table,importance DESC,last_seen DESC);
            CREATE INDEX IF NOT EXISTS idx_compressed_moved ON memory_compressed(moved_at ASC);
            CREATE TABLE IF NOT EXISTS memory_archive (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_table TEXT NOT NULL,
                source_key TEXT NOT NULL,
                search_text TEXT NOT NULL DEFAULT '',
                payload BLOB NOT NULL,
                codec TEXT NOT NULL,
                importance REAL NOT NULL DEFAULT 0,
                original_created REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL DEFAULT 0,
                archived_at REAL NOT NULL,
                access_count INTEGER NOT NULL DEFAULT 0,
                last_accessed REAL NOT NULL DEFAULT 0,
                UNIQUE(source_table,source_key)
            );
            CREATE INDEX IF NOT EXISTS idx_archive_lookup ON memory_archive(source_table,importance DESC,last_seen DESC);
            CREATE TABLE IF NOT EXISTS session_capability (
                session_id TEXT NOT NULL,
                process_id INTEGER NOT NULL DEFAULT 0,
                process_name TEXT NOT NULL DEFAULT '',
                window_hwnd INTEGER NOT NULL DEFAULT 0,
                parent_process_id INTEGER NOT NULL DEFAULT 0,
                owner_hwnd INTEGER NOT NULL DEFAULT 0,
                relation TEXT NOT NULL,
                scope TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '',
                approved INTEGER NOT NULL DEFAULT 0,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL,
                PRIMARY KEY(session_id,process_id,window_hwnd)
            );
            CREATE INDEX IF NOT EXISTS idx_session_capability_recent ON session_capability(session_id,last_seen DESC);
        """)
        self.connection.execute("PRAGMA user_version=9")

    def _migrate_schema(self):
        version = int(self.connection.execute("PRAGMA user_version").fetchone()[0])
        if version < 1:
            self._migrate_0_to_1()
            version = 1
        if version < 2:
            self._migrate_1_to_2()
            version = 2
        if version < 3:
            self._migrate_2_to_3()
            version = 3
        if version < 4:
            self._migrate_3_to_4()
            version = 4
        if version < 5:
            self._migrate_4_to_5()
            version = 5
        if version < 6:
            self._migrate_5_to_6()
            version = 6
        if version < 7:
            self._migrate_6_to_7()
            version = 7
        if version < 8:
            self._migrate_7_to_8()
            version = 8
        if version < 9:
            self._migrate_8_to_9()
            version = 9
        if version != SCHEMA_VERSION:
            raise RuntimeError("SQLite schema 版本不兼容：{} != {}".format(version, SCHEMA_VERSION))

    def close(self):
        with self.lock:
            try:
                self.connection.commit()
                self.connection.close()
            except Exception:
                pass

    def commit(self):
        with self.lock:
            self.connection.commit()

    def count(self, table):
        if table not in (
            "episodic_memory", "state_memory", "skill_memory", "failure_memory", "semantic_knowledge",
            "world_transition", "sleep_report", "strategy_memory", "text_memory", "memory_compressed",
            "memory_archive", "session_capability",
        ):
            return 0
        with self.lock:
            return int(self.connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0])

    @staticmethod
    def _json_safe(value):
        if isinstance(value, (bytes, bytearray, memoryview)):
            return {"__local_ai_bytes__": base64.b64encode(bytes(value)).decode("ascii")}
        if isinstance(value, dict):
            return {str(key): LongTermMemory._json_safe(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [LongTermMemory._json_safe(item) for item in value]
        return value

    @staticmethod
    def _json_restore(value):
        if isinstance(value, dict) and set(value.keys()) == {"__local_ai_bytes__"}:
            return base64.b64decode(str(value["__local_ai_bytes__"]).encode("ascii"))
        if isinstance(value, dict):
            return {str(key): LongTermMemory._json_restore(item) for key, item in value.items()}
        if isinstance(value, list):
            return [LongTermMemory._json_restore(item) for item in value]
        return value

    @classmethod
    def _encode_tier_row(cls, row):
        source = {str(key): row[key] for key in row.keys() if str(key) != "_tier_rowid"}
        raw = compact_json(cls._json_safe(source)).encode("utf-8")
        return zlib.compress(raw, 9)

    @classmethod
    def _decode_tier_payload(cls, payload, codec):
        if str(codec) != "zlib-json-v1":
            raise ValueError("未知归档编码")
        return cls._json_restore(json.loads(zlib.decompress(bytes(payload)).decode("utf-8")))

    @staticmethod
    def _row_search_text(row):
        values = []
        for key in row.keys():
            if str(key) in ("state", "next_state", "representative", "parameter_blob", "_tier_rowid"):
                continue
            value = row[key]
            if isinstance(value, str) and value:
                values.append(value)
        return " ".join(dict.fromkeys(semantic_units(" ".join(values))))

    @staticmethod
    def _source_key(table, row):
        fields = {
            "episodic_memory": ("fingerprint",), "state_memory": ("signature",),
            "skill_memory": ("id",), "failure_memory": ("fingerprint",),
            "text_memory": ("text",), "semantic_knowledge": ("fingerprint",),
            "world_transition": ("fingerprint",), "sleep_report": ("id",),
            "strategy_memory": ("fingerprint",),
        }.get(str(table), ("rowid",))
        return "|".join(str(row[field]) for field in fields if field in row.keys())

    @staticmethod
    def _first_number(row, names, default=0.0):
        for name in names:
            if name in row.keys():
                return safe_float(row[name], default)
        return float(default)

    def _tier_rows(self, source_table, query="", limit=32):
        result = []
        token = next(iter(semantic_units(query)), "")
        for tier in ("memory_compressed", "memory_archive"):
            sql = "SELECT * FROM {} WHERE source_table=?".format(tier)
            parameters = [str(source_table)]
            if token:
                sql += " AND search_text LIKE ?"
                parameters.append("%" + token + "%")
            sql += " ORDER BY importance DESC,last_seen DESC LIMIT ?"
            parameters.append(max(1, int(limit)))
            rows = self.connection.execute(sql, tuple(parameters)).fetchall()
            for row in rows:
                try:
                    decoded = self._decode_tier_payload(row["payload"], row["codec"])
                except Exception:
                    continue
                result.append(decoded)
            if len(result) >= int(limit):
                break
        return result[:max(1, int(limit))]

    def _tier_row(self, source_table, source_key):
        for tier in ("memory_compressed", "memory_archive"):
            row = self.connection.execute(
                "SELECT * FROM {} WHERE source_table=? AND source_key=?".format(tier),
                (str(source_table), str(source_key)),
            ).fetchone()
            if row:
                try:
                    decoded = self._decode_tier_payload(row["payload"], row["codec"])
                    if tier == "memory_archive":
                        self.connection.execute(
                            "UPDATE memory_archive SET access_count=access_count+1,last_accessed=? WHERE id=?",
                            (time.time(), int(row["id"])),
                        )
                    return decoded
                except Exception:
                    return None
        return None

    def tier_counts(self):
        with self.lock:
            compressed = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
            archived = int(self.connection.execute("SELECT COUNT(*) FROM memory_archive").fetchone()[0])
        return {"compressed": compressed, "archived": archived}

    def pending_experience_count(self):
        with self.lock:
            row = self.connection.execute("SELECT COALESCE(MAX(created_at),0) FROM sleep_report").fetchone()
            since = float(row[0] or 0.0)
            count = self.connection.execute("SELECT COUNT(*) FROM episodic_memory WHERE last_seen>?", (since,)).fetchone()
        return int(count[0])

    def fragmentation_score(self):
        with self.lock:
            pages = int(self.connection.execute("PRAGMA page_count").fetchone()[0])
            free = int(self.connection.execute("PRAGMA freelist_count").fetchone()[0])
            compressed = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
        limits = self.resource_budget.memory_limits()
        free_ratio = free / max(1, pages)
        tier_pressure = compressed / max(1, int(limits.get("memory_compressed", compressed + 1)))
        return clamp(free_ratio * 0.55 + tier_pressure * 0.45, 0.0, 1.0)

    def remember_session_capability(self, item):
        if not self._write_allowed():
            return False
        item = dict(item or {})
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO session_capability(session_id,process_id,process_name,window_hwnd,parent_process_id,owner_hwnd,relation,scope,reason,approved,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(session_id,process_id,window_hwnd) DO UPDATE SET
                    process_name=excluded.process_name,parent_process_id=excluded.parent_process_id,owner_hwnd=excluded.owner_hwnd,
                    relation=excluded.relation,scope=excluded.scope,reason=excluded.reason,
                    approved=max(session_capability.approved,excluded.approved),last_seen=excluded.last_seen
            """, (
                str(item.get("session_id", "")), int(item.get("process_id", 0)), str(item.get("process_name", "")),
                int(item.get("window_hwnd", 0)), int(item.get("parent_process_id", 0)), int(item.get("owner_hwnd", 0)),
                str(item.get("relation", "unknown")), str(item.get("scope", "default")), str(item.get("reason", "")),
                int(bool(item.get("approved"))), now, now,
            ))

    def state_visits(self, signature):
        with self.lock:
            row = self.connection.execute("SELECT visits FROM state_memory WHERE signature=?", (signature,)).fetchone()
        return int(row[0]) if row else 0

    def remember_state(self, signature, visual_signature, state, reward=0.0, success=False, failure=False):
        if not self._write_allowed():
            return False
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO state_memory(signature,visual_signature,representative,visits,successes,failures,value,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(signature) DO UPDATE SET
                    visual_signature=excluded.visual_signature,
                    representative=CASE WHEN abs(excluded.value)>=abs(state_memory.value) THEN excluded.representative ELSE state_memory.representative END,
                    visits=state_memory.visits+1,
                    successes=state_memory.successes+excluded.successes,
                    failures=state_memory.failures+excluded.failures,
                    value=state_memory.value*0.97+excluded.value*0.03,
                    last_seen=excluded.last_seen
            """, (signature, visual_signature, pack_state(state), 1, int(bool(success)), int(bool(failure)), float(reward), now, now))

    def add_experience(self, item):
        if not self._write_allowed():
            return False
        action_json = compact_json(item.get("command", {"kind": item["action"], "parameters": {}}))
        parameter_blob = pack_parameters(item.get("parameters", [0.5] * PARAM_COUNT), item.get("parameter_mask", 0))
        fingerprint_source = "|".join((
            str(item.get("signature", "")), str(item["action"]), action_json,
            str(item.get("next_signature", "")), str(item.get("n_steps", 1)), str(item.get("goal_text", "")),
        ))
        fingerprint = hashlib.blake2s(fingerprint_source.encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        try:
            partition = "eval" if int(fingerprint[:4], 16) % 5 == 0 else "train"
        except ValueError:
            partition = "train"
        values = (
            fingerprint, now, now, pack_state(item["state"]), int(item["action"]), action_json, parameter_blob,
            float(item["reward"]), float(item.get("goal_reward", 0.0)), float(item.get("curiosity_reward", 0.0)),
            float(item.get("efficiency_reward", 0.0)), float(item.get("safety_penalty", 0.0)), pack_state(item["next_state"]),
            int(item.get("current_mask", 1 << int(item["action"]))), int(item.get("next_mask", 0)), float(item.get("priority", 0.01)), str(item.get("signature", "")),
            str(item.get("next_signature", "")), int(item.get("n_steps", 1)), str(item.get("goal_text", "")),
            str(item.get("state_key", "")), str(item.get("next_state_key", "")), partition,
        )
        with self.lock:
            self.connection.execute("""
                INSERT INTO episodic_memory(
                    fingerprint,created_at,last_seen,state,action_kind,action_json,parameter_blob,reward,goal_reward,
                    curiosity_reward,efficiency_reward,safety_penalty,next_state,current_mask,next_mask,priority,state_signature,
                    next_signature,n_steps,goal_text,state_key,next_state_key,partition)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    last_seen=excluded.last_seen,
                    reward=(episodic_memory.reward*episodic_memory.sample_count+excluded.reward)/(episodic_memory.sample_count+1),
                    goal_reward=(episodic_memory.goal_reward*episodic_memory.sample_count+excluded.goal_reward)/(episodic_memory.sample_count+1),
                    curiosity_reward=(episodic_memory.curiosity_reward*episodic_memory.sample_count+excluded.curiosity_reward)/(episodic_memory.sample_count+1),
                    efficiency_reward=(episodic_memory.efficiency_reward*episodic_memory.sample_count+excluded.efficiency_reward)/(episodic_memory.sample_count+1),
                    safety_penalty=max(episodic_memory.safety_penalty,excluded.safety_penalty),
                    priority=max(episodic_memory.priority*0.995,excluded.priority),
                    state=CASE WHEN excluded.priority>=episodic_memory.priority THEN excluded.state ELSE episodic_memory.state END,
                    next_state=CASE WHEN excluded.priority>=episodic_memory.priority THEN excluded.next_state ELSE episodic_memory.next_state END,
                    current_mask=excluded.current_mask,
                    next_mask=excluded.next_mask,
                    state_key=CASE WHEN excluded.state_key<>'' THEN excluded.state_key ELSE episodic_memory.state_key END,
                    next_state_key=CASE WHEN excluded.next_state_key<>'' THEN excluded.next_state_key ELSE episodic_memory.next_state_key END,
                    partition=episodic_memory.partition,
                    sample_count=episodic_memory.sample_count+1
            """, values)
            # 价值型记忆：重要性/新颖性/复用/置信度共同决定保留，而不是只按时间或数量。
            visits_row = self.connection.execute("SELECT visits FROM state_memory WHERE signature=?", (str(item.get("signature", "")),)).fetchone()
            visits = int(visits_row[0]) if visits_row else 0
            novelty = clamp(1.0 / math.sqrt(1.0 + visits), 0.05, 1.0)
            importance = clamp(
                0.20 + abs(float(item.get("goal_reward", 0.0))) * 0.34
                + abs(float(item.get("reward", 0.0))) * 0.18
                + float(item.get("safety_penalty", 0.0)) * 0.24
                + clamp(float(item.get("priority", 0.01)) / 6.0, 0.0, 0.20),
                0.05, 1.0,
            )
            row = self.connection.execute("SELECT sample_count FROM episodic_memory WHERE fingerprint=?", (fingerprint,)).fetchone()
            samples = int(row[0]) if row else 1
            confidence = clamp(1.0 - math.exp(-samples / 3.5), 0.20, 0.995)
            self.connection.execute(
                "UPDATE episodic_memory SET importance=max(importance,?), novelty=novelty*0.92+?*0.08, confidence=max(confidence,?), last_used=CASE WHEN last_used=0 THEN ? ELSE last_used END WHERE fingerprint=?",
                (importance, novelty, confidence, now, fingerprint),
            )
        cached = dict(item)
        cached["fingerprint"] = fingerprint
        self.recent.append(cached)
        self.recent_limit = int(self.resource_budget.memory_limits().get("recent_working_set", self.recent_limit))
        while len(self.recent) > self.recent_limit:
            self.recent.popleft()

    @staticmethod
    def _decode_experience(row):
        parameters, parameter_mask = unpack_parameters(row["parameter_blob"])
        return {
            "id": int(row["id"]), "fingerprint": str(row["fingerprint"]), "state": unpack_state(row["state"]), "action": int(row["action_kind"]),
            "command": json.loads(row["action_json"]), "parameters": parameters, "parameter_mask": parameter_mask,
            "reward": float(row["reward"]), "goal_reward": float(row["goal_reward"]),
            "curiosity_reward": float(row["curiosity_reward"]), "efficiency_reward": float(row["efficiency_reward"]),
            "safety_penalty": float(row["safety_penalty"]), "next_state": unpack_state(row["next_state"]),
            "current_mask": int(row["current_mask"]), "next_mask": int(row["next_mask"]), "priority": max(0.001, float(row["priority"])),
            "signature": str(row["state_signature"]), "next_signature": str(row["next_signature"]),
            "state_key": str(row["state_key"]) if "state_key" in row.keys() else "",
            "next_state_key": str(row["next_state_key"]) if "next_state_key" in row.keys() else "",
            "n_steps": int(row["n_steps"]), "sample_count": int(row["sample_count"]),
            "partition": str(row["partition"]) if "partition" in row.keys() else "train",
        }

    def sample_batch(self, count, partition="train"):
        count = max(1, int(count))
        partition = "eval" if str(partition).lower() == "eval" else "train"
        # 候选池随请求和资源预算扩展，没有写死的最终采样窗。
        fetch = max(64, count * 6, int(math.sqrt(max(1, self.recent_limit)) * count))
        with self.lock:
            top = self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? ORDER BY priority DESC LIMIT ?", (partition, fetch)).fetchall()
            recent = self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? ORDER BY last_seen DESC LIMIT ?", (partition, fetch // 2)).fetchall()
            bounds = self.connection.execute("SELECT COUNT(*),COALESCE(MAX(id),0) FROM episodic_memory WHERE partition=?", (partition,)).fetchone()
            uniform = []
            if int(bounds[0]) and int(bounds[1]):
                anchor_count = min(16, max(4, count // 8))
                per_anchor = max(2, fetch // max(1, anchor_count * 4))
                for _ in range(anchor_count):
                    anchor = random.randint(1, int(bounds[1]))
                    uniform.extend(self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? AND id>=? ORDER BY id LIMIT ?", (partition, anchor, per_anchor)).fetchall())
        rows = {int(row["id"]): row for row in list(top) + list(recent) + list(uniform)}
        if len(rows) < count:
            with self.lock:
                tiered = self._tier_rows("episodic_memory", query=partition, limit=count - len(rows))
            for row in tiered:
                if str(row.get("partition", "train")) == partition:
                    rows[int(row["id"])] = row
        if not rows:
            return []
        weighted = []
        for row in rows.values():
            value_score = (
                max(0.05, float(row["importance"])) * 0.34
                + max(0.05, float(row["novelty"])) * 0.18
                + max(0.05, float(row["confidence"])) * 0.18
                + clamp(math.log1p(int(row["reuse_count"])) / 5.0, 0.0, 1.0) * 0.12
                + clamp(max(0.001, float(row["priority"])) / 6.0, 0.0, 1.0) * 0.18
            )
            weight = max(0.001, value_score) * (1.0 + math.log1p(int(row["sample_count"])) * 0.05)
            key = random.random() ** (1.0 / max(1e-6, weight))
            weighted.append((key, weight, row))
        selected = sorted(weighted, key=lambda value: value[0], reverse=True)[:min(count, len(weighted))]
        max_weight = max(value[1] for value in selected)
        result = []
        selected_ids = []
        for _, weight, row in selected:
            item = self._decode_experience(row)
            # importance 仍保留为训练采样修正；数据库中的 importance 是长期价值指标。
            item["importance"] = clamp((max_weight / max(weight, 1e-6)) ** 0.35, 0.2, 1.0)
            result.append(item)
            selected_ids.append(int(row["id"]))
        if selected_ids:
            now = time.time()
            with self.lock:
                self.connection.executemany("UPDATE episodic_memory SET reuse_count=reuse_count+1,last_used=? WHERE id=?", [(now, value) for value in selected_ids])
        return result

    def update_priorities(self, values):
        with self.lock:
            self.connection.executemany("UPDATE episodic_memory SET priority=?, last_seen=? WHERE id=?", [
                (float(clamp(priority, 0.001, 20.0)), time.time(), int(identifier)) for identifier, priority in values
            ])

    def remember_failure(self, command, signature, reason, risk=0.5):
        if not self._write_allowed():
            return False
        payload = command.payload() if isinstance(command, ActionCommand) else command
        action_json = compact_json(payload)
        kind = int(payload.get("kind", -1)) if isinstance(payload, dict) else -1
        fingerprint = hashlib.blake2s((signature + "|" + action_json + "|" + reason).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO failure_memory(fingerprint,action_json,state_signature,reason,occurrences,first_seen,last_seen,action_kind,risk)
                VALUES(?,?,?,?,1,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    occurrences=failure_memory.occurrences+1,last_seen=excluded.last_seen,risk=max(failure_memory.risk,excluded.risk),action_kind=excluded.action_kind
            """, (fingerprint, action_json, signature, str(reason), now, now, kind, float(clamp(risk, 0.0, 1.0))))

    def failure_score(self, signature, command):
        payload = command.payload() if isinstance(command, ActionCommand) else command
        action_json = compact_json(payload)
        with self.lock:
            rows = self.connection.execute("SELECT occurrences,risk,action_json FROM failure_memory WHERE state_signature=?", (str(signature),)).fetchall()
        score = 0.0
        for row in rows:
            if str(row["action_json"]) == action_json:
                score += (1.0 - math.exp(-float(row["occurrences"]) / 2.5)) * max(0.35, float(row["risk"]))
        return clamp(score, 0.0, 1.0)

    def failure_action_scores(self, signature):
        with self.lock:
            rows = self.connection.execute("SELECT action_kind,SUM(occurrences),MAX(risk) FROM failure_memory WHERE state_signature=? GROUP BY action_kind", (str(signature),)).fetchall()
        result = {}
        for row in rows:
            kind = int(row[0])
            if 0 <= kind < ACTION_COUNT:
                result[kind] = clamp((1.0 - math.exp(-float(row[1]) / 3.5)) * max(0.30, float(row[2])), 0.0, 1.0)
        return result

    def remember_text(self, text, success):
        if not self._write_allowed():
            return False
        text = str(text or "")
        if not text:
            return
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO text_memory(text,uses,successes,score,last_seen) VALUES(?,1,?,?,?)
                ON CONFLICT(text) DO UPDATE SET uses=text_memory.uses+1,successes=text_memory.successes+excluded.successes,
                    score=text_memory.score*0.95+excluded.score*0.05,last_seen=excluded.last_seen
            """, (text, int(bool(success)), 1.0 if success else -0.1, now))

    def text_candidates(self, limit=32):
        with self.lock:
            rows = self.connection.execute("SELECT text FROM text_memory ORDER BY score DESC,successes DESC,last_seen DESC LIMIT ?", (int(limit),)).fetchall()
            tiered = self._tier_rows("text_memory", limit=max(1, int(limit) - len(rows))) if len(rows) < int(limit) else []
        values = [str(row[0]) for row in rows] + [str(row.get("text", "")) for row in tiered]
        return list(dict.fromkeys(value for value in values if value))[:max(1, int(limit))]

    def predict_transitions(self, signature, action_kind, limit=8, state_key=""):
        limit = max(1, int(limit))
        with self.lock:
            exact = self.connection.execute(
                "SELECT * FROM episodic_memory WHERE state_signature=? AND action_kind=? ORDER BY priority DESC,last_seen DESC LIMIT ?",
                (str(signature), int(action_kind), limit),
            ).fetchall()
            candidates = []
            if state_key and len(exact) < limit:
                candidate_limit = max(limit * 4, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("episodic_memory", 1)))))
                candidates = self.connection.execute(
                    "SELECT * FROM episodic_memory WHERE action_kind=? AND state_key<>'' ORDER BY priority DESC,last_seen DESC LIMIT ?",
                    (int(action_kind), candidate_limit),
                ).fetchall()
        rows = list(exact)
        seen = {int(row["id"]) for row in rows}
        if state_key and len(rows) < limit:
            ranked = []
            for row in candidates:
                if int(row["id"]) in seen:
                    continue
                score = similarity(state_key, str(row["state_key"]))
                if score >= 0.28:
                    recency = 1.0 / (1.0 + max(0.0, time.time() - float(row["last_seen"])) / 86400.0)
                    ranked.append((score * 0.72 + clamp(float(row["priority"]) / 8.0, 0.0, 1.0) * 0.20 + recency * 0.08, row))
            ranked.sort(key=lambda value: value[0], reverse=True)
            rows.extend(row for _, row in ranked[:max(0, limit - len(rows))])
        return [self._decode_experience(row) for row in rows[:limit]]

    def retrieval_features(self, signature, count):
        count = max(0, int(count))
        if not count:
            return []
        limit = max(2, (count + 5) // 6)
        with self.lock:
            rows = self.connection.execute(
                "SELECT action_kind,reward,goal_reward,safety_penalty,next_signature,priority FROM episodic_memory WHERE state_signature=? ORDER BY priority DESC,last_seen DESC LIMIT ?",
                (str(signature), limit),
            ).fetchall()
        values = []
        for row in rows:
            action = int(row["action_kind"])
            next_hash = hashlib.blake2s(str(row["next_signature"]).encode("utf-8", "ignore"), digest_size=2).digest()
            values.extend([
                action / max(1, ACTION_COUNT - 1),
                clamp(float(row["reward"]) * 0.5 + 0.5, 0.0, 1.0),
                clamp(float(row["goal_reward"]) * 0.5 + 0.5, 0.0, 1.0),
                clamp(float(row["safety_penalty"]), 0.0, 1.0),
                int.from_bytes(next_hash, "little") / 65535.0,
                clamp(math.log1p(max(0.0, float(row["priority"]))) / 3.0, 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        return normalize_state(values, count)

    def remember_world_transition(self, item):
        if not self._write_allowed():
            return False
        """学习 state + action -> predicted_state 的本地世界模型原型。"""
        action = int(item.get("action", WAIT))
        state_key = str(item.get("state_key", "") or item.get("signature", ""))
        cluster_text = " ".join(semantic_units(state_key)) or state_key
        fingerprint = hashlib.blake2s((str(action) + "|" + cluster_text).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        next_state = normalize_state(item.get("next_state", []), max(BASE_FEATURE_COUNT, len(item.get("next_state", []))))
        state = normalize_state(item.get("state", []), max(BASE_FEATURE_COUNT, len(item.get("state", []))))
        with self.lock:
            row = self.connection.execute("SELECT * FROM world_transition WHERE fingerprint=?", (fingerprint,)).fetchone()
            if row:
                observations = int(row["observations"]) + 1
                try:
                    old_next = unpack_state(row["next_state"])
                    sample = min(len(old_next), len(next_state))
                    error = math.sqrt(sum((old_next[i] - next_state[i]) ** 2 for i in range(sample)) / max(1, sample))
                except Exception:
                    error = 0.5
                mean_error = float(row["prediction_error"]) * 0.90 + error * 0.10
                confidence = clamp((1.0 - math.exp(-observations / 5.0)) * (1.0 - clamp(mean_error * 1.8, 0.0, 0.85)), 0.05, 0.995)
                self.connection.execute("""
                    UPDATE world_transition SET state=?,next_state=?,next_signature=?,next_state_key=?,next_mask=?,
                        mean_reward=mean_reward*0.94+?*0.06,mean_safety=mean_safety*0.94+?*0.06,
                        prediction_error=?,confidence=?,observations=?,last_seen=? WHERE fingerprint=?
                """, (
                    pack_state(state), pack_state(next_state), str(item.get("next_signature", "")), str(item.get("next_state_key", "")),
                    int(item.get("next_mask", 0)), float(item.get("reward", 0.0)), float(item.get("safety_penalty", 0.0)),
                    mean_error, confidence, observations, now, fingerprint,
                ))
            else:
                self.connection.execute("""
                    INSERT INTO world_transition(fingerprint,action_kind,state_key,state,next_state,next_signature,next_state_key,next_mask,
                        mean_reward,mean_safety,prediction_error,confidence,observations,created_at,last_seen)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    fingerprint, action, state_key, pack_state(state), pack_state(next_state), str(item.get("next_signature", "")),
                    str(item.get("next_state_key", "")), int(item.get("next_mask", 0)), float(item.get("reward", 0.0)),
                    float(item.get("safety_penalty", 0.0)), 0.35, 0.22, 1, now, now,
                ))

    def world_candidates(self, action_kind, state_key="", limit=48):
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM world_transition WHERE action_kind=? ORDER BY confidence DESC,observations DESC,last_seen DESC LIMIT ?",
                (int(action_kind), max(8, int(limit) * 4)),
            ).fetchall()
        ranked = []
        for row in rows:
            match = similarity(state_key, str(row["state_key"])) if state_key else 0.25
            if state_key and match < 0.05:
                continue
            confidence = float(row["confidence"])
            score = match * 0.68 + confidence * 0.24 + clamp(math.log1p(int(row["observations"])) / 5.0, 0.0, 1.0) * 0.08
            ranked.append((score, {
                "state": unpack_state(row["state"]), "next_state": unpack_state(row["next_state"]),
                "next_signature": str(row["next_signature"]), "next_state_key": str(row["next_state_key"]),
                "next_mask": int(row["next_mask"]), "reward": float(row["mean_reward"]), "safety": float(row["mean_safety"]),
                "prediction_error": float(row["prediction_error"]), "confidence": confidence,
                "observations": int(row["observations"]), "similarity": match,
            }))
        ranked.sort(key=lambda value: value[0], reverse=True)
        return [value for _, value in ranked[:max(1, int(limit))]]

    def remember_observation_knowledge(self, observation):
        if not self._write_allowed():
            return False
        """把软件/窗口/控件语义沉淀为可复用知识，不把所有成长都压给神经网络。"""
        now = time.time()
        process_name = str(getattr(observation, "process_name", "") or "")
        items = []
        window_value = {
            "process_name": process_name, "window_title": observation.accessibility.window_title,
            "window_class": observation.accessibility.window_class,
        }
        window_key = "|".join((process_name, observation.accessibility.window_class, observation.accessibility.window_title))
        items.append(("window", window_key, window_value))
        for record in observation.accessibility.records:
            if record.get("offscreen"):
                continue
            key = "|".join((process_name, str(record.get("control_type", "")), str(record.get("automation_id", "")), str(record.get("name", ""))))
            value = {
                "process_name": process_name, "control_type": record.get("control_type", ""), "name": record.get("name", ""),
                "automation_id": record.get("automation_id", ""), "class_name": record.get("class_name", ""),
                "help": record.get("help", ""), "locator": control_locator(record),
            }
            items.append(("control", key, value))
        with self.lock:
            for kind, key, value in items:
                if not key.strip("|"):
                    continue
                fingerprint = hashlib.blake2s((kind + "|" + key).encode("utf-8", "ignore"), digest_size=16).hexdigest()
                self.connection.execute("""
                    INSERT INTO semantic_knowledge(fingerprint,kind,key_text,value_json,confidence,observations,reuse_count,created_at,last_used,last_seen)
                    VALUES(?,?,?,?,0.30,1,0,?,?,?)
                    ON CONFLICT(fingerprint) DO UPDATE SET value_json=excluded.value_json,observations=semantic_knowledge.observations+1,
                        confidence=min(0.995,1.0-exp(-(semantic_knowledge.observations+1)/8.0)),last_seen=excluded.last_seen
                """, (fingerprint, kind, key, compact_json(value), now, now, now))

    def knowledge_count(self):
        with self.lock:
            return int(self.connection.execute("SELECT COUNT(*) FROM semantic_knowledge").fetchone()[0])

    def remember_external_document(self, url, title, text, fetched_at=None, confidence=0.62):
        if not self._write_allowed():
            return False
        """保存用户明确允许访问的普通网页文本；不调用任何外部 AI。"""
        url = str(url or "").strip()
        text = str(text or "").strip()
        if not url or not text:
            return None
        now = float(fetched_at or time.time())
        value = {
            "source": url, "title": str(title or url), "fetched_at": now,
            "confidence": clamp(float(confidence), 0.0, 1.0), "text": text,
        }
        fingerprint = hashlib.blake2s(("external_document|" + url).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        with self.lock:
            self.connection.execute("""
                INSERT INTO semantic_knowledge(fingerprint,kind,key_text,value_json,confidence,observations,reuse_count,created_at,last_used,last_seen)
                VALUES(?,?,?,?,?,1,0,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET value_json=excluded.value_json,key_text=excluded.key_text,
                    confidence=max(semantic_knowledge.confidence,excluded.confidence),observations=semantic_knowledge.observations+1,
                    last_seen=excluded.last_seen
            """, (fingerprint, "external_document", (str(title or "") + " | " + url), compact_json(value), float(value["confidence"]), now, now, now))
        return fingerprint

    def semantic_context(self, query, limit=8):
        query = str(query or "").strip()
        candidate_limit = max(int(limit) * 6, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("semantic_knowledge", 1)))))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM semantic_knowledge WHERE kind='external_document' ORDER BY confidence DESC,last_seen DESC LIMIT ?",
                (candidate_limit,),
            ).fetchall()
            tiered = self._tier_rows("semantic_knowledge", query=query, limit=candidate_limit)
        candidates = list(rows) + [row for row in tiered if str(row.get("kind", "")) == "external_document"]
        ranked = []
        for row in candidates:
            try:
                value = json.loads(row["value_json"])
            except Exception:
                continue
            title = str(value.get("title", "")); text = str(value.get("text", "")); source = str(value.get("source", ""))
            score = similarity(query, title + " " + text) if query else safe_float(row["confidence"], 0.0)
            if query and any(unit in (title + " " + text).lower() for unit in semantic_units(query)):
                score += 0.25
            ranked.append((score + safe_float(row["confidence"], 0.0) * 0.18, value))
        ranked.sort(key=lambda item: item[0], reverse=True)
        context_chars = max(512, int(math.sqrt(self.resource_budget.network_document_bytes()) * 8.0))
        result = []
        for score, value in ranked[:max(1, int(limit))]:
            result.append({
                "source": str(value.get("source", "")), "title": str(value.get("title", "")),
                "fetched_at": safe_float(value.get("fetched_at", 0.0)), "confidence": safe_float(value.get("confidence", score)),
                "snippet": str(value.get("text", ""))[:context_chars],
            })
        return result

    def known_control_hints(self, process_name, query="", limit=8):
        process_name = str(process_name or "").lower().strip()
        query = str(query or "").strip()
        candidate_limit = max(int(limit) * 8, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("semantic_knowledge", 1))) * 4.0))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM semantic_knowledge WHERE kind='control' ORDER BY confidence DESC,observations DESC,last_seen DESC LIMIT ?",
                (candidate_limit,),
            ).fetchall()
            tiered = self._tier_rows("semantic_knowledge", query=query or process_name, limit=candidate_limit)
        ranked = []
        hot_fingerprints = {str(row["fingerprint"]) for row in rows}
        for row in list(rows) + [item for item in tiered if str(item.get("kind", "")) == "control"]:
            try:
                value = json.loads(row["value_json"])
            except Exception:
                continue
            if process_name and str(value.get("process_name", "")).lower() not in ("", process_name):
                continue
            text = " ".join((str(value.get("name", "")), str(value.get("automation_id", "")), str(value.get("class_name", "")), str(value.get("control_type", ""))))
            score = similarity(query, text) if query else float(row["confidence"])
            if query and query.lower() in text.lower():
                score += 0.45
            score += float(row["confidence"]) * 0.25
            ranked.append((score, row, value, str(row["fingerprint"]) in hot_fingerprints))
        ranked.sort(key=lambda item: item[0], reverse=True)
        chosen = ranked[:max(1, int(limit))]
        hot_chosen = [item for item in chosen if item[3]]
        if hot_chosen:
            now = time.time()
            with self.lock:
                self.connection.executemany(
                    "UPDATE semantic_knowledge SET reuse_count=reuse_count+1,last_used=? WHERE fingerprint=?",
                    [(now, str(row["fingerprint"])) for _, row, _, _ in hot_chosen],
                )
        return [value for _, _, value, _ in chosen]

    def remember_strategy(self, operation, app_key, precondition, recovery, subgoals=None):
        if not self._write_allowed():
            return False
        operation = str(operation or "unknown")
        app_key = str(app_key or "unknown").lower()
        recovery = list(recovery or [])
        subgoals = list(subgoals or [])
        if not recovery:
            return None
        source = compact_json({"operation": operation, "app": app_key, "recovery": recovery, "subgoals": subgoals})
        fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO strategy_memory(fingerprint,operation,app_key,precondition_json,recovery_json,subgoals_json,successes,failures,confidence,reuse_count,created_at,last_used,last_seen)
                VALUES(?,?,?,?,?,?,1,0,0.42,0,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET successes=strategy_memory.successes+1,
                    confidence=min(0.995,1.0-exp(-(strategy_memory.successes+1)/4.0)),last_seen=excluded.last_seen,
                    precondition_json=excluded.precondition_json
            """, (fingerprint, operation, app_key, compact_json(precondition or {}), compact_json(recovery), compact_json(subgoals), now, now, now))
        return fingerprint

    def best_strategy(self, operation, app_key=""):
        operation = str(operation or "")
        app_key = str(app_key or "").lower()
        candidate_limit = max(2, int(math.log2(1.0 + max(1, self.resource_budget.memory_limits().get("strategy_memory", 1))) * 2.0))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM strategy_memory WHERE operation=? AND (app_key=? OR app_key='unknown') ORDER BY confidence DESC,successes DESC,last_seen DESC LIMIT ?",
                (operation, app_key, candidate_limit),
            ).fetchall()
            if not rows and app_key:
                rows = self.connection.execute(
                    "SELECT * FROM strategy_memory WHERE operation=? ORDER BY confidence DESC,successes DESC,last_seen DESC LIMIT ?", (operation, candidate_limit)
                ).fetchall()
            tiered = self._tier_rows("strategy_memory", query=operation, limit=candidate_limit)
        if not rows:
            candidates = [row for row in tiered if str(row.get("operation", "")) == operation and (not app_key or str(row.get("app_key", "")) in (app_key, "unknown"))]
            candidates.sort(key=lambda row: (safe_float(row.get("confidence", 0.0)), int(row.get("successes", 0)), safe_float(row.get("last_seen", 0.0))), reverse=True)
            rows = candidates
        if not rows:
            return None
        row = rows[0]
        now = time.time()
        if isinstance(row, sqlite3.Row):
            with self.lock:
                self.connection.execute("UPDATE strategy_memory SET reuse_count=reuse_count+1,last_used=? WHERE fingerprint=?", (now, str(row["fingerprint"])))
        return {"fingerprint": str(row["fingerprint"]), "operation": str(row["operation"]), "app_key": str(row["app_key"]),
                "precondition": json.loads(row["precondition_json"]), "recovery": json.loads(row["recovery_json"]),
                "subgoals": json.loads(row["subgoals_json"]), "confidence": float(row["confidence"]), "successes": int(row["successes"])}

    def remember_sleep_report(self, report):
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO sleep_report(created_at,reason,findings_json,improvements_json,regressions_json,repeated_errors_json,bottleneck,
                    structural_growth_json,before_metrics_json,after_metrics_json) VALUES(?,?,?,?,?,?,?,?,?,?)
            """, (
                now, str(report.get("reason", "")), compact_json(report.get("findings", [])), compact_json(report.get("improvements", [])),
                compact_json(report.get("regressions", [])), compact_json(report.get("repeated_errors", [])), str(report.get("bottleneck", "unknown"))[:64],
                compact_json(report.get("structural_growth", [])), compact_json(report.get("before_metrics", {})), compact_json(report.get("after_metrics", {})),
            ))
        result = dict(report)
        result["created_at"] = now
        return result

    def latest_sleep_report(self):
        with self.lock:
            row = self.connection.execute("SELECT * FROM sleep_report ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return {}
        return {
            "created_at": float(row["created_at"]), "reason": str(row["reason"]), "findings": json.loads(row["findings_json"]),
            "improvements": json.loads(row["improvements_json"]), "regressions": json.loads(row["regressions_json"]),
            "repeated_errors": json.loads(row["repeated_errors_json"]), "bottleneck": str(row["bottleneck"]),
            "structural_growth": json.loads(row["structural_growth_json"]), "before_metrics": json.loads(row["before_metrics_json"]),
            "after_metrics": json.loads(row["after_metrics_json"]),
        }

    def recent_failure_patterns(self, limit=8):
        with self.lock:
            rows = self.connection.execute("SELECT reason,SUM(occurrences) AS n,MAX(risk) AS r FROM failure_memory GROUP BY reason ORDER BY n DESC,r DESC LIMIT ?", (int(limit),)).fetchall()
        return [{"reason": str(row["reason"]), "occurrences": int(row["n"]), "risk": float(row["r"])} for row in rows]

    def upsert_skill(self, fingerprint, name, level, steps, precondition, expected, score, parameters=None, success=None, recovery=None, program_version=2, capabilities=None):
        if not self._write_allowed():
            return 0
        now = time.time()
        parameters = parameters or {}
        capabilities = sorted(set(str(value) for value in (capabilities or []) if value))
        success = success if success is not None else expected
        recovery = recovery or [{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}]
        with self.lock:
            self.connection.execute("""
                INSERT INTO skill_memory(fingerprint,name,level,steps_json,precondition_json,expected_json,score,created_at,updated_at,parameters_json,success_json,recovery_json,program_version,capabilities_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    name=excluded.name,level=max(skill_memory.level,excluded.level),score=max(skill_memory.score,excluded.score),
                    expected_json=excluded.expected_json,parameters_json=excluded.parameters_json,success_json=excluded.success_json,
                    recovery_json=excluded.recovery_json,capabilities_json=excluded.capabilities_json,
                    program_version=max(skill_memory.program_version,excluded.program_version),updated_at=excluded.updated_at
            """, (fingerprint, str(name), int(level), compact_json(steps), compact_json(precondition), compact_json(expected), float(score), now, now,
                  compact_json(parameters), compact_json(success), compact_json(recovery), int(program_version), compact_json(capabilities)))
            row = self.connection.execute("SELECT id FROM skill_memory WHERE fingerprint=?", (fingerprint,)).fetchone()
        return int(row[0])

    @staticmethod
    def _decode_skill(row):
        keys = set(row.keys())
        level = int(row["level"])
        if level <= 1:
            abstraction_kind = "Skill"
        elif level <= 3:
            abstraction_kind = "Procedure"
        elif level <= 7:
            abstraction_kind = "MacroAction"
        else:
            abstraction_kind = "Tool"
        return {
            "id": int(row["id"]), "fingerprint": str(row["fingerprint"]), "name": str(row["name"]),
            "level": level, "abstraction_kind": abstraction_kind, "steps": json.loads(row["steps_json"]),
            "precondition": json.loads(row["precondition_json"]), "expected": json.loads(row["expected_json"]),
            "parameters": json.loads(row["parameters_json"]) if "parameters_json" in keys and row["parameters_json"] else {},
            "success": json.loads(row["success_json"]) if "success_json" in keys and row["success_json"] else json.loads(row["expected_json"]),
            "recovery": json.loads(row["recovery_json"]) if "recovery_json" in keys and row["recovery_json"] else [],
            "capabilities": json.loads(row["capabilities_json"]) if "capabilities_json" in keys and row["capabilities_json"] else [],
            "program_version": int(row["program_version"]) if "program_version" in keys else 1,
            "uses": int(row["uses"]), "successes": int(row["successes"]),
            "average_seconds": float(row["average_seconds"]), "score": float(row["score"]),
        }

    def get_skill(self, identifier):
        with self.lock:
            row = self.connection.execute("SELECT * FROM skill_memory WHERE id=?", (int(identifier),)).fetchone()
            if row is None:
                row = self._tier_row("skill_memory", str(int(identifier)))
        return self._decode_skill(row) if row else None

    def top_skills(self, limit=256):
        with self.lock:
            rows = self.connection.execute("SELECT * FROM skill_memory ORDER BY score DESC,successes DESC,updated_at DESC LIMIT ?", (int(limit),)).fetchall()
            tiered = self._tier_rows("skill_memory", limit=max(1, int(limit) - len(rows))) if len(rows) < int(limit) else []
        skills = [self._decode_skill(row) for row in list(rows) + tiered]
        unique = {int(skill["id"]): skill for skill in skills}
        ordered = sorted(unique.values(), key=lambda skill: (safe_float(skill.get("score", 0.0)), int(skill.get("successes", 0)), -safe_float(skill.get("average_seconds", 0.0))), reverse=True)
        return ordered[:max(1, int(limit))]

    def record_skill_result(self, identifier, success, seconds):
        if not self._write_allowed():
            return
        with self.lock:
            row = self.connection.execute("SELECT uses,successes,average_seconds,score FROM skill_memory WHERE id=?", (int(identifier),)).fetchone()
            if not row:
                return
            uses = int(row[0]) + 1
            successes = int(row[1]) + int(bool(success))
            average = float(seconds) if uses == 1 else float(row[2]) * 0.9 + float(seconds) * 0.1
            score = float(row[3]) * 0.97 + (0.12 if success else -0.08)
            self.connection.execute("UPDATE skill_memory SET uses=?,successes=?,average_seconds=?,score=?,updated_at=? WHERE id=?", (uses, successes, average, score, time.time(), int(identifier)))

    def _demote_table(self, table, hot_limit, order_by, protected_keys=None):
        """热记忆 -> 可检索压缩记忆。插入成功后才移出热表，不丢弃原始内容。"""
        hot_limit = max(1, int(hot_limit))
        total = int(self.connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0])
        trigger = hot_limit + max(1, int(math.sqrt(hot_limit)))
        if total <= trigger:
            return 0
        needed = total - hot_limit
        protected_keys = set(str(value) for value in (protected_keys or ()))
        candidates = self.connection.execute(
            "SELECT rowid AS _tier_rowid,* FROM " + table + " ORDER BY " + order_by + " LIMIT ?",
            (needed + len(protected_keys) + max(8, int(math.sqrt(needed))),),
        ).fetchall()
        moved = 0
        now = time.time()
        for row in candidates:
            source_key = self._source_key(table, row)
            if not source_key or source_key in protected_keys:
                continue
            payload = self._encode_tier_row(row)
            search_text = self._row_search_text(row)
            importance = self._first_number(row, ("importance", "confidence", "score", "risk", "priority", "value"), 0.0)
            created = self._first_number(row, ("created_at", "first_seen", "created_at", "updated_at"), now)
            last_seen = self._first_number(row, ("last_seen", "last_used", "updated_at", "created_at"), created)
            self.connection.execute("""
                INSERT INTO memory_compressed(source_table,source_key,search_text,payload,codec,importance,original_created,last_seen,moved_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_table,source_key) DO UPDATE SET
                    search_text=excluded.search_text,payload=excluded.payload,codec=excluded.codec,
                    importance=max(memory_compressed.importance,excluded.importance),
                    last_seen=max(memory_compressed.last_seen,excluded.last_seen),moved_at=excluded.moved_at
            """, (table, source_key, search_text, payload, "zlib-json-v1", importance, created, last_seen, now))
            self.connection.execute("DELETE FROM " + table + " WHERE rowid=?", (int(row["_tier_rowid"]),))
            moved += 1
            if moved >= needed:
                break
        return moved

    def _archive_compressed(self, compressed_limit):
        """压缩记忆 -> 只增不自动删除的归档记忆。"""
        compressed_limit = max(1, int(compressed_limit))
        total = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
        trigger = compressed_limit + max(1, int(math.sqrt(compressed_limit)))
        if total <= trigger:
            return 0
        move_count = total - compressed_limit
        rows = self.connection.execute(
            "SELECT * FROM memory_compressed ORDER BY importance ASC,last_seen ASC,moved_at ASC LIMIT ?", (move_count,)
        ).fetchall()
        now = time.time()
        moved = 0
        for row in rows:
            self.connection.execute("""
                INSERT INTO memory_archive(source_table,source_key,search_text,payload,codec,importance,original_created,last_seen,archived_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_table,source_key) DO UPDATE SET
                    search_text=excluded.search_text,payload=excluded.payload,codec=excluded.codec,
                    importance=max(memory_archive.importance,excluded.importance),
                    last_seen=max(memory_archive.last_seen,excluded.last_seen),archived_at=excluded.archived_at
            """, (
                str(row["source_table"]), str(row["source_key"]), str(row["search_text"]), bytes(row["payload"]),
                str(row["codec"]), float(row["importance"]), float(row["original_created"]), float(row["last_seen"]), now,
            ))
            self.connection.execute("DELETE FROM memory_compressed WHERE id=?", (int(row["id"]),))
            moved += 1
        return moved

    def consolidate(self, resource_budget=None):
        budget = resource_budget or self.resource_budget
        budget.refresh()
        self.resource_budget = budget
        limits = budget.memory_limits()
        demoted = {"experiences": 0, "states": 0, "skills": 0, "failures": 0, "texts": 0, "knowledge": 0, "world": 0, "sleep_reports": 0, "strategies": 0}
        with self.lock:
            self.connection.commit()
            demoted["experiences"] = self._demote_table(
                "episodic_memory", limits["episodic_memory"],
                "(importance*0.34 + novelty*0.18 + confidence*0.18 + min(reuse_count,50)/50.0*0.12 + min(priority,6)/6.0*0.18) ASC, last_used ASC, last_seen ASC"
            )
            demoted["states"] = self._demote_table("state_memory", limits["state_memory"], "successes ASC, abs(value) ASC, visits ASC, last_seen ASC")
            demoted["failures"] = self._demote_table("failure_memory", limits["failure_memory"], "risk ASC, occurrences ASC, last_seen ASC")
            demoted["texts"] = self._demote_table("text_memory", limits["text_memory"], "successes ASC, score ASC, uses ASC, last_seen ASC")
            demoted["knowledge"] = self._demote_table("semantic_knowledge", limits["semantic_knowledge"], "confidence ASC, observations ASC, last_used ASC, last_seen ASC")
            demoted["world"] = self._demote_table("world_transition", limits["world_transition"], "confidence ASC, observations ASC, last_seen ASC")
            demoted["sleep_reports"] = self._demote_table("sleep_report", limits["sleep_report"], "created_at ASC")
            demoted["strategies"] = self._demote_table("strategy_memory", limits["strategy_memory"], "confidence ASC, successes ASC, reuse_count ASC, last_used ASC")
            # 技能存在父子引用：递归扫描所有程序分支，保护被复合技能引用的子技能。
            protected = set()
            def collect_refs(step):
                if not isinstance(step, dict):
                    return
                if step.get("type") == "skill":
                    try: protected.add(str(int(step.get("skill_id", 0))))
                    except Exception: pass
                for key in ("steps", "then", "else", "recovery"):
                    value = step.get(key, [])
                    if isinstance(value, dict): value = [value]
                    for child in value if isinstance(value, list) else []:
                        collect_refs(child)
            for row in self.connection.execute("SELECT steps_json FROM skill_memory").fetchall():
                try:
                    for step in json.loads(row[0]): collect_refs(step)
                except Exception:
                    pass
            demoted["skills"] = self._demote_table(
                "skill_memory", limits["skill_memory"], "successes ASC,score ASC,uses ASC,updated_at ASC", protected_keys=protected,
            )
            archived_now = self._archive_compressed(limits["memory_compressed"])
            self.connection.commit()
            self.connection.execute("PRAGMA optimize")
            self.connection.execute("PRAGMA wal_checkpoint(PASSIVE)")
        tiers = self.tier_counts()
        return {
            "experiences": self.count("episodic_memory"), "states": self.count("state_memory"),
            "skills": self.count("skill_memory"), "failures": self.count("failure_memory"),
            "knowledge": self.count("semantic_knowledge"), "world": self.count("world_transition"), "strategies": self.count("strategy_memory"),
            "demoted": demoted, "compressed": tiers["compressed"], "archived": tiers["archived"],
            "archived_now": archived_now, "resource_limits": limits,
        }


class WorldModel:
    """无需第三方模型的可学习世界模型：state + action -> predicted_state + uncertainty。"""
    def __init__(self, memory):
        self.memory = memory

    def _state_similarity(self, first, second):
        if not first or not second:
            return 0.0
        count = min(len(first), len(second))
        if count <= 0:
            return 0.0
        comparison_points = max(64, int(math.sqrt(max(1, self.memory.resource_budget.hot_memory_bytes // 1024))))
        stride = max(1, count // comparison_points)
        distance = sum(abs(float(first[i]) - float(second[i])) for i in range(0, count, stride)) / max(1, len(range(0, count, stride)))
        return clamp(1.0 - distance * 1.8, 0.0, 1.0)

    def observe(self, item):
        self.memory.remember_world_transition(item)

    def predict(self, state, action_kind, state_key=""):
        world_budget = self.memory.resource_budget.memory_limits().get("world_transition", 1)
        candidate_limit = max(4, int(math.log2(1.0 + max(1, world_budget)) * 2.0 * self.memory.resource_budget._latency_factor("decision")))
        candidates = self.memory.world_candidates(action_kind, state_key=state_key, limit=candidate_limit)
        if not candidates:
            return {"predicted_state": normalize_state(state, len(state)), "uncertainty": 1.0, "reward": 0.0, "safety": 0.0, "next_mask": 0, "support": 0}
        ranked = []
        for candidate in candidates:
            state_match = self._state_similarity(state, candidate.get("state", []))
            semantic_match = float(candidate.get("similarity", 0.0))
            confidence = float(candidate.get("confidence", 0.0))
            weight = max(1e-4, state_match * 0.38 + semantic_match * 0.42 + confidence * 0.20)
            ranked.append((weight, candidate, state_match))
        ranked.sort(key=lambda value: value[0], reverse=True)
        selected_count = max(1, int(math.sqrt(max(1, len(ranked)))))
        selected = ranked[:selected_count]
        total = sum(value[0] for value in selected)
        output_count = max(len(state), max(len(value[1].get("next_state", [])) for value in selected))
        predicted = [0.0] * output_count
        reward = safety = 0.0
        mask_scores = Counter()
        for weight, candidate, _ in selected:
            local = normalize_state(candidate.get("next_state", []), output_count)
            ratio = weight / max(1e-9, total)
            for index, item in enumerate(local):
                predicted[index] += float(item) * ratio
            reward += float(candidate.get("reward", 0.0)) * ratio
            safety += float(candidate.get("safety", 0.0)) * ratio
            mask_scores[int(candidate.get("next_mask", 0))] += ratio
        sample = min(output_count, max(64, int(math.sqrt(max(1, self.memory.resource_budget.hot_memory_bytes // 1024)))))
        dispersion = 0.0
        if len(selected) > 1 and sample:
            for _, candidate, _ in selected:
                local = normalize_state(candidate.get("next_state", []), output_count)
                dispersion += math.sqrt(sum((local[i] - predicted[i]) ** 2 for i in range(sample)) / sample)
            dispersion /= len(selected)
        best_weight, best, best_state_match = selected[0]
        support = sum(int(value[1].get("observations", 1)) for value in selected)
        evidence = 1.0 - math.exp(-support / 8.0)
        model_confidence = clamp(
            best_state_match * 0.30 + float(best.get("similarity", 0.0)) * 0.28 + float(best.get("confidence", 0.0)) * 0.24 + evidence * 0.18,
            0.0, 1.0,
        )
        error = sum(float(value[1].get("prediction_error", 0.5)) * value[0] for value in selected) / max(1e-9, total)
        uncertainty = clamp(1.0 - model_confidence + dispersion * 0.55 + error * 0.45, 0.0, 1.0)
        next_mask = mask_scores.most_common(1)[0][0] if mask_scores else 0
        return {
            "predicted_state": predicted, "uncertainty": uncertainty, "reward": reward, "safety": safety,
            "next_mask": int(next_mask), "support": support, "next_signature": str(best.get("next_signature", "")),
            "next_state_key": str(best.get("next_state_key", "")),
        }

    def state_uncertainty(self, state, state_key, allowed):
        candidates = [kind for kind in allowed if kind not in (WAIT, SLEEP)]
        if not candidates:
            return 0.0
        values = [self.predict(state, kind, state_key).get("uncertainty", 1.0) for kind in candidates]
        # 用最可信的可行动作衡量“是否完全看不懂”；避免一个冷门动作把整个状态判成未知。
        values.sort()
        keep = values[:max(1, min(3, len(values)))]
        return sum(keep) / len(keep)


class BottleneckAnalyzer:
    NAMES = ("perception", "knowledge", "skill", "planning", "model_capacity", "none")

    @classmethod
    def classify(cls, context, model, memory):
        context = dict(context or {})
        perception = safe_float(context.get("perception_limited_ratio", 0.0))
        uncertainty = safe_float(context.get("world_uncertainty", 1.0), 1.0)
        stagnant = int(context.get("stagnant", 0))
        repeated = int(context.get("repeated", 0))
        unresolved = bool(context.get("compiler_unresolved", False))
        experiences = memory.count("episodic_memory")
        skills = memory.count("skill_memory")
        if perception >= 0.18:
            return "perception", "UIA/视觉信息不足，优先扩大感知与观察，不扩大策略网络"
        if unresolved or uncertainty >= 0.68:
            return "knowledge", "对对象/软件/状态转移缺少知识，优先积累语义知识和世界模型"
        if repeated >= 4 and skills < max(12, model.hidden_count // 3):
            return "skill", "动作重复但缺少可复用程序技能，优先技能压缩和参数化"
        if stagnant >= 24 and uncertainty < 0.55:
            if experiences >= max(600, model.hidden_count * 12) and skills >= max(10, model.hidden_count // 7) and model.loss_average > 0.10:
                return "model_capacity", "感知/知识已有支撑且策略长期停滞，模型容量可能成为瓶颈"
            return "planning", "世界模型有一定把握但进展停滞，优先扩展前置条件/恢复/规划搜索"
        return "none", "没有证据表明神经网络容量是当前首要瓶颈"


class Point(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class Rect(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class GuiThreadInfo(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND), ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND), ("hwndCaret", wintypes.HWND), ("rcCaret", Rect),
    ]


class ProcessEntry32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260),
    ]


class BitmapInfoHeader(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD),
    ]


class RGBQuad(ctypes.Structure):
    _fields_ = [("rgbBlue", ctypes.c_ubyte), ("rgbGreen", ctypes.c_ubyte), ("rgbRed", ctypes.c_ubyte), ("rgbReserved", ctypes.c_ubyte)]


class BitmapInfo(ctypes.Structure):
    _fields_ = [("bmiHeader", BitmapInfoHeader), ("bmiColors", RGBQuad * 1)]


ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong


class MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR),
    ]


class KeyboardInput(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR),
    ]


class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class InputUnion(ctypes.Union):
    _fields_ = [("mi", MouseInput), ("ki", KeyboardInput), ("hi", HardwareInput)]


class Input(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", wintypes.DWORD), ("union", InputUnion)]


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    @classmethod
    def from_text(cls, text):
        value = uuid.UUID(text)
        return cls(value.time_low, value.time_mid, value.time_hi_version, (ctypes.c_ubyte * 8)(*value.bytes[8:]))


class VariantValue(ctypes.Union):
    _fields_ = [
        ("llVal", ctypes.c_longlong), ("lVal", ctypes.c_long), ("ulVal", ctypes.c_ulong),
        ("dblVal", ctypes.c_double), ("boolVal", ctypes.c_short), ("bstrVal", ctypes.c_void_p),
        ("punkVal", ctypes.c_void_p), ("parray", ctypes.c_void_p), ("byref", ctypes.c_void_p), ("raw", ctypes.c_ubyte * 16),
    ]


class Variant(ctypes.Structure):
    _anonymous_ = ("value",)
    _fields_ = [
        ("vt", ctypes.c_ushort), ("reserved1", ctypes.c_ushort), ("reserved2", ctypes.c_ushort),
        ("reserved3", ctypes.c_ushort), ("value", VariantValue),
    ]


CONTROL_TYPES = {
    50000: "Button", 50001: "Calendar", 50002: "CheckBox", 50003: "ComboBox",
    50004: "Edit", 50005: "Hyperlink", 50006: "Image", 50007: "ListItem",
    50008: "List", 50009: "Menu", 50010: "MenuBar", 50011: "MenuItem",
    50012: "ProgressBar", 50013: "RadioButton", 50014: "ScrollBar", 50015: "Slider",
    50016: "Spinner", 50017: "StatusBar", 50018: "Tab", 50019: "TabItem",
    50020: "Text", 50021: "ToolBar", 50022: "ToolTip", 50023: "Tree",
    50024: "TreeItem", 50025: "Custom", 50026: "Group", 50027: "Thumb",
    50028: "DataGrid", 50029: "DataItem", 50030: "Document", 50031: "SplitButton",
    50032: "Window", 50033: "Pane", 50034: "Header", 50035: "HeaderItem",
    50036: "Table", 50037: "TitleBar", 50038: "Separator", 50039: "SemanticZoom", 50040: "AppBar",
}
INTERACTIVE_CONTROL_TYPES = {
    "Button", "CheckBox", "ComboBox", "Edit", "Hyperlink", "ListItem", "MenuItem",
    "RadioButton", "ScrollBar", "Slider", "Spinner", "TabItem", "TreeItem", "DataItem", "SplitButton",
}


@dataclass
class AccessibilitySnapshot:
    hwnd: int = 0
    window_title: str = ""
    window_class: str = ""
    records: list = field(default_factory=list)

    def text(self):
        values = [self.window_title, self.window_class]
        for record in self.records:
            values.extend((record.get("name", ""), record.get("automation_id", ""), record.get("class_name", ""), record.get("control_type", ""), record.get("help", ""), record.get("value", "")))
        return " ".join(value for value in values if value)


class AccessibilityReader:
    CLSID_CUIAUTOMATION = GUID.from_text("ff48dba4-60ef-4201-aa87-54103eef594e")
    IID_IUIAUTOMATION = GUID.from_text("30cbe57d-d9d0-452a-ab13-7ac5ac4825ee")
    WINAPI = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)

    def __init__(self, user32, max_depth=4, max_nodes=128):
        self.user32 = user32
        self.max_depth = max(1, int(max_depth))
        self.max_nodes = max(16, int(max_nodes))
        self.automation = ctypes.c_void_p()
        self.walker = ctypes.c_void_p()
        self.initialized = False
        self.available = False
        if os.name != "nt":
            return
        try:
            self.ole32 = ctypes.WinDLL("ole32", use_last_error=True)
            self.oleaut32 = ctypes.WinDLL("oleaut32", use_last_error=True)
            self.ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
            self.ole32.CoInitializeEx.restype = ctypes.c_long
            result = int(self.ole32.CoInitializeEx(None, 0))
            self.initialized = result in (0, 1)
            self.ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
            self.ole32.CoCreateInstance.restype = ctypes.c_long
            result = int(self.ole32.CoCreateInstance(ctypes.byref(self.CLSID_CUIAUTOMATION), None, 1, ctypes.byref(self.IID_IUIAUTOMATION), ctypes.byref(self.automation)))
            self.available = result >= 0 and bool(self.automation.value)
            self.oleaut32.VariantClear.argtypes = [ctypes.POINTER(Variant)]
            self.oleaut32.VariantClear.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetDim.argtypes = [ctypes.c_void_p]
            self.oleaut32.SafeArrayGetDim.restype = ctypes.c_uint
            self.oleaut32.SafeArrayGetLBound.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_long)]
            self.oleaut32.SafeArrayGetLBound.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetUBound.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_long)]
            self.oleaut32.SafeArrayGetUBound.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetElement.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_long), ctypes.c_void_p]
            self.oleaut32.SafeArrayGetElement.restype = ctypes.c_long
            if self.available:
                walker = ctypes.c_void_p()
                code = int(self._call(self.automation, 14, ctypes.c_long, [ctypes.POINTER(ctypes.c_void_p)], ctypes.byref(walker)))
                if code >= 0 and walker.value:
                    self.walker = walker
        except Exception:
            self.available = False

    def set_capacity(self, max_depth, max_nodes):
        self.max_depth = max(1, int(max_depth))
        self.max_nodes = max(16, int(max_nodes))

    def close(self):
        try:
            if self.walker.value:
                self._call(self.walker, 2, ctypes.c_ulong, [])
                self.walker = ctypes.c_void_p()
            if self.automation.value:
                self._call(self.automation, 2, ctypes.c_ulong, [])
                self.automation = ctypes.c_void_p()
            if self.initialized:
                self.ole32.CoUninitialize()
        except Exception:
            pass

    def _call(self, pointer, index, result_type, argument_types, *arguments):
        address = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents[index]
        prototype = self.WINAPI(result_type, ctypes.c_void_p, *argument_types)
        return prototype(address)(pointer, *arguments)

    def _array_property(self, value):
        psa = value.parray
        if not psa or self.oleaut32.SafeArrayGetDim(psa) != 1:
            return None
        lower = ctypes.c_long()
        upper = ctypes.c_long()
        if self.oleaut32.SafeArrayGetLBound(psa, 1, ctypes.byref(lower)) < 0 or self.oleaut32.SafeArrayGetUBound(psa, 1, ctypes.byref(upper)) < 0:
            return None
        base = int(value.vt) & 0x0FFF
        result = []
        for number in range(int(lower.value), int(upper.value) + 1):
            index = ctypes.c_long(number)
            if base == 5:
                local = ctypes.c_double()
            elif base in (2, 3, 16, 17, 18, 19, 20, 21, 22, 23):
                local = ctypes.c_longlong()
            else:
                return None
            if self.oleaut32.SafeArrayGetElement(psa, ctypes.byref(index), ctypes.byref(local)) < 0:
                return None
            result.append(float(local.value) if base == 5 else int(local.value))
        return result

    def _property(self, element, property_id):
        value = Variant()
        try:
            result = int(self._call(element, 10, ctypes.c_long, [ctypes.c_int, ctypes.POINTER(Variant)], int(property_id), ctypes.byref(value)))
            if result < 0:
                return None
            if int(value.vt) & 0x2000:
                return self._array_property(value)
            if value.vt == 8 and value.bstrVal:
                return ctypes.wstring_at(value.bstrVal)
            if value.vt in (2, 3, 16, 17, 18, 19, 20, 21, 22, 23):
                return int(value.llVal if value.vt in (20, 21) else value.lVal)
            if value.vt == 11:
                return bool(value.boolVal)
            if value.vt == 5:
                return float(value.dblVal)
            return None
        except Exception:
            return None
        finally:
            try:
                self.oleaut32.VariantClear(ctypes.byref(value))
            except Exception:
                pass

    def _record(self, element, fallback_point, source, depth=0):
        if not element or not element.value:
            return None
        password = bool(self._property(element, 30019))
        control_id = int(self._property(element, 30003) or 0)
        rectangle = self._property(element, 30001)
        x = int(fallback_point[0]) if fallback_point else 0
        y = int(fallback_point[1]) if fallback_point else 0
        bounds = None
        if isinstance(rectangle, list) and len(rectangle) >= 4:
            left, top, width, height = [safe_float(value) for value in rectangle[:4]]
            if width > 0.0 and height > 0.0 and all(math.isfinite(value) for value in (left, top, width, height)):
                x = int(round(left + width * 0.5))
                y = int(round(top + height * 0.5))
                bounds = [left, top, width, height]
        runtime_id = self._property(element, 30000)
        record = {
            "source": source, "depth": int(depth), "x": x, "y": y, "bounding_rectangle": bounds,
            "runtime_id": list(runtime_id) if isinstance(runtime_id, list) else [],
            "name": str(self._property(element, 30005) or ""),
            "automation_id": str(self._property(element, 30011) or ""),
            "class_name": str(self._property(element, 30012) or ""),
            "control_id": control_id,
            "control_type": CONTROL_TYPES.get(control_id, "Control" + str(control_id) if control_id else "Unknown"),
            "enabled": bool(self._property(element, 30010)),
            "focused": bool(self._property(element, 30008)),
            "keyboard_focusable": bool(self._property(element, 30009)),
            "password": password,
            "offscreen": bool(self._property(element, 30022)),
            "help": str(self._property(element, 30013) or ""),
            "value": "" if password else str(self._property(element, 30045) or ""),
        }
        return record

    def _element_from_handle(self, hwnd):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 6, ctypes.c_long, [wintypes.HWND, ctypes.POINTER(ctypes.c_void_p)], hwnd, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _element_from_point(self, point):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 7, ctypes.c_long, [Point, ctypes.POINTER(ctypes.c_void_p)], Point(int(point[0]), int(point[1])), ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _focused_element(self):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 8, ctypes.c_long, [ctypes.POINTER(ctypes.c_void_p)], ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _first_child(self, element):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.walker, 4, ctypes.c_long, [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], element, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _next_sibling(self, element):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.walker, 6, ctypes.c_long, [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], element, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _release(self, element):
        try:
            if element and element.value:
                self._call(element, 2, ctypes.c_ulong, [])
        except Exception:
            pass

    @staticmethod
    def _record_key(record):
        runtime = tuple(record.get("runtime_id") or ())
        if runtime:
            return ("runtime", runtime)
        bounds = tuple(round(safe_float(value), 1) for value in (record.get("bounding_rectangle") or []))
        return (record.get("name", ""), record.get("automation_id", ""), record.get("control_type", ""), bounds, record.get("x", 0), record.get("y", 0))

    def _tree_records(self, root, fallback_point):
        if not root or not root.value or not self.walker.value:
            return []
        records = []
        # 迭代遍历使 UIA 深度可以随资源增长，不受 Python 递归深度这一隐含上限约束。
        stack = [(root, 0, False)]
        while stack and len(records) < self.max_nodes:
            element, depth, owned = stack.pop()
            children = []
            try:
                record = self._record(element, fallback_point, "uia_tree", depth)
                if record:
                    records.append(record)
                if depth < self.max_depth and len(records) < self.max_nodes:
                    child = self._first_child(element)
                    while child and child.value and len(records) + len(stack) + len(children) < self.max_nodes:
                        next_child = self._next_sibling(child)
                        children.append(child)
                        child = next_child
                    if child and child.value:
                        self._release(child)
            finally:
                if owned:
                    self._release(element)
            for child in reversed(children):
                stack.append((child, depth + 1, True))
        for element, _, owned in stack:
            if owned:
                self._release(element)
        return records

    def _native_records(self, hwnd):
        if not hwnd:
            return []
        records = []
        callback_type = self.WINAPI(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        class_map = {
            "button": "Button", "edit": "Edit", "richedit": "Edit", "combobox": "ComboBox",
            "listbox": "List", "syslistview": "List", "systreeview": "Tree", "static": "Text",
            "msctls_progress": "ProgressBar", "scrollbar": "ScrollBar", "toolbarwindow": "ToolBar", "systabcontrol": "Tab",
        }
        try:
            self.user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(Rect)]
            self.user32.GetWindowRect.restype = wintypes.BOOL
            self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
            self.user32.IsWindowVisible.restype = wintypes.BOOL
            self.user32.IsWindowEnabled.argtypes = [wintypes.HWND]
            self.user32.IsWindowEnabled.restype = wintypes.BOOL
            self.user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
            self.user32.GetWindowLongW.restype = ctypes.c_long

            @callback_type
            def visit(child, _):
                native_budget = max(16, int(math.sqrt(max(1, self.max_nodes)) * 4.0))
                if len(records) >= native_budget:
                    return False
                if not self.user32.IsWindowVisible(child):
                    return True
                title_buffer = ctypes.create_unicode_buffer(256)
                class_buffer = ctypes.create_unicode_buffer(128)
                self.user32.GetWindowTextW(child, title_buffer, len(title_buffer))
                self.user32.GetClassNameW(child, class_buffer, len(class_buffer))
                class_lower = class_buffer.value.lower()
                control_type = "Custom"
                for prefix, mapped in class_map.items():
                    if class_lower.startswith(prefix):
                        control_type = mapped
                        break
                if not title_buffer.value and control_type == "Custom":
                    return True
                rectangle = Rect()
                if not self.user32.GetWindowRect(child, ctypes.byref(rectangle)):
                    return True
                if rectangle.right <= rectangle.left or rectangle.bottom <= rectangle.top:
                    return True
                password = control_type == "Edit" and bool(int(self.user32.GetWindowLongW(child, -16)) & 0x20)
                width = rectangle.right - rectangle.left
                height = rectangle.bottom - rectangle.top
                records.append({
                    "source": "native", "depth": 1,
                    "x": int((rectangle.left + rectangle.right) // 2), "y": int((rectangle.top + rectangle.bottom) // 2),
                    "bounding_rectangle": [float(rectangle.left), float(rectangle.top), float(width), float(height)], "runtime_id": [],
                    "name": title_buffer.value, "automation_id": "", "class_name": class_buffer.value, "control_id": 0,
                    "control_type": control_type, "enabled": bool(self.user32.IsWindowEnabled(child)), "focused": False,
                    "keyboard_focusable": control_type in INTERACTIVE_CONTROL_TYPES, "password": password, "offscreen": False, "help": "", "value": "",
                })
                return True

            self.user32.EnumChildWindows.argtypes = [wintypes.HWND, callback_type, wintypes.LPARAM]
            self.user32.EnumChildWindows.restype = wintypes.BOOL
            self.user32.EnumChildWindows(hwnd, visit, 0)
        except Exception:
            return records
        return records

    def snapshot(self, points, fallback_point, deep=True):
        hwnd = self.user32.GetForegroundWindow()
        title_buffer = ctypes.create_unicode_buffer(512)
        class_buffer = ctypes.create_unicode_buffer(256)
        if hwnd:
            self.user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
            self.user32.GetClassNameW(hwnd, class_buffer, len(class_buffer))
        snapshot = AccessibilitySnapshot(int(hwnd or 0), title_buffer.value, class_buffer.value, [])
        if not self.available:
            snapshot.records.extend(self._native_records(hwnd))
            return snapshot
        elements = []
        try:
            active = self._element_from_handle(hwnd) if hwnd else ctypes.c_void_p()
            elements.append(active)
            if active.value:
                if deep:
                    snapshot.records.extend(self._tree_records(active, fallback_point))
                else:
                    root_record = self._record(active, fallback_point, "uia_shallow", 0)
                    if root_record:
                        snapshot.records.append(root_record)
            focused = self._focused_element()
            elements.append(focused)
            extras = [(focused, fallback_point, "focus")]
            for index, point in enumerate(points):
                element = self._element_from_point(point)
                elements.append(element)
                extras.append((element, point, "point" + str(index)))
            seen = {self._record_key(record) for record in snapshot.records}
            for element, point, source in extras:
                record = self._record(element, point, source, 0)
                if record:
                    key = self._record_key(record)
                    if key not in seen:
                        seen.add(key)
                        snapshot.records.append(record)
            for record in self._native_records(hwnd):
                key = self._record_key(record)
                if key not in seen:
                    seen.add(key)
                    snapshot.records.append(record)
        finally:
            for element in elements:
                self._release(element)
        return snapshot


def rgb_edges(rgb, width, height):
    luminance = []
    for index in range(0, len(rgb), 3):
        luminance.append(rgb[index] * 0.2126 + rgb[index + 1] * 0.7152 + rgb[index + 2] * 0.0722)
    edges = []
    for row in range(height):
        for column in range(width):
            index = row * width + column
            value = 0.0
            count = 0
            if column + 1 < width:
                value += abs(luminance[index] - luminance[index + 1]); count += 1
            if row + 1 < height:
                value += abs(luminance[index] - luminance[index + width]); count += 1
            edges.append(clamp(value / max(1, count) * 2.2, 0.0, 1.0))
    return edges, luminance


class Observation:
    def __init__(self, global_rgb, patches, cursor, interest, focus, patch_centers, accessibility, roi_pyramid=None):
        self.global_rgb = global_rgb
        self.patches = patches
        self.roi_pyramid = list(roi_pyramid or [])
        self.cursor_x, self.cursor_y = cursor
        self.interest_x, self.interest_y = interest
        self.focus_x, self.focus_y = focus
        self.patch_centers = patch_centers
        self.accessibility = accessibility
        self.global_edges, self.global_luminance = rgb_edges(global_rgb, GLOBAL_W, GLOBAL_H)
        self.patch_edges = []
        self.patch_luminance = []
        for patch in patches:
            edges, luminance = rgb_edges(patch, PATCH_W, PATCH_H)
            self.patch_edges.append(edges)
            self.patch_luminance.append(luminance)
        self.semantic_text = accessibility.text()
        semantic_normalized = "|".join(semantic_units(self.semantic_text))
        self.semantic_signature = hashlib.blake2s(semantic_normalized.encode("utf-8", "ignore"), digest_size=12).hexdigest()
        visual_sample = []
        combined_visual = self.global_luminance + self.global_edges
        stride = max(1, len(combined_visual) // 64)
        for index in range(0, len(combined_visual), stride):
            visual_sample.append(int(clamp(combined_visual[index], 0.0, 1.0) * 15.999))
            if len(visual_sample) >= 64:
                break
        self.visual_signature = hashlib.blake2s(bytes(visual_sample), digest_size=12).hexdigest()
        self.signature = self.semantic_signature + ":" + self.visual_signature
        control_counts = Counter(str(record.get("control_type", "")) for record in accessibility.records if record.get("control_type") and not record.get("offscreen"))
        control_shape = " ".join("{}{}".format(name, count) for name, count in sorted(control_counts.items()))
        focused = next((record for record in accessibility.records if record.get("focused")), None)
        focus_text = "" if focused is None else " ".join((str(focused.get("control_type", "")), str(focused.get("name", "")), str(focused.get("automation_id", ""))))
        semantic_tokens = semantic_units(self.semantic_text)
        self.fuzzy_key = " ".join(("window", accessibility.window_class, "controls", control_shape, "focus", focus_text, "tokens", " ".join(semantic_tokens)))
        self.any_password = any(record.get("password") for record in accessibility.records)
        visible_records = [record for record in accessibility.records if not record.get("offscreen") and record.get("enabled")]
        named_records = [record for record in visible_records if str(record.get("name", "")).strip() or str(record.get("value", "")).strip()]
        interactive_records = [record for record in visible_records if record.get("control_type") in INTERACTIVE_CONTROL_TYPES]
        self.uia_quality = clamp(len(named_records) / 12.0, 0.0, 1.0) * 0.55 + clamp(len(interactive_records) / 6.0, 0.0, 1.0) * 0.35 + (0.10 if accessibility.window_title else 0.0)
        self.perception_limited = self.uia_quality < 0.22

    @staticmethod
    def _rgb_stats(rgb):
        channels = [rgb[offset::3] for offset in range(3)]
        means = [sum(channel) / max(1, len(channel)) for channel in channels]
        deviations = []
        for channel, mean in zip(channels, means):
            deviations.append(math.sqrt(sum((value - mean) ** 2 for value in channel) / max(1, len(channel))))
        return means, deviations

    def control_points(self):
        result = []
        for record in self.accessibility.records:
            if record.get("offscreen") or not record.get("enabled"):
                continue
            x = clamp(float(record.get("x_norm", 0.5)), 0.0, 1.0)
            y = clamp(float(record.get("y_norm", 0.5)), 0.0, 1.0)
            result.append((x, y, record))
        return result

    def features(self):
        values = list(self.global_rgb) + list(self.global_edges)
        for patch, edges in zip(self.patches, self.patch_edges):
            values.extend(patch)
            values.extend(edges)
        ui_items = [self.accessibility.window_title, self.accessibility.window_class]
        for record in self.accessibility.records:
            flags = "enabled{} focus{} password{}".format(int(bool(record.get("enabled"))), int(bool(record.get("focused"))), int(bool(record.get("password"))))
            ui_items.append(" ".join((record.get("control_type", ""), record.get("name", ""), record.get("automation_id", ""), record.get("class_name", ""), record.get("help", ""), record.get("value", ""), flags)))
        values.extend(hashed_features(ui_items, UI_FEATURES))
        means, deviations = self._rgb_stats(self.global_rgb)
        extra = means + [clamp(value * 2.0, 0.0, 1.0) for value in deviations] + [sum(self.global_edges) / max(1, len(self.global_edges))]
        for patch, edges in zip(self.patches, self.patch_edges):
            patch_means, _ = self._rgb_stats(patch)
            extra.extend(patch_means + [sum(edges) / max(1, len(edges))])
        enabled_count = sum(1 for record in self.accessibility.records if record.get("enabled"))
        focused_count = sum(1 for record in self.accessibility.records if record.get("focused"))
        extra.extend([
            self.cursor_x, self.cursor_y, self.interest_x, self.interest_y, self.focus_x, self.focus_y,
            clamp(len(self.accessibility.records) / 12.0, 0.0, 1.0), clamp(len(self.semantic_text) / 512.0, 0.0, 1.0),
            1.0 if self.any_password else 0.0, 1.0 if self.accessibility.hwnd else 0.0,
            clamp(focused_count, 0.0, 1.0), enabled_count / max(1, len(self.accessibility.records)),
            1.0 if self.accessibility.window_title else 0.0,
        ])
        if len(extra) != OBS_EXTRA:
            raise ValueError("观察附加特征维度错误：{}".format(len(extra)))
        values.extend(extra)
        expected = GLOBAL_FEATURES + PATCH_FEATURES + UI_FEATURES + OBS_EXTRA
        if len(values) != expected:
            raise ValueError("视觉状态维度错误：{} != {}".format(len(values), expected))
        return [clamp(float(value), 0.0, 1.0) for value in values]

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        records = [record for record in self.accessibility.records if not record.get("offscreen")]
        records.sort(key=lambda record: (
            not bool(record.get("focused")),
            record.get("control_type") not in INTERACTIVE_CONTROL_TYPES,
            not bool(record.get("name")),
            int(record.get("depth", 0)),
        ))
        values = []
        # 自适应输入首先购买真正的高分辨率 ROI 视觉槽位，而不是只增加控件哈希数量。
        visual_budget = min(count, max(0, int(count * 0.55))) if self.roi_pyramid else 0
        if visual_budget:
            visual_values = []
            for item in self.roi_pyramid:
                rgb = list(item.get("rgb", []))
                width = max(1, int(item.get("width", 1))); height = max(1, int(item.get("height", 1)))
                if not rgb:
                    continue
                edges, luminance = rgb_edges(rgb, width, height)
                # 分块池化保留空间布局；分辨率越高，新增输入槽可编码越细的局部结构。
                tiles = max(1, int(math.sqrt(max(1, visual_budget // max(1, len(self.roi_pyramid))))))
                for row in range(tiles):
                    for col in range(tiles):
                        xs = range(int(col * width / tiles), max(int((col + 1) * width / tiles), int(col * width / tiles) + 1))
                        ys = range(int(row * height / tiles), max(int((row + 1) * height / tiles), int(row * height / tiles) + 1))
                        idx = [y * width + x for y in ys for x in xs if 0 <= x < width and 0 <= y < height]
                        if idx:
                            visual_values.extend((sum(luminance[i] for i in idx) / len(idx), sum(edges[i] for i in idx) / len(idx)))
                        if len(visual_values) >= visual_budget:
                            break
                    if len(visual_values) >= visual_budget:
                        break
                if len(visual_values) >= visual_budget:
                    break
            values.extend(normalize_state(visual_values, visual_budget))
        # 剩余槽位保存逐控件结构。
        control_budget = max(0, count - len(values))
        slot_width = 10
        slot_count = min(len(records), max(0, int(control_budget * 0.72) // slot_width))
        for record in records[:slot_count]:
            text_hash = hashlib.blake2s("|".join((
                str(record.get("control_type", "")), str(record.get("name", "")),
                str(record.get("automation_id", "")), str(record.get("class_name", "")), str(record.get("value", "")),
            )).encode("utf-8", "ignore"), digest_size=4).digest()
            values.extend([
                clamp(float(record.get("x_norm", 0.5)), 0.0, 1.0),
                clamp(float(record.get("y_norm", 0.5)), 0.0, 1.0),
                1.0 if record.get("enabled") else 0.0,
                1.0 if record.get("focused") else 0.0,
                1.0 if record.get("keyboard_focusable") else 0.0,
                1.0 if record.get("password") else 0.0,
                1.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 0.0,
                clamp(int(record.get("depth", 0)) / 12.0, 0.0, 1.0),
                int.from_bytes(text_hash[:2], "little") / 65535.0,
                int.from_bytes(text_hash[2:], "little") / 65535.0,
            ])
        remaining = max(0, count - len(values))
        if remaining:
            # 注意力式池化：焦点/可交互控件重复加权，保留“集合”信息而不是依赖固定顺序。
            pooled = []
            for record in records:
                text = " ".join((record.get("control_type", ""), record.get("name", ""), record.get("automation_id", ""), record.get("value", "")))
                weight = 1 + int(bool(record.get("focused"))) * 3 + int(record.get("control_type") in INTERACTIVE_CONTROL_TYPES) * 2
                pooled.extend([text] * weight)
            values.extend(hashed_features(pooled, remaining))
        return normalize_state(values, count)


class InputGateClosed(OSError):
    pass


class SharedInputGate:
    """跨线程/跨进程硬输入闸门。close 与正常 SendInput 使用同一把锁，关闭后本轮不可重开。"""
    def __init__(self, closed_event=None, lock=None, stop_event=None):
        self.closed_event = closed_event
        self.lock = lock
        self.stop_event = stop_event

    def is_closed(self):
        return bool((self.closed_event is not None and self.closed_event.is_set()) or (self.stop_event is not None and self.stop_event.is_set()))

    def close(self):
        if self.lock is None:
            if self.closed_event is not None: self.closed_event.set()
            if self.stop_event is not None: self.stop_event.set()
            return
        with self.lock:
            if self.closed_event is not None: self.closed_event.set()
            if self.stop_event is not None: self.stop_event.set()

    def run_if_open(self, callback):
        if self.lock is None:
            if self.is_closed():
                raise InputGateClosed("输入闸门已关闭")
            return callback()
        with self.lock:
            if self.is_closed():
                raise InputGateClosed("输入闸门已关闭")
            return callback()


class WinIO:
    VK_ESCAPE = 0x1B
    VK_SHIFT = 0x10
    VK_CONTROL = 0x11
    VK_MENU = 0x12
    INPUT_MOUSE = 0
    INPUT_KEYBOARD = 1
    KEYEVENTF_EXTENDEDKEY = 0x0001
    KEYEVENTF_KEYUP = 0x0002
    KEYEVENTF_UNICODE = 0x0004
    MOUSEEVENTF_MOVE = 0x0001
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    MOUSEEVENTF_RIGHTDOWN = 0x0008
    MOUSEEVENTF_RIGHTUP = 0x0010
    MOUSEEVENTF_WHEEL = 0x0800
    MOUSEEVENTF_VIRTUALDESK = 0x4000
    MOUSEEVENTF_ABSOLUTE = 0x8000
    SRCCOPY = 0x00CC0020
    DIB_RGB_COLORS = 0
    HALFTONE = 4
    DESKTOP_READOBJECTS = 0x0001
    DESKTOP_SWITCHDESKTOP = 0x0100
    UOI_NAME = 2
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

    def __init__(self, capacities=None, input_enabled=True, input_gate_event=None, input_gate_lock=None, stop_event=None, send_input_adapter=None, resource_budget=None):
        if os.name != "nt":
            raise OSError("仅支持 Windows")
        self.capacities = dict(capacities or {})
        self.input_enabled = bool(input_enabled)
        self.input_gate = SharedInputGate(input_gate_event, input_gate_lock, stop_event)
        self._send_input_adapter = send_input_adapter
        self.resource_budget = resource_budget
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self._desktop_cache = (0.0, False, "unknown")
        self._parent_cache = {}
        self._last_full_scan_at = 0.0
        self.last_capture_seconds = 0.0
        self.last_uia_seconds = 0.0
        self.last_capture_cache_hit = False
        self.capture_cache_hits = 0
        self.capture_full_scans = 0
        self._configure_functions()
        self.left = self.user32.GetSystemMetrics(76)
        self.top = self.user32.GetSystemMetrics(77)
        self.width = max(1, self.user32.GetSystemMetrics(78) or self.user32.GetSystemMetrics(0))
        self.height = max(1, self.user32.GetSystemMetrics(79) or self.user32.GetSystemMetrics(1))
        self.last_interest = (self.left + self.width // 2, self.top + self.height // 2)
        self.accessibility = AccessibilityReader(self.user32, self.capacities.get("uia_depth", 4), self.capacities.get("uia_nodes", 128))
        self.set_capacities(self.capacities)

    def set_capacities(self, capacities):
        self.capacities = dict(capacities or {})
        if self.resource_budget is not None:
            self.resource_budget.refresh(perception_latency=self.last_capture_seconds)
            learned_scale = max(1, int(self.capacities.get("visual_roi_scale", 1)))
            self.capacities["visual_roi_scale"] = min(learned_scale, self.resource_budget.visual_roi_scale())
        self.accessibility.set_capacity(self.capacities.get("uia_depth", 4), self.capacities.get("uia_nodes", 128))

    def _configure_functions(self):
        self.user32.GetSystemMetrics.argtypes = [ctypes.c_int]
        self.user32.GetSystemMetrics.restype = ctypes.c_int
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.ReleaseDC.restype = ctypes.c_int
        self.user32.GetCursorPos.argtypes = [ctypes.POINTER(Point)]
        self.user32.GetCursorPos.restype = wintypes.BOOL
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        self.user32.SendInput.restype = wintypes.UINT
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetWindowTextW.restype = ctypes.c_int
        self.user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetClassNameW.restype = ctypes.c_int
        self.user32.GetGUIThreadInfo.argtypes = [wintypes.DWORD, ctypes.POINTER(GuiThreadInfo)]
        self.user32.GetGUIThreadInfo.restype = wintypes.BOOL
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.OpenInputDesktop.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.user32.OpenInputDesktop.restype = wintypes.HANDLE
        self.user32.CloseDesktop.argtypes = [wintypes.HANDLE]
        self.user32.CloseDesktop.restype = wintypes.BOOL
        self.user32.GetUserObjectInformationW.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetUserObjectInformationW.restype = wintypes.BOOL
        self.user32.IsWindow.argtypes = [wintypes.HWND]
        self.user32.IsWindow.restype = wintypes.BOOL
        self.user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
        self.user32.GetWindow.restype = wintypes.HWND
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        self.kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        self.kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry32W)]
        self.kernel32.Process32FirstW.restype = wintypes.BOOL
        self.kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry32W)]
        self.kernel32.Process32NextW.restype = wintypes.BOOL
        self.user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(Point)]
        self.user32.ClientToScreen.restype = wintypes.BOOL
        self.gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
        self.gdi32.CreateCompatibleDC.restype = wintypes.HDC
        self.gdi32.DeleteDC.argtypes = [wintypes.HDC]
        self.gdi32.DeleteDC.restype = wintypes.BOOL
        self.gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        self.gdi32.CreateCompatibleBitmap.restype = wintypes.HBITMAP
        self.gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
        self.gdi32.SelectObject.restype = wintypes.HGDIOBJ
        self.gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
        self.gdi32.DeleteObject.restype = wintypes.BOOL
        self.gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        self.gdi32.SetStretchBltMode.restype = ctypes.c_int
        self.gdi32.StretchBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.DWORD]
        self.gdi32.StretchBlt.restype = wintypes.BOOL
        self.gdi32.GetDIBits.argtypes = [wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT, ctypes.c_void_p, ctypes.POINTER(BitmapInfo), wintypes.UINT]
        self.gdi32.GetDIBits.restype = ctypes.c_int

    @staticmethod
    def desktop_name_is_safe(name):
        return str(name or "").strip().lower() == "default"

    def input_desktop_status(self, force=False):
        now = time.monotonic()
        cached_at, cached_safe, cached_name = self._desktop_cache
        if not force and now - cached_at < 0.05:
            return cached_safe, cached_name
        desktop = self.user32.OpenInputDesktop(0, False, self.DESKTOP_READOBJECTS | self.DESKTOP_SWITCHDESKTOP)
        if not desktop:
            self._desktop_cache = (now, False, "unavailable")
            return False, "unavailable"
        try:
            needed = wintypes.DWORD(0)
            self.user32.GetUserObjectInformationW(desktop, self.UOI_NAME, None, 0, ctypes.byref(needed))
            count = max(64, int(needed.value // ctypes.sizeof(ctypes.c_wchar) + 2))
            buffer = ctypes.create_unicode_buffer(count)
            if not self.user32.GetUserObjectInformationW(desktop, self.UOI_NAME, buffer, ctypes.sizeof(buffer), ctypes.byref(needed)):
                safe, name = False, "unknown"
            else:
                name = str(buffer.value or "unknown")
                safe = self.desktop_name_is_safe(name)
        finally:
            self.user32.CloseDesktop(desktop)
        self._desktop_cache = (now, safe, name)
        return safe, name

    def _parent_process_id(self, process_id):
        process_id = int(process_id or 0)
        now = time.monotonic()
        cached = self._parent_cache.get(process_id)
        if cached and now - cached[0] < 2.0:
            return int(cached[1])
        parent = 0
        snapshot = self.kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        invalid = ctypes.c_void_p(-1).value
        if snapshot and int(snapshot) != int(invalid):
            try:
                entry = ProcessEntry32W()
                entry.dwSize = ctypes.sizeof(ProcessEntry32W)
                ok = bool(self.kernel32.Process32FirstW(snapshot, ctypes.byref(entry)))
                while ok:
                    if int(entry.th32ProcessID) == process_id:
                        parent = int(entry.th32ParentProcessID)
                        break
                    ok = bool(self.kernel32.Process32NextW(snapshot, ctypes.byref(entry)))
            finally:
                self.kernel32.CloseHandle(snapshot)
        self._parent_cache[process_id] = (now, parent)
        return parent

    def foreground_context(self):
        hwnd = int(self.user32.GetForegroundWindow() or 0)
        pid = wintypes.DWORD(0)
        if hwnd:
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        title_buffer = ctypes.create_unicode_buffer(512)
        class_buffer = ctypes.create_unicode_buffer(256)
        if hwnd:
            self.user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
            self.user32.GetClassNameW(hwnd, class_buffer, len(class_buffer))
        process_path = ""
        if pid.value:
            handle = self.kernel32.OpenProcess(self.PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
            if handle:
                try:
                    size = wintypes.DWORD(2048)
                    buffer = ctypes.create_unicode_buffer(size.value)
                    if self.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
                        process_path = buffer.value
                finally:
                    self.kernel32.CloseHandle(handle)
        safe_desktop, desktop_name = self.input_desktop_status()
        owner_hwnd = int(self.user32.GetWindow(hwnd, 4) or 0) if hwnd else 0
        return {
            "hwnd": hwnd, "process_id": int(pid.value), "process_path": process_path,
            "process_name": os.path.basename(process_path).lower() if process_path else "",
            "window_title": title_buffer.value, "window_class": class_buffer.value,
            "desktop_name": desktop_name, "desktop_safe": bool(safe_desktop),
            "parent_process_id": self._parent_process_id(pid.value), "owner_hwnd": owner_hwnd,
        }

    def input_allowed(self):
        safe, _ = self.input_desktop_status(force=True)
        return bool(safe)

    def close(self):
        self.accessibility.close()

    def close_input_gate(self):
        self.input_gate.close()

    def input_gate_closed(self):
        return self.input_gate.is_closed()

    def escape_down(self):
        return bool(self.user32.GetAsyncKeyState(self.VK_ESCAPE) & 0x8000)

    def wait_escape_release(self, stop_event):
        while self.escape_down() and not stop_event.wait(0.025):
            pass

    def cursor_pixels(self):
        point = Point()
        if not self.user32.GetCursorPos(ctypes.byref(point)):
            return self.left + self.width // 2, self.top + self.height // 2
        return int(point.x), int(point.y)

    def normalize_point(self, point):
        return (
            clamp((point[0] - self.left) / max(1, self.width - 1), 0.0, 1.0),
            clamp((point[1] - self.top) / max(1, self.height - 1), 0.0, 1.0),
        )

    def denormalize_point(self, x, y):
        return self.left + int(clamp(x, 0.0, 1.0) * (self.width - 1)), self.top + int(clamp(y, 0.0, 1.0) * (self.height - 1))

    def focus_pixels(self):
        foreground = self.user32.GetForegroundWindow()
        if not foreground:
            return self.cursor_pixels()
        thread_id = self.user32.GetWindowThreadProcessId(foreground, None)
        info = GuiThreadInfo()
        info.cbSize = ctypes.sizeof(GuiThreadInfo)
        if thread_id and self.user32.GetGUIThreadInfo(thread_id, ctypes.byref(info)) and info.hwndCaret:
            point = Point((info.rcCaret.left + info.rcCaret.right) // 2, (info.rcCaret.top + info.rcCaret.bottom) // 2)
            if self.user32.ClientToScreen(info.hwndCaret, ctypes.byref(point)):
                return int(point.x), int(point.y)
        return self.cursor_pixels()

    def _capture_scaled(self, left, top, source_width, source_height, target_width, target_height):
        screen_dc = self.user32.GetDC(None)
        if not screen_dc:
            raise OSError("无法读取屏幕")
        memory_dc = self.gdi32.CreateCompatibleDC(screen_dc)
        bitmap = self.gdi32.CreateCompatibleBitmap(screen_dc, target_width, target_height)
        if not memory_dc or not bitmap:
            if memory_dc:
                self.gdi32.DeleteDC(memory_dc)
            self.user32.ReleaseDC(None, screen_dc)
            raise OSError("无法创建屏幕采样缓冲区")
        old = self.gdi32.SelectObject(memory_dc, bitmap)
        try:
            self.gdi32.SetStretchBltMode(memory_dc, self.HALFTONE)
            if not self.gdi32.StretchBlt(memory_dc, 0, 0, target_width, target_height, screen_dc, int(left), int(top), int(source_width), int(source_height), self.SRCCOPY):
                raise OSError("屏幕缩放采样失败")
            info = BitmapInfo()
            info.bmiHeader.biSize = ctypes.sizeof(BitmapInfoHeader)
            info.bmiHeader.biWidth = target_width
            info.bmiHeader.biHeight = -target_height
            info.bmiHeader.biPlanes = 1
            info.bmiHeader.biBitCount = 32
            info.bmiHeader.biCompression = 0
            buffer = (ctypes.c_ubyte * (target_width * target_height * 4))()
            rows = self.gdi32.GetDIBits(memory_dc, bitmap, 0, target_height, ctypes.byref(buffer), ctypes.byref(info), self.DIB_RGB_COLORS)
            if rows != target_height:
                raise OSError("屏幕像素读取失败")
            pixels = []
            for index in range(0, len(buffer), 4):
                pixels.extend((buffer[index + 2] / 255.0, buffer[index + 1] / 255.0, buffer[index] / 255.0))
            return pixels
        finally:
            if old:
                self.gdi32.SelectObject(memory_dc, old)
            self.gdi32.DeleteObject(bitmap)
            self.gdi32.DeleteDC(memory_dc)
            self.user32.ReleaseDC(None, screen_dc)

    def _interest_from_change(self, rgb, previous):
        _, luminance = rgb_edges(rgb, GLOBAL_W, GLOBAL_H)
        if previous is None or len(previous.global_luminance) != len(luminance):
            return self.cursor_pixels()
        best_score = -1.0
        best_column = GLOBAL_W // 2
        best_row = GLOBAL_H // 2
        for row in range(GLOBAL_H):
            for column in range(GLOBAL_W):
                index = row * GLOBAL_W + column
                score = abs(luminance[index] - previous.global_luminance[index])
                if column + 1 < GLOBAL_W:
                    score += abs(luminance[index] - luminance[index + 1]) * 0.28
                if row + 1 < GLOBAL_H:
                    score += abs(luminance[index] - luminance[index + GLOBAL_W]) * 0.28
                if score > best_score:
                    best_score, best_column, best_row = score, column, row
        x = self.left + int((best_column + 0.5) * self.width / GLOBAL_W)
        y = self.top + int((best_row + 0.5) * self.height / GLOBAL_H)
        if best_score < 0.025:
            cursor = self.cursor_pixels()
            x = int(cursor[0] * 0.72 + self.last_interest[0] * 0.28)
            y = int(cursor[1] * 0.72 + self.last_interest[1] * 0.28)
        self.last_interest = (x, y)
        return x, y

    def capture(self, previous=None, force_deep=False):
        started = time.perf_counter()
        global_rgb = self._capture_scaled(self.left, self.top, self.width, self.height, GLOBAL_W, GLOBAL_H)
        cursor = self.cursor_pixels()
        interest = self._interest_from_change(global_rgb, previous)
        focus = self.focus_pixels()
        focus_norm = self.normalize_point(focus)
        context = self.foreground_context()
        previous_rgb = list(getattr(previous, "global_rgb", []) or [])
        visual_change = 1.0
        if previous_rgb and len(previous_rgb) == len(global_rgb):
            visual_change = sum(abs(float(left) - float(right)) for left, right in zip(previous_rgb, global_rgb)) / len(global_rgb)
        same_window = bool(
            previous is not None
            and int(getattr(previous.accessibility, "hwnd", 0) or 0) == int(context.get("hwnd", 0) or 0)
            and int(getattr(previous, "process_id", 0) or 0) == int(context.get("process_id", 0) or 0)
        )
        focus_stable = bool(previous is not None and math.hypot(focus_norm[0] - previous.focus_x, focus_norm[1] - previous.focus_y) < 0.004)
        cache_seconds = max(0.02, int(self.capacities.get("observation_cache_ms", 120)) / 1000.0)
        cache_fresh = time.monotonic() - self._last_full_scan_at <= cache_seconds
        cache_hit = bool(previous is not None and same_window and focus_stable and visual_change < 0.0025 and cache_fresh and not force_deep)
        probe_points = [cursor, interest, focus]

        snapshot = None
        patches = None
        regions = None
        selected = None
        roi_pyramid = []
        uia_started = time.perf_counter()
        # 无论低分辨率视觉是否变化，都做浅 UIA 扫描并与旧结构 diff；文字/enabled/bounds/id 改变立即废弃缓存。
        shallow = self.accessibility.snapshot(probe_points, focus, deep=False)
        previous_focused = None if previous is None else next((self.accessibility._record_key(record) for record in previous.accessibility.records if record.get("focused")), None)
        shallow_focused = next((self.accessibility._record_key(record) for record in shallow.records if record.get("focused")), None)

        def record_state(record):
            return (str(record.get("name", "")), str(record.get("value", "")), bool(record.get("enabled")),
                    tuple(record.get("bounding_rectangle") or ()), str(record.get("automation_id", "")))

        structure_changed = False
        if previous is not None:
            previous_map = {self.accessibility._record_key(record): record_state(record) for record in previous.accessibility.records}
            for record in shallow.records:
                key = self.accessibility._record_key(record)
                if key not in previous_map or previous_map[key] != record_state(record):
                    structure_changed = True
                    break
        anomaly = bool(
            force_deep or previous is None or not same_window or not focus_stable or visual_change >= 0.006
            or len(shallow.records) < 2 or shallow_focused != previous_focused or structure_changed
        )
        if anomaly:
            snapshot = self.accessibility.snapshot(probe_points, focus, deep=True)
            self._last_full_scan_at = time.monotonic()
            self.capture_full_scans += 1
        else:
            snapshot = previous.accessibility
            self.last_capture_cache_hit = True
            self.capture_cache_hits += 1
            if cache_hit:
                patches = list(previous.patches)
                regions = list(getattr(previous, "regions", []))
                selected = [self.denormalize_point(x, y) for x, y in previous.patch_centers]
                roi_pyramid = list(getattr(previous, "roi_pyramid", []))
        self.last_uia_seconds = time.perf_counter() - uia_started
        self.last_capture_cache_hit = not anomaly

        for record in snapshot.records:
            record["x_norm"], record["y_norm"] = self.normalize_point((record.get("x", cursor[0]), record.get("y", cursor[1])))
        if selected is None:
            candidates = [(focus, 4.0), (interest, 3.0), (cursor, 2.0)]
            breadth = max(3, int(self.capacities.get("attention_candidates", 8)))
            for record in snapshot.records[:breadth]:
                if record.get("offscreen") or not record.get("enabled") or not record.get("bounding_rectangle"):
                    continue
                score = 1.0 + (4.0 if record.get("focused") else 0.0) + (2.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 0.0) + (0.5 if record.get("name") else 0.0)
                candidates.append(((int(record.get("x", cursor[0])), int(record.get("y", cursor[1]))), score))
            selected = []
            for point, score in sorted(candidates, key=lambda item: item[1], reverse=True):
                if all(math.hypot(point[0] - other[0], point[1] - other[1]) > max(50, min(self.width, self.height) * 0.06) for other in selected):
                    selected.append(point)
                if len(selected) >= PATCH_COUNT:
                    break
            while len(selected) < PATCH_COUNT:
                selected.append(probe_points[len(selected) % len(probe_points)])

        if patches is None:
            patches, regions = [], []
            patch_width = min(self.width, max(300, int(self.width * 0.30)))
            patch_height = min(self.height, max(200, int(self.height * 0.30)))
            for center in selected:
                left = int(clamp(center[0] - patch_width // 2, self.left, self.left + self.width - patch_width))
                top = int(clamp(center[1] - patch_height // 2, self.top, self.top + self.height - patch_height))
                patches.append(self._capture_scaled(left, top, patch_width, patch_height, PATCH_W, PATCH_H))
                regions.append({"left": left, "top": top, "width": patch_width, "height": patch_height, "center": self.normalize_point(center)})
                requested_scale = max(1, int(self.capacities.get("visual_roi_scale", 2)))
                # ROI 金字塔：每个关注区额外保留更高分辨率采样，供 adaptive_input 直接编码。
                for scale in range(2, requested_scale + 1):
                    rw, rh = PATCH_W * scale, PATCH_H * scale
                    roi_pyramid.append({"rgb": self._capture_scaled(left, top, patch_width, patch_height, rw, rh), "width": rw, "height": rh, "scale": scale, "center": self.normalize_point(center)})
        observation = Observation(
            global_rgb, patches, self.normalize_point(cursor), self.normalize_point(interest), focus_norm,
            [self.normalize_point(point) for point in selected], snapshot, roi_pyramid=roi_pyramid,
        )
        observation.screen_width = self.width
        observation.screen_height = self.height
        observation.regions = regions
        observation.process_id = context.get("process_id", 0)
        observation.process_path = context.get("process_path", "")
        observation.process_name = context.get("process_name", "")
        observation.parent_process_id = context.get("parent_process_id", 0)
        observation.owner_hwnd = context.get("owner_hwnd", 0)
        observation.input_desktop_name = context.get("desktop_name", "unknown")
        observation.input_desktop_safe = bool(context.get("desktop_safe", False))
        observation.capture_cache_hit = bool(self.last_capture_cache_hit)
        observation.visual_change = float(visual_change)
        self.last_capture_seconds = time.perf_counter() - started
        return observation

    def _raw_send(self, input_value):
        if self._send_input_adapter is not None:
            return self._send_input_adapter(input_value)
        return self.user32.SendInput(1, ctypes.byref(input_value), ctypes.sizeof(Input))

    def _send(self, input_value):
        if not self.input_enabled:
            raise OSError("只观察模式禁止 SendInput")
        def perform():
            # 桌面检查与真正 SendInput 都处在同一个 gate 临界区；ESC 关闸后不会再进入这里。
            safe, desktop_name = self.input_desktop_status(force=True)
            if not safe:
                raise OSError("输入桌面不可确认或已进入 Secure Desktop（{}），已 fail-closed 禁止 SendInput".format(desktop_name))
            if self._raw_send(input_value) != 1:
                raise OSError("SendInput 失败")
            return True
        return self.input_gate.run_if_open(perform)

    def _send_release(self, input_value):
        # emergency release 只允许 KEYUP / BUTTONUP，由停止路径使用；它不代表 AI 继续活动。
        if not self.input_enabled:
            return False
        safe, _ = self.input_desktop_status(force=True)
        if not safe:
            return False
        return self._raw_send(input_value) == 1

    def _mouse(self, flags, x=0, y=0, data=0):
        value = Input()
        value.type = self.INPUT_MOUSE
        value.mi = MouseInput(int(x), int(y), ctypes.c_ulong(int(data)).value, int(flags), 0, 0)
        self._send(value)

    def move(self, x, y):
        absolute_x = int(clamp(x, 0.0, 1.0) * 65535)
        absolute_y = int(clamp(y, 0.0, 1.0) * 65535)
        self._mouse(self.MOUSEEVENTF_MOVE | self.MOUSEEVENTF_ABSOLUTE | self.MOUSEEVENTF_VIRTUALDESK, absolute_x, absolute_y)

    def key_event(self, virtual_key, up=False, unicode_scan=0):
        value = Input()
        value.type = self.INPUT_KEYBOARD
        flags = self.KEYEVENTF_KEYUP if up else 0
        if unicode_scan:
            flags |= self.KEYEVENTF_UNICODE
        elif int(virtual_key) in (0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x6F, 0x90):
            flags |= self.KEYEVENTF_EXTENDEDKEY
        value.ki = KeyboardInput(0 if unicode_scan else int(virtual_key), int(unicode_scan), flags, 0, 0)
        self._send(value)

    def key(self, virtual_key, modifiers=()):
        for modifier in modifiers:
            self.key_event(int(modifier), False)
        try:
            self.key_event(int(virtual_key), False)
            self.key_event(int(virtual_key), True)
        finally:
            for modifier in reversed(tuple(modifiers)):
                self.key_event(int(modifier), True)

    def type_text(self, text, stop_event=None, expected_hwnd=0):
        units = str(text).encode("utf-16-le", "surrogatepass")
        for index in range(0, len(units), 2):
            if stop_event is not None and stop_event.is_set():
                return False
            if expected_hwnd and int(self.user32.GetForegroundWindow() or 0) != int(expected_hwnd):
                return False
            scan = units[index] | (units[index + 1] << 8)
            self.key_event(0, False, scan)
            self.key_event(0, True, scan)
            time.sleep(0.006)
        return True

    def execute(self, command, stop_event=None, expected_hwnd=0):
        kind = command.kind
        parameters = command.parameters
        if kind == MOVE:
            self.move(float(parameters.get("x", 0.5)), float(parameters.get("y", 0.5)))
        elif kind == CLICK:
            self.move(float(parameters.get("x", 0.5)), float(parameters.get("y", 0.5)))
            if stop_event is not None and stop_event.wait(0.025):
                return False
            if parameters.get("button") == "right":
                self._mouse(self.MOUSEEVENTF_RIGHTDOWN); self._mouse(self.MOUSEEVENTF_RIGHTUP)
            else:
                self._mouse(self.MOUSEEVENTF_LEFTDOWN); self._mouse(self.MOUSEEVENTF_LEFTUP)
        elif kind == SCROLL:
            self._mouse(self.MOUSEEVENTF_WHEEL, data=int(parameters.get("amount", 120)))
        elif kind == KEY:
            self.key(int(parameters.get("vk", 0x09)), tuple(int(value) for value in parameters.get("modifiers", [])))
        elif kind == TYPE:
            return self.type_text(str(parameters.get("text", "")), stop_event, expected_hwnd)
        return True

    def release_inputs(self):
        if not self.input_enabled:
            return
        for key in (self.VK_SHIFT, self.VK_CONTROL, self.VK_MENU, 0x5B, 0x5C, self.VK_ESCAPE):
            try:
                value = Input(); value.type = self.INPUT_KEYBOARD; value.ki = KeyboardInput(key, 0, self.KEYEVENTF_KEYUP, 0, 0)
                self._send_release(value)
            except Exception:
                pass
        for flag in (self.MOUSEEVENTF_LEFTUP, self.MOUSEEVENTF_RIGHTUP):
            try:
                value = Input(); value.type = self.INPUT_MOUSE; value.mi = MouseInput(0, 0, 0, flag, 0, 0)
                self._send_release(value)
            except Exception:
                pass


def release_inputs_in_watchdog(user32):
    try:
        user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        user32.SendInput.restype = wintypes.UINT
        for key in (0x10, 0x11, 0x12, 0x5B, 0x5C, 0x1B):
            value = Input(); value.type = 1; value.ki = KeyboardInput(key, 0, 0x0002, 0, 0)
            user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input))
        for flag in (0x0004, 0x0010):
            value = Input(); value.type = 0; value.mi = MouseInput(0, 0, 0, flag, 0, 0)
            user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input))
    except Exception:
        pass


def escape_watchdog_process(stop_event, done_event, escape_event=None, release_enabled=True, input_gate_event=None, input_gate_lock=None):
    if os.name != "nt":
        return
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        user32.GetAsyncKeyState.restype = ctypes.c_short
        while not done_event.wait(0.012):
            if user32.GetAsyncKeyState(0x1B) & 0x8000:
                if escape_event is not None:
                    escape_event.set()
                SharedInputGate(input_gate_event, input_gate_lock, stop_event).close()
                if release_enabled:
                    release_inputs_in_watchdog(user32)
                return
    except Exception:
        return


class EscapeWatchdog:
    def __init__(self, context, stop_event, escape_event=None, release_enabled=True, input_gate_event=None, input_gate_lock=None):
        self.context = context
        self.stop_event = stop_event
        self.escape_event = escape_event
        self.release_enabled = bool(release_enabled)
        self.input_gate_event = input_gate_event
        self.input_gate_lock = input_gate_lock
        self.done_event = context.Event()
        self.process = None
        self.thread = None

    def start(self):
        self.done_event.clear()
        try:
            self.process = self.context.Process(target=escape_watchdog_process, args=(self.stop_event, self.done_event, self.escape_event, self.release_enabled, self.input_gate_event, self.input_gate_lock), name="EscapeWatchdog", daemon=True)
            self.process.start()
        except Exception:
            self.process = None
        if self.process is None:
            self.thread = threading.Thread(target=escape_watchdog_process, args=(self.stop_event, self.done_event, self.escape_event, self.release_enabled, self.input_gate_event, self.input_gate_lock), name="EscapeWatchdogFallback", daemon=True)
            self.thread.start()

    def stop(self):
        self.done_event.set()
        if self.process is not None:
            self.process.join(0.6)
            if self.process.is_alive():
                self.process.terminate()
                self.process.join(0.3)
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(0.25)


class WorkingMemory:
    def __init__(self, horizon=16):
        self.horizon = max(8, int(horizon))
        self.actions = deque()
        self.rewards = deque()
        self.goals = deque()
        self.curiosities = deque()
        self.safeties = deque()
        self.effects = deque()
        self.signatures = deque()
        self.steps_since_goal = 0
        self.steps_since_sleep = 0

    def set_horizon(self, horizon):
        self.horizon = max(self.horizon, int(horizon))

    def _trim(self):
        limit = max(128, self.horizon * 8)
        for values in (self.actions, self.rewards, self.goals, self.curiosities, self.safeties, self.effects, self.signatures):
            while len(values) > limit:
                values.popleft()

    def update(self, action, reward, components, signature, slept=False):
        self.actions.append(int(action))
        self.rewards.append(float(reward))
        self.goals.append(float(components.get("goal_reward", 0.0)))
        self.curiosities.append(float(components.get("curiosity_reward", 0.0)))
        self.safeties.append(float(components.get("safety_penalty", 0.0)))
        self.effects.append(float(components.get("effect", 0.0)))
        self.signatures.append(str(signature))
        self._trim()
        if components.get("goal_progress", 0.0) > 0.08:
            self.steps_since_goal = 0
        else:
            self.steps_since_goal += 1
        self.steps_since_sleep = 0 if slept else self.steps_since_sleep + 1

    def grow(self):
        self.horizon += 8
        return self.horizon

    def features(self):
        horizon = min(self.horizon, len(self.actions))
        actions = list(self.actions)[-horizon:]
        rewards = list(self.rewards)[-horizon:]
        goals = list(self.goals)[-horizon:]
        curiosities = list(self.curiosities)[-horizon:]
        safeties = list(self.safeties)[-horizon:]
        effects = list(self.effects)[-horizon:]
        one_hot = [0.0] * ACTION_COUNT
        frequencies = [0.0] * ACTION_COUNT
        if actions:
            one_hot[actions[-1]] = 1.0
            counts = Counter(actions)
            frequencies = [counts[index] / horizon for index in range(ACTION_COUNT)]

        def mapped_last(values, default=0.0):
            return clamp((values[-1] if values else default) * 0.5 + 0.5, 0.0, 1.0)

        def mapped_mean(values, default=0.0):
            return clamp(((sum(values) / len(values)) if values else default) * 0.5 + 0.5, 0.0, 1.0)

        scalars = [
            mapped_last(rewards), mapped_mean(rewards),
            sum(1 for value in rewards if value > 0.08) / max(1, horizon),
            sum(1 for value in rewards if value < -0.08) / max(1, horizon),
            mapped_last(goals), mapped_mean(goals),
            clamp(curiosities[-1] if curiosities else 0.0, 0.0, 1.0),
            clamp(sum(curiosities) / max(1, horizon), 0.0, 1.0),
            clamp(safeties[-1] if safeties else 0.0, 0.0, 1.0),
            clamp(sum(safeties) / max(1, horizon), 0.0, 1.0),
            clamp(effects[-1] * 4.0 if effects else 0.0, 0.0, 1.0),
            clamp(sum(effects) / max(1, horizon) * 4.0, 0.0, 1.0),
            len(set(actions)) / max(1, horizon),
            len(set(list(self.signatures)[-horizon:])) / max(1, horizon),
            clamp(self.steps_since_goal / 80.0, 0.0, 1.0),
            clamp(self.steps_since_sleep / 180.0, 0.0, 1.0),
        ]
        values = one_hot + frequencies + scalars
        if len(values) != MEMORY_FEATURES:
            raise ValueError("工作记忆特征维度错误")
        return values

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        actions = list(self.actions)[-max(1, count // 5):]
        rewards = list(self.rewards)[-len(actions):]
        goals = list(self.goals)[-len(actions):]
        safeties = list(self.safeties)[-len(actions):]
        effects = list(self.effects)[-len(actions):]
        values = []
        # 按时间顺序保留可变长度 episodic 工作轨迹，新输入槽位越多，能看到的历史越长。
        for action, reward, goal, safety, effect in zip(actions, rewards, goals, safeties, effects):
            values.extend([
                action / max(1, ACTION_COUNT - 1),
                clamp(reward * 0.5 + 0.5, 0.0, 1.0),
                clamp(goal * 0.5 + 0.5, 0.0, 1.0),
                clamp(safety, 0.0, 1.0),
                clamp(effect * 4.0, 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        return normalize_state(values, count)


class MetaCognitiveSleep:
    """可解释、有滞回的睡眠决策；完全取消随机强制睡眠。"""

    WEIGHTS = {
        "td_error": 0.18, "pending_experience": 0.16, "repeated_failure": 0.16,
        "skill_conflict": 0.12, "world_uncertainty": 0.13, "goal_stagnation": 0.15,
        "memory_fragmentation": 0.10,
    }

    @staticmethod
    def _skill_conflict(skills):
        skills = list(skills or [])
        if len(skills) < 2:
            return 0.0
        top_score = safe_float(skills[0].get("retrieval_score", skills[0].get("score", 0.0)))
        competing = [skill for skill in skills if top_score - safe_float(skill.get("retrieval_score", skill.get("score", 0.0))) <= 0.12]
        if len(competing) < 2:
            return 0.0
        signatures = set()
        for skill in competing:
            first = (skill.get("steps") or [{}])[0]
            signatures.add(compact_json(first))
        capability_sets = {tuple(sorted(skill.get("capabilities", []))) for skill in competing}
        return clamp((len(signatures) - 1) / max(1, len(competing) - 1) * 0.7 + (len(capability_sets) - 1) / max(1, len(competing)) * 0.3, 0.0, 1.0)

    @classmethod
    def evaluate(cls, model, memory, working, world_uncertainty, eligible_skills, repeated=0, compiler_stalled=False, pending_skill=False):
        horizon = max(1, min(working.horizon, len(working.rewards)))
        rewards = list(working.rewards)[-horizon:]
        safeties = list(working.safeties)[-horizon:]
        failures = sum(1 for reward, safety in zip(rewards, safeties) if reward < -0.08 or safety > 0.25)
        repeated_failure = clamp(failures / max(1, horizon) * 1.6 + max(0, int(repeated) - 1) / max(2.0, math.sqrt(horizon)), 0.0, 1.0)
        pending = memory.pending_experience_count()
        episode_budget = max(1, memory.resource_budget.memory_limits().get("episodic_memory", pending + 1))
        factors = {
            "td_error": clamp(math.tanh(max(0.0, float(model.loss_average)) * 1.4), 0.0, 1.0),
            "pending_experience": clamp(math.log1p(pending) / max(1e-9, math.log1p(episode_budget)), 0.0, 1.0),
            "repeated_failure": repeated_failure,
            "skill_conflict": cls._skill_conflict(eligible_skills),
            "world_uncertainty": clamp(float(world_uncertainty), 0.0, 1.0),
            "goal_stagnation": clamp(1.0 - math.exp(-working.steps_since_goal / max(1.0, math.sqrt(working.horizon) * 3.0)), 0.0, 1.0),
            "memory_fragmentation": memory.fragmentation_score(),
        }
        if compiler_stalled:
            factors["goal_stagnation"] = max(factors["goal_stagnation"], 0.96)
            factors["world_uncertainty"] = max(factors["world_uncertainty"], 0.78)
        if pending_skill:
            factors["pending_experience"] = max(factors["pending_experience"], 0.72)
        score = sum(cls.WEIGHTS[name] * factors[name] for name in cls.WEIGHTS)
        if compiler_stalled:
            score = max(score, SLEEP_ENTER_THRESHOLD + 0.01)
        reasons = [name for name, value in sorted(factors.items(), key=lambda item: item[1], reverse=True) if value >= 0.35]
        return {
            "score": clamp(score, 0.0, 1.0), "factors": factors, "reasons": reasons,
            "enter_threshold": SLEEP_ENTER_THRESHOLD, "wake_threshold": SLEEP_WAKE_THRESHOLD,
            "should_sleep": score >= SLEEP_ENTER_THRESHOLD,
        }

    @classmethod
    def after_sleep(cls, decision, before_loss, after_loss, training_accepted=True):
        factors = dict((decision or {}).get("factors") or {})
        factors["pending_experience"] = 0.0
        factors["repeated_failure"] *= 0.18
        factors["skill_conflict"] *= 0.35
        factors["goal_stagnation"] = 0.0
        factors["memory_fragmentation"] *= 0.45
        if before_loss > 1e-9:
            factors["td_error"] = clamp(factors.get("td_error", 0.0) * (after_loss / before_loss), 0.0, 1.0)
        if not training_accepted:
            factors["td_error"] = max(factors.get("td_error", 0.0), 0.38)
        # 世界模型不确定性不会假装被一次睡眠完全消除，但降低为“醒后继续观察”的残余项。
        factors["world_uncertainty"] *= 0.45
        score = sum(cls.WEIGHTS[name] * clamp(factors.get(name, 0.0), 0.0, 1.0) for name in cls.WEIGHTS)
        return {"score": clamp(score, 0.0, 1.0), "factors": factors, "wake_threshold": SLEEP_WAKE_THRESHOLD, "wake_ready": score <= SLEEP_WAKE_THRESHOLD}


@dataclass
class TaskDSLNode:
    """统一类型化任务 DSL：对象→操作→参数→前置→后置/验证→恢复→分支→循环。"""
    identifier: str
    object_ref: str
    operation: str
    parameters: dict = field(default_factory=dict)
    preconditions: list = field(default_factory=list)
    postconditions: list = field(default_factory=list)
    recovery: list = field(default_factory=list)
    branches: list = field(default_factory=list)
    loop: dict = field(default_factory=dict)

    def as_dict(self):
        return {
            "id": self.identifier, "object": self.object_ref, "operation": self.operation,
            "parameters": dict(self.parameters), "preconditions": list(self.preconditions),
            "postconditions": list(self.postconditions), "recovery": list(self.recovery),
            "branches": list(self.branches), "loop": dict(self.loop),
        }


class DeterministicGoalCompiler:
    """通用 GoalCompiler：自然语言 -> 动作/对象/参数/前置条件/结果条件 -> 可学习程序。

    少数成熟任务仍有快速程序，但未知目标不会返回空计划：它会进入观察、候选子目标、
    低风险尝试、验证、成功轨迹编译的通用闭环。因此能力边界不再取决于 rename/search 等正则。
    """

    CONNECTOR_RE = re.compile(r"(?:\s*(?:→|->|然后|再|并且|并|之后|以后|接着|随后|，|,|；|;|\n|\band\b|\bthen\b)\s*)+", re.IGNORECASE)
    POLITE_PREFIX_RE = re.compile(r"^(?:请|请你|麻烦|帮我|请帮我|please|could\s+you|would\s+you)\s*", re.IGNORECASE)
    QUOTE_RE = re.compile(r'["“”‘’\']([^"“”‘’\']+)["“”‘’\']')
    RANGE_RE = re.compile(r"\b([A-Z]{1,3}\d{1,7}\s*:\s*[A-Z]{1,3}\d{1,7})\b", re.IGNORECASE)
    FILE_RE = re.compile(r"([\w\-. ()\[\]{}\u3400-\u9fff]+\.[A-Za-z0-9]{1,12})")

    # 这些是“意图识别规则”，不是动作空间。一个意图可展开成任意数量的子目标。
    INTENT_RULES = (
        ("rename", re.compile(r"(?:把|将)?\s*(?P<target>.+?)\s*(?:重命名|改名|rename)\s*(?:为|成|to)\s*(?P<value>[^，,；;\n]+)", re.IGNORECASE)),
        ("close_window", re.compile(r"(?:关闭|关掉|close)\s*(?:当前|this|current)?\s*(?:窗口|应用|程序|window|app|application)?", re.IGNORECASE)),
        ("spreadsheet_sum", re.compile(r"(?=.*(?:excel|表格|电子表格|spreadsheet))(?=.*(?:总和|合计|求和|sum|计算)).*", re.IGNORECASE)),
    )

    LEGACY_CONCEPTS = (
        ("open", ("打开", "进入", "open", "go to", "navigate")),
        ("click", ("点击", "单击", "click", "press")),
        ("type", ("输入", "键入", "填写", "type")),
        ("search", ("搜索", "检索", "search")),
        ("find", ("查找", "寻找", "find")),
        ("select", ("选择", "选中", "select")),
        ("save", ("保存", "另存", "save")),
    )
    COMPACT_TRANSITIONS = {
        ("open", "search"), ("open", "find"), ("open", "click"),
        ("click", "type"), ("click", "select"), ("select", "type"),
    }

    # 只用于给开放式动作框架赋予语义和 capability；它不是“可执行目标白名单”。
    ACTION_SEMANTICS = (
        ("external_send", ("发送", "发出", "发邮件", "邮件", "email", "mail", "message", "share")),
        ("aggregate", ("求和", "合计", "汇总", "统计", "计算", "sum", "total", "calculate", "aggregate")),
        ("filesystem_write", ("重命名", "改名", "保存", "写入文件", "rename", "save", "write file")),
        ("software_install", ("安装", "卸载", "install", "uninstall")),
        ("financial_commit", ("支付", "购买", "下单", "付款", "pay", "purchase", "buy", "checkout")),
        ("credential_input", ("登录", "密码", "验证码", "sign in", "login", "password", "credential")),
        ("document_write", ("填写", "输入", "编辑", "写", "创建", "type", "edit", "write", "create")),
        ("retrieve", ("查找", "搜索", "获取", "查看", "find", "search", "get", "read", "look up")),
        ("navigate", ("打开", "进入", "切换", "选择", "点击", "open", "navigate", "select", "click")),
    )

    @staticmethod
    def _clean(value):
        return str(value or "").strip(" ：:，,。;；\t\r\n ")

    @classmethod
    def _quoted(cls, text):
        return [cls._clean(value) for value in cls.QUOTE_RE.findall(str(text or "")) if cls._clean(value)]

    @classmethod
    def _node(cls, number, operation, action, payload="", target="", value="", depends_on=None,
              preconditions=None, gui=None, verify=None, recovery=None, source="", parameters=None, max_retries=2,
              capabilities=None, frame=None, generic=False):
        identifier = "g{:02d}".format(number)
        object_ref = cls._clean(target) or cls._clean(payload) or str(operation)
        verify_items = list(verify or [])
        typed = TaskDSLNode(
            identifier=identifier, object_ref=object_ref, operation=str(operation), parameters=dict(parameters or {}),
            preconditions=list(preconditions or []), postconditions=verify_items, recovery=list(recovery or []),
            branches=list((frame or {}).get("branches", [])) if isinstance(frame, dict) else [],
            loop={"max_retries": max(0, int(max_retries))},
        ).as_dict()
        typed.update({
            "action": str(action), "payload": cls._clean(payload), "target": cls._clean(target), "value": cls._clean(value),
            "depends_on": list(depends_on or []), "gui": list(gui or []), "verify": verify_items,
            "capabilities": sorted(set(str(value) for value in (capabilities or []) if value)),
            "frame": dict(frame or {}), "generic": bool(generic),
            "max_retries": max(0, int(max_retries)), "source": cls._clean(source),
        })
        return typed

    @classmethod
    def _chain(cls, specs, source):
        result = []
        previous = []
        for spec in specs:
            local = dict(spec)
            local_source = local.pop("source", source)
            node = cls._node(len(result) + 1, depends_on=previous, source=local_source, **local)
            result.append(node)
            previous = [node["id"]]
        return result

    @classmethod
    def _compile_rename(cls, source, match):
        target = cls._clean(match.group("target"))
        target = re.sub(r"^(?:(?:桌面(?:上的?|\s+))|(?:desktop\s+))", "", target, flags=re.IGNORECASE).strip() or "桌面上的文件"
        value = cls._clean(match.group("value"))
        quoted = cls._quoted(value)
        if quoted:
            value = quoted[-1]
        file_match = cls.FILE_RE.search(value)
        if file_match:
            value = file_match.group(1).strip()
        return cls._chain([
            {"operation":"locate_object", "action":"find", "payload":target, "target":target,
             "preconditions":[{"desktop":"default"}],
             "gui":[{"op":"uia_locate", "query":target, "types":["ListItem","TreeItem","DataItem"]}],
             "verify":[{"object_present":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"open_desktop_if_needed"}]},
            {"operation":"select_object", "action":"select", "payload":target, "target":target,
             "preconditions":[{"object_present":target}],
             "gui":[{"op":"click_semantic", "query":target}],
             "verify":[{"selected_or_focused":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"relocate", "query":target}]},
            {"operation":"request_rename", "action":"rename", "payload":target, "target":target,
             "preconditions":[{"selected_or_focused":target}],
             "gui":[{"op":"key", "vk":0x71, "name":"F2"}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"right_click_then_menu", "query":"重命名 rename"},{"op":"refresh_uia"}]},
            {"operation":"acquire_editor", "action":"find", "payload":"rename editor", "target":"rename editor",
             "preconditions":[{"rename_requested":True}],
             "gui":[{"op":"uia_locate", "types":["Edit","Document"]}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"press_f2_again"},{"op":"refresh_uia"}]},
            {"operation":"replace_text", "action":"type", "payload":value, "value":value,
             "preconditions":[{"focused_type_in":["Edit","Document"]}],
             "gui":[{"op":"replace_focused_text", "text":value}],
             "verify":[{"focused_contains":value}],
             "recovery":[{"op":"refocus_editor"},{"op":"retry", "limit":2}]},
            {"operation":"commit_edit", "action":"key", "payload":"Enter", "value":value,
             "preconditions":[{"focused_contains":value}],
             "gui":[{"op":"key", "vk":0x0D, "name":"Enter"}],
             "verify":[{"editing_finished":True}],
             "recovery":[{"op":"refresh_uia"},{"op":"retry", "limit":1}],
             "capabilities":["filesystem_write"]},
            {"operation":"verify_object", "action":"verify", "payload":value, "target":value,
             "preconditions":[{"editing_finished":True}],
             "gui":[{"op":"observe"}],
             "verify":[{"object_present":value},{"old_name_absent":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"relocate", "query":value}]},
        ], source)

    @classmethod
    def _compile_close(cls, source):
        return cls._chain([
            {"operation":"close_window", "action":"close", "payload":"current window", "target":"current window",
             "preconditions":[{"foreground_window":True},{"desktop":"default"}],
             "gui":[{"op":"key", "vk":0x73, "modifiers":[0x12], "name":"Alt+F4"}],
             "verify":[{"foreground_hwnd_changed":True}],
             "recovery":[{"op":"observe"},{"op":"locate_close_button"}], "max_retries":1},
        ], source)

    @classmethod
    def _compile_spreadsheet_sum(cls, source):
        match = cls.RANGE_RE.search(source)
        cell_range = re.sub(r"\s+", "", match.group(1).upper()) if match else ""
        if not cell_range:
            return []
        formula = "=SUM({})".format(cell_range)
        return cls._chain([
            {"operation":"ensure_application", "action":"open", "payload":"Excel", "target":"Excel",
             "preconditions":[{"desktop":"default"}],
             "gui":[{"op":"ensure_application", "name":"Excel"}],
             "verify":[{"application":"Excel"}],
             "recovery":[{"op":"windows_search", "text":"Excel"}]},
            {"operation":"formula_mode", "action":"key", "payload":"F2", "target":"active cell",
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"key", "vk":0x71, "name":"F2"}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"locate_formula_bar"},{"op":"refresh_uia"}]},
            {"operation":"replace_text", "action":"type", "payload":formula, "value":formula,
             "parameters":{"formula":formula, "range":cell_range},
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"replace_focused_text", "text":formula}],
             "verify":[{"focused_contains":formula}],
             "recovery":[{"op":"press_f2_again"},{"op":"retry", "limit":2}]},
            {"operation":"commit_formula", "action":"key", "payload":"Enter", "value":formula,
             "preconditions":[{"focused_contains":formula}],
             "gui":[{"op":"key", "vk":0x0D, "name":"Enter"}],
             "verify":[{"structured_change":True}],
             "recovery":[{"op":"refresh_uia"},{"op":"retry", "limit":1}],
             "capabilities":["document_write"]},
            {"operation":"verify_formula_result", "action":"verify", "payload":cell_range, "target":cell_range,
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"observe"}],
             "verify":[{"structured_change":True},{"formula_committed":formula}],
             "recovery":[{"op":"refresh_uia"},{"op":"inspect_formula_bar"}]},
        ], source)

    @classmethod
    def _concept_patterns(cls):
        patterns = []
        for kind, phrases in cls.LEGACY_CONCEPTS:
            for phrase in phrases:
                if re.search(r"[A-Za-z]", phrase):
                    body = r"\s+".join(re.escape(part) for part in phrase.split())
                    pattern = re.compile(r"(?<![A-Za-z0-9_])" + body + r"(?![A-Za-z0-9_])", re.IGNORECASE)
                else:
                    pattern = re.compile(re.escape(phrase), re.IGNORECASE)
                patterns.append((kind, phrase, pattern))
        return patterns

    @classmethod
    def _first_concept(cls, text, start=0):
        best = None
        for kind, phrase, pattern in cls._concept_patterns():
            match = pattern.search(text, start)
            if match:
                candidate = (match.start(), match.end(), kind, phrase)
                if best is None or candidate[0] < best[0] or (candidate[0] == best[0] and candidate[1] > best[1]):
                    best = candidate
        return best

    @classmethod
    def _concept_at(cls, text, position):
        for kind, phrase, pattern in cls._concept_patterns():
            match = pattern.match(text, position)
            if match:
                return match.start(), match.end(), kind, phrase
        return None

    @classmethod
    def _next_legacy_boundary(cls, text, payload_start, previous):
        for connector in cls.CONNECTOR_RE.finditer(text, payload_start):
            action = cls._concept_at(text, connector.end())
            if action:
                return connector.start(), action
        for kind, phrase, pattern in cls._concept_patterns():
            if re.search(r"[A-Za-z]", phrase):
                continue
            for match in pattern.finditer(text, payload_start):
                if (previous, kind) not in cls.COMPACT_TRANSITIONS:
                    continue
                payload = text[payload_start:match.start()].strip()
                if payload and len(payload) <= 32:
                    return match.start(), (match.start(), match.end(), kind, phrase)
        return None

    @classmethod
    def _compile_legacy(cls, source):
        urls = re.findall(r"https?://[^\s，。；;]+", source, re.IGNORECASE)
        quoted = cls._quoted(source)
        first = cls._first_concept(source)
        if first is None:
            if urls:
                specs = [{"operation":"ensure_url", "action":"open", "payload":urls[0], "target":urls[0],
                          "preconditions":[{"browser":True}], "gui":[{"op":"navigate", "url":urls[0]}],
                          "verify":[{"url_or_page_changed":True}], "recovery":[{"op":"focus_address_bar"}]}]
                return cls._chain(specs, source)
            if quoted:
                specs = [{"operation":"replace_text", "action":"type", "payload":quoted[0], "value":quoted[0],
                          "preconditions":[{"focused_editable":True}], "gui":[{"op":"type", "text":quoted[0]}],
                          "verify":[{"focused_contains":quoted[0]}], "recovery":[{"op":"refresh_uia"}]}]
                return cls._chain(specs, source)
            return []
        raw = []
        current = first
        while current is not None:
            position, end, action, phrase = current
            boundary = cls._next_legacy_boundary(source, end, action)
            if boundary is None:
                payload_end, nxt = len(source), None
            else:
                payload_end, nxt = boundary
            segment = cls._clean(source[end:payload_end])
            locals_quoted = cls._quoted(segment)
            payload = locals_quoted[-1] if locals_quoted else segment
            payload = re.sub(r"^(?:在|到|为|内容为|关键词为|关键字为|the\s+|a\s+|an\s+)\s*", "", payload, flags=re.IGNORECASE).strip()
            raw.append((action, payload, source[position:payload_end]))
            current = nxt
        specs = []
        operation_map = {
            "open":"ensure_application", "click":"activate_control", "type":"replace_text",
            "search":"search", "find":"find", "select":"select_object", "save":"save",
        }
        for action, payload, local_source in raw:
            operation = operation_map[action]
            preconditions = [{"desktop":"default"}]
            gui = [{"op":operation, "target":payload}]
            verify = [{"semantic_or_structure_changed":True}]
            recovery = [{"op":"refresh_uia"},{"op":"relocate", "query":payload}]
            if action in ("type","search","find"):
                preconditions.append({"editable_or_locatable":True})
                verify = [{"payload_observed":payload}] if payload else verify
            specs.append({"operation":operation, "action":action, "payload":payload, "target":payload,
                          "value":payload if action in ("type","search","find") else "",
                          "preconditions":preconditions, "gui":gui, "verify":verify, "recovery":recovery,
                          "source":local_source})
        return cls._chain(specs, source)

    @classmethod
    def _semantic_action(cls, clause):
        lowered = str(clause or "").lower()
        matches = []
        for category, phrases in cls.ACTION_SEMANTICS:
            for phrase in phrases:
                position = lowered.find(phrase.lower())
                if position >= 0:
                    matches.append((position, -len(phrase), category, clause[position:position + len(phrase)]))
        if matches:
            _, _, category, phrase = sorted(matches)[0]
            return category, cls._clean(phrase), lowered.find(str(phrase).lower())
        # 开放式兜底：不认识谓词也照样建立 achieve 框架，而不是返回空图。
        units = semantic_units(clause)
        return "achieve", (units[0] if units else "achieve"), 0

    @staticmethod
    def _capabilities_for_category(category):
        mapping = {
            "external_send": ["external_send"], "filesystem_write": ["filesystem_write"],
            "software_install": ["software_install"], "financial_commit": ["financial_commit"],
            "credential_input": ["credential_input"], "document_write": ["document_write"],
            "aggregate": ["document_write"], "retrieve": ["network_read"],
        }
        return list(mapping.get(str(category), []))

    @classmethod
    def _parse_frame(cls, clause):
        clause = cls._clean(clause)
        category, action, action_position = cls._semantic_action(clause)
        lowered = clause.lower()
        parameters = {}
        quoted = cls._quoted(clause)
        urls = re.findall(r"https?://[^\s，。；;]+", clause, re.IGNORECASE)
        emails = re.findall(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", clause)
        ranges = [re.sub(r"\s+", "", value.upper()) for value in cls.RANGE_RE.findall(clause)]
        files = [match.group(1).strip() for match in cls.FILE_RE.finditer(clause)]
        if quoted: parameters["quoted_values"] = quoted
        if urls: parameters["urls"] = urls
        if emails: parameters["addresses"] = emails
        if ranges: parameters["ranges"] = ranges
        if files: parameters["files"] = files

        # 通用角色标记：动作前的 给/向 是受事者，在...中 是位置，为/成/to/with 后是值。
        prefix = clause[:max(0, action_position)]
        recipient_match = re.search(r"(?:给|向|to\s+)([^，,；;]+)$", prefix, re.IGNORECASE)
        if recipient_match:
            parameters["recipient"] = cls._clean(recipient_match.group(1))
        location_match = re.search(r"(?:在|于|in\s+|inside\s+)(.+?)(?:中|里|内)?$", prefix, re.IGNORECASE)
        if location_match:
            parameters["location"] = cls._clean(location_match.group(1))
        value_match = re.search(r"(?:为|成|内容为|值为|to|with)\s*[:：]?\s*(.+)$", clause[max(0, action_position + len(action)):], re.IGNORECASE)
        if value_match:
            parameters["value"] = cls._clean(value_match.group(1))

        after = cls._clean(clause[max(0, action_position + len(action)):])
        after = re.sub(r"^(?:给|向|在|于|到|把|将|the|a|an)\s*", "", after, flags=re.IGNORECASE)
        object_text = after
        if not object_text and category == "external_send":
            object_text = "邮件" if any(value in str(action).lower() for value in ("mail", "email", "邮件")) else "消息"
        if not object_text:
            object_text = str(parameters.get("location") or parameters.get("recipient") or "")
        if not object_text:
            # 去掉已识别动作后保留完整语义对象；未知目标仍有可检索 query。
            object_text = cls._clean(lowered.replace(str(action).lower(), " ", 1)) or clause
        result_terms = list(dict.fromkeys(
            [value for value in quoted + emails + ranges + files if value]
            + [unit for unit in semantic_units(object_text) if unit != str(action).lower()]
        ))
        confidence = 0.30 + (0.30 if category != "achieve" else 0.0) + (0.20 if object_text else 0.0) + (0.15 if parameters else 0.0)
        return {
            "action": action, "category": category, "object": cls._clean(object_text),
            "parameters": parameters, "preconditions": [{"desktop": "default"}, {"context_observable": True}],
            "result_conditions": [{"semantic_or_structure_changed": True}, {"goal_terms": result_terms}],
            "capabilities": cls._capabilities_for_category(category), "confidence": clamp(confidence, 0.0, 0.98),
            "source": clause,
        }

    @classmethod
    def _compile_generic(cls, source):
        clauses = [cls._clean(value) for value in cls.CONNECTOR_RE.split(source) if cls._clean(value)] or [cls._clean(source)]
        frames = [cls._parse_frame(clause) for clause in clauses]
        specs = []
        for frame_index, frame in enumerate(frames):
            target = frame["object"] or frame["source"]
            query = " ".join(value for value in (frame["action"], target) if value)
            common = {"frame": frame, "generic": True, "source": frame["source"]}
            specs.extend([
                dict(common, operation="observe_context", action="observe", payload=query, target=target,
                     preconditions=[{"desktop":"default"}],
                     gui=[{"op":"shallow_observe"},{"op":"deep_observe_on_anomaly"}],
                     verify=[{"context_observed":True}], recovery=[{"op":"wait_for_stable_window"}]),
                dict(common, operation="locate_target", action="locate", payload=query, target=target,
                     preconditions=frame["preconditions"],
                     gui=[{"op":"rank_semantic_controls", "query":query},{"op":"propose_candidate_subgoals"}],
                     verify=[{"candidate_or_context_found":True}],
                     recovery=[{"op":"broaden_uia"},{"op":"alternate_control"},{"op":"observe"}]),
                dict(common, operation="candidate_subgoal", action="adapt", payload=frame["source"], target=target,
                     parameters=frame["parameters"], preconditions=frame["preconditions"],
                     gui=[{"op":"try_lowest_risk_candidate", "query":query},{"op":"observe_result"}],
                     verify=[{"structured_progress":True}],
                     recovery=[{"op":"observe"},{"op":"undo_if_possible"},{"op":"alternate_candidate"}]),
                dict(common, operation="commit_candidate", action="commit", payload=frame["source"], target=target,
                     parameters=frame["parameters"], preconditions=[{"candidate_verified":True}],
                     gui=[{"op":"commit_only_after_capability_check"}], verify=frame["result_conditions"],
                     recovery=[{"op":"do_not_repeat_commit"},{"op":"observe"}],
                     capabilities=frame["capabilities"], max_retries=1),
                dict(common, operation="verify_result", action="verify", payload=query, target=target,
                     preconditions=[{"attempt_observed":True}], gui=[{"op":"observe"}],
                     verify=frame["result_conditions"], recovery=[{"op":"alternate_candidate"},{"op":"observe"}]),
                dict(common, operation="compile_success", action="learn", payload=frame["source"], target=target,
                     preconditions=[{"result_stable":True}], gui=[{"op":"compile_trace_to_program"}],
                     verify=[{"program_reusable":True}], recovery=[{"op":"retain_trace_for_sleep"}]),
            ])
        return cls._chain(specs, source)

    @classmethod
    def compile(cls, text):
        text = str(text or "").strip()
        if not text:
            return []
        source = cls.POLITE_PREFIX_RE.sub("", text).strip()
        for intent, pattern in cls.INTENT_RULES:
            match = pattern.search(source)
            if not match:
                continue
            if intent == "rename":
                return cls._compile_rename(source, match)
            if intent == "close_window":
                return cls._compile_close(source)
            if intent == "spreadsheet_sum":
                result = cls._compile_spreadsheet_sum(source)
                if result:
                    return result
        legacy = cls._compile_legacy(source)
        return legacy if legacy else cls._compile_generic(source)

    @staticmethod
    def text_payloads(steps):
        result = []
        for step in steps or []:
            for key in ("value", "payload", "target"):
                value = str(step.get(key, "")).strip()
                if value and value not in ("Enter", "F2", "current window", "rename editor") and value not in result:
                    result.append(value)
        return result

    @classmethod
    def graph(cls, text):
        """公开的结构化表示，便于测试、睡眠反思和未来技能程序化。"""
        return {"version": 3, "schema": "object→operation→parameters→preconditions→postconditions→verification→recovery→branch→loop", "goal": str(text or ""), "nodes": cls.compile(text)}


# 新代码和外部调用都可以使用更准确的名称；旧名称保持兼容。
GoalCompiler = DeterministicGoalCompiler


class GoalEngine:
    STOP_WORDS = {
        "打开", "点击", "输入", "键入", "搜索", "查找", "选择", "进入", "完成", "执行", "窗口", "控件",
        "open", "click", "type", "search", "find", "select", "complete", "window", "button",
    }

    def __init__(self, requested_goal="", success_text=""):
        self.requested_goal = str(requested_goal or "").strip()
        self.success_text = str(success_text or "").strip()
        self.explicit = bool(self.requested_goal or self.success_text)
        self.goal_label = ""
        self.target_point = None
        self.target_record = None
        self.baseline_signature = ""
        self.baseline_semantic = ""
        self.baseline_hwnd = 0
        self.best_coverage = 0.0
        self.completed = False
        self.completion_evidence = 0
        self.generation = 0
        self.compiled_steps = DeterministicGoalCompiler.compile(self.requested_goal)
        self.compiler_generic = bool(self.compiled_steps and any(step.get("generic") for step in self.compiled_steps))
        self.compiled_index = 0
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        self.compiler_stalled = False
        self.baseline_phrase_presence = {}
        self.baseline_phrase_controls = {}
        self.baseline_target_state = None
        self.candidate_target_change = False
        self.knowledge_context = []

    def attach_knowledge(self, items):
        self.knowledge_context = [dict(item) for item in (items or []) if isinstance(item, dict)]
        return len(self.knowledge_context)

    def _terms(self):
        source = self.success_text or self.requested_goal or self.goal_label
        result = []
        for unit in semantic_units(source):
            if unit in self.STOP_WORDS:
                continue
            if len(unit) >= 2 or re.search(r"[a-z0-9]", unit):
                result.append(unit)
        return list(dict.fromkeys(result))

    def _phrases(self):
        return [value.strip().lower() for value in re.split(r"[|｜;；\n]+", self.success_text) if value.strip()]

    def _phrase_controls(self, observation, phrase):
        result = []
        for record in observation.accessibility.records:
            text = " ".join((str(record.get("name", "")), str(record.get("value", "")), str(record.get("help", "")))).lower()
            if phrase in text:
                locator = control_locator(record)
                state = (str(record.get("value", "")), bool(record.get("focused")), bool(record.get("enabled")), bool(record.get("offscreen")))
                result.append((compact_json(locator), state))
        return tuple(sorted(map(str, result)))

    def deterministic_text(self, observation=None):
        payloads = DeterministicGoalCompiler.text_payloads(self.compiled_steps)
        if not payloads:
            return ""
        # 已聚焦可编辑控件时，优先给 TYPE/SEARCH/FIND 子目标；否则 URL 仍可供地址栏输入。
        focused_edit = False
        if observation is not None:
            focused_edit = any(record.get("focused") and record.get("control_type") in ("Edit", "Document", "ComboBox") for record in observation.accessibility.records)
        active = self.active_compiled_step()
        ordered_steps = ([active] if active is not None else []) + [step for step in self.compiled_steps if step is not active]
        for step in ordered_steps:
            if step.get("action") in (("type", "search", "find") if focused_edit else ("open", "type", "search", "find")):
                payload = str(step.get("payload", "")).strip()
                if payload:
                    return payload
        return payloads[0]

    def active_compiled_step(self):
        if 0 <= self.compiled_index < len(self.compiled_steps):
            return self.compiled_steps[self.compiled_index]
        return None

    def set_compiled_phase(self, phase, attempted=False):
        self.compiled_phase = str(phase or "precondition")
        if attempted and self.compiled_phase == "recovery":
            self.compiled_attempts += 1

    def reset_compiled_phase(self):
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        self.compiler_stalled = False

    def _advance_compiled(self, command, previous, current, outcome):
        step = self.active_compiled_step()
        if step is None or not outcome.get("executed"):
            return
        operation = str(step.get("operation") or step.get("action", ""))
        action = str(step.get("action", ""))
        payload = str(step.get("payload", "")).strip().lower()
        value = str(step.get("value", "") or step.get("payload", "")).strip().lower()
        semantic = current.semantic_text.lower()
        title = str(current.accessibility.window_title or "").lower()
        focused = next((record for record in current.accessibility.records if record.get("focused")), None)
        focused_type = str((focused or {}).get("control_type", ""))
        focused_text = " ".join((str((focused or {}).get("value", "")), str((focused or {}).get("name", "")))).lower()
        structured_change = current.semantic_signature != previous.semantic_signature or current.accessibility.hwnd != previous.accessibility.hwnd
        enter = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D
        advance = False

        if operation == "locate_object":
            advance = command.kind == WAIT and bool(payload and payload in semantic)
        elif operation == "select_object":
            advance = command.kind == CLICK and (structured_change or bool(focused and payload and payload in focused_text))
        elif operation == "request_rename":
            advance = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x71
        elif operation == "acquire_editor":
            advance = command.kind == WAIT and focused_type in SafetyPolicy.SAFE_TEXT_TYPES
        elif operation == "replace_text":
            advance = command.kind in (TYPE, WAIT) and bool(value and (value in focused_text or value in semantic))
        elif operation in ("commit_edit", "commit_formula"):
            advance = enter and structured_change
            if operation == "commit_edit" and enter:
                advance = True
        elif operation == "verify_object":
            advance = command.kind == WAIT and bool(payload and payload in semantic)
        elif operation == "close_window":
            advance = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x73 and 0x12 in set(int(x) for x in command.parameters.get("modifiers", [])) and current.accessibility.hwnd != previous.accessibility.hwnd
        elif operation == "formula_mode":
            advance = (command.kind == WAIT and focused_type in SafetyPolicy.SAFE_TEXT_TYPES) or (command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x71 and focused_type in SafetyPolicy.SAFE_TEXT_TYPES)
        elif operation == "verify_formula_result":
            advance = command.kind == WAIT and (current.semantic_signature != self.baseline_signature or current.accessibility.hwnd != self.baseline_hwnd)
        elif operation == "observe_context":
            advance = command.kind == WAIT
        elif operation == "locate_target":
            advance = (command.kind == WAIT and bool(current.accessibility.records)) or (command.kind in (CLICK, KEY) and structured_change)
        elif operation == "candidate_subgoal":
            advance = command.kind in (CLICK, KEY, TYPE, SKILL, WAIT) and (structured_change or outcome.get("simulated") or command.kind == WAIT)
        elif operation == "commit_candidate":
            advance = command.kind in (CLICK, KEY, TYPE, SKILL, WAIT) and bool(outcome.get("executed"))
        elif operation == "verify_result":
            advance = command.kind == WAIT and (structured_change or current.signature != self.baseline_signature)
        elif operation == "compile_success":
            advance = command.kind == WAIT and current.signature != self.baseline_signature
        elif operation in ("ensure_application", "ensure_url"):
            if re.match(r"https?://", payload, re.IGNORECASE):
                advance = enter and structured_change
            elif command.kind == WAIT and payload:
                advance = payload in (semantic + " " + title)
            elif command.kind in (CLICK, KEY) and structured_change:
                advance = True
        elif action in ("click", "select") and command.kind == CLICK:
            advance = structured_change
        elif action == "search":
            advance = enter and structured_change
        elif action == "find":
            advance = command.kind == TYPE and bool(payload and (payload in semantic or payload in focused_text))
        elif action == "type":
            advance = command.kind == TYPE and bool(payload and (payload in semantic or payload in focused_text))
        elif action == "save":
            advance = command.kind == KEY and SafetyPolicy.is_ctrl_s(command)

        if advance:
            self.compiled_index = min(len(self.compiled_steps), self.compiled_index + 1)
            self.reset_compiled_phase()
        elif outcome.get("blocked") or outcome.get("invalid") or (outcome.get("executed") and command.kind not in (WAIT,)):
            # 已执行但验证未通过也属于失败恢复，不无限重放同一动作。
            self.set_compiled_phase("recovery", attempted=True)

    def compiler_action_biases(self):
        step = self.active_compiled_step()
        if step is None:
            return {}
        operation = str(step.get("operation") or step.get("action", ""))
        mapping = {
            "locate_object": WAIT, "select_object": CLICK, "request_rename": KEY, "acquire_editor": WAIT,
            "replace_text": TYPE, "commit_edit": KEY, "verify_object": WAIT, "close_window": KEY,
            "ensure_application": TYPE, "ensure_url": TYPE, "formula_mode": KEY, "commit_formula": KEY,
            "verify_formula_result": WAIT, "activate_control": CLICK, "search": TYPE, "find": TYPE,
            "save": KEY, "observe_context": WAIT, "locate_target": WAIT, "candidate_subgoal": CLICK,
            "commit_candidate": CLICK, "verify_result": WAIT, "compile_success": WAIT,
        }
        kind = mapping.get(operation)
        return {} if kind is None else {kind: 0.34}

    def _coverage(self, observation):
        terms = self._terms()
        if not terms:
            return 0.0
        semantic = observation.semantic_text.lower()
        weights = [max(1.0, math.sqrt(len(term))) for term in terms]
        matched = sum(weight for term, weight in zip(terms, weights) if term in semantic)
        return matched / max(1e-9, sum(weights))

    def _best_record(self, observation):
        query = " ".join((self.requested_goal, self.success_text))
        best = None
        best_score = -1.0
        for record in observation.accessibility.records:
            if record.get("password") or record.get("offscreen") or not record.get("enabled"):
                continue
            text = " ".join((record.get("name", ""), record.get("automation_id", ""), record.get("control_type", ""), record.get("help", "")))
            score = similarity(query, text)
            if record.get("control_type") in INTERACTIVE_CONTROL_TYPES:
                score += 0.12
            if score > best_score:
                best_score, best = score, record
        return best

    def begin(self, observation, renew=False):
        self.generation += 1
        self.completed = False
        self.completion_evidence = 0
        self.baseline_signature = observation.semantic_signature
        self.baseline_semantic = observation.semantic_text
        self.baseline_hwnd = int(observation.accessibility.hwnd or 0)
        phrases = self._phrases()
        semantic_lower = observation.semantic_text.lower()
        self.baseline_phrase_presence = {phrase: phrase in semantic_lower for phrase in phrases}
        self.baseline_phrase_controls = {phrase: self._phrase_controls(observation, phrase) for phrase in phrases}
        self.compiled_steps = DeterministicGoalCompiler.compile(self.requested_goal)
        self.compiler_generic = bool(self.compiled_steps and any(step.get("generic") for step in self.compiled_steps))
        self.compiled_index = 0
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        if self.explicit:
            self.goal_label = self.requested_goal or "使界面出现：" + self.success_text
            self.target_record = self._best_record(observation)
        else:
            candidates = [
                record for record in observation.accessibility.records
                if record.get("enabled") and not record.get("password") and not record.get("offscreen")
                and record.get("control_type") in INTERACTIVE_CONTROL_TYPES and record.get("name")
            ]
            if candidates:
                candidates.sort(key=lambda record: (not record.get("focused"), -len(record.get("name", ""))))
                front = candidates[:min(6, len(candidates))]
                self.target_record = random.choice(front)
                self.goal_label = "激活 {}“{}”并验证结构化结果".format(self.target_record.get("control_type", "控件"), self.target_record.get("name", "")[:80])
            else:
                self.target_record = None
                self.goal_label = "建立一个可验证、可复用且安全的界面状态"
        if self.target_record:
            self.target_point = (float(self.target_record.get("x_norm", 0.5)), float(self.target_record.get("y_norm", 0.5)))
        else:
            self.target_point = (observation.interest_x, observation.interest_y)
        self.baseline_target_state = self._goal_record_state(self._find_target(observation))
        self.candidate_target_change = False
        self.best_coverage = self._coverage(observation)
        return self.goal_label

    def features(self):
        flags = "explicit{} complete{} generation{} compiler{}/{} phase{} attempts{}".format(int(self.explicit), int(self.completed), self.generation % 17, self.compiled_index, len(self.compiled_steps), self.compiled_phase, self.compiled_attempts)
        compiled = " ".join("{}:{}".format(step.get("action", ""), step.get("payload", "")) for step in self.compiled_steps)
        knowledge = " ".join("{} {}".format(item.get("title", ""), item.get("snippet", "")) for item in self.knowledge_context)
        items = [self.goal_label, self.requested_goal, self.success_text, flags, compiled, knowledge]
        if self.target_record:
            items.append(" ".join((self.target_record.get("control_type", ""), self.target_record.get("name", ""), self.target_record.get("automation_id", ""))))
        return hashed_features(items, GOAL_FEATURES)

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        tokens = semantic_units(" ".join((self.goal_label, self.requested_goal, self.success_text)))
        values = []
        # token 级顺序编码；新增输入槽位时可保留更多目标 token，而不是永远压在 64 维内。
        per_token = 4
        for index, token in enumerate(tokens[:max(1, count // per_token)]):
            digest = hashlib.blake2s(token.encode("utf-8", "ignore"), digest_size=4).digest()
            values.extend([
                int.from_bytes(digest[:2], "little") / 65535.0,
                int.from_bytes(digest[2:], "little") / 65535.0,
                clamp(len(token) / 32.0, 0.0, 1.0),
                clamp(index / max(1, len(tokens) - 1), 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        if len(values) < count:
            values.extend(hashed_features(tokens, count - len(values)))
        return normalize_state(values, count)

    def text_candidates(self):
        candidates = list(DeterministicGoalCompiler.text_payloads(self.compiled_steps))
        source = " ".join((self.requested_goal, self.success_text))
        for match in re.findall(r"[\"'“”‘’]([^\"'“”‘’]{1,256})[\"'“”‘’]", source):
            candidates.append(match.strip())
        for match in re.findall(r"(?:输入|键入|搜索|查找|type|search|find)\s*[:：]?\s*([^，。；;\n\"'“”‘’]{1,256})", self.requested_goal, re.IGNORECASE):
            candidates.append(match.strip().strip("\"'“”‘’"))
        for match in re.findall(r"(?:https?://[^\s，。；;]+|[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}|[a-zA-Z0-9_.-]{3,})", source):
            candidates.append(match.strip())
        for item in self.knowledge_context:
            candidates.extend((str(item.get("title", "")), str(item.get("source", ""))))
        result = []
        for value in candidates:
            if value and value not in result:
                result.append(value)
        return result

    @staticmethod
    def _danger(observation):
        text = observation.semantic_text.lower()
        terms = ("error", "failed", "failure", "warning", "danger", "purchase", "payment", "delete", "错误", "失败", "警告", "危险", "付款", "支付", "删除")
        return any(term in text for term in terms)

    def _same_target(self, record):
        if not self.target_record or not record:
            return False
        left_runtime = tuple(self.target_record.get("runtime_id") or ())
        right_runtime = tuple(record.get("runtime_id") or ())
        if left_runtime and right_runtime:
            return left_runtime == right_runtime
        left_id = self.target_record.get("automation_id", "")
        right_id = record.get("automation_id", "")
        if left_id and right_id:
            return left_id == right_id and self.target_record.get("control_type") == record.get("control_type")
        return self.target_record.get("name") == record.get("name") and self.target_record.get("control_type") == record.get("control_type")

    def _find_target(self, observation):
        if not self.target_record:
            return None
        return next((record for record in observation.accessibility.records if self._same_target(record)), None)

    @staticmethod
    def _goal_record_state(record):
        if record is None:
            return None
        return (
            str(record.get("value", "")), bool(record.get("focused")), bool(record.get("enabled")),
            tuple(record.get("runtime_id") or ()), str(record.get("name", "")), bool(record.get("offscreen")),
        )

    def _target_changed(self, previous, current):
        if not self.target_record:
            return current.semantic_signature != previous.semantic_signature
        before = self._find_target(previous)
        after = self._find_target(current)
        if before is None and after is None:
            return current.semantic_signature != previous.semantic_signature
        if after is None:
            return True
        if before is None:
            return True
        for key in ("focused", "enabled", "value", "name", "offscreen"):
            if before.get(key) != after.get(key):
                return True
        return False

    def evaluate(self, command, previous, current, outcome):
        if self.completed:
            return {"reward": 0.0, "progress": 0.0, "completed": False, "candidate": False, "coverage": self.best_coverage, "label": self.goal_label}
        self._advance_compiled(command, previous, current, outcome)
        coverage = self._coverage(current)
        delta = coverage - self.best_coverage
        self.best_coverage = max(self.best_coverage, coverage)
        reward = 0.0
        progress = 0.0
        candidate = False
        if outcome.get("blocked") or outcome.get("invalid"):
            reward -= 0.16
        if self.explicit:
            if delta > 0.01:
                progress = clamp(delta * 1.4, 0.0, 0.32)
                reward += progress
            elif delta < -0.08:
                reward -= min(0.14, abs(delta) * 0.35)
            phrases = self._phrases()
            semantic = current.semantic_text.lower()
            if phrases:
                emerged = any((not self.baseline_phrase_presence.get(phrase, False)) and phrase in semantic for phrase in phrases)
                changed_evidence = any(
                    self.baseline_phrase_presence.get(phrase, False)
                    and phrase in semantic
                    and self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())
                    for phrase in phrases
                )
                target_changed = self._target_changed(previous, current)
                goal_related_action = command.kind in (CLICK, KEY, TYPE, SKILL) and target_changed
                target_text = " ".join((str((self.target_record or {}).get("name", "")), str((self.target_record or {}).get("automation_id", "")), str((self.target_record or {}).get("control_type", ""))))
                explicit_target_change = (
                    any(self.baseline_phrase_presence.values()) and goal_related_action and self.target_record is not None
                    and self._find_target(current) is not None and similarity(self.requested_goal, target_text) >= 0.12
                    and self._goal_record_state(self._find_target(current)) != self.baseline_target_state
                )
                self.candidate_target_change = bool(explicit_target_change)
                candidate = emerged or (changed_evidence and goal_related_action) or explicit_target_change
            else:
                candidate = coverage >= 0.72 and current.semantic_signature != self.baseline_signature
            if self.compiled_steps and self.compiled_index >= len(self.compiled_steps):
                candidate = True
                reward = max(reward, 0.62)
                progress = max(progress, 0.72)
            candidate = candidate and not self._danger(current)
        else:
            targeted = False
            if self.target_point and command.kind in (MOVE, CLICK):
                x = float(command.parameters.get("x", previous.cursor_x))
                y = float(command.parameters.get("y", previous.cursor_y))
                distance = math.hypot(x - self.target_point[0], y - self.target_point[1])
                targeted = distance <= (0.09 if command.kind == CLICK else 0.13)
                if command.kind == MOVE and targeted:
                    reward += 0.06
                    progress = max(progress, 0.06)
                if command.kind == CLICK and targeted:
                    reward += 0.12
                    progress = max(progress, 0.12)
            structured_change = current.semantic_signature != previous.semantic_signature
            target_changed = self._target_changed(previous, current)
            target_terms = set(semantic_units((self.target_record or {}).get("name", "")))
            current_terms = set(semantic_units(current.semantic_text))
            target_after = self._find_target(current)
            target_persisted = target_after is not None
            target_semantic = bool(target_terms & current_terms) if target_terms else target_persisted
            semantic_relation = target_persisted and target_semantic
            candidate = bool(outcome.get("skill_success")) or (targeted and command.kind == CLICK and structured_change and target_changed and semantic_relation)
            candidate = candidate and not self._danger(current)
            if not candidate and command.kind in (CLICK, KEY, TYPE, SKILL) and structured_change:
                reward += 0.05
                progress = max(progress, 0.05)
        if candidate:
            reward = max(reward, 0.45)
            progress = max(progress, 0.55)
        return {"reward": clamp(reward, -1.0, 1.0), "progress": progress, "completed": False, "candidate": candidate, "coverage": coverage, "label": self.goal_label}

    @staticmethod
    def _window_consistent(candidate_observation, current):
        before = candidate_observation.accessibility
        after = current.accessibility
        if before.hwnd and after.hwnd and before.hwnd != after.hwnd:
            return False
        if before.window_class and after.window_class and before.window_class != after.window_class:
            return False
        if before.window_title and after.window_title and before.window_title != after.window_title:
            if similarity(before.window_title, after.window_title) < 0.45:
                return False
        return True

    def _key_control_consistent(self, candidate_observation, current):
        if self.target_record:
            before = self._find_target(candidate_observation)
            after = self._find_target(current)
            if before is None or after is None:
                return False
            for key in ("control_type", "automation_id", "class_name", "enabled", "offscreen"):
                if before.get(key) != after.get(key):
                    return False
            return True
        phrases = self._phrases()
        if not phrases:
            return True
        def matching_records(observation):
            result = []
            for record in observation.accessibility.records:
                text = " ".join((record.get("name", ""), record.get("value", ""), record.get("help", ""))).lower()
                if any(phrase in text for phrase in phrases):
                    result.append((record.get("runtime_id"), record.get("automation_id"), record.get("control_type"), record.get("name")))
            return result
        before = matching_records(candidate_observation)
        after = matching_records(current)
        return bool(set(map(str, before)) & set(map(str, after))) if before else True

    def verify_stable(self, candidate_observation, current):
        if self.completed or self._danger(current):
            return False
        window_stable = self._window_consistent(candidate_observation, current)
        control_stable = self._key_control_consistent(candidate_observation, current)
        semantic_stable = current.semantic_signature == candidate_observation.semantic_signature or similarity(candidate_observation.semantic_text, current.semantic_text) >= 0.68
        if self.explicit:
            if self.compiled_steps and self.compiled_index >= len(self.compiled_steps):
                last = self.compiled_steps[-1]
                operation = str(last.get("operation", ""))
                target = str(last.get("target", "") or last.get("payload", "")).lower()
                if operation == "verify_object":
                    valid = bool(target and target in current.semantic_text.lower()) and semantic_stable
                elif operation == "close_window":
                    valid = int(current.accessibility.hwnd or 0) != int(self.baseline_hwnd or 0) and semantic_stable
                elif last.get("generic"):
                    valid = semantic_stable and current.signature != self.baseline_signature and not self._danger(current)
                else:
                    valid = semantic_stable and not self._danger(current)
                self.completion_evidence = self.completion_evidence + 1 if valid else 0
                if self.completion_evidence >= 2:
                    self.completed = True
                    return True
                return False
            phrases = self._phrases()
            semantic = current.semantic_text.lower()
            if phrases:
                emerged = any((not self.baseline_phrase_presence.get(phrase, False)) and phrase in semantic for phrase in phrases)
                changed_evidence = any(
                    self.baseline_phrase_presence.get(phrase, False)
                    and phrase in semantic
                    and self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())
                    for phrase in phrases
                )
                target_change_stable = False
                if self.candidate_target_change and self.target_record is not None:
                    current_target = self._find_target(current)
                    target_change_stable = current_target is not None and self._goal_record_state(current_target) != self.baseline_target_state
                valid = emerged or changed_evidence or target_change_stable
            else:
                valid = self._coverage(current) >= 0.72 and current.semantic_signature != self.baseline_signature
            valid = valid and window_stable and control_stable and semantic_stable
        else:
            target_persisted = self._find_target(current) is not None if self.target_record else True
            valid = target_persisted and window_stable and control_stable and semantic_stable
        if valid:
            self.completion_evidence += 1
        else:
            self.completion_evidence = 0
        if self.completion_evidence >= 3:
            self.completed = True
            return True
        return False

    def after_sleep(self, observation):
        if not self.explicit and self.completed:
            return self.begin(observation, renew=True)
        if self.explicit and self.compiler_stalled:
            self.reset_compiled_phase()
        return self.goal_label


class SessionCapabilityDomain:
    """把启动时的 HWND/PID 扩展成贯穿整个会话、可审计的窗口权限域。"""

    def __init__(self, memory, initial_observation, goal_text=""):
        self.memory = memory
        self.session_id = uuid.uuid4().hex
        self.goal_text = str(goal_text or "")
        self.allowed_pids = set()
        self.allowed_hwnds = set()
        self.root_process_name = str(getattr(initial_observation, "process_name", "") or "").lower()
        self.root_process_path = str(getattr(initial_observation, "process_path", "") or "").lower()
        self.pending_cross_program_reason = ""
        self.pending_cross_program_at = 0.0
        self._register(initial_observation, "initial", "allow", "用户点击开始时锁定的应用", approved=True)

    def _register(self, observation, relation, scope, reason, approved=False):
        pid = int(getattr(observation, "process_id", 0) or 0)
        hwnd = int(getattr(observation.accessibility, "hwnd", 0) or 0)
        if scope in ("allow", "declared"):
            if pid: self.allowed_pids.add(pid)
            if hwnd: self.allowed_hwnds.add(hwnd)
        self.memory.remember_session_capability({
            "session_id": self.session_id, "process_id": pid,
            "process_name": str(getattr(observation, "process_name", "") or ""), "window_hwnd": hwnd,
            "parent_process_id": int(getattr(observation, "parent_process_id", 0) or 0),
            "owner_hwnd": int(getattr(observation, "owner_hwnd", 0) or 0),
            "relation": relation, "scope": scope, "reason": reason, "approved": approved,
        })
        return scope

    def classify(self, observation, command=None):
        pid = int(getattr(observation, "process_id", 0) or 0)
        hwnd = int(getattr(observation.accessibility, "hwnd", 0) or 0)
        parent_pid = int(getattr(observation, "parent_process_id", 0) or 0)
        owner_hwnd = int(getattr(observation, "owner_hwnd", 0) or 0)
        process_name = str(getattr(observation, "process_name", "") or "").lower()
        process_path = str(getattr(observation, "process_path", "") or "").lower()
        capabilities = set(str(value) for value in getattr(command, "required_capabilities", []) or []) if command is not None else set()
        reason = str(getattr(command, "capability_reason", "") or "") if command is not None else ""
        if "cross_program" in capabilities and reason:
            self.pending_cross_program_reason = reason
            self.pending_cross_program_at = time.monotonic()
        if (pid and pid in self.allowed_pids) or (hwnd and hwnd in self.allowed_hwnds):
            return self._register(observation, "known", "allow", "会话中已验证的窗口")
        if owner_hwnd and owner_hwnd in self.allowed_hwnds:
            return self._register(observation, "owned_window", "allow", "允许应用拥有的子窗口")
        if parent_pid and parent_pid in self.allowed_pids:
            return self._register(observation, "child_process", "allow", "允许应用启动的子进程窗口")
        if self.root_process_path and process_path and process_path == self.root_process_path:
            return self._register(observation, "same_executable", "allow", "同一应用重建/新建的窗口")
        if self.root_process_name and process_name and process_name == self.root_process_name:
            return self._register(observation, "same_application", "allow", "同一应用的多进程窗口")
        if "cross_program" in capabilities and reason:
            return self._register(observation, "planner_declared", "declared", reason)
        if self.pending_cross_program_reason and time.monotonic() - self.pending_cross_program_at <= 15.0:
            reason = self.pending_cross_program_reason
            self.pending_cross_program_reason = ""
            if command is not None:
                command.declare(["cross_program"], reason)
            return self._register(observation, "planner_transition", "declared", reason)
        return self._register(observation, "unrelated", "outside", "未证明属于本次会话的程序")


class SafetyPolicy:
    """结构判断优先、文本判断补充；高影响行为默认拒绝或要求一次性精确批准。"""
    SENSITIVE = ("password", "credential", "windows security", "uac", "密码", "凭据", "安全验证", "支付", "payment", "checkout")
    IRREVERSIBLE = (
        "delete", "remove", "erase", "format", "purchase", "buy", "pay", "checkout", "place order", "submit order",
        "send", "upload", "install", "run script", "execute", "registry", "reset", "factory reset",
        "删除", "移除", "清空", "格式化", "购买", "付款", "支付", "提交订单", "下单", "发送", "上传", "安装", "执行脚本", "注册表", "重置",
    )
    GENERIC_CONFIRM = ("ok", "yes", "confirm", "continue", "apply", "确定", "确认", "继续", "应用", "是")
    SECURITY_WINDOWS = ("credential", "authui", "consent", "secure desktop", "windows security", "用户账户控制", "凭据", "安全验证")
    SAFE_CLICK_TYPES = {"Button", "Hyperlink", "MenuItem", "CheckBox", "RadioButton", "ComboBox", "ListItem", "TreeItem", "TabItem", "Edit"}
    SAFE_TEXT_TYPES = {"Edit", "Document", "ComboBox"}
    ALLOW_APPS = {"notepad.exe", "chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe", "excel.exe", "winword.exe"}
    READONLY_APPS = {"systemsettings.exe"}
    DENY_APPS = {"powershell.exe", "pwsh.exe", "cmd.exe"}
    CAPABILITY_APPROVAL = {"filesystem_write", "external_send", "software_install", "financial_commit"}
    CAPABILITY_FORBIDDEN = {"credential_input"}
    HIGH_RISK_APPS = {"regedit.exe", "msiexec.exe", "taskmgr.exe", "mmc.exe", "wscript.exe", "cscript.exe"}

    def __init__(self):
        self.session_domain = None

    def set_session_domain(self, domain):
        self.session_domain = domain
        return domain

    @staticmethod
    def is_alt_tab(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x09 and 0x12 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def is_ctrl_s(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x53 and 0x11 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def is_alt_f4(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x73 and 0x12 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def _process_name(observation):
        value = str(getattr(observation, "process_name", "") or "").lower().strip()
        if value:
            return value
        path = str(getattr(observation, "process_path", "") or "").lower().strip()
        return os.path.basename(path)

    def _app_scope(self, observation):
        process = self._process_name(observation)
        title = str(getattr(observation.accessibility, "window_title", "") or "").lower()
        window_class = str(getattr(observation.accessibility, "window_class", "") or "").lower()
        # Windows Terminal 本身可能承载普通终端；仅当结构/标题明确是 shell 时按禁止处理。
        if process in self.DENY_APPS or (process == "windowsterminal.exe" and any(x in title for x in ("powershell", "command prompt", "cmd", "命令提示符"))):
            return "deny"
        if process in self.READONLY_APPS or "applicationframewindow" in window_class and "settings" in title:
            return "readonly"
        if process in self.ALLOW_APPS:
            return "allow"
        return "default"

    @staticmethod
    def _nearest(observation, command):
        if command.kind != CLICK:
            return None, 9.0
        x = float(command.parameters.get("x", 0.5)); y = float(command.parameters.get("y", 0.5))
        nearest, distance = None, 9.0
        for record in observation.accessibility.records:
            local = math.hypot(float(record.get("x_norm", 0.5)) - x, float(record.get("y_norm", 0.5)) - y)
            if local < distance:
                nearest, distance = record, local
        return nearest, distance

    def _structural_impact(self, command, observation, nearest=None):
        """根据进程、ControlType、AutomationId、对话框角色和前后文推断外部/不可逆影响。"""
        title = str(observation.accessibility.window_title or "").lower()
        window_class = str(observation.accessibility.window_class or "").lower()
        semantic = str(getattr(observation, "semantic_text", "") or "").lower()
        label = ""
        control_type = ""
        automation_id = ""
        if nearest is not None:
            label = " ".join((str(nearest.get("name", "")), str(nearest.get("help", "")), str(nearest.get("class_name", "")))).lower()
            automation_id = str(nearest.get("automation_id", "") or "").lower()
            control_type = str(nearest.get("control_type", "") or "")
        command_text = (str(command.label) + " " + compact_json(command.parameters)).lower()
        context = " ".join((title, window_class, semantic, label, automation_id, command_text))
        security_dialog = bool(getattr(observation, "any_password", False)) or any(word in (title + " " + window_class) for word in self.SECURITY_WINDOWS)
        if security_dialog:
            return "forbidden", "安全/凭据/UAC 结构"
        # 明确角色：对话框中的确认按钮、菜单项或 Enter，且上下文指向外部/不可逆副作用。
        role_commit = control_type in ("Button", "MenuItem", "Hyperlink") and (any(w in label for w in self.GENERIC_CONFIRM) or automation_id in ("1", "ok", "yes", "submit", "install", "delete"))
        text_risk = any(word in context for word in self.IRREVERSIBLE)
        enter_commit = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D
        dialog_like = "dialog" in window_class or "#32770" in window_class or any(x in title for x in ("confirm", "warning", "确认", "警告", "安装", "付款", "结账"))
        if text_risk and (role_commit or enter_commit or dialog_like):
            return "approval", "结构化控件/对话框将产生高影响或不可逆结果"
        if command.kind == CLICK and text_risk:
            return "approval", "目标控件语义指向高影响操作"
        if command.kind == TYPE and any(word in command_text for word in ("run script", "execute", "执行脚本")):
            return "approval", "输入内容可能触发脚本执行"
        return "normal", ""

    @staticmethod
    def _shell_request(value):
        text = re.sub(r"\s+", " ", str(value or "").strip().lower())
        exact = {
            "powershell", "powershell.exe", "windows powershell", "pwsh", "pwsh.exe",
            "cmd", "cmd.exe", "command prompt", "windows command processor", "命令提示符",
        }
        if text in exact:
            return True
        # 对开始菜单中的典型启动命令采用保守匹配；普通文档/浏览器里提到这些词不会触发。
        return bool(re.fullmatch(r"(?:windows\s+)?powershell(?:\.exe)?(?:\s+-.*)?", text) or re.fullmatch(r"(?:cmd|cmd\.exe)(?:\s+/.*)?", text))

    def _shell_launch_from_search(self, command, observation):
        process = self._process_name(observation)
        title = str(getattr(observation.accessibility, "window_title", "") or "").lower()
        window_class = str(getattr(observation.accessibility, "window_class", "") or "").lower()
        semantic = str(getattr(observation, "semantic_text", "") or "").lower()
        focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
        focus_text = " ".join((
            str(focused.get("name", "")), str(focused.get("automation_id", "")),
            str(focused.get("class_name", "")), str(focused.get("value", "")),
        )).lower()
        search_process = process in {"searchhost.exe", "startmenuexperiencehost.exe", "explorer.exe", "shellexperiencehost.exe"}
        search_structure = any(token in (title + " " + window_class + " " + focus_text + " " + semantic) for token in (
            "start", "search", "type here to search", "searchbox", "开始", "搜索", "查找应用",
        ))
        if not (search_process and search_structure):
            return False
        if command.kind == TYPE:
            return self._shell_request(command.parameters.get("text", ""))
        if command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D:
            return self._shell_request(focused.get("value", "")) or self._shell_request(focused.get("name", ""))
        return False

    def _capabilities(self, command, observation, nearest=None):
        """以动作声明和控件结构为主，文字只作为未知自绘 UI 的补充信号。"""
        result = set(str(value) for value in (getattr(command, "required_capabilities", []) or []) if value)
        focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
        if command.kind == TYPE:
            result.add("document_write")
            if focused.get("password"):
                result.add("credential_input")
        if self.is_ctrl_s(command):
            result.add("filesystem_write")
        if command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x2E:
            result.add("filesystem_write")
        control = nearest or {}
        role = " ".join((
            str(control.get("automation_id", "")), str(control.get("name", "")),
            str(control.get("help", "")), str(control.get("class_name", "")), str(command.label),
        )).lower()
        role_id = str(control.get("automation_id", "") or "").lower()
        # 常见结构化提交角色；多语言/无文字控件仍可由技能显式声明 capability。
        if role_id in ("send", "submitmessage", "sendbutton") or any(value in role for value in ("发送", "send message", "send mail")):
            result.add("external_send")
        if role_id in ("install", "installbutton") or any(value in role for value in ("安装", "install now")):
            result.add("software_install")
        if role_id in ("pay", "checkout", "placeorder", "purchase") or any(value in role for value in ("支付", "付款", "下单", "place order", "checkout")):
            result.add("financial_commit")
        if role_id in ("delete", "remove", "rename", "save") or any(value in role for value in ("删除", "重命名", "delete file", "rename file")):
            result.add("filesystem_write")
        return result

    @staticmethod
    def _approved(command, approved_fingerprint):
        return bool(approved_fingerprint) and secrets.compare_digest(str(approved_fingerprint), command.fingerprint())

    def assess(self, command, observation, safe_mode=True, approved_fingerprint="", observe_only=False):
        desktop_safe = bool(getattr(observation, "input_desktop_safe", True))
        if command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE) and not desktop_safe:
            return 1.0, "输入桌面不可确认或已进入 Secure Desktop：fail-closed 禁止所有 SendInput", True
        if self.session_domain is not None and command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
            session_scope = self.session_domain.classify(observation, command)
            if session_scope == "outside":
                return 0.96, "会话权限域：当前程序既非初始应用/子窗口，也没有规划器声明的跨程序原因", True
            process = self._process_name(observation)
            if session_scope == "declared" and process in self.HIGH_RISK_APPS and not self._approved(command, approved_fingerprint):
                if observe_only:
                    return 0.88, "只观察：跨入高风险程序将需要用户确认", False
                return 0.94, "需要用户确认：规划器请求跨入高风险程序，原因：" + str(command.capability_reason), True
        scope = self._app_scope(observation)
        if self._shell_launch_from_search(command, observation):
            return 1.0, "应用权限范围：禁止从 Windows 搜索/开始菜单启动 PowerShell 或 cmd", True
        if scope == "deny" and command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
            return 1.0, "应用权限范围：PowerShell/cmd 类命令行环境被硬禁止", True
        if scope == "readonly" and command.kind in (CLICK, KEY, TYPE):
            return 0.96, "应用权限范围：Windows 设置仅允许只读观察/滚动，不允许修改性输入", True

        title = observation.accessibility.window_title.lower()
        window_class = observation.accessibility.window_class.lower()
        structural_security = bool(getattr(observation, "any_password", False)) or any(word in (title + " " + window_class) for word in self.SECURITY_WINDOWS)
        focused = [record for record in observation.accessibility.records if record.get("focused")]
        focused_sensitive = any(record.get("password") or any(word in (str(record.get("name", "")) + " " + str(record.get("class_name", ""))).lower() for word in self.SENSITIVE) for record in focused)
        if command.kind in (KEY, TYPE) and (structural_security or focused_sensitive):
            return 0.98, "禁止向密码、凭据、UAC 或支付安全界面发送键盘输入", True
        if command.kind == KEY:
            virtual_key = int(command.parameters.get("vk", 0)); modifiers = set(int(value) for value in command.parameters.get("modifiers", []))
            if virtual_key == 0x1B:
                return 1.0, "ESC 专用于紧急停止", True
            if virtual_key in (0x10, 0x11, 0x12, 0x5B, 0x5C):
                return 0.55, "不允许单独压下修饰键", True
            if safe_mode and virtual_key == 0x56 and 0x11 in modifiers:
                return 0.82, "安全模式禁止粘贴未知剪贴板内容；AI 本轮未写入剪贴板", True
            if self.is_alt_tab(command) and not (
                "cross_program" in set(command.required_capabilities) and str(command.capability_reason).strip()
            ):
                return 0.86, "会话权限域：Alt+Tab 会跨程序，但规划器没有声明原因", True
            if self.is_alt_f4(command):
                # 关闭普通窗口本身可组合；若存在未保存提示/星号，再进入精确批准。
                unsaved = any(x in (title + " " + str(getattr(observation, "semantic_text", "")).lower()) for x in ("unsaved", "save changes", "未保存", "保存更改")) or title.rstrip().endswith("*")
                if unsaved:
                    fp = command.fingerprint()
                    if approved_fingerprint and secrets.compare_digest(str(approved_fingerprint), fp):
                        return 0.12, "已批准本次带未保存状态的精确关闭动作", False
                    return 0.90, "需要用户确认：当前窗口可能包含未保存内容，关闭可能丢失数据", True
        if safe_mode and command.kind == TYPE:
            focused_normal = [record for record in focused if record.get("enabled") and not record.get("offscreen") and record.get("control_type") in self.SAFE_TEXT_TYPES and not record.get("password")]
            if not focused_normal:
                return 0.66, "安全模式只向明确聚焦的普通可编辑控件输入文本", True

        nearest, distance = self._nearest(observation, command)
        capabilities = self._capabilities(command, observation, nearest)
        inferred = capabilities - set(command.required_capabilities)
        if inferred:
            command.declare(inferred, command.capability_reason or "执行前由控件结构推断 capability")
        forbidden = sorted(capabilities & self.CAPABILITY_FORBIDDEN)
        if forbidden:
            if observe_only:
                return 0.98, "只观察：检测到禁止能力 " + ",".join(forbidden), False
            return 0.98, "能力策略禁止自动执行：" + ",".join(forbidden), True
        approval = sorted(capabilities & self.CAPABILITY_APPROVAL)
        if approval and not self._approved(command, approved_fingerprint):
            if observe_only:
                return 0.90, "只观察：实际执行将需要 capability 确认：" + ",".join(approval), False
            return 0.93, "需要用户确认：动作声明/结构检测到外部副作用能力 " + ",".join(approval), True
        if command.kind == CLICK:
            if safe_mode and (nearest is None or distance >= 0.085 or nearest.get("control_type") not in self.SAFE_CLICK_TYPES or not nearest.get("enabled") or nearest.get("offscreen")):
                return 0.68, "安全模式只点击当前重新识别出的普通 UIA 控件", True
            if nearest and distance < 0.10 and nearest.get("password"):
                return 0.58, "不操作密码控件", True
            if command.parameters.get("button") == "right":
                return 0.02, "右键操作具有轻微风险", False

        impact, impact_reason = self._structural_impact(command, observation, nearest)
        if impact == "forbidden":
            return 0.98, impact_reason, True
        if safe_mode and impact == "approval":
            fingerprint = command.fingerprint()
            if approved_fingerprint and secrets.compare_digest(str(approved_fingerprint), fingerprint):
                return 0.10, "已获得本次精确高风险动作的一次性用户确认", False
            return 0.92, "需要用户确认：" + impact_reason, True
        return 0.0, "", False


class RewardEngine:

    @staticmethod
    def _difference(previous, current):
        global_change = sum(abs(a - b) for a, b in zip(previous.global_rgb, current.global_rgb)) / max(1, len(previous.global_rgb))
        patch_changes = []
        for first, second in zip(previous.patches, current.patches):
            patch_changes.append(sum(abs(a - b) for a, b in zip(first, second)) / max(1, len(first)))
        patch_change = sum(patch_changes) / max(1, len(patch_changes))
        structural = 1.0 if previous.semantic_signature != current.semantic_signature else 0.0
        return global_change, patch_change, structural

    def evaluate(self, command, previous, current, repeated, stagnant, goal_result, visits_before, outcome, duration):
        global_change, patch_change, structured_change = self._difference(previous, current)
        effect = global_change * 0.55 + patch_change * 0.45
        goal_reward = float(goal_result.get("reward", 0.0))

        curiosity_reward = 0.0
        if command.kind not in (WAIT, SLEEP) and (structured_change or effect >= 0.004):
            novelty = 1.0 / math.sqrt(visits_before + 1.0)
            curiosity_reward = clamp(novelty * (0.18 if structured_change else min(0.10, effect * 1.2)), 0.0, 0.22)
            if command.kind == MOVE:
                curiosity_reward *= 0.10
            elif command.kind == SCROLL:
                curiosity_reward *= 0.32

        action_costs = {WAIT: 0.025, MOVE: 0.025, CLICK: 0.04, SCROLL: 0.035, KEY: 0.04, TYPE: 0.035, SKILL: 0.03}
        efficiency_reward = -action_costs.get(command.kind, 0.02) - min(0.08, duration * 0.008)
        efficiency_reward -= max(0, repeated - 2) * 0.025
        if stagnant > 20:
            efficiency_reward -= min(0.15, (stagnant - 20) * 0.006)
        interactive = command.kind in (CLICK, SCROLL, KEY, TYPE, SKILL)
        if interactive and effect < 0.0025 and not structured_change and not outcome.get("blocked"):
            efficiency_reward -= 0.075
        if effect > 0.34 and not structured_change:
            efficiency_reward -= min(0.20, (effect - 0.34) * 0.8)
        if goal_result.get("progress", 0.0) > 0.0:
            efficiency_reward += min(0.20, float(goal_result["progress"]) * 0.22)
        efficiency_reward = clamp(efficiency_reward, -0.45, 0.25)

        safety_penalty = clamp(float(outcome.get("safety_penalty", 0.0)), 0.0, 1.0)
        total = goal_reward * 0.78 + curiosity_reward * 0.08 + efficiency_reward * 0.14 - safety_penalty
        total = clamp(total, -1.0, 1.0)
        return total, {
            "goal_reward": goal_reward, "curiosity_reward": curiosity_reward,
            "efficiency_reward": efficiency_reward, "safety_penalty": safety_penalty,
            "goal_progress": float(goal_result.get("progress", 0.0)), "goal_completed": bool(goal_result.get("completed")),
            "effect": effect, "global_change": global_change, "patch_change": patch_change,
            "structured_change": structured_change, "signature": current.signature,
        }


class LocalTextGenerator:
    """纯本地确定性文本组合器：模板 + UI 上下文 + 长期成功文本；不做字符级随机生成。"""

    @staticmethod
    def _clean(value):
        return str(value or "").replace("\x00", "").strip()

    @staticmethod
    def _unicode_literals(text):
        chars = []
        for token in re.findall(r"(?:U\+|u\+)([0-9a-fA-F]{1,6})", str(text or "")):
            try:
                codepoint = int(token, 16)
                if 0 <= codepoint <= 0x10FFFF and not 0xD800 <= codepoint <= 0xDFFF:
                    chars.append(chr(codepoint))
            except ValueError:
                pass
        return "".join(chars)

    def generate(self, goal, observation, control, remembered):
        literal = self._unicode_literals(" ".join((goal.requested_goal, goal.success_text)))
        if literal:
            return literal
        # 1) 明确目标文本始终精确复用。
        preferred = [self._clean(value) for value in goal.text_candidates()]
        preferred = [value for value in dict.fromkeys(preferred) if value]
        if preferred:
            return preferred[0]
        # 2) 没有明确文本时只检索成功历史文本，不拼接随机字符。
        remembered = [self._clean(value) for value in (remembered or [])]
        remembered = [value for value in dict.fromkeys(remembered) if value]
        if remembered:
            index = min(len(remembered) - 1, int(clamp(float(control), 0.0, 1.0) * len(remembered)))
            return remembered[index]
        # 3) UI 上下文只用于安全模板：优先取已聚焦编辑控件已有值/名称；无可靠内容则放弃输入。
        if observation is not None:
            focused = next((record for record in observation.accessibility.records if record.get("focused") and record.get("control_type") in ("Edit", "Document", "ComboBox") and not record.get("password")), None)
            if focused is not None:
                existing = self._clean(focused.get("value", ""))
                if existing:
                    return existing
        return ""


class PlainTextHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.title_parts = []
        self.hidden_depth = 0
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        tag = str(tag).lower()
        if tag in ("script", "style", "noscript", "svg", "canvas"):
            self.hidden_depth += 1
        if tag == "title":
            self.in_title = True
        if tag in ("p", "div", "section", "article", "li", "br", "h1", "h2", "h3", "tr"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = str(tag).lower()
        if tag in ("script", "style", "noscript", "svg", "canvas") and self.hidden_depth:
            self.hidden_depth -= 1
        if tag == "title":
            self.in_title = False

    def handle_data(self, data):
        if self.hidden_depth:
            return
        value = re.sub(r"\s+", " ", str(data or "")).strip()
        if value:
            self.parts.append(value)
            if self.in_title:
                self.title_parts.append(value)

    def result(self):
        text = re.sub(r"[ \t]+", " ", " ".join(self.parts))
        text = re.sub(r"\n\s*\n+", "\n", text).strip()
        return " ".join(self.title_parts).strip(), text


class ExternalKnowledgeFetcher:
    """仅抓取用户列出的网页/文档，使用标准库解析，不下载或调用第三方 AI。"""

    def __init__(self, resource_budget, stop_event=None):
        self.resource_budget = resource_budget
        self.stop_event = stop_event

    @staticmethod
    def _public_url(url):
        parsed = urllib_parse.urlsplit(str(url or "").strip())
        if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("只允许不含凭据的 http/https URL")
        addresses = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme.lower() == "https" else 80), type=socket.SOCK_STREAM)
        for address in addresses:
            ip = ipaddress.ip_address(address[4][0].split("%")[0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
                raise ValueError("拒绝访问本机、内网或保留地址")
        return urllib_parse.urlunsplit(parsed)

    def fetch(self, url):
        url = self._public_url(url)
        if self.stop_event is not None and self.stop_event.is_set():
            raise InterruptedError("停止请求")
        maximum = int(self.resource_budget.network_document_bytes())
        request = urllib_request.Request(url, headers={
            "User-Agent": "Local-Unbounded-AI-Knowledge/1.0", "Accept": "text/html,text/plain,application/json,application/xml;q=0.8",
        })
        # urllib 默认会在返回 response 前自动跟随跳转，所以“跳转后再检查”已经太晚。
        # 每个 Location 在发出下一个请求前都重做公网地址与凭据检查，防止公网 URL 跳入内网。
        validate = self._public_url

        class PublicOnlyRedirectHandler(urllib_request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                checked = validate(urllib_parse.urljoin(req.full_url, str(newurl or "")))
                return super().redirect_request(req, fp, code, msg, headers, checked)

        opener = urllib_request.build_opener(PublicOnlyRedirectHandler())
        with opener.open(request, timeout=10.0) as response:
            final_url = self._public_url(response.geturl())
            content_type = str(response.headers.get_content_type() or "").lower()
            if not (content_type.startswith("text/") or content_type in ("application/json", "application/xml", "application/xhtml+xml")):
                raise ValueError("仅允许文本、HTML、JSON 或 XML 文档")
            raw = response.read(maximum + 1)
            truncated = len(raw) > maximum
            raw = raw[:maximum]
            charset = response.headers.get_content_charset() or "utf-8"
        try:
            decoded = raw.decode(charset, "replace")
        except LookupError:
            decoded = raw.decode("utf-8", "replace")
        title = final_url
        if "html" in content_type or "xhtml" in content_type:
            parser = PlainTextHTMLParser(); parser.feed(decoded)
            parsed_title, text = parser.result()
            title = parsed_title or title
        else:
            text = re.sub(r"\s+", " ", decoded).strip()
        return {"url": final_url, "title": title, "text": text, "truncated": truncated, "fetched_at": time.time()}

    def fetch_all(self, urls, memory):
        results = []
        for url in list(dict.fromkeys(str(value).strip() for value in (urls or []) if str(value).strip())):
            if self.stop_event is not None and self.stop_event.is_set():
                break
            try:
                item = self.fetch(url)
                confidence = 0.52 if item["truncated"] else 0.66
                memory.remember_external_document(item["url"], item["title"], item["text"], item["fetched_at"], confidence)
                item["ok"] = True
            except Exception as error:
                item = {"url": url, "ok": False, "error": str(error)}
            results.append(item)
        memory.commit()
        return results


class ActionPlanner:
    def __init__(self, memory, breadth=48, world_model=None):
        self.memory = memory
        self.world_model = world_model or WorldModel(memory)
        self.breadth = max(16, int(breadth))
        self.text_generator = LocalTextGenerator()
        self.meta_report = {}

    def set_meta_report(self, report):
        self.meta_report = dict(report or {})

    def state_uncertainty(self, state, observation, allowed):
        return self.world_model.state_uncertainty(state, getattr(observation, "fuzzy_key", ""), allowed)

    def set_breadth(self, breadth):
        self.breadth = max(self.breadth, int(breadth))

    @staticmethod
    def _perturb(values, exploration, count):
        values = list(values)[:count] + [0.5] * max(0, count - len(values))
        if not exploration:
            return [clamp(value, 0.0, 1.0) for value in values]
        return [clamp(value + random.uniform(-0.28, 0.28), 0.0, 1.0) for value in values]

    def action_biases(self, signature, eligible_skills):
        failures = self.memory.failure_action_scores(signature)
        result = {kind: -0.82 * score for kind, score in failures.items()}
        if eligible_skills:
            bonuses = []
            for skill in eligible_skills:
                uses = max(1, int(skill.get("uses", 0)))
                success = int(skill.get("successes", 0)) / uses
                bonuses.append(success * 0.22 + clamp(float(skill.get("score", 0.0)), -1.0, 1.0) * 0.08)
            result[SKILL] = result.get(SKILL, 0.0) + max(bonuses)
        bottleneck = str((self.meta_report or {}).get("bottleneck", ""))
        if bottleneck == "perception":
            result[WAIT] = result.get(WAIT, 0.0) + 0.18
            result[MOVE] = result.get(MOVE, 0.0) + 0.05
            result[CLICK] = result.get(CLICK, 0.0) - 0.16
        elif bottleneck in ("skill", "planning"):
            result[SKILL] = result.get(SKILL, 0.0) + 0.10
        elif bottleneck == "knowledge":
            result[WAIT] = result.get(WAIT, 0.0) + 0.08
        return result

    def text_candidates(self, goal, observation=None):
        values = goal.text_candidates() + self.memory.text_candidates(32)
        if goal.explicit:
            values.extend((goal.requested_goal, goal.success_text, goal.goal_label))
        if observation is not None and (goal.explicit or any(record.get("focused") and record.get("control_type") in ("Edit", "Document") for record in observation.accessibility.records)):
            values.extend(record.get("name", "") for record in observation.accessibility.records if record.get("name"))
        result = []
        for value in values:
            value = str(value)
            if value and value not in result:
                result.append(value)
        return result

    @staticmethod
    def key_candidates(observation):
        values = [
            (0x09, (), "Tab"), (0x09, (0x10,), "Shift+Tab"), (0x0D, (), "Enter"), (0x20, (), "Space"),
            (0x08, (), "Backspace"), (0x25, (), "Left"), (0x27, (), "Right"), (0x26, (), "Up"), (0x28, (), "Down"),
            (0x24, (), "Home"), (0x23, (), "End"), (0x21, (), "PageUp"), (0x22, (), "PageDown"),
            (0x41, (0x11,), "Ctrl+A"), (0x43, (0x11,), "Ctrl+C"), (0x56, (0x11,), "Ctrl+V"),
            (0x53, (0x11,), "Ctrl+S"), (0x4C, (0x11,), "Ctrl+L"), (0x46, (0x11,), "Ctrl+F"),
            (0x5A, (0x11,), "Ctrl+Z"), (0x59, (0x11,), "Ctrl+Y"), (0x09, (0x12,), "Alt+Tab"),
        ]
        focused_types = {record.get("control_type") for record in observation.accessibility.records if record.get("focused")}
        if "Edit" in focused_types or "Document" in focused_types:
            values = [values[0], values[1], values[2], values[4], values[13], values[16], values[17], values[18], values[19]] + values[5:13]
        return values

    def _choose_point(self, parameters, observation, goal, exploration):
        candidates = []
        if goal.target_point:
            candidates.append((goal.target_point[0], goal.target_point[1], "目标", 5.0, control_locator(goal.target_record)))
        records = [record for record in observation.accessibility.records if record.get("enabled") and not record.get("offscreen") and not record.get("password")]
        records = records[:self.breadth]
        for record in records:
            priority = 2.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 1.0
            if record.get("focused"):
                priority += 1.5
            candidates.append((float(record.get("x_norm", 0.5)), float(record.get("y_norm", 0.5)), record.get("name") or record.get("control_type", "控件"), priority, control_locator(record)))
        candidates.extend((x, y, "动态区域", 0.5, {}) for x, y in observation.patch_centers)
        desired = (parameters[0], parameters[1])
        if goal.target_point and random.random() < (0.72 if not exploration else 0.48):
            return goal.target_point[0], goal.target_point[1], "目标", control_locator(goal.target_record)
        if candidates:
            if exploration and random.random() < 0.35:
                chosen = random.choice(candidates)
                return chosen[0], chosen[1], chosen[2], chosen[4]
            chosen = min(candidates, key=lambda point: math.hypot(point[0] - desired[0], point[1] - desired[1]) - point[3] * 0.015)
            return chosen[0], chosen[1], chosen[2], chosen[4]
        return desired[0], desired[1], "坐标", {}

    def allowed(self, settings, awake_steps, text_candidates, eligible_skills, allow_sleep=False):
        allowed = [WAIT, MOVE, SCROLL]
        if allow_sleep:
            allowed.append(SLEEP)
        if settings.get("clicks"):
            allowed.append(CLICK)
        if settings.get("keyboard"):
            allowed.append(KEY)
            if text_candidates:
                allowed.append(TYPE)
        if eligible_skills:
            allowed.append(SKILL)
        return list(dict.fromkeys(allowed))

    def _lookahead_value(self, model, state, signature, allowed_mask, depth, cache, state_key=""):
        state = normalize_state(state, model.input_count)
        allowed = actions_from_mask(allowed_mask)
        if not allowed:
            return 0.0
        key = (str(signature), str(state_key), int(allowed_mask), int(depth))
        if key in cache:
            return cache[key]
        forward_key = ("forward", str(signature), str(state_key), int(allowed_mask))
        if forward_key in cache:
            q_values = cache[forward_key]
        else:
            _, q_values, _ = model.forward(state)
            cache[forward_key] = q_values
        top = sorted(allowed, key=lambda action: q_values[action], reverse=True)
        if depth <= 0:
            value = max(q_values[action] for action in top)
            cache[key] = value
            return value
        best = -1e9
        for action in top:
            # 优先使用可泛化世界模型；不确定度过高时回退到精确/模糊历史转移。
            prediction = self.world_model.predict(state, action, state_key)
            uncertainty = float(prediction.get("uncertainty", 1.0))
            if prediction.get("support", 0) and uncertainty <= 0.78:
                next_mask = int(prediction.get("next_mask", 0)) or allowed_mask
                future = self._lookahead_value(
                    model, prediction["predicted_state"], prediction.get("next_signature", ""), next_mask,
                    depth - 1, cache, prediction.get("next_state_key", ""),
                )
                action_value = float(prediction.get("reward", 0.0)) + 0.94 * future - float(prediction.get("safety", 0.0)) * 0.50
                action_value -= uncertainty * (0.18 if action in (CLICK, KEY, TYPE, SKILL) else 0.06)
            else:
                transition_limit = max(2, int(math.sqrt(max(1, self.breadth))))
                transitions = self.memory.predict_transitions(signature, action, transition_limit, state_key=state_key) if signature else []
                if transitions:
                    unique = {}
                    for item in transitions:
                        transition_key = (item.get("next_signature", ""), item.get("next_state_key", ""), int(item.get("next_mask", 0)))
                        if transition_key not in unique or float(item.get("priority", 0.0)) > float(unique[transition_key].get("priority", 0.0)):
                            unique[transition_key] = item
                    estimates = []
                    for item in unique.values():
                        future = self._lookahead_value(model, item["next_state"], item.get("next_signature", ""), item.get("next_mask", 0), depth - 1, cache, item.get("next_state_key", ""))
                        estimates.append(float(item.get("reward", 0.0)) + 0.94 * future - float(item.get("safety_penalty", 0.0)) * 0.45)
                    action_value = sum(estimates) / len(estimates)
                else:
                    action_value = q_values[action] - (0.12 if action in (CLICK, KEY, TYPE, SKILL) else 0.02)
            best = max(best, action_value)
        cache[key] = best
        return best

    @staticmethod
    def _browser_context(observation):
        window_class = str(observation.accessibility.window_class or "").lower()
        title = str(observation.accessibility.window_title or "").lower()
        browser_classes = ("chrome_widgetwin", "mozillawindowclass")
        if any(value in window_class for value in browser_classes):
            return True
        browser_terms = ("microsoft edge", "google chrome", "mozilla firefox", "浏览器")
        if any(value in title for value in browser_terms):
            return True
        for record in observation.accessibility.records:
            text = " ".join((str(record.get("name", "")), str(record.get("automation_id", "")), str(record.get("help", "")))).lower()
            if record.get("control_type") in ("Edit", "ComboBox") and any(term in text for term in ("address", "omnibox", "search bar", "地址", "搜索栏")):
                return True
        return False

    @staticmethod
    def _start_search_context(observation):
        title = str(observation.accessibility.window_title or "").strip().lower()
        window_class = str(observation.accessibility.window_class or "").lower()
        semantic = observation.semantic_text.lower()
        if title in ("search", "windows search", "start", "搜索", "开始"):
            return True
        if len(title) <= 48 and any(term in title for term in ("windows search", "search", "搜索")):
            return True
        shell_classes = ("windows.ui.core.corewindow", "xamlexplorerhostislandwindow", "startmenuexperiencehost")
        return any(term in window_class for term in shell_classes) and any(term in semantic for term in ("search", "搜索", "type here to search"))

    def compiled_command(self, goal, observation, allowed, settings=None):
        """执行 GoalCompiler 的单个子目标状态机；每次只发一个原子动作，动作后必须重新感知。"""
        step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else None
        if step is None:
            return None
        operation = str(step.get("operation") or step.get("action", ""))
        action = str(step.get("action", ""))
        payload = str(step.get("payload", "")).strip()
        target = str(step.get("target", "") or payload).strip()
        value = str(step.get("value", "") or payload).strip()
        safe_mode = True if settings is None else bool(settings.get("safe_mode", True))
        knowledge_cache = {}
        max_retries = max(0, int(step.get("max_retries", 2)))
        if str(getattr(goal, "compiled_phase", "")) == "recovery" and int(getattr(goal, "compiled_attempts", 0)) > max_retries:
            goal.compiler_stalled = True
            if WAIT in allowed:
                return ActionCommand(WAIT, {"duration": 0.22}, "子目标恢复次数耗尽：停止盲重试，等待元认知睡眠/重新规划", [0.5], 0b1)
            return None

        def emit(command, phase):
            capabilities = list(step.get("capabilities") or [])
            reason = "目标子步骤 {}：{}".format(operation, str(step.get("source", "") or payload)[:240])
            if operation in ("ensure_application",) and "cross_program" not in capabilities:
                capabilities.append("cross_program")
                reason = "为完成目标而切换/启动指定应用：" + str(step.get("target", "") or payload)[:220]
            command.declare(capabilities, reason if capabilities else "")
            if hasattr(goal, "set_compiled_phase"):
                goal.set_compiled_phase(phase, attempted=True)
            return command

        def record_text(record):
            return " ".join((str(record.get("name", "")), str(record.get("automation_id", "")), str(record.get("help", "")), str(record.get("value", "")), str(record.get("class_name", ""))))

        def matching_control(types=None, query=None, threshold=0.28):
            query = target if query is None else str(query)
            best = None
            best_score = -1.0
            qlower = query.lower().strip()
            for record in observation.accessibility.records:
                if record.get("offscreen") or not record.get("enabled") or record.get("password"):
                    continue
                if types and record.get("control_type") not in types:
                    continue
                text = record_text(record)
                lower = text.lower()
                score = similarity(query, text) if query else 0.0
                name = str(record.get("name", "")).strip().lower()
                if qlower and qlower == name:
                    score += 1.15
                elif qlower and qlower in lower:
                    score += 0.62
                if record.get("focused"):
                    score += 0.08
                # 知识成长真正参与定位：过去见过的 AutomationId/ControlType 只提供语义先验，最终仍必须匹配当前 UIA 控件。
                cache_key = (str(getattr(observation, "process_name", "") or "").lower(), query)
                if cache_key not in knowledge_cache:
                    knowledge_cache[cache_key] = self.memory.known_control_hints(cache_key[0], query, limit=8)
                for hint in knowledge_cache[cache_key]:
                    if hint.get("automation_id") and str(hint.get("automation_id")) == str(record.get("automation_id", "")):
                        score += 0.42
                    if hint.get("control_type") and hint.get("control_type") == record.get("control_type") and similarity(str(hint.get("name", "")), str(record.get("name", ""))) >= 0.42:
                        score += 0.18
                if score > best_score:
                    best_score, best = score, record
            return best if best is not None and best_score >= threshold else None

        def click_record(record, label, phase, button="left"):
            command = ActionCommand(
                CLICK,
                {"x": float(record.get("x_norm", 0.5)), "y": float(record.get("y_norm", 0.5)), "button": button, "target": control_locator(record)},
                label, [float(record.get("x_norm", 0.5)), float(record.get("y_norm", 0.5)), 1.0 if button == "right" else 0.0], 0b111,
            )
            if record.get("control_type") == "Hyperlink":
                command.declare(["cross_program"], "激活目标相关链接；若打开新程序，纳入本次会话权限域")
            return emit(command, phase)

        focused = next((record for record in observation.accessibility.records if record.get("focused") and record.get("enabled") and not record.get("offscreen") and not record.get("password")), None)
        focused_type = str((focused or {}).get("control_type", ""))
        focused_value = " ".join((str((focused or {}).get("value", "")), str((focused or {}).get("name", "")))).lower()
        editable = focused is not None and focused_type in SafetyPolicy.SAFE_TEXT_TYPES
        payload_present = bool(value and value.lower() in focused_value)
        phase = str(getattr(goal, "compiled_phase", "precondition"))
        semantic = observation.semantic_text.lower()
        title = str(observation.accessibility.window_title or "").lower()
        process_name = str(getattr(observation, "process_name", "") or "").lower()
        if phase == "recovery" and int(getattr(goal, "compiled_attempts", 0)) >= 1:
            learned = self.memory.best_strategy(operation, process_name or "unknown")
            if learned and learned.get("confidence", 0.0) >= 0.38:
                for payload_item in learned.get("recovery", [])[:4]:
                    try:
                        learned_command = ActionCommand.from_payload(payload_item)
                    except Exception:
                        continue
                    if learned_command.kind in allowed and learned_command.kind in (CLICK, KEY):
                        learned_command.label = "学习到的恢复策略：" + (learned_command.label or ACTION_NAMES[learned_command.kind])
                        return emit(learned_command, "recovery")

        def application_matches(name):
            name = str(name or "").strip().lower()
            if not name:
                return False
            joined = " ".join((title, semantic, process_name))
            if name in joined:
                return True
            if any(token in name for token in ("浏览器", "browser")):
                return self._browser_context(observation)
            if any(token in name for token in ("excel", "电子表格")):
                return "excel" in joined or "xlmain" in str(observation.accessibility.window_class or "").lower()
            if any(token in name for token in ("记事本", "notepad")):
                return "notepad" in joined or "记事本" in joined
            return False

        # --- 未知目标的通用“观察 -> 候选子目标 -> 尝试 -> 验证 -> 编译”路径 ---
        if step.get("generic"):
            frame = dict(step.get("frame") or {})
            frame_parameters = dict(frame.get("parameters") or {})
            query = " ".join(value for value in (str(frame.get("action", "")), str(frame.get("object", "")), target) if value)
            candidate = matching_control(INTERACTIVE_CONTROL_TYPES, query=query, threshold=0.04)
            if operation == "observe_context" and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.08, "force_deep_observation": True}, "通用目标：先观察 UI 和前置条件", [0.2], 0b1), "verify")
            if operation == "locate_target":
                if candidate is not None and WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "通用目标：已提出候选控件 {}".format(str(candidate.get("name") or candidate.get("control_type"))[:80]), [0.2], 0b1), "verify")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": True}, "通用目标：扩大 UIA 后重新提出候选", [0.35], 0b1), "recovery")
            if operation == "candidate_subgoal":
                typed_values = list(frame_parameters.get("addresses") or []) + list(frame_parameters.get("quoted_values") or [])
                if frame_parameters.get("value"):
                    typed_values.append(str(frame_parameters["value"]))
                if editable and typed_values and TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": str(typed_values[0])}, "通用候选：填入已解析参数", [0.0], 0b1), "action")
                if candidate is not None and CLICK in allowed:
                    return click_record(candidate, "通用候选：尝试最相关的低风险控件", "action")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x09, "modifiers": []}, "通用候选：用 Tab 探索下一个可验证焦点", [0.0], 0b1), "action")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.12}, "通用候选：等待可观察变化", [0.3], 0b1), "action")
            if operation == "commit_candidate":
                category = str(frame.get("category", "achieve"))
                commit_terms = {
                    "external_send": "send submit 发送 发出",
                    "filesystem_write": "save rename apply 保存 重命名 应用",
                    "software_install": "install continue 安装 继续",
                    "financial_commit": "pay buy checkout confirm 支付 购买 下单 确认",
                    "document_write": "apply save done 应用 保存 完成",
                    "aggregate": "sum total calculate 求和 合计 计算",
                }.get(category, query)
                commit_control = matching_control({"Button", "MenuItem", "Hyperlink", "ListItem"}, query=commit_terms, threshold=0.08)
                if commit_control is not None and CLICK in allowed:
                    return click_record(commit_control, "通用目标：提交已验证候选", "submit")
                if category in ("aggregate", "document_write") and KEY in allowed and editable:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "通用目标：提交当前编辑", [0.0], 0b1), "submit")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.12, "force_deep_observation": True}, "通用目标：未找到可安全提交控件，保持观察", [0.3], 0b1), "recovery")
            if operation in ("verify_result", "compile_success") and WAIT in allowed:
                label = "验证通用目标结果" if operation == "verify_result" else "稳定结果并把成功轨迹编译成新程序"
                return emit(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": operation == "verify_result"}, label, [0.35], 0b1), "verify")
            return None

        # --- 结构化子目标：文件/对象重命名 ---
        if operation == "locate_object":
            record = matching_control({"ListItem", "TreeItem", "DataItem", "Text", "Button"}, query=target, threshold=0.18)
            if record is not None and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.08}, "子目标：已定位 {}".format(str(record.get("name") or target)[:80]), [0.2], 0b1), "verify")
            # “桌面上的文件”是一个结构前置条件，不靠随机点击寻找。
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x44, "modifiers": [0x5B]}, "恢复：显示桌面后重新扫描目标", [0.0], 0b1), "recovery")
            return ActionCommand(WAIT, {"duration": 0.18}, "等待 UIA 提供目标对象", [0.4], 0b1) if WAIT in allowed else None

        if operation == "select_object":
            record = matching_control({"ListItem", "TreeItem", "DataItem", "Text", "Button"}, query=target, threshold=0.18)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：选中 {}".format(str(record.get("name") or target)[:80]), "action")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.14}, "恢复：目标暂不可见，重新感知", [0.3], 0b1), "recovery")

        if operation == "request_rename":
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "子目标：F2 请求重命名", [0.0], 0b1), "action")

        if operation == "acquire_editor":
            if editable and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.06}, "子目标：已获得重命名编辑框", [0.2], 0b1), "verify")
            edit = matching_control(SafetyPolicy.SAFE_TEXT_TYPES, query="rename name filename 名称 重命名", threshold=0.05)
            if edit is not None and CLICK in allowed:
                return click_record(edit, "恢复：聚焦重命名编辑框", "recovery")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "恢复：再次请求重命名编辑框", [0.0], 0b1), "recovery")

        # replace_text 同时服务普通输入、重命名、公式。先 Ctrl+A，再 TYPE，避免“追加文本”。
        if operation == "replace_text" and value:
            if editable:
                if payload_present and WAIT in allowed:
                    # 目标文本已被 UIA 观察到，直接进入验证；避免异步 ValuePattern 导致重复追加输入。
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "验证：指定文本已存在于编辑控件", [0.2], 0b1), "verify")
                if phase not in ("select_existing_text", "enter_payload") and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中编辑框现有内容", [0.0], 0b1), "select_existing_text")
                if TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": value}, "子目标：输入 {}".format(value[:96]), [0.0], 0b1), "enter_payload")
            # Excel/Explorer 的编辑器可能在 F2 后才进入 UIA Control View。
            if KEY in allowed and ("excel" in process_name or operation == "replace_text") and phase == "recovery":
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "恢复：请求当前对象进入编辑模式", [0.0], 0b1), "recovery")
            record = matching_control(SafetyPolicy.SAFE_TEXT_TYPES, query=target or "edit input 编辑", threshold=0.05)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：聚焦可编辑控件", "focus_target")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.12}, "等待可编辑控件", [0.3], 0b1), "recovery")

        if operation in ("commit_edit", "commit_formula"):
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：Enter 提交编辑", [0.0], 0b1), "submit")

        if operation == "verify_object":
            record = matching_control(None, query=target, threshold=0.18)
            if record is not None and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.10}, "验证：{} 已出现".format(target[:96]), [0.25], 0b1), "verify")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.18}, "验证未通过：重新扫描 {}".format(target[:96]), [0.45], 0b1), "recovery")

        # --- 当前窗口关闭：只产生关闭请求；是否允许由结构化 SafetyPolicy 决定。 ---
        if operation == "close_window":
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x73, "modifiers": [0x12]}, "子目标：关闭当前窗口", [0.0], 0b1), "action")

        # --- Excel 公式程序 ---
        if operation == "formula_mode":
            if application_matches("Excel"):
                if editable and WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "子目标：Excel 单元格已进入公式编辑模式", [0.2], 0b1), "verify")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "子目标：F2 进入 Excel 单元格编辑模式", [0.0], 0b1), "action")
            # 前置应用丢失时回到确定性的应用恢复，不随机点击。
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "恢复：重新定位 Excel", [0.0], 0b1), "recovery")

        if operation == "verify_formula_result":
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.14}, "验证：公式提交后的结构化状态", [0.35], 0b1), "verify")

        # --- URL / 应用前置条件 ---
        if operation in ("ensure_url",) or (operation in ("search", "ensure_application") and value and re.match(r"https?://", value, re.IGNORECASE)):
            url = value
            if not self._browser_context(observation):
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "前置条件：打开 Windows 搜索以启动浏览器", [0.0], 0b1), "ensure_browser")
                return None
            address = matching_control({"Edit", "ComboBox"}, query="address search 地址 搜索栏 omnibox", threshold=0.05)
            if editable and TYPE in allowed and url.lower() not in focused_value:
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中地址栏内容", [0.0], 0b1), "select_existing_text")
                return emit(ActionCommand(TYPE, {"text": url}, "子目标：输入 URL", [0.0], 0b1), "enter_payload")
            if editable and url.lower() in focused_value and KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：提交 URL", [0.0], 0b1), "submit")
            if address is not None and CLICK in allowed:
                return click_record(address, "子目标：聚焦浏览器地址栏", "focus_target")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x4C, "modifiers": [0x11]}, "恢复：浏览器中 Ctrl+L 聚焦地址栏", [0.0], 0b1), "recovery")

        if operation == "ensure_application" and payload:
            if application_matches(payload):
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.10}, "验证：目标应用已在前台", [0.25], 0b1), "verify")
            # Windows Search 是可验证的应用启动路径。
            if self._start_search_context(observation) and editable:
                launch_text = "Microsoft Edge" if any(x in payload.lower() for x in ("浏览器", "browser")) else payload
                if launch_text.lower() not in focused_value and TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": launch_text}, "子目标：在 Windows 搜索输入应用名", [0.0], 0b1), "enter_payload")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：启动应用并重新验证", [0.0], 0b1), "submit")
            record = matching_control(INTERACTIVE_CONTROL_TYPES, query=payload, threshold=0.58)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：打开 {}".format(str(record.get("name") or payload)[:80]), "action")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "前置条件：打开 Windows 搜索", [0.0], 0b1), "precondition")

        if operation in ("activate_control",) or action == "click":
            if CLICK in allowed and payload:
                record = matching_control(INTERACTIVE_CONTROL_TYPES, query=payload, threshold=0.26)
                if record is not None:
                    return click_record(record, "子目标：定位并点击 {}".format(str(record.get("name") or payload)[:80]), "action")

        if operation == "search" and payload:
            search_control = matching_control({"Edit", "ComboBox", "Document"}, query="search 搜索 find 查找", threshold=0.05)
            if editable:
                if payload.lower() in focused_value and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：提交搜索", [0.0], 0b1), "submit")
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中搜索框内容", [0.0], 0b1), "select_existing_text")
                if TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": payload}, "子目标：输入搜索词", [0.0], 0b1), "enter_payload")
            if search_control is not None and CLICK in allowed:
                return click_record(search_control, "子目标：聚焦搜索框", "focus_target")
            if self._browser_context(observation) and KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x4C, "modifiers": [0x11]}, "恢复：浏览器中聚焦地址/搜索栏", [0.0], 0b1), "recovery")

        if operation == "find" and payload:
            if editable and TYPE in allowed:
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中查找框内容", [0.0], 0b1), "select_existing_text")
                return emit(ActionCommand(TYPE, {"text": payload}, "子目标：输入查找词", [0.0], 0b1), "enter_payload")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x46, "modifiers": [0x11]}, "子目标：打开查找框", [0.0], 0b1), "focus_target")

        if operation == "save" and KEY in allowed and not safe_mode:
            return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x11]}, "子目标：保存", [0.0], 0b1), "submit")
        return None

    def plan_with_lookahead(self, model, state, allowed, observation, goal, text_candidates, eligible_skills, exploration=False, settings=None):
        compiled = self.compiled_command(goal, observation, allowed, settings=settings)
        if compiled is not None:
            # 明确目标的结构化程序不依赖随机探索；每步动作后都会二次感知/验证。
            return compiled
        cache = {}
        _, q_values, parameter_map = model.forward(state)
        state_key = str(getattr(observation, "fuzzy_key", ""))
        cache[("forward", str(observation.signature), state_key, int(mask_actions(allowed)))] = q_values
        biases = self.action_biases(observation.signature, eligible_skills)
        for kind, bonus in goal.compiler_action_biases().items():
            biases[kind] = biases.get(kind, 0.0) + bonus

        uncertainty_by_action = {kind: self.world_model.predict(state, kind, state_key).get("uncertainty", 1.0) for kind in allowed}
        actionable_uncertainty = [float(value) for kind, value in uncertainty_by_action.items() if kind not in (WAIT, SLEEP)]
        global_uncertainty = min(actionable_uncertainty) if actionable_uncertainty else 0.0
        # “看不清就不动作”：高不确定时优先观察/等待，不用随机点击填补知识空白。
        if global_uncertainty >= 0.82 and WAIT in allowed and (getattr(observation, "perception_limited", False) or exploration):
            return ActionCommand(WAIT, {"duration": 0.18}, "世界模型不确定：等待并重新获取 UIA/视觉", [0.45], 0b1)
        for kind, uncertainty in uncertainty_by_action.items():
            if kind in (CLICK, KEY, TYPE, SKILL):
                biases[kind] = biases.get(kind, 0.0) - float(uncertainty) * 0.22
            elif kind == WAIT:
                biases[kind] = biases.get(kind, 0.0) + global_uncertainty * 0.10

        branch = min(len(allowed), max(3, int(math.sqrt(max(1, self.breadth)))))
        # 规则/GoalCompiler/UIA/技能先产生合法候选命令；Q 网络只对候选排序。
        legal_commands = []
        for action in allowed:
            raw = list(parameter_map.get(action, []))
            legal_commands.append(self.plan(action, raw, observation, goal, text_candidates, eligible_skills, exploration=False))
            if exploration and global_uncertainty < 0.50 and action not in (SLEEP, SKILL):
                legal_commands.append(self.plan(action, raw, observation, goal, text_candidates, eligible_skills, exploration=True))
        unique_commands = {}
        for command in legal_commands:
            unique_commands.setdefault(command.fingerprint(), command)
        legal_commands = list(unique_commands.values())
        legal_commands.sort(key=lambda command: q_values[command.kind] + float(biases.get(command.kind, 0.0)) - self.memory.failure_score(observation.signature, command) * 0.55, reverse=True)
        ranked_commands = legal_commands[:max(branch, min(len(legal_commands), branch * 2))]
        depth = max(2, int(math.log2(1.0 + max(1, self.breadth)) / 2.0))
        best = None
        for command in ranked_commands:
            action = command.kind
            immediate = q_values[action] + float(biases.get(action, 0.0)) - self.memory.failure_score(observation.signature, command) * 0.55
            prediction = self.world_model.predict(state, action, state_key)
            if prediction.get("support", 0) and float(prediction.get("uncertainty", 1.0)) <= 0.78:
                future = self._lookahead_value(
                    model, prediction["predicted_state"], prediction.get("next_signature", ""),
                    int(prediction.get("next_mask", 0)) or mask_actions(allowed), depth - 2, cache, prediction.get("next_state_key", ""),
                )
                immediate += (float(prediction.get("reward", 0.0)) + 0.94 * future - float(prediction.get("safety", 0.0)) * 0.50) * 0.70
                immediate -= float(prediction.get("uncertainty", 1.0)) * (0.20 if action in (CLICK, KEY, TYPE, SKILL) else 0.05)
            else:
                transitions = self.memory.predict_transitions(observation.signature, action, max(2, int(math.sqrt(max(1, self.breadth)))), state_key=state_key)
                if transitions:
                    future_values = []
                    for item in transitions:
                        future = self._lookahead_value(model, item["next_state"], item.get("next_signature", ""), item.get("next_mask", 0), depth - 2, cache, item.get("next_state_key", ""))
                        future_values.append(float(item.get("reward", 0.0)) + 0.94 * future - float(item.get("safety_penalty", 0.0)) * 0.50)
                    immediate += sum(future_values) / len(future_values) * 0.55
            if best is None or immediate > best[0]:
                best = (immediate, command)
        if best is None:
            return self.plan(WAIT, [0.5], observation, goal, text_candidates, eligible_skills, exploration=False)
        command = best[1]
        command.label = "{}步世界模型规划：{}".format(depth, command.label)
        return command

    def plan(self, kind, raw_parameters, observation, goal, text_candidates, eligible_skills, exploration=False):
        count = PARAM_HEAD_SIZES[int(kind)]
        values = self._perturb(raw_parameters, exploration, count)
        mask = (1 << count) - 1 if count else 0
        if kind == WAIT:
            duration = 0.10 + values[0] * 0.35
            return ActionCommand(WAIT, {"duration": duration}, "等待 {:.2f}s".format(duration), values, mask)
        if kind == SLEEP:
            return ActionCommand(SLEEP, {}, "进入睡眠", values, 0)
        if kind in (MOVE, CLICK):
            x, y, target_name, target_locator = self._choose_point(values, observation, goal, exploration)
            values[0], values[1] = x, y
            if kind == MOVE:
                return ActionCommand(MOVE, {"x": x, "y": y}, "移动到 " + str(target_name)[:60], values, mask)
            button = "right" if values[2] > 0.93 else "left"
            values[2] = 1.0 if button == "right" else 0.0
            click_parameters = {"x": x, "y": y, "button": button}
            if target_locator:
                click_parameters["target"] = target_locator
            command = ActionCommand(CLICK, click_parameters, "{}键点击 {}".format("右" if button == "right" else "左", str(target_name)[:60]), values, mask)
            if self.memory.failure_score(observation.signature, command) > 0.62 and not exploration:
                values[0] = clamp(values[0] + random.uniform(-0.10, 0.10), 0.0, 1.0)
                values[1] = clamp(values[1] + random.uniform(-0.10, 0.10), 0.0, 1.0)
                retry_parameters = {"x": values[0], "y": values[1], "button": button}
                if target_locator:
                    retry_parameters["target"] = target_locator
                command = ActionCommand(CLICK, retry_parameters, "避开失败记忆后点击", values, mask)
            return command
        if kind == SCROLL:
            steps = int(round((values[0] * 2.0 - 1.0) * 8.0))
            if steps == 0:
                steps = 1 if values[0] >= 0.5 else -1
            amount = int(clamp(steps * 120, -960, 960))
            values[0] = amount / 1920.0 + 0.5
            return ActionCommand(SCROLL, {"amount": amount}, "滚动 {}".format(amount), values, mask)
        if kind == KEY:
            candidates = self.key_candidates(observation)
            index = min(len(candidates) - 1, int(values[0] * len(candidates)))
            virtual_key, modifiers, name = candidates[index]
            values[0] = index / max(1, len(candidates) - 1)
            return ActionCommand(KEY, {"vk": virtual_key, "modifiers": list(modifiers)}, "按键 " + name, values, mask)
        if kind == TYPE:
            text = goal.deterministic_text(observation)
            if text:
                return ActionCommand(TYPE, {"text": text}, "目标编译器确定性输入（{} 字符）".format(len(text)), values, mask)
            text = self.text_generator.generate(goal, observation, values[0], text_candidates)
            return ActionCommand(TYPE, {"text": text}, "本地模板/记忆兜底输入（{} 字符）".format(len(text)), values, mask)
        if kind == SKILL:
            index = min(len(eligible_skills) - 1, int(values[0] * len(eligible_skills)))
            skill = eligible_skills[index]
            values[0] = index / max(1, len(eligible_skills) - 1)
            args = {}
            specs = dict(skill.get("parameters") or {})
            deterministic = goal.deterministic_text(observation)
            for name, spec in specs.items():
                default = spec.get("default", "") if isinstance(spec, dict) else spec
                if name == "text" and deterministic:
                    args[name] = deterministic
                else:
                    args[name] = default
            return ActionCommand(SKILL, {"skill_id": skill["id"], "args": args}, "{}：{}".format(skill.get("abstraction_kind", "Skill"), skill["name"][:80]), values, mask)
        return ActionCommand(WAIT, {"duration": 0.2}, "等待", [0.5], 1)


class SkillManager:

    def __init__(self, memory, attention_limit=128):
        self.memory = memory
        self.attention_limit = max(32, int(attention_limit))
        self.pending = []
        self.episode_trace = []
        self.start_context = {}
        self.goal_label = ""
        self.queued_current = False

    def set_attention_limit(self, attention_limit):
        self.attention_limit = max(self.attention_limit, int(attention_limit))

    def context(self, observation):
        context_limit = max(24, min(self.attention_limit, len(observation.accessibility.records)))
        controls = [record.get("control_type", "") + " " + record.get("name", "") for record in observation.accessibility.records[:context_limit]]
        semantic_limit = max(8, int(math.sqrt(max(1, self.attention_limit)) * 8.0))
        return {
            "window_title": observation.accessibility.window_title,
            "window_class": observation.accessibility.window_class,
            "semantic_terms": semantic_units(" ".join(controls))[:semantic_limit],
            "semantic_signature": observation.semantic_signature,
        }

    def begin_goal(self, observation, goal_label):
        self.episode_trace = []
        self.start_context = self.context(observation)
        self.goal_label = str(goal_label)
        self.queued_current = False

    @staticmethod
    def _semantic_skill_command(command):
        payload = command.payload()
        if command.kind == CLICK:
            parameters = dict(payload.get("parameters", {}))
            locator = dict(parameters.get("target") or {})
            if locator:
                # 技能以语义定位为主；归一化坐标仅作为低优先级兜底元数据，不作为首选执行目标。
                fallback = [safe_float(parameters.get("x", 0.5), 0.5), safe_float(parameters.get("y", 0.5), 0.5)]
                payload["parameters"] = {"button": parameters.get("button", "left"), "target": locator, "fallback_point": fallback}
        return payload

    def observe(self, command, outcome, components, current, duration):
        if not outcome.get("executed") or command.kind in (WAIT, SLEEP):
            return
        if command.kind == SKILL:
            step = {"type": "skill", "skill_id": int(command.parameters.get("skill_id", 0)), "condition": self.start_context}
        else:
            step = {"type": "action", "command": self._semantic_skill_command(command)}
        self.episode_trace.append(step)
        if components.get("goal_completed") and not self.queued_current:
            self.queue_candidate(current, float(components.get("goal_reward", 0.0)))

    def queue_candidate(self, observation, score):
        if self.queued_current or len(self.episode_trace) < 2:
            return
        expected = self.context(observation)
        self.pending.append({
            "name": self.goal_label or "可复用界面技能", "steps": list(self.episode_trace),
            "precondition": dict(self.start_context), "expected": expected, "score": max(0.05, float(score)),
        })
        self.queued_current = True

    @staticmethod
    def precondition_matches(skill, observation):
        condition = skill.get("precondition", {})
        current_class = observation.accessibility.window_class
        expected_class = condition.get("window_class", "")
        if expected_class and current_class and expected_class != current_class:
            return False
        expected_title = condition.get("window_title", "")
        if expected_title and observation.accessibility.window_title and similarity(expected_title, observation.accessibility.window_title) < 0.08:
            return False
        return True

    @staticmethod
    def expected_matches(skill, observation):
        expected = skill.get("expected", {})
        if expected.get("semantic_signature") and expected["semantic_signature"] == observation.semantic_signature:
            return True
        if expected.get("window_title") and similarity(expected["window_title"], observation.accessibility.window_title) >= 0.45:
            return True
        terms = set(expected.get("semantic_terms", []))
        current = set(semantic_units(observation.semantic_text))
        return bool(terms) and len(terms & current) / len(terms) >= 0.62

    @staticmethod
    def _resolve_program_value(value, variables):
        if isinstance(value, dict) and set(value.keys()) == {"$var"}:
            return variables.get(str(value.get("$var")), "")
        if isinstance(value, dict):
            return {key: SkillManager._resolve_program_value(item, variables) for key, item in value.items()}
        if isinstance(value, list):
            return [SkillManager._resolve_program_value(item, variables) for item in value]
        return value

    @staticmethod
    def _programize(steps):
        """把动作轨迹升级为参数化程序；程序解释器还支持 if/retry/loop/skill/observe。"""
        result = []
        parameters = {}
        text_index = 0
        for original in steps:
            step = json.loads(compact_json(original))
            if step.get("type") == "action":
                command = step.get("command", {})
                if int(command.get("kind", WAIT)) == TYPE:
                    params = command.setdefault("parameters", {})
                    literal = str(params.get("text", ""))
                    text_index += 1
                    name = "text" if text_index == 1 else "text{}".format(text_index)
                    parameters[name] = {"type": "text", "default": literal, "required": True}
                    params["text"] = {"$var": name}
            result.append(step)
        return result, parameters

    @staticmethod
    def _program_steps(step):
        if not isinstance(step, dict):
            return []
        found = [step]
        for key in ("steps", "then", "else", "recovery"):
            value = step.get(key, [])
            if isinstance(value, dict):
                value = [value]
            for child in value if isinstance(value, list) else []:
                found.extend(SkillManager._program_steps(child))
        return found

    @classmethod
    def _program_capabilities(cls, steps, memory=None):
        capabilities = set()
        for root in steps or []:
            for step in cls._program_steps(root):
                if step.get("type") == "action":
                    capabilities.update(str(value) for value in step.get("command", {}).get("required_capabilities", []) if value)
                elif step.get("type") == "skill" and memory is not None:
                    child = memory.get_skill(int(step.get("skill_id", 0)))
                    if child:
                        capabilities.update(str(value) for value in child.get("capabilities", []) if value)
        return sorted(capabilities)

    @staticmethod
    def success_matches(skill, observation):
        success = dict(skill.get("success") or {})
        if not success:
            return SkillManager.expected_matches(skill, observation)
        kind = str(success.get("type", "expected_context"))
        if kind == "expected_context":
            pseudo = dict(skill)
            pseudo["expected"] = dict(success.get("value") or skill.get("expected") or {})
            return SkillManager.expected_matches(pseudo, observation)
        if kind == "semantic_contains":
            return str(success.get("value", "")).lower() in observation.semantic_text.lower()
        if kind == "focused_contains":
            needle = str(success.get("value", "")).lower()
            focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
            return needle in (str(focused.get("value", "")) + " " + str(focused.get("name", ""))).lower()
        if kind == "control_exists":
            query = str(success.get("value", ""))
            return any(similarity(query, str(record.get("name", ""))) >= 0.28 for record in observation.accessibility.records)
        return SkillManager.expected_matches(skill, observation)

    def capability_allowed(self, skill, settings, seen=None):
        if settings is None:
            return True
        seen = set(seen or ())
        identifier = int(skill.get("id", 0))
        if identifier in seen:
            return False
        seen.add(identifier)
        if not settings.get("observe_only") and set(skill.get("capabilities", [])) & SafetyPolicy.CAPABILITY_FORBIDDEN:
            return False
        for root in skill.get("steps", []):
            for step in self._program_steps(root):
                if step.get("type") == "skill":
                    child = self.memory.get_skill(int(step.get("skill_id", 0)))
                    if child is None or not self.capability_allowed(child, settings, seen):
                        return False
                    continue
                if step.get("type") != "action":
                    continue
                try:
                    kind = int(step.get("command", {}).get("kind", WAIT))
                except (TypeError, ValueError):
                    return False
                if kind == CLICK and not settings.get("clicks"):
                    return False
                if kind in (KEY, TYPE) and not settings.get("keyboard"):
                    return False
        return True

    def eligible(self, observation, settings=None, limit=48):
        candidates = []
        for skill in self.memory.top_skills(self.attention_limit):
            if not self.precondition_matches(skill, observation):
                continue
            if not self.capability_allowed(skill, settings):
                continue
            ratio = skill["successes"] / max(1, skill["uses"])
            context_score = similarity(skill["precondition"].get("window_title", ""), observation.accessibility.window_title)
            skill["retrieval_score"] = skill["score"] + ratio * 0.35 + context_score * 0.25
            candidates.append(skill)
        candidates.sort(key=lambda value: value["retrieval_score"], reverse=True)
        return candidates[:int(limit)]

    @staticmethod
    def _step_key(step):
        if step.get("type") == "skill":
            return "skill:" + str(step.get("skill_id", 0))
        return "action:" + compact_json(step.get("command", {}))

    def _compress_with_children(self, steps, existing):
        result = list(steps)
        children = []
        patterns = []
        for skill in existing:
            keys = [self._step_key(step) for step in skill.get("steps", [])]
            if len(keys) >= 2:
                patterns.append((len(keys), keys, skill))
        patterns.sort(reverse=True, key=lambda value: value[0])
        index = 0
        compressed = []
        while index < len(result):
            match = None
            for length, keys, skill in patterns:
                if index + length <= len(result) and [self._step_key(step) for step in result[index:index + length]] == keys:
                    if index == 0 and length == len(result):
                        continue
                    match = (length, skill)
                    break
            if match:
                length, child = match
                compressed.append({"type": "skill", "skill_id": child["id"], "condition": child.get("precondition", {})})
                children.append(child)
                index += length
            else:
                compressed.append(result[index])
                index += 1
        level = 1 + max([child.get("level", 1) for child in children] or [0])
        return compressed, level

    def consolidate(self):
        if not self.pending:
            return 0
        existing = self.memory.top_skills(max(self.attention_limit, 128))
        created = []
        pending = self.pending
        self.pending = []
        for candidate in pending:
            compressed, level = self._compress_with_children(candidate["steps"], existing + created)
            steps, parameters = self._programize(compressed)
            capabilities = self._program_capabilities(steps, self.memory)
            success = {"type": "expected_context", "value": candidate["expected"]}
            recovery = [{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}, {"type": "observe"}]
            source = compact_json({"steps": steps, "precondition": candidate["precondition"], "success": success, "parameters": parameters, "capabilities": capabilities})
            fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
            identifier = self.memory.upsert_skill(
                fingerprint, candidate["name"], level, steps, candidate["precondition"], candidate["expected"], candidate["score"],
                parameters=parameters, success=success, recovery=recovery, program_version=2,
                capabilities=capabilities,
            )
            skill = self.memory.get_skill(identifier)
            if skill:
                created.append(skill)
        if len(created) >= 2:
            steps = [{"type": "skill", "skill_id": skill["id"], "args": {}, "condition": skill["precondition"]} for skill in created]
            level = 1 + max(skill["level"] for skill in created)
            precondition = created[0]["precondition"]
            expected = created[-1]["expected"]
            success = {"type": "expected_context", "value": expected}
            capabilities = self._program_capabilities(steps, self.memory)
            source = compact_json({"steps": steps, "precondition": precondition, "success": success, "capabilities": capabilities})
            fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
            self.memory.upsert_skill(
                fingerprint, "长技能：" + created[-1]["name"], level, steps, precondition, expected,
                sum(skill["score"] for skill in created) / len(created), parameters={}, success=success,
                recovery=[{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}], program_version=2,
                capabilities=capabilities,
            )
        self.memory.commit()
        return len(created)


class NStepAccumulator:
    def __init__(self, n_steps=N_STEP, gamma=0.94):
        self.n_steps = int(n_steps)
        self.gamma = float(gamma)
        self.items = deque()

    def _combine(self, length, terminal=False):
        selected = list(self.items)[:length]
        first = dict(selected[0])
        reward = 0.0
        goal_reward = 0.0
        curiosity_reward = 0.0
        efficiency_reward = 0.0
        safety_penalty = 0.0
        for index, item in enumerate(selected):
            discount = self.gamma ** index
            reward += discount * float(item["reward"])
            goal_reward += discount * float(item.get("goal_reward", 0.0))
            curiosity_reward += discount * float(item.get("curiosity_reward", 0.0))
            efficiency_reward += discount * float(item.get("efficiency_reward", 0.0))
            safety_penalty = max(safety_penalty, float(item.get("safety_penalty", 0.0)))
        last = selected[-1]
        first.update({
            "reward": reward, "goal_reward": goal_reward, "curiosity_reward": curiosity_reward,
            "efficiency_reward": efficiency_reward, "safety_penalty": safety_penalty,
            "next_state": last["next_state"], "next_mask": 0 if terminal else last["next_mask"],
            "next_signature": last.get("next_signature", ""), "next_state_key": last.get("next_state_key", ""), "n_steps": length,
            "priority": abs(reward) + abs(goal_reward) * 1.8 + safety_penalty * 1.5 + 0.02,
        })
        return first

    def append(self, item, terminal=False):
        self.items.append(dict(item))
        emitted = []
        if len(self.items) >= self.n_steps:
            emitted.append(self._combine(self.n_steps, terminal=terminal))
            self.items.popleft()
        if terminal:
            while self.items:
                emitted.append(self._combine(min(self.n_steps, len(self.items)), terminal=True))
                self.items.popleft()
        return emitted

    def flush(self):
        emitted = []
        while self.items:
            emitted.append(self._combine(min(self.n_steps, len(self.items)), terminal=False))
            self.items.popleft()
        return emitted


class SessionLogger:
    @staticmethod
    def _rotate(directory):
        try:
            files = sorted(directory.glob("session_*.jsonl"), key=lambda path: path.stat().st_mtime, reverse=True)
            total = sum(path.stat().st_size for path in files)
            for index, path in enumerate(files):
                if index < SESSION_LOG_KEEP and total <= SESSION_LOG_SOFT_BYTES:
                    continue
                size = path.stat().st_size
                try:
                    path.unlink()
                    total -= size
                except OSError:
                    pass
        except Exception:
            pass

    def __init__(self, data_dir):
        directory = data_dir / "logs"
        directory.mkdir(parents=True, exist_ok=True)
        self._rotate(directory)
        self.path = directory / ("session_" + time.strftime("%Y%m%d_%H%M%S") + ".jsonl")
        self.stream = open(self.path, "a", encoding="utf-8", buffering=1)
        self.lock = threading.Lock()
        self.resource_budget = ResourceBudget(data_dir)
        self._disk_checked_at = 0.0
        self._disk_writable = True

    def write(self, kind, payload):
        now = time.monotonic()
        if now - self._disk_checked_at >= 2.0:
            self.resource_budget.refresh()
            self._disk_writable = self.resource_budget.free_disk > self.resource_budget.disk_reserve_bytes + 32 * 1024 ** 2
            self._disk_checked_at = now
        if not self._disk_writable:
            return False
        record = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "kind": kind}
        record.update(payload)
        with self.lock:
            self.stream.write(compact_json(record) + "\n")

    def close(self):
        try:
            self.stream.close()
        except Exception:
            pass


class AgentRuntime:
    def __init__(self, data_dir, messages, stop_event=None, input_gate_event=None, input_gate_lock=None):
        self.data_dir = data_dir
        self.model_path = data_dir / MODEL_FILE_NAME
        self.checkpoint_dir = data_dir / "checkpoints"
        self.messages = messages
        self.context = multiprocessing.get_context("spawn")
        self.stop_event = stop_event if stop_event is not None else self.context.Event()
        self.input_gate_event = input_gate_event if input_gate_event is not None else self.context.Event()
        self.input_gate_lock = input_gate_lock if input_gate_lock is not None else self.context.Lock()
        self.input_gate = SharedInputGate(self.input_gate_event, self.input_gate_lock, self.stop_event)
        self.resource_budget = ResourceBudget(data_dir)
        self.memory = LongTermMemory(data_dir / DATABASE_FILE_NAME, resource_budget=self.resource_budget)
        self.safety = SafetyPolicy()
        self.session_domain = None
        self.approved_risk_fingerprint = ""
        self.model, model_note = self._load_model()
        self.world_model = WorldModel(self.memory)
        self.skills = SkillManager(self.memory, self.model.capacities.get("skill_attention", 128))
        self.planner = ActionPlanner(self.memory, self.model.capacities.get("planner_breadth", 48), world_model=self.world_model)
        self.planner.set_meta_report(self.memory.latest_sleep_report())
        self.last_io_metrics = {"capture_seconds": 0.0, "uia_seconds": 0.0, "cache_hits": 0, "full_scans": 0}
        self.last_sleep_decision = {"score": 0.0, "factors": {}}
        legacy_note = ""
        if (data_dir / "model.json.gz").exists() or (data_dir / "experience.json.gz").exists() or (data_dir / "skills.json.gz").exists():
            legacy_note = "检测到旧版 v3 数据，因感知/动作维度已重构而原样保留"
        self.startup_note = "；".join(value for value in (model_note, "SQLite 长期记忆已就绪", legacy_note) if value)
        self.save_model()

    def _load_model(self):
        if self.model_path.exists():
            try:
                return DoubleQNetwork.load(self.model_path), "已载入二进制模型"
            except Exception:
                self._quarantine(self.model_path)
                recovered = self._recover_checkpoint()
                if recovered is not None:
                    return recovered, "主模型校验失败，已回滚 checkpoint"
                return DoubleQNetwork(), "原模型无效，已新建"
        recovered = self._recover_checkpoint()
        if recovered is not None:
            return recovered, "已从 checkpoint 恢复模型"
        return DoubleQNetwork(), "已创建全新 Double-Q 模型"

    def _recover_checkpoint(self):
        if not self.checkpoint_dir.exists():
            return None
        for path in sorted(self.checkpoint_dir.glob("model_*.bin"), reverse=True):
            try:
                return DoubleQNetwork.load(path)
            except Exception:
                continue
        return None

    @staticmethod
    def _quarantine(path):
        try:
            os.replace(path, path.with_name(path.name + ".invalid_" + time.strftime("%Y%m%d_%H%M%S")))
        except OSError:
            pass

    def save_model(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        payload = self.model.to_bytes()
        self.resource_budget.refresh()
        needed = max(64 * 1024 ** 2, len(payload) * 2)
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + needed:
            self.resource_budget.cleanup_regenerable_storage()
            self.resource_budget.refresh()
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + needed:
            return False
        atomic_write(self.model_path, payload)
        self.memory.commit()
        return True

    def checkpoint(self):
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S") + "_" + str(self.model.training_steps)
        self.model.save(self.checkpoint_dir / ("model_" + stamp + ".bin"))
        files = sorted(self.checkpoint_dir.glob("model_*.bin"), reverse=True)
        for path in files[CHECKPOINT_KEEP:]:
            try:
                path.unlink()
            except OSError:
                pass

    def _post(self, kind, payload):
        self.messages.put((kind, payload))

    def _wait(self, duration):
        return not self.stop_event.wait(max(0.0, float(duration)))

    def _state(self, observation, goal, working):
        values = observation.features() + goal.features() + working.features()
        if len(values) != BASE_FEATURE_COUNT:
            raise ValueError("基础状态维度错误：{} != {}".format(len(values), BASE_FEATURE_COUNT))
        extra = max(0, self.model.input_count - BASE_FEATURE_COUNT)
        if extra:
            ui_count = int(extra * 0.52)
            goal_count = int(extra * 0.20)
            working_count = int(extra * 0.16)
            retrieval_count = extra - ui_count - goal_count - working_count
            values.extend(observation.adaptive_features(ui_count))
            values.extend(goal.adaptive_features(goal_count))
            values.extend(working.adaptive_features(working_count))
            values.extend(self.memory.retrieval_features(observation.signature, retrieval_count))
        values = normalize_state(values, self.model.input_count)
        return [clamp(float(value), 0.0, 1.0) for value in values]

    def _stats(self, phase, goal_label="", progress=0, total=0):
        tiers = self.memory.tier_counts()
        return {
            "phase": phase, "goal": goal_label, "hidden": self.model.hidden_count, "depth": self.model.depth, "input_count": self.model.input_count,
            "experiences": self.memory.count("episodic_memory"), "states": self.memory.count("state_memory"),
            "skills": self.memory.count("skill_memory"), "failures": self.memory.count("failure_memory"),
            "knowledge": self.memory.count("semantic_knowledge"), "world": self.memory.count("world_transition"),
            "bottleneck": str((self.planner.meta_report or {}).get("bottleneck", "none")),
            "sleep_count": self.model.sleep_count, "training_steps": self.model.training_steps,
            "target_syncs": self.model.target_syncs, "growth": self.model.accepted_growth,
            "loss": self.model.loss_average, "reward": self.model.reward_average,
            "goal_progress": self.model.progress_average, "safety": self.model.safety_average,
            "progress": progress, "total": total, "capacities": dict(self.model.capacities), "compute_backend": getattr(self.model, "compute_backend", "stdlib-array"),
            "compressed_memory": tiers["compressed"], "archived_memory": tiers["archived"],
            "resources": self.resource_budget.as_dict(), "io_metrics": dict(self.last_io_metrics),
            "sleep_score": safe_float(self.last_sleep_decision.get("score", 0.0)),
            "sleep_factors": dict(self.last_sleep_decision.get("factors") or {}),
            "storage_paused": bool(getattr(self.memory, "storage_paused", False)),
            "storage_pause_reason": str(getattr(self.memory, "storage_pause_reason", "")),
        }

    def _record_crash(self, error):
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            with open(self.data_dir / "crash.log", "a", encoding="utf-8") as stream:
                stream.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + repr(error) + "\n")
        except Exception:
            pass

    def _execute_command(self, io, command, observation, settings, interval):
        started = time.monotonic()
        outcome = {
            "ok": True, "executed": False, "blocked": False, "invalid": False, "blocked_reason": "",
            "safety_penalty": 0.0, "skill_id": None, "skill": None, "skill_success": False,
        }
        budget = {"remaining": max(
            32, int(self.model.capacities.get("skill_attention", 128)) * 4
            + int(self.model.capacities.get("planner_breadth", 48)),
        )}
        live_observation = {"value": observation}
        program_state = {"last_action": None}

        def resolve_value(value, variables):
            return SkillManager._resolve_program_value(value, variables)

        def condition_ok(condition, before_signature=""):
            if not condition:
                return True
            obs = live_observation["value"]
            if isinstance(condition, list):
                return all(condition_ok(item, before_signature) for item in condition)
            if not isinstance(condition, dict):
                return bool(condition)
            if "all" in condition:
                return all(condition_ok(item, before_signature) for item in condition.get("all", []))
            if "any" in condition:
                return any(condition_ok(item, before_signature) for item in condition.get("any", []))
            if "not" in condition:
                return not condition_ok(condition.get("not"), before_signature)
            if "focused_editable" in condition:
                focused = next((r for r in obs.accessibility.records if r.get("focused")), None)
                value = bool(focused and focused.get("control_type") in SafetyPolicy.SAFE_TEXT_TYPES and not focused.get("password"))
                return value == bool(condition.get("focused_editable"))
            if "focused_contains" in condition:
                needle = str(condition.get("focused_contains", "")).lower()
                focused = next((r for r in obs.accessibility.records if r.get("focused")), {})
                return needle in (str(focused.get("value", "")) + " " + str(focused.get("name", ""))).lower()
            if "control_exists" in condition:
                query = str(condition.get("control_exists", ""))
                return any(similarity(query, str(r.get("name", ""))) >= 0.28 for r in obs.accessibility.records)
            if "semantic_contains" in condition:
                return str(condition.get("semantic_contains", "")).lower() in obs.semantic_text.lower()
            if condition.get("structured_change"):
                return bool(before_signature and obs.semantic_signature != before_signature)
            return True

        def refresh_after_step():
            if not self._wait(min(0.16, max(0.025, interval * 0.35))):
                return False
            try:
                last = program_state.get("last_action")
                force_deep = bool(last is not None and last.parameters.get("force_deep_observation"))
                live_observation["value"] = io.capture(live_observation["value"], force_deep=force_deep)
                return True
            except Exception:
                outcome["invalid"] = True
                outcome["blocked_reason"] = "程序步骤后重新感知失败"
                return True

        def run_program_step(step, depth, seen, variables, last_action=None):
            if self.stop_event.is_set():
                return False
            if not isinstance(step, dict) or depth > 24:
                outcome["blocked"] = True; outcome["blocked_reason"] = "技能程序结构无效或层级过深"; outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.62)
                return True
            kind = str(step.get("type", "action"))
            if kind == "observe":
                try: live_observation["value"] = io.capture(live_observation["value"])
                except Exception: outcome["invalid"] = True; outcome["blocked_reason"] = "技能恢复阶段感知失败"
                return True
            if kind == "set":
                variables[str(step.get("name", "value"))] = resolve_value(step.get("value"), variables); return True
            if kind == "if":
                branch = step.get("then", []) if condition_ok(resolve_value(step.get("condition", {}), variables)) else step.get("else", [])
                for child in branch if isinstance(branch, list) else [branch]:
                    if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                    if outcome.get("blocked") or outcome.get("invalid"): return True
                return True
            if kind == "loop":
                maximum = min(8, max(0, int(step.get("max_iterations", 1))))
                for _ in range(maximum):
                    if not condition_ok(resolve_value(step.get("while", {}), variables)): break
                    for child in step.get("steps", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                        if outcome.get("blocked") or outcome.get("invalid"): return True
                return True
            if kind == "retry":
                maximum = min(3, max(1, int(step.get("max_attempts", 2))))
                for attempt in range(maximum):
                    before_sig = live_observation["value"].semantic_signature
                    for child in step.get("steps", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                        if outcome.get("blocked"): return True
                    if not refresh_after_step(): return False
                    if condition_ok(resolve_value(step.get("until", {}), variables), before_sig): return True
                    outcome["invalid"] = False; outcome["blocked_reason"] = ""
                    for child in step.get("recovery", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                outcome["invalid"] = True; outcome["blocked_reason"] = "技能程序重试后仍未满足成功条件"
                return True
            if kind == "retry_last":
                replay = program_state.get("last_action") or last_action
                if replay is not None:
                    return run(replay, depth + 1, seen)
                return True
            if kind == "skill":
                args = resolve_value(step.get("args", {}), variables)
                return run(ActionCommand(SKILL, {"skill_id": int(step.get("skill_id", 0)), "args": args}, "子程序技能"), depth + 1, seen)
            command_payload = resolve_value(step.get("command", {}), variables)
            child = ActionCommand.from_payload(command_payload)
            program_state["last_action"] = child
            if not run(child, depth + 1, seen): return False
            if outcome.get("blocked") or outcome.get("invalid"): return True
            return refresh_after_step()

        def run(current, depth, seen):
            if self.stop_event.is_set():
                return False
            if budget["remaining"] <= 0 or depth > 24:
                outcome["blocked"] = True
                outcome["blocked_reason"] = "技能达到单次运行安全预算"
                outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.62)
                return True
            if current.kind == SKILL:
                identifier = int(current.parameters.get("skill_id", 0))
                if identifier in seen:
                    outcome["blocked"] = True; outcome["blocked_reason"] = "检测到技能循环调用"; outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.75)
                    return True
                skill = self.memory.get_skill(identifier)
                if skill is None:
                    outcome["invalid"] = True; outcome["blocked_reason"] = "技能不存在"; return True
                if depth == 0:
                    outcome["skill_id"] = identifier; outcome["skill"] = skill
                if not self.skills.precondition_matches(skill, live_observation["value"]):
                    outcome["invalid"] = True; outcome["blocked_reason"] = "技能前提不满足"; return True
                local_seen = set(seen); local_seen.add(identifier)
                variables = {}
                for name, spec in dict(skill.get("parameters") or {}).items():
                    variables[name] = spec.get("default", "") if isinstance(spec, dict) else spec
                variables.update(dict(current.parameters.get("args") or {}))
                for step in skill.get("steps", []):
                    if not run_program_step(step, depth + 1, local_seen, variables):
                        return False
                    if outcome.get("blocked") or outcome.get("invalid"):
                        break
                # 技能成功条件是程序的一部分；失败时先观察并执行有限恢复，再交回规划器。
                if not outcome.get("blocked") and not outcome.get("invalid"):
                    outcome["skill_success"] = self.skills.success_matches(skill, live_observation["value"])
                if not outcome.get("skill_success") and not outcome.get("blocked"):
                    for recovery_step in skill.get("recovery", [])[:4]:
                        if not run_program_step(recovery_step, depth + 1, local_seen, variables):
                            return False
                        if outcome.get("blocked"): break
                    if not outcome.get("blocked"):
                        outcome["skill_success"] = self.skills.success_matches(skill, live_observation["value"])
                return True
            budget["remaining"] -= 1
            if current.kind == CLICK and not settings.get("clicks"):
                outcome["blocked"] = True
                outcome["blocked_reason"] = "用户已禁用鼠标点击"
                return True
            if current.kind in (KEY, TYPE) and not settings.get("keyboard"):
                outcome["blocked"] = True
                outcome["blocked_reason"] = "用户已禁用键盘输入"
                return True
            if current.kind in (CLICK, KEY, TYPE):
                planned_observation = live_observation["value"]
                planned_focus = next((control_locator(record) for record in planned_observation.accessibility.records if record.get("focused")), {})
                try:
                    fresh = io.capture(planned_observation)
                except Exception:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前二次感知失败，已取消本次输入动作"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.55)
                    return True
                if planned_observation.accessibility.hwnd and fresh.accessibility.hwnd and planned_observation.accessibility.hwnd != fresh.accessibility.hwnd:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前检测到前台窗口变化，已取消动作并重新规划"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.60)
                    live_observation["value"] = fresh
                    return True
                if planned_observation.accessibility.window_class and fresh.accessibility.window_class and planned_observation.accessibility.window_class != fresh.accessibility.window_class:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前检测到窗口类型变化，已取消动作并重新规划"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.60)
                    live_observation["value"] = fresh
                    return True
                if current.kind == CLICK:
                    locator = dict(current.parameters.get("target") or {})
                    resolved = resolve_control(fresh, locator) if locator else None
                    if not locator:
                        planned_target = control_at_point(planned_observation, current.parameters.get("x", 0.5), current.parameters.get("y", 0.5), radius=0.10)
                        fresh_target = control_at_point(fresh, current.parameters.get("x", 0.5), current.parameters.get("y", 0.5), radius=0.10)
                        if planned_target is not None and (fresh_target is None or locator_score(control_locator(planned_target), fresh_target) < 0.9):
                            outcome["invalid"] = True
                            outcome["blocked_reason"] = "执行前检测到点击目标控件变化，已取消动作并重新规划"
                            outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.58)
                            live_observation["value"] = fresh
                            return True
                    if locator and resolved is not None:
                        current.parameters["x"] = float(resolved.get("x_norm", current.parameters.get("x", 0.5)))
                        current.parameters["y"] = float(resolved.get("y_norm", current.parameters.get("y", 0.5)))
                    elif locator:
                        fallback = current.parameters.get("fallback_point")
                        if fallback and len(fallback) >= 2:
                            current.parameters["x"] = safe_float(fallback[0], 0.5)
                            current.parameters["y"] = safe_float(fallback[1], 0.5)
                        elif "x" not in current.parameters or "y" not in current.parameters:
                            outcome["invalid"] = True
                            outcome["blocked_reason"] = "技能语义控件已不存在，且没有可用兜底位置；已重新规划"
                            live_observation["value"] = fresh
                            return True
                else:
                    fresh_focus = next((record for record in fresh.accessibility.records if record.get("focused")), None)
                    if bool(planned_focus) != bool(fresh_focus) or (planned_focus and fresh_focus is not None and locator_score(planned_focus, fresh_focus) < 0.9):
                        outcome["invalid"] = True
                        outcome["blocked_reason"] = "执行前检测到键盘焦点变化，已取消动作并重新规划"
                        outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.58)
                        live_observation["value"] = fresh
                        return True
                live_observation["value"] = fresh
            approved = self.approved_risk_fingerprint or str(settings.get("approved_risk_fingerprint", ""))
            penalty, reason, blocked = self.safety.assess(
                current, live_observation["value"], bool(settings.get("safe_mode", True)),
                approved_fingerprint=approved, observe_only=bool(settings.get("observe_only", False)),
            )
            outcome["safety_penalty"] = clamp(outcome["safety_penalty"] + penalty, 0.0, 1.0)
            if blocked:
                outcome["blocked"] = True
                outcome["blocked_reason"] = reason
                if reason.startswith("需要用户确认："):
                    outcome["approval_required"] = True
                    outcome["approval_fingerprint"] = current.fingerprint()
                    outcome["approval_label"] = current.label
                return True
            if bool(settings.get("observe_only", False)) and current.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
                outcome["executed"] = True
                outcome["simulated"] = True
                outcome["planned_action"] = current.payload()
                self._post("event", "只观察模式：原本准备执行“{}”；SendInput 未调用{}".format(
                    current.label or ACTION_NAMES[current.kind], "；" + reason if reason else "",
                ))
                return True
            if current.kind == WAIT:
                outcome["executed"] = True
                return self._wait(float(current.parameters.get("duration", 0.2)))
            if current.kind == SLEEP:
                return True
            expected_hwnd = live_observation["value"].accessibility.hwnd
            try:
                result = io.execute(current, self.stop_event, expected_hwnd=expected_hwnd)
            except OSError as error:
                if "Secure Desktop" in str(error) or "输入桌面" in str(error):
                    outcome["blocked"] = True
                    outcome["desktop_blocked"] = True
                    outcome["blocked_reason"] = "输入桌面已改变：立即停止 SendInput，等待 Default Desktop 恢复"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.35)
                    return True
                raise
            if not result and current.kind == TYPE and not self.stop_event.is_set():
                outcome["invalid"] = True
                outcome["blocked_reason"] = "文本输入期间前台窗口发生变化，已立即停止继续发送字符"
                outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.78)
                return True
            outcome["executed"] = outcome["executed"] or bool(result)
            if bool(result) and approved and secrets.compare_digest(str(approved), current.fingerprint()):
                self.approved_risk_fingerprint = ""
                settings["approved_risk_fingerprint"] = ""
            return bool(result)

        outcome["ok"] = run(command, 0, set())
        outcome["duration"] = time.monotonic() - started
        return outcome

    @staticmethod
    def _decision_latency(model, items, repeats=1):
        states = [item.get("state", []) for item in (items or [])]
        if not states:
            return 0.0
        started = time.perf_counter()
        for _ in range(max(1, int(repeats))):
            for state in states:
                model.forward(state)
        return (time.perf_counter() - started) / (len(states) * max(1, int(repeats)))


    @staticmethod
    def _sleep_reward(awake_steps, stagnant, count, before_loss, after_loss, updates):
        backlog = clamp(math.log1p(count) / math.log(5000.0), 0.0, 1.0)
        stagnation_need = clamp(stagnant / 40.0, 0.0, 1.0)
        gain = 0.0
        if before_loss > 1e-9 and updates > 0:
            gain = clamp((before_loss - after_loss) / before_loss, -1.0, 1.0)
        early_penalty = max(0.0, (24 - awake_steps) / 24.0) * 0.20
        reward = backlog * 0.10 + stagnation_need * 0.16 + max(0.0, gain) * 0.48 - max(0.0, -gain) * 0.22 - early_penalty - 0.025
        return clamp(reward, -0.60, 0.65), gain

    def _sleep_and_learn(self, io, logger, goal_label, sleep_context=None, trigger="metacognitive"):
        """元认知睡眠：先诊断瓶颈，再只扩对应能力；网络结构增长最后考虑。"""
        sleep_context = dict(sleep_context or {})
        sleep_decision = dict(sleep_context.get("sleep_decision") or self.last_sleep_decision or {})
        io.release_inputs()
        self.model.sleep_count += 1
        self._post("stats", self._stats("睡眠 1/6：禁止输入并保存 checkpoint", goal_label))
        self.checkpoint()
        before_metrics = {
            "loss": float(self.model.loss_average), "reward": float(self.model.reward_average),
            "progress": float(self.model.progress_average), "safety": float(self.model.safety_average),
            "hidden": int(self.model.hidden_count), "depth": int(self.model.depth), "input": int(self.model.input_count),
            "sleep_score": safe_float(sleep_decision.get("score", 0.0)), "sleep_factors": dict(sleep_decision.get("factors") or {}),
        }
        self._post("stats", self._stats("睡眠 2/6：记忆压缩、知识沉淀、技能程序化与瓶颈诊断", goal_label))
        self.resource_budget.refresh(
            decision_latency=safe_float(sleep_context.get("decision_latency", 0.0)),
            perception_latency=safe_float(sleep_context.get("perception_latency", io.last_capture_seconds)),
        )
        new_skills = self.skills.consolidate()
        summary = self.memory.consolidate(self.resource_budget)
        count = summary["experiences"]
        bottleneck, bottleneck_reason = BottleneckAnalyzer.classify(sleep_context, self.model, self.memory)
        capacity_growth = self.model.grow_capabilities(count, summary["skills"], bottleneck=bottleneck, resource_budget=self.resource_budget)
        findings = [
            bottleneck_reason,
            "睡眠分数 {:.3f}；主要因素 {}".format(safe_float(sleep_decision.get("score", 0.0)), ",".join(sleep_decision.get("reasons", [])) or "综合负荷"),
            "热知识 {}，压缩记忆 {}，归档记忆 {}，世界模型 {}，技能 {}，恢复策略 {}".format(
                summary.get("knowledge", 0), summary.get("compressed", 0), summary.get("archived", 0),
                summary.get("world", 0), summary.get("skills", 0), summary.get("strategies", 0),
            ),
        ]
        if new_skills:
            findings.append("本次压缩出 {} 个新的参数化程序技能".format(new_skills))
        training = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=False), partition="train") if count else []
        evaluation = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=True), partition="eval") if count else []
        before_loss = self.model.validation_loss(evaluation) if len(evaluation) >= 8 else 0.0
        before_benchmark = self.model.benchmark(evaluation) if len(evaluation) >= 8 else {"score": 0.5}
        training_accepted = True
        grew = False
        growth_kind = "未触发"
        losses = []
        baseline_latency = self._decision_latency(self.model, evaluation, repeats=1) if evaluation else 0.0
        before_training_snapshot = self.model.snapshot()

        # 只有明确诊断为模型容量不足时，才允许增加输入槽；知识/技能/规划不足不再用神经元掩盖。
        input_growth_attempted = False
        if bottleneck == "model_capacity" and len(evaluation) >= 8:
            current_extra = max(0, self.model.input_count - BASE_FEATURE_COUNT)
            evidence_pressure = math.log1p(count) + math.log1p(summary["skills"]) * 1.4
            target_extra = current_extra + int(self.resource_budget.growth_amount("adaptive_input", current_extra or 1) * max(1.0, evidence_pressure / 8.0))
            if target_extra > current_extra:
                amount = target_extra - current_extra
                snapshot = self.model.snapshot()
                self.model.grow_input(amount, sync=False)
                latency = self._decision_latency(self.model, evaluation, repeats=1)
                if baseline_latency > 0 and latency > baseline_latency * 1.12:
                    self.model.restore(snapshot)
                    capacity_growth.append("自适应输入回滚：延迟预算")
                else:
                    input_growth_attempted = True
                    capacity_growth.append("自适应输入+{}（待永久 eval 验证）".format(amount))

        if len(training) >= 8 and len(evaluation) >= 8:
            self._post("stats", self._stats("睡眠 3/6：永久 train 分区离线训练", goal_label, 0, 1))
            updates = self.resource_budget.training_updates(count)
            priority_updates = []
            for number in range(updates):
                if self.stop_event.is_set() or io.escape_down():
                    io.close_input_gate(); break
                item = random.choice(training)
                loss = self.model.train_one(item, allow_target_sync=False)
                losses.append(loss)
                priority_updates.append((item["id"], loss + abs(item.get("goal_reward", 0.0)) * 1.4 + item.get("safety_penalty", 0.0) + 0.01))
                if len(priority_updates) >= 32:
                    self.memory.update_priorities(priority_updates); priority_updates = []
                if number % 20 == 0:
                    self._post("stats", self._stats("睡眠 3/6：永久 train 分区离线训练", goal_label, number + 1, updates)); time.sleep(0)
            if priority_updates:
                self.memory.update_priorities(priority_updates)
            self._post("stats", self._stats("睡眠 4/6：永久 eval、延迟与回归验证", goal_label))
            after_loss = self.model.validation_loss(evaluation)
            after_benchmark = self.model.benchmark(evaluation)
            after_latency = self._decision_latency(self.model, evaluation, repeats=1)
            input_ok = (not input_growth_attempted) or (after_benchmark["score"] >= before_benchmark["score"] + 0.001 and (baseline_latency <= 0 or after_latency <= baseline_latency * 1.12))
            training_accepted = after_benchmark["score"] >= before_benchmark["score"] - 0.015 and (before_loss <= 1e-9 or after_loss <= before_loss * 1.08) and input_ok
            if not training_accepted:
                self.model.restore(before_training_snapshot)
                after_loss = before_loss; after_benchmark = before_benchmark
                findings.append("训练回滚：永久 eval 或延迟预算未通过")
        else:
            after_loss = before_loss; after_benchmark = before_benchmark
            findings.append("永久 train/eval 样本不足：只整理知识/技能，不训练或扩神经网络")

        # 模型增宽/加深是最后一级机制，并且必须是 model_capacity 瓶颈 + 数据充分 + 永久 eval/延迟验证通过。
        plateau = before_loss > 1e-9 and after_loss >= before_loss * 0.985
        capability_pressure = self.model.progress_average < 0.04 or self.model.safety_average > 0.16 or float(after_benchmark.get("score", 0.5)) < 0.72
        evidence_floor = max(32, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("episodic_memory", 1))) * 4.0))
        if bottleneck == "model_capacity" and len(training) >= 32 and len(evaluation) >= 8 and count >= max(evidence_floor, self.model.hidden_count * 10) and (plateau or capability_pressure) and not self.stop_event.is_set():
            snapshot = self.model.snapshot()
            baseline_growth_loss = after_loss
            baseline_growth_benchmark = after_benchmark
            baseline_growth_latency = self._decision_latency(self.model, evaluation, repeats=1)
            if self.model.sleep_count % 5 == 0:
                depth_extra = self.resource_budget.growth_amount("adaptive_input", self.model.layer_sizes[-1])
                self.model.grow_depth(self.model.layer_sizes[-1] + depth_extra, sync=False); growth_kind = "深度"
            else:
                layer_index = min(range(len(self.model.layer_sizes)), key=lambda index: self.model.layer_sizes[index])
                width_growth = self.resource_budget.growth_amount("adaptive_input", self.model.layer_sizes[layer_index])
                self.model.grow_width(layer_index, width_growth, sync=False); growth_kind = "宽度"
            for _ in range(max(len(training), self.resource_budget.training_updates(count) // 3)):
                if self.stop_event.is_set(): break
                self.model.train_one(random.choice(training), learning_rate=0.00072, allow_target_sync=False)
            grown_loss = self.model.validation_loss(evaluation)
            grown_benchmark = self.model.benchmark(evaluation)
            grown_latency = self._decision_latency(self.model, evaluation, repeats=1)
            gain = grown_benchmark["score"] - baseline_growth_benchmark["score"]
            latency_ratio = grown_latency / max(1e-9, baseline_growth_latency) if baseline_growth_latency > 0 else 1.0
            if ((gain >= 0.001) or (gain > 0 and grown_loss <= baseline_growth_loss * 0.985)) and (latency_ratio <= 1.22 or (gain >= 0.015 and latency_ratio <= 1.50)):
                self.model.accepted_growth += 1; grew = True; after_loss = grown_loss; after_benchmark = grown_benchmark
                capacity_growth.append("神经网络{}扩张通过永久 eval/延迟验证".format(growth_kind))
            else:
                self.model.restore(snapshot); self.model.rejected_growth += 1; findings.append("神经网络结构扩张回滚：收益/延迟未达标"); growth_kind = "回滚"

        self._post("stats", self._stats("睡眠 5/6：生成 SleepReport 并更新下一轮策略", goal_label))
        self.model.sync_target()
        io.set_capacities(self.model.capacities)
        self.planner.set_breadth(self.model.capacities["planner_breadth"])
        self.skills.set_attention_limit(self.model.capacities["skill_attention"])
        improvements, regressions = [], []
        before_score = float(before_benchmark.get("score", 0.5)); after_score = float(after_benchmark.get("score", 0.5))
        if after_score > before_score + 0.001: improvements.append("永久 eval 基准 {:.3f}→{:.3f}".format(before_score, after_score))
        if before_loss > 0 and after_loss < before_loss * 0.99: improvements.append("验证误差 {:.4f}→{:.4f}".format(before_loss, after_loss))
        if after_score < before_score - 0.001: regressions.append("永久 eval 基准下降 {:.3f}→{:.3f}".format(before_score, after_score))
        if before_loss > 0 and after_loss > before_loss * 1.01: regressions.append("验证误差上升 {:.4f}→{:.4f}".format(before_loss, after_loss))
        after_metrics = {
            "loss": float(after_loss), "benchmark": after_score, "hidden": int(self.model.hidden_count), "depth": int(self.model.depth),
            "input": int(self.model.input_count), "knowledge": int(summary.get("knowledge", 0)), "world": int(summary.get("world", 0)), "skills": int(summary.get("skills", 0)),
        }
        wake_decision = MetaCognitiveSleep.after_sleep(sleep_decision, before_loss, after_loss, training_accepted)
        continuation_cycles = 0
        while not wake_decision.get("wake_ready") and not self.stop_event.is_set():
            continuation_cycles += 1
            self._post("stats", self._stats("睡眠继续：分数尚未降到醒来阈值，继续整理记忆冲突", goal_label))
            self.memory.consolidate(self.resource_budget)
            wake_decision = MetaCognitiveSleep.after_sleep(
                {"factors": wake_decision.get("factors", {})}, max(after_loss, 1e-9), max(after_loss, 1e-9), True,
            )
        after_metrics["wake_score"] = safe_float(wake_decision.get("score", 0.0))
        after_metrics["wake_threshold"] = SLEEP_WAKE_THRESHOLD
        after_metrics["wake_factors"] = dict(wake_decision.get("factors") or {})
        after_metrics["continuation_cycles"] = continuation_cycles
        trigger = str(trigger or "metacognitive")
        trigger_reason = str(sleep_context.get("reason", "元认知负荷触发睡眠"))
        reason_text = (
            "sleep_score={:.3f}>={:.3f}；{}".format(safe_float(sleep_decision.get("score", 0.0)), SLEEP_ENTER_THRESHOLD, trigger_reason)
            if trigger == "metacognitive" else "{}；{}".format(trigger, trigger_reason)
        )
        report = {
            "trigger": trigger, "reason": reason_text, "findings": findings,
            "improvements": improvements, "regressions": regressions, "repeated_errors": self.memory.recent_failure_patterns(8),
            "bottleneck": bottleneck, "structural_growth": list(capacity_growth), "before_metrics": before_metrics, "after_metrics": after_metrics,
        }
        report = self.memory.remember_sleep_report(report)
        self.planner.set_meta_report(report)
        self._post("stats", self._stats("睡眠 6/6：原子保存模型、索引与 SleepReport", goal_label))
        self.save_model(); self.checkpoint()
        logger.write("sleep", {
            "updates": len(losses), "new_skills": new_skills, "before_loss": before_loss, "after_loss": after_loss,
            "before_benchmark": before_score, "after_benchmark": after_score, "training_accepted": training_accepted,
            "grew": grew, "growth_kind": growth_kind, "capacity_growth": capacity_growth, "bottleneck": bottleneck,
            "sleep_report": report, "memory": summary,
            "sleep_decision": sleep_decision, "wake_decision": wake_decision,
        })
        return {"updates": len(losses), "new_skills": new_skills, "before_loss": before_loss, "after_loss": after_loss,
                "before_benchmark": before_score, "after_benchmark": after_score, "training_accepted": training_accepted,
                "grew": grew, "capacity_growth": capacity_growth, "summary": summary, "sleep_report": report, "bottleneck": bottleneck,
                "sleep_decision": sleep_decision, "wake_decision": wake_decision}

    def _remember_emitted(self, emitted):
        for item in emitted:
            self.memory.add_experience(item)
            self.world_model.observe(item)

    def _wait_for_default_desktop(self, io, announce=True):
        announced = False
        while not self.stop_event.is_set():
            safe, name = io.input_desktop_status(force=True)
            if safe:
                if announced and announce:
                    self._post("event", "Default Desktop 已恢复；重新感知后才允许输入")
                return True
            if announce and not announced:
                self._post("event", "检测到 Secure/未知 Input Desktop（{}）：fail-closed，所有 SendInput 已禁止".format(name))
                announced = True
            if not self._wait(0.12):
                return False
        return False

    def _validate_initial_context(self, io, observation, locked):
        locked = dict(locked or {})
        expected_hwnd = int(locked.get("hwnd", 0) or 0)
        if not expected_hwnd:
            return observation, True, "没有可锁定的外部前台窗口，采用启动后的稳定窗口"
        current_hwnd = int(observation.accessibility.hwnd or 0)
        if current_hwnd == expected_hwnd:
            return observation, True, "初始工作上下文 HWND 已验证"
        expected_pid = int(locked.get("process_id", 0) or 0)
        if expected_pid and int(getattr(observation, "process_id", 0) or 0) == expected_pid:
            return observation, True, "初始工作上下文进程已验证（HWND 发生合法重建）"
        self._post("event", "隐藏主界面后前台窗口异常变化：先 WAIT 并重新确认，暂不发送任何输入")
        last = observation
        stable_hwnd = current_hwnd; stable_count = 1
        for _ in range(8):
            if not self._wait(0.12) or not self._wait_for_default_desktop(io, announce=False):
                return last, False, "停止请求"
            try:
                last = io.capture(last)
            except Exception:
                continue
            hwnd = int(last.accessibility.hwnd or 0)
            if hwnd == expected_hwnd or (expected_pid and int(getattr(last, "process_id", 0) or 0) == expected_pid):
                return last, True, "等待后恢复到锁定的初始工作上下文"
            if hwnd and hwnd == stable_hwnd:
                stable_count += 1
            else:
                stable_hwnd, stable_count = hwnd, 1
        # 原 HWND 仍存在却未回前台时不能猜测另一个窗口就是用户目标。
        try:
            original_exists = bool(io.user32.IsWindow(expected_hwnd))
        except Exception:
            original_exists = True
        if original_exists:
            return last, False, "初始目标窗口仍存在但未处于前台；为避免误操作已 fail-closed 停止"
        if stable_hwnd and stable_count >= 3:
            return last, True, "原目标窗口已消失；已将连续稳定的新前台窗口重新确认为工作上下文"
        return last, False, "无法重新确认稳定工作上下文"

    def _run(self, settings):
        reason = "已停止"
        logger = None
        io = None
        accumulator = NStepAccumulator()
        try:
            logger = SessionLogger(self.data_dir)
            observe_only = bool(settings.get("observe_only", False))
            io = WinIO(self.model.capacities, input_enabled=not observe_only, input_gate_event=self.input_gate_event, input_gate_lock=self.input_gate_lock, stop_event=self.stop_event, resource_budget=self.resource_budget)
            io.wait_escape_release(self.stop_event)
            if not self._wait_for_default_desktop(io):
                reason = "停止请求"
                raise InterruptedError(reason)
            interval = float(settings.get("interval", 0.32))
            self.approved_risk_fingerprint = str(settings.get("approved_risk_fingerprint", ""))
            working = WorkingMemory(self.model.capacities.get("memory_horizon", 16))
            reward_engine = RewardEngine()
            goal = GoalEngine(settings.get("goal", ""), settings.get("success_text", ""))
            observation = io.capture()
            observation, context_ok, context_note = self._validate_initial_context(io, observation, settings.get("initial_context", {}))
            self._post("event", context_note)
            if not context_ok:
                reason = context_note
                raise InterruptedError(reason)
            self.session_domain = SessionCapabilityDomain(self.memory, observation, settings.get("goal", ""))
            self.safety.set_session_domain(self.session_domain)
            self.memory.remember_observation_knowledge(observation)
            if bool(settings.get("allow_network_knowledge")) and settings.get("knowledge_urls"):
                self._post("event", "正在读取用户明确允许的网页/文档；不调用任何外部 AI 模型")
                fetched = ExternalKnowledgeFetcher(self.resource_budget, self.stop_event).fetch_all(settings.get("knowledge_urls", []), self.memory)
                succeeded = sum(1 for item in fetched if item.get("ok"))
                self._post("event", "网络知识层：成功读取 {}/{} 个用户允许的来源".format(succeeded, len(fetched)))
            goal.attach_knowledge(self.memory.semantic_context(" ".join((goal.requested_goal, goal.success_text)), limit=max(2, int(math.sqrt(self.model.capacities.get("memory_horizon", 16))))))
            goal_label = goal.begin(observation)
            self.skills.begin_goal(observation, goal_label)
            state = self._state(observation, goal, working)
            perception_history = deque()
            uncertainty_history = deque()
            recovery_trace = []
            awake_steps = 0
            stagnant = 0
            repeated = 0
            last_fingerprint = ""
            self._post("event", "当前目标：" + goal_label)
            self._post("stats", self._stats("清醒：选择参数化动作", goal_label))
            logger.write("start", {
                "clicks": bool(settings.get("clicks")), "keyboard": bool(settings.get("keyboard")),
                "safe_mode": bool(settings.get("safe_mode", True)), "observe_only": observe_only,
                "allow_network_knowledge": bool(settings.get("allow_network_knowledge")), "interval": interval,
                "feature_count": self.model.input_count, "base_feature_count": BASE_FEATURE_COUNT, "action_categories": ACTION_COUNT,
                "goal": goal_label, "explicit_goal": goal.explicit,
            })
            while not self.stop_event.is_set():
                if io.escape_down():
                    io.close_input_gate()
                    reason = "检测到 ESC，AI 已停止"
                    break
                if not self._wait_for_default_desktop(io):
                    reason = "检测到停止请求"; break
                if not bool(getattr(observation, "input_desktop_safe", True)):
                    observation = io.capture(observation); state = self._state(observation, goal, working)
                eligible_skills = self.skills.eligible(observation, settings)
                text_candidates = self.planner.text_candidates(goal, observation)
                allowed = self.planner.allowed(settings, awake_steps, text_candidates, eligible_skills)
                world_uncertainty = self.planner.state_uncertainty(state, observation, allowed)
                uncertainty_history.append(world_uncertainty)
                perception_history.append(1.0 if getattr(observation, "perception_limited", False) else 0.0)
                signal_horizon = max(8, int(self.model.capacities.get("memory_horizon", 16)) * 4)
                while len(uncertainty_history) > signal_horizon: uncertainty_history.popleft()
                while len(perception_history) > signal_horizon: perception_history.popleft()
                sleep_decision = MetaCognitiveSleep.evaluate(
                    self.model, self.memory, working, world_uncertainty, eligible_skills, repeated=repeated,
                    compiler_stalled=bool(getattr(goal, "compiler_stalled", False)), pending_skill=bool(self.skills.pending),
                )
                self.last_sleep_decision = sleep_decision
                allowed = self.planner.allowed(settings, awake_steps, text_candidates, eligible_skills, allow_sleep=bool(sleep_decision.get("should_sleep")))
                current_mask = mask_actions(allowed)
                exploration = clamp(0.30 / math.sqrt(1.0 + self.model.training_steps / 3500.0), 0.04, 0.30)
                if self.model.progress_average < 0.03:
                    exploration = min(0.36, exploration + 0.05)
                # 统一成不确定性驱动探索：越不确定越观察，而不是越随机。
                exploration *= clamp(1.0 - world_uncertainty * 0.92, 0.05, 1.0)
                if getattr(observation, "perception_limited", False):
                    # UIA 贫乏时把问题标记为感知瓶颈，不用随机点击把错误经验写成策略失败。
                    exploration = min(exploration, 0.015)
                    if CLICK in allowed and not any(record.get("control_type") in INTERACTIVE_CONTROL_TYPES and record.get("enabled") and not record.get("offscreen") for record in observation.accessibility.records):
                        allowed = [kind for kind in allowed if kind != CLICK]
                        current_mask = mask_actions(allowed)
                    if awake_steps % 12 == 0:
                        self._post("event", "感知边界：当前 UIA 信息贫乏，已降低探索点击；这会被记为感知不足而不是策略错误")
                # 睡眠是确定性的元认知滞回决策，不再含随机触发。
                force_sleep = SLEEP in allowed and bool(sleep_decision.get("should_sleep"))
                decision_started = time.perf_counter()
                if force_sleep:
                    command = self.planner.plan(SLEEP, [], observation, goal, text_candidates, eligible_skills, False)
                else:
                    command = self.planner.plan_with_lookahead(
                        self.model, state, allowed, observation, goal, text_candidates, eligible_skills, random.random() < exploration, settings=settings
                    )
                decision_elapsed = time.perf_counter() - decision_started
                self.resource_budget.decision_latency = decision_elapsed
                self.resource_budget.perception_latency = io.last_capture_seconds
                self.last_io_metrics = {
                    "capture_seconds": io.last_capture_seconds, "uia_seconds": io.last_uia_seconds,
                    "cache_hits": io.capture_cache_hits, "full_scans": io.capture_full_scans,
                }
                fingerprint = command.fingerprint()
                repeated = repeated + 1 if fingerprint == last_fingerprint else 0
                last_fingerprint = fingerprint

                if command.kind == SLEEP:
                    self._remember_emitted(accumulator.flush())
                    pre_state = state
                    pre_signature = observation.signature
                    sleep_context = {
                        "reason": "元认知因素：" + ",".join(sleep_decision.get("reasons", [])), "stagnant": stagnant, "repeated": repeated,
                        "perception_limited_ratio": sum(perception_history) / max(1, len(perception_history)),
                        "world_uncertainty": sum(uncertainty_history) / max(1, len(uncertainty_history)),
                        "compiler_unresolved": bool(goal.explicit and not goal.compiled_steps),
                        "sleep_decision": sleep_decision, "decision_latency": decision_elapsed,
                        "perception_latency": io.last_capture_seconds,
                    }
                    result = self._sleep_and_learn(io, logger, goal_label, sleep_context=sleep_context, trigger="metacognitive")
                    if self.stop_event.is_set():
                        reason = "检测到 ESC，AI 已停止"
                        break
                    sleep_reward, learning_gain = self._sleep_reward(
                        awake_steps, stagnant, result["summary"]["experiences"], result["before_loss"], result["after_loss"], result["updates"]
                    )
                    next_observation = io.capture(observation)
                    goal_label = goal.after_sleep(next_observation)
                    if not goal.explicit and goal.generation > 1:
                        self.skills.begin_goal(next_observation, goal_label)
                    components = {
                        "goal_reward": 0.0, "curiosity_reward": 0.0, "efficiency_reward": sleep_reward,
                        "safety_penalty": 0.0, "goal_progress": max(0.0, sleep_reward), "goal_completed": False, "effect": 0.0,
                    }
                    working.update(SLEEP, sleep_reward, components, next_observation.signature, slept=True)
                    working.set_horizon(self.model.capacities.get("memory_horizon", working.horizon))
                    next_state = self._state(next_observation, goal, working)
                    next_skills = self.skills.eligible(next_observation, settings)
                    next_text = self.planner.text_candidates(goal, next_observation)
                    next_allowed = self.planner.allowed(settings, 0, next_text, next_skills)
                    sleep_item = {
                        "state": pre_state, "action": SLEEP, "command": command.payload(),
                        "parameters": command.parameter_targets, "parameter_mask": command.parameter_mask,
                        "reward": sleep_reward, "goal_reward": 0.0, "curiosity_reward": 0.0,
                        "efficiency_reward": sleep_reward, "safety_penalty": 0.0,
                        "next_state": next_state, "current_mask": current_mask, "next_mask": mask_actions(next_allowed), "priority": abs(sleep_reward) + abs(learning_gain) + 0.03,
                        "signature": pre_signature, "next_signature": next_observation.signature, "state_key": getattr(observation, "fuzzy_key", ""),
                        "next_state_key": getattr(next_observation, "fuzzy_key", ""), "n_steps": 1, "goal_text": goal_label,
                    }
                    self.memory.add_experience(sleep_item)
                    self.world_model.observe(sleep_item)
                    self.model.reward_average = self.model.reward_average * 0.985 + sleep_reward * 0.015
                    capability_text = "，" + "/".join(result.get("capacity_growth", [])) + "已扩展" if result.get("capacity_growth") else ""
                    self._post("event", "AI 睡醒：训练 {} 次{}，新增技能 {} 个，能力收益 {:+.3f}，基准 {:.3f}→{:.3f}{}{}".format(
                        result["updates"], "（能力测试未通过，已回滚）" if not result.get("training_accepted", True) else "",
                        result["new_skills"], learning_gain, result.get("before_benchmark", 0.5), result.get("after_benchmark", 0.5),
                        "，模型扩容已通过" if result["grew"] else "", capability_text
                    ))
                    logger.write("sleep_choice", {"reward": sleep_reward, "gain": learning_gain, "awake_steps": awake_steps, "stagnant": stagnant,
                                                        "sleep_score": sleep_decision.get("score"), "factors": sleep_decision.get("factors"),
                                                        "wake_score": result.get("wake_decision", {}).get("score")})
                    observation, state = next_observation, next_state
                    awake_steps = stagnant = repeated = 0
                    self._post("stats", self._stats("已醒来：继续参数化行动", goal_label))
                    continue

                pre_state = state
                pre_signature = observation.signature
                compiled_before_index = int(getattr(goal, "compiled_index", 0))
                compiled_before_phase = str(getattr(goal, "compiled_phase", ""))
                compiled_before_step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else None
                if compiled_before_phase == "recovery" and command.kind not in (WAIT, SLEEP):
                    recovery_trace.append(command.payload())
                    recovery_trace[:] = recovery_trace[-8:]
                outcome = self._execute_command(io, command, observation, settings, interval)
                outcome["perception_limited"] = bool(getattr(observation, "perception_limited", False))
                if not outcome.get("ok"):
                    reason = "检测到 ESC，AI 已停止" if self.stop_event.is_set() else "动作执行中止"
                    break
                if outcome.get("approval_required"):
                    self._post("approval_required", {"fingerprint": outcome.get("approval_fingerprint", ""), "label": outcome.get("approval_label", command.label), "reason": outcome.get("blocked_reason", "")})
                    reason = "高风险动作等待用户确认"
                    break
                if outcome.get("desktop_blocked"):
                    if not self._wait_for_default_desktop(io):
                        reason = "检测到停止请求"; break
                    observation = io.capture(observation); state = self._state(observation, goal, working)
                    self._post("event", "安全桌面恢复后已重新感知；原动作不会自动重放")
                    continue
                if command.kind != WAIT and not self._wait(interval):
                    reason = "检测到 ESC，AI 已停止"
                    break
                if not self._wait_for_default_desktop(io):
                    reason = "检测到停止请求"; break
                next_observation = io.capture(observation, force_deep=bool(command.parameters.get("force_deep_observation")))
                if command.kind == SKILL and outcome.get("skill"):
                    skill_success = bool(outcome.get("skill_success")) or self.skills.success_matches(outcome["skill"], next_observation)
                    outcome["skill_success"] = skill_success
                    self.memory.record_skill_result(outcome["skill_id"], skill_success, outcome.get("duration", 0.0))
                goal_result = goal.evaluate(command, observation, next_observation, outcome)
                if compiled_before_step is not None and int(getattr(goal, "compiled_index", 0)) > compiled_before_index and recovery_trace:
                    operation = str(compiled_before_step.get("operation") or compiled_before_step.get("action", "unknown"))
                    app_key = str(getattr(next_observation, "process_name", "") or getattr(observation, "process_name", "") or "unknown")
                    precondition = {"window_class": observation.accessibility.window_class, "process_name": getattr(observation, "process_name", ""), "operation": operation}
                    self.memory.remember_strategy(operation, app_key, precondition, list(recovery_trace), subgoals=compiled_before_step.get("recovery", []))
                    recovery_trace.clear()
                if goal_result.get("candidate") and not self.stop_event.is_set():
                    candidate_observation = next_observation
                    verification = next_observation
                    stable = False
                    for delay in (0.18, 0.22, 0.28):
                        if not self._wait(delay):
                            break
                        verification = io.capture(verification)
                        stable = goal.verify_stable(candidate_observation, verification)
                        if not stable and goal.completion_evidence == 0:
                            break
                    next_observation = verification
                    if stable:
                        goal_result["completed"] = True
                        goal_result["reward"] = 1.0
                        goal_result["progress"] = 1.0
                    else:
                        goal_result["reward"] = min(float(goal_result.get("reward", 0.0)), 0.18)
                        goal_result["progress"] = min(float(goal_result.get("progress", 0.0)), 0.18)
                visits_before = self.memory.state_visits(next_observation.signature)
                reward, components = reward_engine.evaluate(
                    command, observation, next_observation, repeated, stagnant, goal_result,
                    visits_before, outcome, outcome.get("duration", 0.0),
                )
                self.model.reward_average = reward if self.model.training_steps == 0 and self.memory.count("episodic_memory") == 0 else self.model.reward_average * 0.985 + reward * 0.015
                self.model.progress_average = self.model.progress_average * 0.985 + components["goal_progress"] * 0.015
                self.model.safety_average = self.model.safety_average * 0.985 + components["safety_penalty"] * 0.015
                working.update(command.kind, reward, components, next_observation.signature)
                next_state = self._state(next_observation, goal, working)
                awake_steps += 1
                if components["goal_progress"] > 0.08:
                    stagnant = max(0, stagnant - 6)
                elif not components["structured_change"] and components["effect"] < 0.005:
                    stagnant += 1
                else:
                    stagnant = max(0, stagnant - 1)

                if command.kind == TYPE:
                    self.memory.remember_text(command.parameters.get("text", ""), components["goal_progress"] > 0.05 or components["structured_change"])
                self.skills.observe(command, outcome, components, next_observation, outcome.get("duration", 0.0))
                next_skills = self.skills.eligible(next_observation, settings)
                next_text = self.planner.text_candidates(goal, next_observation)
                next_allowed = self.planner.allowed(settings, awake_steps, next_text, next_skills)
                transition = {
                    "state": pre_state, "action": command.kind, "command": command.payload(),
                    "parameters": command.parameter_targets, "parameter_mask": command.parameter_mask,
                    "reward": reward, "goal_reward": components["goal_reward"],
                    "curiosity_reward": components["curiosity_reward"], "efficiency_reward": components["efficiency_reward"],
                    "safety_penalty": components["safety_penalty"], "next_state": next_state,
                    "current_mask": current_mask, "next_mask": mask_actions(next_allowed), "signature": pre_signature,
                    "next_signature": next_observation.signature, "state_key": getattr(observation, "fuzzy_key", ""),
                    "next_state_key": getattr(next_observation, "fuzzy_key", ""), "goal_text": goal_label,
                }
                self._remember_emitted(accumulator.append(transition, terminal=bool(goal.explicit and components["goal_completed"])))
                self.memory.remember_state(
                    next_observation.signature, next_observation.visual_signature, next_state, reward,
                    success=components["goal_completed"], failure=bool((outcome.get("blocked") or outcome.get("invalid") or reward < -0.35) and not outcome.get("perception_limited")),
                )
                if outcome.get("blocked_reason"):
                    self.memory.remember_failure(command, pre_signature, outcome["blocked_reason"], outcome.get("safety_penalty", 0.5))
                    prefix = "安全策略：" if outcome.get("blocked") else "动作未执行："
                    self._post("event", prefix + outcome["blocked_reason"])
                logger.write("step", {
                    "action": ACTION_NAMES[command.kind], "label": command.label, "reward": round(reward, 5),
                    "goal_reward": round(components["goal_reward"], 5), "curiosity_reward": round(components["curiosity_reward"], 5),
                    "efficiency_reward": round(components["efficiency_reward"], 5), "safety_penalty": round(components["safety_penalty"], 5),
                    "structured_change": components["structured_change"], "effect": round(components["effect"], 5), "stagnant": stagnant,
                })
                observation, state = next_observation, next_state
                if awake_steps % 5 == 0:
                    self.memory.remember_observation_knowledge(observation)

                if components["goal_completed"]:
                    self._post("event", "目标已验证完成：" + goal_label)
                    if goal.explicit:
                        self._post("stats", self._stats("目标完成：禁止输入并整理能力", goal_label))
                        self._sleep_and_learn(io, logger, goal_label, sleep_context={
                            "reason": "目标完成后的反思整理", "stagnant": stagnant, "repeated": repeated,
                            "perception_limited_ratio": sum(perception_history) / max(1, len(perception_history)),
                            "world_uncertainty": sum(uncertainty_history) / max(1, len(uncertainty_history)),
                            "compiler_unresolved": False,
                        }, trigger="goal_completed")
                        reason = "目标已完成并完成睡眠整理"
                        break
                if awake_steps % 5 == 0:
                    self._post("stats", self._stats("清醒：选择参数化动作", goal_label))
                if awake_steps % 24 == 0:
                    self.save_model()

            self._remember_emitted(accumulator.flush())
            try:
                self.skills.consolidate()
                self.memory.consolidate()
                self.save_model()
            except Exception as save_error:
                reason += "；保存失败：" + str(save_error)
        except InterruptedError as error:
            reason = str(error) or reason
            try:
                self._remember_emitted(accumulator.flush())
                self.save_model()
            except Exception:
                pass
        except Exception as error:
            reason = "运行错误：" + str(error)
            self._record_crash(error)
            try:
                self._remember_emitted(accumulator.flush())
                self.save_model()
            except Exception:
                pass
        finally:
            if io is not None:
                try:
                    io.release_inputs()
                    io.close()
                except Exception:
                    pass
            if logger is not None:
                logger.write("stop", {"reason": reason})
                logger.close()
        self._post("stopped", reason)


def agent_worker_process(data_dir, settings, stop_event, messages, input_gate_event, input_gate_lock):
    runtime = None
    try:
        runtime = AgentRuntime(Path(data_dir), messages, stop_event, input_gate_event=input_gate_event, input_gate_lock=input_gate_lock)
        runtime._run(dict(settings))
    except Exception as error:
        try:
            messages.put(("stopped", "运行错误：" + str(error)))
        except Exception:
            pass
    finally:
        if runtime is not None:
            try:
                runtime.memory.close()
            except Exception:
                pass


class StartupSelfTest:
    """启动按钮启用前的本地端到端检查；不进行任何实际输入。"""

    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)

    @staticmethod
    def _item(name, ok, detail="", critical=True):
        return {"name": str(name), "ok": bool(ok), "detail": str(detail), "critical": bool(critical)}

    def run(self):
        results = [self._item("Windows 11 x64", is_windows_11_x64(), "需要 Windows 11 x64")]
        token = uuid.uuid4().hex
        probe = self.data_dir / ("self_test_" + token + ".tmp")
        database = self.data_dir / ("self_test_" + token + ".sqlite3")
        model_path = self.data_dir / ("self_test_" + token + ".bin")
        try:
            with open(probe, "wb") as stream:
                stream.write(b"local-ai-self-test"); stream.flush(); os.fsync(stream.fileno())
            results.append(self._item("数据目录写入", probe.read_bytes() == b"local-ai-self-test", str(self.data_dir)))
        except Exception as error:
            results.append(self._item("数据目录写入", False, error))
        try:
            test_memory = LongTermMemory(database, resource_budget=ResourceBudget(self.data_dir))
            try:
                test_memory.connection.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('self_test','ok')")
                test_memory.commit()
                ok = test_memory.connection.execute("SELECT value FROM metadata WHERE key='self_test'").fetchone()[0] == "ok"
            finally:
                test_memory.close()
            results.append(self._item("SQLite 写入", ok, "schema v{}".format(SCHEMA_VERSION)))
            with sqlite3.connect(str(database)) as check_connection:
                wal_ok = check_connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            results.append(self._item("SQLite WAL 恢复/完整性", wal_ok, "integrity_check=ok"))
        except Exception as error:
            results.append(self._item("SQLite 写入", False, error))
            results.append(self._item("SQLite WAL 恢复/完整性", False, error))
        try:
            model = DoubleQNetwork(); model.save(model_path); loaded = DoubleQNetwork.load(model_path)
            ok = loaded.input_count == model.input_count and loaded.layer_sizes == model.layer_sizes
            results.append(self._item("模型 save/load", ok, "二进制校验"))
            damaged = model_path.with_name(model_path.name + ".damaged")
            damaged.write_bytes(model_path.read_bytes()[:-7] + b"broken!")
            corrupt_rejected = False
            try:
                DoubleQNetwork.load(damaged)
            except Exception:
                corrupt_rejected = True
            results.append(self._item("模型损坏检测", corrupt_rejected, "损坏 checkpoint 必须被校验拒绝"))
            try: damaged.unlink()
            except OSError: pass

            # 验证主模型损坏时不是仅仅“报错”，而是能自动隔离损坏文件并回滚最近可用 checkpoint。
            recovery_dir = self.data_dir / ("self_test_recovery_" + token)
            recovery_runtime = None
            try:
                checkpoint_dir = recovery_dir / "checkpoints"
                checkpoint_dir.mkdir(parents=True, exist_ok=True)
                recovery_model = DoubleQNetwork()
                recovery_model.training_steps = 37
                recovery_model.save(checkpoint_dir / "model_99999999_999999_37.bin")
                recovery_dir.mkdir(parents=True, exist_ok=True)
                (recovery_dir / MODEL_FILE_NAME).write_bytes(b"deliberately-corrupt-model")
                recovery_runtime = AgentRuntime(recovery_dir, queue.Queue())
                recovered_ok = recovery_runtime.model.training_steps == 37 and "回滚 checkpoint" in recovery_runtime.startup_note
                quarantined = any(recovery_dir.glob(MODEL_FILE_NAME + ".invalid_*"))
                results.append(self._item("模型损坏自动恢复", recovered_ok and quarantined, "损坏主模型已隔离，并从最近有效 checkpoint 回滚"))
            finally:
                if recovery_runtime is not None:
                    try: recovery_runtime.memory.close()
                    except Exception: pass
                shutil.rmtree(recovery_dir, ignore_errors=True)
        except Exception as error:
            results.append(self._item("模型 save/load", False, error))
            results.append(self._item("模型损坏检测", False, error))
            results.append(self._item("模型损坏自动恢复", False, error))

        # 不调用 Windows SendInput 的并发竞态测试：close() 返回之后，mock send 次数必须保持不变。
        try:
            gate_event = threading.Event(); gate_lock = threading.Lock(); stop_probe = threading.Event()
            gate = SharedInputGate(gate_event, gate_lock, stop_probe)
            sent = {"count": 0}; running = threading.Event(); running.set()
            def mock_sender():
                while running.is_set():
                    try:
                        gate.run_if_open(lambda: sent.__setitem__("count", sent["count"] + 1))
                    except InputGateClosed:
                        break
            threads = [threading.Thread(target=mock_sender) for _ in range(4)]
            for thread in threads: thread.start()
            time.sleep(0.01); gate.close(); after_close = sent["count"]; time.sleep(0.01); running.clear()
            for thread in threads: thread.join(0.2)
            results.append(self._item("ESC 硬输入闸门竞态", sent["count"] == after_close and gate_event.is_set(), "gate 关闭后的 mock SendInput 次数恒为 0"))
        except Exception as error:
            results.append(self._item("ESC 硬输入闸门竞态", False, error))

        io = None
        if os.name == "nt":
            try:
                adapter_gate_event = threading.Event(); adapter_gate_lock = threading.Lock(); adapter_stop = threading.Event()
                adapter_count = {"normal": 0}
                mock_io = WinIO(input_enabled=True, input_gate_event=adapter_gate_event, input_gate_lock=adapter_gate_lock, stop_event=adapter_stop,
                                send_input_adapter=lambda _value: adapter_count.__setitem__("normal", adapter_count["normal"] + 1) or 1)
                value = Input(); value.type = WinIO.INPUT_KEYBOARD; value.ki = KeyboardInput(0x09, 0, 0, 0, 0)
                mock_io._send(value); mock_io.close_input_gate(); frozen = adapter_count["normal"]
                blocked = False
                try: mock_io._send(value)
                except InputGateClosed: blocked = True
                mock_io.close()
                results.append(self._item("WinIO SendInput adapter 闸门", blocked and adapter_count["normal"] == frozen, "adapter 证明关闸后正常发送为 0"))
                results.append(self._item("Secure Desktop fail-closed", WinIO.desktop_name_is_safe("Default") and not WinIO.desktop_name_is_safe("Winlogon"), "非 Default desktop 一律禁止正常输入"))
            except Exception as error:
                results.append(self._item("WinIO SendInput adapter 闸门", False, error))
                results.append(self._item("Secure Desktop fail-closed", False, error))
            try:
                io = WinIO(input_enabled=False)
                safe, desktop = io.input_desktop_status(force=True)
                results.append(self._item("Default Input Desktop", safe, desktop))
                results.append(self._item("UIA COM", bool(io.accessibility.available), "CUIAutomation"))
                observation = io.capture(force_deep=True)
                results.append(self._item("截图与 UIA 感知", bool(observation.global_rgb), "HWND {}".format(observation.accessibility.hwnd)))
            except Exception as error:
                results.append(self._item("Default Input Desktop", False, error))
                results.append(self._item("UIA COM", False, error))
                results.append(self._item("截图与 UIA 感知", False, error))
            finally:
                if io is not None:
                    io.close()
            try:
                context = multiprocessing.get_context("spawn")
                stop_event = context.Event(); escape_event = context.Event()
                watchdog = EscapeWatchdog(context, stop_event, escape_event, release_enabled=False)
                watchdog.start()
                alive = bool((watchdog.process is not None and watchdog.process.is_alive()) or (watchdog.thread is not None and watchdog.thread.is_alive()))
                watchdog.stop()
                results.append(self._item("ESC watchdog 创建", alive, "只检测，不发送输入"))
            except Exception as error:
                results.append(self._item("ESC watchdog 创建", False, error))
            try:
                context = multiprocessing.get_context("spawn")
                sleeper = context.Process(target=time.sleep, args=(5.0,), daemon=True)
                sleeper.start(); sleeper.terminate(); sleeper.join(1.0)
                results.append(self._item("worker 强制 terminate", not sleeper.is_alive(), "监督进程可在宽限期后强制终止"))
            except Exception as error:
                results.append(self._item("worker 强制 terminate", False, error))
        else:
            results.extend([
                self._item("Default Input Desktop", False, "非 Windows"), self._item("UIA COM", False, "非 Windows"),
                self._item("截图与 UIA 感知", False, "非 Windows"), self._item("ESC watchdog 创建", False, "非 Windows"),
                self._item("WinIO SendInput adapter 闸门", False, "非 Windows"), self._item("Secure Desktop fail-closed", False, "非 Windows"),
                self._item("worker 强制 terminate", False, "非 Windows"),
            ])
        for path in (probe, database, Path(str(database) + "-wal"), Path(str(database) + "-shm"), model_path):
            try:
                if path.exists(): path.unlink()
            except OSError:
                pass
        ready = all(item["ok"] for item in results if item["critical"])
        return {"ready": ready, "checks": results, "summary": "；".join("{}:{}".format(item["name"], "通过" if item["ok"] else "失败") for item in results)}


class LocalAgent:
    def __init__(self, data_dir, messages):
        self.data_dir = Path(data_dir)
        self.messages = messages
        self.context = multiprocessing.get_context("spawn")
        self.stop_event = None
        self.escape_event = None
        self.input_gate_event = None
        self.input_gate_lock = None
        self.process = None
        self.process_messages = None
        self.monitor_thread = None
        self.watchdog = None
        self.last_stats = None
        self.startup_note = ""
        self.self_test_report = {"ready": False, "checks": [], "summary": "未运行"}
        self._initialize_storage()
        self.self_test_report = StartupSelfTest(self.data_dir).run()
        self.startup_ready = bool(self.self_test_report.get("ready"))
        self.startup_note += "；启动自检：" + str(self.self_test_report.get("summary", ""))

    def _initialize_storage(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        memory = LongTermMemory(self.data_dir / DATABASE_FILE_NAME)
        try:
            counts = {
                "experiences": memory.count("episodic_memory"), "states": memory.count("state_memory"),
                "skills": memory.count("skill_memory"), "failures": memory.count("failure_memory"),
                "knowledge": memory.count("semantic_knowledge"), "world": memory.count("world_transition"),
            }
            tiers = memory.tier_counts()
            resources = memory.resource_budget.as_dict()
        finally:
            memory.close()
        model_path = self.data_dir / MODEL_FILE_NAME
        note = ""
        if model_path.exists():
            try:
                model = DoubleQNetwork.load(model_path)
                note = "已载入可扩展多层模型"
            except Exception:
                try:
                    os.replace(model_path, model_path.with_name(model_path.name + ".invalid_" + time.strftime("%Y%m%d_%H%M%S")))
                except OSError:
                    pass
                model = DoubleQNetwork()
                model.save(model_path)
                note = "旧模型结构不兼容，已保留旧文件并创建 v7 模型"
        else:
            model = DoubleQNetwork()
            model.save(model_path)
            note = "已创建可扩展多层模型"
        self.startup_note = note + "；SQLite schema v{} 已就绪".format(SCHEMA_VERSION)
        self.last_stats = {
            "phase": "就绪", "goal": "", "hidden": model.hidden_count, "depth": model.depth, "input_count": model.input_count,
            "experiences": counts["experiences"], "states": counts["states"], "skills": counts["skills"], "failures": counts["failures"],
            "knowledge": counts["knowledge"], "world": counts["world"], "compressed_memory": tiers["compressed"], "archived_memory": tiers["archived"],
            "sleep_count": model.sleep_count, "training_steps": model.training_steps, "target_syncs": model.target_syncs,
            "growth": model.accepted_growth, "loss": model.loss_average, "reward": model.reward_average,
            "goal_progress": model.progress_average, "safety": model.safety_average, "progress": 0, "total": 0,
            "capacities": dict(model.capacities),
            "resources": resources, "sleep_score": 0.0, "bottleneck": "none",
        }

    def _stats(self, phase, goal_label="", progress=0, total=0):
        result = dict(self.last_stats or {})
        result.update({"phase": phase, "goal": goal_label, "progress": progress, "total": total})
        return result

    def running(self):
        return self.process is not None and self.process.is_alive()

    def start(self, settings):
        if self.running():
            return
        self.stop_event = self.context.Event()
        self.escape_event = self.context.Event()
        self.input_gate_event = self.context.Event()
        self.input_gate_lock = self.context.Lock()
        self.process_messages = self.context.Queue()
        self.watchdog = EscapeWatchdog(
            self.context, self.stop_event, self.escape_event,
            release_enabled=not bool(settings.get("observe_only", False)),
            input_gate_event=self.input_gate_event, input_gate_lock=self.input_gate_lock,
        )
        self.watchdog.start()
        self.process = self.context.Process(
            target=agent_worker_process,
            args=(str(self.data_dir), dict(settings), self.stop_event, self.process_messages, self.input_gate_event, self.input_gate_lock),
            name="LocalAIWorker",
            daemon=True,
        )
        try:
            self.process.start()
        except Exception:
            if self.watchdog is not None:
                self.watchdog.stop()
            self.process = None
            raise
        self.monitor_thread = threading.Thread(target=self._monitor, name="LocalAIWorkerSupervisor", daemon=True)
        self.monitor_thread.start()

    def _monitor(self):
        emergency_sent = False
        no_more_input_sent = False
        stop_started = None
        child_reported_stop = False
        while True:
            try:
                kind, payload = self.process_messages.get(timeout=0.010)
                if kind == "stats" and isinstance(payload, dict):
                    self.last_stats = dict(payload)
                if kind == "stopped":
                    child_reported_stop = True
                self.messages.put((kind, payload))
            except queue.Empty:
                pass
            except (EOFError, OSError):
                pass
            if self.stop_event is not None and self.stop_event.is_set() and self.running():
                if not emergency_sent:
                    emergency_sent = True
                    stop_started = time.monotonic()
                    escaped = self.escape_event is not None and self.escape_event.is_set()
                    text = (
                        "检测到 ESC：硬输入闸门已关闭并释放输入；正在终止 AI（开始按钮保持禁用）"
                        if escaped else "检测到停止请求：硬输入闸门已关闭并释放输入；正在终止 AI（开始按钮保持禁用）"
                    )
                    self.messages.put(("emergency", text))
                if self.input_gate_event is not None and self.input_gate_event.is_set() and not no_more_input_sent:
                    no_more_input_sent = True
                    self.messages.put(("no_more_input", "输入层已确认 no_more_input：本轮正常 SendInput 永久关闭，等待 worker terminated"))
                escaped = self.escape_event is not None and self.escape_event.is_set()
                # GUI 已由主进程立即恢复；worker 在禁止继续执行动作的 stop_event 下获得最终提交窗口。
                grace = 2.0 if escaped else 0.85
                if stop_started is not None and time.monotonic() - stop_started >= grace and self.running():
                    try:
                        self.process.terminate()
                    except Exception:
                        pass
            if not self.running():
                for _ in range(64):
                    try:
                        kind, payload = self.process_messages.get_nowait()
                    except Exception:
                        break
                    if kind == "stats" and isinstance(payload, dict):
                        self.last_stats = dict(payload)
                    if kind == "stopped":
                        child_reported_stop = True
                    self.messages.put((kind, payload))
                break
        if self.watchdog is not None:
            self.watchdog.stop()
        if emergency_sent and not child_reported_stop:
            self.messages.put(("stopped", "AI worker 已被主进程强制停止"))
        elif not child_reported_stop:
            self.messages.put(("stopped", "AI worker 已退出"))

    def request_stop(self):
        if self.stop_event is not None:
            SharedInputGate(self.input_gate_event, self.input_gate_lock, self.stop_event).close()

    def shutdown(self):
        if self.running():
            self.request_stop()
            self.process.join(0.85)
            if self.running():
                try:
                    self.process.terminate()
                except Exception:
                    pass
                self.process.join(0.3)
        if self.watchdog is not None:
            self.watchdog.stop()
        return True


def is_windows_11_x64():
    if os.name != "nt" or ctypes.sizeof(ctypes.c_void_p) != 8:
        return False
    try:
        version = sys.getwindowsversion()
        return int(version.major) == 10 and int(version.build) >= 22000
    except Exception:
        return False


def capture_foreground_context(exclude_pid=None, z_order_fallback=True):
    """点击“开始”的瞬间锁定用户工作窗口；若 GUI 自己在前台，则取其后第一个可见外部顶层窗口。"""
    if os.name != "nt":
        return {}
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]; user32.GetWindow.restype = wintypes.HWND
        user32.IsWindowVisible.argtypes = [wintypes.HWND]; user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]; user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]; kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]; kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]; kernel32.CloseHandle.restype = wintypes.BOOL
        hwnd = user32.GetForegroundWindow()
        # GW_HWNDNEXT=2：Tk 的“开始”按钮通常使自身成为前台，向 Z-order 后方寻找用户原工作窗口。
        for _ in range(64):
            if not hwnd:
                break
            pid = wintypes.DWORD(0); user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if (exclude_pid is None or int(pid.value) != int(exclude_pid)) and user32.IsWindowVisible(hwnd):
                title = ctypes.create_unicode_buffer(512); cls = ctypes.create_unicode_buffer(256)
                user32.GetWindowTextW(hwnd, title, len(title)); user32.GetClassNameW(hwnd, cls, len(cls))
                if title.value.strip() or cls.value.strip():
                    process_path = ""
                    handle = kernel32.OpenProcess(0x1000, False, pid.value) if pid.value else None
                    if handle:
                        try:
                            size = wintypes.DWORD(2048); buf = ctypes.create_unicode_buffer(size.value)
                            if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                                process_path = buf.value
                        finally:
                            kernel32.CloseHandle(handle)
                    return {"hwnd": int(hwnd), "process_id": int(pid.value), "process_path": process_path,
                            "process_name": os.path.basename(process_path).lower() if process_path else "",
                            "window_title": title.value, "window_class": cls.value, "captured_at": time.time()}
            if not z_order_fallback:
                break
            hwnd = user32.GetWindow(hwnd, 2)
    except Exception:
        return {}
    return {}


def choose_data_directory():
    preferred = Path(__file__).resolve().parent / "local_ai_data"
    candidates = [preferred]
    local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
    if local_appdata:
        candidates.append(Path(local_appdata) / "LocalAI")
    else:
        candidates.append(Path.home() / "AppData" / "Local" / "LocalAI")
    errors = []
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / (".write_probe_" + uuid.uuid4().hex)
            with open(probe, "wb") as stream:
                stream.write(b"ok")
                stream.flush()
                os.fsync(stream.fileno())
            probe.unlink()
            return candidate, (candidate != preferred), ""
        except Exception as error:
            errors.append("{}: {}".format(candidate, error))
    raise OSError("没有可写的数据目录：" + "；".join(errors))


class Application:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("900x820")
        self.root.minsize(780, 720)
        self.root.configure(bg="#0f172a")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.messages = queue.Queue()
        self.closing = False
        self.pending_approval = None
        self.terminating = False
        self.last_settings = None
        self.last_external_context = {}
        try:
            self.data_dir, self.data_dir_fallback, self.data_dir_note = choose_data_directory()
        except Exception as error:
            self.data_dir = Path(__file__).resolve().parent / "local_ai_data"
            self.data_dir_fallback = False
            self.data_dir_note = str(error)
        try:
            self.agent = LocalAgent(self.data_dir, self.messages)
            self.startup_error = ""
        except Exception as error:
            self.agent = None
            self.startup_error = str(error)
        self.clicks = tk.BooleanVar(value=True)
        self.keyboard = tk.BooleanVar(value=True)
        self.safe_mode = tk.BooleanVar(value=True)
        # 默认保持原始产品流程：点击“开始”后可执行鼠标/键盘。
        # 用户可在首次运行前主动勾选只观察，届时规划与学习照常、SendInput 硬禁止。
        self.observe_only = tk.BooleanVar(value=False)
        self.allow_network_knowledge = tk.BooleanVar(value=False)
        self.knowledge_urls = tk.StringVar(value="")
        self.speed = tk.DoubleVar(value=0.32)
        self.goal = tk.StringVar(value="")
        self.success_text = tk.StringVar(value="")
        self.status = tk.StringVar(value="就绪")
        self.details = tk.StringVar(value="")
        self.last_event = tk.StringVar(value="")
        self.target_context_text = tk.StringVar(value="将控制：等待最近一个外部前台窗口")
        self._build()
        self.last_external_context = capture_foreground_context(exclude_pid=os.getpid())
        self.root.after(120, self._track_external_foreground)
        self.root.after(20, self.poll)

    def _track_external_foreground(self):
        if self.closing:
            return
        candidate = capture_foreground_context(exclude_pid=os.getpid(), z_order_fallback=False)
        if candidate:
            self.last_external_context = candidate
            if hasattr(self, "target_context_text"):
                self.target_context_text.set("将控制：{} | {}".format(candidate.get("process_name", "未知进程"), candidate.get("window_title", "未知窗口")[:100]))
        elif self.last_external_context and hasattr(self, "target_context_text"):
            candidate = self.last_external_context
            self.target_context_text.set("将控制：{} | {}".format(candidate.get("process_name", "未知进程"), candidate.get("window_title", "未知窗口")[:100]))
        self.root.after(120, self._track_external_foreground)

    def _locked_context(self):
        candidate = dict(self.last_external_context or {})
        if candidate:
            return candidate
        return capture_foreground_context(exclude_pid=os.getpid())

    def _label(self, parent, text="", variable=None, size=11, color="#d1d5db", bold=False, wrap=0, background="#0f172a"):
        return tk.Label(parent, text=text, textvariable=variable, font=("Microsoft YaHei UI", size, "bold" if bold else "normal"), fg=color, bg=background, justify="left", anchor="w", wraplength=wrap)

    def _build(self):
        frame = tk.Frame(self.root, bg="#0f172a", padx=26, pady=22)
        frame.pack(fill="both", expand=True)
        self._label(frame, APP_NAME, size=23, color="#f8fafc", bold=True).pack(fill="x")
        self._label(frame, "通用目标框架 · UIA 分层感知 · 资源预算扩展 · 三级长期记忆", size=11, color="#60a5fa", bold=True).pack(fill="x", pady=(4, 12))
        info = "不调用或下载第三方 AI 模型。本程序实现的是‘无固定容量上限’：网络、感知、规划、技能注意和记忆不写死最终最大值，而由资源与验证结果扩展；这不等同于‘无限智力’，模型从本机 GUI 经验开始学习。未知目标进入类型化 DSL 的观察→合法候选→排序→验证→编译程序闭环。"
        self._label(frame, info, size=9, color="#cbd5e1", wrap=840).pack(fill="x", pady=(0, 12))

        goal_panel = tk.Frame(frame, bg="#1e293b", padx=16, pady=13)
        goal_panel.pack(fill="x", pady=(0, 10))
        self._label(goal_panel, "本次目标（留空时由 AI 从可访问控件生成具体课程目标）", size=9, color="#e2e8f0", bold=True, background="#1e293b").pack(fill="x")
        tk.Entry(goal_panel, textvariable=self.goal, font=("Microsoft YaHei UI", 10), bg="#334155", fg="#f8fafc", insertbackground="#ffffff", relief="flat").pack(fill="x", ipady=6, pady=(5, 9))
        self._label(goal_panel, "成功判据（可选；填写应在窗口/控件中出现的文字，多个判据用 | 分隔）", size=9, color="#e2e8f0", background="#1e293b").pack(fill="x")
        tk.Entry(goal_panel, textvariable=self.success_text, font=("Microsoft YaHei UI", 10), bg="#334155", fg="#f8fafc", insertbackground="#ffffff", relief="flat").pack(fill="x", ipady=6, pady=(5, 0))

        panel = tk.Frame(frame, bg="#1e293b", padx=16, pady=13)
        panel.pack(fill="x")
        check_style = {"font": ("Microsoft YaHei UI", 9), "fg": "#f1f5f9", "bg": "#1e293b", "activebackground": "#1e293b", "activeforeground": "#ffffff", "selectcolor": "#334155"}
        tk.Checkbutton(panel, text="允许鼠标点击", variable=self.clicks, **check_style).grid(row=0, column=0, sticky="w", padx=(0, 24))
        tk.Checkbutton(panel, text="允许键盘与 Unicode 文本", variable=self.keyboard, **check_style).grid(row=0, column=1, sticky="w", padx=(0, 24))
        tk.Checkbutton(panel, text="安全模式", variable=self.safe_mode, **check_style).grid(row=0, column=2, sticky="w")
        tk.Checkbutton(panel, text="模拟/只观察（禁止全部 SendInput）", variable=self.observe_only, **check_style).grid(row=1, column=0, columnspan=2, sticky="w", pady=(10, 0))
        tk.Checkbutton(panel, text="读取下方用户允许的网络来源", variable=self.allow_network_knowledge, **check_style).grid(row=1, column=2, sticky="w", pady=(10, 0))
        tk.Label(panel, text="动作间隔", font=("Microsoft YaHei UI", 9), fg="#f1f5f9", bg="#1e293b").grid(row=2, column=0, sticky="w", pady=(12, 0))
        tk.Scale(panel, from_=0.15, to=1.2, resolution=0.05, orient="horizontal", variable=self.speed, length=330, showvalue=True, bg="#1e293b", fg="#f1f5f9", troughcolor="#334155", highlightthickness=0).grid(row=2, column=1, columnspan=2, sticky="w", pady=(7, 0))
        self._label(panel, "允许读取的 http/https URL（用空格、分号或换行分隔；留空则不联网）", size=8, color="#cbd5e1", background="#1e293b").grid(row=3, column=0, columnspan=3, sticky="w", pady=(9, 3))
        tk.Entry(panel, textvariable=self.knowledge_urls, font=("Microsoft YaHei UI", 9), bg="#334155", fg="#f8fafc", insertbackground="#ffffff", relief="flat").grid(row=4, column=0, columnspan=3, sticky="ew", ipady=5)
        panel.grid_columnconfigure(1, weight=1)

        status_panel = tk.Frame(frame, bg="#0f172a", pady=13)
        status_panel.pack(fill="x")
        self._label(status_panel, variable=self.status, size=12, color="#34d399", bold=True).pack(fill="x")
        self._label(status_panel, variable=self.details, size=9, color="#d1d5db", wrap=840).pack(fill="x", pady=(4, 0))
        self._label(status_panel, variable=self.last_event, size=9, color="#93c5fd", wrap=840).pack(fill="x", pady=(4, 0))

        safety = "睡眠主线：价值型记忆压缩 → 参数化 Skill/Procedure/MacroAction/Tool 组合 → 瓶颈诊断 → 永久 train/eval 验证 → 仅在 model_capacity 瓶颈时考虑神经网络扩张 → SleepReport → checkpoint。下一轮规划会读取 SleepReport。"
        self._label(frame, safety, size=8, color="#a7f3d0", wrap=760).pack(fill="x", pady=(0, 10))
        warning = "重要：GUI 持续记录最近一个非本程序前台窗口；点击开始直接锁定该 HWND/PID。ESC 会先永久关闭本轮硬输入闸门，再释放输入并终止 worker；Secure Desktop 同样 fail-closed。"
        self._label(frame, warning, size=9, color="#fbbf24", bold=True, wrap=760).pack(fill="x", pady=(0, 8))
        self._label(frame, variable=self.target_context_text, size=9, color="#93c5fd", bold=True, wrap=820).pack(fill="x", pady=(0, 12))
        self.start_button = tk.Button(frame, text="开始", command=self.start, font=("Microsoft YaHei UI", 14, "bold"), bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white", relief="flat", cursor="hand2", padx=22, pady=10)
        self.start_button.pack(fill="x")
        if self.agent is not None:
            storage_note = "；数据目录：{}{}".format(self.data_dir, "（code.py 目录不可写，已回退）" if self.data_dir_fallback else "")
            self.status.set("就绪：" + self.agent.startup_note + storage_note)
            self._update_details(self.agent._stats("就绪"))
        if not is_windows_11_x64():
            self.start_button.configure(state="disabled")
            self.status.set("此程序只能在 Windows 11 x64 环境运行")
        elif self.startup_error:
            self.start_button.configure(state="disabled")
            self.status.set("初始化失败：" + self.startup_error)
        elif self.agent is not None and not getattr(self.agent, "startup_ready", False):
            self.start_button.configure(state="disabled")
            failed = [item["name"] + "：" + item.get("detail", "") for item in self.agent.self_test_report.get("checks", []) if item.get("critical") and not item.get("ok")]
            self.status.set("启动自检未通过：" + "；".join(failed))

    def _update_details(self, stats):
        training = ""
        if stats.get("total"):
            training = " | 睡眠训练 {}/{}".format(stats.get("progress", 0), stats["total"])
        goal = " | 目标：{}".format(stats["goal"][:80]) if stats.get("goal") else ""
        capacities = stats.get("capacities", {})
        capacity = " | UIA {}/{} | ROI×{} | 记忆窗 {} | 策略 {} | 技能注意 {}".format(
            capacities.get("uia_depth", "-"), capacities.get("uia_nodes", "-"), capacities.get("visual_roi_scale", "-"), capacities.get("memory_horizon", "-"),
            capacities.get("planner_breadth", "-"), capacities.get("skill_attention", "-"),
        )
        resources = stats.get("resources", {})
        resource_text = " | 可用RAM {:.1f}GB | 可用盘 {:.1f}GB / 安全线 {:.1f}GB{}".format(
            safe_float(resources.get("available_ram", 0)) / 1024 ** 3,
            safe_float(resources.get("free_disk", 0)) / 1024 ** 3,
            safe_float(resources.get("disk_reserve_bytes", 0)) / 1024 ** 3,
            " | 经验写入暂停" if stats.get("storage_paused") else "",
        ) if resources else ""
        self.details.set(
            "输入 {} 维 | 神经元 {} / {} 层 | 热情景 {} | 压缩/归档 {}/{} | 状态 {} | 技能 {} | 失败记忆 {} | 睡眠 {} | sleep_score {:.3f} | 训练 {} | 扩容通过 {} | 误差 {:.4f} | 奖励 {:+.3f}{}{}{}{}".format(
                stats.get("input_count", BASE_FEATURE_COUNT), stats.get("hidden", 0), stats.get("depth", 0), stats.get("experiences", 0),
                stats.get("compressed_memory", 0), stats.get("archived_memory", 0), stats.get("states", 0), stats.get("skills", 0), stats.get("failures", 0),
                stats.get("sleep_count", 0), stats.get("sleep_score", 0.0), stats.get("training_steps", 0), stats.get("growth", 0),
                stats.get("loss", 0.0), stats.get("reward", 0.0), capacity + " | 知识 {} | 世界 {} | 瓶颈 {}".format(stats.get("knowledge", 0), stats.get("world", 0), stats.get("bottleneck", "none")), resource_text, training, goal,
            )
        )

    def start(self):
        if self.agent is None or self.agent.running() or self.terminating or not getattr(self.agent, "startup_ready", False):
            return
        urls = [value for value in re.split(r"[\s;；]+", self.knowledge_urls.get().strip()) if value]
        settings = {
            "clicks": self.clicks.get(), "keyboard": self.keyboard.get(), "safe_mode": self.safe_mode.get(),
            "interval": self.speed.get(), "goal": self.goal.get().strip(), "success_text": self.success_text.get().strip(),
            "observe_only": self.observe_only.get(), "allow_network_knowledge": self.allow_network_knowledge.get(),
            "knowledge_urls": urls,
        }
        # 必须在 withdraw() 前抓取；隐藏 Tk 后 Windows 可能自动切换前台窗口。
        settings["initial_context"] = self._locked_context()
        self.last_settings = dict(settings)
        locked = settings.get("initial_context", {})
        self.last_event.set("已锁定初始工作上下文：{} | {}".format(locked.get("process_name", "未知进程"), locked.get("window_title", "未知窗口")[:90]))
        self.status.set("AI 正在建立目标与感知状态")
        self.terminating = False
        self.start_button.configure(state="disabled")
        self.root.withdraw()
        try:
            self.agent.start(settings)
        except Exception as error:
            self.restore("运行错误：无法启动 AI worker：" + str(error))

    def restore(self, reason, ready=True):
        if self.closing:
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()
            return
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(500, lambda: self.root.attributes("-topmost", False))
        self.terminating = not bool(ready)
        self.start_button.configure(state="normal" if ready else "disabled")
        self.status.set(reason)
        if reason.startswith("运行错误"):
            messagebox.showerror(APP_NAME, reason, parent=self.root)

    def _restart_after_approval(self):
        if not self.pending_approval or self.agent is None:
            return
        if self.agent.running() or (self.agent.monitor_thread is not None and self.agent.monitor_thread.is_alive()):
            self.root.after(40, self._restart_after_approval)
            return
        fingerprint = str(self.pending_approval)
        self.pending_approval = None
        settings = dict(self.last_settings or {})
        settings["approved_risk_fingerprint"] = fingerprint
        settings["initial_context"] = self._locked_context()
        self.last_settings = dict(settings)
        self.status.set("已确认一次高风险动作；重新感知后仅允许精确匹配的那个动作")
        self.terminating = False
        self.start_button.configure(state="disabled")
        self.root.withdraw()
        try:
            self.agent.start(settings)
        except Exception as error:
            self.restore("运行错误：确认后无法重新启动 AI worker：" + str(error))

    def _handle_approval(self, payload):
        self.restore("高风险动作已暂停，等待用户确认；worker 正在终止", ready=False)
        label = str((payload or {}).get("label", "高风险操作"))
        reason = str((payload or {}).get("reason", "检测到不可逆操作"))
        fingerprint = str((payload or {}).get("fingerprint", ""))
        approved = messagebox.askyesno(
            APP_NAME,
            "AI 已在执行前暂停。\n\n{}\n\n动作：{}\n\n是否只允许这一个精确动作执行一次？".format(reason, label),
            parent=self.root,
        )
        if approved and fingerprint:
            self.pending_approval = fingerprint
            self.status.set("已确认；等待 worker 安全退出后重新感知并执行一次")
            self.root.after(40, self._restart_after_approval)
        else:
            self.pending_approval = None
            self.status.set("已取消高风险动作；AI 保持停止")

    def _finish_stop_restore(self, reason):
        if self.agent is not None and (self.agent.running() or (self.agent.monitor_thread is not None and self.agent.monitor_thread.is_alive())):
            self.root.after(40, lambda: self._finish_stop_restore(reason))
            return
        self.restore(reason, ready=True)

    def poll(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "stats":
                    self.status.set(payload["phase"])
                    self._update_details(payload)
                elif kind == "event":
                    self.last_event.set(payload)
                elif kind == "emergency":
                    self.restore(payload, ready=False)
                elif kind == "no_more_input":
                    self.status.set(payload)
                    self.start_button.configure(state="disabled")
                elif kind == "approval_required":
                    self._handle_approval(payload)
                elif kind == "stopped":
                    if self.pending_approval:
                        self.root.after(40, self._restart_after_approval)
                    else:
                        self._finish_stop_restore(payload)
        except queue.Empty:
            pass
        if self.closing and (self.agent is None or not self.agent.running()):
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()
            return
        self.root.after(20, self.poll)

    def close(self):
        if self.agent is not None and self.agent.running():
            self.closing = True
            self.agent.request_stop()
            self.status.set("正在安全停止并保存……")
        else:
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()


def main():
    multiprocessing.freeze_support()
    root = tk.Tk()
    Application(root)
    root.mainloop()


if __name__ == "__main__":
    main()
