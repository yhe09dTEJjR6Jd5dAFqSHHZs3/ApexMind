import base64
import copy
import ctypes
from ctypes import wintypes
import hashlib
import json
import math
import os
import random
import shutil
import sys
import threading
import time


FEATURE_W = 16
FEATURE_H = 12
VISUAL_CHANNELS = 5
FEATURE_CHANNELS = 6
VISUAL_COUNT = FEATURE_W * FEATURE_H * VISUAL_CHANNELS
FEATURE_COUNT = FEATURE_W * FEATURE_H * FEATURE_CHANNELS
HIDDEN_COUNT = 16
VALUE_HIDDEN_COUNT = 14
MAX_TRAIN_MEMORY = 560
MAX_VALIDATION_MEMORY = 140
MAX_AUDIT_MEMORY = 120
MAX_SEEN_STATES = 2400
MIN_TRAIN_SAMPLES = 64
MIN_VALIDATION_SAMPLES = 18
MIN_AUDIT_SAMPLES = 10
TRAIN_BATCH_LIMIT = 80
AWAKE_STEPS = 24
MIN_SLEEP_SECONDS = 2.0
PASSIVE_HISTORY_COUNT = 3
PASSIVE_FRAME_INTERVAL = 0.22
CAUSAL_FRAME_SECONDS = 0.65
MIN_GATE_IMPROVEMENT = 0.003
MAX_GATE_REGRESSION = 0.0
VISIBLE_SAMPLE_COLUMNS = 7
VISIBLE_SAMPLE_ROWS = 5
MAX_RECOVERY_SECONDS = 8.0
AUTOSAVE_EVERY_EXPERIENCES = 8
STATE_VERSION = 5


def clamp(value, low=0.0, high=1.0):
    return max(low, min(high, value))


def build_base_actions():
    actions = []
    for y in (0.10, 0.25, 0.40, 0.55, 0.70, 0.85):
        for x in (0.10, 0.30, 0.50, 0.70, 0.90):
            actions.append((0, x, y, x, y))
    for x in (0.30, 0.50, 0.70):
        actions.append((1, x, 0.72, x, 0.28))
        actions.append((1, x, 0.28, x, 0.72))
    for y in (0.35, 0.65):
        actions.append((1, 0.75, y, 0.25, y))
        actions.append((1, 0.25, y, 0.75, y))
    return tuple(actions)


BASE_ACTIONS = build_base_actions()


def normalize_action(action):
    kind, x1, y1, x2, y2 = action
    return (
        int(kind),
        round(clamp(float(x1), 0.03, 0.97), 4),
        round(clamp(float(y1), 0.03, 0.97), 4),
        round(clamp(float(x2), 0.03, 0.97), 4),
        round(clamp(float(y2), 0.03, 0.97), 4),
    )


def action_key(action):
    kind, x1, y1, x2, y2 = normalize_action(action)
    return f"{kind}:{x1:.4f}:{y1:.4f}:{x2:.4f}:{y2:.4f}"


def action_vector(action):
    kind, x1, y1, x2, y2 = normalize_action(action)
    return [
        x1 * 2.0 - 1.0,
        y1 * 2.0 - 1.0,
        (x2 - x1) * 2.0,
        (y2 - y1) * 2.0,
        1.0 if kind == 0 else -1.0,
        1.0 if kind == 1 else -1.0,
    ]


def state_from_visual(previous_visual, current_visual):
    if len(previous_visual) != VISUAL_COUNT or len(current_visual) != VISUAL_COUNT:
        raise ValueError("画面特征尺寸不匹配")
    state = [0.0] * FEATURE_COUNT
    for cell in range(FEATURE_W * FEATURE_H):
        visual_base = cell * VISUAL_CHANNELS
        state_base = cell * FEATURE_CHANNELS
        for channel in range(VISUAL_CHANNELS):
            state[state_base + channel] = current_visual[visual_base + channel]
        previous_luma = (
            previous_visual[visual_base] * 0.299
            + previous_visual[visual_base + 1] * 0.587
            + previous_visual[visual_base + 2] * 0.114
        )
        current_luma = (
            current_visual[visual_base] * 0.299
            + current_visual[visual_base + 1] * 0.587
            + current_visual[visual_base + 2] * 0.114
        )
        state[state_base + 5] = clamp(0.5 + (current_luma - previous_luma) * 0.5)
    return state


class TinyWorldModel:
    def __init__(self, rng=None):
        rng = rng or random.Random()
        self.input_count = FEATURE_COUNT + 6
        scale1 = 0.20 / math.sqrt(self.input_count)
        scale2 = 0.12 / math.sqrt(HIDDEN_COUNT)
        self.w1 = [
            [rng.uniform(-scale1, scale1) for _ in range(self.input_count)]
            for _ in range(HIDDEN_COUNT)
        ]
        self.b1 = [0.0] * HIDDEN_COUNT
        self.w2 = [
            [rng.uniform(-scale2, scale2) for _ in range(HIDDEN_COUNT)]
            for _ in range(FEATURE_COUNT)
        ]
        self.b2 = [0.0] * FEATURE_COUNT

    @staticmethod
    def make_input(features, action):
        return [value * 2.0 - 1.0 for value in features] + action_vector(action)

    def forward_input(self, values, base_features):
        hidden = []
        for row, bias in zip(self.w1, self.b1):
            total = bias
            for weight, value in zip(row, values):
                total += weight * value
            hidden.append(math.tanh(total))
        output = []
        raw_deltas = []
        for output_index, (row, bias) in enumerate(zip(self.w2, self.b2)):
            total = bias
            for weight, value in zip(row, hidden):
                total += weight * value
            delta = math.tanh(total)
            raw_deltas.append(delta)
            output.append(clamp(base_features[output_index] + delta * 0.25))
        return output, hidden, raw_deltas

    def predict(self, features, action):
        return self.forward_input(self.make_input(features, action), features)[0]

    def sample_loss(self, sample):
        prediction = self.predict(sample["before"], sample["action"])
        total = 0.0
        for predicted, target in zip(prediction, sample["after"]):
            error = predicted - target
            total += error * error
        return total / FEATURE_COUNT

    def loss(self, samples):
        if not samples:
            return float("inf")
        return sum(self.sample_loss(sample) for sample in samples) / len(samples)

    def train_epoch(self, samples, learning_rate, rng, stopped):
        order = list(range(len(samples)))
        rng.shuffle(order)
        for position, sample_index in enumerate(order):
            if position % 8 == 0 and stopped():
                return False
            sample = samples[sample_index]
            values = self.make_input(sample["before"], sample["action"])
            prediction, hidden, raw_deltas = self.forward_input(values, sample["before"])
            hidden_gradient = [0.0] * HIDDEN_COUNT
            target = sample["after"]
            for output_index in range(FEATURE_COUNT):
                error = prediction[output_index] - target[output_index]
                derivative = 0.25 * (1.0 - raw_deltas[output_index] ** 2)
                gradient = max(-0.12, min(0.12, 2.0 * error * derivative))
                row = self.w2[output_index]
                for hidden_index in range(HIDDEN_COUNT):
                    old_weight = row[hidden_index]
                    hidden_gradient[hidden_index] += gradient * old_weight
                    row[hidden_index] -= learning_rate * gradient * hidden[hidden_index]
                self.b2[output_index] -= learning_rate * gradient
            for hidden_index in range(HIDDEN_COUNT):
                delta = (hidden_gradient[hidden_index] / math.sqrt(FEATURE_COUNT)) * (1.0 - hidden[hidden_index] ** 2)
                delta = max(-0.35, min(0.35, delta))
                row = self.w1[hidden_index]
                for input_index, value in enumerate(values):
                    row[input_index] -= learning_rate * delta * value
                self.b1[hidden_index] -= learning_rate * delta
        return True

    def to_dict(self):
        return {"w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2}

    @classmethod
    def from_dict(cls, data):
        model = cls(random.Random(0))
        w1, b1, w2, b2 = data["w1"], data["b1"], data["w2"], data["b2"]
        if (
            len(w1) != HIDDEN_COUNT
            or any(len(row) != model.input_count for row in w1)
            or len(b1) != HIDDEN_COUNT
            or len(w2) != FEATURE_COUNT
            or any(len(row) != HIDDEN_COUNT for row in w2)
            or len(b2) != FEATURE_COUNT
        ):
            raise ValueError("环境模型尺寸不匹配")
        model.w1 = [[float(value) for value in row] for row in w1]
        model.b1 = [float(value) for value in b1]
        model.w2 = [[float(value) for value in row] for row in w2]
        model.b2 = [float(value) for value in b2]
        return model


class TinyValueModel:
    def __init__(self, rng=None):
        rng = rng or random.Random()
        self.input_count = FEATURE_COUNT + 6
        scale1 = 0.24 / math.sqrt(self.input_count)
        scale2 = 0.18 / math.sqrt(VALUE_HIDDEN_COUNT)
        self.w1 = [
            [rng.uniform(-scale1, scale1) for _ in range(self.input_count)]
            for _ in range(VALUE_HIDDEN_COUNT)
        ]
        self.b1 = [0.0] * VALUE_HIDDEN_COUNT
        self.w2 = [
            [rng.uniform(-scale2, scale2) for _ in range(VALUE_HIDDEN_COUNT)]
            for _ in range(2)
        ]
        self.b2 = [0.0, 0.0]

    @staticmethod
    def make_input(features, action):
        return [value * 2.0 - 1.0 for value in features] + action_vector(action)

    def forward_input(self, values):
        hidden = []
        for row, bias in zip(self.w1, self.b1):
            total = bias
            for weight, value in zip(row, values):
                total += weight * value
            hidden.append(math.tanh(total))
        outputs = []
        raw = []
        for row, bias in zip(self.w2, self.b2):
            total = bias
            for weight, value in zip(row, hidden):
                total += weight * value
            value = math.tanh(total)
            raw.append(value)
            outputs.append(0.5 + value * 0.5)
        return outputs, hidden, raw

    def predict(self, features, action):
        values = self.make_input(features, action)
        outputs, _hidden, _raw = self.forward_input(values)
        return outputs[0], outputs[1]

    def sample_loss(self, sample):
        reward, causal = self.predict(sample["before"], sample["action"])
        reward_error = reward - sample["reward"]
        causal_error = causal - sample["causal"]
        return (reward_error * reward_error + causal_error * causal_error) * 0.5

    def loss(self, samples):
        if not samples:
            return float("inf")
        return sum(self.sample_loss(sample) for sample in samples) / len(samples)

    def train_epoch(self, samples, learning_rate, rng, stopped):
        order = list(range(len(samples)))
        rng.shuffle(order)
        for position, sample_index in enumerate(order):
            if position % 8 == 0 and stopped():
                return False
            sample = samples[sample_index]
            values = self.make_input(sample["before"], sample["action"])
            outputs, hidden, raw = self.forward_input(values)
            targets = (sample["reward"], sample["causal"])
            hidden_gradient = [0.0] * VALUE_HIDDEN_COUNT
            for output_index in range(2):
                error = outputs[output_index] - targets[output_index]
                derivative = 0.5 * (1.0 - raw[output_index] ** 2)
                gradient = max(-0.4, min(0.4, error * derivative))
                row = self.w2[output_index]
                for hidden_index in range(VALUE_HIDDEN_COUNT):
                    old_weight = row[hidden_index]
                    hidden_gradient[hidden_index] += gradient * old_weight
                    row[hidden_index] -= learning_rate * gradient * hidden[hidden_index]
                self.b2[output_index] -= learning_rate * gradient
            for hidden_index in range(VALUE_HIDDEN_COUNT):
                delta = hidden_gradient[hidden_index] * (1.0 - hidden[hidden_index] ** 2)
                delta = max(-0.35, min(0.35, delta))
                row = self.w1[hidden_index]
                for input_index, value in enumerate(values):
                    row[input_index] -= learning_rate * delta * value
                self.b1[hidden_index] -= learning_rate * delta
        return True

    def to_dict(self):
        return {"w1": self.w1, "b1": self.b1, "w2": self.w2, "b2": self.b2}

    @classmethod
    def from_dict(cls, data):
        model = cls(random.Random(0))
        w1, b1, w2, b2 = data["w1"], data["b1"], data["w2"], data["b2"]
        if (
            len(w1) != VALUE_HIDDEN_COUNT
            or any(len(row) != model.input_count for row in w1)
            or len(b1) != VALUE_HIDDEN_COUNT
            or len(w2) != 2
            or any(len(row) != VALUE_HIDDEN_COUNT for row in w2)
            or len(b2) != 2
        ):
            raise ValueError("动作价值模型尺寸不匹配")
        model.w1 = [[float(value) for value in row] for row in w1]
        model.b1 = [float(value) for value in b1]
        model.w2 = [[float(value) for value in row] for row in w2]
        model.b2 = [float(value) for value in b2]
        return model


def encode_features(features):
    raw = bytes(max(0, min(255, round(value * 255.0))) for value in features)
    return base64.b64encode(raw).decode("ascii")


def decode_features(encoded):
    raw = base64.b64decode(encoded.encode("ascii"), validate=True)
    if len(raw) != FEATURE_COUNT:
        raise ValueError("画面特征尺寸不匹配")
    return [value / 255.0 for value in raw]


class Brain:
    def __init__(self, state_path):
        self.state_path = state_path
        self.backup_path = state_path + ".bak"
        self.rng = random.Random()
        self.model = TinyWorldModel(self.rng)
        self.value_model = TinyValueModel(self.rng)
        self.generation = 0
        self.training_memory = []
        self.validation_memory = []
        self.audit_memory = []
        self.audit_generation = 0
        self.action_stats = {}
        self.seen = {}
        self.loaded_from_backup = False
        self.last_action_exploratory = False
        self.load()

    @staticmethod
    def frame_change(left_frame, right_frame):
        if not left_frame or not right_frame:
            return 0.0
        return sum(abs(left - right) for left, right in zip(left_frame, right_frame)) / len(left_frame)

    @staticmethod
    def visual_change(left_frame, right_frame):
        if not left_frame or not right_frame:
            return 0.0
        total = 0.0
        count = 0
        for cell in range(FEATURE_W * FEATURE_H):
            base = cell * VISUAL_CHANNELS
            for channel in range(VISUAL_CHANNELS):
                total += abs(left_frame[base + channel] - right_frame[base + channel])
                count += 1
        return total / max(1, count)

    @staticmethod
    def action_region_change(left_frame, right_frame, action):
        kind, x1, y1, x2, y2 = normalize_action(action)
        total = 0.0
        weight_total = 0.0
        for gy in range(FEATURE_H):
            cy = (gy + 0.5) / FEATURE_H
            for gx in range(FEATURE_W):
                cx = (gx + 0.5) / FEATURE_W
                if kind == 0:
                    distance = math.hypot(cx - x1, cy - y1)
                else:
                    dx, dy = x2 - x1, y2 - y1
                    denom = dx * dx + dy * dy
                    ratio = 0.0 if denom <= 1e-9 else clamp(((cx - x1) * dx + (cy - y1) * dy) / denom)
                    px, py = x1 + dx * ratio, y1 + dy * ratio
                    distance = math.hypot(cx - px, cy - py)
                weight = max(0.0, 1.0 - distance / 0.22)
                if weight <= 0.0:
                    continue
                base = (gy * FEATURE_W + gx) * VISUAL_CHANNELS
                cell_change = sum(
                    abs(left_frame[base + channel] - right_frame[base + channel])
                    for channel in range(VISUAL_CHANNELS)
                ) / VISUAL_CHANNELS
                total += cell_change * weight
                weight_total += weight
        return total / max(1e-9, weight_total)

    def signature(self, features):
        quantized = bytes(max(0, min(7, int(value * 7.999))) for value in features)
        return hashlib.blake2b(quantized, digest_size=8).hexdigest()

    def sample_split(self, sample):
        key = f'{self.signature(sample["before"])}:{action_key(sample["action"])}'.encode("ascii")
        bucket = int.from_bytes(hashlib.blake2b(key, digest_size=2).digest(), "big") % 100
        if bucket < 70:
            return "train"
        if bucket < 90:
            return "validation"
        return "audit" if sample.get("policy", True) else "train"

    def _append_sample(self, sample):
        split = self.sample_split(sample)
        if split == "train":
            memory, limit = self.training_memory, MAX_TRAIN_MEMORY
        elif split == "validation":
            memory, limit = self.validation_memory, MAX_VALIDATION_MEMORY
        else:
            memory, limit = self.audit_memory, MAX_AUDIT_MEMORY
        memory.append(sample)
        if len(memory) > limit:
            del memory[: len(memory) - limit]

    @staticmethod
    def _decode_sample(item):
        if not isinstance(item, (list, tuple)) or len(item) < 9:
            return None
        before = decode_features(item[0])
        action = normalize_action(item[1])
        after = decode_features(item[2])
        passive_change = clamp(float(item[3]))
        causal_change = clamp(float(item[4]))
        local_causal = clamp(float(item[5]))
        novelty = clamp(float(item[6]))
        reward = clamp(float(item[7]))
        control = clamp(float(item[8]))
        if not all(math.isfinite(value) for value in (passive_change, causal_change, local_causal, novelty, reward, control)):
            return None
        return {
            "before": before,
            "action": action,
            "after": after,
            "passive": passive_change,
            "causal": causal_change,
            "local_causal": local_causal,
            "novelty": novelty,
            "reward": reward,
            "control": control,
        }

    @staticmethod
    def _encode_sample(sample):
        return [
            encode_features(sample["before"]),
            list(sample["action"]),
            encode_features(sample["after"]),
            round(sample["passive"], 6),
            round(sample["causal"], 6),
            round(sample["local_causal"], 6),
            round(sample["novelty"], 6),
            round(sample["reward"], 6),
            round(sample["control"], 6),
        ]

    def _load_file(self, path):
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        if int(data.get("version", 0)) != STATE_VERSION:
            raise ValueError("状态版本与当前双模型架构不兼容")
        world_model = TinyWorldModel.from_dict(data["model"])
        value_model = TinyValueModel.from_dict(data["value_model"])
        training_memory = []
        validation_memory = []
        audit_memory = []
        for item in data.get("training_memory", []):
            sample = self._decode_sample(item)
            if sample is not None:
                training_memory.append(sample)
        for item in data.get("validation_memory", []):
            sample = self._decode_sample(item)
            if sample is not None:
                validation_memory.append(sample)
        for item in data.get("audit_memory", []):
            sample = self._decode_sample(item)
            if sample is not None:
                audit_memory.append(sample)
        return data, world_model, value_model, training_memory, validation_memory, audit_memory

    def load(self):
        candidates = []
        if os.path.isfile(self.state_path):
            candidates.append((self.state_path, False))
        if os.path.isfile(self.backup_path):
            candidates.append((self.backup_path, True))
        if not candidates:
            return
        errors = []
        for path, is_backup in candidates:
            try:
                data, world_model, value_model, training_memory, validation_memory, audit_memory = self._load_file(path)
                self.model = world_model
                self.value_model = value_model
                self.generation = max(0, int(data.get("generation", 0)))
                self.audit_generation = max(0, int(data.get("audit_generation", self.generation)))
                if self.audit_generation != self.generation:
                    audit_memory = []
                    self.audit_generation = self.generation
                self.training_memory = training_memory[-MAX_TRAIN_MEMORY:]
                self.validation_memory = validation_memory[-MAX_VALIDATION_MEMORY:]
                self.audit_memory = audit_memory[-MAX_AUDIT_MEMORY:]
                raw_stats = data.get("action_stats", {})
                if isinstance(raw_stats, dict):
                    for key, values in raw_stats.items():
                        if not isinstance(key, str) or not isinstance(values, (list, tuple)) or len(values) < 4:
                            continue
                        self.action_stats[key] = [
                            max(0, int(values[0])),
                            clamp(float(values[1])),
                            clamp(float(values[2])),
                            clamp(float(values[3])),
                        ]
                self.seen = {
                    str(key): max(1, int(value))
                    for key, value in data.get("seen", {}).items()
                    if isinstance(key, str)
                }
                self.loaded_from_backup = is_backup
                source = "备份状态" if is_backup else "状态"
                print(
                    f"已载入{source}：第 {self.generation} 代，训练 {len(self.training_memory)} / "
                    f"验证 {len(self.validation_memory)} / future audit {len(self.audit_memory)} 条经验。"
                )
                if is_backup:
                    print("主状态文件不可用，已自动从 mouse_ai_state.json.bak 恢复。")
                return
            except Exception as error:
                errors.append(f"{os.path.basename(path)}: {error}")
        self.model = TinyWorldModel(self.rng)
        self.value_model = TinyValueModel(self.rng)
        self.generation = 0
        self.audit_generation = 0
        self.training_memory = []
        self.validation_memory = []
        self.audit_memory = []
        self.action_stats = {}
        self.seen = {}
        print("状态文件无法读取，将从新双模型大脑开始：" + "；".join(errors))

    def save(self):
        if len(self.seen) > MAX_SEEN_STATES:
            keep = sorted(self.seen.items(), key=lambda item: item[1], reverse=True)[: int(MAX_SEEN_STATES * 0.8)]
            self.seen = dict(keep)
        data = {
            "version": STATE_VERSION,
            "generation": self.generation,
            "audit_generation": self.audit_generation,
            "model": self.model.to_dict(),
            "value_model": self.value_model.to_dict(),
            "action_stats": self.action_stats,
            "seen": self.seen,
            "training_memory": [self._encode_sample(sample) for sample in self.training_memory[-MAX_TRAIN_MEMORY:]],
            "validation_memory": [self._encode_sample(sample) for sample in self.validation_memory[-MAX_VALIDATION_MEMORY:]],
            "audit_memory": [self._encode_sample(sample) for sample in self.audit_memory[-MAX_AUDIT_MEMORY:]],
        }
        temporary_path = self.state_path + ".tmp"
        with open(temporary_path, "w", encoding="utf-8") as file:
            json.dump(data, file, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            file.flush()
            os.fsync(file.fileno())
        if os.path.isfile(self.state_path) and not self.loaded_from_backup:
            backup_temp = self.backup_path + ".tmp"
            shutil.copyfile(self.state_path, backup_temp)
            with open(backup_temp, "rb+") as file:
                os.fsync(file.fileno())
            os.replace(backup_temp, self.backup_path)
        os.replace(temporary_path, self.state_path)
        self.loaded_from_backup = False

    def stats_for(self, action):
        key = action_key(action)
        stats = self.action_stats.get(key)
        if stats is None:
            stats = [0, 0.0, 0.08, 0.0]
            self.action_stats[key] = stats
        return stats

    def candidate_actions(self):
        candidates = list(BASE_ACTIONS)
        successful = []
        for key, stats in self.action_stats.items():
            if stats[0] < 2 or stats[1] < 0.015:
                continue
            try:
                parts = key.split(":")
                action = normalize_action((int(parts[0]), *(float(value) for value in parts[1:])))
            except (ValueError, TypeError):
                continue
            if action[0] == 0:
                successful.append((stats[1] + stats[3] * 0.25, action))
        successful.sort(reverse=True, key=lambda item: item[0])
        for _, action in successful[:4]:
            _, x, y, _, _ = action
            for dy in (-0.05, 0.0, 0.05):
                for dx in (-0.05, 0.0, 0.05):
                    if dx == 0.0 and dy == 0.0:
                        continue
                    nx, ny = clamp(x + dx, 0.04, 0.96), clamp(y + dy, 0.04, 0.96)
                    candidates.append(normalize_action((0, nx, ny, nx, ny)))
        unique = {}
        for action in candidates:
            unique[action_key(action)] = normalize_action(action)
        return list(unique.values())

    def choose_action(self, features):
        candidates = self.candidate_actions()
        exploration = max(0.10, 0.38 * (0.968 ** self.generation))
        if self.rng.random() < exploration:
            self.last_action_exploratory = True
            minimum = min(self.stats_for(action)[0] for action in candidates)
            pool = [action for action in candidates if self.stats_for(action)[0] <= minimum + 1]
            return self.rng.choice(pool)
        self.last_action_exploratory = False
        best_action = candidates[0]
        best_score = -float("inf")
        for action in candidates:
            predicted_reward, predicted_causal = self.value_model.predict(features, action)
            predicted_control = min(1.0, predicted_causal * 7.0)
            prediction = self.model.predict(features, action)
            predicted_change = min(1.0, self.frame_change(features, prediction) * 5.0)
            predicted_novelty = 1.0 / math.sqrt(self.seen.get(self.signature(prediction), 0) + 1.0)
            count, _effect_ema, _error_ema, learning_ema = self.stats_for(action)
            uncertainty = 1.0 / math.sqrt(count + 1.0)
            score = (
                predicted_reward * 0.50
                + predicted_control * 0.27
                + predicted_novelty * 0.10
                + predicted_change * 0.04
                + learning_ema * 0.03
                + uncertainty * 0.06
                + self.rng.random() * 0.003
            )
            if score > best_score:
                best_score, best_action = score, action
        return best_action

    @staticmethod
    def _ema(values):
        if not values:
            return 0.0
        value = values[0]
        for next_value in values[1:]:
            value = value * 0.60 + next_value * 0.40
        return value

    def observe(self, passive_history, before_state, action, after_visual):
        before_visual = passive_history[-1]
        after_state = state_from_visual(before_visual, after_visual)
        passive_changes = [
            self.visual_change(passive_history[index - 1], passive_history[index])
            for index in range(1, len(passive_history))
        ]
        passive_local_changes = [
            self.action_region_change(passive_history[index - 1], passive_history[index], action)
            for index in range(1, len(passive_history))
        ]
        passive_scale = CAUSAL_FRAME_SECONDS / max(0.001, PASSIVE_FRAME_INTERVAL)
        expected_passive_change = clamp(self._ema(passive_changes) * passive_scale)
        expected_passive_local = clamp(self._ema(passive_local_changes) * passive_scale)
        action_change = self.visual_change(before_visual, after_visual)
        action_local_change = self.action_region_change(before_visual, after_visual, action)
        global_causal = max(0.0, action_change - expected_passive_change)
        local_causal = max(0.0, action_local_change - expected_passive_local)
        causal_change = clamp(global_causal * 0.58 + local_causal * 0.42)
        after_signature = self.signature(after_state)
        visits = self.seen.get(after_signature, 0)
        novelty_reward = 1.0 / math.sqrt(visits + 1.0)
        controllability_reward = min(1.0, causal_change * 7.0)
        stats = self.stats_for(action)
        learning_reward = stats[3]
        reward = clamp(controllability_reward * 0.74 + novelty_reward * 0.26)
        if causal_change < 0.0015:
            reward *= 0.50
        world_sample = {"before": before_state, "action": action, "after": after_state}
        prediction_error = min(1.0, self.model.sample_loss(world_sample) * 12.0)
        value_prediction_error = min(
            1.0,
            self.value_model.sample_loss(
                {"before": before_state, "action": action, "reward": reward, "causal": causal_change}
            ) * 4.0,
        )
        count = stats[0]
        alpha = 0.18 if count < 12 else 0.08
        stats[0] = count + 1
        stats[1] = stats[1] * (1.0 - alpha) + controllability_reward * alpha
        stats[2] = stats[2] * (1.0 - alpha) + value_prediction_error * alpha
        self.seen[after_signature] = visits + 1
        sample = {
            "before": before_state,
            "action": normalize_action(action),
            "after": after_state,
            "passive": expected_passive_change,
            "causal": causal_change,
            "local_causal": local_causal,
            "novelty": novelty_reward,
            "reward": reward,
            "control": controllability_reward,
            "policy": not self.last_action_exploratory,
        }
        self._append_sample(sample)
        return {
            "reward": reward,
            "action_change": action_change,
            "passive_change": expected_passive_change,
            "causal_change": causal_change,
            "local_causal": local_causal,
            "controllability": controllability_reward,
            "novelty": novelty_reward,
            "learning": learning_reward,
            "prediction_error": prediction_error,
            "value_prediction_error": value_prediction_error,
        }

    @staticmethod
    def ability_from_loss(loss, scale):
        if not math.isfinite(loss):
            return 0.0
        return 100.0 / (1.0 + loss * scale)

    @staticmethod
    def control_ability(samples):
        if not samples:
            return 0.0
        return 100.0 * sum(sample["control"] for sample in samples) / len(samples)

    def ready_to_sleep(self):
        return len(self.training_memory) >= MIN_TRAIN_SAMPLES and len(self.validation_memory) >= MIN_VALIDATION_SAMPLES

    def _training_batch(self, seed_offset=0):
        training = self.training_memory
        if len(training) <= TRAIN_BATCH_LIMIT:
            return list(training)
        recent_count = TRAIN_BATCH_LIMIT // 2
        recent = training[-recent_count:]
        older = training[:-recent_count]
        rng = random.Random(self.generation * 1009 + len(training) * 17 + seed_offset * 7919)
        return rng.sample(older, TRAIN_BATCH_LIMIT - recent_count) + recent

    @staticmethod
    def _relative_gain(old_loss, new_loss):
        if not math.isfinite(old_loss) or old_loss <= 1e-12:
            return 0.0
        return (old_loss - new_loss) / old_loss

    def _apply_learning_gains(self, old_world, new_world, old_value, new_value, samples):
        grouped = {}
        for sample in samples:
            old_loss = old_world.sample_loss(sample) + old_value.sample_loss(sample)
            new_loss = new_world.sample_loss(sample) + new_value.sample_loss(sample)
            gain = 0.0 if old_loss <= 1e-12 else clamp((old_loss - new_loss) / old_loss)
            key = action_key(sample["action"])
            total, count = grouped.get(key, (0.0, 0))
            grouped[key] = (total + gain, count + 1)
        for key, (total, count) in grouped.items():
            stats = self.action_stats.get(key)
            if stats is not None:
                stats[3] = stats[3] * 0.75 + (total / max(1, count)) * 0.25

    def sleep_and_learn(self, stopped):
        started = time.monotonic()
        if not self.ready_to_sleep():
            return None
        validation = list(self.validation_memory)
        old_world = self.model
        old_value = self.value_model
        old_world_loss = old_world.loss(validation)
        old_value_loss = old_value.loss(validation)
        audit_count = len(self.audit_memory)
        audit_control = self.control_ability(self.audit_memory) if audit_count >= MIN_AUDIT_SAMPLES else None
        best_world, best_value = None, None
        best_world_loss, best_value_loss = old_world_loss, old_value_loss
        attempts = (
            (0.0045, 0.0100, 2),
            (0.0028, 0.0065, 3),
            (0.0018, 0.0040, 3),
            (0.0010, 0.0025, 4),
        )
        for attempt_index, (world_lr, value_lr, epochs) in enumerate(attempts):
            training = self._training_batch(attempt_index)
            candidate_world = copy.deepcopy(old_world)
            candidate_value = copy.deepcopy(old_value)
            candidate_rng = random.Random(self.generation * 100003 + attempt_index * 7919 + len(training) * 17)
            for _ in range(epochs):
                if not candidate_world.train_epoch(training, world_lr, candidate_rng, stopped):
                    return False
                if not candidate_value.train_epoch(training, value_lr, candidate_rng, stopped):
                    return False
            world_loss = candidate_world.loss(validation)
            value_loss = candidate_value.loss(validation)
            if world_loss < best_world_loss:
                best_world, best_world_loss = candidate_world, world_loss
            if value_loss < best_value_loss:
                best_value, best_value_loss = candidate_value, value_loss
        candidate_world = best_world if best_world is not None else old_world
        candidate_value = best_value if best_value is not None else old_value
        world_gain = self._relative_gain(old_world_loss, best_world_loss)
        value_gain = self._relative_gain(old_value_loss, best_value_loss)
        world_non_regression = best_world_loss <= old_world_loss * (1.0 + MAX_GATE_REGRESSION)
        value_non_regression = best_value_loss <= old_value_loss * (1.0 + MAX_GATE_REGRESSION)
        gate_gain = (max(0.0, world_gain) + max(0.0, value_gain)) * 0.5
        improved = bool(world_non_regression and value_non_regression and gate_gain >= MIN_GATE_IMPROVEMENT)
        learning_gain = 0.0
        if improved:
            probe = self._training_batch(999)[-48:] + validation[-18:]
            old_probe = old_world.loss(probe) + old_value.loss(probe)
            new_probe = candidate_world.loss(probe) + candidate_value.loss(probe)
            if old_probe > 1e-12:
                learning_gain = clamp((old_probe - new_probe) / old_probe)
            self._apply_learning_gains(old_world, candidate_world, old_value, candidate_value, probe)
            self.model = candidate_world
            self.value_model = candidate_value
            self.generation += 1
            self.audit_generation = self.generation
            self.audit_memory = []
        elapsed = time.monotonic() - started
        return {
            "improved": improved,
            "world_before": self.ability_from_loss(old_world_loss, 18.0),
            "world_after": self.ability_from_loss(best_world_loss, 18.0),
            "value_before": self.ability_from_loss(old_value_loss, 6.0),
            "value_after": self.ability_from_loss(best_value_loss, 6.0),
            "world_gain": world_gain,
            "value_gain": value_gain,
            "gate_gain": gate_gain,
            "audit_generation": self.audit_generation if not improved else self.generation - 1,
            "audit_count": audit_count,
            "audit_control": audit_control,
            "learning_gain": learning_gain,
            "remaining": max(0.0, MIN_SLEEP_SECONDS - elapsed),
        }


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", ctypes.c_long),
        ("top", ctypes.c_long),
        ("right", ctypes.c_long),
        ("bottom", ctypes.c_long),
    ]


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", ctypes.c_long),
        ("dy", ctypes.c_long),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_size_t),
    ]


class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("mi", MOUSEINPUT)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", ctypes.c_long),
        ("biHeight", ctypes.c_long),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", ctypes.c_long),
        ("biYPelsPerMeter", ctypes.c_long),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]


class MSG(ctypes.Structure):
    _fields_ = [
        ("hwnd", wintypes.HWND),
        ("message", wintypes.UINT),
        ("wParam", wintypes.WPARAM),
        ("lParam", wintypes.LPARAM),
        ("time", wintypes.DWORD),
        ("pt", POINT),
        ("lPrivate", wintypes.DWORD),
    ]


CALLBACK = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)
ENUMPROC = CALLBACK(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
HOOKPROC = CALLBACK(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)


if os.name == "nt":
    USER32 = ctypes.WinDLL("user32", use_last_error=True)
    GDI32 = ctypes.WinDLL("gdi32", use_last_error=True)
    KERNEL32 = ctypes.WinDLL("kernel32", use_last_error=True)
else:
    USER32 = GDI32 = KERNEL32 = None


def configure_windows_api():
    USER32.EnumWindows.argtypes = [ENUMPROC, wintypes.LPARAM]
    USER32.EnumWindows.restype = wintypes.BOOL
    USER32.EnumChildWindows.argtypes = [wintypes.HWND, ENUMPROC, wintypes.LPARAM]
    USER32.EnumChildWindows.restype = wintypes.BOOL
    USER32.IsWindow.argtypes = [wintypes.HWND]
    USER32.IsWindow.restype = wintypes.BOOL
    USER32.IsWindowVisible.argtypes = [wintypes.HWND]
    USER32.IsWindowVisible.restype = wintypes.BOOL
    USER32.IsIconic.argtypes = [wintypes.HWND]
    USER32.IsIconic.restype = wintypes.BOOL
    USER32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
    USER32.GetClientRect.restype = wintypes.BOOL
    USER32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
    USER32.ClientToScreen.restype = wintypes.BOOL
    USER32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    USER32.GetWindowTextLengthW.restype = ctypes.c_int
    USER32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    USER32.GetWindowTextW.restype = ctypes.c_int
    USER32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    USER32.GetClassNameW.restype = ctypes.c_int
    USER32.GetDC.argtypes = [wintypes.HWND]
    USER32.GetDC.restype = wintypes.HDC
    USER32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
    USER32.ReleaseDC.restype = ctypes.c_int
    USER32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    USER32.GetAncestor.restype = wintypes.HWND
    USER32.IsChild.argtypes = [wintypes.HWND, wintypes.HWND]
    USER32.IsChild.restype = wintypes.BOOL
    USER32.WindowFromPoint.argtypes = [POINT]
    USER32.WindowFromPoint.restype = wintypes.HWND
    USER32.SetForegroundWindow.argtypes = [wintypes.HWND]
    USER32.SetForegroundWindow.restype = wintypes.BOOL
    USER32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
    USER32.SetCursorPos.restype = wintypes.BOOL
    USER32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
    USER32.GetCursorPos.restype = wintypes.BOOL
    USER32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    USER32.SendInput.restype = wintypes.UINT
    USER32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    USER32.GetWindowThreadProcessId.restype = wintypes.DWORD
    USER32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    USER32.GetAsyncKeyState.restype = ctypes.c_short
    USER32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    USER32.SetWindowsHookExW.restype = wintypes.HHOOK
    USER32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    USER32.CallNextHookEx.restype = ctypes.c_ssize_t
    USER32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
    USER32.GetMessageW.argtypes = [ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
    USER32.GetMessageW.restype = wintypes.BOOL
    USER32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    USER32.TranslateMessage.argtypes = [ctypes.POINTER(MSG)]
    USER32.TranslateMessage.restype = wintypes.BOOL
    USER32.DispatchMessageW.argtypes = [ctypes.POINTER(MSG)]
    USER32.DispatchMessageW.restype = ctypes.c_ssize_t
    GDI32.CreateCompatibleDC.argtypes = [wintypes.HDC]
    GDI32.CreateCompatibleDC.restype = wintypes.HDC
    GDI32.CreateDIBSection.argtypes = [
        wintypes.HDC,
        ctypes.POINTER(BITMAPINFO),
        wintypes.UINT,
        ctypes.POINTER(ctypes.c_void_p),
        wintypes.HANDLE,
        wintypes.DWORD,
    ]
    GDI32.CreateDIBSection.restype = wintypes.HBITMAP
    GDI32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
    GDI32.SelectObject.restype = wintypes.HGDIOBJ
    GDI32.BitBlt.argtypes = [
        wintypes.HDC,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        ctypes.c_int,
        wintypes.HDC,
        ctypes.c_int,
        ctypes.c_int,
        wintypes.DWORD,
    ]
    GDI32.BitBlt.restype = wintypes.BOOL
    GDI32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
    GDI32.DeleteDC.argtypes = [wintypes.HDC]
    KERNEL32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    KERNEL32.GetModuleHandleW.restype = wintypes.HMODULE
    KERNEL32.GetCurrentThreadId.restype = wintypes.DWORD
    KERNEL32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    KERNEL32.OpenProcess.restype = wintypes.HANDLE
    KERNEL32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)
    ]
    KERNEL32.QueryFullProcessImageNameW.restype = wintypes.BOOL
    KERNEL32.CloseHandle.argtypes = [wintypes.HANDLE]
    KERNEL32.CloseHandle.restype = wintypes.BOOL


def set_dpi_awareness():
    try:
        USER32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        try:
            ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)
        except Exception:
            pass


def window_text(hwnd):
    length = USER32.GetWindowTextLengthW(hwnd)
    buffer = ctypes.create_unicode_buffer(max(1, length + 1))
    USER32.GetWindowTextW(hwnd, buffer, len(buffer))
    return buffer.value


def window_class(hwnd):
    buffer = ctypes.create_unicode_buffer(256)
    USER32.GetClassNameW(hwnd, buffer, len(buffer))
    return buffer.value


def client_rect_on_screen(hwnd):
    if not hwnd or not USER32.IsWindow(hwnd) or not USER32.IsWindowVisible(hwnd):
        return None
    root = USER32.GetAncestor(hwnd, 2) or hwnd
    if USER32.IsIconic(root):
        return None
    rectangle = RECT()
    if not USER32.GetClientRect(hwnd, ctypes.byref(rectangle)):
        return None
    origin = POINT(0, 0)
    if not USER32.ClientToScreen(hwnd, ctypes.byref(origin)):
        return None
    width = rectangle.right - rectangle.left
    height = rectangle.bottom - rectangle.top
    if width < 64 or height < 64:
        return None
    return origin.x, origin.y, origin.x + width, origin.y + height


def emulator_score(title, class_name):
    value = (title + " " + class_name).lower()
    score = 0
    for term in ("雷电", "ldplayer", "dnplayer", "leidian", "therender", "android emulator"):
        if term in value:
            score += 10
    return score


def window_process_id(hwnd):
    process_id = wintypes.DWORD()
    if not USER32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id)):
        return 0
    return int(process_id.value)


def process_executable(process_id):
    if not process_id:
        return ""
    handle = KERNEL32.OpenProcess(0x1000, False, process_id)
    if not handle:
        return ""
    try:
        capacity = wintypes.DWORD(32768)
        buffer = ctypes.create_unicode_buffer(capacity.value)
        if not KERNEL32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(capacity)):
            return ""
        return buffer.value
    finally:
        KERNEL32.CloseHandle(handle)


def is_ldplayer_process_path(path):
    basename = os.path.basename(os.path.normcase(path or "")).lower()
    terms = (
        "ldplayer",
        "dnplayer",
        "leidian",
        "ld9box",
        "ldvbox",
        "ldconsole",
        "ldmultiplayer",
        "dnmultiplayer",
    )
    return bool(basename and any(term in basename for term in terms))


def verified_ldplayer_outer(hwnd, title=None, class_name=None):
    if not hwnd or not USER32.IsWindow(hwnd):
        return False, 0, ""
    title = window_text(hwnd) if title is None else title
    class_name = window_class(hwnd) if class_name is None else class_name
    process_id = window_process_id(hwnd)
    executable = process_executable(process_id)
    score = emulator_score(title, class_name)
    if is_ldplayer_process_path(executable):
        score += 20
    return bool(score > 0 and executable and is_ldplayer_process_path(executable)), process_id, executable


def render_belongs_to_outer(render_hwnd, outer_hwnd, outer_process_id, outer_executable):
    if not render_hwnd or not USER32.IsWindow(render_hwnd) or not USER32.IsChild(outer_hwnd, render_hwnd):
        return False
    root = USER32.GetAncestor(render_hwnd, 2) or render_hwnd
    if int(root) != int(outer_hwnd):
        return False
    render_process_id = window_process_id(render_hwnd)
    if render_process_id == outer_process_id:
        return True
    render_executable = process_executable(render_process_id)
    if is_ldplayer_process_path(render_executable):
        return True
    if outer_executable and render_executable:
        return os.path.dirname(os.path.normcase(render_executable)) == os.path.dirname(os.path.normcase(outer_executable))
    return False


def enumerate_top_windows():
    records = []

    @ENUMPROC
    def callback(hwnd, _):
        if not USER32.IsWindowVisible(hwnd):
            return True
        title = window_text(hwnd).strip()
        if not title:
            return True
        rectangle = client_rect_on_screen(hwnd)
        if not rectangle:
            return True
        left, top, right, bottom = rectangle
        width, height = right - left, bottom - top
        if width < 300 or height < 220:
            return True
        class_name = window_class(hwnd)
        verified, process_id, executable = verified_ldplayer_outer(hwnd, title, class_name)
        score = emulator_score(title, class_name) + (20 if is_ldplayer_process_path(executable) else 0)
        records.append(
            {
                "hwnd": int(hwnd),
                "title": title,
                "class": class_name,
                "width": width,
                "height": height,
                "score": score,
                "verified": verified,
                "pid": process_id,
                "executable": executable,
            }
        )
        return True

    USER32.EnumWindows(callback, 0)
    records.sort(
        key=lambda item: (item["verified"], item["score"], item["width"] * item["height"]),
        reverse=True,
    )
    return records


def resolve_render_window(outer_hwnd):
    verified, outer_process_id, outer_executable = verified_ldplayer_outer(outer_hwnd)
    if not verified:
        return None
    outer_rectangle = client_rect_on_screen(outer_hwnd)
    if not outer_rectangle:
        return None
    outer_area = (outer_rectangle[2] - outer_rectangle[0]) * (outer_rectangle[3] - outer_rectangle[1])
    candidates = []

    @ENUMPROC
    def callback(hwnd, _):
        rectangle = client_rect_on_screen(hwnd)
        if not rectangle:
            return True
        area = (rectangle[2] - rectangle[0]) * (rectangle[3] - rectangle[1])
        value = (window_text(hwnd) + " " + window_class(hwnd)).lower()
        render_score = sum(term in value for term in ("render", "android", "subwin"))
        if (
            render_score
            and area >= outer_area * 0.20
            and render_belongs_to_outer(hwnd, outer_hwnd, outer_process_id, outer_executable)
        ):
            candidates.append((render_score, area, int(hwnd)))
        return True

    USER32.EnumChildWindows(outer_hwnd, callback, 0)
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][2]
    return None


def select_window_and_directory(default_directory):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    result = {"hwnd": None, "directory": None}
    root = tk.Tk()
    root.title("睡眠学习鼠标 AI")
    root.geometry("760x500")
    root.minsize(680, 430)
    root.columnconfigure(0, weight=1)
    root.rowconfigure(2, weight=1)

    ttk.Label(
        root,
        text="选择并确认雷电模拟器窗口。开启后，按键盘上的任意按键即可停止。",
        padding=(12, 12, 12, 8),
    ).grid(row=0, column=0, sticky="ew")

    directory_frame = ttk.Frame(root, padding=(12, 0, 12, 8))
    directory_frame.grid(row=1, column=0, sticky="ew")
    directory_frame.columnconfigure(1, weight=1)
    ttk.Label(directory_frame, text="数据文件夹：").grid(row=0, column=0, sticky="w")
    directory_value = tk.StringVar(value=default_directory)
    ttk.Entry(directory_frame, textvariable=directory_value).grid(row=0, column=1, sticky="ew", padx=6)

    def browse():
        selected = filedialog.askdirectory(initialdir=directory_value.get() or default_directory)
        if selected:
            directory_value.set(selected)

    ttk.Button(directory_frame, text="浏览…", command=browse).grid(row=0, column=2)

    list_frame = ttk.Frame(root, padding=(12, 0, 12, 8))
    list_frame.grid(row=2, column=0, sticky="nsew")
    list_frame.columnconfigure(0, weight=1)
    list_frame.rowconfigure(0, weight=1)
    window_list = tk.Listbox(list_frame, activestyle="dotbox", exportselection=False)
    scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=window_list.yview)
    window_list.configure(yscrollcommand=scrollbar.set)
    window_list.grid(row=0, column=0, sticky="nsew")
    scrollbar.grid(row=0, column=1, sticky="ns")
    records = []

    def refresh():
        nonlocal records
        records = enumerate_top_windows()
        window_list.delete(0, tk.END)
        preferred = None
        for index, item in enumerate(records):
            marker = "[已验证雷电] " if item["verified"] else "[未验证] "
            window_list.insert(
                tk.END,
                f'{marker}{item["title"]}  |  {item["class"]}  |  {item["width"]}×{item["height"]}',
            )
            if preferred is None and item["verified"]:
                preferred = index
        if records:
            selected_index = preferred if preferred is not None else 0
            window_list.selection_set(selected_index)
            window_list.see(selected_index)

    def confirm():
        selection = window_list.curselection()
        if not selection:
            messagebox.showerror("无法开启", "请先选择一个模拟器窗口。")
            return
        item = records[selection[0]]
        hwnd = item["hwnd"]
        if not client_rect_on_screen(hwnd):
            messagebox.showerror("无法开启", "该窗口已关闭、最小化或不可用，请刷新后重试。")
            return
        verified, _process_id, _executable = verified_ldplayer_outer(hwnd)
        if not verified:
            messagebox.showerror(
                "无法开启",
                "该窗口未通过雷电模拟器进程校验。为保证鼠标边界安全，AI 不会在此窗口启动。",
            )
            return
        target_hwnd = resolve_render_window(hwnd)
        if not target_hwnd:
            messagebox.showerror("无法开启", "未找到安卓渲染客户区，AI 不会控制整个模拟器窗口。")
            return
        raw_directory = directory_value.get().strip()
        if not raw_directory:
            messagebox.showerror("无法开启", "请指定数据文件夹。")
            return
        directory = os.path.abspath(os.path.expandvars(os.path.expanduser(raw_directory)))
        try:
            os.makedirs(directory, exist_ok=True)
            test_path = os.path.join(directory, f".mouse_ai_write_test_{os.getpid()}")
            with open(test_path, "wb") as file:
                file.write(b"ok")
            os.remove(test_path)
        except Exception as error:
            messagebox.showerror("无法开启", f"数据文件夹不可写：\n{error}")
            return
        result["hwnd"] = hwnd
        result["directory"] = directory
        USER32.SetForegroundWindow(hwnd)
        root.destroy()

    button_frame = ttk.Frame(root, padding=(12, 0, 12, 12))
    button_frame.grid(row=3, column=0, sticky="ew")
    ttk.Button(button_frame, text="刷新窗口列表", command=refresh).pack(side="left")
    ttk.Button(button_frame, text="确认窗口并开启 AI", command=confirm).pack(side="right")
    window_list.bind("<Double-Button-1>", lambda _event: confirm())
    refresh()
    root.mainloop()
    return result["hwnd"], result["directory"]


class KeyboardStopper:
    def __init__(self):
        self.event = threading.Event()
        self.ready = threading.Event()
        self.failed = False
        self.thread_id = 0
        self.hook = None
        self.callback = None
        self.thread = None

    @staticmethod
    def any_key_down():
        return any(USER32.GetAsyncKeyState(key) & 0x8000 for key in range(8, 256))

    def start(self):
        while self.any_key_down():
            time.sleep(0.02)
        for key in range(8, 256):
            USER32.GetAsyncKeyState(key)
        self.thread = threading.Thread(target=self._hook_loop, name="keyboard-stop", daemon=True)
        self.thread.start()
        if not self.ready.wait(2.0):
            self.failed = True

    def _hook_loop(self):
        self.thread_id = int(KERNEL32.GetCurrentThreadId())

        @HOOKPROC
        def callback(code, message, data):
            if code >= 0 and int(message) in (0x0100, 0x0104):
                self.event.set()
            return USER32.CallNextHookEx(self.hook, code, message, data)

        self.callback = callback
        module = KERNEL32.GetModuleHandleW(None)
        self.hook = USER32.SetWindowsHookExW(13, self.callback, module, 0)
        if not self.hook:
            self.failed = True
            self.ready.set()
            return
        self.ready.set()
        message = MSG()
        while USER32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
            USER32.TranslateMessage(ctypes.byref(message))
            USER32.DispatchMessageW(ctypes.byref(message))
        USER32.UnhookWindowsHookEx(self.hook)
        self.hook = None

    def stopped(self):
        if self.event.is_set():
            return True
        if self.failed and self.any_key_down():
            self.event.set()
            return True
        return False

    def close(self):
        if self.thread_id and self.hook:
            USER32.PostThreadMessageW(self.thread_id, 0x0012, 0, 0)
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=1.0)


def wait_interruptibly(seconds, stopper):
    deadline = time.monotonic() + max(0.0, seconds)
    while time.monotonic() < deadline:
        if stopper.stopped():
            return False
        time.sleep(min(0.02, max(0.0, deadline - time.monotonic())))
    return not stopper.stopped()


def point_belongs_to_window(x, y, target_hwnd):
    if not target_hwnd or not USER32.IsWindow(target_hwnd):
        return False
    rectangle = client_rect_on_screen(target_hwnd)
    if not rectangle:
        return False
    left, top, right, bottom = rectangle
    x, y = int(x), int(y)
    if not (left <= x < right and top <= y < bottom):
        return False
    hit = USER32.WindowFromPoint(POINT(x, y))
    if not hit:
        return False
    return int(hit) == int(target_hwnd) or bool(USER32.IsChild(target_hwnd, hit))


def client_visible_ratio(hwnd, columns=VISIBLE_SAMPLE_COLUMNS, rows=VISIBLE_SAMPLE_ROWS):
    rectangle = client_rect_on_screen(hwnd)
    if not rectangle:
        return 0.0
    left, top, right, bottom = rectangle
    width = right - left
    height = bottom - top
    total = columns * rows
    visible = 0
    for row in range(rows):
        y = top + round((row + 0.5) * height / rows)
        y = min(bottom - 2, max(top + 1, y))
        for column in range(columns):
            x = left + round((column + 0.5) * width / columns)
            x = min(right - 2, max(left + 1, x))
            if point_belongs_to_window(x, y, hwnd):
                visible += 1
    return visible / total


def client_is_visible(hwnd):
    return client_visible_ratio(hwnd) >= 1.0


def normalized_point(target_hwnd, x, y):
    rectangle = client_rect_on_screen(target_hwnd)
    if not rectangle:
        return None
    left, top, right, bottom = rectangle
    margin_x = max(2, int((right - left) * 0.01))
    margin_y = max(2, int((bottom - top) * 0.01))
    screen_x = round(left + margin_x + x * max(1, right - left - margin_x * 2 - 1))
    screen_y = round(top + margin_y + y * max(1, bottom - top - margin_y * 2 - 1))
    return screen_x, screen_y


def get_cursor_position():
    point = POINT()
    if not USER32.GetCursorPos(ctypes.byref(point)):
        return None
    return int(point.x), int(point.y)


def move_cursor_safely(target_hwnd, point):
    if not point or not point_belongs_to_window(point[0], point[1], target_hwnd):
        return None
    if not USER32.SetCursorPos(int(point[0]), int(point[1])):
        return None
    actual = get_cursor_position()
    if not actual or not point_belongs_to_window(actual[0], actual[1], target_hwnd):
        return None
    return actual


def safe_mouse_event(target_hwnd, flags, require_full_visibility=True):
    if flags not in (0x0002, 0x0004):
        return False
    if require_full_visibility and not client_is_visible(target_hwnd):
        return False
    actual = get_cursor_position()
    if not actual or not point_belongs_to_window(actual[0], actual[1], target_hwnd):
        return False
    event = INPUT(0, MOUSEINPUT(0, 0, 0, flags, 0, 0))
    return USER32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)) == 1


def safe_release_mouse(target_hwnd, preferred=None):
    candidates = []
    if preferred:
        candidates.append(preferred)
    rectangle = client_rect_on_screen(target_hwnd)
    if rectangle:
        left, top, right, bottom = rectangle
        for y_fraction in (0.50, 0.35, 0.65, 0.20, 0.80):
            for x_fraction in (0.50, 0.35, 0.65, 0.20, 0.80):
                candidates.append(
                    (
                        round(left + x_fraction * max(1, right - left - 1)),
                        round(top + y_fraction * max(1, bottom - top - 1)),
                    )
                )
    for point in candidates:
        actual = move_cursor_safely(target_hwnd, point)
        if actual and safe_mouse_event(target_hwnd, 0x0004, require_full_visibility=False):
            return True
    return False


def features_from_bgra(pixels, width, height):
    features = [0.0] * VISUAL_COUNT
    sample_fractions = (0.20, 0.50, 0.80)
    for grid_y in range(FEATURE_H):
        for grid_x in range(FEATURE_W):
            red_total = 0.0
            green_total = 0.0
            blue_total = 0.0
            lumas = []
            for y_fraction in sample_fractions:
                y = min(height - 1, int((grid_y + y_fraction) * height / FEATURE_H))
                row_lumas = []
                for x_fraction in sample_fractions:
                    x = min(width - 1, int((grid_x + x_fraction) * width / FEATURE_W))
                    offset = (y * width + x) * 4
                    blue = pixels[offset]
                    green = pixels[offset + 1]
                    red = pixels[offset + 2]
                    red_total += red
                    green_total += green
                    blue_total += blue
                    row_lumas.append(red * 0.299 + green * 0.587 + blue * 0.114)
                lumas.append(row_lumas)
            luma_values = [value for row in lumas for value in row]
            gradient_total = 0.0
            gradient_count = 0
            for row in range(3):
                for column in range(2):
                    gradient_total += abs(lumas[row][column + 1] - lumas[row][column])
                    gradient_count += 1
            for row in range(2):
                for column in range(3):
                    gradient_total += abs(lumas[row + 1][column] - lumas[row][column])
                    gradient_count += 1
            base = (grid_y * FEATURE_W + grid_x) * VISUAL_CHANNELS
            features[base] = red_total / (9.0 * 255.0)
            features[base + 1] = green_total / (9.0 * 255.0)
            features[base + 2] = blue_total / (9.0 * 255.0)
            features[base + 3] = (max(luma_values) - min(luma_values)) / 255.0
            features[base + 4] = gradient_total / (max(1, gradient_count) * 255.0)
    return features


def capture_features(hwnd):
    if not client_is_visible(hwnd):
        return None
    rectangle = client_rect_on_screen(hwnd)
    if not rectangle:
        return None
    left, top, right, bottom = rectangle
    width, height = right - left, bottom - top
    screen_dc = USER32.GetDC(None)
    if not screen_dc:
        return None
    memory_dc = GDI32.CreateCompatibleDC(screen_dc)
    if not memory_dc:
        USER32.ReleaseDC(None, screen_dc)
        return None
    bitmap = None
    old_object = None
    try:
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = width
        info.bmiHeader.biHeight = -height
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0
        bits = ctypes.c_void_p()
        bitmap = GDI32.CreateDIBSection(screen_dc, ctypes.byref(info), 0, ctypes.byref(bits), None, 0)
        if not bitmap or not bits:
            return None
        old_object = GDI32.SelectObject(memory_dc, bitmap)
        if not GDI32.BitBlt(memory_dc, 0, 0, width, height, screen_dc, left, top, 0x40CC0020):
            return None
        if not client_is_visible(hwnd):
            return None
        pixels = ctypes.string_at(bits, width * height * 4)
        return features_from_bgra(pixels, width, height)
    finally:
        if old_object:
            GDI32.SelectObject(memory_dc, old_object)
        if bitmap:
            GDI32.DeleteObject(bitmap)
        if memory_dc:
            GDI32.DeleteDC(memory_dc)
        if screen_dc:
            USER32.ReleaseDC(None, screen_dc)


def unconditional_left_up():
    event = INPUT(0, MOUSEINPUT(0, 0, 0, 0x0004, 0, 0))
    return USER32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT)) == 1


def safe_click_pair(target_hwnd):
    if not client_is_visible(target_hwnd):
        return False
    actual = get_cursor_position()
    if not actual or not point_belongs_to_window(actual[0], actual[1], target_hwnd):
        return False
    events = (INPUT * 2)(
        INPUT(0, MOUSEINPUT(0, 0, 0, 0x0002, 0, 0)),
        INPUT(0, MOUSEINPUT(0, 0, 0, 0x0004, 0, 0)),
    )
    sent = USER32.SendInput(2, events, ctypes.sizeof(INPUT))
    if sent != 2:
        unconditional_left_up()
        return False
    return True


def action_window_valid(
    outer_hwnd,
    target_hwnd,
    expected_outer_pid,
    expected_outer_executable,
    expected_render_pid,
    expected_render_executable,
    expected_outer_rect,
    expected_target_rect,
):
    if not outer_hwnd or not target_hwnd or not USER32.IsWindow(outer_hwnd) or not USER32.IsWindow(target_hwnd):
        return False
    verified, current_outer_pid, current_outer_executable = verified_ldplayer_outer(outer_hwnd)
    if not verified or current_outer_pid != expected_outer_pid:
        return False
    if os.path.normcase(current_outer_executable or "") != os.path.normcase(expected_outer_executable or ""):
        return False
    current_render_pid = window_process_id(target_hwnd)
    current_render_executable = process_executable(current_render_pid)
    if current_render_pid != expected_render_pid:
        return False
    if os.path.normcase(current_render_executable or "") != os.path.normcase(expected_render_executable or ""):
        return False
    if not render_belongs_to_outer(
        target_hwnd, outer_hwnd, expected_outer_pid, expected_outer_executable
    ):
        return False
    if client_rect_on_screen(outer_hwnd) != expected_outer_rect:
        return False
    if client_rect_on_screen(target_hwnd) != expected_target_rect:
        return False
    return client_is_visible(target_hwnd)

def execute_action(outer_hwnd, target_hwnd, action, stopper):
    kind, x1, y1, x2, y2 = normalize_action(action)
    verified, expected_outer_pid, expected_outer_executable = verified_ldplayer_outer(outer_hwnd)
    expected_outer_rect = client_rect_on_screen(outer_hwnd)
    expected_target_rect = client_rect_on_screen(target_hwnd)
    expected_render_pid = window_process_id(target_hwnd)
    expected_render_executable = process_executable(expected_render_pid)
    if not verified or not expected_outer_rect or not expected_target_rect or not expected_render_pid:
        return False

    def still_same_window():
        return action_window_valid(
            outer_hwnd,
            target_hwnd,
            expected_outer_pid,
            expected_outer_executable,
            expected_render_pid,
            expected_render_executable,
            expected_outer_rect,
            expected_target_rect,
        )

    if not still_same_window():
        return False
    start_point = normalized_point(target_hwnd, x1, y1)
    actual = move_cursor_safely(target_hwnd, start_point)
    if not actual:
        return False
    if not wait_interruptibly(0.06, stopper):
        return False
    if not still_same_window():
        return False
    actual = get_cursor_position()
    if not actual or not point_belongs_to_window(actual[0], actual[1], target_hwnd):
        return False
    if kind == 0:
        return safe_click_pair(target_hwnd) and not stopper.stopped()
    if not safe_mouse_event(target_hwnd, 0x0002):
        return False
    button_is_down = True
    last_safe = get_cursor_position() or actual
    completed = True
    try:
        for step in range(1, 13):
            if not still_same_window():
                completed = False
                break
            ratio = step / 12.0
            point = normalized_point(target_hwnd, x1 + (x2 - x1) * ratio, y1 + (y2 - y1) * ratio)
            if not point:
                completed = False
                break
            actual = move_cursor_safely(target_hwnd, point)
            if not actual:
                completed = False
                break
            last_safe = actual
            if not wait_interruptibly(0.025, stopper):
                completed = False
                break
        if not still_same_window():
            completed = False
    finally:
        if button_is_down:
            if still_same_window():
                released = safe_release_mouse(target_hwnd, last_safe)
                if released:
                    button_is_down = False
                else:
                    completed = False
            if button_is_down:
                if not unconditional_left_up():
                    completed = False
                button_is_down = False
    return completed and not stopper.stopped()

def run_ai(outer_hwnd, data_directory):
    state_path = os.path.join(data_directory, "mouse_ai_state.json")
    brain = Brain(state_path)
    USER32.SetForegroundWindow(outer_hwnd)
    time.sleep(0.20)
    stopper = KeyboardStopper()
    stopper.start()
    print("AI 已开启。按键盘上的任意按键停止。")
    print("控制边界：仅限已确认雷电模拟器的安卓渲染客户区；35/35 可见采样点用于遮挡筛查，实际动作点仍逐点复核。")
    print("学习目标：world model + action-value model；候选只由 train→validation/gate 决定，future audit 只评价已部署代。")
    awake_round = 0
    recovery_started = None
    recovery_reason = None
    recovery_timed_out = False
    experiences_since_save = 0

    def save_brain(label):
        try:
            brain.save()
            return True
        except Exception as error:
            print(f"{label}保存失败：{error}")
            return False

    def recovery_wait(reason, delay):
        nonlocal recovery_started, recovery_reason, recovery_timed_out
        now = time.monotonic()
        if recovery_started is None:
            recovery_started = now
            recovery_reason = reason
            print(f"  [安全暂停] {reason}；自动等待，最多 {MAX_RECOVERY_SECONDS:.0f} 秒。")
        else:
            recovery_reason = reason
        elapsed = now - recovery_started
        remaining = MAX_RECOVERY_SECONDS - elapsed
        if remaining <= 0.0:
            recovery_timed_out = True
            print(f"  [安全关闭] {recovery_reason}持续超过 {MAX_RECOVERY_SECONDS:.0f} 秒，AI 自动停止并保存状态。")
            return False
        return wait_interruptibly(min(delay, remaining), stopper)

    def recovery_clear():
        nonlocal recovery_started, recovery_reason
        if recovery_started is not None:
            print("  [安全恢复] 安卓客户区 35/35 可见采样点重新通过，继续运行。")
        recovery_started = None
        recovery_reason = None

    try:
        while not stopper.stopped():
            if not USER32.IsWindow(outer_hwnd):
                print("模拟器窗口已关闭，AI 停止。")
                break
            target_hwnd = resolve_render_window(outer_hwnd)
            if not target_hwnd:
                if not recovery_wait("无法确认雷电安卓渲染客户区", 0.5):
                    break
                continue
            if not client_is_visible(target_hwnd):
                if not recovery_wait("安卓客户区可见采样点未全部通过", 0.45):
                    break
                continue
            recovery_clear()
            awake_round += 1
            print(f"[清醒 {awake_round}] 正在观察、估计自然动态并仅用鼠标探索。")
            completed_steps = 0
            while completed_steps < AWAKE_STEPS and not stopper.stopped():
                target_hwnd = resolve_render_window(outer_hwnd)
                if not target_hwnd:
                    if not recovery_wait("无法确认雷电安卓渲染客户区", 0.4):
                        break
                    continue
                if not client_is_visible(target_hwnd):
                    if not recovery_wait("安卓客户区未达到 35/35 可见采样点通过", 0.45):
                        break
                    continue
                passive_history = []
                capture_failed = False
                for passive_index in range(PASSIVE_HISTORY_COUNT):
                    if passive_index > 0:
                        if not wait_interruptibly(PASSIVE_FRAME_INTERVAL, stopper):
                            capture_failed = True
                            break
                    current_target = resolve_render_window(outer_hwnd)
                    if current_target != target_hwnd or not client_is_visible(target_hwnd):
                        capture_failed = True
                        break
                    frame = capture_features(target_hwnd)
                    if frame is None:
                        capture_failed = True
                        break
                    passive_history.append(frame)
                if stopper.stopped():
                    break
                if capture_failed or len(passive_history) < PASSIVE_HISTORY_COUNT:
                    if not recovery_wait("被动帧采集失败、窗口变化或可见性发生变化", 0.35):
                        break
                    continue
                recovery_clear()
                before_visual = passive_history[-1]
                before_state = state_from_visual(passive_history[-2], before_visual)
                action = brain.choose_action(before_state)
                action_window_started = time.monotonic()
                if not execute_action(outer_hwnd, target_hwnd, action, stopper):
                    if stopper.stopped():
                        break
                    if not recovery_wait("鼠标真实位置、窗口身份或边界安全校验未通过", 0.25):
                        break
                    continue
                action_elapsed = time.monotonic() - action_window_started
                if not wait_interruptibly(max(0.0, CAUSAL_FRAME_SECONDS - action_elapsed), stopper):
                    break
                if resolve_render_window(outer_hwnd) != target_hwnd or not client_is_visible(target_hwnd):
                    if not recovery_wait("动作后安卓客户区发生变化或可见采样点未通过", 0.35):
                        break
                    continue
                after_visual = capture_features(target_hwnd)
                if after_visual is None:
                    if not recovery_wait("动作后画面采集失败", 0.35):
                        break
                    continue
                recovery_clear()
                feedback = brain.observe(passive_history, before_state, action, after_visual)
                completed_steps += 1
                experiences_since_save += 1
                if experiences_since_save >= AUTOSAVE_EVERY_EXPERIENCES:
                    if save_brain("周期性原子"):
                        experiences_since_save = 0
                if completed_steps % 8 == 0:
                    print(
                        f'  经验 {completed_steps}/{AWAKE_STEPS}，综合反馈 {feedback["reward"]:.3f}，'
                        f'实际可控性 {feedback["controllability"]:.3f}，局部因果 {feedback["local_causal"]:.4f}，'
                        f'world误差 {feedback["prediction_error"]:.3f}，value误差 {feedback["value_prediction_error"]:.3f}'
                    )
            if stopper.stopped() or recovery_timed_out:
                break
            if completed_steps < AWAKE_STEPS:
                continue
            if not brain.ready_to_sleep():
                print(
                    f"[意识] 本轮结束，但训练条件尚未满足，保持清醒继续采集："
                    f"train {len(brain.training_memory)}/{MIN_TRAIN_SAMPLES}，"
                    f"validation {len(brain.validation_memory)}/{MIN_VALIDATION_SAMPLES}。"
                )
                continue
            print("[意识] 训练与验证数据已达到门槛，意识到该睡觉了。")
            print("[睡觉] 同时训练 world model 与 action-value model；future audit 不参与候选选择，睡眠期间不控制鼠标。")
            report = brain.sleep_and_learn(stopper.stopped)
            if report is False or stopper.stopped():
                break
            if report is None:
                continue
            if not wait_interruptibly(report["remaining"], stopper):
                break
            if report["audit_control"] is None:
                print(
                    f'[future audit] 第 {report["audit_generation"]} 代新鲜审计样本 '
                    f'{report["audit_count"]}/{MIN_AUDIT_SAMPLES}，样本不足，只记录不参与本次 gate。'
                )
            else:
                print(
                    f'[future audit] 第 {report["audit_generation"]} 代 control_ability（真实已执行动作）'
                    f'{report["audit_control"]:.2f}，共 {report["audit_count"]} 条新鲜样本；该结果未参与本次候选接纳。'
                )
            if report["improved"]:
                print(
                    f'[睡觉] validation/gate：world_model_ability {report["world_before"]:.2f} → {report["world_after"]:.2f}；'
                    f'action_value_ability {report["value_before"]:.2f} → {report["value_after"]:.2f}；'
                    f'综合相对提升 {report["gate_gain"] * 100:.2f}%。'
                )
                print(f"[睡觉] 已接受第 {brain.generation} 代双模型；下一轮清醒才会产生这一代的 future audit。")
            else:
                print(
                    f'[睡觉] 已尝试多组 batch/学习率/轮数，但 gate 未达到至少 {MIN_GATE_IMPROVEMENT * 100:.2f}% 的综合提升且双模型零回退；'
                    f'world 相对变化 {report["world_gain"] * 100:.2f}%，value 相对变化 {report["value_gain"] * 100:.2f}%。旧模型保持不变。'
                )
            if save_brain("睡眠后原子"):
                experiences_since_save = 0
            print("[清醒] 睡醒，开始下一轮。")
    finally:
        save_brain("退出时原子")
        stopper.close()
    print("AI 已关闭。")

def main():
    if os.name != "nt":
        raise SystemExit("此程序仅支持 Windows 11。")
    configure_windows_api()
    set_dpi_awareness()
    script_directory = os.path.dirname(os.path.abspath(sys.argv[0]))
    default_directory = os.path.join(script_directory, "AI_Data")
    outer_hwnd, data_directory = select_window_and_directory(default_directory)
    if not outer_hwnd:
        return
    run_ai(outer_hwnd, data_directory)


if __name__ == "__main__":
    main()
