本地无固定容量上限 AI — 交付版说明
日期：2026-08-10

一、产品目标与表述
- 本程序不承诺有限机器上的“智商无上限”。可交付、可验证的目标是：能力架构不设置固定硬编码等级上限。
- ReasoningBackend、视觉/OCR、规划等能力接口可持续替换为更强版本；本地 Agent 负责状态、长期记忆、安全、验证和键鼠操作。
- 未配置外部推理后端时，安全回退到本地 GoalCompiler + Double-Q/记忆层，不把该回退层描述成通用高级推理模型。

二、运行环境与数据目录
- Windows 11 x64，Windows build >= 22000。
- 支持 CPython 3.11–3.14 64-bit；推荐 CPython 3.12/3.13 64-bit。
- NumPy 可选；未安装仍可运行。
- 默认数据优先写入 code.py 同目录下 local_ai_data；同目录不可写时才回退到用户本地应用数据目录。
- 严格便携模式：在 code.py 同目录创建空文件 portable.flag，或使用 code.py --portable 启动。此模式下如果同目录不可写，会直接报错，不回退 AppData。

三、真正的全局联网总开关
GUI 现在只有一个总权限语义：
“允许程序联网（包括推理后端、网页读取）”。

默认关闭。关闭时：
- ReasoningBackend 不会发起 HTTP/HTTPS 请求。
- 即使存在 LOCAL_AI_REASONING_URL 环境变量，也只保留配置值，不创建网络连接。
- ExternalKnowledgeFetcher 不会读取网页，并且在 DNS/socket 前就被全局 NetworkPermission 拒绝。
- 当前代码中的所有网络路径共用同一会话 NetworkPermission。

开启时：
- 用户填写的网页/文档 URL 才允许读取。
- ReasoningBackend URL 才允许调用。
- 远程 ReasoningBackend 默认必须使用 HTTPS。
- http://127.0.0.1、http://localhost、http://[::1] 等回环地址允许作为本地模型服务。
- 其他非本机 HTTP 默认拒绝。只有用户明确勾选“高级：明确允许非本机明文 HTTP 推理”后才放行；该选项仍受全局联网总开关约束。

四、ReasoningBackend 视觉传输性能
原先的“未压缩 PPM -> Base64 -> JSON”已改为标准库 PNG：
- PNG 使用 struct + zlib 编码，不新增 Pillow 依赖。
- 正常重新规划：只发送 UIA/语义，不发送截图。
- UIA/语义不足：升级发送 ROI PNG。
- 同一受限观察仍不足：再升级为缩放全屏 PNG。
- screen 字段包含 tier、viewport 与 coordinate_space="screen-normalized"，便于后端理解 ROI 对应的全屏位置。

后端请求中的视觉字段：
- visual_elements：UIA 优先的统一元素。
- screen：可选 image/png Base64；不是每次请求都存在。

五、远程视觉坐标不再是安全证据
远程模型的 confidence、bbox、x/y 只作为“操作建议”，不能自行获得 SafetyPolicy 放行。

对于 ReasoningBackend 给出的非 UIA CLICK：
1. 执行前重新感知当前窗口。
2. 在目标附近用本地 WinIO 连续采样两帧视觉探针。
3. 只有两帧局部画面足够稳定，才形成“本地稳定视觉目标”证据。
4. 本地 SafetyPolicy 再根据视觉文字/动作标签推断 capability。
5. “发送、提交、上传、发布、保存、删除、安装、购买、支付、登录”等语义会触发对应副作用能力判断。
6. 如果没有 UIA，又无法可靠判断是低风险导航，即使两帧稳定，也要求一次性人工确认。
7. 自主模式仍只允许有 UIA 证据的低风险导航点击；非 UIA 自绘/纯坐标点击不会借远程 confidence 绕过限制。

本地 GoalCompiler 明确提供的本地目标点和内部 E2E 自检仍保留其本地可信标记，与远程视觉建议区分。

六、任务模式：完成、失败、恢复
“发送” / Enter：mode="task"
- 必须填写明确任务。
- 隐藏主界面后执行。
- 只有目标特定完成证据稳定成立，才宣布完成。
- 完成后立即 seal_input_gate()，停止本会话输入并恢复主界面。

新增可靠失败退出：
- 不是固定“100 步超时”。
- 综合“无进展有效重规划数、同一阻断原因重复次数、ReasoningBackend 连续失败次数、compiler stalled 次数”判断。
- 在约 30–50 次无可靠进展的重新规划区间内达到组合条件时，关闭输入并退出。
- 用户看到：“任务未完成：无法获得可靠操作/完成证据”。
- 不会因为无法理解任务或长期无法识别页面而无限 WAIT/重规划。

七、自主模式：清醒 -> 睡眠 -> 醒来 -> 继续
“开始（自主）”：mode="autonomous"
- 保留原 MetaCognitiveSleep 的不确定性、失败、经验、碎片化等因素。
- 新增 maintenance_debt：由长期清醒累计、待整理经验、记忆碎片、训练债务等连续推动。
- 它不是“每 N 步强制睡眠”的固定硬上限；压力连续累积，长期自主运行最终会自然越过睡眠阈值。
- 睡眠完成后按 wake 阈值醒来并继续控制。

GUI 会直接显示自主模式当前权限，例如：
- 鼠标：移动 / 滚动 / 安全导航点击（若用户允许点击）。
- 键盘：仅导航键（若用户允许键盘）。
- 文本输入：禁止。
- 发送 / 保存 / 删除 / 安装 / 购买 / 支付 / 登录：禁止。

八、ESC 与输入安全
- ESC 专用于紧急停止。
- 硬输入闸门优先关闭，然后 worker 停止并恢复主界面。
- Secure Desktop / 无法确认输入桌面时继续 fail-closed。
- ReasoningBackend 的任何动作都必须经过 SafetyPolicy -> WinIO，不存在直接 SendInput 旁路。

九、ReasoningBackend JSON v1 关键字段
请求：
- protocol: "local-ai-reasoning-v1"
- mode: "task" / "autonomous"
- goal / success_text
- task_graph
- observation: window_title/window_class/process_name/semantic_text/signature/uia_quality
- visual_elements
- allowed_actions
- screen: 可选 PNG；包含 mime/base64/width/height/tier/viewport/coordinate_space

后端可返回：
- task_graph
- visual_elements
- action

注意：后端 action 中的 required_capabilities 只会增加限制，不能替代本地安全推断；远程 confidence 也不能作为安全放行证据。

十、交付验证说明
本包已完成：
- Python py_compile 语法检查。
- AST 解析检查。
- 模块导入级烟测（未启动 GUI、未执行真实 Windows 键鼠控制）。
- 标准库 PNG 编码签名检查。
- 全局断网阻止 ReasoningBackend 的连接检查。
- 全局断网阻止 ExternalKnowledgeFetcher 在 DNS 前触网检查。
- 远程 HTTP 默认拒绝 / 高级显式放行分支检查。
- 远程纯坐标不会生成本地可信 explicit_visual_target 检查。
- 非 UIA 远程点击两帧/确认策略检查。
- maintenance_debt 长期触发睡眠检查。
- portable.flag / --portable 严格目录逻辑检查。

由于当前构建环境不是 Windows 11，本交付未在此环境执行真实 SendInput E2E。程序自身保留“运行完整诊断（含真实 SendInput E2E）”按钮，建议最终用户首次部署时在目标 Windows 11 x64 机器上运行一次完整诊断。
