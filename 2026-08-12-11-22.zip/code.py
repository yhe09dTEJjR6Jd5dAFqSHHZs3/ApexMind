import ast
import ctypes
from ctypes import wintypes
from array import array
import base64
from collections import Counter, OrderedDict, deque
from dataclasses import dataclass, field
import heapq
import hashlib
import json
import math
import multiprocessing
import os
from pathlib import Path
import queue
import random
import re
import secrets
import shutil
import sqlite3
import struct
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox
import uuid
import zlib

# 所有可生成文件的首选位置统一由 RuntimePaths 提供；不可写时仅数据目录允许回退 LOCALAPPDATA。
LOCAL_DEPENDENCY_DIR_NAME = ".local_ai_deps"
LOCAL_TEMP_DIR_NAME = ".local_ai_tmp"



@dataclass(frozen=True)
class RuntimePaths:
    base_dir: Path = field(default_factory=lambda: Path(__file__).resolve().parent)

    @property
    def data_dir(self): return self.base_dir / "local_ai_data"

    @property
    def dependency_dir(self): return self.base_dir / LOCAL_DEPENDENCY_DIR_NAME

    @property
    def temp_dir(self): return self.base_dir / LOCAL_TEMP_DIR_NAME

    def data_candidates(self):
        candidates = [self.data_dir]
        local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
        if local_appdata:
            candidates.append(Path(local_appdata) / "LocalAI")
        else:
            candidates.append(Path.home() / "AppData" / "Local" / "LocalAI")
        return candidates

RUNTIME_PATHS = RuntimePaths()

# NumPy 是唯一允许的第三方计算依赖，但只是可选加速器，不是启动硬依赖。
# 若系统已有 pip，可在 AI 活动开始前用 pip --target 安装到 code.py 同目录；无 pip/安装失败时使用 stdlib-array 后端。
def _local_dependency_dir():
    return RUNTIME_PATHS.dependency_dir


def _activate_local_dependency_dir():
    target = str(_local_dependency_dir())
    if target not in sys.path:
        sys.path.insert(0, target)
    return target


_activate_local_dependency_dir()
try:
    import numpy as _np
except Exception:
    _np = None


APP_NAME = "本地自成长 AI"
FORMAT_VERSION = 11
PYTHON_MIN = (3, 11)
PYTHON_MAX_EXCLUSIVE = (3, 15)
PYTHON_RECOMMENDED = "CPython 3.12/3.13 64-bit"

# 单文件交付 ≠ 内部耦合。九层架构契约（依赖尽量向下，通过 dataclass/字典快照传递）：
# Platform   : ResourceBudget / Win32 原语 / SharedInputGate
# Perception : AccessibilitySnapshot / AccessibilityReader / VisualElement / UnifiedVisualPerception / Observation / WinIO.capture
# Reasoning  : ReasoningBackend / SymbolicWorldState / GenericOperatorPlanner（本地前置/效果搜索）
# Goal       : TaskDSLNode / GoalCompiler 2.0 / GoalEngine / GoalStateVerifier（控制流与对象级验证）
# Safety     : SessionCapabilityDomain / ExternalAIDelegationPolicy / SafetyPolicy / hard input gate（ReasoningBackend 不可绕过）
# Planner    : WorldModel / ActionPlanner（Operator A* 生成合法候选，Double-Q 仅做经验排序）
# Learning   : DoubleQNetwork / RewardEngine / MetaCognitiveSleep / SkillManager（经验优化层，不再承担高级推理大脑）
# Memory     : LongTermMemory / SQLite tiers / SleepReport / strategy memory
# Runtime    : AgentRuntime / LocalAgent / EscapeWatchdog / worker supervisor
# GUI        : Application

                                      
GLOBAL_W = 24
GLOBAL_H = 14
# 全局保持低分辨率；ROI 本身提高到可辨认 UI 细节的基础分辨率，并可按资源继续建立更高分辨率金字塔。
PATCH_W = 32
PATCH_H = 20
PATCH_COUNT = 3
GLOBAL_FEATURES = GLOBAL_W * GLOBAL_H * 4
PATCH_FEATURES = PATCH_W * PATCH_H * 4 * PATCH_COUNT
UI_FEATURES = 128
OBS_EXTRA = 32
GOAL_FEATURES = 64
MEMORY_FEATURES = 32
BASE_FEATURE_COUNT = GLOBAL_FEATURES + PATCH_FEATURES + UI_FEATURES + OBS_EXTRA + GOAL_FEATURES + MEMORY_FEATURES
# 兼容旧模型/旧经验的基础输入宽度。运行时模型可在此基础上继续扩展输入维度。
FEATURE_COUNT = BASE_FEATURE_COUNT

WAIT, SLEEP, MOVE, CLICK, SCROLL, KEY, TYPE, SKILL = range(8)
ACTION_NAMES = ("等待", "睡眠", "移动", "点击", "滚动", "按键", "输入文本", "调用技能")
ACTION_COUNT = len(ACTION_NAMES)
PARAM_COUNT = 3
PARAM_HEAD_SIZES = (1, 0, 2, 3, 1, 1, 1, 1)
SCHEMA_VERSION = 10
SESSION_LOG_KEEP = 40
SESSION_LOG_SOFT_BYTES = 32 * 1024 * 1024
N_STEP = 3
CHECKPOINT_KEEP = 8
TARGET_SYNC_INTERVAL = 64
MODEL_FILE_NAME = "model.bin"
DATABASE_FILE_NAME = "memory.sqlite3"
MODEL_MAGIC = b"LAI7BIN\0"
STORAGE_MANIFEST_FILE_NAME = "storage_manifest.json"
STORAGE_USAGE_FILE_NAME = "storage_usage.json"
SLEEP_WORK_SLICE_SECONDS = 18.0
SLEEP_EVAL_INTERVAL = 24
SLEEP_NO_GAIN_PATIENCE = 3
SLEEP_MIN_RELATIVE_GAIN = 0.001
SLEEP_MIN_GAIN_PER_SECOND = 0.00008

# 容量没有设计时的“最终值”。下列只是各类热数据的资源占比和近似字节成本；
# ResourceBudget 会按当时可用 RAM、磁盘和实际延迟持续重算本轮可用容量。
HOT_MEMORY_PROFILE = {
    "episodic_memory": (0.34, 11000), "state_memory": (0.12, 5600),
    "skill_memory": (0.10, 6200), "failure_memory": (0.05, 1500),
    "text_memory": (0.04, 1000), "semantic_knowledge": (0.12, 2600),
    "world_transition": (0.15, 10500), "sleep_report": (0.03, 3600),
    "strategy_memory": (0.05, 2800),
}
SLEEP_ENTER_THRESHOLD = 0.68
SLEEP_WAKE_THRESHOLD = 0.34
MAX_CONTINUOUS_AWAKE_SECONDS = 300.0
ESC_E2E_ATTESTATION_FILE = "esc_e2e_attestation.json"
PRODUCT_FLOW_E2E_ATTESTATION_FILE = "product_flow_e2e_attestation.json"
STARTUP_STATIC_ATTESTATION_FILE = "startup_static_attestation.json"
PROCESSOR_ARCHITECTURE_AMD64 = 9
ESC_WORKER_KILL_GRACE = 0.35

STATE_IDLE = "idle"
STATE_TASK_ACTIVE = "task_active"
STATE_FREE_ACTIVE = "free_active"
STATE_FREE_SLEEP_PREPARE = "free_sleep_prepare"
STATE_SLEEPING = "sleeping"
STATE_FREE_WAKE_PREPARE = "free_wake_prepare"
STATE_STOPPING = "stopping"


class SessionStateMachine:
    """显式会话状态机：所有 GUI/任务/自由/睡眠恢复顺序都必须经过这里。"""
    _ALLOWED = {
        STATE_IDLE: {STATE_TASK_ACTIVE, STATE_FREE_ACTIVE},
        STATE_TASK_ACTIVE: {STATE_STOPPING},
        STATE_FREE_ACTIVE: {STATE_FREE_SLEEP_PREPARE, STATE_STOPPING},
        STATE_FREE_SLEEP_PREPARE: {STATE_SLEEPING, STATE_STOPPING},
        STATE_SLEEPING: {STATE_FREE_WAKE_PREPARE, STATE_STOPPING},
        STATE_FREE_WAKE_PREPARE: {STATE_FREE_ACTIVE, STATE_STOPPING},
        STATE_STOPPING: {STATE_IDLE},
    }

    def __init__(self, initial=STATE_IDLE):
        self._state = str(initial)
        self._lock = threading.RLock()

    @property
    def state(self):
        with self._lock:
            return self._state

    def transition(self, target):
        target = str(target)
        with self._lock:
            current = self._state
            if target == current:
                return current
            if target not in self._ALLOWED.get(current, set()):
                raise RuntimeError("非法会话状态转换：{} -> {}".format(current, target))
            self._state = target
            return target

    def force_stopping(self):
        with self._lock:
            if self._state == STATE_IDLE:
                return self._state
            if self._state != STATE_STOPPING:
                self._state = STATE_STOPPING
            return self._state


class WorkerStateSequence:
    """主进程对 worker 状态信封做会话、序号、来源和合法边校验。"""

    def __init__(self):
        self.reset()

    def reset(self, session_id="", bootstrap_target=""):
        self.session_id = str(session_id or "")
        self.bootstrap_target = str(bootstrap_target or "")
        self.last_seq = 0
        self.last_worker_state = STATE_IDLE

    def validate(self, payload, application_state):
        if not isinstance(payload, dict):
            raise RuntimeError("worker 状态消息不是结构化信封")
        session_id = str(payload.get("session_id", ""))
        try:
            seq = int(payload.get("seq", -1))
        except (TypeError, ValueError):
            seq = -1
        source = str(payload.get("from", ""))
        target = str(payload.get("to", ""))
        if not self.session_id or session_id != self.session_id:
            raise RuntimeError("worker session_id 不匹配")
        if seq != self.last_seq + 1:
            raise RuntimeError("worker state_seq 不连续：期望 {}，收到 {}".format(self.last_seq + 1, seq))
        if source != self.last_worker_state:
            raise RuntimeError("worker from_state 不连续：期望 {}，收到 {}".format(self.last_worker_state, source))
        bootstrap = self.last_seq == 0
        if bootstrap:
            if source != STATE_IDLE or target != self.bootstrap_target or str(application_state) != target:
                raise RuntimeError("worker 初始状态确认与主进程已批准状态不一致")
        else:
            if source != str(application_state):
                raise RuntimeError("worker from_state 与主进程状态不一致：{} != {}".format(source, application_state))
            if target not in SessionStateMachine._ALLOWED.get(source, set()):
                raise RuntimeError("worker 请求非法状态边：{} -> {}".format(source, target))
        return {"seq": seq, "from": source, "to": target, "bootstrap": bootstrap}

    def commit(self, validated):
        self.last_seq = int(validated["seq"])
        self.last_worker_state = str(validated["to"])
        return self.last_worker_state


def clamp(value, low, high):
    return low if value < low else high if value > high else value


def safe_float(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError):
        return default


def source_version_fingerprint(path=None):
    target = Path(path or __file__).resolve()
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    build = 0
    if os.name == "nt":
        try:
            build = int(sys.getwindowsversion().build)
        except Exception:
            build = 0
    return {
        "source_sha256": digest,
        "format_version": int(FORMAT_VERSION),
        "python": "{}.{}.{}".format(sys.version_info.major, sys.version_info.minor, sys.version_info.micro),
        "implementation": str(getattr(sys.implementation, "name", "python")),
        "pointer_bits": int(ctypes.sizeof(ctypes.c_void_p) * 8),
        "windows_build": build,
    }


_RUNTIME_OFFLINE_GUARD_INSTALLED = False
_RUNTIME_ACTIVITY_LOCKED = False
_RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL = None


def lock_runtime_activity():
    """进入 AI 活动期：从此进程内禁止再创建/替换任何子进程，直到本轮活动完全结束。"""
    global _RUNTIME_ACTIVITY_LOCKED
    _RUNTIME_ACTIVITY_LOCKED = True
    return True


def unlock_runtime_activity():
    """仅主监督进程在确认 worker 与安全子进程都已结束后调用，以允许下一轮会话预创建安全进程。"""
    global _RUNTIME_ACTIVITY_LOCKED
    _RUNTIME_ACTIVITY_LOCKED = False
    return True


def runtime_activity_locked():
    return bool(_RUNTIME_ACTIVITY_LOCKED)


def require_pre_activity(operation="该操作"):
    """任何只允许启动阶段执行的进程/OS 配置动作都统一经过此硬门。"""
    if runtime_activity_locked():
        raise PermissionError(str(operation) + "只允许 AI 活动开始前执行")
    return True


def ensure_numpy_available():
    """NumPy 仅作可选加速器；绝不引导安装 pip，也不因 NumPy 不可用阻止 stdlib-array 后端启动。"""
    global _np
    require_pre_activity("NumPy 可选依赖安装")
    dependency_dir = _local_dependency_dir()
    dependency_dir.mkdir(parents=True, exist_ok=True)
    _activate_local_dependency_dir()
    local_temp_dir = RUNTIME_PATHS.temp_dir
    local_temp_dir.mkdir(parents=True, exist_ok=True)
    local_install_env = dict(os.environ)
    local_install_env["TMP"] = str(local_temp_dir)
    local_install_env["TEMP"] = str(local_temp_dir)
    local_install_env["TMPDIR"] = str(local_temp_dir)
    local_install_env["PIP_CACHE_DIR"] = str(local_temp_dir / "pip-cache-disabled")
    local_install_env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    local_install_env["PIP_NO_INPUT"] = "1"

    def cleanup_local_temp():
        shutil.rmtree(local_temp_dir, ignore_errors=True)

    def reset_to_stdlib(detail):
        global _np
        _np = None
        # pip 失败可能留下半安装目录；清掉可选加速器残留，避免下一次误加载不完整 NumPy。
        try:
            shutil.rmtree(dependency_dir, ignore_errors=True)
            dependency_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        cleanup_local_temp()
        return {"ok": True, "backend": "stdlib-array", "detail": str(detail)}

    def dependency_inventory():
        names = set()
        try:
            for metadata_dir in dependency_dir.glob("*.dist-info"):
                metadata = metadata_dir / "METADATA"
                name = ""
                if metadata.exists():
                    for line in metadata.read_text(encoding="utf-8", errors="replace").splitlines():
                        if line.lower().startswith("name:"):
                            name = line.split(":", 1)[1].strip().lower().replace("_", "-")
                            break
                names.add(name or metadata_dir.name.split("-", 1)[0].lower().replace("_", "-"))
        except Exception:
            return set()
        return names

    def probe():
        probe_code = (
            "import sys;"
            "sys.path.insert(0," + repr(str(dependency_dir)) + ");"
            "import numpy as n;"
            "print(n.__version__)"
        )
        try:
            completed = subprocess.run(
                [str(Path(sys.executable).resolve()), "-I", "-S", "-c", probe_code],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, errors="replace", timeout=20.0,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False, env=local_install_env,
            )
            version = (completed.stdout or "").strip().splitlines()[-1] if completed.returncode == 0 and (completed.stdout or "").strip() else ""
            return completed.returncode == 0 and bool(version), version, ((completed.stderr or completed.stdout or "").strip()[:500])
        except Exception as error:
            return False, "", str(error)

    ok, version, detail = probe()
    inventory = dependency_inventory()
    if ok and inventory != {"numpy"}:
        ok = False
        detail = "本地依赖目录必须且只能包含 NumPy；当前发行包：" + (",".join(sorted(inventory)) or "无法确认")
    if not ok:
        # P0：只使用系统已经存在的 pip。pip 不存在时不引导安装、不修改系统 Python，直接回退标准库后端。
        pip_base = [str(Path(sys.executable).resolve()), "-m", "pip"]
        try:
            check = subprocess.run(
                pip_base + ["--version"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True, errors="replace", timeout=30.0, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False, env=local_install_env,
            )
        except Exception as error:
            return reset_to_stdlib("无法检测 pip；不修改系统 Python，使用 stdlib-array 后端：" + str(error))
        if check.returncode != 0:
            return reset_to_stdlib("未检测到可用 pip；不修改系统 Python，使用 stdlib-array 后端")
        # 清理不符合白名单/已损坏的本地可选依赖后，再进行一次完全同目录安装。
        if inventory and inventory != {"numpy"}:
            shutil.rmtree(dependency_dir, ignore_errors=True)
            dependency_dir.mkdir(parents=True, exist_ok=True)
        install = subprocess.run(
            pip_base + [
                "install", "--disable-pip-version-check", "--no-input", "--no-cache-dir", "--only-binary=:all:",
                "--upgrade", "--target", str(dependency_dir), "numpy",
            ],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, errors="replace",
            timeout=300.0, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False, env=local_install_env,
        )
        if install.returncode != 0:
            return reset_to_stdlib("NumPy 可选加速器安装失败；继续使用 stdlib-array 后端：" + ((install.stderr or install.stdout or "未知 pip 错误").strip()[-900:]))
        ok, version, detail = probe()
        inventory = dependency_inventory()
        if not ok or inventory != {"numpy"}:
            return reset_to_stdlib("NumPy 本地隔离验证未通过；继续使用 stdlib-array 后端：" + str(detail))

    try:
        module_file = str(getattr(_np, "__file__", "")) if _np is not None else ""
        if not module_file or os.path.normcase(str(dependency_dir)) not in os.path.normcase(module_file):
            for name in [key for key in list(sys.modules) if key == "numpy" or key.startswith("numpy.")]:
                sys.modules.pop(name, None)
            import numpy as local_numpy
            _np = local_numpy
        cleanup_local_temp()
        return {
            "ok": True,
            "backend": "numpy",
            "detail": "NumPy {} 已就绪（可选加速器；本地依赖目录：{}；pip 临时目录已清理）".format(version or getattr(_np, "__version__", "未知"), dependency_dir),
        }
    except Exception as error:
        return reset_to_stdlib("NumPy 本地导入失败；继续使用 stdlib-array 后端：" + str(error))

def _audit_text(value):
    if isinstance(value, bytes):
        try:
            return os.fsdecode(value)
        except Exception:
            return value.decode("utf-8", "replace")
    return str(value or "")


def _audit_subprocess_argv(audit_args):
    try:
        executable = _audit_text(audit_args[0])
    except Exception:
        executable = ""
    try:
        raw = audit_args[1]
    except Exception:
        raw = []
    if isinstance(raw, (list, tuple)):
        argv = [_audit_text(value) for value in raw]
    elif raw is None:
        argv = []
    else:
        # 字符串命令行难以做到无歧义参数验证，因此 fail-closed。
        argv = []
    return executable, argv


def _is_exact_internal_python_bootstrap(executable, argv, current_exe):
    """只允许本程序在 AI 活动前创建 multiprocessing bootstrap 或 MinimalEscapeGuardian。"""
    try:
        normalized = os.path.normcase(os.path.abspath(executable))
    except Exception:
        return False
    if normalized != current_exe or not argv:
        return False
    parts = list(argv)
    if parts:
        try:
            if os.path.normcase(os.path.abspath(parts[0])) == current_exe:
                parts = parts[1:]
        except Exception:
            pass
    # multiprocessing.spawn 的 CPython 标准 bootstrap；不接受任意 -c 代码。
    if "--multiprocessing-fork" in parts and "-c" in parts:
        try:
            index = parts.index("-c")
            code = parts[index + 1]
        except Exception:
            return False
        if code.startswith("from multiprocessing.spawn import spawn_main; spawn_main(") and code.endswith(")"):
            trailing = parts[index + 2:]
            if trailing == ["--multiprocessing-fork"]:
                return True
    # 独立 MinimalEscapeGuardian：源码和固定参数形状都必须精确匹配。
    minimal_source = globals().get("MINIMAL_GUARDIAN_SOURCE")
    if minimal_source is not None and len(parts) == 10 and parts[:3] == ["-I", "-S", "-c"] and parts[3] == minimal_source:
        escape_name, done_name, gate_closed_name = parts[4], parts[5], parts[6]
        try:
            parent_pid = int(parts[7]); worker_pid = int(parts[8]); int(parts[9])
        except Exception:
            return False
        return bool(
            str(escape_name).startswith("Local\\LocalAI_Escape_")
            and str(done_name).startswith("Local\\LocalAI_Done_")
            and str(gate_closed_name).startswith("Local\\LocalAI_GateClosed_")
            and parent_pid > 0 and worker_pid > 0
        )
    return False


def install_runtime_offline_guard():
    """Python 运行时第二层防线：拒绝网络 API、shell 与非精确白名单子进程。

    AI 活动一旦 lock_runtime_activity()，则不再存在任何新建/替换进程的例外。
    """
    global _RUNTIME_OFFLINE_GUARD_INSTALLED
    if _RUNTIME_OFFLINE_GUARD_INSTALLED:
        return True
    current_exe = os.path.normcase(os.path.abspath(str(Path(sys.executable).resolve())))
    blocked_dll_tokens = ("ws2_32", "winhttp", "wininet", "urlmon", "websocket")

    # Windows multiprocessing.spawn 直接调用 _winapi.CreateProcess，不一定经过 subprocess.Popen audit event。
    # 因此再包一层底层 CreateProcess：AI 活动前允许预创建 watchdog/worker/guardian；锁定后绝对禁止新进程。
    if os.name == "nt":
        try:
            global _RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL
            _winapi = __import__("_winapi")
            if _RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL is None:
                _RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL = _winapi.CreateProcess
                original_create_process = _RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL
                def _guarded_create_process(*create_args, **create_kwargs):
                    if _RUNTIME_ACTIVITY_LOCKED:
                        raise PermissionError("AI 活动期间禁止 WinAPI CreateProcess")
                    return original_create_process(*create_args, **create_kwargs)
                _winapi.CreateProcess = _guarded_create_process
        except Exception:
            # 若底层包装失败，worker 的 Job Object 仍是 OS 级最后防线；启动自检会显示运行时守卫状态。
            pass

    def _audit(event, args):
        event = str(event or "")
        if event.startswith("socket."):
            raise PermissionError("运行时离线守卫：禁止 Python socket 网络操作")
        if event == "os.system":
            raise PermissionError("运行时离线守卫：禁止 os.system")
        if _RUNTIME_ACTIVITY_LOCKED and (event == "subprocess.Popen" or event.startswith("os.spawn") or event.startswith("os.exec") or event == "os.posix_spawn"):
            raise PermissionError("AI 活动期间禁止创建/替换任何新进程")
        if event == "subprocess.Popen":
            executable, argv = _audit_subprocess_argv(args)
            if _is_exact_internal_python_bootstrap(executable, argv, current_exe):
                return
            raise PermissionError("运行时离线守卫：子进程命令不在精确白名单 " + str(argv[:6]))
        if event == "ctypes.dlopen":
            try:
                library = str(args[0] or "").lower()
            except Exception:
                library = ""
            if any(token in library for token in blocked_dll_tokens):
                raise PermissionError("运行时离线守卫：禁止加载联网 DLL " + library)

    sys.addaudithook(_audit)
    _RUNTIME_OFFLINE_GUARD_INSTALLED = True
    return True


class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_longlong), ("PerJobUserTimeLimit", ctypes.c_longlong),
        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD),
    ]


class _JOB_IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong), ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong), ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong), ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", _JOBOBJECT_BASIC_LIMIT_INFORMATION), ("IoInfo", _JOB_IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


class WorkerProcessJob:
    """Windows Job Object：worker 自己占据唯一 ActiveProcess 名额，OS 层拒绝其创建联网/辅助子进程。"""

    JOB_OBJECT_LIMIT_ACTIVE_PROCESS = 0x00000008
    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
    JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS = 9
    PROCESS_TERMINATE = 0x0001
    PROCESS_SET_QUOTA = 0x0100
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

    def __init__(self):
        self.handle = None
        self.kernel32 = None

    def assign(self, pid):
        if os.name != "nt" or not pid:
            return False, "非 Windows 或 worker PID 无效"
        self.close()
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        kernel32.CreateJobObjectW.restype = wintypes.HANDLE
        kernel32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        kernel32.SetInformationJobObject.restype = wintypes.BOOL
        kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel32.CreateJobObjectW(None, None)
        if not handle:
            return False, "CreateJobObjectW 失败：{}".format(ctypes.get_last_error())
        info = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        info.BasicLimitInformation.LimitFlags = self.JOB_OBJECT_LIMIT_ACTIVE_PROCESS | self.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        info.BasicLimitInformation.ActiveProcessLimit = 1
        if not kernel32.SetInformationJobObject(handle, self.JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS, ctypes.byref(info), ctypes.sizeof(info)):
            error = ctypes.get_last_error(); kernel32.CloseHandle(handle)
            return False, "SetInformationJobObject 失败：{}".format(error)
        access = self.PROCESS_TERMINATE | self.PROCESS_SET_QUOTA | self.PROCESS_QUERY_LIMITED_INFORMATION
        process_handle = kernel32.OpenProcess(access, False, int(pid))
        if not process_handle:
            error = ctypes.get_last_error(); kernel32.CloseHandle(handle)
            return False, "OpenProcess(worker) 失败：{}".format(error)
        try:
            if not kernel32.AssignProcessToJobObject(handle, process_handle):
                error = ctypes.get_last_error(); kernel32.CloseHandle(handle)
                return False, "AssignProcessToJobObject 失败：{}".format(error)
        finally:
            kernel32.CloseHandle(process_handle)
        self.kernel32 = kernel32
        self.handle = handle
        return True, "worker 已分配到 ActiveProcessLimit=1 的 Windows Job Object"

    def close(self):
        if self.handle and self.kernel32 is not None:
            try:
                self.kernel32.CloseHandle(self.handle)
            except Exception:
                pass
        self.handle = None
        self.kernel32 = None


def enable_per_monitor_dpi_awareness():
    """在创建 Tk/Win32 窗口前启用 Per-Monitor DPI Awareness V2，并兼容旧 API。"""
    if os.name != "nt":
        return "non-windows"
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        setter = getattr(user32, "SetProcessDpiAwarenessContext", None)
        if setter is not None:
            setter.argtypes = [ctypes.c_void_p]
            setter.restype = wintypes.BOOL
            # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 == (HANDLE)-4
            if setter(ctypes.c_void_p(-4)):
                return "per-monitor-v2"
    except Exception:
        pass
    try:
        shcore = ctypes.WinDLL("shcore", use_last_error=True)
        setter = getattr(shcore, "SetProcessDpiAwareness", None)
        if setter is not None:
            setter.argtypes = [ctypes.c_int]
            setter.restype = ctypes.c_long
            result = int(setter(2))  # PROCESS_PER_MONITOR_DPI_AWARE
            if result in (0, -2147024891):  # S_OK / E_ACCESSDENIED(通常表示已由宿主设置)
                return "per-monitor-v1"
    except Exception:
        pass
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        setter = getattr(user32, "SetProcessDPIAware", None)
        if setter is not None and setter():
            return "system-aware"
    except Exception:
        pass
    return "unavailable"


class MemoryStatusEx(ctypes.Structure):
    _fields_ = [
        ("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


class ResourceBudget:
    """把所有可增长能力绑定到当前资源，而不是绑定到代码中的最终常量。"""

    def __init__(self, data_dir, decision_latency_target=0.16, perception_latency_target=0.28):
        self.data_dir = Path(data_dir)
        self.decision_latency_target = float(decision_latency_target)
        self.perception_latency_target = float(perception_latency_target)
        self.total_ram = 0
        self.available_ram = 0
        self.free_disk = 0
        self.total_disk = 0
        self.system_total_disk = 0
        self.system_free_disk = 0
        self.system_same_as_data_disk = True
        self.recent_db_growth_24h = 0
        self.recent_write_bytes_24h = 0
        self.storage_history_path = self.data_dir / STORAGE_USAGE_FILE_NAME
        self._storage_history = self._load_storage_history()
        self._last_storage_sample_at = safe_float(self._storage_history[-1].get("time", 0.0)) if self._storage_history else 0.0
        self.decision_latency = 0.0
        self.perception_latency = 0.0
        self.updated_at = 0.0
        self.refresh()

    def _load_storage_history(self):
        try:
            payload = json.loads(self.storage_history_path.read_text(encoding="utf-8"))
            rows = payload.get("samples", []) if isinstance(payload, dict) else []
            return [dict(row) for row in rows if isinstance(row, dict)][-192:]
        except Exception:
            return []

    def _managed_storage_bytes(self):
        total = 0
        db_total = 0
        paths = []
        try:
            paths.extend(self.data_dir.glob(DATABASE_FILE_NAME + "*"))
            paths.extend(self.data_dir.glob(MODEL_FILE_NAME + "*"))
            paths.extend((self.data_dir / "checkpoints").glob("*.bin"))
            paths.extend((self.data_dir / "logs").glob("*.jsonl"))
        except Exception:
            pass
        for path in paths:
            try:
                size = int(path.stat().st_size)
            except OSError:
                continue
            total += size
            if path.name.startswith(DATABASE_FILE_NAME):
                db_total += size
        return db_total, total

    def _sample_storage_history(self, now=None):
        now = time.time() if now is None else float(now)
        db_bytes, managed_bytes = self._managed_storage_bytes()
        cutoff = now - 24.0 * 3600.0
        rows = [row for row in self._storage_history if safe_float(row.get("time", 0.0)) >= cutoff]
        if not rows or now - self._last_storage_sample_at >= 900.0:
            rows.append({"time": now, "db_bytes": int(db_bytes), "managed_bytes": int(managed_bytes), "free_disk": int(self.free_disk)})
            self._last_storage_sample_at = now
            try:
                self.data_dir.mkdir(parents=True, exist_ok=True)
                atomic_write(self.storage_history_path, json.dumps({"version": 1, "samples": rows[-192:]}, ensure_ascii=False, sort_keys=True).encode("utf-8"))
            except Exception:
                pass
        self._storage_history = rows[-192:]
        if rows:
            first_db = int(rows[0].get("db_bytes", db_bytes) or 0)
            self.recent_db_growth_24h = max(0, int(db_bytes) - first_db)
            positive = 0
            previous = int(rows[0].get("managed_bytes", managed_bytes) or 0)
            for row in rows[1:]:
                current = int(row.get("managed_bytes", previous) or 0)
                if current > previous:
                    positive += current - previous
                previous = current
            # 当前样本尚未落盘时也计入增长，避免刚开始高速写入时安全线滞后。
            positive += max(0, int(managed_bytes) - previous)
            self.recent_write_bytes_24h = max(self.recent_db_growth_24h, positive)

    def _system_disk_status(self):
        try:
            data_anchor = str(self.data_dir.resolve().anchor or "").rstrip("\\/").lower()
            system_drive = os.environ.get("SystemDrive", data_anchor or "C:").rstrip("\\/").lower()
            target = system_drive + "\\" if os.name == "nt" else (self.data_dir.resolve().anchor or "/")
            disk = shutil.disk_usage(target)
            same = bool(data_anchor and system_drive and data_anchor == system_drive)
            return int(disk.total), int(disk.free), same
        except Exception:
            return int(self.total_disk), int(self.free_disk), True

    @staticmethod
    def _ram_status():
        if os.name == "nt":
            try:
                status = MemoryStatusEx()
                status.dwLength = ctypes.sizeof(MemoryStatusEx)
                kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
                kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MemoryStatusEx)]
                kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL
                if kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                    return int(status.ullTotalPhys), int(status.ullAvailPhys)
            except Exception:
                pass
        try:
            page = int(os.sysconf("SC_PAGE_SIZE"))
            total = page * int(os.sysconf("SC_PHYS_PAGES"))
            available = page * int(os.sysconf("SC_AVPHYS_PAGES"))
            return total, available
        except Exception:
            # 无法读取时只给出保守的本轮预算；这不是容量上限，下次成功读取会自动扩展。
            return 2 * 1024 ** 3, 512 * 1024 ** 2

    def refresh(self, decision_latency=None, perception_latency=None):
        self.total_ram, self.available_ram = self._ram_status()
        try:
            disk = shutil.disk_usage(str(self.data_dir.resolve().anchor or self.data_dir))
            self.total_disk, self.free_disk = int(disk.total), int(disk.free)
        except Exception:
            self.total_disk, self.free_disk = 8 * 1024 ** 3, 512 * 1024 ** 2
        self.system_total_disk, self.system_free_disk, self.system_same_as_data_disk = self._system_disk_status()
        if decision_latency is not None:
            self.decision_latency = max(0.0, safe_float(decision_latency))
        if perception_latency is not None:
            self.perception_latency = max(0.0, safe_float(perception_latency))
        self.updated_at = time.time()
        self._sample_storage_history(self.updated_at)
        return self

    def _latency_factor(self, kind="decision"):
        observed = self.perception_latency if kind == "perception" else self.decision_latency
        target = self.perception_latency_target if kind == "perception" else self.decision_latency_target
        if observed <= 1e-9:
            return 1.0
        return clamp(target / observed, 0.08, 2.0)

    def planner_depth(self):
        """本轮 A* 深度预算：由 RAM、磁盘余量和实际决策延迟决定，没有代码写死的最终上限。"""
        ram_mib = max(1.0, self.available_ram / float(1024 ** 2))
        disk_gib = max(0.25, self.free_disk / float(1024 ** 3))
        latency = self._latency_factor("decision")
        return max(8, int(math.log2(1.0 + ram_mib) * math.sqrt(disk_gib) * max(0.25, latency)))

    def skill_depth(self):
        return max(24, self.planner_depth() * 3)

    def skill_loop_iterations(self):
        return max(8, self.planner_depth())

    def skill_retry_attempts(self):
        return max(3, int(math.sqrt(self.planner_depth())))

    @property
    def disk_reserve_bytes(self):
        """动态磁盘安全线：结合系统盘余量、24h 数据增长和写入速度，不用固定 8% 截断长期学习。"""
        gib = 1024 ** 3
        base = max(4 * gib, min(24 * gib, int(self.total_disk * 0.015)))
        growth_buffer = max(1 * gib, int(self.recent_db_growth_24h * 3.0), int(self.recent_write_bytes_24h * 1.75))
        ratio_guard = 0
        if self.system_same_as_data_disk and self.system_total_disk > 0:
            ratio = self.system_free_disk / float(self.system_total_disk)
            if ratio < 0.05:
                ratio_guard = min(32 * gib, int(self.total_disk * 0.045))
            elif ratio < 0.08:
                ratio_guard = min(20 * gib, int(self.total_disk * 0.025))
            elif ratio < 0.12:
                ratio_guard = min(12 * gib, int(self.total_disk * 0.015))
        return int(max(base, growth_buffer, ratio_guard))

    @property
    def storage_pressure(self):
        reserve = max(1, self.disk_reserve_bytes)
        return clamp((reserve - self.free_disk) / float(reserve), 0.0, 1.0)

    def storage_writes_allowed(self, margin_bytes=64 * 1024 ** 2):
        self.refresh()
        return self.free_disk > self.disk_reserve_bytes + max(0, int(margin_bytes))

    def cleanup_regenerable_storage(self):
        """逼近安全线时仅清理可再生成内容：旧日志、旧 checkpoint、临时文件；归档知识不自动删除。"""
        self.refresh()
        if self.free_disk > self.disk_reserve_bytes + 512 * 1024 ** 2:
            return 0
        removed = 0
        candidates = []
        for directory, pattern, keep in ((self.data_dir / "logs", "session_*.jsonl", 4), (self.data_dir / "checkpoints", "model_*.bin", 2)):
            try:
                files = sorted(directory.glob(pattern), key=lambda path: path.stat().st_mtime, reverse=True)
                candidates.extend(files[keep:])
            except Exception:
                pass
        try:
            candidates.extend(self.data_dir.glob("*.tmp"))
        except Exception:
            pass
        for path in candidates:
            try:
                size = path.stat().st_size
                path.unlink()
                removed += int(size)
            except OSError:
                pass
            self.refresh()
            if self.free_disk > self.disk_reserve_bytes + 768 * 1024 ** 2:
                break
        return removed

    def visual_roi_scale(self):
        """按当前资源计算可承担的 ROI 倍率；随资源增长，没有代码写死的最终倍率。"""
        headroom_gib = max(0.0, self.available_ram / float(1024 ** 3))
        latency = self._latency_factor("perception")
        # 对数增长避免一次采样吞掉全部 RAM；更大硬件仍会得到更高倍率。
        return max(1, int(1.0 + math.log2(1.0 + headroom_gib) * max(0.20, latency) * 0.72))

    @property
    def hot_memory_bytes(self):
        ram_budget = max(8 * 1024 ** 2, int(self.available_ram * 0.075))
        disk_budget = max(8 * 1024 ** 2, int(self.free_disk * 0.035))
        return min(ram_budget, disk_budget)

    def memory_limits(self):
        budget = self.hot_memory_bytes
        limits = {}
        for table, (share, estimated_bytes) in HOT_MEMORY_PROFILE.items():
            limits[table] = max(32, int(budget * float(share) / max(1, int(estimated_bytes))))
        # 压缩层随磁盘增加而增大；归档层不自动淘汰。
        compressed_bytes = max(8 * 1024 ** 2, int(self.free_disk * 0.018))
        limits["memory_compressed"] = max(128, int(compressed_bytes / 2400.0))
        limits["recent_working_set"] = max(128, int(math.sqrt(max(1, budget // 1024)) * 5.0))
        return limits

    def growth_amount(self, capability, current, kind="decision"):
        current = max(0, int(current))
        headroom_mib = max(1.0, self.available_ram / float(1024 ** 2))
        disk_gib = max(0.25, self.free_disk / float(1024 ** 3))
        resource_units = max(1, int(math.log2(1.0 + headroom_mib) * math.sqrt(disk_gib)))
        factor = self._latency_factor(kind)
        if factor < 0.45:
            return 0
        scales = {
            "uia_nodes": 3.0, "uia_depth": 0.10, "attention_candidates": 0.35,
            "memory_horizon": 0.50, "planner_breadth": 1.2, "skill_attention": 2.0,
            "adaptive_input": 1.5, "visual_roi_scale": 0.18, "forward_cache_entries": 1.0,
        }
        scale = float(scales.get(str(capability), 1.0))
        proportional = math.sqrt(max(1, current)) * 0.12
        return max(1, int((resource_units * scale + proportional) * min(1.5, factor)))

    def network_document_bytes(self):
        # 用户明确允许的单个文档，大小只由当时资源决定。
        return max(64 * 1024, int(min(self.available_ram * 0.0025, self.free_disk * 0.0008)))

    def forward_cache_entries(self, input_count, hidden_count):
        bytes_per_entry = max(1024, (int(input_count) + int(hidden_count) * 2 + ACTION_COUNT * 4) * 4)
        return max(8, int(self.available_ram * 0.012 / bytes_per_entry))

    def training_batch_size(self, experience_count, evaluation=False):
        base = math.sqrt(max(1, int(experience_count))) * (2.0 if evaluation else 10.0)
        resource_scale = max(0.5, math.log2(1.0 + self.available_ram / float(1024 ** 2)) / 8.0)
        return max(8, int(base * resource_scale))

    def training_updates(self, experience_count):
        latency = self._latency_factor("decision")
        return max(16, int(math.sqrt(max(1, int(experience_count))) * 4.8 * latency))

    def as_dict(self):
        return {
            "total_ram": int(self.total_ram), "available_ram": int(self.available_ram),
            "total_disk": int(self.total_disk), "free_disk": int(self.free_disk),
            "system_total_disk": int(self.system_total_disk), "system_free_disk": int(self.system_free_disk),
            "system_same_as_data_disk": bool(self.system_same_as_data_disk),
            "recent_db_growth_24h": int(self.recent_db_growth_24h), "recent_write_bytes_24h": int(self.recent_write_bytes_24h),
            "decision_latency": float(self.decision_latency), "perception_latency": float(self.perception_latency),
            "hot_memory_bytes": int(self.hot_memory_bytes), "disk_reserve_bytes": int(self.disk_reserve_bytes),
            "planner_depth": int(self.planner_depth()), "skill_depth": int(self.skill_depth()),
            "skill_loop_iterations": int(self.skill_loop_iterations()), "skill_retry_attempts": int(self.skill_retry_attempts()),
            "storage_pressure": float(self.storage_pressure), "updated_at": float(self.updated_at),
        }


def compact_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def atomic_write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with open(temporary, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def write_storage_manifest(data_dir):
    """记录运行时文件用途与版本；仍保持用户交付物只有一个 code.py。"""
    data_dir = Path(data_dir)
    code_directory = Path(__file__).resolve().parent
    data_directory = data_dir.resolve()
    external_fallbacks = []
    if data_directory != (code_directory / "local_ai_data").resolve():
        external_fallbacks.append(str(data_directory))
    payload = {
        "app": APP_NAME, "format_version": FORMAT_VERSION, "schema_version": SCHEMA_VERSION,
        "generated_at": time.time(),
        "code_directory": str(code_directory),
        "data_directory": str(data_directory),
        "external_fallbacks": external_fallbacks,
        "capacity_statement": "本程序的认知、规划、学习和任务求解不调用或委托第三方 AI；无人工设定的最终学习/模型/记忆容量上限，实际能力受当前硬件、数据和算法有效性约束；这不等同于可验证的‘无限智力’。",
        "entries": [
            {"path": DATABASE_FILE_NAME, "purpose": "SQLite 长期记忆、知识、世界模型、技能、失败与睡眠报告", "version": SCHEMA_VERSION},
            {"path": DATABASE_FILE_NAME + "-wal/-shm", "purpose": "SQLite WAL 临时文件", "version": SCHEMA_VERSION},
            {"path": MODEL_FILE_NAME, "purpose": "Double-Q 网络与可增长容量状态", "version": FORMAT_VERSION},
            {"path": "checkpoints/", "purpose": "模型原子恢复 checkpoint", "version": FORMAT_VERSION},
            {"path": "logs/", "purpose": "会话 JSONL 日志", "version": 1},
            {"path": STORAGE_USAGE_FILE_NAME, "purpose": "磁盘增长与最近 24h 写入采样，用于动态安全线", "version": 1},
            {"path": "crash.log", "purpose": "运行异常日志", "version": 1},
            {"path": STORAGE_MANIFEST_FILE_NAME, "purpose": "本清单", "version": 1},
            {"path": LOCAL_DEPENDENCY_DIR_NAME + "/", "purpose": "可选 NumPy 加速器；仅在已有 pip 时用 --target 同目录安装，缺失时使用 stdlib-array", "version": 1},
            {"path": LOCAL_TEMP_DIR_NAME + "/", "purpose": "pip 临时目录；安装结束立即删除；绝不运行 ensurepip", "version": 1},
        ],
    }
    try:
        atomic_write(data_dir / STORAGE_MANIFEST_FILE_NAME, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"))
        return True
    except Exception:
        return False


def pack_state(values):
    raw = bytes(int(clamp(round(value * 255.0), 0, 255)) for value in values)
    return zlib.compress(raw, 1)


def unpack_state(blob):
    raw = zlib.decompress(blob)
    if len(raw) < BASE_FEATURE_COUNT:
        raise ValueError("长期记忆中的状态维度过短")
    return [value / 255.0 for value in raw]


def normalize_state(values, count, neutral=0.5):
    values = list(values)
    count = int(count)
    if len(values) < count:
        values.extend([float(neutral)] * (count - len(values)))
    elif len(values) > count:
        values = values[:count]
    return values


def pack_parameters(values, mask):
    values = list(values)[:PARAM_COUNT] + [0.5] * max(0, PARAM_COUNT - len(values))
    raw = bytes([int(mask) & 0xFF] + [int(clamp(round(value * 255.0), 0, 255)) for value in values[:PARAM_COUNT]])
    return raw


def unpack_parameters(blob):
    if not blob or len(blob) != PARAM_COUNT + 1:
        return [0.5] * PARAM_COUNT, 0
    return [value / 255.0 for value in blob[1:]], int(blob[0])


def mask_actions(actions):
    mask = 0
    for action in actions:
        mask |= 1 << int(action)
    return mask


def actions_from_mask(mask):
    return [index for index in range(ACTION_COUNT) if int(mask) & (1 << index)]


def semantic_units(text):
    text = str(text or "").lower()
    units = []
    for token in re.findall(r"[a-z0-9][a-z0-9_.:/@+\-]*|[\u3400-\u9fff]+", text):
        if token not in units:
            units.append(token)
        if re.fullmatch(r"[\u3400-\u9fff]+", token):
            if len(token) <= 8:
                units.extend(token)
            for size in (2, 3):
                if len(token) >= size:
                    units.extend(token[index:index + size] for index in range(len(token) - size + 1))
    result = []
    seen = set()
    for unit in units:
        if unit and unit not in seen:
            seen.add(unit)
            result.append(unit)
    return result


def hashed_features(items, count):
    values = [0.0] * count
    for position, item in enumerate(items):
        for token in semantic_units(item):
            digest = hashlib.blake2s(token.encode("utf-8", "ignore"), digest_size=8).digest()
            index = int.from_bytes(digest[:4], "little") % count
            sign = 1.0 if digest[4] & 1 else -1.0
            weight = 1.0 / math.sqrt(1.0 + position * 0.15)
            values[index] += sign * weight
    return [0.5 + 0.5 * math.tanh(value * 0.7) for value in values]


def similarity(first, second):
    left = set(semantic_units(first))
    right = set(semantic_units(second))
    if not left or not right:
        return 0.0
    return len(left & right) / max(1, len(left | right))


def control_locator(record):
    if not record:
        return {}
    locator = {
        "control_type": str(record.get("control_type", "")),
        "automation_id": str(record.get("automation_id", "")),
        "name": str(record.get("name", "")),
        "class_name": str(record.get("class_name", "")),
    }
    runtime_id = record.get("runtime_id")
    if runtime_id:
        try:
            locator["runtime_id"] = [int(value) for value in runtime_id]
        except Exception:
            pass
    return {key: value for key, value in locator.items() if value not in ("", [], None)}


def locator_score(locator, record):
    if not locator or not record or record.get("offscreen") or not record.get("enabled"):
        return -1.0
    expected_type = str(locator.get("control_type", ""))
    current_type = str(record.get("control_type", ""))
    if expected_type and current_type and expected_type != current_type:
        return -1.0
    score = 0.0
    expected_runtime = tuple(locator.get("runtime_id") or ())
    current_runtime = tuple(record.get("runtime_id") or ())
    if expected_runtime and current_runtime and expected_runtime == current_runtime:
        score += 2.8
    expected_id = str(locator.get("automation_id", ""))
    current_id = str(record.get("automation_id", ""))
    if expected_id and current_id:
        score += 2.2 if expected_id == current_id else similarity(expected_id, current_id) * 0.35
    expected_name = str(locator.get("name", ""))
    current_name = str(record.get("name", ""))
    if expected_name and current_name:
        score += similarity(expected_name, current_name) * 1.8
        if expected_name.lower() == current_name.lower():
            score += 1.2
    expected_class = str(locator.get("class_name", ""))
    current_class = str(record.get("class_name", ""))
    if expected_class and current_class and expected_class == current_class:
        score += 0.7
    if expected_type and current_type == expected_type:
        score += 0.8
    return score


def resolve_control(observation, locator, minimum=1.0):
    if observation is None or not locator:
        return None
    best = None
    best_score = float(minimum)
    for record in observation.accessibility.records:
        score = locator_score(locator, record)
        if score > best_score:
            best_score, best = score, record
    return best


def control_at_point(observation, x, y, radius=0.11):
    best = None
    best_distance = float(radius)
    for record in observation.accessibility.records:
        if record.get("offscreen") or not record.get("enabled") or record.get("password"):
            continue
        distance = math.hypot(float(record.get("x_norm", 0.5)) - float(x), float(record.get("y_norm", 0.5)) - float(y))
        if distance < best_distance:
            best_distance, best = distance, record
    return best


@dataclass
class ActionCommand:
    kind: int
    parameters: dict = field(default_factory=dict)
    label: str = ""
    parameter_targets: list = field(default_factory=lambda: [0.5] * PARAM_COUNT)
    parameter_mask: int = 0
    required_capabilities: list = field(default_factory=list)
    capability_reason: str = ""
    # 仅运行期授权标记，不进入可持久化 payload：技能/历史经验不能伪造“编译器明确跨程序步骤”。
    compiled_scope_token: str = ""
    compiled_scope_target: str = ""
    evidence_source: str = ""

    def payload(self):
        payload = {"kind": int(self.kind), "parameters": self.parameters, "label": self.label}
        if self.required_capabilities:
            payload["required_capabilities"] = sorted(set(str(value) for value in self.required_capabilities if value))
        if self.capability_reason:
            payload["capability_reason"] = str(self.capability_reason)
        return payload

    @classmethod
    def from_payload(cls, source):
        kind = int(source.get("kind", WAIT))
        if kind < 0 or kind >= ACTION_COUNT:
            raise ValueError("技能包含未知动作类型")
        return cls(
            kind, dict(source.get("parameters", {})), str(source.get("label", "")),
            required_capabilities=list(source.get("required_capabilities") or []),
            capability_reason=str(source.get("capability_reason", "")),
        )

    def declare(self, capabilities=None, reason=""):
        self.required_capabilities = sorted(set(
            list(self.required_capabilities) + [str(value) for value in (capabilities or []) if value]
        ))
        if reason:
            self.capability_reason = str(reason)
        return self

    def fingerprint(self):
        return hashlib.blake2s(compact_json(self.payload()).encode("utf-8"), digest_size=10).hexdigest()


@dataclass
class VisualElement:
    """统一 UIA 与视觉语义结果。bbox 使用 0..1 归一化坐标。"""
    text: str = ""
    role: str = ""
    bbox: tuple = (0.0, 0.0, 0.0, 0.0)
    confidence: float = 0.0
    source: str = "uia"
    locator: dict = field(default_factory=dict)

    def as_dict(self):
        return {
            "text": str(self.text)[:320], "role": str(self.role)[:120],
            "bbox": [round(float(v), 6) for v in self.bbox],
            "confidence": round(clamp(float(self.confidence), 0.0, 1.0), 4),
            "source": str(self.source), "locator": dict(self.locator or {}),
        }


class UnifiedVisualPerception:
    """UIA 优先，纯像素视觉只补足 UIA 看不到的 Canvas 与自绘控件结构。"""

    @staticmethod
    def _uia_bbox(record, observation):
        """把 UIA/native 的 [left, top, width, height] 映射到 WinIO 的虚拟桌面归一化坐标。"""
        rect = tuple(record.get("bounding_rectangle") or ())
        screen_left = float(getattr(observation, "screen_left", 0) or 0)
        screen_top = float(getattr(observation, "screen_top", 0) or 0)
        width = max(1.0, float(getattr(observation, "screen_width", 1) or 1))
        height = max(1.0, float(getattr(observation, "screen_height", 1) or 1))
        x_den = max(1.0, width - 1.0)
        y_den = max(1.0, height - 1.0)
        if len(rect) >= 4:
            left, top, box_width, box_height = map(float, rect[:4])
            right = left + max(0.0, box_width)
            bottom = top + max(0.0, box_height)
            return (
                clamp((left - screen_left) / x_den, 0.0, 1.0),
                clamp((top - screen_top) / y_den, 0.0, 1.0),
                clamp((right - screen_left) / x_den, 0.0, 1.0),
                clamp((bottom - screen_top) / y_den, 0.0, 1.0),
            )
        x = clamp(safe_float(record.get("x_norm", 0.5), 0.5), 0.0, 1.0)
        y = clamp(safe_float(record.get("y_norm", 0.5), 0.5), 0.0, 1.0)
        return (x, y, x, y)

    @classmethod
    def merge(cls, observation, visual_items=None):
        result = []
        for record in observation.accessibility.records:
            if record.get("offscreen"):
                continue
            text = " ".join(str(record.get(key, "")) for key in ("name", "value", "help")).strip()
            result.append(VisualElement(
                text=text, role=str(record.get("control_type", "")), bbox=cls._uia_bbox(record, observation),
                confidence=0.99 if record.get("automation_id") else 0.94, source="uia", locator=control_locator(record),
            ))
        for item in visual_items or []:
            if not isinstance(item, dict):
                continue
            box = item.get("bbox") or item.get("box") or []
            if not isinstance(box, (list, tuple)) or len(box) < 4:
                continue
            try:
                bbox = tuple(clamp(float(v), 0.0, 1.0) for v in box[:4])
            except Exception:
                continue
            candidate = VisualElement(
                text=str(item.get("text", "")), role=str(item.get("role", item.get("type", "visual"))),
                bbox=bbox, confidence=clamp(safe_float(item.get("confidence", 0.0)), 0.0, 1.0), source="vision", locator={},
            )
            duplicate = False
            for existing in result:
                if existing.source != "uia":
                    continue
                if candidate.text and existing.text and similarity(candidate.text, existing.text) >= 0.82:
                    duplicate = True; break
                cx = (candidate.bbox[0] + candidate.bbox[2]) * 0.5; cy = (candidate.bbox[1] + candidate.bbox[3]) * 0.5
                ex = (existing.bbox[0] + existing.bbox[2]) * 0.5; ey = (existing.bbox[1] + existing.bbox[3]) * 0.5
                if math.hypot(cx - ex, cy - ey) < 0.025 and existing.role == candidate.role:
                    duplicate = True; break
            if not duplicate and candidate.confidence >= 0.45:
                result.append(candidate)
        result.sort(key=lambda element: (element.source != "uia", -element.confidence))
        return result


class LocalVisualRecognizer:
    """完全本地、无外部模型的视觉补充层。

    只使用纯像素梯度、连通域和矩形结构发现 Canvas/自绘控件；
    文本语义优先来自 Windows UI Automation。纯像素层不调用任何 OCR 模型或外部 AI。
    """

    def __init__(self, max_elements=72):
        self.max_elements = max(16, int(max_elements))
        self.last_error = ""

    @staticmethod
    def _map_box(box, viewport, width, height):
        vx1, vy1, vx2, vy2 = [safe_float(value) for value in (viewport or (0.0, 0.0, 1.0, 1.0))[:4]]
        x1, y1, x2, y2 = box
        return (
            clamp(vx1 + (vx2 - vx1) * x1 / max(1.0, float(width)), 0.0, 1.0),
            clamp(vy1 + (vy2 - vy1) * y1 / max(1.0, float(height)), 0.0, 1.0),
            clamp(vx1 + (vx2 - vx1) * x2 / max(1.0, float(width)), 0.0, 1.0),
            clamp(vy1 + (vy2 - vy1) * y2 / max(1.0, float(height)), 0.0, 1.0),
        )

    def _visual_regions(self, frame):
        rgb = list(frame.get("rgb") or [])
        width = max(1, int(frame.get("width", 1))); height = max(1, int(frame.get("height", 1)))
        if len(rgb) < width * height * 3:
            return []
        stride = max(1, int(math.ceil(max(width, height) / 480.0)))
        sw = max(1, width // stride); sh = max(1, height // stride)
        gray = [0.0] * (sw * sh)
        for y in range(sh):
            for x in range(sw):
                source = ((y * stride) * width + x * stride) * 3
                gray[y * sw + x] = rgb[source] * 0.2126 + rgb[source + 1] * 0.7152 + rgb[source + 2] * 0.0722
        gradients = [0.0] * len(gray)
        samples = []
        for y in range(1, sh - 1):
            for x in range(1, sw - 1):
                index = y * sw + x
                value = abs(gray[index + 1] - gray[index - 1]) + abs(gray[index + sw] - gray[index - sw])
                gradients[index] = value
                samples.append(value)
        if not samples:
            return []
        samples.sort()
        threshold = clamp(samples[int(len(samples) * 0.82)] * 0.72, 0.075, 0.30)
        active = bytearray(1 if value >= threshold else 0 for value in gradients)
        # 一次 8 邻域膨胀把字符笔画和自绘边框合并成可用区域。
        dilated = bytearray(active)
        for y in range(1, sh - 1):
            for x in range(1, sw - 1):
                index = y * sw + x
                if active[index]:
                    for dy in (-1, 0, 1):
                        for dx in (-1, 0, 1):
                            dilated[(y + dy) * sw + x + dx] = 1
        visited = bytearray(len(dilated)); regions = []
        for seed, flag in enumerate(dilated):
            if not flag or visited[seed]:
                continue
            stack = [seed]; visited[seed] = 1
            min_x = max_x = seed % sw; min_y = max_y = seed // sw; count = 0
            while stack:
                index = stack.pop(); count += 1
                x = index % sw; y = index // sw
                min_x = min(min_x, x); max_x = max(max_x, x); min_y = min(min_y, y); max_y = max(max_y, y)
                for dy in (-1, 0, 1):
                    ny = y + dy
                    if ny < 0 or ny >= sh: continue
                    for dx in (-1, 0, 1):
                        nx = x + dx
                        if nx < 0 or nx >= sw: continue
                        neighbor = ny * sw + nx
                        if dilated[neighbor] and not visited[neighbor]:
                            visited[neighbor] = 1; stack.append(neighbor)
            box_width = max_x - min_x + 1; box_height = max_y - min_y + 1
            area = box_width * box_height
            if count < 12 or box_width < 5 or box_height < 4 or area > sw * sh * 0.55:
                continue
            if box_width / max(1.0, box_height) > 18.0 or box_height / max(1.0, box_width) > 10.0:
                continue
            density = count / max(1.0, float(area))
            confidence = clamp(0.45 + min(0.22, density * 0.32) + min(0.15, math.log1p(area) / 55.0), 0.45, 0.82)
            mapped = self._map_box((min_x * stride, min_y * stride, (max_x + 1) * stride, (max_y + 1) * stride), frame.get("viewport"), width, height)
            regions.append({
                "text": "", "role": "visual_region", "bbox": mapped, "confidence": confidence, "source": "vision",
                "locator": {"engine": "local_cv", "edge_density": round(density, 4)},
            })
        regions.sort(key=lambda item: (-(item["bbox"][2] - item["bbox"][0]) * (item["bbox"][3] - item["bbox"][1]), -item["confidence"]))
        return regions[:max(8, self.max_elements // 2)]

    def analyze(self, frame, goal_text=""):
        if not isinstance(frame, dict) or not frame.get("rgb"):
            return []
        self.last_error = ""
        result = self._visual_regions(frame)
        # 纯像素区域本身没有伪造文本；文字语义由 UI Automation 层提供并在上层融合。
        result.sort(key=lambda item: -safe_float(item.get("confidence")))
        return result[:self.max_elements]


@dataclass
class SymbolicWorldState:
    """由 UIA、视觉和窗口结构提取的只读世界状态。"""
    facts: set = field(default_factory=set)
    controls: list = field(default_factory=list)
    semantic_text: str = ""
    window_title: str = ""
    window_class: str = ""
    process_name: str = ""

    @staticmethod
    def _record_text(record):
        return " ".join(str(record.get(key, "")) for key in ("name", "value", "help", "automation_id", "control_type", "class_name")).strip()

    @classmethod
    def from_observation(cls, observation, visual_elements=None):
        controls = [dict(record, source="uia") for record in observation.accessibility.records if not record.get("offscreen")]
        for item in visual_elements or []:
            if isinstance(item, VisualElement):
                item = item.as_dict()
            if not isinstance(item, dict):
                continue
            box = item.get("bbox") or (0.0, 0.0, 0.0, 0.0)
            if len(box) < 4: continue
            controls.append({
                "name": str(item.get("text", "")), "value": "", "help": "", "automation_id": "",
                "control_type": "Visual", "class_name": str(item.get("role", "visual")), "enabled": True,
                "offscreen": False, "focused": False, "password": False, "source": "vision",
                "x_norm": (safe_float(box[0]) + safe_float(box[2])) * 0.5,
                "y_norm": (safe_float(box[1]) + safe_float(box[3])) * 0.5,
                "bounding_normalized": tuple(box[:4]), "visual_locator": dict(item.get("locator") or {}),
            })
        facts = {"desktop_default", "context_observed"}
        if any(record.get("focused") for record in controls): facts.add("some_control_focused")
        if any(record.get("control_type") in INTERACTIVE_CONTROL_TYPES for record in controls): facts.add("interactive_controls_visible")
        if any(record.get("source") == "vision" for record in controls): facts.add("visual_context_available")
        return cls(
            facts=facts, controls=controls, semantic_text=str(observation.semantic_text or ""),
            window_title=str(observation.accessibility.window_title or ""), window_class=str(observation.accessibility.window_class or ""),
            process_name=str(getattr(observation, "process_name", "") or ""),
        )

    def matching_controls(self, query, types=None, limit=6):
        query = str(query or "").strip()
        result = []
        for record in self.controls:
            if record.get("offscreen") or not record.get("enabled") or record.get("password"):
                continue
            if types and record.get("control_type") not in types and record.get("source") != "vision":
                continue
            text = self._record_text(record)
            score = similarity(query, text) if query else 0.05
            if query and query.lower() in text.lower(): score += 0.55
            if record.get("focused"): score += 0.12
            if record.get("source") == "uia": score += 0.08
            if record.get("control_type") in INTERACTIVE_CONTROL_TYPES: score += 0.08
            result.append((score, record))
        result.sort(key=lambda item: item[0], reverse=True)
        return [record for score, record in result[:max(1, int(limit))] if score >= (0.04 if query else 0.0)]

    def application_matches(self, name):
        name = str(name or "").strip().lower()
        joined = " ".join((self.window_title, self.window_class, self.process_name, self.semantic_text)).lower()
        aliases = {
            "browser": ("browser", "浏览器", "chrome", "edge", "firefox"),
            "excel": ("excel", "电子表格", "xlmain"),
            "mail": ("mail", "邮件", "outlook", "foxmail", "thunderbird"),
        }
        if name and name in joined: return True
        for values in aliases.values():
            if any(value in name for value in values) and any(value in joined for value in values): return True
        return False


@dataclass(frozen=True)
class OperatorSpec:
    name: str
    preconditions: tuple
    effects: tuple
    cost: float
    risk: float


@dataclass
class CandidatePlan:
    operators: list
    commands: list
    cost: float
    risk: float
    rationale: str = ""


class GenericOperatorPlanner:
    """通用操作符规划器；A* 搜索前置条件/效果，实例化后交给 Q 网络排序。"""

    def __init__(self, resource_budget=None, memory=None):
        self.resource_budget = resource_budget
        self.memory = memory

    OPERATORS = (
        OperatorSpec("Observe", (), ("observed",), 0.20, 0.00),
        OperatorSpec("Locate", ("observed",), ("located",), 0.55, 0.00),
        OperatorSpec("Focus", ("located",), ("focused",), 0.65, 0.04),
        OperatorSpec("Activate", ("located",), ("activated",), 0.85, 0.16),
        OperatorSpec("EnterText", ("focused",), ("value_present",), 0.75, 0.10),
        OperatorSpec("PressKey", ("observed",), ("key_sent",), 0.55, 0.08),
        OperatorSpec("SwitchApplication", ("observed",), ("application_ready",), 1.10, 0.12),
        OperatorSpec("Verify", ("observed",), ("verified",), 0.25, 0.00),
    )
    BY_NAME = {operator.name: operator for operator in OPERATORS}
    GOALS = {
        "Observe": "observed", "Locate": "located", "Focus": "focused", "Activate": "activated",
        "EnterText": "value_present", "PressKey": "key_sent", "SwitchApplication": "application_ready",
        "Verify": "verified", "Assert": "verified",
    }
    LEGACY_MAP = {
        "observe_context":"Observe", "locate_target":"Locate", "locate_object":"Locate", "select_object":"Focus",
        "request_rename":"PressKey", "acquire_editor":"Focus", "replace_text":"EnterText",
        "commit_edit":"PressKey", "commit_formula":"PressKey", "verify_object":"Verify", "verify_formula_result":"Verify",
        "close_window":"PressKey", "formula_mode":"PressKey", "ensure_application":"SwitchApplication", "ensure_url":"SwitchApplication",
        "activate_control":"Activate", "search":"EnterText", "find":"EnterText", "save":"PressKey",
        "candidate_subgoal":"Activate", "commit_candidate":"Activate", "verify_result":"Verify", "compile_success":"Verify",
        "observe_condition":"Observe", "loop_check":"Observe", "assert":"Assert",
    }

    @classmethod
    def canonical_operator(cls, step):
        value = str(step.get("operator") or step.get("operation") or step.get("action") or "Observe")
        normalized = value.replace("_", "").lower()
        for name in cls.GOALS:
            if name.replace("_", "").lower() == normalized:
                return name
        return cls.LEGACY_MAP.get(value, cls.LEGACY_MAP.get(value.lower(), "Observe"))

    def _search(self, initial, goal_fact):
        initial = frozenset(initial)
        if self.resource_budget is not None:
            max_depth = int(self.resource_budget.planner_depth())
        else:
            # 无注入预算器时也按当前机器资源计算，而不是退回固定最终深度。
            _total_ram, available_ram = ResourceBudget._ram_status()
            try:
                free_disk = int(shutil.disk_usage(str(Path(__file__).resolve().parent)).free)
            except Exception:
                free_disk = 512 * 1024 ** 2
            ram_mib = max(1.0, available_ram / float(1024 ** 2))
            disk_gib = max(0.25, free_disk / float(1024 ** 3))
            max_depth = max(8, int(math.log2(1.0 + ram_mib) * math.sqrt(disk_gib)))
        queue_items = [(0.0, 0, initial, [])]; visited = {initial: 0.0}; serial = 0
        while queue_items:
            score, _, facts, path = heapq.heappop(queue_items)
            if goal_fact in facts:
                return path
            if len(path) >= max_depth:
                continue
            for operator in self.OPERATORS:
                if not set(operator.preconditions).issubset(facts):
                    continue
                next_facts = frozenset(set(facts) | set(operator.effects))
                if next_facts == facts:
                    continue
                cost = score + operator.cost + operator.risk * 0.45
                if cost + 1e-9 >= visited.get(next_facts, 1e99):
                    continue
                visited[next_facts] = cost; serial += 1
                heapq.heappush(queue_items, (cost, serial, next_facts, path + [operator.name]))
        return []

    @staticmethod
    def _step_value(step):
        parameters = dict(step.get("parameters") or {})
        values = parameters.get("quoted_values") or []
        return str(step.get("value") or parameters.get("value") or parameters.get("text") or (values[-1] if values else "") or step.get("payload") or "").strip()

    @staticmethod
    def _key_parameters(step):
        parameters = dict(step.get("parameters") or {})
        if "vk" in parameters:
            return int(parameters.get("vk", 0x09)), [int(value) for value in parameters.get("modifiers", [])]
        gui = list(step.get("gui") or [])
        key_spec = next((item for item in gui if isinstance(item, dict) and item.get("op") == "key"), {})
        if key_spec:
            return int(key_spec.get("vk", 0x09)), [int(value) for value in key_spec.get("modifiers", [])]
        payload = str(step.get("payload", "")).lower()
        if payload in ("enter", "回车"): return 0x0D, []
        if payload == "f2": return 0x71, []
        if "alt+f4" in payload or str(step.get("operation", "")) == "close_window": return 0x73, [0x12]
        if str(step.get("operation", "")) in ("commit_edit", "commit_formula"): return 0x0D, []
        return 0x09, []

    @staticmethod
    def _is_start_search(world):
        joined = " ".join((world.window_title, world.window_class, world.semantic_text)).lower()
        return any(value in joined for value in ("windows search", "searchhost", "type here to search", "windows 搜索", "开始菜单"))

    @staticmethod
    def _click_command(record, label):
        x = clamp(safe_float(record.get("x_norm"), 0.5), 0.0, 1.0); y = clamp(safe_float(record.get("y_norm"), 0.5), 0.0, 1.0)
        parameters = {"x": x, "y": y, "button": "left"}
        source = str(record.get("source", "uia"))
        if source == "uia":
            parameters["target"] = control_locator(record)
        else:
            locator = dict(record.get("visual_locator") or {})
            stable = bool(locator.get("local_visual_stable"))
            parameters.update({
                "explicit_visual_target": stable, "local_visual_stable": stable,
                "visual_target_text": str(record.get("name", "")), "visual_bbox": list(record.get("bounding_normalized") or []),
            })
        command = ActionCommand(CLICK, parameters, label, [x, y, 0.0], 0b111)
        command.evidence_source = "local_visual" if source == "vision" else "uia"
        return command

    @staticmethod
    def _decorate(command, step, operator_name):
        capabilities = list(step.get("capabilities") or [])
        reason = "通用操作符 {}：{}".format(operator_name, str(step.get("source") or step.get("payload") or step.get("target") or "")[:220])
        if operator_name == "SwitchApplication" and "cross_program" not in capabilities:
            capabilities.append("cross_program")
        command.declare(capabilities, reason if capabilities else "")
        if "cross_program" in command.required_capabilities:
            token_source = "|".join((operator_name, str(step.get("source", "")), str(step.get("target", ""))))
            command.compiled_scope_token = hashlib.blake2s(token_source.encode("utf-8", "ignore"), digest_size=10).hexdigest()
            command.compiled_scope_target = str(step.get("target") or step.get("payload") or "")[:220]
        command.parameters["symbolic_operator"] = operator_name
        return command

    def _instantiate(self, operator_name, goal, step, world, allowed):
        target = str(step.get("target") or step.get("object") or step.get("object_ref") or step.get("payload") or "").strip()
        value = self._step_value(step)
        types = None
        if operator_name in ("Focus", "EnterText"):
            types = SafetyPolicy.SAFE_TEXT_TYPES
        matches = world.matching_controls(target, types=types, limit=5) if target else []
        commands = []
        if operator_name == "Observe" and WAIT in allowed:
            commands.append(ActionCommand(WAIT, {"duration": 0.10, "force_deep_observation": True}, "Observe：刷新世界状态", [0.22], 0b1))
        elif operator_name == "Locate":
            if matches and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.06}, "Locate：已定位 {}".format(target[:96]), [0.16], 0b1))
            if not matches and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": True}, "Locate：扩大 UIA/本地视觉搜索 {}".format(target[:96]), [0.38], 0b1))
            if not matches and SCROLL in allowed:
                commands.append(ActionCommand(SCROLL, {"amount": 120}, "Locate：滚动后重新观察", [0.56], 0b1))
        elif operator_name == "Focus":
            focused = next((record for record in matches if record.get("focused")), None)
            if focused is not None and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.05}, "Focus：目标已聚焦", [0.14], 0b1))
            for record in matches:
                if CLICK in allowed:
                    commands.append(self._click_command(record, "Focus：{}".format(str(record.get("name") or target)[:96])))
            if not commands and KEY in allowed:
                commands.append(ActionCommand(KEY, {"vk": 0x09, "modifiers": []}, "Focus：Tab 定位下一个控件", [0.2], 0b1))
        elif operator_name == "Activate":
            interactive = world.matching_controls(target, types=INTERACTIVE_CONTROL_TYPES, limit=5)
            for record in interactive:
                if CLICK in allowed:
                    commands.append(self._click_command(record, "Activate：{}".format(str(record.get("name") or target)[:96])))
            if not commands and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": True}, "Activate：目标缺少可靠点击证据，重新观察", [0.38], 0b1))
        elif operator_name == "EnterText":
            focused = next((record for record in world.controls if record.get("focused") and record.get("control_type") in SafetyPolicy.SAFE_TEXT_TYPES and not record.get("password")), None)
            focused_text = SymbolicWorldState._record_text(focused or {}).lower()
            if focused is None:
                for record in matches:
                    if CLICK in allowed: commands.append(self._click_command(record, "Focus：输入前聚焦 {}".format(str(record.get("name") or target)[:96])))
            elif value and value.lower() in focused_text and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.06}, "EnterText：目标值已由结构化控件读回", [0.16], 0b1))
            elif str(getattr(goal, "compiled_phase", "")) != "text_selected" and KEY in allowed:
                commands.append(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11], "next_compiled_phase": "text_selected"}, "EnterText：先选中现有值", [0.0], 0b1))
            elif value and TYPE in allowed:
                commands.append(ActionCommand(TYPE, {"text": value}, "EnterText：输入 {}".format(value[:96]), [0.0], 0b1))
        elif operator_name == "PressKey" and KEY in allowed:
            vk, modifiers = self._key_parameters(step)
            commands.append(ActionCommand(KEY, {"vk": vk, "modifiers": modifiers}, "PressKey：{}".format(str(step.get("payload") or hex(vk))), [0.0], 0b1))
        elif operator_name == "SwitchApplication":
            application = target or value
            if world.application_matches(application) and WAIT in allowed:
                commands.append(ActionCommand(WAIT, {"duration": 0.08}, "SwitchApplication：目标应用已在前台", [0.18], 0b1))
            elif self._is_start_search(world):
                focused = next((record for record in world.controls if record.get("focused") and record.get("control_type") in SafetyPolicy.SAFE_TEXT_TYPES), None)
                focused_text = self._step_value({"value": SymbolicWorldState._record_text(focused or {})}).lower()
                if focused is not None and application.lower() not in focused_text and TYPE in allowed:
                    commands.append(ActionCommand(TYPE, {"text": application}, "SwitchApplication：在 Windows Search 输入目标应用", [0.0], 0b1))
                elif focused is not None and KEY in allowed:
                    commands.append(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "SwitchApplication：启动并重新验证", [0.0], 0b1))
            elif KEY in allowed:
                commands.append(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "SwitchApplication：打开 Windows Search", [0.0], 0b1))
        elif operator_name in ("Verify", "Assert") and WAIT in allowed:
            commands.append(ActionCommand(WAIT, {"duration": 0.12, "force_deep_observation": True}, "{}：只读验证目标状态".format(operator_name), [0.28], 0b1))
        return [self._decorate(command, step, operator_name) for command in commands if command.kind in allowed]

    def _learned_operator_plans(self, goal, observation, allowed):
        """把 SQLite skill_memory 中的可验证程序技能暴露为数据驱动高层 operator。

        8 个底层原语保持固定；高层 operator 的数量、前置条件、后置条件、验证器和恢复策略
        来自持久化技能，可随经验持续增加。
        """
        if self.memory is None or SKILL not in allowed:
            return []
        try:
            breadth = int(self.resource_budget.planner_breadth()) if self.resource_budget is not None else 48
        except Exception:
            breadth = 48
        try:
            skills = self.memory.top_skills(max(8, breadth))
        except Exception:
            return []
        plans = []
        active_step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else {}
        goal_text = " ".join((
            str(getattr(goal, "requested_goal", "")),
            str((active_step or {}).get("source", "")), str((active_step or {}).get("target", "")),
            str((active_step or {}).get("payload", "")), compact_json((active_step or {}).get("parameters", {})),
        )).strip()
        goal_units = set(semantic_units(goal_text))
        for skill in skills:
            try:
                if not SkillManager.precondition_matches(skill, observation):
                    continue
                skill_text = " ".join((
                    str(skill.get("name", "")), compact_json(skill.get("expected") or {}),
                    compact_json(skill.get("success") or {}), compact_json(skill.get("parameters") or {}),
                ))
                skill_units = set(semantic_units(skill_text))
                relevance = similarity(goal_text, skill_text) if goal_text else 0.0
                if goal_units and skill_units:
                    relevance = max(relevance, len(goal_units & skill_units) / max(1, len(goal_units | skill_units)))
                # 数据驱动不等于无条件抢占：必须与当前目标/子目标存在可解释关联。
                if goal_text and relevance < 0.10:
                    continue
                success = dict(skill.get("success") or skill.get("expected") or {})
                recovery = list(skill.get("recovery") or [])
                if not success or not recovery:
                    continue
                capabilities = list(skill.get("capabilities") or [])
                name = "LearnedOperator:{}".format(str(skill.get("name", "skill"))[:96])
                schema = {
                    "preconditions": dict(skill.get("precondition") or {}),
                    "postconditions": dict(skill.get("expected") or {}),
                    "validator": success, "recovery": recovery,
                    "program_version": int(skill.get("program_version", 1)),
                }
                command = ActionCommand(
                    SKILL, {"skill_id": int(skill.get("id", 0)), "args": {}, "operator_schema": schema},
                    "数据驱动高层操作符：{}".format(str(skill.get("name", "skill"))[:96]),
                    [clamp(1.0 - safe_float(skill.get("score", 0.0)) * 0.5, 0.0, 1.0)], 0b1,
                )
                command.declare(capabilities, "SQLite skill operator schema")
                cost = clamp(1.2 - safe_float(skill.get("score", 0.0)) * 0.35 + safe_float(skill.get("average_seconds", 0.0)) * 0.02, 0.15, 4.0)
                risk = clamp(0.06 + 0.08 * len(capabilities), 0.0, 0.75)
                plans.append(CandidatePlan([name], [command], cost, risk, "SQLite skill_memory：前置条件→程序→验证器→恢复策略"))
            except Exception:
                continue
        plans.sort(key=lambda plan: (plan.cost + plan.risk * 0.45, plan.risk))
        return plans[:max(1, breadth)]

    def candidate_plans(self, goal, observation, allowed, visual_elements=None):
        step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else None
        if step is None:
            return []
        if str(getattr(goal, "compiled_phase", "")) == "recovery" and int(getattr(goal, "compiled_attempts", 0)) > max(0, int(step.get("max_retries", 2))):
            goal.compiler_stalled = True
            if WAIT in allowed:
                command = ActionCommand(WAIT, {"duration":0.22, "force_deep_observation":True, "symbolic_operator":"Observe"}, "Operator 恢复预算耗尽：停止重放并等待重新规划", [0.5], 0b1)
                return [CandidatePlan(["Observe"], [command], 1.5, 0.0, "有界恢复/等待元认知重新规划")]
            return []
        world = SymbolicWorldState.from_observation(observation, visual_elements=visual_elements)
        operator_name = self.canonical_operator(step)
        target = str(step.get("target") or step.get("object") or step.get("object_ref") or step.get("payload") or "")
        value = self._step_value(step)
        facts = set(world.facts) | {"observed"}
        matches = world.matching_controls(target, limit=4) if target else []
        if matches: facts.add("located")
        if any(record.get("focused") for record in matches): facts.add("focused")
        if value and value.lower() in world.semantic_text.lower(): facts.add("value_present")
        if operator_name == "SwitchApplication" and world.application_matches(target or value): facts.add("application_ready")
        goal_fact = self.GOALS.get(operator_name, "observed")
        abstract_path = self._search(facts, goal_fact) or [operator_name]
        next_operator = abstract_path[0] if abstract_path else operator_name
        # 当前 DSL 指令本身必须执行；A* 只在前置条件缺失时插入 Locate/Focus 等通用操作符。
        if goal_fact in facts:
            next_operator = operator_name
        commands = self._instantiate(next_operator, goal, step, world, allowed)
        if not commands and next_operator != operator_name:
            commands = self._instantiate(operator_name, goal, step, world, allowed)
        plans = []
        for command in commands:
            specs = [self.BY_NAME[name] for name in abstract_path if name in self.BY_NAME]
            plans.append(CandidatePlan(
                operators=list(abstract_path), commands=[command],
                cost=sum(item.cost for item in specs) + 0.02 * len(abstract_path),
                risk=sum(item.risk for item in specs),
                rationale="{} → {}（前置条件/效果 A*）".format(operator_name, " → ".join(abstract_path)),
            ))
        plans.extend(self._learned_operator_plans(goal, observation, allowed))
        plans.sort(key=lambda plan: (plan.cost + plan.risk * 0.45, plan.risk))
        return plans


class ReasoningBackend:
    """本地符号推理核心：世界状态、子目标、前置/效果和候选计划。"""

    PROTOCOL = "local-symbolic-reasoning-v2"

    def __init__(self, resource_budget=None, memory=None):
        self.configured = True
        self.enabled = True
        self.allow_ui_context = True
        self.allow_screenshots = True
        self.last_error = ""
        self.last_graph = {}
        self.last_visual = []
        self.last_visual_signature = ""
        self.last_visual_at = 0.0
        self.force_visual_refresh = False
        self.visual_recognizer = LocalVisualRecognizer()
        self.operator_planner = GenericOperatorPlanner(resource_budget, memory=memory)

    @staticmethod
    def _sensitive_observation(observation):
        title = " ".join((str(observation.accessibility.window_title), str(observation.accessibility.window_class))).lower()
        return bool(getattr(observation, "any_password", False)) or any(value in title for value in ("credential", "authui", "uac", "payment", "密码", "凭据", "支付"))

    @staticmethod
    def visual_tier(observation):
        return "full" if safe_float(getattr(observation, "uia_quality", 0.0)) < 0.10 else "roi"

    def invalidate(self):
        self.last_visual_signature = ""
        self.last_visual_at = 0.0
        self.force_visual_refresh = True

    def _local_graph(self, goal):
        try:
            program = GoalCompiler.graph(goal.requested_goal)
        except Exception:
            program = {"goal": goal.requested_goal, "nodes": list(goal.compiled_steps)}
        return {
            "source": self.PROTOCOL, "goal": goal.requested_goal,
            "program": program, "nodes": list(goal.compiled_steps),
            "completion_evidence": list(goal._phrases()),
        }

    def needs_refresh(self, _goal, observation, _allowed, mode="task"):
        if self._sensitive_observation(observation):
            return False
        if self.force_visual_refresh:
            return True
        if time.monotonic() - self.last_visual_at < 0.75:
            return False
        limited = bool(getattr(observation, "perception_limited", False))
        return bool(limited and (observation.visual_signature != self.last_visual_signature or not self.last_visual))

    @staticmethod
    def _stabilize_visual(previous, current):
        stabilized = []
        for item in current:
            local = dict(item); locator = dict(local.get("locator") or {})
            box = local.get("bbox") or (0, 0, 0, 0)
            cx = (safe_float(box[0]) + safe_float(box[2])) * 0.5; cy = (safe_float(box[1]) + safe_float(box[3])) * 0.5
            stable = False
            for old in previous:
                old_box = old.get("bbox") or (0, 0, 0, 0)
                ox = (safe_float(old_box[0]) + safe_float(old_box[2])) * 0.5; oy = (safe_float(old_box[1]) + safe_float(old_box[3])) * 0.5
                same_text = not local.get("text") or not old.get("text") or similarity(local.get("text", ""), old.get("text", "")) >= 0.82
                if same_text and math.hypot(cx - ox, cy - oy) <= 0.018:
                    stable = True; break
            locator["local_visual_stable"] = stable
            local["locator"] = locator
            stabilized.append(local)
        return stabilized

    def decide(self, goal, observation, allowed, mode="task", frame=None, force=False):
        visual = [item.as_dict() if isinstance(item, VisualElement) else dict(item) for item in (getattr(observation, "visual_elements", []) or []) if isinstance(item, (VisualElement, dict))]
        error = ""
        if frame is not None and not self._sensitive_observation(observation):
            try:
                visual = self._stabilize_visual(self.last_visual, self.visual_recognizer.analyze(frame, goal.requested_goal))
                self.last_visual = list(visual)
                self.last_visual_signature = str(observation.visual_signature)
                self.last_visual_at = time.monotonic()
                self.force_visual_refresh = False
                error = self.visual_recognizer.last_error
            except Exception as visual_error:
                error = str(visual_error)[:320]
        plans = self.operator_planner.candidate_plans(goal, observation, allowed, visual_elements=visual)
        commands = [plan.commands[0] for plan in plans if plan.commands]
        graph = self._local_graph(goal)
        world = SymbolicWorldState.from_observation(observation, visual_elements=visual)
        graph.update({
            "world_state": {
                "facts": sorted(world.facts), "window": world.window_title, "process": world.process_name,
                "uia_controls": sum(1 for item in world.controls if item.get("source") == "uia"),
                "visual_controls": sum(1 for item in world.controls if item.get("source") == "vision"),
            },
            "active_subgoal": dict(goal.active_compiled_step() or {}),
            "candidate_plans": [{"operators": plan.operators, "cost": plan.cost, "risk": plan.risk, "rationale": plan.rationale} for plan in plans],
        })
        self.last_graph = graph
        self.last_error = error
        return {
            "graph": graph, "command": commands[0] if commands else None, "candidates": commands,
            "visual_elements": visual, "source": self.PROTOCOL, "error": error,
        }


class ApprovalFreeze:
    """一次性高风险批准冻结：动作 + 程序/窗口关系 + UIA 目标 + 页面语义。页面变化后 token 自动失效。"""
    process_path: str
    process_name: str
    hwnd: int
    owner_hwnd: int
    window_title: str
    window_class: str
    semantic_signature: str
    automation_id: str
    control_type: str
    control_text: str
    operation_kind: int
    parameter_hash: str

    @classmethod
    def capture(cls, command, observation):
        record = None
        if int(getattr(command, "kind", WAIT)) == CLICK:
            record = control_at_point(
                observation, safe_float(command.parameters.get("x", 0.5), 0.5),
                safe_float(command.parameters.get("y", 0.5), 0.5), radius=0.12,
            )
        if record is None:
            record = next((item for item in observation.accessibility.records if item.get("focused")), None)
        record = record or {}
        control_text = re.sub(r"\s+", " ", " ".join((
            str(record.get("name", "")), str(record.get("value", "")),
            str(record.get("help", "")), str(record.get("class_name", "")),
        )).strip())[:320]
        parameters = dict(getattr(command, "parameters", {}) or {})
        # 运行期证据标记不属于用户批准参数。
        parameters.pop("_verified_skill", None)
        parameter_hash = hashlib.blake2s(compact_json({
            "kind": int(getattr(command, "kind", WAIT)), "parameters": parameters,
            "required_capabilities": sorted(set(getattr(command, "required_capabilities", []) or [])),
        }).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        return cls(
            process_path=str(getattr(observation, "process_path", "") or "").lower(),
            process_name=str(getattr(observation, "process_name", "") or "").lower(),
            hwnd=int(getattr(observation.accessibility, "hwnd", 0) or 0),
            owner_hwnd=int(getattr(observation, "owner_hwnd", 0) or 0),
            window_title=str(getattr(observation.accessibility, "window_title", "") or "")[:320],
            window_class=str(getattr(observation.accessibility, "window_class", "") or "")[:160],
            semantic_signature=str(getattr(observation, "semantic_signature", "") or ""),
            automation_id=str(record.get("automation_id", "") or "")[:240],
            control_type=str(record.get("control_type", "") or "")[:120],
            control_text=control_text, operation_kind=int(getattr(command, "kind", WAIT)), parameter_hash=parameter_hash,
        )

    def token(self):
        payload = {
            "process_path": self.process_path, "process_name": self.process_name, "hwnd": self.hwnd, "owner_hwnd": self.owner_hwnd,
            "window_title": self.window_title, "window_class": self.window_class, "semantic_signature": self.semantic_signature,
            "automation_id": self.automation_id, "control_type": self.control_type, "control_text": self.control_text,
            "operation_kind": self.operation_kind, "parameter_hash": self.parameter_hash,
        }
        return hashlib.blake2s(compact_json(payload).encode("utf-8", "ignore"), digest_size=20).hexdigest()


class DoubleQNetwork:
    def __init__(self, input_count=FEATURE_COUNT, layer_sizes=None, capacities=None):
        self.input_count = int(input_count)
        self.layer_sizes = [int(value) for value in (layer_sizes or [48, 32]) if int(value) > 0]
        if not self.layer_sizes:
            self.layer_sizes = [48, 32]
        self.action_count = ACTION_COUNT
        self.parameter_count = PARAM_COUNT
        self.param_head_sizes = list(PARAM_HEAD_SIZES)
        self.sleep_count = 0
        self.training_steps = 0
        self.target_syncs = 0
        self.accepted_growth = 0
        self.rejected_growth = 0
        self.reward_average = 0.0
        self.loss_average = 0.0
        self.progress_average = 0.0
        self.safety_average = 0.0
        self.capacities = {
            "uia_depth": 4, "uia_nodes": 128, "attention_candidates": 8,
            "memory_horizon": 16, "planner_breadth": 48, "skill_attention": 128,
            "adaptive_input": max(0, self.input_count - BASE_FEATURE_COUNT),
            "visual_roi_scale": 2, "forward_cache_entries": 32, "observation_cache_ms": 120,
        }
        if capacities:
            for key, value in capacities.items():
                if key in self.capacities:
                    # adaptive_input=0 是合法状态；其余容量至少为 1。
                    minimum = 0 if key == "adaptive_input" else 1
                    self.capacities[key] = max(minimum, int(value))
        source = random.Random(secrets.randbits(256))
        self.layers = []
        self.biases = []
        self.layer_modes = []
        previous = self.input_count
        for size in self.layer_sizes:
            scale = math.sqrt(2.0 / max(1, previous))
            self.layers.append([array("f", (source.uniform(-scale, scale) for _ in range(previous))) for _ in range(size)])
            self.biases.append(array("f", (source.uniform(-0.01, 0.01) for _ in range(size))))
            self.layer_modes.append("tanh")
            previous = size
        output_size = self.layer_sizes[-1]
        scale = math.sqrt(2.0 / max(1, output_size))
        self.wq = [array("f", (source.uniform(-scale, scale) for _ in range(output_size))) for _ in range(self.action_count)]
        self.bq = array("f", [0.0] * self.action_count)
        self.wp = []
        self.bp = []
        for action, count in enumerate(self.param_head_sizes):
            local_scale = scale * 0.35
            self.wp.append([array("f", (source.uniform(-local_scale, local_scale) for _ in range(output_size))) for _ in range(count)])
            self.bp.append(array("f", [0.0] * count))
        self._np_cache = {}
        self._forward_cache = OrderedDict()
        self._training_mode = False
        self.compute_backend = "numpy" if _np is not None else "stdlib-array"
        # 初始化目标网络不是一次训练同步，不计入统计。
        self.sync_target(count_stat=False)

    @property
    def hidden_count(self):
        return sum(self.layer_sizes)

    @property
    def depth(self):
        return len(self.layer_sizes)

    @staticmethod
    def _activate(inputs, rows, biases):
        result = []
        for row, bias in zip(rows, biases):
            total = float(bias)
            for weight, value in zip(row, inputs):
                total += float(weight) * value
            result.append(math.tanh(total))
        return result

    @staticmethod
    def _linear(inputs, rows, biases):
        result = []
        for row, bias in zip(rows, biases):
            total = float(bias)
            for weight, value in zip(row, inputs):
                total += float(weight) * value
            result.append(total)
        return result

    def _invalidate_accelerator(self, target=None):
        if not hasattr(self, "_np_cache"):
            self._np_cache = {}
        if not hasattr(self, "_forward_cache"):
            self._forward_cache = OrderedDict()
        self._forward_cache.clear()
        if target is None:
            self._np_cache.clear()
        else:
            self._np_cache.pop("target" if target else "online", None)

    def _numpy_pack(self, target=False):
        if _np is None:
            return None
        key = "target" if target else "online"
        cached = self._np_cache.get(key)
        if cached is not None:
            return cached
        layers = self.tlayers if target else self.layers
        biases = self.tbiases if target else self.biases
        modes = self.tlayer_modes if target else self.layer_modes
        qrows = self.twq if target else self.wq
        qbias = self.tbq if target else self.bq
        packed = {
            "layers": [_np.asarray(rows, dtype=_np.float32) for rows in layers],
            "biases": [_np.asarray(values, dtype=_np.float32) for values in biases],
            "modes": list(modes),
            "q": _np.asarray(qrows, dtype=_np.float32),
            "qb": _np.asarray(qbias, dtype=_np.float32),
        }
        if not target:
            packed["p"] = [(_np.asarray(self.wp[action], dtype=_np.float32) if self.param_head_sizes[action] else None) for action in range(self.action_count)]
            packed["pb"] = [(_np.asarray(self.bp[action], dtype=_np.float32) if self.param_head_sizes[action] else None) for action in range(self.action_count)]
        self._np_cache[key] = packed
        return packed

    def _forward_numpy(self, state, target=False):
        packed = self._numpy_pack(target)
        value = _np.asarray(normalize_state(state, self.input_count), dtype=_np.float32)
        activations = [value.tolist()]
        for matrix, bias, mode in zip(packed["layers"], packed["biases"], packed["modes"]):
            value = matrix @ value + bias
            if mode != "identity":
                value = _np.tanh(value)
            activations.append(value.tolist())
        q = (packed["q"] @ value + packed["qb"]).tolist()
        if target:
            return activations, [float(x) for x in q], {}
        parameters = {}
        for action, count in enumerate(self.param_head_sizes):
            if not count:
                parameters[action] = []
                continue
            raw = packed["p"][action] @ value + packed["pb"][action]
            raw = _np.clip(raw, -20.0, 20.0)
            parameters[action] = (1.0 / (1.0 + _np.exp(-raw))).astype(float).tolist()
        return activations, [float(x) for x in q], parameters

    def _encode(self, state, target=False):
        state = normalize_state(state, self.input_count)
        rows_list = self.tlayers if target else self.layers
        bias_list = self.tbiases if target else self.biases
        modes = self.tlayer_modes if target else self.layer_modes
        activations = [state]
        value = state
        for rows, biases, mode in zip(rows_list, bias_list, modes):
            linear = self._linear(value, rows, biases)
            value = linear if mode == "identity" else [math.tanh(total) for total in linear]
            activations.append(value)
        return activations

    def forward(self, state, target=False):
        training = bool(getattr(self, "_training_mode", False))
        normalized = normalize_state(state, self.input_count)
        cache_key = None
        if not training:
            raw = array("f", normalized)
            if sys.byteorder != "little":
                raw.byteswap()
            cache_key = (bool(target), hashlib.blake2s(raw.tobytes(), digest_size=12).digest())
            cached = self._forward_cache.get(cache_key)
            if cached is not None:
                self._forward_cache.move_to_end(cache_key)
                return cached
        if _np is not None and not training:
            result = self._forward_numpy(normalized, target)
        else:
            activations = self._encode(normalized, target)
            hidden = activations[-1]
            if target:
                result = (activations, self._linear(hidden, self.twq, self.tbq), {})
            else:
                q_values = self._linear(hidden, self.wq, self.bq)
                parameters = {}
                for action, count in enumerate(self.param_head_sizes):
                    if not count:
                        parameters[action] = []
                        continue
                    raw_values = self._linear(hidden, self.wp[action], self.bp[action])
                    parameters[action] = [1.0 / (1.0 + math.exp(-clamp(value, -20.0, 20.0))) for value in raw_values]
                result = (activations, q_values, parameters)
        if cache_key is not None:
            self._forward_cache[cache_key] = result
            limit = max(1, int(self.capacities.get("forward_cache_entries", 32)))
            while len(self._forward_cache) > limit:
                self._forward_cache.popitem(last=False)
        return result

    def parameters_for(self, state, action):
        return self.forward(state)[2].get(int(action), [])

    def choose(self, state, allowed, exploration, action_bias=None):
        if not allowed:
            return WAIT, [0.5] * self.param_head_sizes[WAIT]
        _, values, parameters = self.forward(state)
        biases = action_bias or {}
        adjusted = {index: values[index] + float(biases.get(index, 0.0)) for index in allowed}
        if random.random() < exploration:
            action = random.choice(list(allowed))
        else:
            best = max(adjusted.values())
            action = random.choice([index for index in allowed if adjusted[index] >= best - 1e-12])
        return action, list(parameters.get(action, []))

    def sync_target(self, count_stat=True):
        self.tlayers = [[array("f", row) for row in rows] for rows in self.layers]
        self.tbiases = [array("f", values) for values in self.biases]
        self.tlayer_modes = list(self.layer_modes)
        self.twq = [array("f", row) for row in self.wq]
        self.tbq = array("f", self.bq)
        self._invalidate_accelerator(target=True)
        if count_stat:
            self.target_syncs += 1

    def train_one(self, item, learning_rate=0.0011, gamma=0.94, allow_target_sync=True):
        # NumPy 可用时，前向、Double-Q 目标、反向传播和参数更新全部走向量化路径。
        # 标准库实现仅作为没有 NumPy 时的完整 fallback。
        if _np is not None:
            return self._train_one_numpy(item, learning_rate, gamma, allow_target_sync)
        self._training_mode = True
        try:
            return self._train_one_impl(item, learning_rate, gamma, allow_target_sync)
        finally:
            self._training_mode = False
            self._invalidate_accelerator(target=False)

    def _train_one_numpy(self, item, learning_rate=0.0011, gamma=0.94, allow_target_sync=True):
        state = _np.asarray(normalize_state(item["state"], self.input_count), dtype=_np.float32)
        next_state = _np.asarray(normalize_state(item["next_state"], self.input_count), dtype=_np.float32)
        action = int(item["action"]); importance = clamp(float(item.get("importance", 1.0)), 0.15, 1.5)
        packed = self._numpy_pack(False); target_packed = self._numpy_pack(True)

        def encode(value, bundle):
            activations = [value]
            current = value
            for matrix, bias, mode in zip(bundle["layers"], bundle["biases"], bundle["modes"]):
                current = matrix @ current + bias
                if mode != "identity": current = _np.tanh(current)
                activations.append(current)
            return activations

        activations = encode(state, packed); hidden = activations[-1]
        outputs = packed["q"] @ hidden + packed["qb"]
        next_allowed = actions_from_mask(item.get("next_mask", 0))
        future = 0.0
        if next_allowed:
            online_hidden = encode(next_state, packed)[-1]
            online_next = packed["q"] @ online_hidden + packed["qb"]
            selected = max(next_allowed, key=lambda index: float(online_next[index]))
            target_hidden = encode(next_state, target_packed)[-1]
            target_next = target_packed["q"] @ target_hidden + target_packed["qb"]
            future = float(target_next[selected])
        target_value = float(item["reward"]) + gamma ** max(1, int(item.get("n_steps", 1))) * future
        error = float(outputs[action]) - target_value
        q_gradient = clamp(error, -1.0, 1.0) * importance
        old_q_weights = packed["q"][action].copy()
        packed["q"][action] -= _np.float32(learning_rate * q_gradient) * hidden
        packed["qb"][action] -= _np.float32(learning_rate * q_gradient)
        hidden_gradients = _np.asarray(q_gradient, dtype=_np.float32) * old_q_weights

        targets = list(item.get("parameters", [])); mask = int(item.get("parameter_mask", 0))
        positive_signal = clamp(float(item.get("goal_reward", 0.0)) * 1.6 + max(0.0, float(item["reward"])), 0.0, 1.0)
        parameter_loss = 0.0
        if positive_signal > 0.015 and self.param_head_sizes[action] and packed["p"][action] is not None:
            raw = packed["p"][action] @ hidden + packed["pb"][action]
            raw = _np.clip(raw, -20.0, 20.0); predictions = 1.0 / (1.0 + _np.exp(-raw))
            for parameter_index in range(min(len(predictions), len(targets))):
                if not mask & (1 << parameter_index): continue
                prediction = float(predictions[parameter_index])
                local_error = prediction - clamp(float(targets[parameter_index]), 0.0, 1.0)
                raw_gradient = clamp(local_error * prediction * (1.0 - prediction) * positive_signal * importance, -0.5, 0.5)
                old_weights = packed["p"][action][parameter_index].copy()
                packed["p"][action][parameter_index] -= _np.float32(learning_rate * raw_gradient) * hidden
                packed["pb"][action][parameter_index] -= _np.float32(learning_rate * raw_gradient)
                hidden_gradients += _np.float32(raw_gradient) * old_weights
                parameter_loss += abs(local_error)

        gradient = hidden_gradients
        for layer_index in range(len(packed["layers"]) - 1, -1, -1):
            current = activations[layer_index + 1]; previous = activations[layer_index]
            derivative = _np.ones_like(current) if packed["modes"][layer_index] == "identity" else (1.0 - current * current)
            local = _np.clip(gradient * derivative, -1.0, 1.0).astype(_np.float32, copy=False)
            matrix = packed["layers"][layer_index]; old_matrix = matrix.copy()
            matrix -= _np.float32(learning_rate) * local[:, None] * previous[None, :]
            packed["biases"][layer_index] -= _np.float32(learning_rate) * local
            gradient = old_matrix.T @ local

        # Python array 仍是持久化/结构扩张的权威表示；仅做一次批量同步，不再逐标量 Python 更新。
        self.layers = [[array("f", row.tolist()) for row in matrix] for matrix in packed["layers"]]
        self.biases = [array("f", bias.tolist()) for bias in packed["biases"]]
        self.wq = [array("f", row.tolist()) for row in packed["q"]]
        self.bq = array("f", packed["qb"].tolist())
        for index, count in enumerate(self.param_head_sizes):
            if count and packed["p"][index] is not None:
                self.wp[index] = [array("f", row.tolist()) for row in packed["p"][index]]
                self.bp[index] = array("f", packed["pb"][index].tolist())
        self._forward_cache.clear()
        self.training_steps += 1
        absolute = abs(error) + parameter_loss * 0.08
        self.loss_average = absolute if self.training_steps == 1 else self.loss_average * 0.995 + absolute * 0.005
        if allow_target_sync and self.training_steps % TARGET_SYNC_INTERVAL == 0:
            self.sync_target()
        return absolute

    def _train_one_impl(self, item, learning_rate=0.0011, gamma=0.94, allow_target_sync=True):
        # 没有 NumPy 时的标准库慢速 fallback。
        state = item["state"]
        next_state = item["next_state"]
        action = int(item["action"])
        importance = clamp(float(item.get("importance", 1.0)), 0.15, 1.5)
        activations, outputs, parameter_map = self.forward(state)
        hidden = activations[-1]
        next_allowed = actions_from_mask(item.get("next_mask", 0))
        future = 0.0
        if next_allowed:
            _, online_next, _ = self.forward(next_state)
            selected = max(next_allowed, key=lambda index: online_next[index])
            _, target_next, _ = self.forward(next_state, target=True)
            future = target_next[selected]
        target_value = float(item["reward"]) + gamma ** max(1, int(item.get("n_steps", 1))) * future
        error = outputs[action] - target_value
        q_gradient = clamp(error, -1.0, 1.0) * importance
        old_q_weights = array("f", self.wq[action])
        for index in range(len(hidden)):
            self.wq[action][index] -= learning_rate * q_gradient * hidden[index]
        self.bq[action] -= learning_rate * q_gradient
        hidden_gradients = [q_gradient * float(old_q_weights[index]) for index in range(len(hidden))]
        targets = list(item.get("parameters", []))
        mask = int(item.get("parameter_mask", 0))
        positive_signal = clamp(float(item.get("goal_reward", 0.0)) * 1.6 + max(0.0, float(item["reward"])), 0.0, 1.0)
        parameter_loss = 0.0
        predictions = parameter_map.get(action, [])
        if positive_signal > 0.015:
            for parameter_index in range(min(len(predictions), len(targets))):
                if not mask & (1 << parameter_index):
                    continue
                prediction = predictions[parameter_index]
                local_error = prediction - clamp(float(targets[parameter_index]), 0.0, 1.0)
                raw_gradient = clamp(local_error * prediction * (1.0 - prediction) * positive_signal * importance, -0.5, 0.5)
                old_weights = array("f", self.wp[action][parameter_index])
                for hidden_index in range(len(hidden)):
                    self.wp[action][parameter_index][hidden_index] -= learning_rate * raw_gradient * hidden[hidden_index]
                    hidden_gradients[hidden_index] += raw_gradient * float(old_weights[hidden_index])
                self.bp[action][parameter_index] -= learning_rate * raw_gradient
                parameter_loss += abs(local_error)
        gradient = hidden_gradients
        for layer_index in range(len(self.layers) - 1, -1, -1):
            current = activations[layer_index + 1]
            previous = activations[layer_index]
            previous_gradient = [0.0] * len(previous)
            rows = self.layers[layer_index]
            for neuron_index in range(len(rows)):
                derivative = 1.0 if self.layer_modes[layer_index] == "identity" else (1.0 - current[neuron_index] * current[neuron_index])
                local = clamp(gradient[neuron_index] * derivative, -1.0, 1.0)
                row = rows[neuron_index]
                old_row = array("f", row)
                for input_index, value in enumerate(previous):
                    row[input_index] -= learning_rate * local * value
                    previous_gradient[input_index] += local * float(old_row[input_index])
                self.biases[layer_index][neuron_index] -= learning_rate * local
            gradient = previous_gradient
        self.training_steps += 1
        absolute = abs(error) + parameter_loss * 0.08
        self.loss_average = absolute if self.training_steps == 1 else self.loss_average * 0.995 + absolute * 0.005
        if allow_target_sync and self.training_steps % TARGET_SYNC_INTERVAL == 0:
            self.sync_target()
        return absolute

    def td_error(self, item, gamma=0.94):
        _, outputs, _ = self.forward(item["state"])
        next_allowed = actions_from_mask(item.get("next_mask", 0))
        future = 0.0
        if next_allowed:
            _, online_next, _ = self.forward(item["next_state"])
            selected = max(next_allowed, key=lambda index: online_next[index])
            _, target_next, _ = self.forward(item["next_state"], target=True)
            future = target_next[selected]
        expected = float(item["reward"]) + gamma ** max(1, int(item.get("n_steps", 1))) * future
        return abs(outputs[int(item["action"])] - expected)

    def validation_loss(self, items):
        return 0.0 if not items else sum(self.td_error(item) for item in items) / len(items)

    def benchmark(self, items):
        if not items:
            return {"score": 0.5, "td": 0.5, "action": 0.5, "parameter": 0.5, "safety": 0.5, "preference": 0.5}
        loss = self.validation_loss(items)
        td_score = 1.0 / (1.0 + loss)
        action_scores = []
        parameter_scores = []
        safety_scores = []
        positive_values = []
        negative_values = []
        for item in items:
            _, q_values, parameter_map = self.forward(item["state"])
            action = int(item["action"])
            allowed = actions_from_mask(item.get("current_mask", 0))
            candidates = list(dict.fromkeys(([action] + allowed)))
            if float(item.get("goal_reward", 0.0)) > 0.08 or float(item.get("reward", 0.0)) > 0.18:
                best = max(q_values[index] for index in candidates)
                gap = best - q_values[action]
                action_scores.append(clamp(1.0 - gap, 0.0, 1.0))
                targets = list(item.get("parameters", []))
                predictions = parameter_map.get(action, [])
                mask = int(item.get("parameter_mask", 0))
                local = []
                for index in range(min(len(targets), len(predictions))):
                    if mask & (1 << index):
                        local.append(1.0 - abs(float(targets[index]) - float(predictions[index])))
                if local:
                    parameter_scores.append(sum(local) / len(local))
                positive_values.append(max(q_values[index] for index in candidates))
            if float(item.get("safety_penalty", 0.0)) > 0.18 or float(item.get("reward", 0.0)) < -0.30:
                alternatives = [q_values[index] for index in candidates if index != action]
                margin = (max(alternatives) if alternatives else 0.0) - q_values[action]
                safety_scores.append(clamp(0.5 + margin * 0.5, 0.0, 1.0))
                negative_values.append(q_values[action])
        action_score = sum(action_scores) / len(action_scores) if action_scores else 0.5
        parameter_score = sum(parameter_scores) / len(parameter_scores) if parameter_scores else 0.5
        safety_score = sum(safety_scores) / len(safety_scores) if safety_scores else 0.5
        if positive_values and negative_values:
            preference_score = clamp(0.5 + (sum(positive_values) / len(positive_values) - sum(negative_values) / len(negative_values)) * 0.15, 0.0, 1.0)
        else:
            preference_score = 0.5
        score = td_score * 0.28 + action_score * 0.26 + parameter_score * 0.16 + safety_score * 0.20 + preference_score * 0.10
        return {"score": score, "td": td_score, "action": action_score, "parameter": parameter_score, "safety": safety_score, "preference": preference_score}

    def snapshot(self):
        return {
            "input_count": self.input_count, "layer_sizes": list(self.layer_sizes), "layer_modes": list(self.layer_modes),
            "layers": [[array("f", row) for row in rows] for rows in self.layers],
            "biases": [array("f", values) for values in self.biases],
            "wq": [array("f", row) for row in self.wq], "bq": array("f", self.bq),
            "wp": [[array("f", row) for row in heads] for heads in self.wp],
            "bp": [array("f", values) for values in self.bp],
            "capacities": dict(self.capacities), "stats": self.stats_payload(),
        }

    def restore(self, snapshot):
        self.input_count = int(snapshot.get("input_count", self.input_count))
        self.layer_sizes = [int(value) for value in snapshot["layer_sizes"]]
        self.layer_modes = list(snapshot.get("layer_modes", ["tanh"] * len(self.layer_sizes)))
        self.layers = [[array("f", row) for row in rows] for rows in snapshot["layers"]]
        self.biases = [array("f", values) for values in snapshot["biases"]]
        self.wq = [array("f", row) for row in snapshot["wq"]]
        self.bq = array("f", snapshot["bq"])
        self.wp = [[array("f", row) for row in heads] for heads in snapshot["wp"]]
        self.bp = [array("f", values) for values in snapshot["bp"]]
        restored_capacities = dict(self.capacities)
        restored_capacities.update(dict(snapshot.get("capacities", {})))
        restored_capacities["adaptive_input"] = max(0, int(restored_capacities.get("adaptive_input", 0)))
        self.capacities = restored_capacities
        self.load_stats(snapshot.get("stats", {}))
        # 回滚只恢复参数，不虚增“目标网络同步次数”。
        self.sync_target(count_stat=False)

    def grow_width(self, layer_index=None, amount=2, sync=True):
        if layer_index is None:
            layer_index = min(range(len(self.layer_sizes)), key=lambda index: self.layer_sizes[index])
        layer_index = int(clamp(int(layer_index), 0, len(self.layer_sizes) - 1))
        amount = max(1, int(amount))
        source = random.Random(secrets.randbits(256))
        previous_size = self.input_count if layer_index == 0 else self.layer_sizes[layer_index - 1]
        scale = math.sqrt(2.0 / max(1, previous_size))
        for _ in range(amount):
            self.layers[layer_index].append(array("f", (source.uniform(-scale, scale) for _ in range(previous_size))))
            self.biases[layer_index].append(source.uniform(-0.01, 0.01))
            if layer_index + 1 < len(self.layers):
                for row in self.layers[layer_index + 1]:
                    row.append(0.0)
            else:
                for row in self.wq:
                    row.append(0.0)
                for heads in self.wp:
                    for row in heads:
                        row.append(0.0)
            self.layer_sizes[layer_index] += 1
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()

    def grow_depth(self, size=None, sync=True):
        # 功能保持式加深：在线性 identity 层中插入精确单位映射，输出头完全保留。
        # 对 tanh 网络而言直接插入 tanh(Ix) 也会改变函数，因此这里显式支持 identity 隐层。
        previous = self.layer_sizes[-1]
        size = previous if size is None else int(size)
        if size < previous:
            raise ValueError("功能保持式加深不能把新层缩到上一层以下")
        rows = []
        for row_index in range(size):
            row = array("f", [0.0] * previous)
            if row_index < previous:
                row[row_index] = 1.0
            rows.append(row)
        self.layers.append(rows)
        self.biases.append(array("f", [0.0] * size))
        self.layer_sizes.append(size)
        self.layer_modes.append("identity")
        # 新增的零通道不改变原输出；输出头宽度随 size 真正扩展。
        extra = size - previous
        if extra:
            for row in self.wq:
                row.extend([0.0] * extra)
            for heads in self.wp:
                for row in heads:
                    row.extend([0.0] * extra)
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()
        return size

    def grow_input(self, amount=128, sync=True):
        amount = max(1, int(amount))
        for row in self.layers[0]:
            row.extend([0.0] * amount)
        self.input_count += amount
        self.capacities["adaptive_input"] = max(int(self.capacities.get("adaptive_input", 0)), self.input_count - BASE_FEATURE_COUNT)
        self._invalidate_accelerator(target=False)
        if sync:
            self.sync_target()
        return self.input_count

    def grow_capabilities(self, memory_count, skill_count, bottleneck="none", resource_budget=None):
        """按瓶颈和实时资源扩容；任何字段都没有代码写死的最终容量。"""
        changed = []
        bottleneck = str(bottleneck or "none")

        def grow(name, kind="decision"):
            current = max(0, int(self.capacities.get(name, 0)))
            if resource_budget is not None:
                amount = resource_budget.growth_amount(name, current, kind=kind)
            else:
                amount = max(1, int(math.sqrt(max(1, current)) * 0.18))
            if amount <= 0:
                return 0
            self.capacities[name] = current + int(amount)
            return int(amount)

        if bottleneck == "perception":
            amounts = (grow("uia_nodes", "perception"), grow("uia_depth", "perception"), grow("attention_candidates", "perception"))
            roi_growth = grow("visual_roi_scale", "perception")
            if any(amounts) or roi_growth:
                changed.append("感知容量+{}/{}/{}（节点/深度/候选），ROI 金字塔+{}".format(*amounts, roi_growth))
            elif resource_budget is not None:
                # 扫描已经超过延迟预算时增加复用窗口，而不是继续堆 UIA 节点。
                gain = resource_budget.growth_amount("memory_horizon", self.capacities.get("observation_cache_ms", 120), "decision")
                self.capacities["observation_cache_ms"] = int(self.capacities.get("observation_cache_ms", 120)) + max(1, gain)
                changed.append("感知缓存窗口按延迟预算扩大")
        elif bottleneck == "knowledge":
            amount = grow("memory_horizon")
            if amount: changed.append("知识检索窗口+{}".format(amount))
        elif bottleneck == "skill":
            attention = grow("skill_attention"); horizon = grow("memory_horizon")
            if attention or horizon: changed.append("技能注意/组合窗口+{}/{}".format(attention, horizon))
        elif bottleneck == "planning":
            breadth = grow("planner_breadth"); horizon = grow("memory_horizon")
            if breadth or horizon: changed.append("策略宽度/规划记忆窗+{}/{}".format(breadth, horizon))
        elif bottleneck == "model_capacity":
            # 这里只开放“模型相关能力”的许可；真正增宽/加深仍需 validation、shadow-test 与延迟预算验证。
            self.capacities["adaptive_input"] = max(int(self.capacities.get("adaptive_input", 0)), self.input_count - BASE_FEATURE_COUNT)
            cache_growth = grow("forward_cache_entries")
            if resource_budget is not None:
                target_cache = resource_budget.forward_cache_entries(self.input_count, self.hidden_count)
                self.capacities["forward_cache_entries"] = max(self.capacities["forward_cache_entries"], target_cache)
            changed.append("模型容量扩张许可；推理缓存+{}".format(cache_growth))
        return changed

    def stats_payload(self):
        return {
            "sleep_count": self.sleep_count, "training_steps": self.training_steps,
            "target_syncs": self.target_syncs, "accepted_growth": self.accepted_growth,
            "rejected_growth": self.rejected_growth, "reward_average": self.reward_average,
            "loss_average": self.loss_average, "progress_average": self.progress_average,
            "safety_average": self.safety_average,
        }

    def load_stats(self, stats):
        for name in ("sleep_count", "training_steps", "target_syncs", "accepted_growth", "rejected_growth"):
            setattr(self, name, int(stats.get(name, getattr(self, name))))
        for name in ("reward_average", "loss_average", "progress_average", "safety_average"):
            setattr(self, name, safe_float(stats.get(name, getattr(self, name))))

    def to_bytes(self):
        metadata = compact_json({
            "format": FORMAT_VERSION, "input_count": self.input_count, "layer_sizes": self.layer_sizes, "layer_modes": self.layer_modes,
            "action_count": self.action_count, "param_head_sizes": self.param_head_sizes,
            "capacities": self.capacities, "stats": self.stats_payload(),
        }).encode("utf-8")
        floats = array("f")
        for rows, biases in zip(self.layers, self.biases):
            for row in rows:
                floats.extend(row)
            floats.extend(biases)
        for row in self.wq:
            floats.extend(row)
        floats.extend(self.bq)
        for heads, biases in zip(self.wp, self.bp):
            for row in heads:
                floats.extend(row)
            floats.extend(biases)
        if sys.byteorder != "little":
            floats.byteswap()
        body = struct.pack("<I", len(metadata)) + metadata + floats.tobytes()
        return MODEL_MAGIC + hashlib.sha256(body).digest() + body

    @classmethod
    def from_bytes(cls, data):
        if not data.startswith(MODEL_MAGIC) or len(data) < len(MODEL_MAGIC) + 36:
            raise ValueError("模型文件头无效")
        start = len(MODEL_MAGIC)
        checksum = data[start:start + 32]
        body = data[start + 32:]
        if hashlib.sha256(body).digest() != checksum:
            raise ValueError("模型校验失败")
        metadata_size = struct.unpack("<I", body[:4])[0]
        if metadata_size < 2 or metadata_size > len(body) - 4:
            raise ValueError("模型元数据长度无效")
        metadata = json.loads(body[4:4 + metadata_size].decode("utf-8"))
        if int(metadata.get("format", -1)) != FORMAT_VERSION:
            raise ValueError("模型版本不兼容")
        input_count = int(metadata.get("input_count", -1))
        if input_count < BASE_FEATURE_COUNT or int(metadata.get("action_count", -1)) != ACTION_COUNT:
            raise ValueError("模型结构不兼容")
        if list(metadata.get("param_head_sizes", [])) != list(PARAM_HEAD_SIZES):
            raise ValueError("动作参数头结构不兼容")
        layer_sizes = [int(value) for value in metadata.get("layer_sizes", [])]
        if not layer_sizes or any(value < 1 for value in layer_sizes):
            raise ValueError("模型层结构无效")
        values = array("f")
        values.frombytes(body[4 + metadata_size:])
        if sys.byteorder != "little":
            values.byteswap()
        layer_modes = list(metadata.get("layer_modes", ["tanh"] * len(layer_sizes)))
        if len(layer_modes) != len(layer_sizes) or any(mode not in ("tanh", "identity") for mode in layer_modes):
            raise ValueError("模型激活层结构无效")
        expected = 0
        previous = input_count
        for size in layer_sizes:
            expected += size * previous + size
            previous = size
        expected += ACTION_COUNT * previous + ACTION_COUNT
        expected += sum(count * previous + count for count in PARAM_HEAD_SIZES)
        if len(values) != expected or not all(math.isfinite(float(value)) for value in values):
            raise ValueError("模型权重损坏")
        # 先用文件实际权重数量验证结构，再分配网络，避免损坏元数据触发超大内存分配。
        model = cls(input_count, layer_sizes, metadata.get("capacities", {}))
        model.layer_modes = layer_modes
        offset = 0
        model.layers = []
        model.biases = []
        previous = input_count
        for size in layer_sizes:
            rows = []
            for _ in range(size):
                rows.append(array("f", values[offset:offset + previous])); offset += previous
            model.layers.append(rows)
            model.biases.append(array("f", values[offset:offset + size])); offset += size
            previous = size
        model.wq = []
        for _ in range(ACTION_COUNT):
            model.wq.append(array("f", values[offset:offset + previous])); offset += previous
        model.bq = array("f", values[offset:offset + ACTION_COUNT]); offset += ACTION_COUNT
        model.wp = []
        model.bp = []
        for count in PARAM_HEAD_SIZES:
            heads = []
            for _ in range(count):
                heads.append(array("f", values[offset:offset + previous])); offset += previous
            model.wp.append(heads)
            model.bp.append(array("f", values[offset:offset + count])); offset += count
        model.load_stats(metadata.get("stats", {}))
        # 从磁盘恢复目标参数不属于一次训练同步。
        model.sync_target(count_stat=False)
        return model

    def save(self, path):
        atomic_write(path, self.to_bytes())

    @classmethod
    def load(cls, path):
        with open(path, "rb") as stream:
            return cls.from_bytes(stream.read())


class LongTermMemory:

    def __init__(self, path, resource_budget=None):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.resource_budget = resource_budget or ResourceBudget(path.parent)
        self.lock = threading.RLock()
        self.connection = sqlite3.connect(str(path), timeout=20.0, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        with self.lock:
            self.connection.execute("PRAGMA journal_mode=WAL")
            self.connection.execute("PRAGMA synchronous=NORMAL")
            self.connection.execute("PRAGMA temp_store=MEMORY")
            self.connection.execute("PRAGMA busy_timeout=3000")
            cache_kib = max(8192, min(262144, int(self.resource_budget.hot_memory_bytes // (8 * 1024))))
            self.connection.execute("PRAGMA cache_size=-{}".format(cache_kib))
            self.connection.execute("PRAGMA foreign_keys=ON")
            self._migrate_schema()
            self.connection.commit()
        self.recent = deque()
        self.recent_limit = int(self.resource_budget.memory_limits().get("recent_working_set", 128))
        self.storage_paused = False
        self.storage_pause_reason = ""
        self._storage_checked_at = 0.0

    def _write_allowed(self, essential=False):
        # 不设置“最多多少条”知识。低于资源安全线时暂停可增长经验写入，并先清理可再生成缓存。
        now = time.monotonic()
        if now - self._storage_checked_at >= (0.20 if self.storage_paused else 1.0):
            self.resource_budget.refresh()
            self._storage_checked_at = now
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + 512 * 1024 ** 2:
            self.resource_budget.cleanup_regenerable_storage()
            self.resource_budget.refresh()
        allowed = essential or self.resource_budget.free_disk > self.resource_budget.disk_reserve_bytes + 64 * 1024 ** 2
        self.storage_paused = not allowed
        self.storage_pause_reason = "磁盘已接近安全线，经验写入暂停" if not allowed else ""
        return allowed

    def _column_names(self, table):
        return {str(row[1]) for row in self.connection.execute("PRAGMA table_info(" + table + ")").fetchall()}

    def _migrate_0_to_1(self):
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS episodic_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                created_at REAL NOT NULL,
                last_seen REAL NOT NULL,
                state BLOB NOT NULL,
                action_kind INTEGER NOT NULL,
                action_json TEXT NOT NULL,
                parameter_blob BLOB NOT NULL,
                reward REAL NOT NULL,
                goal_reward REAL NOT NULL,
                curiosity_reward REAL NOT NULL,
                efficiency_reward REAL NOT NULL,
                safety_penalty REAL NOT NULL,
                next_state BLOB NOT NULL,
                next_mask INTEGER NOT NULL,
                priority REAL NOT NULL,
                state_signature TEXT NOT NULL,
                next_signature TEXT NOT NULL,
                n_steps INTEGER NOT NULL,
                sample_count INTEGER NOT NULL DEFAULT 1,
                goal_text TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_episode_priority ON episodic_memory(priority DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_recent ON episodic_memory(last_seen DESC);
            CREATE INDEX IF NOT EXISTS idx_episode_signature ON episodic_memory(state_signature);
            CREATE TABLE IF NOT EXISTS state_memory (
                signature TEXT PRIMARY KEY,
                visual_signature TEXT NOT NULL,
                representative BLOB NOT NULL,
                visits INTEGER NOT NULL,
                successes INTEGER NOT NULL,
                failures INTEGER NOT NULL,
                value REAL NOT NULL,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_state_value ON state_memory(value DESC);
            CREATE TABLE IF NOT EXISTS skill_memory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fingerprint TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                level INTEGER NOT NULL,
                steps_json TEXT NOT NULL,
                precondition_json TEXT NOT NULL,
                expected_json TEXT NOT NULL,
                uses INTEGER NOT NULL DEFAULT 0,
                successes INTEGER NOT NULL DEFAULT 0,
                average_seconds REAL NOT NULL DEFAULT 0,
                score REAL NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_skill_score ON skill_memory(score DESC, successes DESC);
            CREATE TABLE IF NOT EXISTS failure_memory (
                fingerprint TEXT PRIMARY KEY,
                action_json TEXT NOT NULL,
                state_signature TEXT NOT NULL,
                reason TEXT NOT NULL,
                occurrences INTEGER NOT NULL,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_failure_recent ON failure_memory(last_seen DESC);
            CREATE TABLE IF NOT EXISTS text_memory (
                text TEXT PRIMARY KEY,
                uses INTEGER NOT NULL,
                successes INTEGER NOT NULL,
                score REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        self.connection.execute("PRAGMA user_version=1")

    def _migrate_1_to_2(self):
        columns = self._column_names("failure_memory")
        if "action_kind" not in columns:
            self.connection.execute("ALTER TABLE failure_memory ADD COLUMN action_kind INTEGER NOT NULL DEFAULT -1")
        if "risk" not in columns:
            self.connection.execute("ALTER TABLE failure_memory ADD COLUMN risk REAL NOT NULL DEFAULT 0")
        rows = self.connection.execute("SELECT fingerprint,action_json FROM failure_memory WHERE action_kind<0").fetchall()
        for row in rows:
            try:
                kind = int(json.loads(row["action_json"]).get("kind", -1))
            except Exception:
                kind = -1
            self.connection.execute("UPDATE failure_memory SET action_kind=? WHERE fingerprint=?", (kind, row["fingerprint"]))
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_failure_state_action ON failure_memory(state_signature,action_kind)")
        self.connection.execute("PRAGMA user_version=2")

    def _migrate_2_to_3(self):
        columns = self._column_names("episodic_memory")
        if "current_mask" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN current_mask INTEGER NOT NULL DEFAULT 0")
        # 旧记录没有当前状态动作掩码，只能做保守迁移：至少包含实际动作；next_mask 仅用于补充历史兼容。
        self.connection.execute("UPDATE episodic_memory SET current_mask=(current_mask | next_mask | (1 << action_kind)) WHERE current_mask=0")
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_state_action ON episodic_memory(state_signature,action_kind,priority DESC)")
        self.connection.execute("PRAGMA user_version=3")

    def _migrate_3_to_4(self):
        columns = self._column_names("episodic_memory")
        if "state_key" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN state_key TEXT NOT NULL DEFAULT ''")
        if "next_state_key" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN next_state_key TEXT NOT NULL DEFAULT ''")
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_state_key_action ON episodic_memory(state_key,action_kind,priority DESC)")
        self.connection.execute("PRAGMA user_version=4")

    def _migrate_4_to_5(self):
        columns = self._column_names("episodic_memory")
        if "partition" not in columns:
            self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN partition TEXT NOT NULL DEFAULT 'train'")
        rows = self.connection.execute("SELECT id,fingerprint FROM episodic_memory").fetchall()
        for row in rows:
            fingerprint = str(row["fingerprint"] or "")
            try:
                partition = "eval" if int(fingerprint[:4], 16) % 5 == 0 else "train"
            except ValueError:
                partition = "train"
            self.connection.execute("UPDATE episodic_memory SET partition=? WHERE id=?", (partition, int(row["id"])))
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_partition_priority ON episodic_memory(partition,priority DESC)")
        self.connection.execute("PRAGMA user_version=5")

    def _migrate_5_to_6(self):
        columns = self._column_names("episodic_memory")
        additions = {
            "importance": "REAL NOT NULL DEFAULT 0.5",
            "novelty": "REAL NOT NULL DEFAULT 0.5",
            "reuse_count": "INTEGER NOT NULL DEFAULT 0",
            "last_used": "REAL NOT NULL DEFAULT 0",
            "confidence": "REAL NOT NULL DEFAULT 0.35",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self.connection.execute("ALTER TABLE episodic_memory ADD COLUMN {} {}".format(name, declaration))
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS world_transition (
                fingerprint TEXT PRIMARY KEY,
                action_kind INTEGER NOT NULL,
                state_key TEXT NOT NULL,
                state BLOB NOT NULL,
                next_state BLOB NOT NULL,
                next_signature TEXT NOT NULL DEFAULT '',
                next_state_key TEXT NOT NULL DEFAULT '',
                next_mask INTEGER NOT NULL DEFAULT 0,
                mean_reward REAL NOT NULL DEFAULT 0,
                mean_safety REAL NOT NULL DEFAULT 0,
                prediction_error REAL NOT NULL DEFAULT 0,
                confidence REAL NOT NULL DEFAULT 0.25,
                observations INTEGER NOT NULL DEFAULT 1,
                created_at REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_world_action ON world_transition(action_kind,last_seen DESC);
            CREATE TABLE IF NOT EXISTS semantic_knowledge (
                fingerprint TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                key_text TEXT NOT NULL,
                value_json TEXT NOT NULL,
                confidence REAL NOT NULL DEFAULT 0.35,
                observations INTEGER NOT NULL DEFAULT 1,
                reuse_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                last_used REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_knowledge_kind ON semantic_knowledge(kind,confidence DESC,last_seen DESC);
            CREATE TABLE IF NOT EXISTS sleep_report (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at REAL NOT NULL,
                reason TEXT NOT NULL,
                findings_json TEXT NOT NULL,
                improvements_json TEXT NOT NULL,
                regressions_json TEXT NOT NULL,
                repeated_errors_json TEXT NOT NULL,
                bottleneck TEXT NOT NULL,
                structural_growth_json TEXT NOT NULL,
                before_metrics_json TEXT NOT NULL,
                after_metrics_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_sleep_report_recent ON sleep_report(created_at DESC);
        """)
        self.connection.execute("PRAGMA user_version=6")

    def _migrate_6_to_7(self):
        columns = self._column_names("skill_memory")
        additions = {
            "parameters_json": "TEXT NOT NULL DEFAULT '{}'",
            "success_json": "TEXT NOT NULL DEFAULT '{}'",
            "recovery_json": "TEXT NOT NULL DEFAULT '[]'",
            "program_version": "INTEGER NOT NULL DEFAULT 1",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self.connection.execute("ALTER TABLE skill_memory ADD COLUMN {} {}".format(name, declaration))
        self.connection.execute("PRAGMA user_version=7")

    def _migrate_7_to_8(self):
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS strategy_memory (
                fingerprint TEXT PRIMARY KEY,
                operation TEXT NOT NULL,
                app_key TEXT NOT NULL,
                precondition_json TEXT NOT NULL,
                recovery_json TEXT NOT NULL,
                subgoals_json TEXT NOT NULL,
                successes INTEGER NOT NULL DEFAULT 1,
                failures INTEGER NOT NULL DEFAULT 0,
                confidence REAL NOT NULL DEFAULT 0.35,
                reuse_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                last_used REAL NOT NULL,
                last_seen REAL NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_strategy_lookup ON strategy_memory(operation,app_key,confidence DESC,last_seen DESC);
        """)
        self.connection.execute("PRAGMA user_version=8")

    def _migrate_8_to_9(self):
        columns = self._column_names("skill_memory")
        if "capabilities_json" not in columns:
            self.connection.execute("ALTER TABLE skill_memory ADD COLUMN capabilities_json TEXT NOT NULL DEFAULT '[]'")
        self.connection.executescript("""
            CREATE TABLE IF NOT EXISTS memory_compressed (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_table TEXT NOT NULL,
                source_key TEXT NOT NULL,
                search_text TEXT NOT NULL DEFAULT '',
                payload BLOB NOT NULL,
                codec TEXT NOT NULL,
                importance REAL NOT NULL DEFAULT 0,
                original_created REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL DEFAULT 0,
                moved_at REAL NOT NULL,
                UNIQUE(source_table,source_key)
            );
            CREATE INDEX IF NOT EXISTS idx_compressed_lookup ON memory_compressed(source_table,importance DESC,last_seen DESC);
            CREATE INDEX IF NOT EXISTS idx_compressed_moved ON memory_compressed(moved_at ASC);
            CREATE TABLE IF NOT EXISTS memory_archive (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_table TEXT NOT NULL,
                source_key TEXT NOT NULL,
                search_text TEXT NOT NULL DEFAULT '',
                payload BLOB NOT NULL,
                codec TEXT NOT NULL,
                importance REAL NOT NULL DEFAULT 0,
                original_created REAL NOT NULL DEFAULT 0,
                last_seen REAL NOT NULL DEFAULT 0,
                archived_at REAL NOT NULL,
                access_count INTEGER NOT NULL DEFAULT 0,
                last_accessed REAL NOT NULL DEFAULT 0,
                UNIQUE(source_table,source_key)
            );
            CREATE INDEX IF NOT EXISTS idx_archive_lookup ON memory_archive(source_table,importance DESC,last_seen DESC);
            CREATE TABLE IF NOT EXISTS session_capability (
                session_id TEXT NOT NULL,
                process_id INTEGER NOT NULL DEFAULT 0,
                process_name TEXT NOT NULL DEFAULT '',
                window_hwnd INTEGER NOT NULL DEFAULT 0,
                parent_process_id INTEGER NOT NULL DEFAULT 0,
                owner_hwnd INTEGER NOT NULL DEFAULT 0,
                relation TEXT NOT NULL,
                scope TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT '',
                approved INTEGER NOT NULL DEFAULT 0,
                first_seen REAL NOT NULL,
                last_seen REAL NOT NULL,
                PRIMARY KEY(session_id,process_id,window_hwnd)
            );
            CREATE INDEX IF NOT EXISTS idx_session_capability_recent ON session_capability(session_id,last_seen DESC);
        """)
        self.connection.execute("PRAGMA user_version=9")

    @staticmethod
    def _experience_partition(fingerprint):
        """稳定切分 train/validation/shadow；shadow 永不参与训练或结构选择。"""
        try:
            bucket = int(str(fingerprint)[:8], 16) % 10
        except (TypeError, ValueError):
            bucket = 9
        if bucket == 0:
            return "shadow"
        if bucket in (1, 2):
            return "validation"
        return "train"

    def _migrate_9_to_10(self):
        rows = self.connection.execute("SELECT id,fingerprint FROM episodic_memory").fetchall()
        for row in rows:
            partition = self._experience_partition(row["fingerprint"])
            self.connection.execute("UPDATE episodic_memory SET partition=? WHERE id=?", (partition, int(row["id"])))
        self.connection.execute("CREATE INDEX IF NOT EXISTS idx_episode_partition_priority ON episodic_memory(partition,priority DESC)")
        self.connection.execute("PRAGMA user_version=10")

    def _migrate_schema(self):
        version = int(self.connection.execute("PRAGMA user_version").fetchone()[0])
        if version < 1:
            self._migrate_0_to_1()
            version = 1
        if version < 2:
            self._migrate_1_to_2()
            version = 2
        if version < 3:
            self._migrate_2_to_3()
            version = 3
        if version < 4:
            self._migrate_3_to_4()
            version = 4
        if version < 5:
            self._migrate_4_to_5()
            version = 5
        if version < 6:
            self._migrate_5_to_6()
            version = 6
        if version < 7:
            self._migrate_6_to_7()
            version = 7
        if version < 8:
            self._migrate_7_to_8()
            version = 8
        if version < 9:
            self._migrate_8_to_9()
            version = 9
        if version < 10:
            self._migrate_9_to_10()
            version = 10
        if version != SCHEMA_VERSION:
            raise RuntimeError("SQLite schema 版本不兼容：{} != {}".format(version, SCHEMA_VERSION))

    def rollback(self):
        with self.lock:
            try:
                self.connection.rollback()
            except Exception:
                pass

    def close(self, commit=True):
        with self.lock:
            try:
                if commit:
                    self.connection.commit()
                else:
                    self.connection.rollback()
                self.connection.close()
            except Exception:
                pass

    def commit(self):
        with self.lock:
            self.connection.commit()

    def set_metadata(self, key, value, commit=True):
        with self.lock:
            self.connection.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (str(key), str(value)))
            if commit:
                self.connection.commit()

    def get_metadata(self, key, default=""):
        with self.lock:
            row = self.connection.execute("SELECT value FROM metadata WHERE key=?", (str(key),)).fetchone()
            return default if row is None else str(row[0])

    def delete_metadata(self, key, commit=True):
        with self.lock:
            self.connection.execute("DELETE FROM metadata WHERE key=?", (str(key),))
            if commit:
                self.connection.commit()

    def count(self, table):
        if table not in (
            "episodic_memory", "state_memory", "skill_memory", "failure_memory", "semantic_knowledge",
            "world_transition", "sleep_report", "strategy_memory", "text_memory", "memory_compressed",
            "memory_archive", "session_capability",
        ):
            return 0
        with self.lock:
            return int(self.connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0])

    @staticmethod
    def _json_safe(value):
        if isinstance(value, (bytes, bytearray, memoryview)):
            return {"__local_ai_bytes__": base64.b64encode(bytes(value)).decode("ascii")}
        if isinstance(value, dict):
            return {str(key): LongTermMemory._json_safe(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [LongTermMemory._json_safe(item) for item in value]
        return value

    @staticmethod
    def _json_restore(value):
        if isinstance(value, dict) and set(value.keys()) == {"__local_ai_bytes__"}:
            return base64.b64decode(str(value["__local_ai_bytes__"]).encode("ascii"))
        if isinstance(value, dict):
            return {str(key): LongTermMemory._json_restore(item) for key, item in value.items()}
        if isinstance(value, list):
            return [LongTermMemory._json_restore(item) for item in value]
        return value

    @classmethod
    def _encode_tier_row(cls, row):
        source = {str(key): row[key] for key in row.keys() if str(key) != "_tier_rowid"}
        raw = compact_json(cls._json_safe(source)).encode("utf-8")
        return zlib.compress(raw, 9)

    @classmethod
    def _decode_tier_payload(cls, payload, codec):
        if str(codec) != "zlib-json-v1":
            raise ValueError("未知归档编码")
        return cls._json_restore(json.loads(zlib.decompress(bytes(payload)).decode("utf-8")))

    @staticmethod
    def _row_search_text(row):
        values = []
        for key in row.keys():
            if str(key) in ("state", "next_state", "representative", "parameter_blob", "_tier_rowid"):
                continue
            value = row[key]
            if isinstance(value, str) and value:
                values.append(value)
        return " ".join(dict.fromkeys(semantic_units(" ".join(values))))

    @staticmethod
    def _source_key(table, row):
        fields = {
            "episodic_memory": ("fingerprint",), "state_memory": ("signature",),
            "skill_memory": ("id",), "failure_memory": ("fingerprint",),
            "text_memory": ("text",), "semantic_knowledge": ("fingerprint",),
            "world_transition": ("fingerprint",), "sleep_report": ("id",),
            "strategy_memory": ("fingerprint",),
        }.get(str(table), ("rowid",))
        return "|".join(str(row[field]) for field in fields if field in row.keys())

    @staticmethod
    def _first_number(row, names, default=0.0):
        for name in names:
            if name in row.keys():
                return safe_float(row[name], default)
        return float(default)

    def _tier_rows(self, source_table, query="", limit=32):
        result = []
        token = next(iter(semantic_units(query)), "")
        for tier in ("memory_compressed", "memory_archive"):
            sql = "SELECT * FROM {} WHERE source_table=?".format(tier)
            parameters = [str(source_table)]
            if token:
                sql += " AND search_text LIKE ?"
                parameters.append("%" + token + "%")
            sql += " ORDER BY importance DESC,last_seen DESC LIMIT ?"
            parameters.append(max(1, int(limit)))
            rows = self.connection.execute(sql, tuple(parameters)).fetchall()
            for row in rows:
                try:
                    decoded = self._decode_tier_payload(row["payload"], row["codec"])
                except Exception:
                    continue
                result.append(decoded)
            if len(result) >= int(limit):
                break
        return result[:max(1, int(limit))]

    def _tier_row(self, source_table, source_key):
        for tier in ("memory_compressed", "memory_archive"):
            row = self.connection.execute(
                "SELECT * FROM {} WHERE source_table=? AND source_key=?".format(tier),
                (str(source_table), str(source_key)),
            ).fetchone()
            if row:
                try:
                    decoded = self._decode_tier_payload(row["payload"], row["codec"])
                    if tier == "memory_archive":
                        self.connection.execute(
                            "UPDATE memory_archive SET access_count=access_count+1,last_accessed=? WHERE id=?",
                            (time.time(), int(row["id"])),
                        )
                    return decoded
                except Exception:
                    return None
        return None

    def tier_counts(self):
        with self.lock:
            compressed = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
            archived = int(self.connection.execute("SELECT COUNT(*) FROM memory_archive").fetchone()[0])
        return {"compressed": compressed, "archived": archived}

    def pending_experience_count(self):
        with self.lock:
            row = self.connection.execute("SELECT COALESCE(MAX(created_at),0) FROM sleep_report").fetchone()
            since = float(row[0] or 0.0)
            count = self.connection.execute("SELECT COUNT(*) FROM episodic_memory WHERE last_seen>?", (since,)).fetchone()
        return int(count[0])

    def fragmentation_score(self):
        with self.lock:
            pages = int(self.connection.execute("PRAGMA page_count").fetchone()[0])
            free = int(self.connection.execute("PRAGMA freelist_count").fetchone()[0])
            compressed = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
        limits = self.resource_budget.memory_limits()
        free_ratio = free / max(1, pages)
        tier_pressure = compressed / max(1, int(limits.get("memory_compressed", compressed + 1)))
        return clamp(free_ratio * 0.55 + tier_pressure * 0.45, 0.0, 1.0)

    def remember_session_capability(self, item):
        if not self._write_allowed():
            return False
        item = dict(item or {})
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO session_capability(session_id,process_id,process_name,window_hwnd,parent_process_id,owner_hwnd,relation,scope,reason,approved,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(session_id,process_id,window_hwnd) DO UPDATE SET
                    process_name=excluded.process_name,parent_process_id=excluded.parent_process_id,owner_hwnd=excluded.owner_hwnd,
                    relation=excluded.relation,scope=excluded.scope,reason=excluded.reason,
                    approved=max(session_capability.approved,excluded.approved),last_seen=excluded.last_seen
            """, (
                str(item.get("session_id", "")), int(item.get("process_id", 0)), str(item.get("process_name", "")),
                int(item.get("window_hwnd", 0)), int(item.get("parent_process_id", 0)), int(item.get("owner_hwnd", 0)),
                str(item.get("relation", "unknown")), str(item.get("scope", "default")), str(item.get("reason", "")),
                int(bool(item.get("approved"))), now, now,
            ))

    def state_visits(self, signature):
        with self.lock:
            row = self.connection.execute("SELECT visits FROM state_memory WHERE signature=?", (signature,)).fetchone()
        return int(row[0]) if row else 0

    def remember_state(self, signature, visual_signature, state, reward=0.0, success=False, failure=False):
        if not self._write_allowed():
            return False
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO state_memory(signature,visual_signature,representative,visits,successes,failures,value,first_seen,last_seen)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(signature) DO UPDATE SET
                    visual_signature=excluded.visual_signature,
                    representative=CASE WHEN abs(excluded.value)>=abs(state_memory.value) THEN excluded.representative ELSE state_memory.representative END,
                    visits=state_memory.visits+1,
                    successes=state_memory.successes+excluded.successes,
                    failures=state_memory.failures+excluded.failures,
                    value=state_memory.value*0.97+excluded.value*0.03,
                    last_seen=excluded.last_seen
            """, (signature, visual_signature, pack_state(state), 1, int(bool(success)), int(bool(failure)), float(reward), now, now))

    def add_experience(self, item):
        if not self._write_allowed():
            return False
        action_json = compact_json(item.get("command", {"kind": item["action"], "parameters": {}}))
        parameter_blob = pack_parameters(item.get("parameters", [0.5] * PARAM_COUNT), item.get("parameter_mask", 0))
        fingerprint_source = "|".join((
            str(item.get("signature", "")), str(item["action"]), action_json,
            str(item.get("next_signature", "")), str(item.get("n_steps", 1)), str(item.get("goal_text", "")),
        ))
        fingerprint = hashlib.blake2s(fingerprint_source.encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        partition = self._experience_partition(fingerprint)
        values = (
            fingerprint, now, now, pack_state(item["state"]), int(item["action"]), action_json, parameter_blob,
            float(item["reward"]), float(item.get("goal_reward", 0.0)), float(item.get("curiosity_reward", 0.0)),
            float(item.get("efficiency_reward", 0.0)), float(item.get("safety_penalty", 0.0)), pack_state(item["next_state"]),
            int(item.get("current_mask", 1 << int(item["action"]))), int(item.get("next_mask", 0)), float(item.get("priority", 0.01)), str(item.get("signature", "")),
            str(item.get("next_signature", "")), int(item.get("n_steps", 1)), str(item.get("goal_text", "")),
            str(item.get("state_key", "")), str(item.get("next_state_key", "")), partition,
        )
        with self.lock:
            self.connection.execute("""
                INSERT INTO episodic_memory(
                    fingerprint,created_at,last_seen,state,action_kind,action_json,parameter_blob,reward,goal_reward,
                    curiosity_reward,efficiency_reward,safety_penalty,next_state,current_mask,next_mask,priority,state_signature,
                    next_signature,n_steps,goal_text,state_key,next_state_key,partition)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    last_seen=excluded.last_seen,
                    reward=(episodic_memory.reward*episodic_memory.sample_count+excluded.reward)/(episodic_memory.sample_count+1),
                    goal_reward=(episodic_memory.goal_reward*episodic_memory.sample_count+excluded.goal_reward)/(episodic_memory.sample_count+1),
                    curiosity_reward=(episodic_memory.curiosity_reward*episodic_memory.sample_count+excluded.curiosity_reward)/(episodic_memory.sample_count+1),
                    efficiency_reward=(episodic_memory.efficiency_reward*episodic_memory.sample_count+excluded.efficiency_reward)/(episodic_memory.sample_count+1),
                    safety_penalty=max(episodic_memory.safety_penalty,excluded.safety_penalty),
                    priority=max(episodic_memory.priority*0.995,excluded.priority),
                    state=CASE WHEN excluded.priority>=episodic_memory.priority THEN excluded.state ELSE episodic_memory.state END,
                    next_state=CASE WHEN excluded.priority>=episodic_memory.priority THEN excluded.next_state ELSE episodic_memory.next_state END,
                    current_mask=excluded.current_mask,
                    next_mask=excluded.next_mask,
                    state_key=CASE WHEN excluded.state_key<>'' THEN excluded.state_key ELSE episodic_memory.state_key END,
                    next_state_key=CASE WHEN excluded.next_state_key<>'' THEN excluded.next_state_key ELSE episodic_memory.next_state_key END,
                    partition=episodic_memory.partition,
                    sample_count=episodic_memory.sample_count+1
            """, values)
            # 价值型记忆：重要性/新颖性/复用/置信度共同决定保留，而不是只按时间或数量。
            visits_row = self.connection.execute("SELECT visits FROM state_memory WHERE signature=?", (str(item.get("signature", "")),)).fetchone()
            visits = int(visits_row[0]) if visits_row else 0
            novelty = clamp(1.0 / math.sqrt(1.0 + visits), 0.05, 1.0)
            importance = clamp(
                0.20 + abs(float(item.get("goal_reward", 0.0))) * 0.34
                + abs(float(item.get("reward", 0.0))) * 0.18
                + float(item.get("safety_penalty", 0.0)) * 0.24
                + clamp(float(item.get("priority", 0.01)) / 6.0, 0.0, 0.20),
                0.05, 1.0,
            )
            row = self.connection.execute("SELECT sample_count FROM episodic_memory WHERE fingerprint=?", (fingerprint,)).fetchone()
            samples = int(row[0]) if row else 1
            confidence = clamp(1.0 - math.exp(-samples / 3.5), 0.20, 0.995)
            self.connection.execute(
                "UPDATE episodic_memory SET importance=max(importance,?), novelty=novelty*0.92+?*0.08, confidence=max(confidence,?), last_used=CASE WHEN last_used=0 THEN ? ELSE last_used END WHERE fingerprint=?",
                (importance, novelty, confidence, now, fingerprint),
            )
        cached = dict(item)
        cached["fingerprint"] = fingerprint
        self.recent.append(cached)
        self.recent_limit = int(self.resource_budget.memory_limits().get("recent_working_set", self.recent_limit))
        while len(self.recent) > self.recent_limit:
            self.recent.popleft()

    @staticmethod
    def _decode_experience(row):
        parameters, parameter_mask = unpack_parameters(row["parameter_blob"])
        return {
            "id": int(row["id"]), "fingerprint": str(row["fingerprint"]), "state": unpack_state(row["state"]), "action": int(row["action_kind"]),
            "command": json.loads(row["action_json"]), "parameters": parameters, "parameter_mask": parameter_mask,
            "reward": float(row["reward"]), "goal_reward": float(row["goal_reward"]),
            "curiosity_reward": float(row["curiosity_reward"]), "efficiency_reward": float(row["efficiency_reward"]),
            "safety_penalty": float(row["safety_penalty"]), "next_state": unpack_state(row["next_state"]),
            "current_mask": int(row["current_mask"]), "next_mask": int(row["next_mask"]), "priority": max(0.001, float(row["priority"])),
            "signature": str(row["state_signature"]), "next_signature": str(row["next_signature"]),
            "state_key": str(row["state_key"]) if "state_key" in row.keys() else "",
            "next_state_key": str(row["next_state_key"]) if "next_state_key" in row.keys() else "",
            "n_steps": int(row["n_steps"]), "sample_count": int(row["sample_count"]),
            "partition": str(row["partition"]) if "partition" in row.keys() else "train",
        }

    def sample_batch(self, count, partition="train"):
        count = max(1, int(count))
        requested_partition = str(partition).lower().replace("_", "-")
        partition = {
            "eval": "validation", "validation": "validation",
            "shadow": "shadow", "shadow-test": "shadow",
        }.get(requested_partition, "train")
        if partition == "shadow":
            # 冻结 hold-out：固定 fingerprint 顺序，不做优先级采样，也不更新 reuse/priority。
            with self.lock:
                rows = self.connection.execute(
                    "SELECT * FROM episodic_memory WHERE partition='shadow' ORDER BY fingerprint ASC LIMIT ?",
                    (count,),
                ).fetchall()
            return [self._decode_experience(row) for row in rows]
        # 候选池随请求和资源预算扩展，没有写死的最终采样窗。
        fetch = max(64, count * 6, int(math.sqrt(max(1, self.recent_limit)) * count))
        with self.lock:
            top = self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? ORDER BY priority DESC LIMIT ?", (partition, fetch)).fetchall()
            recent = self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? ORDER BY last_seen DESC LIMIT ?", (partition, fetch // 2)).fetchall()
            bounds = self.connection.execute("SELECT COUNT(*),COALESCE(MAX(id),0) FROM episodic_memory WHERE partition=?", (partition,)).fetchone()
            uniform = []
            if int(bounds[0]) and int(bounds[1]):
                anchor_count = min(16, max(4, count // 8))
                per_anchor = max(2, fetch // max(1, anchor_count * 4))
                for _ in range(anchor_count):
                    anchor = random.randint(1, int(bounds[1]))
                    uniform.extend(self.connection.execute("SELECT * FROM episodic_memory WHERE partition=? AND id>=? ORDER BY id LIMIT ?", (partition, anchor, per_anchor)).fetchall())
        rows = {int(row["id"]): row for row in list(top) + list(recent) + list(uniform)}
        if len(rows) < count:
            with self.lock:
                tiered = self._tier_rows("episodic_memory", query=partition, limit=count - len(rows))
            for row in tiered:
                if str(row.get("partition", "train")) == partition:
                    rows[int(row["id"])] = row
        if not rows:
            return []
        weighted = []
        for row in rows.values():
            value_score = (
                max(0.05, float(row["importance"])) * 0.34
                + max(0.05, float(row["novelty"])) * 0.18
                + max(0.05, float(row["confidence"])) * 0.18
                + clamp(math.log1p(int(row["reuse_count"])) / 5.0, 0.0, 1.0) * 0.12
                + clamp(max(0.001, float(row["priority"])) / 6.0, 0.0, 1.0) * 0.18
            )
            weight = max(0.001, value_score) * (1.0 + math.log1p(int(row["sample_count"])) * 0.05)
            key = random.random() ** (1.0 / max(1e-6, weight))
            weighted.append((key, weight, row))
        selected = sorted(weighted, key=lambda value: value[0], reverse=True)[:min(count, len(weighted))]
        max_weight = max(value[1] for value in selected)
        result = []
        selected_ids = []
        for _, weight, row in selected:
            item = self._decode_experience(row)
            # importance 仍保留为训练采样修正；数据库中的 importance 是长期价值指标。
            item["importance"] = clamp((max_weight / max(weight, 1e-6)) ** 0.35, 0.2, 1.0)
            result.append(item)
            selected_ids.append(int(row["id"]))
        if selected_ids:
            now = time.time()
            with self.lock:
                self.connection.executemany("UPDATE episodic_memory SET reuse_count=reuse_count+1,last_used=? WHERE id=?", [(now, value) for value in selected_ids])
        return result

    @staticmethod
    def holdout_fingerprint(items):
        payload = "|".join(str(item.get("fingerprint", "")) for item in items)
        return hashlib.sha256(payload.encode("ascii", "ignore")).hexdigest()

    def update_priorities(self, values):
        with self.lock:
            self.connection.executemany("UPDATE episodic_memory SET priority=?, last_seen=? WHERE id=?", [
                (float(clamp(priority, 0.001, 20.0)), time.time(), int(identifier)) for identifier, priority in values
            ])

    def remember_failure(self, command, signature, reason, risk=0.5):
        if not self._write_allowed():
            return False
        payload = command.payload() if isinstance(command, ActionCommand) else command
        action_json = compact_json(payload)
        kind = int(payload.get("kind", -1)) if isinstance(payload, dict) else -1
        fingerprint = hashlib.blake2s((signature + "|" + action_json + "|" + reason).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO failure_memory(fingerprint,action_json,state_signature,reason,occurrences,first_seen,last_seen,action_kind,risk)
                VALUES(?,?,?,?,1,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    occurrences=failure_memory.occurrences+1,last_seen=excluded.last_seen,risk=max(failure_memory.risk,excluded.risk),action_kind=excluded.action_kind
            """, (fingerprint, action_json, signature, str(reason), now, now, kind, float(clamp(risk, 0.0, 1.0))))

    def failure_score(self, signature, command):
        payload = command.payload() if isinstance(command, ActionCommand) else command
        action_json = compact_json(payload)
        with self.lock:
            rows = self.connection.execute("SELECT occurrences,risk,action_json FROM failure_memory WHERE state_signature=?", (str(signature),)).fetchall()
        score = 0.0
        for row in rows:
            if str(row["action_json"]) == action_json:
                score += (1.0 - math.exp(-float(row["occurrences"]) / 2.5)) * max(0.35, float(row["risk"]))
        return clamp(score, 0.0, 1.0)

    def failure_action_scores(self, signature):
        with self.lock:
            rows = self.connection.execute("SELECT action_kind,SUM(occurrences),MAX(risk) FROM failure_memory WHERE state_signature=? GROUP BY action_kind", (str(signature),)).fetchall()
        result = {}
        for row in rows:
            kind = int(row[0])
            if 0 <= kind < ACTION_COUNT:
                result[kind] = clamp((1.0 - math.exp(-float(row[1]) / 3.5)) * max(0.30, float(row[2])), 0.0, 1.0)
        return result

    def remember_text(self, text, success):
        if not self._write_allowed():
            return False
        text = str(text or "")
        if not text:
            return
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO text_memory(text,uses,successes,score,last_seen) VALUES(?,1,?,?,?)
                ON CONFLICT(text) DO UPDATE SET uses=text_memory.uses+1,successes=text_memory.successes+excluded.successes,
                    score=text_memory.score*0.95+excluded.score*0.05,last_seen=excluded.last_seen
            """, (text, int(bool(success)), 1.0 if success else -0.1, now))

    def text_candidates(self, limit=32):
        with self.lock:
            rows = self.connection.execute("SELECT text FROM text_memory ORDER BY score DESC,successes DESC,last_seen DESC LIMIT ?", (int(limit),)).fetchall()
            tiered = self._tier_rows("text_memory", limit=max(1, int(limit) - len(rows))) if len(rows) < int(limit) else []
        values = [str(row[0]) for row in rows] + [str(row.get("text", "")) for row in tiered]
        return list(dict.fromkeys(value for value in values if value))[:max(1, int(limit))]

    def predict_transitions(self, signature, action_kind, limit=8, state_key=""):
        limit = max(1, int(limit))
        with self.lock:
            exact = self.connection.execute(
                "SELECT * FROM episodic_memory WHERE state_signature=? AND action_kind=? ORDER BY priority DESC,last_seen DESC LIMIT ?",
                (str(signature), int(action_kind), limit),
            ).fetchall()
            candidates = []
            if state_key and len(exact) < limit:
                candidate_limit = max(limit * 4, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("episodic_memory", 1)))))
                candidates = self.connection.execute(
                    "SELECT * FROM episodic_memory WHERE action_kind=? AND state_key<>'' ORDER BY priority DESC,last_seen DESC LIMIT ?",
                    (int(action_kind), candidate_limit),
                ).fetchall()
        rows = list(exact)
        seen = {int(row["id"]) for row in rows}
        if state_key and len(rows) < limit:
            ranked = []
            for row in candidates:
                if int(row["id"]) in seen:
                    continue
                score = similarity(state_key, str(row["state_key"]))
                if score >= 0.28:
                    recency = 1.0 / (1.0 + max(0.0, time.time() - float(row["last_seen"])) / 86400.0)
                    ranked.append((score * 0.72 + clamp(float(row["priority"]) / 8.0, 0.0, 1.0) * 0.20 + recency * 0.08, row))
            ranked.sort(key=lambda value: value[0], reverse=True)
            rows.extend(row for _, row in ranked[:max(0, limit - len(rows))])
        return [self._decode_experience(row) for row in rows[:limit]]

    def retrieval_features(self, signature, count):
        count = max(0, int(count))
        if not count:
            return []
        limit = max(2, (count + 5) // 6)
        with self.lock:
            rows = self.connection.execute(
                "SELECT action_kind,reward,goal_reward,safety_penalty,next_signature,priority FROM episodic_memory WHERE state_signature=? ORDER BY priority DESC,last_seen DESC LIMIT ?",
                (str(signature), limit),
            ).fetchall()
        values = []
        for row in rows:
            action = int(row["action_kind"])
            next_hash = hashlib.blake2s(str(row["next_signature"]).encode("utf-8", "ignore"), digest_size=2).digest()
            values.extend([
                action / max(1, ACTION_COUNT - 1),
                clamp(float(row["reward"]) * 0.5 + 0.5, 0.0, 1.0),
                clamp(float(row["goal_reward"]) * 0.5 + 0.5, 0.0, 1.0),
                clamp(float(row["safety_penalty"]), 0.0, 1.0),
                int.from_bytes(next_hash, "little") / 65535.0,
                clamp(math.log1p(max(0.0, float(row["priority"]))) / 3.0, 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        return normalize_state(values, count)

    def remember_world_transition(self, item):
        if not self._write_allowed():
            return False
        """学习 state + action -> predicted_state 的本地世界模型原型。"""
        action = int(item.get("action", WAIT))
        state_key = str(item.get("state_key", "") or item.get("signature", ""))
        cluster_text = " ".join(semantic_units(state_key)) or state_key
        fingerprint = hashlib.blake2s((str(action) + "|" + cluster_text).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        now = time.time()
        next_state = normalize_state(item.get("next_state", []), max(BASE_FEATURE_COUNT, len(item.get("next_state", []))))
        state = normalize_state(item.get("state", []), max(BASE_FEATURE_COUNT, len(item.get("state", []))))
        with self.lock:
            row = self.connection.execute("SELECT * FROM world_transition WHERE fingerprint=?", (fingerprint,)).fetchone()
            if row:
                observations = int(row["observations"]) + 1
                try:
                    old_next = unpack_state(row["next_state"])
                    sample = min(len(old_next), len(next_state))
                    error = math.sqrt(sum((old_next[i] - next_state[i]) ** 2 for i in range(sample)) / max(1, sample))
                except Exception:
                    error = 0.5
                mean_error = float(row["prediction_error"]) * 0.90 + error * 0.10
                confidence = clamp((1.0 - math.exp(-observations / 5.0)) * (1.0 - clamp(mean_error * 1.8, 0.0, 0.85)), 0.05, 0.995)
                self.connection.execute("""
                    UPDATE world_transition SET state=?,next_state=?,next_signature=?,next_state_key=?,next_mask=?,
                        mean_reward=mean_reward*0.94+?*0.06,mean_safety=mean_safety*0.94+?*0.06,
                        prediction_error=?,confidence=?,observations=?,last_seen=? WHERE fingerprint=?
                """, (
                    pack_state(state), pack_state(next_state), str(item.get("next_signature", "")), str(item.get("next_state_key", "")),
                    int(item.get("next_mask", 0)), float(item.get("reward", 0.0)), float(item.get("safety_penalty", 0.0)),
                    mean_error, confidence, observations, now, fingerprint,
                ))
            else:
                self.connection.execute("""
                    INSERT INTO world_transition(fingerprint,action_kind,state_key,state,next_state,next_signature,next_state_key,next_mask,
                        mean_reward,mean_safety,prediction_error,confidence,observations,created_at,last_seen)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    fingerprint, action, state_key, pack_state(state), pack_state(next_state), str(item.get("next_signature", "")),
                    str(item.get("next_state_key", "")), int(item.get("next_mask", 0)), float(item.get("reward", 0.0)),
                    float(item.get("safety_penalty", 0.0)), 0.35, 0.22, 1, now, now,
                ))

    def world_candidates(self, action_kind, state_key="", limit=48):
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM world_transition WHERE action_kind=? ORDER BY confidence DESC,observations DESC,last_seen DESC LIMIT ?",
                (int(action_kind), max(8, int(limit) * 4)),
            ).fetchall()
        ranked = []
        for row in rows:
            match = similarity(state_key, str(row["state_key"])) if state_key else 0.25
            if state_key and match < 0.05:
                continue
            confidence = float(row["confidence"])
            score = match * 0.68 + confidence * 0.24 + clamp(math.log1p(int(row["observations"])) / 5.0, 0.0, 1.0) * 0.08
            ranked.append((score, {
                "state": unpack_state(row["state"]), "next_state": unpack_state(row["next_state"]),
                "next_signature": str(row["next_signature"]), "next_state_key": str(row["next_state_key"]),
                "next_mask": int(row["next_mask"]), "reward": float(row["mean_reward"]), "safety": float(row["mean_safety"]),
                "prediction_error": float(row["prediction_error"]), "confidence": confidence,
                "observations": int(row["observations"]), "similarity": match,
            }))
        ranked.sort(key=lambda value: value[0], reverse=True)
        return [value for _, value in ranked[:max(1, int(limit))]]

    def remember_observation_knowledge(self, observation):
        if not self._write_allowed():
            return False
        """把软件/窗口/控件语义沉淀为可复用知识，不把所有成长都压给神经网络。"""
        now = time.time()
        process_name = str(getattr(observation, "process_name", "") or "")
        items = []
        window_value = {
            "process_name": process_name, "window_title": observation.accessibility.window_title,
            "window_class": observation.accessibility.window_class,
        }
        window_key = "|".join((process_name, observation.accessibility.window_class, observation.accessibility.window_title))
        items.append(("window", window_key, window_value))
        for record in observation.accessibility.records:
            if record.get("offscreen"):
                continue
            key = "|".join((process_name, str(record.get("control_type", "")), str(record.get("automation_id", "")), str(record.get("name", ""))))
            value = {
                "process_name": process_name, "control_type": record.get("control_type", ""), "name": record.get("name", ""),
                "automation_id": record.get("automation_id", ""), "class_name": record.get("class_name", ""),
                "help": record.get("help", ""), "locator": control_locator(record),
            }
            items.append(("control", key, value))
        with self.lock:
            for kind, key, value in items:
                if not key.strip("|"):
                    continue
                fingerprint = hashlib.blake2s((kind + "|" + key).encode("utf-8", "ignore"), digest_size=16).hexdigest()
                self.connection.execute("""
                    INSERT INTO semantic_knowledge(fingerprint,kind,key_text,value_json,confidence,observations,reuse_count,created_at,last_used,last_seen)
                    VALUES(?,?,?,?,0.30,1,0,?,?,?)
                    ON CONFLICT(fingerprint) DO UPDATE SET value_json=excluded.value_json,observations=semantic_knowledge.observations+1,
                        confidence=min(0.995,1.0-exp(-(semantic_knowledge.observations+1)/8.0)),last_seen=excluded.last_seen
                """, (fingerprint, kind, key, compact_json(value), now, now, now))

    def knowledge_count(self):
        with self.lock:
            return int(self.connection.execute("SELECT COUNT(*) FROM semantic_knowledge").fetchone()[0])

    def remember_external_document(self, url, title, text, fetched_at=None, confidence=0.62):
        if not self._write_allowed():
            return False
        """保存用户明确允许访问的普通网页文本；不调用任何外部 AI。"""
        url = str(url or "").strip()
        text = str(text or "").strip()
        if not url or not text:
            return None
        now = float(fetched_at or time.time())
        value = {
            "source": url, "title": str(title or url), "fetched_at": now,
            "confidence": clamp(float(confidence), 0.0, 1.0), "text": text,
        }
        fingerprint = hashlib.blake2s(("external_document|" + url).encode("utf-8", "ignore"), digest_size=16).hexdigest()
        with self.lock:
            self.connection.execute("""
                INSERT INTO semantic_knowledge(fingerprint,kind,key_text,value_json,confidence,observations,reuse_count,created_at,last_used,last_seen)
                VALUES(?,?,?,?,?,1,0,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET value_json=excluded.value_json,key_text=excluded.key_text,
                    confidence=max(semantic_knowledge.confidence,excluded.confidence),observations=semantic_knowledge.observations+1,
                    last_seen=excluded.last_seen
            """, (fingerprint, "external_document", (str(title or "") + " | " + url), compact_json(value), float(value["confidence"]), now, now, now))
        return fingerprint

    def semantic_context(self, query, limit=8):
        query = str(query or "").strip()
        candidate_limit = max(int(limit) * 6, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("semantic_knowledge", 1)))))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM semantic_knowledge WHERE kind='external_document' ORDER BY confidence DESC,last_seen DESC LIMIT ?",
                (candidate_limit,),
            ).fetchall()
            tiered = self._tier_rows("semantic_knowledge", query=query, limit=candidate_limit)
        candidates = list(rows) + [row for row in tiered if str(row.get("kind", "")) == "external_document"]
        ranked = []
        for row in candidates:
            try:
                value = json.loads(row["value_json"])
            except Exception:
                continue
            title = str(value.get("title", "")); text = str(value.get("text", "")); source = str(value.get("source", ""))
            score = similarity(query, title + " " + text) if query else safe_float(row["confidence"], 0.0)
            if query and any(unit in (title + " " + text).lower() for unit in semantic_units(query)):
                score += 0.25
            ranked.append((score + safe_float(row["confidence"], 0.0) * 0.18, value))
        ranked.sort(key=lambda item: item[0], reverse=True)
        context_chars = max(512, int(math.sqrt(self.resource_budget.network_document_bytes()) * 8.0))
        result = []
        for score, value in ranked[:max(1, int(limit))]:
            result.append({
                "source": str(value.get("source", "")), "title": str(value.get("title", "")),
                "fetched_at": safe_float(value.get("fetched_at", 0.0)), "confidence": safe_float(value.get("confidence", score)),
                "snippet": str(value.get("text", ""))[:context_chars],
            })
        return result

    def known_control_hints(self, process_name, query="", limit=8):
        process_name = str(process_name or "").lower().strip()
        query = str(query or "").strip()
        candidate_limit = max(int(limit) * 8, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("semantic_knowledge", 1))) * 4.0))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM semantic_knowledge WHERE kind='control' ORDER BY confidence DESC,observations DESC,last_seen DESC LIMIT ?",
                (candidate_limit,),
            ).fetchall()
            tiered = self._tier_rows("semantic_knowledge", query=query or process_name, limit=candidate_limit)
        ranked = []
        hot_fingerprints = {str(row["fingerprint"]) for row in rows}
        for row in list(rows) + [item for item in tiered if str(item.get("kind", "")) == "control"]:
            try:
                value = json.loads(row["value_json"])
            except Exception:
                continue
            if process_name and str(value.get("process_name", "")).lower() not in ("", process_name):
                continue
            text = " ".join((str(value.get("name", "")), str(value.get("automation_id", "")), str(value.get("class_name", "")), str(value.get("control_type", ""))))
            score = similarity(query, text) if query else float(row["confidence"])
            if query and query.lower() in text.lower():
                score += 0.45
            score += float(row["confidence"]) * 0.25
            ranked.append((score, row, value, str(row["fingerprint"]) in hot_fingerprints))
        ranked.sort(key=lambda item: item[0], reverse=True)
        chosen = ranked[:max(1, int(limit))]
        hot_chosen = [item for item in chosen if item[3]]
        if hot_chosen:
            now = time.time()
            with self.lock:
                self.connection.executemany(
                    "UPDATE semantic_knowledge SET reuse_count=reuse_count+1,last_used=? WHERE fingerprint=?",
                    [(now, str(row["fingerprint"])) for _, row, _, _ in hot_chosen],
                )
        return [value for _, _, value, _ in chosen]

    def remember_strategy(self, operation, app_key, precondition, recovery, subgoals=None):
        if not self._write_allowed():
            return False
        operation = str(operation or "unknown")
        app_key = str(app_key or "unknown").lower()
        recovery = list(recovery or [])
        subgoals = list(subgoals or [])
        if not recovery:
            return None
        source = compact_json({"operation": operation, "app": app_key, "recovery": recovery, "subgoals": subgoals})
        fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO strategy_memory(fingerprint,operation,app_key,precondition_json,recovery_json,subgoals_json,successes,failures,confidence,reuse_count,created_at,last_used,last_seen)
                VALUES(?,?,?,?,?,?,1,0,0.42,0,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET successes=strategy_memory.successes+1,
                    confidence=min(0.995,1.0-exp(-(strategy_memory.successes+1)/4.0)),last_seen=excluded.last_seen,
                    precondition_json=excluded.precondition_json
            """, (fingerprint, operation, app_key, compact_json(precondition or {}), compact_json(recovery), compact_json(subgoals), now, now, now))
        return fingerprint

    def best_strategy(self, operation, app_key=""):
        operation = str(operation or "")
        app_key = str(app_key or "").lower()
        candidate_limit = max(2, int(math.log2(1.0 + max(1, self.resource_budget.memory_limits().get("strategy_memory", 1))) * 2.0))
        with self.lock:
            rows = self.connection.execute(
                "SELECT * FROM strategy_memory WHERE operation=? AND (app_key=? OR app_key='unknown') ORDER BY confidence DESC,successes DESC,last_seen DESC LIMIT ?",
                (operation, app_key, candidate_limit),
            ).fetchall()
            if not rows and app_key:
                rows = self.connection.execute(
                    "SELECT * FROM strategy_memory WHERE operation=? ORDER BY confidence DESC,successes DESC,last_seen DESC LIMIT ?", (operation, candidate_limit)
                ).fetchall()
            tiered = self._tier_rows("strategy_memory", query=operation, limit=candidate_limit)
        if not rows:
            candidates = [row for row in tiered if str(row.get("operation", "")) == operation and (not app_key or str(row.get("app_key", "")) in (app_key, "unknown"))]
            candidates.sort(key=lambda row: (safe_float(row.get("confidence", 0.0)), int(row.get("successes", 0)), safe_float(row.get("last_seen", 0.0))), reverse=True)
            rows = candidates
        if not rows:
            return None
        row = rows[0]
        now = time.time()
        if isinstance(row, sqlite3.Row):
            with self.lock:
                self.connection.execute("UPDATE strategy_memory SET reuse_count=reuse_count+1,last_used=? WHERE fingerprint=?", (now, str(row["fingerprint"])))
        return {"fingerprint": str(row["fingerprint"]), "operation": str(row["operation"]), "app_key": str(row["app_key"]),
                "precondition": json.loads(row["precondition_json"]), "recovery": json.loads(row["recovery_json"]),
                "subgoals": json.loads(row["subgoals_json"]), "confidence": float(row["confidence"]), "successes": int(row["successes"])}

    def remember_sleep_report(self, report):
        now = time.time()
        with self.lock:
            self.connection.execute("""
                INSERT INTO sleep_report(created_at,reason,findings_json,improvements_json,regressions_json,repeated_errors_json,bottleneck,
                    structural_growth_json,before_metrics_json,after_metrics_json) VALUES(?,?,?,?,?,?,?,?,?,?)
            """, (
                now, str(report.get("reason", "")), compact_json(report.get("findings", [])), compact_json(report.get("improvements", [])),
                compact_json(report.get("regressions", [])), compact_json(report.get("repeated_errors", [])), str(report.get("bottleneck", "unknown"))[:64],
                compact_json(report.get("structural_growth", [])), compact_json(report.get("before_metrics", {})), compact_json(report.get("after_metrics", {})),
            ))
        result = dict(report)
        result["created_at"] = now
        return result

    def latest_sleep_report(self):
        with self.lock:
            row = self.connection.execute("SELECT * FROM sleep_report ORDER BY id DESC LIMIT 1").fetchone()
        if not row:
            return {}
        return {
            "created_at": float(row["created_at"]), "reason": str(row["reason"]), "findings": json.loads(row["findings_json"]),
            "improvements": json.loads(row["improvements_json"]), "regressions": json.loads(row["regressions_json"]),
            "repeated_errors": json.loads(row["repeated_errors_json"]), "bottleneck": str(row["bottleneck"]),
            "structural_growth": json.loads(row["structural_growth_json"]), "before_metrics": json.loads(row["before_metrics_json"]),
            "after_metrics": json.loads(row["after_metrics_json"]),
        }

    def recent_failure_patterns(self, limit=8):
        with self.lock:
            rows = self.connection.execute("SELECT reason,SUM(occurrences) AS n,MAX(risk) AS r FROM failure_memory GROUP BY reason ORDER BY n DESC,r DESC LIMIT ?", (int(limit),)).fetchall()
        return [{"reason": str(row["reason"]), "occurrences": int(row["n"]), "risk": float(row["r"])} for row in rows]

    def upsert_skill(self, fingerprint, name, level, steps, precondition, expected, score, parameters=None, success=None, recovery=None, program_version=2, capabilities=None):
        if not self._write_allowed():
            return 0
        now = time.time()
        parameters = parameters or {}
        capabilities = sorted(set(str(value) for value in (capabilities or []) if value))
        success = success if success is not None else expected
        recovery = recovery or [{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}]
        with self.lock:
            self.connection.execute("""
                INSERT INTO skill_memory(fingerprint,name,level,steps_json,precondition_json,expected_json,score,created_at,updated_at,parameters_json,success_json,recovery_json,program_version,capabilities_json)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    name=excluded.name,level=max(skill_memory.level,excluded.level),score=max(skill_memory.score,excluded.score),
                    expected_json=excluded.expected_json,parameters_json=excluded.parameters_json,success_json=excluded.success_json,
                    recovery_json=excluded.recovery_json,capabilities_json=excluded.capabilities_json,
                    program_version=max(skill_memory.program_version,excluded.program_version),updated_at=excluded.updated_at
            """, (fingerprint, str(name), int(level), compact_json(steps), compact_json(precondition), compact_json(expected), float(score), now, now,
                  compact_json(parameters), compact_json(success), compact_json(recovery), int(program_version), compact_json(capabilities)))
            row = self.connection.execute("SELECT id FROM skill_memory WHERE fingerprint=?", (fingerprint,)).fetchone()
        return int(row[0])

    @staticmethod
    def _decode_skill(row):
        keys = set(row.keys())
        level = int(row["level"])
        if level <= 1:
            abstraction_kind = "Skill"
        elif level <= 3:
            abstraction_kind = "Procedure"
        elif level <= 7:
            abstraction_kind = "MacroAction"
        else:
            abstraction_kind = "Tool"
        return {
            "id": int(row["id"]), "fingerprint": str(row["fingerprint"]), "name": str(row["name"]),
            "level": level, "abstraction_kind": abstraction_kind, "steps": json.loads(row["steps_json"]),
            "precondition": json.loads(row["precondition_json"]), "expected": json.loads(row["expected_json"]),
            "parameters": json.loads(row["parameters_json"]) if "parameters_json" in keys and row["parameters_json"] else {},
            "success": json.loads(row["success_json"]) if "success_json" in keys and row["success_json"] else json.loads(row["expected_json"]),
            "recovery": json.loads(row["recovery_json"]) if "recovery_json" in keys and row["recovery_json"] else [],
            "capabilities": json.loads(row["capabilities_json"]) if "capabilities_json" in keys and row["capabilities_json"] else [],
            "program_version": int(row["program_version"]) if "program_version" in keys else 1,
            "uses": int(row["uses"]), "successes": int(row["successes"]),
            "average_seconds": float(row["average_seconds"]), "score": float(row["score"]),
        }

    def get_skill(self, identifier):
        with self.lock:
            row = self.connection.execute("SELECT * FROM skill_memory WHERE id=?", (int(identifier),)).fetchone()
            if row is None:
                row = self._tier_row("skill_memory", str(int(identifier)))
        return self._decode_skill(row) if row else None

    def top_skills(self, limit=256):
        with self.lock:
            rows = self.connection.execute("SELECT * FROM skill_memory ORDER BY score DESC,successes DESC,updated_at DESC LIMIT ?", (int(limit),)).fetchall()
            tiered = self._tier_rows("skill_memory", limit=max(1, int(limit) - len(rows))) if len(rows) < int(limit) else []
        skills = [self._decode_skill(row) for row in list(rows) + tiered]
        unique = {int(skill["id"]): skill for skill in skills}
        ordered = sorted(unique.values(), key=lambda skill: (safe_float(skill.get("score", 0.0)), int(skill.get("successes", 0)), -safe_float(skill.get("average_seconds", 0.0))), reverse=True)
        return ordered[:max(1, int(limit))]

    def record_skill_result(self, identifier, success, seconds):
        if not self._write_allowed():
            return
        with self.lock:
            row = self.connection.execute("SELECT uses,successes,average_seconds,score FROM skill_memory WHERE id=?", (int(identifier),)).fetchone()
            if not row:
                return
            uses = int(row[0]) + 1
            successes = int(row[1]) + int(bool(success))
            average = float(seconds) if uses == 1 else float(row[2]) * 0.9 + float(seconds) * 0.1
            score = float(row[3]) * 0.97 + (0.12 if success else -0.08)
            self.connection.execute("UPDATE skill_memory SET uses=?,successes=?,average_seconds=?,score=?,updated_at=? WHERE id=?", (uses, successes, average, score, time.time(), int(identifier)))

    def _demote_table(self, table, hot_limit, order_by, protected_keys=None, deadline=None, batch_limit=256):
        """热记忆 -> 可检索压缩记忆。按小批量执行并尊重睡眠 deadline，避免数据库越大睡眠越久。"""
        hot_limit = max(1, int(hot_limit))
        total = int(self.connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0])
        trigger = hot_limit + max(1, int(math.sqrt(hot_limit)))
        if total <= trigger:
            return 0
        needed = total - hot_limit
        protected_keys = set(str(value) for value in (protected_keys or ()))
        query_limit = min(
            needed + len(protected_keys) + max(8, int(math.sqrt(needed))),
            max(16, int(batch_limit)) + len(protected_keys),
        )
        candidates = self.connection.execute(
            "SELECT rowid AS _tier_rowid,* FROM " + table + " ORDER BY " + order_by + " LIMIT ?",
            (query_limit,),
        ).fetchall()
        moved = 0
        now = time.time()
        for row in candidates:
            if deadline is not None and time.monotonic() >= float(deadline):
                break
            source_key = self._source_key(table, row)
            if not source_key or source_key in protected_keys:
                continue
            payload = self._encode_tier_row(row)
            search_text = self._row_search_text(row)
            importance = self._first_number(row, ("importance", "confidence", "score", "risk", "priority", "value"), 0.0)
            created = self._first_number(row, ("created_at", "first_seen", "created_at", "updated_at"), now)
            last_seen = self._first_number(row, ("last_seen", "last_used", "updated_at", "created_at"), created)
            self.connection.execute("""
                INSERT INTO memory_compressed(source_table,source_key,search_text,payload,codec,importance,original_created,last_seen,moved_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_table,source_key) DO UPDATE SET
                    search_text=excluded.search_text,payload=excluded.payload,codec=excluded.codec,
                    importance=max(memory_compressed.importance,excluded.importance),
                    last_seen=max(memory_compressed.last_seen,excluded.last_seen),moved_at=excluded.moved_at
            """, (table, source_key, search_text, payload, "zlib-json-v1", importance, created, last_seen, now))
            self.connection.execute("DELETE FROM " + table + " WHERE rowid=?", (int(row["_tier_rowid"]),))
            moved += 1
            if moved >= needed:
                break
        return moved

    def _archive_compressed(self, compressed_limit, deadline=None, batch_limit=256):
        """压缩记忆 -> 只增不自动删除的归档记忆；每轮只处理受限批次。"""
        compressed_limit = max(1, int(compressed_limit))
        total = int(self.connection.execute("SELECT COUNT(*) FROM memory_compressed").fetchone()[0])
        trigger = compressed_limit + max(1, int(math.sqrt(compressed_limit)))
        if total <= trigger:
            return 0
        move_count = min(total - compressed_limit, max(16, int(batch_limit)))
        rows = self.connection.execute(
            "SELECT * FROM memory_compressed ORDER BY importance ASC,last_seen ASC,moved_at ASC LIMIT ?", (move_count,)
        ).fetchall()
        now = time.time()
        moved = 0
        for row in rows:
            if deadline is not None and time.monotonic() >= float(deadline):
                break
            self.connection.execute("""
                INSERT INTO memory_archive(source_table,source_key,search_text,payload,codec,importance,original_created,last_seen,archived_at)
                VALUES(?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_table,source_key) DO UPDATE SET
                    search_text=excluded.search_text,payload=excluded.payload,codec=excluded.codec,
                    importance=max(memory_archive.importance,excluded.importance),
                    last_seen=max(memory_archive.last_seen,excluded.last_seen),archived_at=excluded.archived_at
            """, (
                str(row["source_table"]), str(row["source_key"]), str(row["search_text"]), bytes(row["payload"]),
                str(row["codec"]), float(row["importance"]), float(row["original_created"]), float(row["last_seen"]), now,
            ))
            self.connection.execute("DELETE FROM memory_compressed WHERE id=?", (int(row["id"]),))
            moved += 1
        return moved

    def consolidate(self, resource_budget=None, deadline=None):
        """分层整理记忆；deadline 到期时保留未处理数据给下一次睡眠继续。"""
        budget = resource_budget or self.resource_budget
        budget.refresh()
        self.resource_budget = budget
        limits = budget.memory_limits()
        demoted = {"experiences": 0, "states": 0, "skills": 0, "failures": 0, "texts": 0, "knowledge": 0, "world": 0, "sleep_reports": 0, "strategies": 0}
        timed_out = False
        with self.lock:
            self.connection.commit()
            table_jobs = [
                ("experiences", "episodic_memory", "(importance*0.34 + novelty*0.18 + confidence*0.18 + min(reuse_count,50)/50.0*0.12 + min(priority,6)/6.0*0.18) ASC, last_used ASC, last_seen ASC"),
                ("states", "state_memory", "successes ASC, abs(value) ASC, visits ASC, last_seen ASC"),
                ("failures", "failure_memory", "risk ASC, occurrences ASC, last_seen ASC"),
                ("texts", "text_memory", "successes ASC, score ASC, uses ASC, last_seen ASC"),
                ("knowledge", "semantic_knowledge", "confidence ASC, observations ASC, last_used ASC, last_seen ASC"),
                ("world", "world_transition", "confidence ASC, observations ASC, last_seen ASC"),
                ("sleep_reports", "sleep_report", "created_at ASC"),
                ("strategies", "strategy_memory", "confidence ASC, successes ASC, reuse_count ASC, last_used ASC"),
            ]
            for key, table, order_by in table_jobs:
                if deadline is not None and time.monotonic() >= float(deadline):
                    timed_out = True
                    break
                demoted[key] = self._demote_table(table, limits[table], order_by, deadline=deadline)

            protected = set()
            if not timed_out:
                # 技能存在父子引用：递归扫描程序分支，保护被复合技能引用的子技能。
                def collect_refs(step):
                    if not isinstance(step, dict):
                        return
                    if step.get("type") == "skill":
                        try: protected.add(str(int(step.get("skill_id", 0))))
                        except Exception: pass
                    for key in ("steps", "then", "else", "recovery"):
                        value = step.get(key, [])
                        if isinstance(value, dict): value = [value]
                        for child in value if isinstance(value, list) else []:
                            collect_refs(child)
                # 扫描也分批，以免超大技能库独占睡眠时间。
                cursor = 0
                while True:
                    if deadline is not None and time.monotonic() >= float(deadline):
                        timed_out = True
                        break
                    rows = self.connection.execute("SELECT rowid,steps_json FROM skill_memory WHERE rowid>? ORDER BY rowid LIMIT 256", (cursor,)).fetchall()
                    if not rows:
                        break
                    for row in rows:
                        cursor = int(row[0])
                        try:
                            for step in json.loads(row[1]): collect_refs(step)
                        except Exception:
                            pass
                    if len(rows) < 256:
                        break
            if not timed_out:
                demoted["skills"] = self._demote_table(
                    "skill_memory", limits["skill_memory"], "successes ASC,score ASC,uses ASC,updated_at ASC",
                    protected_keys=protected, deadline=deadline,
                )
            archived_now = 0 if (deadline is not None and time.monotonic() >= float(deadline)) else self._archive_compressed(limits["memory_compressed"], deadline=deadline)
            timed_out = timed_out or (deadline is not None and time.monotonic() >= float(deadline))
            self.connection.commit()
            if not timed_out:
                self.connection.execute("PRAGMA optimize")
                self.connection.execute("PRAGMA wal_checkpoint(PASSIVE)")
        tiers = self.tier_counts()
        return {
            "experiences": self.count("episodic_memory"), "states": self.count("state_memory"),
            "skills": self.count("skill_memory"), "failures": self.count("failure_memory"),
            "knowledge": self.count("semantic_knowledge"), "world": self.count("world_transition"), "strategies": self.count("strategy_memory"),
            "demoted": demoted, "compressed": tiers["compressed"], "archived": tiers["archived"],
            "archived_now": archived_now, "resource_limits": limits, "timed_out": bool(timed_out),
        }



class WorldModel:
    """无需第三方模型的可学习世界模型：state + action -> predicted_state + uncertainty。"""
    def __init__(self, memory):
        self.memory = memory

    def _state_similarity(self, first, second):
        if not first or not second:
            return 0.0
        count = min(len(first), len(second))
        if count <= 0:
            return 0.0
        comparison_points = max(64, int(math.sqrt(max(1, self.memory.resource_budget.hot_memory_bytes // 1024))))
        stride = max(1, count // comparison_points)
        distance = sum(abs(float(first[i]) - float(second[i])) for i in range(0, count, stride)) / max(1, len(range(0, count, stride)))
        return clamp(1.0 - distance * 1.8, 0.0, 1.0)

    def observe(self, item):
        self.memory.remember_world_transition(item)

    def predict(self, state, action_kind, state_key=""):
        world_budget = self.memory.resource_budget.memory_limits().get("world_transition", 1)
        candidate_limit = max(4, int(math.log2(1.0 + max(1, world_budget)) * 2.0 * self.memory.resource_budget._latency_factor("decision")))
        candidates = self.memory.world_candidates(action_kind, state_key=state_key, limit=candidate_limit)
        if not candidates:
            return {"predicted_state": normalize_state(state, len(state)), "uncertainty": 1.0, "reward": 0.0, "safety": 0.0, "next_mask": 0, "support": 0}
        ranked = []
        for candidate in candidates:
            state_match = self._state_similarity(state, candidate.get("state", []))
            semantic_match = float(candidate.get("similarity", 0.0))
            confidence = float(candidate.get("confidence", 0.0))
            weight = max(1e-4, state_match * 0.38 + semantic_match * 0.42 + confidence * 0.20)
            ranked.append((weight, candidate, state_match))
        ranked.sort(key=lambda value: value[0], reverse=True)
        selected_count = max(1, int(math.sqrt(max(1, len(ranked)))))
        selected = ranked[:selected_count]
        total = sum(value[0] for value in selected)
        output_count = max(len(state), max(len(value[1].get("next_state", [])) for value in selected))
        predicted = [0.0] * output_count
        reward = safety = 0.0
        mask_scores = Counter()
        for weight, candidate, _ in selected:
            local = normalize_state(candidate.get("next_state", []), output_count)
            ratio = weight / max(1e-9, total)
            for index, item in enumerate(local):
                predicted[index] += float(item) * ratio
            reward += float(candidate.get("reward", 0.0)) * ratio
            safety += float(candidate.get("safety", 0.0)) * ratio
            mask_scores[int(candidate.get("next_mask", 0))] += ratio
        sample = min(output_count, max(64, int(math.sqrt(max(1, self.memory.resource_budget.hot_memory_bytes // 1024)))))
        dispersion = 0.0
        if len(selected) > 1 and sample:
            for _, candidate, _ in selected:
                local = normalize_state(candidate.get("next_state", []), output_count)
                dispersion += math.sqrt(sum((local[i] - predicted[i]) ** 2 for i in range(sample)) / sample)
            dispersion /= len(selected)
        best_weight, best, best_state_match = selected[0]
        support = sum(int(value[1].get("observations", 1)) for value in selected)
        evidence = 1.0 - math.exp(-support / 8.0)
        model_confidence = clamp(
            best_state_match * 0.30 + float(best.get("similarity", 0.0)) * 0.28 + float(best.get("confidence", 0.0)) * 0.24 + evidence * 0.18,
            0.0, 1.0,
        )
        error = sum(float(value[1].get("prediction_error", 0.5)) * value[0] for value in selected) / max(1e-9, total)
        uncertainty = clamp(1.0 - model_confidence + dispersion * 0.55 + error * 0.45, 0.0, 1.0)
        next_mask = mask_scores.most_common(1)[0][0] if mask_scores else 0
        return {
            "predicted_state": predicted, "uncertainty": uncertainty, "reward": reward, "safety": safety,
            "next_mask": int(next_mask), "support": support, "next_signature": str(best.get("next_signature", "")),
            "next_state_key": str(best.get("next_state_key", "")),
        }

    def state_uncertainty(self, state, state_key, allowed):
        candidates = [kind for kind in allowed if kind not in (WAIT, SLEEP)]
        if not candidates:
            return 0.0
        values = [self.predict(state, kind, state_key).get("uncertainty", 1.0) for kind in candidates]
        # 用最可信的可行动作衡量“是否完全看不懂”；避免一个冷门动作把整个状态判成未知。
        values.sort()
        keep = values[:max(1, min(3, len(values)))]
        return sum(keep) / len(keep)


class BottleneckAnalyzer:
    NAMES = ("perception", "knowledge", "skill", "planning", "model_capacity", "none")

    @classmethod
    def classify(cls, context, model, memory):
        context = dict(context or {})
        perception = safe_float(context.get("perception_limited_ratio", 0.0))
        uncertainty = safe_float(context.get("world_uncertainty", 1.0), 1.0)
        stagnant = int(context.get("stagnant", 0))
        repeated = int(context.get("repeated", 0))
        unresolved = bool(context.get("compiler_unresolved", False))
        experiences = memory.count("episodic_memory")
        skills = memory.count("skill_memory")
        if perception >= 0.18:
            return "perception", "UIA/视觉信息不足，优先扩大感知与观察，不扩大策略网络"
        if unresolved or uncertainty >= 0.68:
            return "knowledge", "对对象/软件/状态转移缺少知识，优先积累语义知识和世界模型"
        if repeated >= 4 and skills < max(12, model.hidden_count // 3):
            return "skill", "动作重复但缺少可复用程序技能，优先技能压缩和参数化"
        if stagnant >= 24 and uncertainty < 0.55:
            if experiences >= max(600, model.hidden_count * 12) and skills >= max(10, model.hidden_count // 7) and model.loss_average > 0.10:
                return "model_capacity", "感知/知识已有支撑且策略长期停滞，模型容量可能成为瓶颈"
            return "planning", "世界模型有一定把握但进展停滞，优先扩展前置条件/恢复/规划搜索"
        return "none", "没有证据表明神经网络容量是当前首要瓶颈"


class Point(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class Rect(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class GuiThreadInfo(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND), ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND), ("hwndCaret", wintypes.HWND), ("rcCaret", Rect),
    ]


class ProcessEntry32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260),
    ]


class BitmapInfoHeader(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD), ("biWidth", wintypes.LONG), ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD), ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD), ("biXPelsPerMeter", wintypes.LONG), ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD),
    ]


class RGBQuad(ctypes.Structure):
    _fields_ = [("rgbBlue", ctypes.c_ubyte), ("rgbGreen", ctypes.c_ubyte), ("rgbRed", ctypes.c_ubyte), ("rgbReserved", ctypes.c_ubyte)]


class BitmapInfo(ctypes.Structure):
    _fields_ = [("bmiHeader", BitmapInfoHeader), ("bmiColors", RGBQuad * 1)]


ULONG_PTR = ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p) == 8 else ctypes.c_ulong


class MouseInput(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR),
    ]


class KeyboardInput(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR),
    ]


class HardwareInput(ctypes.Structure):
    _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]


class InputUnion(ctypes.Union):
    _fields_ = [("mi", MouseInput), ("ki", KeyboardInput), ("hi", HardwareInput)]


class Input(ctypes.Structure):
    _anonymous_ = ("union",)
    _fields_ = [("type", wintypes.DWORD), ("union", InputUnion)]


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_ulong), ("Data2", ctypes.c_ushort), ("Data3", ctypes.c_ushort),
        ("Data4", ctypes.c_ubyte * 8),
    ]

    @classmethod
    def from_text(cls, text):
        value = uuid.UUID(text)
        return cls(value.time_low, value.time_mid, value.time_hi_version, (ctypes.c_ubyte * 8)(*value.bytes[8:]))


class VariantValue(ctypes.Union):
    _fields_ = [
        ("llVal", ctypes.c_longlong), ("lVal", ctypes.c_long), ("ulVal", ctypes.c_ulong),
        ("dblVal", ctypes.c_double), ("boolVal", ctypes.c_short), ("bstrVal", ctypes.c_void_p),
        ("punkVal", ctypes.c_void_p), ("parray", ctypes.c_void_p), ("byref", ctypes.c_void_p), ("raw", ctypes.c_ubyte * 16),
    ]


class Variant(ctypes.Structure):
    _anonymous_ = ("value",)
    _fields_ = [
        ("vt", ctypes.c_ushort), ("reserved1", ctypes.c_ushort), ("reserved2", ctypes.c_ushort),
        ("reserved3", ctypes.c_ushort), ("value", VariantValue),
    ]


CONTROL_TYPES = {
    50000: "Button", 50001: "Calendar", 50002: "CheckBox", 50003: "ComboBox",
    50004: "Edit", 50005: "Hyperlink", 50006: "Image", 50007: "ListItem",
    50008: "List", 50009: "Menu", 50010: "MenuBar", 50011: "MenuItem",
    50012: "ProgressBar", 50013: "RadioButton", 50014: "ScrollBar", 50015: "Slider",
    50016: "Spinner", 50017: "StatusBar", 50018: "Tab", 50019: "TabItem",
    50020: "Text", 50021: "ToolBar", 50022: "ToolTip", 50023: "Tree",
    50024: "TreeItem", 50025: "Custom", 50026: "Group", 50027: "Thumb",
    50028: "DataGrid", 50029: "DataItem", 50030: "Document", 50031: "SplitButton",
    50032: "Window", 50033: "Pane", 50034: "Header", 50035: "HeaderItem",
    50036: "Table", 50037: "TitleBar", 50038: "Separator", 50039: "SemanticZoom", 50040: "AppBar",
}
INTERACTIVE_CONTROL_TYPES = {
    "Button", "CheckBox", "ComboBox", "Edit", "Hyperlink", "ListItem", "MenuItem",
    "RadioButton", "ScrollBar", "Slider", "Spinner", "TabItem", "TreeItem", "DataItem", "SplitButton",
}


@dataclass
class AccessibilitySnapshot:
    hwnd: int = 0
    window_title: str = ""
    window_class: str = ""
    records: list = field(default_factory=list)

    def text(self):
        values = [self.window_title, self.window_class]
        for record in self.records:
            values.extend((record.get("name", ""), record.get("automation_id", ""), record.get("class_name", ""), record.get("control_type", ""), record.get("help", ""), record.get("value", "")))
        return " ".join(value for value in values if value)


class AccessibilityReader:
    CLSID_CUIAUTOMATION = GUID.from_text("ff48dba4-60ef-4201-aa87-54103eef594e")
    IID_IUIAUTOMATION = GUID.from_text("30cbe57d-d9d0-452a-ab13-7ac5ac4825ee")
    WINAPI = getattr(ctypes, "WINFUNCTYPE", ctypes.CFUNCTYPE)

    def __init__(self, user32, max_depth=4, max_nodes=128):
        self.user32 = user32
        self.max_depth = max(1, int(max_depth))
        self.max_nodes = max(16, int(max_nodes))
        self.automation = ctypes.c_void_p()
        self.walker = ctypes.c_void_p()
        self.initialized = False
        self.available = False
        if os.name != "nt":
            return
        try:
            self.ole32 = ctypes.WinDLL("ole32", use_last_error=True)
            self.oleaut32 = ctypes.WinDLL("oleaut32", use_last_error=True)
            self.ole32.CoInitializeEx.argtypes = [ctypes.c_void_p, wintypes.DWORD]
            self.ole32.CoInitializeEx.restype = ctypes.c_long
            result = int(self.ole32.CoInitializeEx(None, 0))
            self.initialized = result in (0, 1)
            self.ole32.CoCreateInstance.argtypes = [ctypes.POINTER(GUID), ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(GUID), ctypes.POINTER(ctypes.c_void_p)]
            self.ole32.CoCreateInstance.restype = ctypes.c_long
            result = int(self.ole32.CoCreateInstance(ctypes.byref(self.CLSID_CUIAUTOMATION), None, 1, ctypes.byref(self.IID_IUIAUTOMATION), ctypes.byref(self.automation)))
            self.available = result >= 0 and bool(self.automation.value)
            self.oleaut32.VariantClear.argtypes = [ctypes.POINTER(Variant)]
            self.oleaut32.VariantClear.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetDim.argtypes = [ctypes.c_void_p]
            self.oleaut32.SafeArrayGetDim.restype = ctypes.c_uint
            self.oleaut32.SafeArrayGetLBound.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_long)]
            self.oleaut32.SafeArrayGetLBound.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetUBound.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.POINTER(ctypes.c_long)]
            self.oleaut32.SafeArrayGetUBound.restype = ctypes.c_long
            self.oleaut32.SafeArrayGetElement.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_long), ctypes.c_void_p]
            self.oleaut32.SafeArrayGetElement.restype = ctypes.c_long
            if self.available:
                walker = ctypes.c_void_p()
                code = int(self._call(self.automation, 14, ctypes.c_long, [ctypes.POINTER(ctypes.c_void_p)], ctypes.byref(walker)))
                if code >= 0 and walker.value:
                    self.walker = walker
        except Exception:
            self.available = False

    def set_capacity(self, max_depth, max_nodes):
        self.max_depth = max(1, int(max_depth))
        self.max_nodes = max(16, int(max_nodes))

    def close(self):
        try:
            if self.walker.value:
                self._call(self.walker, 2, ctypes.c_ulong, [])
                self.walker = ctypes.c_void_p()
            if self.automation.value:
                self._call(self.automation, 2, ctypes.c_ulong, [])
                self.automation = ctypes.c_void_p()
            if self.initialized:
                self.ole32.CoUninitialize()
        except Exception:
            pass

    def _call(self, pointer, index, result_type, argument_types, *arguments):
        address = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents[index]
        prototype = self.WINAPI(result_type, ctypes.c_void_p, *argument_types)
        return prototype(address)(pointer, *arguments)

    def _array_property(self, value):
        psa = value.parray
        if not psa or self.oleaut32.SafeArrayGetDim(psa) != 1:
            return None
        lower = ctypes.c_long()
        upper = ctypes.c_long()
        if self.oleaut32.SafeArrayGetLBound(psa, 1, ctypes.byref(lower)) < 0 or self.oleaut32.SafeArrayGetUBound(psa, 1, ctypes.byref(upper)) < 0:
            return None
        base = int(value.vt) & 0x0FFF
        result = []
        for number in range(int(lower.value), int(upper.value) + 1):
            index = ctypes.c_long(number)
            if base == 5:
                local = ctypes.c_double()
            elif base in (2, 3, 16, 17, 18, 19, 20, 21, 22, 23):
                local = ctypes.c_longlong()
            else:
                return None
            if self.oleaut32.SafeArrayGetElement(psa, ctypes.byref(index), ctypes.byref(local)) < 0:
                return None
            result.append(float(local.value) if base == 5 else int(local.value))
        return result

    def _property(self, element, property_id):
        value = Variant()
        try:
            result = int(self._call(element, 10, ctypes.c_long, [ctypes.c_int, ctypes.POINTER(Variant)], int(property_id), ctypes.byref(value)))
            if result < 0:
                return None
            if int(value.vt) & 0x2000:
                return self._array_property(value)
            if value.vt == 8 and value.bstrVal:
                return ctypes.wstring_at(value.bstrVal)
            if value.vt in (2, 3, 16, 17, 18, 19, 20, 21, 22, 23):
                return int(value.llVal if value.vt in (20, 21) else value.lVal)
            if value.vt == 11:
                return bool(value.boolVal)
            if value.vt == 5:
                return float(value.dblVal)
            return None
        except Exception:
            return None
        finally:
            try:
                self.oleaut32.VariantClear(ctypes.byref(value))
            except Exception:
                pass

    def _record(self, element, fallback_point, source, depth=0):
        if not element or not element.value:
            return None
        password = bool(self._property(element, 30019))
        control_id = int(self._property(element, 30003) or 0)
        rectangle = self._property(element, 30001)
        x = int(fallback_point[0]) if fallback_point else 0
        y = int(fallback_point[1]) if fallback_point else 0
        bounds = None
        if isinstance(rectangle, list) and len(rectangle) >= 4:
            left, top, width, height = [safe_float(value) for value in rectangle[:4]]
            if width > 0.0 and height > 0.0 and all(math.isfinite(value) for value in (left, top, width, height)):
                x = int(round(left + width * 0.5))
                y = int(round(top + height * 0.5))
                bounds = [left, top, width, height]
        runtime_id = self._property(element, 30000)
        record = {
            "source": source, "depth": int(depth), "x": x, "y": y, "bounding_rectangle": bounds,
            "runtime_id": list(runtime_id) if isinstance(runtime_id, list) else [],
            "name": str(self._property(element, 30005) or ""),
            "automation_id": str(self._property(element, 30011) or ""),
            "class_name": str(self._property(element, 30012) or ""),
            "control_id": control_id,
            "control_type": CONTROL_TYPES.get(control_id, "Control" + str(control_id) if control_id else "Unknown"),
            "enabled": bool(self._property(element, 30010)),
            "focused": bool(self._property(element, 30008)),
            "keyboard_focusable": bool(self._property(element, 30009)),
            "password": password,
            "offscreen": bool(self._property(element, 30022)),
            "help": str(self._property(element, 30013) or ""),
            "value": "" if password else str(self._property(element, 30045) or ""),
        }
        return record

    def _element_from_handle(self, hwnd):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 6, ctypes.c_long, [wintypes.HWND, ctypes.POINTER(ctypes.c_void_p)], hwnd, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _element_from_point(self, point):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 7, ctypes.c_long, [Point, ctypes.POINTER(ctypes.c_void_p)], Point(int(point[0]), int(point[1])), ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _focused_element(self):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.automation, 8, ctypes.c_long, [ctypes.POINTER(ctypes.c_void_p)], ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _first_child(self, element):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.walker, 4, ctypes.c_long, [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], element, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _next_sibling(self, element):
        result = ctypes.c_void_p()
        try:
            code = int(self._call(self.walker, 6, ctypes.c_long, [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], element, ctypes.byref(result)))
            return result if code >= 0 else ctypes.c_void_p()
        except Exception:
            return ctypes.c_void_p()

    def _release(self, element):
        try:
            if element and element.value:
                self._call(element, 2, ctypes.c_ulong, [])
        except Exception:
            pass

    @staticmethod
    def _record_key(record):
        runtime = tuple(record.get("runtime_id") or ())
        if runtime:
            return ("runtime", runtime)
        bounds = tuple(round(safe_float(value), 1) for value in (record.get("bounding_rectangle") or []))
        return (record.get("name", ""), record.get("automation_id", ""), record.get("control_type", ""), bounds, record.get("x", 0), record.get("y", 0))

    def _tree_records(self, root, fallback_point):
        if not root or not root.value or not self.walker.value:
            return []
        records = []
        # 迭代遍历使 UIA 深度可以随资源增长，不受 Python 递归深度这一隐含上限约束。
        stack = [(root, 0, False)]
        while stack and len(records) < self.max_nodes:
            element, depth, owned = stack.pop()
            children = []
            try:
                record = self._record(element, fallback_point, "uia_tree", depth)
                if record:
                    records.append(record)
                if depth < self.max_depth and len(records) < self.max_nodes:
                    child = self._first_child(element)
                    while child and child.value and len(records) + len(stack) + len(children) < self.max_nodes:
                        next_child = self._next_sibling(child)
                        children.append(child)
                        child = next_child
                    if child and child.value:
                        self._release(child)
            finally:
                if owned:
                    self._release(element)
            for child in reversed(children):
                stack.append((child, depth + 1, True))
        for element, _, owned in stack:
            if owned:
                self._release(element)
        return records

    def _native_records(self, hwnd):
        if not hwnd:
            return []
        records = []
        callback_type = self.WINAPI(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        class_map = {
            "button": "Button", "edit": "Edit", "richedit": "Edit", "combobox": "ComboBox",
            "listbox": "List", "syslistview": "List", "systreeview": "Tree", "static": "Text",
            "msctls_progress": "ProgressBar", "scrollbar": "ScrollBar", "toolbarwindow": "ToolBar", "systabcontrol": "Tab",
        }
        try:
            self.user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(Rect)]
            self.user32.GetWindowRect.restype = wintypes.BOOL
            self.user32.IsWindowVisible.argtypes = [wintypes.HWND]
            self.user32.IsWindowVisible.restype = wintypes.BOOL
            self.user32.IsWindowEnabled.argtypes = [wintypes.HWND]
            self.user32.IsWindowEnabled.restype = wintypes.BOOL
            self.user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
            self.user32.GetWindowLongW.restype = ctypes.c_long

            @callback_type
            def visit(child, _):
                native_budget = max(16, int(math.sqrt(max(1, self.max_nodes)) * 4.0))
                if len(records) >= native_budget:
                    return False
                if not self.user32.IsWindowVisible(child):
                    return True
                title_buffer = ctypes.create_unicode_buffer(256)
                class_buffer = ctypes.create_unicode_buffer(128)
                self.user32.GetWindowTextW(child, title_buffer, len(title_buffer))
                self.user32.GetClassNameW(child, class_buffer, len(class_buffer))
                class_lower = class_buffer.value.lower()
                control_type = "Custom"
                for prefix, mapped in class_map.items():
                    if class_lower.startswith(prefix):
                        control_type = mapped
                        break
                if not title_buffer.value and control_type == "Custom":
                    return True
                rectangle = Rect()
                if not self.user32.GetWindowRect(child, ctypes.byref(rectangle)):
                    return True
                if rectangle.right <= rectangle.left or rectangle.bottom <= rectangle.top:
                    return True
                password = control_type == "Edit" and bool(int(self.user32.GetWindowLongW(child, -16)) & 0x20)
                width = rectangle.right - rectangle.left
                height = rectangle.bottom - rectangle.top
                records.append({
                    "source": "native", "depth": 1,
                    "x": int((rectangle.left + rectangle.right) // 2), "y": int((rectangle.top + rectangle.bottom) // 2),
                    "bounding_rectangle": [float(rectangle.left), float(rectangle.top), float(width), float(height)], "runtime_id": [],
                    "name": title_buffer.value, "automation_id": "", "class_name": class_buffer.value, "control_id": 0,
                    "control_type": control_type, "enabled": bool(self.user32.IsWindowEnabled(child)), "focused": False,
                    "keyboard_focusable": control_type in INTERACTIVE_CONTROL_TYPES, "password": password, "offscreen": False, "help": "", "value": "",
                })
                return True

            self.user32.EnumChildWindows.argtypes = [wintypes.HWND, callback_type, wintypes.LPARAM]
            self.user32.EnumChildWindows.restype = wintypes.BOOL
            self.user32.EnumChildWindows(hwnd, visit, 0)
        except Exception:
            return records
        return records

    def snapshot(self, points, fallback_point, deep=True):
        hwnd = self.user32.GetForegroundWindow()
        title_buffer = ctypes.create_unicode_buffer(512)
        class_buffer = ctypes.create_unicode_buffer(256)
        if hwnd:
            self.user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
            self.user32.GetClassNameW(hwnd, class_buffer, len(class_buffer))
        snapshot = AccessibilitySnapshot(int(hwnd or 0), title_buffer.value, class_buffer.value, [])
        if not self.available:
            snapshot.records.extend(self._native_records(hwnd))
            return snapshot
        elements = []
        try:
            active = self._element_from_handle(hwnd) if hwnd else ctypes.c_void_p()
            elements.append(active)
            if active.value:
                if deep:
                    snapshot.records.extend(self._tree_records(active, fallback_point))
                else:
                    root_record = self._record(active, fallback_point, "uia_shallow", 0)
                    if root_record:
                        snapshot.records.append(root_record)
            focused = self._focused_element()
            elements.append(focused)
            extras = [(focused, fallback_point, "focus")]
            for index, point in enumerate(points):
                element = self._element_from_point(point)
                elements.append(element)
                extras.append((element, point, "point" + str(index)))
            seen = {self._record_key(record) for record in snapshot.records}
            for element, point, source in extras:
                record = self._record(element, point, source, 0)
                if record:
                    key = self._record_key(record)
                    if key not in seen:
                        seen.add(key)
                        snapshot.records.append(record)
            for record in self._native_records(hwnd):
                key = self._record_key(record)
                if key not in seen:
                    seen.add(key)
                    snapshot.records.append(record)
        finally:
            for element in elements:
                self._release(element)
        return snapshot


def rgb_edges(rgb, width, height):
    luminance = []
    for index in range(0, len(rgb), 3):
        luminance.append(rgb[index] * 0.2126 + rgb[index + 1] * 0.7152 + rgb[index + 2] * 0.0722)
    edges = []
    for row in range(height):
        for column in range(width):
            index = row * width + column
            value = 0.0
            count = 0
            if column + 1 < width:
                value += abs(luminance[index] - luminance[index + 1]); count += 1
            if row + 1 < height:
                value += abs(luminance[index] - luminance[index + width]); count += 1
            edges.append(clamp(value / max(1, count) * 2.2, 0.0, 1.0))
    return edges, luminance


class Observation:
    def __init__(self, global_rgb, patches, cursor, interest, focus, patch_centers, accessibility, roi_pyramid=None):
        self.global_rgb = global_rgb
        self.patches = patches
        self.roi_pyramid = list(roi_pyramid or [])
        self.cursor_x, self.cursor_y = cursor
        self.interest_x, self.interest_y = interest
        self.focus_x, self.focus_y = focus
        self.patch_centers = patch_centers
        self.accessibility = accessibility
        self.global_edges, self.global_luminance = rgb_edges(global_rgb, GLOBAL_W, GLOBAL_H)
        self.patch_edges = []
        self.patch_luminance = []
        for patch in patches:
            edges, luminance = rgb_edges(patch, PATCH_W, PATCH_H)
            self.patch_edges.append(edges)
            self.patch_luminance.append(luminance)
        self.visual_elements = []
        self.visual_semantic_text = ""
        self.semantic_text = accessibility.text()
        semantic_normalized = "|".join(semantic_units(self.semantic_text))
        self.semantic_signature = hashlib.blake2s(semantic_normalized.encode("utf-8", "ignore"), digest_size=12).hexdigest()
        visual_sample = []
        combined_visual = self.global_luminance + self.global_edges
        stride = max(1, len(combined_visual) // 64)
        for index in range(0, len(combined_visual), stride):
            visual_sample.append(int(clamp(combined_visual[index], 0.0, 1.0) * 15.999))
            if len(visual_sample) >= 64:
                break
        self.visual_signature = hashlib.blake2s(bytes(visual_sample), digest_size=12).hexdigest()
        self.signature = self.semantic_signature + ":" + self.visual_signature
        control_counts = Counter(str(record.get("control_type", "")) for record in accessibility.records if record.get("control_type") and not record.get("offscreen"))
        control_shape = " ".join("{}{}".format(name, count) for name, count in sorted(control_counts.items()))
        focused = next((record for record in accessibility.records if record.get("focused")), None)
        focus_text = "" if focused is None else " ".join((str(focused.get("control_type", "")), str(focused.get("name", "")), str(focused.get("automation_id", ""))))
        semantic_tokens = semantic_units(self.semantic_text)
        self.fuzzy_key = " ".join(("window", accessibility.window_class, "controls", control_shape, "focus", focus_text, "tokens", " ".join(semantic_tokens)))
        self.any_password = any(record.get("password") for record in accessibility.records)
        visible_records = [record for record in accessibility.records if not record.get("offscreen") and record.get("enabled")]
        named_records = [record for record in visible_records if str(record.get("name", "")).strip() or str(record.get("value", "")).strip()]
        interactive_records = [record for record in visible_records if record.get("control_type") in INTERACTIVE_CONTROL_TYPES]
        self.uia_quality = clamp(len(named_records) / 12.0, 0.0, 1.0) * 0.55 + clamp(len(interactive_records) / 6.0, 0.0, 1.0) * 0.35 + (0.10 if accessibility.window_title else 0.0)
        self.perception_limited = self.uia_quality < 0.22

    def attach_visual_elements(self, elements):
        """把纯像素视觉元素作为 UIA 的补充结构合并进当前观察；UIA 文本始终优先保留。"""
        normalized = []
        for item in elements or []:
            if isinstance(item, VisualElement):
                element = item
            elif isinstance(item, dict):
                box = item.get("bbox") or [0.0, 0.0, 0.0, 0.0]
                if not isinstance(box, (list, tuple)) or len(box) < 4: continue
                element = VisualElement(
                    text=str(item.get("text", "")), role=str(item.get("role", "visual")),
                    bbox=tuple(clamp(safe_float(v), 0.0, 1.0) for v in box[:4]), confidence=clamp(safe_float(item.get("confidence", 0.0)), 0.0, 1.0),
                    source=str(item.get("source", "vision")), locator=dict(item.get("locator") or {}),
                )
            else:
                continue
            if element.source == "vision" and element.confidence >= 0.45:
                normalized.append(element)
        self.visual_elements = normalized
        self.visual_semantic_text = " ".join("{} {}".format(item.role, item.text).strip() for item in normalized if item.text or item.role)
        base = self.accessibility.text()
        self.semantic_text = (base + ("\nVISUAL: " + self.visual_semantic_text if self.visual_semantic_text else "")).strip()
        semantic_normalized = "|".join(semantic_units(self.semantic_text))
        self.semantic_signature = hashlib.blake2s(semantic_normalized.encode("utf-8", "ignore"), digest_size=12).hexdigest()
        self.signature = self.semantic_signature + ":" + self.visual_signature
        if sum(1 for item in normalized if item.confidence >= 0.70) >= 2:
            self.perception_limited = False
        return self

    @staticmethod
    def _rgb_stats(rgb):
        channels = [rgb[offset::3] for offset in range(3)]
        means = [sum(channel) / max(1, len(channel)) for channel in channels]
        deviations = []
        for channel, mean in zip(channels, means):
            deviations.append(math.sqrt(sum((value - mean) ** 2 for value in channel) / max(1, len(channel))))
        return means, deviations

    def control_points(self):
        result = []
        for record in self.accessibility.records:
            if record.get("offscreen") or not record.get("enabled"):
                continue
            x = clamp(float(record.get("x_norm", 0.5)), 0.0, 1.0)
            y = clamp(float(record.get("y_norm", 0.5)), 0.0, 1.0)
            result.append((x, y, record))
        return result

    def features(self):
        values = list(self.global_rgb) + list(self.global_edges)
        for patch, edges in zip(self.patches, self.patch_edges):
            values.extend(patch)
            values.extend(edges)
        ui_items = [self.accessibility.window_title, self.accessibility.window_class]
        for record in self.accessibility.records:
            flags = "enabled{} focus{} password{}".format(int(bool(record.get("enabled"))), int(bool(record.get("focused"))), int(bool(record.get("password"))))
            ui_items.append(" ".join((record.get("control_type", ""), record.get("name", ""), record.get("automation_id", ""), record.get("class_name", ""), record.get("help", ""), record.get("value", ""), flags)))
        values.extend(hashed_features(ui_items, UI_FEATURES))
        means, deviations = self._rgb_stats(self.global_rgb)
        extra = means + [clamp(value * 2.0, 0.0, 1.0) for value in deviations] + [sum(self.global_edges) / max(1, len(self.global_edges))]
        for patch, edges in zip(self.patches, self.patch_edges):
            patch_means, _ = self._rgb_stats(patch)
            extra.extend(patch_means + [sum(edges) / max(1, len(edges))])
        enabled_count = sum(1 for record in self.accessibility.records if record.get("enabled"))
        focused_count = sum(1 for record in self.accessibility.records if record.get("focused"))
        extra.extend([
            self.cursor_x, self.cursor_y, self.interest_x, self.interest_y, self.focus_x, self.focus_y,
            clamp(len(self.accessibility.records) / 12.0, 0.0, 1.0), clamp(len(self.semantic_text) / 512.0, 0.0, 1.0),
            1.0 if self.any_password else 0.0, 1.0 if self.accessibility.hwnd else 0.0,
            clamp(focused_count, 0.0, 1.0), enabled_count / max(1, len(self.accessibility.records)),
            1.0 if self.accessibility.window_title else 0.0,
        ])
        if len(extra) != OBS_EXTRA:
            raise ValueError("观察附加特征维度错误：{}".format(len(extra)))
        values.extend(extra)
        expected = GLOBAL_FEATURES + PATCH_FEATURES + UI_FEATURES + OBS_EXTRA
        if len(values) != expected:
            raise ValueError("视觉状态维度错误：{} != {}".format(len(values), expected))
        return [clamp(float(value), 0.0, 1.0) for value in values]

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        records = [record for record in self.accessibility.records if not record.get("offscreen")]
        records.sort(key=lambda record: (
            not bool(record.get("focused")),
            record.get("control_type") not in INTERACTIVE_CONTROL_TYPES,
            not bool(record.get("name")),
            int(record.get("depth", 0)),
        ))
        values = []
        # 自适应输入首先购买真正的高分辨率 ROI 视觉槽位，而不是只增加控件哈希数量。
        visual_budget = min(count, max(0, int(count * 0.55))) if self.roi_pyramid else 0
        if visual_budget:
            visual_values = []
            for item in self.roi_pyramid:
                rgb = list(item.get("rgb", []))
                width = max(1, int(item.get("width", 1))); height = max(1, int(item.get("height", 1)))
                if not rgb:
                    continue
                edges, luminance = rgb_edges(rgb, width, height)
                # 分块池化保留空间布局；分辨率越高，新增输入槽可编码越细的局部结构。
                tiles = max(1, int(math.sqrt(max(1, visual_budget // max(1, len(self.roi_pyramid))))))
                for row in range(tiles):
                    for col in range(tiles):
                        xs = range(int(col * width / tiles), max(int((col + 1) * width / tiles), int(col * width / tiles) + 1))
                        ys = range(int(row * height / tiles), max(int((row + 1) * height / tiles), int(row * height / tiles) + 1))
                        idx = [y * width + x for y in ys for x in xs if 0 <= x < width and 0 <= y < height]
                        if idx:
                            visual_values.extend((sum(luminance[i] for i in idx) / len(idx), sum(edges[i] for i in idx) / len(idx)))
                        if len(visual_values) >= visual_budget:
                            break
                    if len(visual_values) >= visual_budget:
                        break
                if len(visual_values) >= visual_budget:
                    break
            values.extend(normalize_state(visual_values, visual_budget))
        # 剩余槽位保存逐控件结构。
        control_budget = max(0, count - len(values))
        slot_width = 10
        slot_count = min(len(records), max(0, int(control_budget * 0.72) // slot_width))
        for record in records[:slot_count]:
            text_hash = hashlib.blake2s("|".join((
                str(record.get("control_type", "")), str(record.get("name", "")),
                str(record.get("automation_id", "")), str(record.get("class_name", "")), str(record.get("value", "")),
            )).encode("utf-8", "ignore"), digest_size=4).digest()
            values.extend([
                clamp(float(record.get("x_norm", 0.5)), 0.0, 1.0),
                clamp(float(record.get("y_norm", 0.5)), 0.0, 1.0),
                1.0 if record.get("enabled") else 0.0,
                1.0 if record.get("focused") else 0.0,
                1.0 if record.get("keyboard_focusable") else 0.0,
                1.0 if record.get("password") else 0.0,
                1.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 0.0,
                clamp(int(record.get("depth", 0)) / 12.0, 0.0, 1.0),
                int.from_bytes(text_hash[:2], "little") / 65535.0,
                int.from_bytes(text_hash[2:], "little") / 65535.0,
            ])
        remaining = max(0, count - len(values))
        if remaining:
            # 注意力式池化：焦点/可交互控件重复加权，保留“集合”信息而不是依赖固定顺序。
            pooled = []
            for record in records:
                text = " ".join((record.get("control_type", ""), record.get("name", ""), record.get("automation_id", ""), record.get("value", "")))
                weight = 1 + int(bool(record.get("focused"))) * 3 + int(record.get("control_type") in INTERACTIVE_CONTROL_TYPES) * 2
                pooled.extend([text] * weight)
            values.extend(hashed_features(pooled, remaining))
        return normalize_state(values, count)


class InputGateClosed(OSError):
    pass


class SharedInputGate:
    """跨线程/跨进程硬输入闸门 + 主进程 generation 租约。旧 worker 即使残留，也无法跨会话 SendInput。"""
    def __init__(self, closed_event=None, lock=None, stop_event=None, pause_event=None, generation_value=None, expected_generation=None):
        self.closed_event = closed_event
        self.lock = lock
        self.stop_event = stop_event
        self.pause_event = pause_event
        self.generation_value = generation_value
        self.expected_generation = None if expected_generation is None else int(expected_generation)

    def generation_matches(self):
        if self.generation_value is None or self.expected_generation is None:
            return True
        try:
            return int(self.generation_value.value) == int(self.expected_generation) and int(self.expected_generation) != 0
        except Exception:
            return False

    def is_closed(self):
        return bool(
            (self.closed_event is not None and self.closed_event.is_set())
            or (self.pause_event is not None and self.pause_event.is_set())
            or (self.stop_event is not None and self.stop_event.is_set())
            or not self.generation_matches()
        )

    def _close_unlocked(self):
        matches = self.generation_matches()
        if self.closed_event is not None:
            self.closed_event.set()
        if self.stop_event is not None:
            self.stop_event.set()
        # 只有仍持有当前主进程租约的会话才能使共享 generation 失效；旧 worker 不能误杀新会话。
        if self.generation_value is not None and (self.expected_generation is None or matches):
            try:
                self.generation_value.value = 0
            except Exception:
                pass

    def close(self):
        if self.lock is None:
            self._close_unlocked()
            return
        with self.lock:
            self._close_unlocked()

    def run_if_open(self, callback):
        if self.lock is None:
            if self.is_closed():
                raise InputGateClosed("输入闸门已关闭/暂停或 generation 租约已失效")
            return callback()
        with self.lock:
            if self.is_closed():
                raise InputGateClosed("输入闸门已关闭/暂停或 generation 租约已失效")
            # generation 检查和真正 SendInput 在同一把跨会话锁内，主进程切代后旧 worker 没有 TOCTOU 窗口。
            return callback()


class WinIO:
    VK_ESCAPE = 0x1B
    VK_SHIFT = 0x10
    VK_CONTROL = 0x11
    VK_MENU = 0x12
    INPUT_MOUSE = 0
    INPUT_KEYBOARD = 1
    KEYEVENTF_EXTENDEDKEY = 0x0001
    KEYEVENTF_KEYUP = 0x0002
    KEYEVENTF_UNICODE = 0x0004
    MOUSEEVENTF_MOVE = 0x0001
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    MOUSEEVENTF_RIGHTDOWN = 0x0008
    MOUSEEVENTF_RIGHTUP = 0x0010
    MOUSEEVENTF_WHEEL = 0x0800
    MOUSEEVENTF_VIRTUALDESK = 0x4000
    MOUSEEVENTF_ABSOLUTE = 0x8000
    SRCCOPY = 0x00CC0020
    DIB_RGB_COLORS = 0
    HALFTONE = 4
    DESKTOP_READOBJECTS = 0x0001
    DESKTOP_SWITCHDESKTOP = 0x0100
    UOI_NAME = 2
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

    def __init__(self, capacities=None, input_enabled=True, input_gate_event=None, input_pause_event=None, input_gate_lock=None, stop_event=None, send_input_adapter=None, resource_budget=None, generation_value=None, expected_generation=None):
        if os.name != "nt":
            raise OSError("仅支持 Windows")
        self.capacities = dict(capacities or {})
        self.input_enabled = bool(input_enabled)
        self.input_gate = SharedInputGate(input_gate_event, input_gate_lock, stop_event, pause_event=input_pause_event, generation_value=generation_value, expected_generation=expected_generation)
        self._send_input_adapter = send_input_adapter
        self.resource_budget = resource_budget
        self.user32 = ctypes.WinDLL("user32", use_last_error=True)
        self.gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self._desktop_cache = (0.0, False, "unknown")
        self._parent_cache = {}
        self._last_full_scan_at = 0.0
        self._last_event_probe_at = 0.0
        self.last_capture_seconds = 0.0
        self.last_uia_seconds = 0.0
        self.last_capture_cache_hit = False
        self.capture_cache_hits = 0
        self.capture_full_scans = 0
        self.event_cache_hits = 0
        self.local_action_scans = 0
        self._configure_functions()
        self.left = self.user32.GetSystemMetrics(76)
        self.top = self.user32.GetSystemMetrics(77)
        self.width = max(1, self.user32.GetSystemMetrics(78) or self.user32.GetSystemMetrics(0))
        self.height = max(1, self.user32.GetSystemMetrics(79) or self.user32.GetSystemMetrics(1))
        self.last_interest = (self.left + self.width // 2, self.top + self.height // 2)
        self.accessibility = AccessibilityReader(self.user32, self.capacities.get("uia_depth", 4), self.capacities.get("uia_nodes", 128))
        self.set_capacities(self.capacities)

    def set_capacities(self, capacities):
        self.capacities = dict(capacities or {})
        if self.resource_budget is not None:
            self.resource_budget.refresh(perception_latency=self.last_capture_seconds)
            learned_scale = max(1, int(self.capacities.get("visual_roi_scale", 1)))
            self.capacities["visual_roi_scale"] = min(learned_scale, self.resource_budget.visual_roi_scale())
        self.accessibility.set_capacity(self.capacities.get("uia_depth", 4), self.capacities.get("uia_nodes", 128))

    def _configure_functions(self):
        self.user32.GetSystemMetrics.argtypes = [ctypes.c_int]
        self.user32.GetSystemMetrics.restype = ctypes.c_int
        self.user32.GetDC.argtypes = [wintypes.HWND]
        self.user32.GetDC.restype = wintypes.HDC
        self.user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        self.user32.ReleaseDC.restype = ctypes.c_int
        self.user32.GetCursorPos.argtypes = [ctypes.POINTER(Point)]
        self.user32.GetCursorPos.restype = wintypes.BOOL
        self.user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        self.user32.GetAsyncKeyState.restype = ctypes.c_short
        self.user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        self.user32.SendInput.restype = wintypes.UINT
        self.user32.GetForegroundWindow.restype = wintypes.HWND
        self.user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetWindowTextW.restype = ctypes.c_int
        self.user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        self.user32.GetClassNameW.restype = ctypes.c_int
        self.user32.GetGUIThreadInfo.argtypes = [wintypes.DWORD, ctypes.POINTER(GuiThreadInfo)]
        self.user32.GetGUIThreadInfo.restype = wintypes.BOOL
        self.user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        self.user32.OpenInputDesktop.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.user32.OpenInputDesktop.restype = wintypes.HANDLE
        self.user32.CloseDesktop.argtypes = [wintypes.HANDLE]
        self.user32.CloseDesktop.restype = wintypes.BOOL
        self.user32.GetUserObjectInformationW.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
        self.user32.GetUserObjectInformationW.restype = wintypes.BOOL
        self.user32.IsWindow.argtypes = [wintypes.HWND]
        self.user32.IsWindow.restype = wintypes.BOOL
        self.user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]
        self.user32.GetWindow.restype = wintypes.HWND
        self.kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        self.kernel32.OpenProcess.restype = wintypes.HANDLE
        self.kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        self.kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.kernel32.CloseHandle.restype = wintypes.BOOL
        self.kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        self.kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        self.kernel32.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry32W)]
        self.kernel32.Process32FirstW.restype = wintypes.BOOL
        self.kernel32.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry32W)]
        self.kernel32.Process32NextW.restype = wintypes.BOOL
        self.user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(Point)]
        self.user32.ClientToScreen.restype = wintypes.BOOL
        self.gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
        self.gdi32.CreateCompatibleDC.restype = wintypes.HDC
        self.gdi32.DeleteDC.argtypes = [wintypes.HDC]
        self.gdi32.DeleteDC.restype = wintypes.BOOL
        self.gdi32.CreateCompatibleBitmap.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        self.gdi32.CreateCompatibleBitmap.restype = wintypes.HBITMAP
        self.gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
        self.gdi32.SelectObject.restype = wintypes.HGDIOBJ
        self.gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
        self.gdi32.DeleteObject.restype = wintypes.BOOL
        self.gdi32.SetStretchBltMode.argtypes = [wintypes.HDC, ctypes.c_int]
        self.gdi32.SetStretchBltMode.restype = ctypes.c_int
        self.gdi32.StretchBlt.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.DWORD]
        self.gdi32.StretchBlt.restype = wintypes.BOOL
        self.gdi32.GetDIBits.argtypes = [wintypes.HDC, wintypes.HBITMAP, wintypes.UINT, wintypes.UINT, ctypes.c_void_p, ctypes.POINTER(BitmapInfo), wintypes.UINT]
        self.gdi32.GetDIBits.restype = ctypes.c_int

    @staticmethod
    def desktop_name_is_safe(name):
        return str(name or "").strip().lower() == "default"

    def input_desktop_status(self, force=False):
        now = time.monotonic()
        cached_at, cached_safe, cached_name = self._desktop_cache
        if not force and now - cached_at < 0.05:
            return cached_safe, cached_name
        desktop = self.user32.OpenInputDesktop(0, False, self.DESKTOP_READOBJECTS | self.DESKTOP_SWITCHDESKTOP)
        if not desktop:
            self._desktop_cache = (now, False, "unavailable")
            return False, "unavailable"
        try:
            needed = wintypes.DWORD(0)
            self.user32.GetUserObjectInformationW(desktop, self.UOI_NAME, None, 0, ctypes.byref(needed))
            count = max(64, int(needed.value // ctypes.sizeof(ctypes.c_wchar) + 2))
            buffer = ctypes.create_unicode_buffer(count)
            if not self.user32.GetUserObjectInformationW(desktop, self.UOI_NAME, buffer, ctypes.sizeof(buffer), ctypes.byref(needed)):
                safe, name = False, "unknown"
            else:
                name = str(buffer.value or "unknown")
                safe = self.desktop_name_is_safe(name)
        finally:
            self.user32.CloseDesktop(desktop)
        self._desktop_cache = (now, safe, name)
        return safe, name

    def _parent_process_id(self, process_id):
        process_id = int(process_id or 0)
        now = time.monotonic()
        cached = self._parent_cache.get(process_id)
        if cached and now - cached[0] < 2.0:
            return int(cached[1])
        parent = 0
        snapshot = self.kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        invalid = ctypes.c_void_p(-1).value
        if snapshot and int(snapshot) != int(invalid):
            try:
                entry = ProcessEntry32W()
                entry.dwSize = ctypes.sizeof(ProcessEntry32W)
                ok = bool(self.kernel32.Process32FirstW(snapshot, ctypes.byref(entry)))
                while ok:
                    if int(entry.th32ProcessID) == process_id:
                        parent = int(entry.th32ParentProcessID)
                        break
                    ok = bool(self.kernel32.Process32NextW(snapshot, ctypes.byref(entry)))
            finally:
                self.kernel32.CloseHandle(snapshot)
        self._parent_cache[process_id] = (now, parent)
        return parent

    def foreground_context(self):
        hwnd = int(self.user32.GetForegroundWindow() or 0)
        pid = wintypes.DWORD(0)
        if hwnd:
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        title_buffer = ctypes.create_unicode_buffer(512)
        class_buffer = ctypes.create_unicode_buffer(256)
        if hwnd:
            self.user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
            self.user32.GetClassNameW(hwnd, class_buffer, len(class_buffer))
        process_path = ""
        if pid.value:
            handle = self.kernel32.OpenProcess(self.PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
            if handle:
                try:
                    size = wintypes.DWORD(2048)
                    buffer = ctypes.create_unicode_buffer(size.value)
                    if self.kernel32.QueryFullProcessImageNameW(handle, 0, buffer, ctypes.byref(size)):
                        process_path = buffer.value
                finally:
                    self.kernel32.CloseHandle(handle)
        safe_desktop, desktop_name = self.input_desktop_status()
        owner_hwnd = int(self.user32.GetWindow(hwnd, 4) or 0) if hwnd else 0
        return {
            "hwnd": hwnd, "process_id": int(pid.value), "process_path": process_path,
            "process_name": os.path.basename(process_path).lower() if process_path else "",
            "window_title": title_buffer.value, "window_class": class_buffer.value,
            "desktop_name": desktop_name, "desktop_safe": bool(safe_desktop),
            "parent_process_id": self._parent_process_id(pid.value), "owner_hwnd": owner_hwnd,
        }

    def input_allowed(self):
        safe, _ = self.input_desktop_status(force=True)
        return bool(safe)

    def close(self):
        self.accessibility.close()

    def close_input_gate(self):
        self.input_gate.close()

    def pause_normal_input(self):
        """睡眠期临时暂停正常 SendInput；不设置 stop_event，也不作废 generation。"""
        lock = self.input_gate.lock
        def pause():
            if self.input_gate.pause_event is not None:
                self.input_gate.pause_event.set()
        if lock is None:
            pause()
        else:
            with lock:
                pause()
        self.release_inputs()

    def resume_normal_input(self):
        """仅在调用方完成完整 P0 醒来复验后重新开放临时暂停闸门。"""
        lock = self.input_gate.lock
        def resume():
            if self.input_gate.closed_event is not None and self.input_gate.closed_event.is_set():
                raise InputGateClosed("永久 input gate 已关闭，禁止重新开放")
            if self.input_gate.stop_event is not None and self.input_gate.stop_event.is_set():
                raise InputGateClosed("stop_event 已设置，禁止重新开放")
            if not self.input_gate.generation_matches():
                raise InputGateClosed("generation 租约无效，禁止重新开放")
            if self.input_gate.pause_event is not None:
                self.input_gate.pause_event.clear()
        if lock is None:
            resume()
        else:
            with lock:
                resume()

    def seal_input_gate(self):
        """任务完成时永久封住本会话输入租约，但不触发 ESC/停止事件，便于做毫秒级必要提交后正常退出。"""
        lock = self.input_gate.lock
        def seal():
            if self.input_gate.closed_event is not None:
                self.input_gate.closed_event.set()
            if self.input_gate.generation_value is not None:
                try: self.input_gate.generation_value.value = 0
                except Exception: pass
        if lock is None:
            seal()
        else:
            with lock: seal()

    def input_gate_closed(self):
        return self.input_gate.is_closed()

    def escape_down(self):
        return bool(self.user32.GetAsyncKeyState(self.VK_ESCAPE) & 0x8000)

    def wait_escape_release(self, stop_event):
        while self.escape_down() and not stop_event.wait(0.025):
            pass

    def cursor_pixels(self):
        point = Point()
        if not self.user32.GetCursorPos(ctypes.byref(point)):
            return self.left + self.width // 2, self.top + self.height // 2
        return int(point.x), int(point.y)

    def normalize_point(self, point):
        return (
            clamp((point[0] - self.left) / max(1, self.width - 1), 0.0, 1.0),
            clamp((point[1] - self.top) / max(1, self.height - 1), 0.0, 1.0),
        )

    def denormalize_point(self, x, y):
        return self.left + int(clamp(x, 0.0, 1.0) * (self.width - 1)), self.top + int(clamp(y, 0.0, 1.0) * (self.height - 1))

    def focus_pixels(self):
        foreground = self.user32.GetForegroundWindow()
        if not foreground:
            return self.cursor_pixels()
        thread_id = self.user32.GetWindowThreadProcessId(foreground, None)
        info = GuiThreadInfo()
        info.cbSize = ctypes.sizeof(GuiThreadInfo)
        if thread_id and self.user32.GetGUIThreadInfo(thread_id, ctypes.byref(info)) and info.hwndCaret:
            point = Point((info.rcCaret.left + info.rcCaret.right) // 2, (info.rcCaret.top + info.rcCaret.bottom) // 2)
            if self.user32.ClientToScreen(info.hwndCaret, ctypes.byref(point)):
                return int(point.x), int(point.y)
        return self.cursor_pixels()

    def _capture_scaled(self, left, top, source_width, source_height, target_width, target_height):
        screen_dc = self.user32.GetDC(None)
        if not screen_dc:
            raise OSError("无法读取屏幕")
        memory_dc = self.gdi32.CreateCompatibleDC(screen_dc)
        bitmap = self.gdi32.CreateCompatibleBitmap(screen_dc, target_width, target_height)
        if not memory_dc or not bitmap:
            if memory_dc:
                self.gdi32.DeleteDC(memory_dc)
            self.user32.ReleaseDC(None, screen_dc)
            raise OSError("无法创建屏幕采样缓冲区")
        old = self.gdi32.SelectObject(memory_dc, bitmap)
        try:
            self.gdi32.SetStretchBltMode(memory_dc, self.HALFTONE)
            if not self.gdi32.StretchBlt(memory_dc, 0, 0, target_width, target_height, screen_dc, int(left), int(top), int(source_width), int(source_height), self.SRCCOPY):
                raise OSError("屏幕缩放采样失败")
            info = BitmapInfo()
            info.bmiHeader.biSize = ctypes.sizeof(BitmapInfoHeader)
            info.bmiHeader.biWidth = target_width
            info.bmiHeader.biHeight = -target_height
            info.bmiHeader.biPlanes = 1
            info.bmiHeader.biBitCount = 32
            info.bmiHeader.biCompression = 0
            buffer = (ctypes.c_ubyte * (target_width * target_height * 4))()
            rows = self.gdi32.GetDIBits(memory_dc, bitmap, 0, target_height, ctypes.byref(buffer), ctypes.byref(info), self.DIB_RGB_COLORS)
            if rows != target_height:
                raise OSError("屏幕像素读取失败")
            pixels = []
            for index in range(0, len(buffer), 4):
                pixels.extend((buffer[index + 2] / 255.0, buffer[index + 1] / 255.0, buffer[index] / 255.0))
            return pixels
        finally:
            if old:
                self.gdi32.SelectObject(memory_dc, old)
            self.gdi32.DeleteObject(bitmap)
            self.gdi32.DeleteDC(memory_dc)
            self.user32.ReleaseDC(None, screen_dc)

    def _interest_from_change(self, rgb, previous):
        _, luminance = rgb_edges(rgb, GLOBAL_W, GLOBAL_H)
        if previous is None or len(previous.global_luminance) != len(luminance):
            return self.cursor_pixels()
        best_score = -1.0
        best_column = GLOBAL_W // 2
        best_row = GLOBAL_H // 2
        for row in range(GLOBAL_H):
            for column in range(GLOBAL_W):
                index = row * GLOBAL_W + column
                score = abs(luminance[index] - previous.global_luminance[index])
                if column + 1 < GLOBAL_W:
                    score += abs(luminance[index] - luminance[index + 1]) * 0.28
                if row + 1 < GLOBAL_H:
                    score += abs(luminance[index] - luminance[index + GLOBAL_W]) * 0.28
                if score > best_score:
                    best_score, best_column, best_row = score, column, row
        x = self.left + int((best_column + 0.5) * self.width / GLOBAL_W)
        y = self.top + int((best_row + 0.5) * self.height / GLOBAL_H)
        if best_score < 0.025:
            cursor = self.cursor_pixels()
            x = int(cursor[0] * 0.72 + self.last_interest[0] * 0.28)
            y = int(cursor[1] * 0.72 + self.last_interest[1] * 0.28)
        self.last_interest = (x, y)
        return x, y

    def capture(self, previous=None, force_deep=False, action_hint=None, require_probe=False):
        """事件优先感知。静默期复用；动作后先查局部目标/UIA，只有验证失败才升级全屏+深 UIA。"""
        started = time.perf_counter()
        cursor = self.cursor_pixels()
        focus = self.focus_pixels()
        focus_norm = self.normalize_point(focus)
        context = self.foreground_context()
        now_mono = time.monotonic()
        cache_seconds = max(0.02, int(self.capacities.get("observation_cache_ms", 120)) / 1000.0)
        same_window = bool(
            previous is not None
            and int(getattr(previous.accessibility, "hwnd", 0) or 0) == int(context.get("hwnd", 0) or 0)
            and int(getattr(previous, "process_id", 0) or 0) == int(context.get("process_id", 0) or 0)
            and str(getattr(previous.accessibility, "window_title", "") or "") == str(context.get("window_title", "") or "")
            and str(getattr(previous.accessibility, "window_class", "") or "") == str(context.get("window_class", "") or "")
        )
        focus_stable = bool(previous is not None and math.hypot(focus_norm[0] - previous.focus_x, focus_norm[1] - previous.focus_y) < 0.004)

        def finish(observation, regions=None, visual_change=0.0, cache_hit=False):
            # 与 WinIO.normalize_point() 使用同一个虚拟桌面坐标系；左/上副屏可为负数。
            observation.screen_left = self.left
            observation.screen_top = self.top
            observation.screen_width = self.width
            observation.screen_height = self.height
            observation.regions = list(regions or getattr(previous, "regions", []) or [])
            observation.process_id = context.get("process_id", 0)
            observation.process_path = context.get("process_path", "")
            observation.process_name = context.get("process_name", "")
            observation.parent_process_id = context.get("parent_process_id", 0)
            observation.owner_hwnd = context.get("owner_hwnd", 0)
            observation.input_desktop_name = context.get("desktop_name", "unknown")
            observation.input_desktop_safe = bool(context.get("desktop_safe", False))
            observation.capture_cache_hit = bool(cache_hit)
            observation.visual_change = float(visual_change)
            self.last_capture_cache_hit = bool(cache_hit)
            self.last_capture_seconds = time.perf_counter() - started
            return observation

        # HWND/标题/焦点/前景进程都没变化且刚做过事件探测时，完全跳过截图和 UIA。
        quiet_reuse = bool(
            previous is not None and same_window and focus_stable and not force_deep and action_hint is None and not require_probe
            and self._last_event_probe_at > 0 and now_mono - self._last_event_probe_at <= min(cache_seconds, 0.10)
        )
        if quiet_reuse:
            self.last_uia_seconds = 0.0
            self.capture_cache_hits += 1
            self.event_cache_hits += 1
            observation = Observation(
                list(previous.global_rgb), [list(patch) for patch in previous.patches], self.normalize_point(cursor),
                (previous.interest_x, previous.interest_y), focus_norm, list(previous.patch_centers), previous.accessibility,
                roi_pyramid=list(getattr(previous, "roi_pyramid", []) or []),
            )
            return finish(observation, visual_change=0.0, cache_hit=True)

        def record_state(record):
            return (
                str(record.get("name", "")), str(record.get("value", "")), bool(record.get("enabled")),
                tuple(record.get("bounding_rectangle") or ()), str(record.get("automation_id", "")),
                str(record.get("control_type", "")), bool(record.get("offscreen")),
            )

        previous_map = {}
        previous_focused = None
        if previous is not None:
            previous_map = {self.accessibility._record_key(record): record_state(record) for record in previous.accessibility.records}
            previous_focused = next((self.accessibility._record_key(record) for record in previous.accessibility.records if record.get("focused")), None)

        # 动作后局部验证：优先目标控件/焦点附近，不先做全屏截图。
        if previous is not None and same_window and action_hint is not None and not force_deep:
            params = dict(getattr(action_hint, "parameters", {}) or {})
            kind = int(getattr(action_hint, "kind", WAIT))
            if kind in (MOVE, CLICK) and "x" in params and "y" in params:
                target = self.denormalize_point(safe_float(params.get("x", 0.5), 0.5), safe_float(params.get("y", 0.5), 0.5))
            else:
                target = focus
            patch_width = min(self.width, max(300, int(self.width * 0.30)))
            patch_height = min(self.height, max(200, int(self.height * 0.30)))
            local_left = int(clamp(target[0] - patch_width // 2, self.left, self.left + self.width - patch_width))
            local_top = int(clamp(target[1] - patch_height // 2, self.top, self.top + self.height - patch_height))
            local_patch = self._capture_scaled(local_left, local_top, patch_width, patch_height, PATCH_W, PATCH_H)
            nearest_index = None
            nearest_distance = 9.0
            tx, ty = self.normalize_point(target)
            for index, center in enumerate(previous.patch_centers):
                distance = math.hypot(float(center[0]) - tx, float(center[1]) - ty)
                if distance < nearest_distance:
                    nearest_distance, nearest_index = distance, index
            baseline = None
            if nearest_index is not None and nearest_distance <= 0.18 and nearest_index < len(previous.patches):
                baseline = previous.patches[nearest_index]
            local_change = 1.0 if baseline is None else sum(abs(float(a) - float(b)) for a, b in zip(local_patch, baseline)) / max(1, len(local_patch))
            uia_started = time.perf_counter()
            shallow = self.accessibility.snapshot([cursor, target, focus], focus, deep=False)
            self._last_event_probe_at = time.monotonic()
            for record in shallow.records:
                record["x_norm"], record["y_norm"] = self.normalize_point((record.get("x", cursor[0]), record.get("y", cursor[1])))
            shallow_focused = next((self.accessibility._record_key(record) for record in shallow.records if record.get("focused")), None)
            structure_changed = any(
                self.accessibility._record_key(record) not in previous_map
                or previous_map[self.accessibility._record_key(record)] != record_state(record)
                for record in shallow.records
            )
            locator = dict(params.get("target") or {}) if kind == CLICK else {}
            locator_ok = True
            if locator:
                locator_ok = any(locator_score(locator, record) >= 1.0 for record in shallow.records)
            local_evidence = bool(local_change >= 0.004 or structure_changed or shallow_focused != previous_focused)
            self.last_uia_seconds = time.perf_counter() - uia_started
            if baseline is not None and len(shallow.records) >= 2 and locator_ok and local_evidence:
                # 用浅 UIA 更新旧树中命中的节点，保留未触及区域；避免浅扫描本身造成“整棵树消失”的假变化。
                merged = {self.accessibility._record_key(record): dict(record) for record in previous.accessibility.records}
                for record in shallow.records:
                    merged[self.accessibility._record_key(record)] = dict(record)
                snapshot = AccessibilitySnapshot(
                    hwnd=int(shallow.hwnd or previous.accessibility.hwnd),
                    window_title=str(shallow.window_title or previous.accessibility.window_title),
                    window_class=str(shallow.window_class or previous.accessibility.window_class),
                    records=list(merged.values())[:max(len(previous.accessibility.records), int(self.capacities.get("uia_nodes", 128)))],
                )
                patches = [list(patch) for patch in previous.patches]
                centers = list(previous.patch_centers)
                regions = [dict(item) for item in (getattr(previous, "regions", []) or [])]
                if nearest_index is not None:
                    patches[nearest_index] = local_patch
                    centers[nearest_index] = (tx, ty)
                    if nearest_index < len(regions):
                        regions[nearest_index] = {"left": local_left, "top": local_top, "width": patch_width, "height": patch_height, "center": (tx, ty)}
                observation = Observation(
                    list(previous.global_rgb), patches, self.normalize_point(cursor), (tx, ty), focus_norm, centers, snapshot,
                    roi_pyramid=list(getattr(previous, "roi_pyramid", []) or []),
                )
                self.local_action_scans += 1
                return finish(observation, regions=regions, visual_change=local_change * 0.35, cache_hit=False)
            # 局部没有足够变化/目标消失/无可比基线 => 验证失败，升级全屏与深 UIA。
            force_deep = True

        global_rgb = self._capture_scaled(self.left, self.top, self.width, self.height, GLOBAL_W, GLOBAL_H)
        interest = self._interest_from_change(global_rgb, previous)
        previous_rgb = list(getattr(previous, "global_rgb", []) or [])
        visual_change = 1.0
        if previous_rgb and len(previous_rgb) == len(global_rgb):
            visual_change = sum(abs(float(left) - float(right)) for left, right in zip(previous_rgb, global_rgb)) / len(global_rgb)
        cache_fresh = now_mono - self._last_full_scan_at <= cache_seconds
        cache_hit = bool(previous is not None and same_window and focus_stable and visual_change < 0.0025 and cache_fresh and not force_deep)
        probe_points = [cursor, interest, focus]

        uia_started = time.perf_counter()
        shallow = self.accessibility.snapshot(probe_points, focus, deep=False)
        self._last_event_probe_at = time.monotonic()
        for record in shallow.records:
            record["x_norm"], record["y_norm"] = self.normalize_point((record.get("x", cursor[0]), record.get("y", cursor[1])))
        shallow_focused = next((self.accessibility._record_key(record) for record in shallow.records if record.get("focused")), None)
        structure_changed = False
        if previous is not None:
            for record in shallow.records:
                key = self.accessibility._record_key(record)
                if key not in previous_map or previous_map[key] != record_state(record):
                    structure_changed = True
                    break
        anomaly = bool(
            force_deep or previous is None or not same_window or not focus_stable or visual_change >= 0.006
            or len(shallow.records) < 2 or shallow_focused != previous_focused or structure_changed
        )
        patches = None
        regions = None
        selected = None
        roi_pyramid = []
        if anomaly:
            snapshot = self.accessibility.snapshot(probe_points, focus, deep=True)
            self._last_full_scan_at = time.monotonic()
            self.capture_full_scans += 1
        else:
            snapshot = previous.accessibility
            if cache_hit:
                patches = [list(patch) for patch in previous.patches]
                regions = [dict(item) for item in (getattr(previous, "regions", []) or [])]
                selected = [self.denormalize_point(x, y) for x, y in previous.patch_centers]
                roi_pyramid = list(getattr(previous, "roi_pyramid", []) or [])
                self.capture_cache_hits += 1
        self.last_uia_seconds = time.perf_counter() - uia_started

        for record in snapshot.records:
            record["x_norm"], record["y_norm"] = self.normalize_point((record.get("x", cursor[0]), record.get("y", cursor[1])))
        if selected is None:
            candidates = [(focus, 4.0), (interest, 3.0), (cursor, 2.0)]
            breadth = max(3, int(self.capacities.get("attention_candidates", 8)))
            for record in snapshot.records[:breadth]:
                if record.get("offscreen") or not record.get("enabled") or not record.get("bounding_rectangle"):
                    continue
                score = 1.0 + (4.0 if record.get("focused") else 0.0) + (2.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 0.0) + (0.5 if record.get("name") else 0.0)
                candidates.append(((int(record.get("x", cursor[0])), int(record.get("y", cursor[1]))), score))
            selected = []
            for point, score in sorted(candidates, key=lambda item: item[1], reverse=True):
                if all(math.hypot(point[0] - other[0], point[1] - other[1]) > max(50, min(self.width, self.height) * 0.06) for other in selected):
                    selected.append(point)
                if len(selected) >= PATCH_COUNT:
                    break
            while len(selected) < PATCH_COUNT:
                selected.append(probe_points[len(selected) % len(probe_points)])

        if patches is None:
            patches, regions = [], []
            patch_width = min(self.width, max(300, int(self.width * 0.30)))
            patch_height = min(self.height, max(200, int(self.height * 0.30)))
            for center in selected:
                left = int(clamp(center[0] - patch_width // 2, self.left, self.left + self.width - patch_width))
                top = int(clamp(center[1] - patch_height // 2, self.top, self.top + self.height - patch_height))
                patches.append(self._capture_scaled(left, top, patch_width, patch_height, PATCH_W, PATCH_H))
                regions.append({"left": left, "top": top, "width": patch_width, "height": patch_height, "center": self.normalize_point(center)})
                requested_scale = max(1, int(self.capacities.get("visual_roi_scale", 2)))
                for scale in range(2, requested_scale + 1):
                    rw, rh = PATCH_W * scale, PATCH_H * scale
                    roi_pyramid.append({"rgb": self._capture_scaled(left, top, patch_width, patch_height, rw, rh), "width": rw, "height": rh, "scale": scale, "center": self.normalize_point(center)})
        observation = Observation(
            global_rgb, patches, self.normalize_point(cursor), self.normalize_point(interest), focus_norm,
            [self.normalize_point(point) for point in selected], snapshot, roi_pyramid=roi_pyramid,
        )
        return finish(observation, regions=regions, visual_change=visual_change, cache_hit=cache_hit and not anomaly)

    def capture_reasoning_frame(self, observation=None, tier="full", max_width=960, max_height=540):
        """按需采样视觉帧：ROI 优先，仍不足才发缩放全屏；坐标元数据始终映射到全屏 0..1。"""
        tier = "roi" if str(tier).lower() == "roi" else "full"
        left, top, source_width, source_height = self.left, self.top, self.width, self.height
        if tier == "roi" and observation is not None:
            cx = safe_float(getattr(observation, "focus_x", getattr(observation, "interest_x", 0.5)), 0.5)
            cy = safe_float(getattr(observation, "focus_y", getattr(observation, "interest_y", 0.5)), 0.5)
            if not (0.02 <= cx <= 0.98 and 0.02 <= cy <= 0.98):
                cx = safe_float(getattr(observation, "interest_x", 0.5), 0.5); cy = safe_float(getattr(observation, "interest_y", 0.5), 0.5)
            source_width = max(320, min(self.width, int(self.width * 0.46)))
            source_height = max(220, min(self.height, int(self.height * 0.46)))
            center_x = self.left + int(clamp(cx, 0.0, 1.0) * self.width)
            center_y = self.top + int(clamp(cy, 0.0, 1.0) * self.height)
            left = int(clamp(center_x - source_width // 2, self.left, self.left + self.width - source_width))
            top = int(clamp(center_y - source_height // 2, self.top, self.top + self.height - source_height))
            max_width = min(int(max_width), 640); max_height = min(int(max_height), 360)
        width = max(160, min(int(max_width), int(source_width)))
        height = max(90, int(round(width * source_height / max(1, source_width))))
        if height > int(max_height):
            height = int(max_height); width = max(160, int(round(height * source_width / max(1, source_height))))
        viewport = [
            clamp((left - self.left) / max(1.0, float(self.width)), 0.0, 1.0),
            clamp((top - self.top) / max(1.0, float(self.height)), 0.0, 1.0),
            clamp((left + source_width - self.left) / max(1.0, float(self.width)), 0.0, 1.0),
            clamp((top + source_height - self.top) / max(1.0, float(self.height)), 0.0, 1.0),
        ]
        return {
            "rgb": self._capture_scaled(left, top, source_width, source_height, width, height),
            "width": width, "height": height, "tier": tier, "viewport": viewport,
        }

    def capture_target_probe(self, x_norm, y_norm, width=64, height=48):
        """本地点击证据探针；不调用远程模型，用两帧像素稳定性拒绝漂移/动画目标。"""
        cx = self.left + int(clamp(safe_float(x_norm, 0.5), 0.0, 1.0) * self.width)
        cy = self.top + int(clamp(safe_float(y_norm, 0.5), 0.0, 1.0) * self.height)
        source_width = max(96, min(self.width, int(self.width * 0.10)))
        source_height = max(72, min(self.height, int(self.height * 0.10)))
        left = int(clamp(cx - source_width // 2, self.left, self.left + self.width - source_width))
        top = int(clamp(cy - source_height // 2, self.top, self.top + self.height - source_height))
        return self._capture_scaled(left, top, source_width, source_height, int(width), int(height))

    def _raw_send(self, input_value):
        if self._send_input_adapter is not None:
            return self._send_input_adapter(input_value)
        return self.user32.SendInput(1, ctypes.byref(input_value), ctypes.sizeof(Input))

    def _send(self, input_value, expected_hwnd=0):
        if not self.input_enabled:
            raise OSError("只观察模式禁止 SendInput")
        def perform():
            # Hard input gate、Secure Desktop 与前台 HWND 校验和真正 SendInput 位于同一临界区。
            safe, desktop_name = self.input_desktop_status(force=True)
            if not safe:
                raise OSError("输入桌面不可确认或已进入 Secure Desktop（{}），已 fail-closed 禁止 SendInput".format(desktop_name))
            if expected_hwnd and int(self.user32.GetForegroundWindow() or 0) != int(expected_hwnd):
                raise OSError("前台窗口已改变：SendInput 最后一刻 HWND 校验失败")
            if self._raw_send(input_value) != 1:
                raise OSError("SendInput 失败")
            return True
        return self.input_gate.run_if_open(perform)

    def _send_release(self, input_value):
        # emergency release 只允许 KEYUP / BUTTONUP，由异常/停止路径用于避免按键或鼠标卡住；它不代表 AI 继续活动。
        if not self.input_enabled:
            return False
        safe, _ = self.input_desktop_status(force=True)
        if not safe:
            return False
        return self._raw_send(input_value) == 1

    def _mouse_input(self, flags, x=0, y=0, data=0):
        value = Input()
        value.type = self.INPUT_MOUSE
        value.mi = MouseInput(int(x), int(y), ctypes.c_ulong(int(data)).value, int(flags), 0, 0)
        return value

    def _mouse(self, flags, x=0, y=0, data=0, expected_hwnd=0):
        self._send(self._mouse_input(flags, x, y, data), expected_hwnd=expected_hwnd)

    def _mouse_release(self, flags):
        return self._send_release(self._mouse_input(flags))

    def move(self, x, y, expected_hwnd=0):
        absolute_x = int(clamp(x, 0.0, 1.0) * 65535)
        absolute_y = int(clamp(y, 0.0, 1.0) * 65535)
        self._mouse(self.MOUSEEVENTF_MOVE | self.MOUSEEVENTF_ABSOLUTE | self.MOUSEEVENTF_VIRTUALDESK, absolute_x, absolute_y, expected_hwnd=expected_hwnd)

    def _keyboard_input(self, virtual_key, up=False, unicode_scan=0):
        value = Input()
        value.type = self.INPUT_KEYBOARD
        flags = self.KEYEVENTF_KEYUP if up else 0
        if unicode_scan:
            flags |= self.KEYEVENTF_UNICODE
        elif int(virtual_key) in (0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x6F, 0x90):
            flags |= self.KEYEVENTF_EXTENDEDKEY
        value.ki = KeyboardInput(0 if unicode_scan else int(virtual_key), int(unicode_scan), flags, 0, 0)
        return value

    def key_event(self, virtual_key, up=False, unicode_scan=0, expected_hwnd=0):
        self._send(self._keyboard_input(virtual_key, up=up, unicode_scan=unicode_scan), expected_hwnd=expected_hwnd)

    def _key_release(self, virtual_key, unicode_scan=0):
        return self._send_release(self._keyboard_input(virtual_key, up=True, unicode_scan=unicode_scan))

    def key(self, virtual_key, modifiers=(), expected_hwnd=0):
        pressed_modifiers = []
        main_down = False
        try:
            for modifier in modifiers:
                self.key_event(int(modifier), False, expected_hwnd=expected_hwnd)
                pressed_modifiers.append(int(modifier))
            self.key_event(int(virtual_key), False, expected_hwnd=expected_hwnd)
            main_down = True
            self.key_event(int(virtual_key), True, expected_hwnd=expected_hwnd)
            main_down = False
        finally:
            # 如果 HWND 在 key-down 与 key-up 之间切换，禁止继续产生新的 down，
            # 但仍发送纯 release，避免修饰键/主键卡住。
            if main_down:
                self._key_release(int(virtual_key))
            for modifier in reversed(pressed_modifiers):
                try:
                    self.key_event(int(modifier), True, expected_hwnd=expected_hwnd)
                except Exception:
                    self._key_release(int(modifier))

    def type_text(self, text, stop_event=None, expected_hwnd=0):
        units = str(text).encode("utf-16-le", "surrogatepass")
        for index in range(0, len(units), 2):
            if stop_event is not None and stop_event.is_set():
                return False
            scan = units[index] | (units[index + 1] << 8)
            down = False
            try:
                # HWND 不是只在循环顶部检查，而是在 gate 临界区内紧贴每次 SendInput 复核。
                self.key_event(0, False, scan, expected_hwnd=expected_hwnd)
                down = True
                self.key_event(0, True, scan, expected_hwnd=expected_hwnd)
                down = False
            except OSError as error:
                if down:
                    self._key_release(0, unicode_scan=scan)
                if "前台窗口已改变" in str(error):
                    return False
                raise
            time.sleep(0.006)
        return True

    def execute(self, command, stop_event=None, expected_hwnd=0):
        kind = command.kind
        parameters = command.parameters
        if kind == MOVE:
            self.move(float(parameters.get("x", 0.5)), float(parameters.get("y", 0.5)), expected_hwnd=expected_hwnd)
        elif kind == CLICK:
            # 先移动，再在 mouse-down 前于 input gate 临界区中重新校验 HWND。
            self.move(float(parameters.get("x", 0.5)), float(parameters.get("y", 0.5)), expected_hwnd=expected_hwnd)
            if stop_event is not None and stop_event.wait(0.025):
                return False
            if parameters.get("button") == "right":
                down_flag, up_flag = self.MOUSEEVENTF_RIGHTDOWN, self.MOUSEEVENTF_RIGHTUP
            else:
                down_flag, up_flag = self.MOUSEEVENTF_LEFTDOWN, self.MOUSEEVENTF_LEFTUP
            down = False
            try:
                self._mouse(down_flag, expected_hwnd=expected_hwnd); down = True
                self._mouse(up_flag, expected_hwnd=expected_hwnd); down = False
            finally:
                if down:
                    self._mouse_release(up_flag)
        elif kind == SCROLL:
            self._mouse(self.MOUSEEVENTF_WHEEL, data=int(parameters.get("amount", 120)), expected_hwnd=expected_hwnd)
        elif kind == KEY:
            self.key(int(parameters.get("vk", 0x09)), tuple(int(value) for value in parameters.get("modifiers", [])), expected_hwnd=expected_hwnd)
        elif kind == TYPE:
            return self.type_text(str(parameters.get("text", "")), stop_event, expected_hwnd)
        return True

    def release_inputs(self):
        if not self.input_enabled:
            return
        for key in (self.VK_SHIFT, self.VK_CONTROL, self.VK_MENU, 0x5B, 0x5C, self.VK_ESCAPE):
            try:
                value = Input(); value.type = self.INPUT_KEYBOARD; value.ki = KeyboardInput(key, 0, self.KEYEVENTF_KEYUP, 0, 0)
                self._send_release(value)
            except Exception:
                pass
        for flag in (self.MOUSEEVENTF_LEFTUP, self.MOUSEEVENTF_RIGHTUP):
            try:
                value = Input(); value.type = self.INPUT_MOUSE; value.mi = MouseInput(0, 0, 0, flag, 0, 0)
                self._send_release(value)
            except Exception:
                pass


def release_inputs_in_watchdog(user32):
    try:
        user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        user32.SendInput.restype = wintypes.UINT
        for key in (0x10, 0x11, 0x12, 0x5B, 0x5C, 0x1B):
            value = Input(); value.type = 1; value.ki = KeyboardInput(key, 0, 0x0002, 0, 0)
            user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input))
        for flag in (0x0004, 0x0010):
            value = Input(); value.type = 0; value.mi = MouseInput(0, 0, 0, flag, 0, 0)
            user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input))
    except Exception:
        pass


def escape_watchdog_process(stop_event, done_event, escape_event=None, release_enabled=True, input_gate_event=None, input_gate_lock=None, generation_value=None, expected_generation=None):
    if os.name != "nt":
        return
    try:
        install_runtime_offline_guard()
        lock_runtime_activity()
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
        user32.GetAsyncKeyState.restype = ctypes.c_short
        while not done_event.wait(0.012):
            if user32.GetAsyncKeyState(0x1B) & 0x8000:
                if escape_event is not None:
                    escape_event.set()
                SharedInputGate(input_gate_event, input_gate_lock, stop_event, generation_value=generation_value, expected_generation=expected_generation).close()
                if release_enabled:
                    release_inputs_in_watchdog(user32)
                return
    except Exception:
        return


class EscapeWatchdog:
    def __init__(self, context, stop_event, escape_event=None, release_enabled=True, input_gate_event=None, input_gate_lock=None, generation_value=None, expected_generation=None):
        self.context = context
        self.stop_event = stop_event
        self.escape_event = escape_event
        self.release_enabled = bool(release_enabled)
        self.input_gate_event = input_gate_event
        self.input_gate_lock = input_gate_lock
        self.generation_value = generation_value
        self.expected_generation = expected_generation
        self.done_event = context.Event()
        self.process = None
        self.thread = None

    def start(self):
        self.done_event.clear()
        try:
            self.process = self.context.Process(target=escape_watchdog_process, args=(self.stop_event, self.done_event, self.escape_event, self.release_enabled, self.input_gate_event, self.input_gate_lock, self.generation_value, self.expected_generation), name="EscapeWatchdog", daemon=True)
            self.process.start()
        except Exception:
            self.process = None
        if self.process is None:
            self.thread = threading.Thread(target=escape_watchdog_process, args=(self.stop_event, self.done_event, self.escape_event, self.release_enabled, self.input_gate_event, self.input_gate_lock, self.generation_value, self.expected_generation), name="EscapeWatchdogFallback", daemon=True)
            self.thread.start()

    def is_alive(self, require_process=False):
        process_alive = bool(self.process is not None and self.process.is_alive())
        if require_process:
            return process_alive
        return process_alive or bool(self.thread is not None and self.thread.is_alive())

    def stop(self):
        self.done_event.set()
        if self.process is not None:
            self.process.join(0.6)
            if self.process.is_alive():
                self.process.terminate()
                self.process.join(0.3)
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(0.25)

    def abnormal_exit(self):
        return bool(self.process is not None and not self.process.is_alive() and not self.done_event.is_set())


MINIMAL_GUARDIAN_SOURCE = r'''
import ctypes
from ctypes import wintypes
import sys
import time

EVENT_MODIFY_STATE = 0x0002
SYNCHRONIZE = 0x00100000
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 0x00000102
escape_name, done_name, gate_closed_name = sys.argv[1], sys.argv[2], sys.argv[3]
parent_pid, worker_pid, main_hwnd = map(int, sys.argv[4:7])
kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
user32 = ctypes.WinDLL('user32', use_last_error=True)
kernel32.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
kernel32.OpenEventW.restype = wintypes.HANDLE
kernel32.SetEvent.argtypes = [wintypes.HANDLE]
kernel32.SetEvent.restype = wintypes.BOOL
kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel32.WaitForSingleObject.restype = wintypes.DWORD
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.IsWindowVisible.argtypes = [wintypes.HWND]
user32.IsWindowVisible.restype = wintypes.BOOL
escape_handle = kernel32.OpenEventW(EVENT_MODIFY_STATE | SYNCHRONIZE, False, escape_name)
done_handle = kernel32.OpenEventW(EVENT_MODIFY_STATE | SYNCHRONIZE, False, done_name)
gate_closed_handle = kernel32.OpenEventW(SYNCHRONIZE, False, gate_closed_name)
parent_handle = kernel32.OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, False, parent_pid)
worker_handle = kernel32.OpenProcess(SYNCHRONIZE | PROCESS_TERMINATE | PROCESS_QUERY_LIMITED_INFORMATION, False, worker_pid)
try:
    while escape_handle and done_handle:
        if kernel32.WaitForSingleObject(done_handle, 0) == WAIT_OBJECT_0:
            break
        if parent_handle and kernel32.WaitForSingleObject(parent_handle, 0) == WAIT_OBJECT_0:
            # 主进程已经死亡：guardian 才接管最后应急恢复。先确保 worker 死亡，再显示窗口。
            if worker_handle and kernel32.WaitForSingleObject(worker_handle, 0) == WAIT_TIMEOUT:
                kernel32.TerminateProcess(worker_handle, 0xE5C0)
                kernel32.WaitForSingleObject(worker_handle, 1000)
            root = user32.GetAncestor(main_hwnd, 2) if main_hwnd else 0
            if root:
                user32.ShowWindow(root, 9)
                user32.SetForegroundWindow(root)
            break
        if worker_handle and kernel32.WaitForSingleObject(worker_handle, 0) == WAIT_OBJECT_0:
            break
        if user32.GetAsyncKeyState(0x1B) & 0x8000:
            # ESC P0：先通知主进程 bridge 永久关 input gate；不提供保存/训练宽限。
            kernel32.SetEvent(escape_handle)
            if gate_closed_handle:
                kernel32.WaitForSingleObject(gate_closed_handle, 60)
            # 纯 KEYUP/MOUSEUP 紧急释放允许绕过正常输入 pause/close。
            for key in (0x10, 0x11, 0x12, 0x5B, 0x5C, 0x1B):
                user32.keybd_event(key, 0, 0x0002, 0)
            user32.mouse_event(0x0004, 0, 0, 0, 0)
            user32.mouse_event(0x0010, 0, 0, 0, 0)
            if worker_handle and kernel32.WaitForSingleObject(worker_handle, 0) == WAIT_TIMEOUT:
                kernel32.TerminateProcess(worker_handle, 0xE5C1)
            # 正常 ESC 路径只负责关闸和杀 worker；GUI 的正常所有者是主进程 Application。
            worker_dead = True
            if worker_handle:
                worker_dead = (kernel32.WaitForSingleObject(worker_handle, 1000) == WAIT_OBJECT_0)
            if not worker_dead:
                break
            # 主进程若仍活着，先等待 Application 在 STATE_STOPPING->IDLE 后自行 deiconify。
            # 只有主进程死亡，或 worker 已死但 GUI 长时间仍隐藏（视为主 GUI 卡死）时，guardian 才应急 ShowWindow。
            root = user32.GetAncestor(main_hwnd, 2) if main_hwnd else 0
            restore_deadline = time.monotonic() + 1.8
            emergency_restore = False
            while root and parent_handle:
                if kernel32.WaitForSingleObject(parent_handle, 0) == WAIT_OBJECT_0:
                    emergency_restore = True
                    break
                if user32.IsWindowVisible(root):
                    break
                if kernel32.WaitForSingleObject(done_handle, 0) == WAIT_OBJECT_0:
                    break
                if time.monotonic() >= restore_deadline:
                    emergency_restore = True
                    break
                time.sleep(0.02)
            if emergency_restore and root:
                user32.ShowWindow(root, 9)
                user32.SetForegroundWindow(root)
            break
        time.sleep(0.008)
finally:
    for handle in (worker_handle, parent_handle, gate_closed_handle, done_handle, escape_handle):
        if handle:
            kernel32.CloseHandle(handle)
'''.replace("__ESC_WORKER_KILL_GRACE__", repr(ESC_WORKER_KILL_GRACE))


class MinimalEscapeGuardian:
    """独立 python -I -S 进程：正常只处理 ESC/释放输入/强杀 worker；GUI 仅在主进程死亡或主 GUI 恢复超时卡死时应急恢复。"""

    def __init__(self, stop_event, escape_event, input_gate_event, input_gate_lock, generation_value, expected_generation):
        self.stop_event = stop_event
        self.escape_event = escape_event
        self.input_gate_event = input_gate_event
        self.input_gate_lock = input_gate_lock
        self.generation_value = generation_value
        self.expected_generation = expected_generation
        self.process = None
        self.bridge = None
        self.kernel32 = None
        self.escape_handle = None
        self.done_handle = None
        self.gate_closed_handle = None
        token = uuid.uuid4().hex
        self.escape_name = "Local\\LocalAI_Escape_" + token
        self.done_name = "Local\\LocalAI_Done_" + token
        self.gate_closed_name = "Local\\LocalAI_GateClosed_" + token

    @staticmethod
    def source_is_minimal():
        lowered = MINIMAL_GUARDIAN_SOURCE.lower()
        forbidden = ("sqlite", "numpy", "tkinter", "reasoning", "perception", "model.bin", "memory.sqlite")
        return not any(value in lowered for value in forbidden) and "import ctypes" in lowered and "import time" in lowered

    def start(self, worker_pid, main_hwnd=0):
        if os.name != "nt" or not worker_pid:
            return False
        self.kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel32.CreateEventW.argtypes = [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR]
        self.kernel32.CreateEventW.restype = wintypes.HANDLE
        self.kernel32.SetEvent.argtypes = [wintypes.HANDLE]; self.kernel32.SetEvent.restype = wintypes.BOOL
        self.kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]; self.kernel32.WaitForSingleObject.restype = wintypes.DWORD
        self.kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        self.escape_handle = self.kernel32.CreateEventW(None, False, False, self.escape_name)
        self.done_handle = self.kernel32.CreateEventW(None, True, False, self.done_name)
        self.gate_closed_handle = self.kernel32.CreateEventW(None, True, False, self.gate_closed_name)
        if not self.escape_handle or not self.done_handle or not self.gate_closed_handle:
            self.stop(); return False
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        self.process = subprocess.Popen(
            [sys.executable, "-I", "-S", "-c", MINIMAL_GUARDIAN_SOURCE, self.escape_name, self.done_name, self.gate_closed_name,
             str(os.getpid()), str(int(worker_pid)), str(int(main_hwnd or 0))],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            close_fds=True, creationflags=creationflags,
        )
        self.bridge = threading.Thread(target=self._bridge_escape, name="MinimalGuardianBridge", daemon=True)
        self.bridge.start()
        return True

    def _bridge_escape(self):
        while self.process is not None and self.process.poll() is None and self.escape_handle:
            if self.kernel32.WaitForSingleObject(self.escape_handle, 40) == 0:
                try: self.escape_event.set()
                except Exception: pass
                SharedInputGate(
                    self.input_gate_event, self.input_gate_lock, self.stop_event,
                    generation_value=self.generation_value, expected_generation=self.expected_generation,
                ).close()
                if self.kernel32 is not None and self.gate_closed_handle:
                    try: self.kernel32.SetEvent(self.gate_closed_handle)
                    except Exception: pass
                return

    def is_alive(self):
        return bool(self.process is not None and self.process.poll() is None)

    def stop(self):
        if self.kernel32 is not None and self.done_handle:
            try: self.kernel32.SetEvent(self.done_handle)
            except Exception: pass
        if self.process is not None:
            try: self.process.wait(timeout=0.45)
            except Exception:
                try: self.process.terminate(); self.process.wait(timeout=0.25)
                except Exception: pass
        if self.bridge is not None and self.bridge.is_alive():
            self.bridge.join(0.20)
        if self.kernel32 is not None:
            for handle in (self.escape_handle, self.done_handle, self.gate_closed_handle):
                if handle:
                    try: self.kernel32.CloseHandle(handle)
                    except Exception: pass
        self.escape_handle = self.done_handle = self.gate_closed_handle = None
        self.process = None


class WorkingMemory:
    def __init__(self, horizon=16):
        self.horizon = max(8, int(horizon))
        self.actions = deque()
        self.rewards = deque()
        self.goals = deque()
        self.curiosities = deque()
        self.safeties = deque()
        self.effects = deque()
        self.signatures = deque()
        self.steps_since_goal = 0
        self.steps_since_sleep = 0

    def set_horizon(self, horizon):
        self.horizon = max(self.horizon, int(horizon))

    def _trim(self):
        limit = max(128, self.horizon * 8)
        for values in (self.actions, self.rewards, self.goals, self.curiosities, self.safeties, self.effects, self.signatures):
            while len(values) > limit:
                values.popleft()

    def update(self, action, reward, components, signature, slept=False):
        self.actions.append(int(action))
        self.rewards.append(float(reward))
        self.goals.append(float(components.get("goal_reward", 0.0)))
        self.curiosities.append(float(components.get("curiosity_reward", 0.0)))
        self.safeties.append(float(components.get("safety_penalty", 0.0)))
        self.effects.append(float(components.get("effect", 0.0)))
        self.signatures.append(str(signature))
        self._trim()
        if components.get("goal_progress", 0.0) > 0.08:
            self.steps_since_goal = 0
        else:
            self.steps_since_goal += 1
        self.steps_since_sleep = 0 if slept else self.steps_since_sleep + 1

    def grow(self):
        self.horizon += 8
        return self.horizon

    def features(self):
        horizon = min(self.horizon, len(self.actions))
        actions = list(self.actions)[-horizon:]
        rewards = list(self.rewards)[-horizon:]
        goals = list(self.goals)[-horizon:]
        curiosities = list(self.curiosities)[-horizon:]
        safeties = list(self.safeties)[-horizon:]
        effects = list(self.effects)[-horizon:]
        one_hot = [0.0] * ACTION_COUNT
        frequencies = [0.0] * ACTION_COUNT
        if actions:
            one_hot[actions[-1]] = 1.0
            counts = Counter(actions)
            frequencies = [counts[index] / horizon for index in range(ACTION_COUNT)]

        def mapped_last(values, default=0.0):
            return clamp((values[-1] if values else default) * 0.5 + 0.5, 0.0, 1.0)

        def mapped_mean(values, default=0.0):
            return clamp(((sum(values) / len(values)) if values else default) * 0.5 + 0.5, 0.0, 1.0)

        scalars = [
            mapped_last(rewards), mapped_mean(rewards),
            sum(1 for value in rewards if value > 0.08) / max(1, horizon),
            sum(1 for value in rewards if value < -0.08) / max(1, horizon),
            mapped_last(goals), mapped_mean(goals),
            clamp(curiosities[-1] if curiosities else 0.0, 0.0, 1.0),
            clamp(sum(curiosities) / max(1, horizon), 0.0, 1.0),
            clamp(safeties[-1] if safeties else 0.0, 0.0, 1.0),
            clamp(sum(safeties) / max(1, horizon), 0.0, 1.0),
            clamp(effects[-1] * 4.0 if effects else 0.0, 0.0, 1.0),
            clamp(sum(effects) / max(1, horizon) * 4.0, 0.0, 1.0),
            len(set(actions)) / max(1, horizon),
            len(set(list(self.signatures)[-horizon:])) / max(1, horizon),
            clamp(self.steps_since_goal / 80.0, 0.0, 1.0),
            clamp(self.steps_since_sleep / 180.0, 0.0, 1.0),
        ]
        values = one_hot + frequencies + scalars
        if len(values) != MEMORY_FEATURES:
            raise ValueError("工作记忆特征维度错误")
        return values

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        actions = list(self.actions)[-max(1, count // 5):]
        rewards = list(self.rewards)[-len(actions):]
        goals = list(self.goals)[-len(actions):]
        safeties = list(self.safeties)[-len(actions):]
        effects = list(self.effects)[-len(actions):]
        values = []
        # 按时间顺序保留可变长度 episodic 工作轨迹，新输入槽位越多，能看到的历史越长。
        for action, reward, goal, safety, effect in zip(actions, rewards, goals, safeties, effects):
            values.extend([
                action / max(1, ACTION_COUNT - 1),
                clamp(reward * 0.5 + 0.5, 0.0, 1.0),
                clamp(goal * 0.5 + 0.5, 0.0, 1.0),
                clamp(safety, 0.0, 1.0),
                clamp(effect * 4.0, 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        return normalize_state(values, count)


class SleepEntryPolicy:
    """本地可学习入睡策略。训练标签来自历次睡眠后的真实收益，而不是固定计时器/固定压力阈值。"""

    FEATURE_NAMES = (
        "td_error", "pending_experience", "repeated_failure", "skill_conflict",
        "world_uncertainty", "goal_stagnation", "memory_fragmentation", "awake_debt", "maintenance_debt",
    )
    DECISION_BOUNDARY = 0.50

    def __init__(self):
        self.bias = -1.10
        self.weights = {
            "td_error": 0.76, "pending_experience": 0.92, "repeated_failure": 0.62, "skill_conflict": 0.55,
            "world_uncertainty": 0.48, "goal_stagnation": 0.66, "memory_fragmentation": 0.74,
            "awake_debt": 0.52, "maintenance_debt": 1.08,
        }
        self.updates = 0

    def score(self, features):
        raw = self.bias
        for name in self.FEATURE_NAMES:
            raw += self.weights.get(name, 0.0) * clamp(safe_float(features.get(name, 0.0)), 0.0, 1.0)
        raw = clamp(raw, -12.0, 12.0)
        return 1.0 / (1.0 + math.exp(-raw))

    def wants_sleep(self, features):
        value = self.score(features)
        return value >= self.DECISION_BOUNDARY, value

    def learn(self, features, realized_sleep_value):
        prediction = self.score(features)
        target = clamp(safe_float(realized_sleep_value, prediction), 0.0, 1.0)
        error = target - prediction
        rate = 0.035 / math.sqrt(1.0 + self.updates * 0.02)
        for name in self.FEATURE_NAMES:
            value = clamp(safe_float(features.get(name, 0.0)), 0.0, 1.0)
            self.weights[name] = clamp(self.weights.get(name, 0.0) + rate * error * value, -2.0, 3.0)
        self.bias = clamp(self.bias + rate * error, -4.0, 2.0)
        self.updates += 1
        return self.score(features)

    def snapshot(self):
        return {"bias": float(self.bias), "weights": {name: float(self.weights.get(name, 0.0)) for name in self.FEATURE_NAMES}, "updates": int(self.updates)}

    def restore(self, payload):
        payload = dict(payload or {})
        weights = dict(payload.get("weights") or {})
        if weights:
            for name in self.FEATURE_NAMES:
                if name in weights:
                    self.weights[name] = clamp(safe_float(weights[name], self.weights.get(name, 0.0)), -2.0, 3.0)
        if "bias" in payload:
            self.bias = clamp(safe_float(payload.get("bias"), self.bias), -4.0, 2.0)
        if "updates" in payload:
            self.updates = max(0, int(safe_float(payload.get("updates"), self.updates)))
        return self.snapshot()


class SleepWakePolicy:
    """完全本地的可学习睡/醒策略；只吃本次睡眠的真实效果，不使用计时器作为醒来理由。"""

    FEATURE_NAMES = (
        "pending_ratio", "fragmentation", "td_error", "skill_conflict",
        "world_uncertainty", "repeated_failure", "goal_stagnation", "useful_gain",
    )

    def __init__(self):
        self.bias = -1.35
        self.weights = {
            "pending_ratio": 1.10, "fragmentation": 0.95, "td_error": 0.90, "skill_conflict": 0.72,
            "world_uncertainty": 0.62, "repeated_failure": 0.48, "goal_stagnation": 0.42, "useful_gain": 0.70,
        }
        self.updates = 0

    def score(self, features):
        raw = self.bias
        for name in self.FEATURE_NAMES:
            raw += self.weights.get(name, 0.0) * clamp(safe_float(features.get(name, 0.0)), 0.0, 1.0)
        raw = clamp(raw, -12.0, 12.0)
        return 1.0 / (1.0 + math.exp(-raw))

    def learn(self, features, target_sleep_need):
        prediction = self.score(features)
        target = clamp(safe_float(target_sleep_need, prediction), 0.0, 1.0)
        error = target - prediction
        rate = 0.035 / math.sqrt(1.0 + self.updates * 0.02)
        for name in self.FEATURE_NAMES:
            value = clamp(safe_float(features.get(name, 0.0)), 0.0, 1.0)
            self.weights[name] = clamp(self.weights.get(name, 0.0) + rate * error * value, -2.0, 3.0)
        self.bias = clamp(self.bias + rate * error, -4.0, 2.0)
        self.updates += 1
        return self.score(features)

    def snapshot(self):
        return {"bias": float(self.bias), "weights": {name: float(self.weights.get(name, 0.0)) for name in self.FEATURE_NAMES}, "updates": int(self.updates)}

    def restore(self, payload):
        payload = dict(payload or {})
        weights = dict(payload.get("weights") or {})
        if weights:
            for name in self.FEATURE_NAMES:
                if name in weights:
                    self.weights[name] = clamp(safe_float(weights[name], self.weights.get(name, 0.0)), -2.0, 3.0)
        if "bias" in payload:
            self.bias = clamp(safe_float(payload.get("bias"), self.bias), -4.0, 2.0)
        if "updates" in payload:
            self.updates = max(0, int(safe_float(payload.get("updates"), self.updates)))
        return self.snapshot()


class MetaCognitiveSleep:
    """可解释、有滞回的睡眠决策；完全取消随机强制睡眠。"""

    WEIGHTS = {
        "td_error": 0.18, "pending_experience": 0.16, "repeated_failure": 0.16,
        "skill_conflict": 0.12, "world_uncertainty": 0.13, "goal_stagnation": 0.15,
        "memory_fragmentation": 0.10,
    }

    @staticmethod
    def _skill_conflict(skills):
        skills = list(skills or [])
        if len(skills) < 2:
            return 0.0
        top_score = safe_float(skills[0].get("retrieval_score", skills[0].get("score", 0.0)))
        competing = [skill for skill in skills if top_score - safe_float(skill.get("retrieval_score", skill.get("score", 0.0))) <= 0.12]
        if len(competing) < 2:
            return 0.0
        signatures = set()
        for skill in competing:
            first = (skill.get("steps") or [{}])[0]
            signatures.add(compact_json(first))
        capability_sets = {tuple(sorted(skill.get("capabilities", []))) for skill in competing}
        return clamp((len(signatures) - 1) / max(1, len(competing) - 1) * 0.7 + (len(capability_sets) - 1) / max(1, len(competing)) * 0.3, 0.0, 1.0)

    @classmethod
    def evaluate(cls, model, memory, working, world_uncertainty, eligible_skills, repeated=0, compiler_stalled=False, pending_skill=False, awake_steps=0, awake_seconds=0.0, deferred_maintenance=False):
        horizon = max(1, min(working.horizon, len(working.rewards)))
        rewards = list(working.rewards)[-horizon:]
        safeties = list(working.safeties)[-horizon:]
        failures = sum(1 for reward, safety in zip(rewards, safeties) if reward < -0.08 or safety > 0.25)
        repeated_failure = clamp(failures / max(1, horizon) * 1.6 + max(0, int(repeated) - 1) / max(2.0, math.sqrt(horizon)), 0.0, 1.0)
        pending = memory.pending_experience_count()
        episode_budget = max(1, memory.resource_budget.memory_limits().get("episodic_memory", pending + 1))
        factors = {
            "td_error": clamp(math.tanh(max(0.0, float(model.loss_average)) * 1.4), 0.0, 1.0),
            "pending_experience": clamp(math.log1p(pending) / max(1e-9, math.log1p(episode_budget)), 0.0, 1.0),
            "repeated_failure": repeated_failure,
            "skill_conflict": cls._skill_conflict(eligible_skills),
            "world_uncertainty": clamp(float(world_uncertainty), 0.0, 1.0),
            "goal_stagnation": clamp(1.0 - math.exp(-working.steps_since_goal / max(1.0, math.sqrt(working.horizon) * 3.0)), 0.0, 1.0),
            "memory_fragmentation": memory.fragmentation_score(),
        }
        if compiler_stalled:
            factors["goal_stagnation"] = max(factors["goal_stagnation"], 0.96)
            factors["world_uncertainty"] = max(factors["world_uncertainty"], 0.78)
        if pending_skill:
            factors["pending_experience"] = max(factors["pending_experience"], 0.72)
        if deferred_maintenance:
            # 上一次任务留下的是“维护压力”，不是程序级强制睡眠命令。
            factors["pending_experience"] = max(factors["pending_experience"], 0.88)
        score = sum(cls.WEIGHTS[name] * factors[name] for name in cls.WEIGHTS)
        # 清醒债务是 AI 的连续内部状态；最大连续清醒秒数仅保留为资源安全遥测，绝不直接决定 should_sleep。
        awake_scale = max(180.0, float(max(1, working.horizon)) * 14.0)
        awake_debt = 1.0 - math.exp(-max(0.0, float(awake_steps)) / awake_scale)
        awake_seconds = max(0.0, safe_float(awake_seconds, 0.0))
        resource_awake_ratio = clamp(awake_seconds / max(1.0, float(MAX_CONTINUOUS_AWAKE_SECONDS)), 0.0, 1.0)
        training_debt = clamp((float(getattr(model, "training_steps", 0)) % max(1, TARGET_SYNC_INTERVAL)) / max(1.0, float(TARGET_SYNC_INTERVAL)), 0.0, 1.0)
        maintenance_debt = clamp(max(
            awake_debt,
            factors["pending_experience"] * 0.78 + factors["memory_fragmentation"] * 0.22,
            training_debt * 0.45 + factors["goal_stagnation"] * 0.35,
            0.92 if deferred_maintenance else 0.0,
        ), 0.0, 1.0)
        factors["awake_debt"] = awake_debt
        factors["maintenance_debt"] = maintenance_debt
        heuristic_pressure = 1.0 - (1.0 - clamp(score, 0.0, 1.0)) * (1.0 - 0.78 * maintenance_debt * maintenance_debt)
        # 固定 SLEEP_ENTER_THRESHOLD 只保留为安全边界：例如 compiler 已明确停滞时允许强制维护；
        # 正常“AI 想睡”由可学习 SleepEntryPolicy 决定，与醒来策略在语义上对称。
        if compiler_stalled:
            heuristic_pressure = max(heuristic_pressure, SLEEP_ENTER_THRESHOLD + 0.01)
        entry_features = {name: clamp(safe_float(factors.get(name, 0.0)), 0.0, 1.0) for name in SleepEntryPolicy.FEATURE_NAMES}
        policy_wants_sleep, entry_policy_score = cls._ENTRY_POLICY.wants_sleep(entry_features)
        safety_sleep_required = bool(compiler_stalled and heuristic_pressure >= SLEEP_ENTER_THRESHOLD)
        reasons = [name for name, value in sorted(factors.items(), key=lambda item: item[1], reverse=True) if value >= 0.35]
        return {
            "score": clamp(entry_policy_score, 0.0, 1.0), "heuristic_pressure": clamp(heuristic_pressure, 0.0, 1.0),
            "factors": factors, "entry_features": entry_features, "reasons": reasons,
            "resource_monitors": {"awake_seconds": awake_seconds, "max_continuous_awake_seconds": float(MAX_CONTINUOUS_AWAKE_SECONDS), "ratio": resource_awake_ratio},
            "entry_policy_boundary": float(SleepEntryPolicy.DECISION_BOUNDARY),
            "safety_pressure_threshold": SLEEP_ENTER_THRESHOLD, "wake_threshold": SLEEP_WAKE_THRESHOLD,
            "policy_wants_sleep": bool(policy_wants_sleep), "safety_sleep_required": bool(safety_sleep_required),
            "should_sleep": bool(policy_wants_sleep or safety_sleep_required),
            "entry_policy_updates": int(cls._ENTRY_POLICY.updates),
        }

    _ENTRY_POLICY = SleepEntryPolicy()
    _WAKE_POLICY = SleepWakePolicy()

    @classmethod
    def after_sleep(cls, decision, before_loss, after_loss, training_accepted=True, sleep_elapsed=0.0,
                    resource_deadline_reached=False, effects=None):
        """根据真实睡眠前后指标决定是否醒来；时间片结束只触发再次评估，不会强制退出/强制醒。"""
        prior_factors = dict((decision or {}).get("factors") or {})
        effects = dict(effects or {})

        pending_before = max(0.0, safe_float(effects.get("pending_before", 0.0)))
        pending_after = max(0.0, safe_float(effects.get("pending_after", pending_before)))
        pending_capacity = max(1.0, safe_float(effects.get("pending_capacity", max(1.0, pending_before))))
        pending_ratio = clamp(math.log1p(pending_after) / max(1e-9, math.log1p(pending_capacity)), 0.0, 1.0)
        fragmentation_after = clamp(safe_float(effects.get("fragmentation_after", prior_factors.get("memory_fragmentation", 0.0))), 0.0, 1.0)
        skill_conflict_after = clamp(safe_float(effects.get("skill_conflict_after", prior_factors.get("skill_conflict", 0.0))), 0.0, 1.0)
        world_uncertainty = clamp(safe_float(effects.get("world_uncertainty_after", prior_factors.get("world_uncertainty", 0.0))), 0.0, 1.0)
        repeated_failure = clamp(safe_float(effects.get("repeated_failure_after", prior_factors.get("repeated_failure", 0.0))), 0.0, 1.0)
        goal_stagnation = clamp(safe_float(effects.get("goal_stagnation_after", prior_factors.get("goal_stagnation", 0.0))), 0.0, 1.0)
        td_error = clamp(math.tanh(max(0.0, safe_float(after_loss, 0.0)) * 1.4), 0.0, 1.0)
        if not training_accepted:
            td_error = max(td_error, clamp(safe_float(prior_factors.get("td_error", 0.0)), 0.0, 1.0))

        gain_per_second = max(0.0, safe_float(effects.get("training_gain_per_second", 0.0)))
        memory_gain = max(0.0, safe_float(effects.get("memory_gain", 0.0)))
        skill_gain = max(0.0, safe_float(effects.get("new_skill_count", 0.0)))
        useful_gain = clamp(
            gain_per_second / max(1e-9, SLEEP_MIN_GAIN_PER_SECOND * 4.0)
            + memory_gain * 0.35
            + min(1.0, skill_gain / 3.0) * 0.25,
            0.0, 1.0,
        )

        wake_features = {
            "pending_ratio": pending_ratio,
            "fragmentation": fragmentation_after,
            "td_error": td_error,
            "skill_conflict": skill_conflict_after,
            "world_uncertainty": world_uncertainty,
            "repeated_failure": repeated_failure,
            "goal_stagnation": goal_stagnation,
            # 睡眠仍在产生明显真实收益时，策略可选择继续睡；收益低时不会被伪造为“已修复”。
            "useful_gain": useful_gain,
        }
        empirical_need = clamp(
            0.23 * pending_ratio + 0.18 * fragmentation_after + 0.20 * td_error
            + 0.10 * skill_conflict_after + 0.10 * world_uncertainty
            + 0.07 * repeated_failure + 0.05 * goal_stagnation + 0.07 * useful_gain,
            0.0, 1.0,
        )
        # 用“这次睡眠到底有没有带来真实收益”反向训练入睡策略。
        entry_features = dict((decision or {}).get("entry_features") or {})
        prior_fragmentation = clamp(safe_float(prior_factors.get("memory_fragmentation", fragmentation_after)), 0.0, 1.0)
        prior_td = clamp(math.tanh(max(0.0, safe_float(before_loss, 0.0)) * 1.4), 0.0, 1.0)
        pending_improvement = clamp((pending_before - pending_after) / pending_capacity, 0.0, 1.0)
        fragmentation_improvement = clamp(prior_fragmentation - fragmentation_after, 0.0, 1.0)
        td_improvement = clamp(prior_td - td_error, 0.0, 1.0)
        realized_gain = clamp(
            0.30 * pending_improvement + 0.18 * fragmentation_improvement + 0.22 * td_improvement
            + 0.12 * clamp(memory_gain, 0.0, 1.0) + 0.08 * clamp(skill_gain / 3.0, 0.0, 1.0)
            + 0.10 * clamp(gain_per_second / max(1e-9, SLEEP_MIN_GAIN_PER_SECOND * 4.0), 0.0, 1.0),
            0.0, 1.0,
        )
        realized_sleep_value = clamp((0.34 if training_accepted else 0.10) + 0.66 * realized_gain, 0.0, 1.0)
        if entry_features:
            cls._ENTRY_POLICY.learn(entry_features, realized_sleep_value)

        policy_score = cls._WAKE_POLICY.learn(wake_features, empirical_need)
        wake_score = clamp(policy_score * 0.55 + empirical_need * 0.45, 0.0, 1.0)
        factors = {
            "td_error": td_error,
            "pending_experience": pending_ratio,
            "repeated_failure": repeated_failure,
            "skill_conflict": skill_conflict_after,
            "world_uncertainty": world_uncertainty,
            "goal_stagnation": goal_stagnation,
            "memory_fragmentation": fragmentation_after,
            "useful_gain": useful_gain,
        }
        return {
            "score": wake_score,
            "residual_sleep_need": wake_score,
            "factors": factors,
            "wake_features": wake_features,
            "wake_threshold": SLEEP_WAKE_THRESHOLD,
            "wake_ready": wake_score <= SLEEP_WAKE_THRESHOLD,
            # 仅遥测：工作切片耗尽绝不再等价于自由会话终止。
            "work_slice_exhausted": bool(resource_deadline_reached),
            "sleep_elapsed": max(0.0, safe_float(sleep_elapsed, 0.0)),
            "policy_updates": int(cls._WAKE_POLICY.updates),
            "entry_policy_updates": int(cls._ENTRY_POLICY.updates),
            "realized_sleep_value": float(realized_sleep_value),
        }



@dataclass
class TaskDSLNode:
    """GoalCompiler 2.0 的类型化节点；既能表示动作，也能表示真实控制流。"""
    identifier: str
    object_ref: str
    operation: str
    parameters: dict = field(default_factory=dict)
    preconditions: list = field(default_factory=list)
    postconditions: list = field(default_factory=list)
    recovery: list = field(default_factory=list)
    branches: list = field(default_factory=list)
    loop: dict = field(default_factory=dict)
    node_type: str = "Action"
    condition: dict = field(default_factory=dict)
    children: list = field(default_factory=list)
    else_children: list = field(default_factory=list)
    variable: str = ""
    iterable: list = field(default_factory=list)

    def as_dict(self):
        return {
            "id": self.identifier, "object": self.object_ref, "operation": self.operation,
            "parameters": dict(self.parameters), "preconditions": list(self.preconditions),
            "postconditions": list(self.postconditions), "recovery": list(self.recovery),
            "branches": list(self.branches), "loop": dict(self.loop), "type": self.node_type,
            "condition": dict(self.condition), "children": list(self.children),
            "else": list(self.else_children), "variable": self.variable, "iterable": list(self.iterable),
        }


class DeterministicGoalCompiler:
    """通用 GoalCompiler：自然语言 -> 动作/对象/参数/前置条件/结果条件 -> 可学习程序。

    少数成熟任务仍有快速程序，但未知目标不会返回空计划：它会进入观察、候选子目标、
    低风险尝试、验证、成功轨迹编译的通用闭环。因此能力边界不再取决于 rename/search 等正则。
    """

    CONNECTOR_RE = re.compile(r"(?:\s*(?:→|->|然后|再|并且|并|之后|以后|接着|随后|，|,|；|;|\n|\band\b|\bthen\b)\s*)+", re.IGNORECASE)
    POLITE_PREFIX_RE = re.compile(r"^(?:请|请你|麻烦|帮我|请帮我|please|could\s+you|would\s+you)\s*", re.IGNORECASE)
    QUOTE_RE = re.compile(r'["“”‘’\']([^"“”‘’\']+)["“”‘’\']')
    RANGE_RE = re.compile(r"\b([A-Z]{1,3}\d{1,7}\s*:\s*[A-Z]{1,3}\d{1,7})\b", re.IGNORECASE)
    FILE_RE = re.compile(r"([\w\-. ()\[\]{}\u3400-\u9fff]+\.[A-Za-z0-9]{1,12})")

    # 这些是“意图识别规则”，不是动作空间。一个意图可展开成任意数量的子目标。
    INTENT_RULES = (
        ("rename", re.compile(r"(?:把|将)?\s*(?P<target>.+?)\s*(?:重命名|改名|rename)\s*(?:为|成|to)\s*(?P<value>[^，,；;\n]+)", re.IGNORECASE)),
        ("close_window", re.compile(r"(?:关闭|关掉|close)\s*(?:当前|this|current)?\s*(?:窗口|应用|程序|window|app|application)?", re.IGNORECASE)),
        ("spreadsheet_sum", re.compile(r"(?=.*(?:excel|表格|电子表格|spreadsheet))(?=.*(?:总和|合计|求和|sum|计算)).*", re.IGNORECASE)),
    )

    LEGACY_CONCEPTS = (
        ("open", ("打开", "进入", "open", "go to", "navigate")),
        ("click", ("点击", "单击", "click", "press")),
        ("type", ("输入", "键入", "填写", "type")),
        ("search", ("搜索", "检索", "search")),
        ("find", ("查找", "寻找", "find")),
        ("select", ("选择", "选中", "select")),
        ("save", ("保存", "另存", "save")),
    )
    COMPACT_TRANSITIONS = {
        ("open", "search"), ("open", "find"), ("open", "click"),
        ("click", "type"), ("click", "select"), ("select", "type"),
    }

    # 只用于给开放式动作框架赋予语义和 capability；它不是“可执行目标白名单”。
    ACTION_SEMANTICS = (
        ("external_send", ("发送", "发出", "发邮件", "邮件", "email", "mail", "message", "share")),
        ("aggregate", ("求和", "合计", "汇总", "统计", "计算", "sum", "total", "calculate", "aggregate")),
        ("filesystem_write", ("重命名", "改名", "保存", "写入文件", "rename", "save", "write file")),
        ("software_install", ("安装", "卸载", "install", "uninstall")),
        ("financial_commit", ("支付", "购买", "下单", "付款", "pay", "purchase", "buy", "checkout")),
        ("credential_input", ("登录", "密码", "验证码", "sign in", "login", "password", "credential")),
        ("document_write", ("填写", "输入", "编辑", "写", "创建", "type", "edit", "write", "create")),
        ("retrieve", ("查找", "搜索", "获取", "查看", "find", "search", "get", "read", "look up")),
        ("navigate", ("打开", "进入", "切换", "选择", "点击", "open", "navigate", "select", "click")),
    )

    @staticmethod
    def _clean(value):
        return str(value or "").strip(" ：:，,。;；\t\r\n ")

    @classmethod
    def _quoted(cls, text):
        return [cls._clean(value) for value in cls.QUOTE_RE.findall(str(text or "")) if cls._clean(value)]

    @classmethod
    def _node(cls, number, operation, action, payload="", target="", value="", depends_on=None,
              preconditions=None, gui=None, verify=None, recovery=None, source="", parameters=None, max_retries=2,
              capabilities=None, frame=None, generic=False):
        identifier = "g{:02d}".format(number)
        object_ref = cls._clean(target) or cls._clean(payload) or str(operation)
        verify_items = list(verify or [])
        typed = TaskDSLNode(
            identifier=identifier, object_ref=object_ref, operation=str(operation), parameters=dict(parameters or {}),
            preconditions=list(preconditions or []), postconditions=verify_items, recovery=list(recovery or []),
            branches=list((frame or {}).get("branches", [])) if isinstance(frame, dict) else [],
            loop={"max_retries": max(0, int(max_retries))},
        ).as_dict()
        typed.update({
            "action": str(action), "payload": cls._clean(payload), "target": cls._clean(target), "value": cls._clean(value),
            "depends_on": list(depends_on or []), "gui": list(gui or []), "verify": verify_items,
            "capabilities": sorted(set(str(value) for value in (capabilities or []) if value)),
            "frame": dict(frame or {}), "generic": bool(generic),
            "max_retries": max(0, int(max_retries)), "source": cls._clean(source),
        })
        return typed

    @classmethod
    def _chain(cls, specs, source):
        result = []
        previous = []
        for spec in specs:
            local = dict(spec)
            local_source = local.pop("source", source)
            node = cls._node(len(result) + 1, depends_on=previous, source=local_source, **local)
            result.append(node)
            previous = [node["id"]]
        return result

    @classmethod
    def _compile_rename(cls, source, match):
        target = cls._clean(match.group("target"))
        target = re.sub(r"^(?:(?:桌面(?:上的?|\s+))|(?:desktop\s+))", "", target, flags=re.IGNORECASE).strip() or "桌面上的文件"
        value = cls._clean(match.group("value"))
        quoted = cls._quoted(value)
        if quoted:
            value = quoted[-1]
        file_match = cls.FILE_RE.search(value)
        if file_match:
            value = file_match.group(1).strip()
        return cls._chain([
            {"operation":"locate_object", "action":"find", "payload":target, "target":target,
             "preconditions":[{"desktop":"default"}],
             "gui":[{"op":"uia_locate", "query":target, "types":["ListItem","TreeItem","DataItem"]}],
             "verify":[{"object_present":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"open_desktop_if_needed"}]},
            {"operation":"select_object", "action":"select", "payload":target, "target":target,
             "preconditions":[{"object_present":target}],
             "gui":[{"op":"click_semantic", "query":target}],
             "verify":[{"selected_or_focused":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"relocate", "query":target}]},
            {"operation":"request_rename", "action":"rename", "payload":target, "target":target,
             "preconditions":[{"selected_or_focused":target}],
             "gui":[{"op":"key", "vk":0x71, "name":"F2"}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"right_click_then_menu", "query":"重命名 rename"},{"op":"refresh_uia"}]},
            {"operation":"acquire_editor", "action":"find", "payload":"rename editor", "target":"rename editor",
             "preconditions":[{"rename_requested":True}],
             "gui":[{"op":"uia_locate", "types":["Edit","Document"]}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"press_f2_again"},{"op":"refresh_uia"}]},
            {"operation":"replace_text", "action":"type", "payload":value, "value":value,
             "preconditions":[{"focused_type_in":["Edit","Document"]}],
             "gui":[{"op":"replace_focused_text", "text":value}],
             "verify":[{"focused_contains":value}],
             "recovery":[{"op":"refocus_editor"},{"op":"retry", "limit":2}]},
            {"operation":"commit_edit", "action":"key", "payload":"Enter", "value":value,
             "preconditions":[{"focused_contains":value}],
             "gui":[{"op":"key", "vk":0x0D, "name":"Enter"}],
             "verify":[{"editing_finished":True}],
             "recovery":[{"op":"refresh_uia"},{"op":"retry", "limit":1}],
             "capabilities":["filesystem_write"]},
            {"operation":"verify_object", "action":"verify", "payload":value, "target":value,
             "preconditions":[{"editing_finished":True}],
             "gui":[{"op":"observe"}],
             "verify":[{"object_present":value},{"old_name_absent":target}],
             "recovery":[{"op":"refresh_uia"},{"op":"relocate", "query":value}]},
        ], source)

    @classmethod
    def _compile_close(cls, source):
        return cls._chain([
            {"operation":"close_window", "action":"close", "payload":"current window", "target":"current window",
             "preconditions":[{"foreground_window":True},{"desktop":"default"}],
             "gui":[{"op":"key", "vk":0x73, "modifiers":[0x12], "name":"Alt+F4"}],
             "verify":[{"foreground_hwnd_changed":True}],
             "recovery":[{"op":"observe"},{"op":"locate_close_button"}], "max_retries":1},
        ], source)

    @classmethod
    def _compile_spreadsheet_sum(cls, source):
        match = cls.RANGE_RE.search(source)
        cell_range = re.sub(r"\s+", "", match.group(1).upper()) if match else ""
        if not cell_range:
            return []
        formula = "=SUM({})".format(cell_range)
        return cls._chain([
            {"operation":"ensure_application", "action":"open", "payload":"Excel", "target":"Excel",
             "preconditions":[{"desktop":"default"}],
             "gui":[{"op":"ensure_application", "name":"Excel"}],
             "verify":[{"application":"Excel"}],
             "recovery":[{"op":"windows_search", "text":"Excel"}]},
            {"operation":"formula_mode", "action":"key", "payload":"F2", "target":"active cell",
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"key", "vk":0x71, "name":"F2"}],
             "verify":[{"focused_type_in":["Edit","Document"]}],
             "recovery":[{"op":"locate_formula_bar"},{"op":"refresh_uia"}]},
            {"operation":"replace_text", "action":"type", "payload":formula, "value":formula,
             "parameters":{"formula":formula, "range":cell_range},
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"replace_focused_text", "text":formula}],
             "verify":[{"focused_contains":formula}],
             "recovery":[{"op":"press_f2_again"},{"op":"retry", "limit":2}]},
            {"operation":"commit_formula", "action":"key", "payload":"Enter", "value":formula,
             "preconditions":[{"focused_contains":formula}],
             "gui":[{"op":"key", "vk":0x0D, "name":"Enter"}],
             "verify":[{"structured_change":True}],
             "recovery":[{"op":"refresh_uia"},{"op":"retry", "limit":1}],
             "capabilities":["document_write"]},
            {"operation":"verify_formula_result", "action":"verify", "payload":cell_range, "target":cell_range,
             "preconditions":[{"application":"Excel"}],
             "gui":[{"op":"observe"}],
             "verify":[{"structured_change":True},{"formula_committed":formula}],
             "recovery":[{"op":"refresh_uia"},{"op":"inspect_formula_bar"}]},
        ], source)

    @classmethod
    def _concept_patterns(cls):
        patterns = []
        for kind, phrases in cls.LEGACY_CONCEPTS:
            for phrase in phrases:
                if re.search(r"[A-Za-z]", phrase):
                    body = r"\s+".join(re.escape(part) for part in phrase.split())
                    pattern = re.compile(r"(?<![A-Za-z0-9_])" + body + r"(?![A-Za-z0-9_])", re.IGNORECASE)
                else:
                    pattern = re.compile(re.escape(phrase), re.IGNORECASE)
                patterns.append((kind, phrase, pattern))
        return patterns

    @classmethod
    def _first_concept(cls, text, start=0):
        best = None
        for kind, phrase, pattern in cls._concept_patterns():
            match = pattern.search(text, start)
            if match:
                candidate = (match.start(), match.end(), kind, phrase)
                if best is None or candidate[0] < best[0] or (candidate[0] == best[0] and candidate[1] > best[1]):
                    best = candidate
        return best

    @classmethod
    def _concept_at(cls, text, position):
        for kind, phrase, pattern in cls._concept_patterns():
            match = pattern.match(text, position)
            if match:
                return match.start(), match.end(), kind, phrase
        return None

    @classmethod
    def _next_legacy_boundary(cls, text, payload_start, previous):
        for connector in cls.CONNECTOR_RE.finditer(text, payload_start):
            action = cls._concept_at(text, connector.end())
            if action:
                return connector.start(), action
        for kind, phrase, pattern in cls._concept_patterns():
            if re.search(r"[A-Za-z]", phrase):
                continue
            for match in pattern.finditer(text, payload_start):
                if (previous, kind) not in cls.COMPACT_TRANSITIONS:
                    continue
                payload = text[payload_start:match.start()].strip()
                if payload and len(payload) <= 32:
                    return match.start(), (match.start(), match.end(), kind, phrase)
        return None

    @classmethod
    def _compile_legacy(cls, source):
        urls = re.findall(r"https?://[^\s，。；;]+", source, re.IGNORECASE)
        quoted = cls._quoted(source)
        first = cls._first_concept(source)
        if first is None:
            if urls:
                specs = [{"operation":"ensure_url", "action":"open", "payload":urls[0], "target":urls[0],
                          "preconditions":[{"browser":True}], "gui":[{"op":"navigate", "url":urls[0]}],
                          "verify":[{"url_or_page_changed":True}], "recovery":[{"op":"focus_address_bar"}]}]
                return cls._chain(specs, source)
            if quoted:
                specs = [{"operation":"replace_text", "action":"type", "payload":quoted[0], "value":quoted[0],
                          "preconditions":[{"focused_editable":True}], "gui":[{"op":"type", "text":quoted[0]}],
                          "verify":[{"focused_contains":quoted[0]}], "recovery":[{"op":"refresh_uia"}]}]
                return cls._chain(specs, source)
            return []
        raw = []
        current = first
        while current is not None:
            position, end, action, phrase = current
            boundary = cls._next_legacy_boundary(source, end, action)
            if boundary is None:
                payload_end, nxt = len(source), None
            else:
                payload_end, nxt = boundary
            segment = cls._clean(source[end:payload_end])
            locals_quoted = cls._quoted(segment)
            payload = locals_quoted[-1] if locals_quoted else segment
            payload = re.sub(r"^(?:在|到|为|内容为|关键词为|关键字为|the\s+|a\s+|an\s+)\s*", "", payload, flags=re.IGNORECASE).strip()
            raw.append((action, payload, source[position:payload_end]))
            current = nxt
        specs = []
        operation_map = {
            "open":"ensure_application", "click":"activate_control", "type":"replace_text",
            "search":"search", "find":"find", "select":"select_object", "save":"save",
        }
        for action, payload, local_source in raw:
            operation = operation_map[action]
            preconditions = [{"desktop":"default"}]
            gui = [{"op":operation, "target":payload}]
            verify = [{"semantic_or_structure_changed":True}]
            recovery = [{"op":"refresh_uia"},{"op":"relocate", "query":payload}]
            if action in ("type","search","find"):
                preconditions.append({"editable_or_locatable":True})
                verify = [{"payload_observed":payload}] if payload else verify
            specs.append({"operation":operation, "action":action, "payload":payload, "target":payload,
                          "value":payload if action in ("type","search","find") else "",
                          "preconditions":preconditions, "gui":gui, "verify":verify, "recovery":recovery,
                          "source":local_source})
        return cls._chain(specs, source)

    @classmethod
    def _semantic_action(cls, clause):
        lowered = str(clause or "").lower()
        matches = []
        for category, phrases in cls.ACTION_SEMANTICS:
            for phrase in phrases:
                position = lowered.find(phrase.lower())
                if position >= 0:
                    matches.append((position, -len(phrase), category, clause[position:position + len(phrase)]))
        if matches:
            _, _, category, phrase = sorted(matches)[0]
            return category, cls._clean(phrase), lowered.find(str(phrase).lower())
        # 开放式兜底：不认识谓词也照样建立 achieve 框架，而不是返回空图。
        units = semantic_units(clause)
        return "achieve", (units[0] if units else "achieve"), 0

    @staticmethod
    def _capabilities_for_category(category):
        mapping = {
            "external_send": ["external_send"], "filesystem_write": ["filesystem_write"],
            "software_install": ["software_install"], "financial_commit": ["financial_commit"],
            "credential_input": ["credential_input"], "document_write": ["document_write"],
            "aggregate": ["document_write"], "retrieve": ["network_read"],
        }
        return list(mapping.get(str(category), []))

    @classmethod
    def _parse_frame(cls, clause):
        clause = cls._clean(clause)
        category, action, action_position = cls._semantic_action(clause)
        lowered = clause.lower()
        parameters = {}
        quoted = cls._quoted(clause)
        urls = re.findall(r"https?://[^\s，。；;]+", clause, re.IGNORECASE)
        emails = re.findall(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}", clause)
        ranges = [re.sub(r"\s+", "", value.upper()) for value in cls.RANGE_RE.findall(clause)]
        files = [match.group(1).strip() for match in cls.FILE_RE.finditer(clause)]
        if quoted: parameters["quoted_values"] = quoted
        if urls: parameters["urls"] = urls
        if emails: parameters["addresses"] = emails
        if ranges: parameters["ranges"] = ranges
        if files: parameters["files"] = files

        # 通用角色标记：动作前的 给/向 是受事者，在...中 是位置，为/成/to/with 后是值。
        prefix = clause[:max(0, action_position)]
        recipient_match = re.search(r"(?:给|向|to\s+)([^，,；;]+)$", prefix, re.IGNORECASE)
        if recipient_match:
            parameters["recipient"] = cls._clean(recipient_match.group(1))
        location_match = re.search(r"(?:在|于|in\s+|inside\s+)(.+?)(?:中|里|内)?$", prefix, re.IGNORECASE)
        if location_match:
            parameters["location"] = cls._clean(location_match.group(1))
        value_match = re.search(r"(?:为|成|内容为|值为|to|with)\s*[:：]?\s*(.+)$", clause[max(0, action_position + len(action)):], re.IGNORECASE)
        if value_match:
            parameters["value"] = cls._clean(value_match.group(1))

        after = cls._clean(clause[max(0, action_position + len(action)):])
        after = re.sub(r"^(?:给|向|在|于|到|把|将|the|a|an)\s*", "", after, flags=re.IGNORECASE)
        object_text = after
        if not object_text and category == "external_send":
            object_text = "邮件" if any(value in str(action).lower() for value in ("mail", "email", "邮件")) else "消息"
        if not object_text:
            object_text = str(parameters.get("location") or parameters.get("recipient") or "")
        if not object_text:
            # 去掉已识别动作后保留完整语义对象；未知目标仍有可检索 query。
            object_text = cls._clean(lowered.replace(str(action).lower(), " ", 1)) or clause
        result_terms = list(dict.fromkeys(
            [value for value in quoted + emails + ranges + files if value]
            + [unit for unit in semantic_units(object_text) if unit != str(action).lower()]
        ))
        confidence = 0.30 + (0.30 if category != "achieve" else 0.0) + (0.20 if object_text else 0.0) + (0.15 if parameters else 0.0)
        return {
            "action": action, "category": category, "object": cls._clean(object_text),
            "parameters": parameters, "preconditions": [{"desktop": "default"}, {"context_observable": True}],
            "result_conditions": [{"semantic_or_structure_changed": True}, {"goal_terms": result_terms}],
            "capabilities": cls._capabilities_for_category(category), "confidence": clamp(confidence, 0.0, 0.98),
            "source": clause,
        }

    @classmethod
    def _compile_generic(cls, source):
        clauses = [cls._clean(value) for value in cls.CONNECTOR_RE.split(source) if cls._clean(value)] or [cls._clean(source)]
        frames = [cls._parse_frame(clause) for clause in clauses]
        specs = []
        for frame_index, frame in enumerate(frames):
            target = frame["object"] or frame["source"]
            query = " ".join(value for value in (frame["action"], target) if value)
            common = {"frame": frame, "generic": True, "source": frame["source"]}
            specs.extend([
                dict(common, operation="observe_context", action="observe", payload=query, target=target,
                     preconditions=[{"desktop":"default"}],
                     gui=[{"op":"shallow_observe"},{"op":"deep_observe_on_anomaly"}],
                     verify=[{"context_observed":True}], recovery=[{"op":"wait_for_stable_window"}]),
                dict(common, operation="locate_target", action="locate", payload=query, target=target,
                     preconditions=frame["preconditions"],
                     gui=[{"op":"rank_semantic_controls", "query":query},{"op":"propose_candidate_subgoals"}],
                     verify=[{"candidate_or_context_found":True}],
                     recovery=[{"op":"broaden_uia"},{"op":"alternate_control"},{"op":"observe"}]),
                dict(common, operation="candidate_subgoal", action="adapt", payload=frame["source"], target=target,
                     parameters=frame["parameters"], preconditions=frame["preconditions"],
                     gui=[{"op":"try_lowest_risk_candidate", "query":query},{"op":"observe_result"}],
                     verify=[{"structured_progress":True}],
                     recovery=[{"op":"observe"},{"op":"undo_if_possible"},{"op":"alternate_candidate"}]),
                dict(common, operation="commit_candidate", action="commit", payload=frame["source"], target=target,
                     parameters=frame["parameters"], preconditions=[{"candidate_verified":True}],
                     gui=[{"op":"commit_only_after_capability_check"}], verify=frame["result_conditions"],
                     recovery=[{"op":"do_not_repeat_commit"},{"op":"observe"}],
                     capabilities=frame["capabilities"], max_retries=1),
                dict(common, operation="verify_result", action="verify", payload=query, target=target,
                     preconditions=[{"attempt_observed":True}], gui=[{"op":"observe"}],
                     verify=frame["result_conditions"], recovery=[{"op":"alternate_candidate"},{"op":"observe"}]),
                dict(common, operation="compile_success", action="learn", payload=frame["source"], target=target,
                     preconditions=[{"result_stable":True}], gui=[{"op":"compile_trace_to_program"}],
                     verify=[{"program_reusable":True}], recovery=[{"op":"retain_trace_for_sleep"}]),
            ])
        return cls._chain(specs, source)

    @classmethod
    def compile(cls, text):
        text = str(text or "").strip()
        if not text:
            return []
        source = cls.POLITE_PREFIX_RE.sub("", text).strip()
        for intent, pattern in cls.INTENT_RULES:
            match = pattern.search(source)
            if not match:
                continue
            if intent == "rename":
                return cls._compile_rename(source, match)
            if intent == "close_window":
                return cls._compile_close(source)
            if intent == "spreadsheet_sum":
                result = cls._compile_spreadsheet_sum(source)
                if result:
                    return result
        legacy = cls._compile_legacy(source)
        return legacy if legacy else cls._compile_generic(source)

    @staticmethod
    def text_payloads(steps):
        result = []
        for step in steps or []:
            for key in ("value", "payload", "target"):
                value = str(step.get(key, "")).strip()
                if value and value not in ("Enter", "F2", "current window", "rename editor") and value not in result:
                    result.append(value)
        return result

    @classmethod
    def graph(cls, text):
        """公开的结构化表示，便于测试、睡眠反思和未来技能程序化。"""
        return {"version": 3, "schema": "object→operation→parameters→preconditions→postconditions→verification→recovery→branch→loop", "goal": str(text or ""), "nodes": cls.compile(text)}


class StructuredGoalCompiler(DeterministicGoalCompiler):
    """GoalCompiler 2.0：先构造程序 AST，再降低为可执行 TaskDSL 字节码。

    关键词只用于识别原子谓词；Sequence/If/Else/While/ForEach/Until/Retry/
    Variable/ObjectRef/Assert 都是有类型、有边界、可解释的节点，不再靠中文连接词
    假装控制流。未知动作也进入同一套 Operator DSL，而不是退化成随意输入文本。
    """

    VERSION = 4
    TYPE_NAMES = {"Sequence", "If", "Else", "While", "ForEach", "Until", "Retry", "Variable", "ObjectRef", "Assert", "Action"}
    ACTION_KIND = {
        "Observe":"observe", "Locate":"locate", "Focus":"focus", "Activate":"click", "EnterText":"type",
        "PressKey":"key", "SwitchApplication":"open", "Verify":"verify", "Assert":"verify",
        "SetVariable":"variable", "LoopEnd":"control", "ForEach":"control",
    }
    NUMBER_WORDS = {"一":1, "二":2, "两":2, "三":3, "四":4, "五":5, "六":6, "七":7, "八":8, "九":9, "十":10}

    @classmethod
    def _ast(cls, node_type, **values):
        if node_type not in cls.TYPE_NAMES:
            raise ValueError("未知 TaskDSL 节点类型：{}".format(node_type))
        result = {
            "type": node_type, "source": cls._clean(values.pop("source", "")),
            "children": list(values.pop("children", []) or []), "else": list(values.pop("else_children", []) or []),
        }
        result.update(values)
        return result

    @classmethod
    def _action(cls, operator, target="", value="", parameters=None, preconditions=None, effects=None,
                verification=None, recovery=None, capabilities=None, source="", node_type="Action"):
        return cls._ast(
            node_type, source=source, operator=str(operator), object_ref=cls._clean(target), value=cls._clean(value),
            parameters=dict(parameters or {}), preconditions=list(preconditions or [{"desktop":"default"}]),
            effects=list(effects or []), verification=list(verification or []), recovery=list(recovery or []),
            capabilities=sorted(set(str(item) for item in (capabilities or []) if item)),
        )

    @classmethod
    def _sequence(cls, children, source=""):
        flattened = []
        for child in children:
            if child and child.get("type") == "Sequence":
                flattened.extend(child.get("children", []))
            elif child:
                flattened.append(child)
        return cls._ast("Sequence", source=source, children=flattened)

    @classmethod
    def _split_top_level(cls, text):
        text = str(text or "").strip()
        strong = ("→", "->", "；", ";", "\n", "然后", "接着", "随后", "之后", "并且", "再", "并")
        quotes = {"“":"”", "‘":"’", '"':'"', "'":"'"}
        result = []; start = 0; quote_end = ""; depth = 0; index = 0
        while index < len(text):
            char = text[index]
            if quote_end:
                if char == quote_end: quote_end = ""
                index += 1; continue
            if char in quotes:
                quote_end = quotes[char]; index += 1; continue
            if char in "([{（【": depth += 1; index += 1; continue
            if char in ")] }）】".replace(" ", ""):
                depth = max(0, depth - 1); index += 1; continue
            token = next((value for value in strong if depth == 0 and text.startswith(value, index)), None)
            if token:
                left = cls._clean(text[start:index]); right = cls._clean(text[index + len(token):])
                # “合并/并非”等词内字符不是控制流连接符。
                if token == "并" and (text[max(0, index - 1):index + 2] in ("合并", "并非", "并行")):
                    index += len(token); continue
                if left and right:
                    result.append(left); start = index + len(token); index = start; continue
            index += 1
        tail = cls._clean(text[start:])
        if tail: result.append(tail)
        return result if len(result) > 1 else [text]

    @classmethod
    def _condition(cls, text):
        source = cls._clean(text)
        lowered = source.lower()
        negate = bool(re.search(r"(?:不|没有|未|not\b|without\b)", lowered))
        value = re.sub(r"^(?:浏览器|当前)?(?:页面|界面|窗口)?(?:中|上)?\s*(?:显示|出现|包含|存在|有|shows?|contains?|has)\s*", "", source, flags=re.IGNORECASE)
        value = re.sub(r"^(?:不|没有|未|not\s+)", "", value, flags=re.IGNORECASE)
        return {"type":"text_present", "value":cls._clean(value) or source, "negate":negate, "source":source}

    @classmethod
    def _parse_if(cls, text):
        patterns = (
            re.compile(r"^(?:如果|若|假如)\s*(?P<condition>.+?)[，,]?\s*(?:就|那么|则)\s*(?P<then>.+?)(?:[，,]?\s*否则\s*(?P<else>.+))?$", re.IGNORECASE),
            re.compile(r"^if\s+(?P<condition>.+?)\s+then\s+(?P<then>.+?)(?:\s+else\s+(?P<else>.+))?$", re.IGNORECASE),
        )
        for pattern in patterns:
            match = pattern.match(text)
            if not match: continue
            then_node = cls._parse_statement(match.group("then"))
            else_text = match.groupdict().get("else") or ""
            else_node = cls._parse_statement(else_text) if else_text else cls._sequence([], source="")
            else_wrapper = cls._ast("Else", source=else_text, children=list(else_node.get("children", [else_node]) if else_node.get("type") == "Sequence" else [else_node]))
            return cls._ast(
                "If", source=text, condition=cls._condition(match.group("condition")),
                children=list(then_node.get("children", []) if then_node.get("type") == "Sequence" else [then_node]),
                else_children=[else_wrapper],
            )
        return None

    @classmethod
    def _parse_loop(cls, text):
        foreach = re.match(r"^(?:对|针对)?\s*(?:每个|所有)\s*(?P<object>[^，,:：]+?)\s*(?:都|执行|进行|[:：，,])\s*(?P<body>.+)$", text, re.IGNORECASE)
        if foreach:
            variable = re.sub(r"\s+", "_", cls._clean(foreach.group("object"))) or "item"
            body = cls._parse_statement(foreach.group("body"))
            children = list(body.get("children", []) if body.get("type") == "Sequence" else [body])
            return cls._ast("ForEach", source=text, variable=variable, iterable={"object_query":foreach.group("object")}, children=children, max_iterations=32)
        foreach_en = re.match(r"^for\s+each\s+(?P<object>.+?)\s+(?:do\s+)?(?P<body>.+)$", text, re.IGNORECASE)
        if foreach_en:
            body = cls._parse_statement(foreach_en.group("body")); children = list(body.get("children", []) if body.get("type") == "Sequence" else [body])
            return cls._ast("ForEach", source=text, variable="item", iterable={"object_query":foreach_en.group("object")}, children=children, max_iterations=32)
        while_match = re.match(r"^(?:当|只要)\s*(?P<condition>.+?)(?:时|期间)[，,]?\s*(?:就|则|重复)?\s*(?P<body>.+)$", text, re.IGNORECASE)
        if not while_match:
            while_match = re.match(r"^while\s+(?P<condition>.+?)\s+(?:do\s+)?(?P<body>.+)$", text, re.IGNORECASE)
        if while_match:
            body = cls._parse_statement(while_match.group("body")); children = list(body.get("children", []) if body.get("type") == "Sequence" else [body])
            return cls._ast("While", source=text, condition=cls._condition(while_match.group("condition")), children=children, max_iterations=16)
        until_match = re.match(r"^(?:重复\s*)?(?P<body>.+?)\s*(?:直到|直至|until)\s*(?P<condition>.+)$", text, re.IGNORECASE)
        if until_match:
            body = cls._parse_statement(until_match.group("body")); children = list(body.get("children", []) if body.get("type") == "Sequence" else [body])
            return cls._ast("Until", source=text, condition=cls._condition(until_match.group("condition")), children=children, max_iterations=16)
        return None

    @classmethod
    def _parse_variable(cls, text):
        match = re.match(r"^(?:设置|令|设)\s*([A-Za-z_\u3400-\u9fff][\w\u3400-\u9fff]*)\s*(?:=|为|成)\s*(.+)$", text, re.IGNORECASE)
        if match:
            return cls._ast("Variable", source=text, variable=match.group(1), value=cls._clean(match.group(2)), children=[])
        match = re.match(r"^把\s*(.+?)\s*(?:记为|保存为变量|赋给)\s*([A-Za-z_\u3400-\u9fff][\w\u3400-\u9fff]*)$", text, re.IGNORECASE)
        if match:
            return cls._ast("Variable", source=text, variable=match.group(2), value=cls._clean(match.group(1)), children=[])
        match = re.match(r"^set\s+([A-Za-z_]\w*)\s+(?:to|=)\s+(.+)$", text, re.IGNORECASE)
        if match:
            return cls._ast("Variable", source=text, variable=match.group(1), value=cls._clean(match.group(2)), children=[])
        return None

    @classmethod
    def _parse_retry(cls, text):
        match = re.match(r"^(?:重试|重做|retry)\s*(?P<count>\d+|[一二两三四五六七八九十])?\s*(?:次|times?)?\s*[:：，,]?\s*(?P<body>.+)$", text, re.IGNORECASE)
        if not match:
            match = re.match(r"^(?P<body>.+?)\s*(?:重试|重做|retry)\s*(?P<count>\d+|[一二两三四五六七八九十])?\s*(?:次|times?)?$", text, re.IGNORECASE)
        if not match: return None
        count_text = match.group("count") or "2"
        count = int(count_text) if str(count_text).isdigit() else cls.NUMBER_WORDS.get(count_text, 2)
        body_text = cls._clean(match.group("body"))
        if not body_text: return None
        body = cls._parse_statement(body_text); children = list(body.get("children", []) if body.get("type") == "Sequence" else [body])
        return cls._ast("Retry", source=text, children=children, max_iterations=max(1, min(10, count)))

    @classmethod
    def _parse_assert(cls, text):
        match = re.match(r"^(?:确保|确认|验证|断言|assert|verify|ensure)\s*[:：]?\s*(.+)$", text, re.IGNORECASE)
        if not match: return None
        condition = cls._condition(match.group(1))
        return cls._ast("Assert", source=text, condition=condition, operator="Verify", object_ref=condition.get("value", ""), parameters={"verifier":"predicate", "condition":condition}, children=[])

    @classmethod
    def _compile_mail_ast(cls, source):
        recipient_match = re.search(r"(?:给|向)\s*(.+?)\s*(?:发送|发出|发一封|寄出|发|send\s+(?:an?\s+)?(?:email|message)\s+to)", source, re.IGNORECASE)
        if not recipient_match:
            recipient_match = re.search(r"(?:to|recipient)\s*[:：]?\s*([^，,；;]+)", source, re.IGNORECASE)
        recipient = cls._clean(recipient_match.group(1)) if recipient_match else "收件人"
        quotes = cls._quoted(source)
        content_match = re.search(r"(?:内容|正文|消息)(?:为|是)?\s*[:：]?\s*(.+)$", source, re.IGNORECASE)
        content = quotes[-1] if quotes else cls._clean(content_match.group(1)) if content_match else ""
        subject_match = re.search(r"(?:主题|subject)(?:为|是)?\s*[:：]?\s*([^，,；;]+)", source, re.IGNORECASE)
        subject = cls._clean(subject_match.group(1)) if subject_match else ""
        app = "邮件应用" if any(value in source.lower() for value in ("邮件", "email", "mail")) else "消息应用"
        common = {"recipient":recipient, "content":content, "subject":subject}
        children = [
            cls._action("SwitchApplication", app, parameters=common, effects=[{"application_ready":app}], source=source),
            cls._action("Locate", "收件人", parameters=common, effects=[{"object_present":"收件人"}], source=source, node_type="ObjectRef"),
            cls._action("Focus", "收件人", parameters=common, effects=[{"focused":"收件人"}], source=source),
            cls._action("EnterText", "收件人", recipient, parameters=dict(common, role="recipient"), effects=[{"field_value":{"role":"recipient", "value":recipient}}], source=source),
        ]
        if subject:
            children.extend([
                cls._action("Locate", "主题", parameters=common, source=source, node_type="ObjectRef"),
                cls._action("Focus", "主题", parameters=common, source=source),
                cls._action("EnterText", "主题", subject, parameters=dict(common, role="subject"), source=source),
            ])
        children.extend([
            cls._action("Locate", "正文 消息输入框", parameters=common, source=source, node_type="ObjectRef"),
            cls._action("Focus", "正文 消息输入框", parameters=common, source=source),
            cls._action("EnterText", "正文 消息输入框", content, parameters=dict(common, role="content"), effects=[{"field_value":{"role":"content", "value":content}}], source=source),
            cls._action("Locate", "发送 send", parameters=common, source=source, node_type="ObjectRef"),
            cls._action("Activate", "发送 send", parameters=common, effects=[{"message_commit_requested":True}], capabilities=["external_send"], source=source),
            cls._action("Verify", recipient, parameters=dict(common, verifier="message_sent"), verification=[{"message_sent":{"recipient":recipient, "content":content}}], source=source, node_type="Assert"),
        ])
        return cls._sequence(children, source)

    @classmethod
    def _compile_rename_ast(cls, source):
        match = next((pattern.search(source) for intent, pattern in cls.INTENT_RULES if intent == "rename" and pattern.search(source)), None)
        if not match: return None
        target = re.sub(r"^(?:(?:桌面(?:上的?|\s+))|(?:desktop\s+))", "", cls._clean(match.group("target")), flags=re.IGNORECASE).strip()
        value = cls._clean(match.group("value")); quoted = cls._quoted(value)
        if quoted: value = quoted[-1]
        found = cls.FILE_RE.search(value)
        if found: value = found.group(1).strip()
        params = {"old_name":target, "new_name":value, "location":"desktop" if "桌面" in source or "desktop" in source.lower() else "current"}
        return cls._sequence([
            cls._action("Locate", target, parameters=params, source=source, node_type="ObjectRef"),
            cls._action("Focus", target, parameters=params, source=source),
            cls._action("PressKey", target, "F2", parameters=dict(params, vk=0x71, modifiers=[]), effects=[{"rename_editor_requested":True}], source=source),
            cls._action("Focus", "rename editor", parameters=params, source=source),
            cls._action("EnterText", "rename editor", value, parameters=params, source=source),
            cls._action("PressKey", "rename editor", "Enter", parameters=dict(params, vk=0x0D, modifiers=[]), capabilities=["filesystem_write"], source=source),
            cls._action("Verify", value, parameters=dict(params, verifier="file_renamed"), verification=[{"file_renamed":params}], source=source, node_type="Assert"),
        ], source)

    @classmethod
    def _compile_spreadsheet_ast(cls, source):
        if not (any(value in source.lower() for value in ("excel", "表格", "电子表格", "spreadsheet")) and any(value in source.lower() for value in ("求和", "合计", "总和", "sum", "计算"))):
            return None
        match = cls.RANGE_RE.search(source)
        if not match: return None
        cell_range = re.sub(r"\s+", "", match.group(1).upper()); formula = "=SUM({})".format(cell_range)
        params = {"range":cell_range, "formula":formula, "verifier":"spreadsheet_formula"}
        return cls._sequence([
            cls._action("SwitchApplication", "Excel", parameters=params, source=source),
            cls._action("PressKey", "active cell", "F2", parameters=dict(params, vk=0x71, modifiers=[]), source=source),
            cls._action("EnterText", "active cell", formula, parameters=params, source=source),
            cls._action("PressKey", "active cell", "Enter", parameters=dict(params, vk=0x0D, modifiers=[]), capabilities=["document_write"], source=source),
            cls._action("Verify", cell_range, parameters=params, verification=[{"formula_committed":formula}], source=source, node_type="Assert"),
        ], source)

    @classmethod
    def _compile_close_ast(cls, source):
        if not re.search(r"(?:关闭|关掉|close)\s*(?:当前|this|current)?\s*(?:窗口|应用|程序|window|app|application)?", source, re.IGNORECASE):
            return None
        params = {"vk":0x73, "modifiers":[0x12], "verifier":"window_closed"}
        return cls._sequence([
            cls._action("PressKey", "current window", "Alt+F4", parameters=params, source=source),
            cls._action("Verify", "current window", parameters=params, verification=[{"window_destroyed":True}], source=source, node_type="Assert"),
        ], source)

    @classmethod
    def _compile_generic_ast(cls, source):
        frame = cls._parse_frame(source)
        target = frame.get("object") or source
        parameters = dict(frame.get("parameters") or {})
        parameters.update({"semantic_category":frame.get("category"), "verifier":"predicate", "source_clause":source})
        value = str(parameters.get("value") or ((parameters.get("quoted_values") or [""])[-1]) or "")
        category = str(frame.get("category", "achieve"))
        action_word = str(frame.get("action", ""))
        lowered = source.lower()
        if any(value_ in lowered for value_ in ("返回", "back")):
            target = "返回 back"; category = "navigate"
        children = [cls._action("Observe", target, parameters=parameters, source=source)]
        if category == "navigate" and any(value_ in lowered for value_ in ("打开", "open", "切换", "进入应用")):
            children.append(cls._action("SwitchApplication", target, parameters=parameters, source=source))
        else:
            children.append(cls._action("Locate", target, parameters=parameters, source=source, node_type="ObjectRef"))
            if value or category in ("document_write", "credential_input"):
                children.extend([
                    cls._action("Focus", target, parameters=parameters, source=source),
                    cls._action("EnterText", target, value, parameters=parameters, source=source),
                ])
            elif category in ("navigate", "external_send", "filesystem_write", "software_install", "financial_commit", "aggregate", "achieve"):
                children.append(cls._action("Activate", target or action_word, parameters=parameters, capabilities=frame.get("capabilities"), source=source))
        children.append(cls._action("Verify", target, parameters=parameters, verification=frame.get("result_conditions"), source=source, node_type="Assert"))
        return cls._sequence(children, source)

    @classmethod
    def _is_mail(cls, text):
        lowered = text.lower()
        return any(value in lowered for value in ("发送", "发出", "寄出", "send")) and any(value in lowered for value in ("邮件", "email", "mail", "消息", "message"))

    @classmethod
    def _parse_statement(cls, text):
        text = cls._clean(text)
        if not text: return cls._sequence([], text)
        control = cls._parse_if(text)
        if control: return control
        loop = cls._parse_loop(text)
        if loop: return loop
        # 原子高信息意图先于连接词切分，避免“邮件，内容为……”被拆坏。
        if cls._is_mail(text): return cls._compile_mail_ast(text)
        rename = cls._compile_rename_ast(text)
        if rename: return rename
        spreadsheet = cls._compile_spreadsheet_ast(text)
        if spreadsheet: return spreadsheet
        parts = cls._split_top_level(text)
        if len(parts) > 1:
            return cls._sequence([cls._parse_statement(part) for part in parts], text)
        close = cls._compile_close_ast(text)
        if close: return close
        variable = cls._parse_variable(text)
        if variable: return variable
        assertion = cls._parse_assert(text)
        if assertion: return assertion
        retry = cls._parse_retry(text)
        if retry: return retry
        return cls._compile_generic_ast(text)

    @classmethod
    def parse(cls, text):
        source = cls.POLITE_PREFIX_RE.sub("", str(text or "").strip()).strip()
        return cls._parse_statement(source) if source else cls._sequence([], "")

    @classmethod
    def _flat_action(cls, node, identifier, depends_on, guard=None, control=None, loop=None):
        operator = str(node.get("operator", "Observe"))
        target = cls._clean(node.get("object_ref", "")); value = cls._clean(node.get("value", ""))
        payload = value or target
        typed = TaskDSLNode(
            identifier=identifier, object_ref=target or operator, operation=operator,
            parameters=dict(node.get("parameters") or {}), preconditions=list(node.get("preconditions") or []),
            postconditions=list(node.get("verification") or node.get("effects") or []), recovery=list(node.get("recovery") or []),
            branches=[dict(guard)] if guard else [], loop=dict(loop or {}), node_type=str(node.get("type", "Action")),
            condition=dict(node.get("condition") or {}), variable=str(node.get("variable", "")),
        ).as_dict()
        typed.update({
            "operator":operator, "action":cls.ACTION_KIND.get(operator, "observe"), "payload":payload,
            "target":target, "value":value, "depends_on":list(depends_on), "verify":list(node.get("verification") or []),
            "capabilities":list(node.get("capabilities") or []), "source":cls._clean(node.get("source", "")),
            "guard":dict(guard or {}), "control":dict(control or {}), "generic":False,
            "max_retries":max(0, int((loop or {}).get("max_retries", node.get("max_retries", 6 if operator in ("Verify", "Assert") else 2)))),
        })
        return typed

    @classmethod
    def lower(cls, program):
        output = []; counter = [0]; previous = []
        def next_id():
            counter[0] += 1; return "g{:03d}".format(counter[0])
        def emit(node, guard=None, control=None, loop_meta=None):
            nonlocal previous
            flat = cls._flat_action(node, next_id(), previous, guard=guard, control=control, loop=loop_meta)
            output.append(flat); previous = [flat["id"]]; return flat
        def walk(node, guard=None, loop_meta=None):
            nonlocal previous
            node_type = str(node.get("type", "Action"))
            if node_type in ("Sequence", "Else"):
                for child in node.get("children", []): walk(child, guard=guard, loop_meta=loop_meta)
                return
            if node_type == "Variable":
                emit({"type":"Variable", "operator":"SetVariable", "object_ref":node.get("variable", ""), "value":node.get("value", ""), "parameters":{"variable":node.get("variable", ""), "value":node.get("value", "")}, "source":node.get("source", "")}, guard, loop_meta=loop_meta)
                return
            if node_type == "If":
                if_id = "if_" + next_id()
                emit({"type":"If", "operator":"Observe", "object_ref":node.get("condition", {}).get("value", "condition"), "condition":node.get("condition", {}), "parameters":{"condition":node.get("condition", {})}, "source":node.get("source", "")}, guard, control={"type":"If", "if_id":if_id, "condition":node.get("condition", {})}, loop_meta=loop_meta)
                for child in node.get("children", []): walk(child, guard={"if_id":if_id, "equals":True}, loop_meta=loop_meta)
                for wrapper in node.get("else", []): walk(wrapper, guard={"if_id":if_id, "equals":False}, loop_meta=loop_meta)
                return
            if node_type in ("While", "Until", "ForEach"):
                loop_id = "loop_" + next_id(); max_iterations = max(1, min(64, int(node.get("max_iterations", 16))))
                condition = dict(node.get("condition") or {})
                check_operator = "ForEach" if node_type == "ForEach" else "Observe"
                emit({"type":node_type, "operator":check_operator, "object_ref":condition.get("value") or str((node.get("iterable") or {}).get("object_query", "items")), "condition":condition,
                      "parameters":{"condition":condition, "iterable":node.get("iterable", {}), "variable":node.get("variable", "")}, "source":node.get("source", "")},
                     guard, control={"type":node_type, "loop_id":loop_id, "condition":condition, "max_iterations":max_iterations}, loop_meta={"loop_id":loop_id, "max_iterations":max_iterations})
                body_start = len(output)
                for child in node.get("children", []): walk(child, guard=guard, loop_meta={"loop_id":loop_id, "max_iterations":max_iterations})
                emit({"type":node_type, "operator":"LoopEnd", "object_ref":loop_id, "parameters":{"loop_id":loop_id}, "source":node.get("source", "")}, guard,
                     control={"type":"LoopEnd", "loop_id":loop_id, "check_index":body_start - 1}, loop_meta={"loop_id":loop_id, "max_iterations":max_iterations})
                return
            if node_type == "Retry":
                retry_id = "retry_" + next_id(); maximum = max(1, min(10, int(node.get("max_iterations", 2))))
                for child in node.get("children", []):
                    child = dict(child); child["max_retries"] = maximum
                    walk(child, guard=guard, loop_meta={"retry_id":retry_id, "max_retries":maximum})
                return
            emit(node, guard=guard, loop_meta=loop_meta)
        walk(program)
        return output

    @classmethod
    def compile(cls, text):
        return cls.lower(cls.parse(text))

    @classmethod
    def graph(cls, text):
        program = cls.parse(text)
        return {
            "version":cls.VERSION,
            "schema":"Sequence|If|Else|While|ForEach|Until|Retry|Variable|ObjectRef|Assert|Action",
            "goal":str(text or ""), "program":program, "nodes":cls.lower(program),
        }


# 旧编译器只保留为数据迁移参考；所有运行时入口固定使用 GoalCompiler 2.0。
LegacyGoalCompiler = DeterministicGoalCompiler
GoalCompiler = StructuredGoalCompiler


class GoalStateVerifier:
    """按对象类型验证真实目标状态；文字提示只可作为辅助证据。"""

    @staticmethod
    def _records(observation):
        records = [dict(record) for record in observation.accessibility.records if not record.get("offscreen")]
        for item in getattr(observation, "visual_elements", []) or []:
            if isinstance(item, VisualElement):
                item = item.as_dict()
            box = item.get("bbox") or (0, 0, 0, 0)
            records.append({
                "name":str(item.get("text", "")), "value":"", "help":"", "control_type":"VisualText",
                "runtime_id":(), "automation_id":"", "focused":False, "enabled":True, "offscreen":False,
                "x_norm":(safe_float(box[0]) + safe_float(box[2])) * 0.5,
                "y_norm":(safe_float(box[1]) + safe_float(box[3])) * 0.5,
                "source":"vision", "confidence":safe_float(item.get("confidence")),
            })
        return records

    @staticmethod
    def _record_text(record):
        return " ".join(str(record.get(key, "")) for key in ("name", "value", "help", "automation_id", "control_type", "class_name")).lower()

    @staticmethod
    def _record_identity(record):
        runtime = tuple(record.get("runtime_id") or ())
        if runtime: return ("runtime", runtime)
        locator = control_locator(record)
        return ("locator", compact_json(locator), GoalStateVerifier._record_text(record)[:180])

    @staticmethod
    def evaluate_predicate(condition, observation):
        condition = dict(condition or {})
        kind = str(condition.get("type", "text_present"))
        value = str(condition.get("value", "")).strip().lower()
        semantic = str(observation.semantic_text or "").lower()
        result = False
        if kind == "text_present":
            result = bool(value and value in semantic)
        elif kind == "window_title_contains":
            result = bool(value and value in str(observation.accessibility.window_title or "").lower())
        elif kind == "control_present":
            result = any(value in GoalStateVerifier._record_text(record) for record in GoalStateVerifier._records(observation))
        elif kind == "window_changed":
            result = bool(condition.get("baseline_hwnd") and int(observation.accessibility.hwnd or 0) != int(condition.get("baseline_hwnd")))
        if condition.get("negate"):
            result = not result
        return bool(result)

    @staticmethod
    def _verifier_spec(goal):
        for step in reversed(list(getattr(goal, "compiled_steps", []) or [])):
            parameters = dict(step.get("parameters") or {})
            verifier = str(parameters.get("verifier", ""))
            if verifier:
                return verifier, parameters, step
        return "", {}, {}

    @staticmethod
    def _candidate_directories(location="current"):
        result = []
        if location == "desktop":
            profile = Path(os.environ.get("USERPROFILE") or Path.home())
            result.extend((profile / "Desktop", profile / "OneDrive" / "Desktop"))
            one_drive = os.environ.get("OneDrive")
            if one_drive: result.append(Path(one_drive) / "Desktop")
        result.extend((Path.cwd(), Path(__file__).resolve().parent))
        unique = []
        for path in result:
            try: resolved = path.resolve()
            except Exception: resolved = path
            if resolved not in unique: unique.append(resolved)
        return unique

    @classmethod
    def _file_facts(cls, parameters):
        old_name = str(parameters.get("old_name", "")).strip(); new_name = str(parameters.get("new_name", "")).strip()
        rows = []
        for directory in cls._candidate_directories(str(parameters.get("location", "current"))):
            for label, name in (("old", old_name), ("new", new_name)):
                if not name: continue
                path = directory / name
                try:
                    stat = path.stat()
                    rows.append({"label":label, "path":str(path), "exists":True, "size":int(stat.st_size), "mtime_ns":int(stat.st_mtime_ns), "inode":int(getattr(stat, "st_ino", 0))})
                except OSError:
                    rows.append({"label":label, "path":str(path), "exists":False})
        return rows

    @classmethod
    def capture(cls, goal, observation):
        verifier, parameters, verifier_step = cls._verifier_spec(goal)
        records = cls._records(observation)
        baseline = {
            "verifier":verifier, "parameters":parameters, "hwnd":int(observation.accessibility.hwnd or 0),
            "semantic_signature":str(observation.semantic_signature), "visual_signature":str(observation.visual_signature),
            "target":str(verifier_step.get("target") or verifier_step.get("object") or verifier_step.get("payload") or ""),
        }
        if verifier == "file_renamed":
            baseline["files"] = cls._file_facts(parameters)
        elif verifier == "spreadsheet_formula":
            formula = str(parameters.get("formula", "")).lower(); cell_range = str(parameters.get("range", "")).lower()
            baseline["formula_records"] = [cls._record_identity(record) for record in records if formula and formula in cls._record_text(record)]
            baseline["range_states"] = [(cls._record_identity(record), cls._record_text(record)) for record in records if cell_range and cell_range in cls._record_text(record)]
        elif verifier == "message_sent":
            content = str(parameters.get("content", "")).lower()
            baseline["message_records"] = [cls._record_identity(record) for record in records if content and content in cls._record_text(record)]
            baseline["send_controls"] = [(cls._record_identity(record), cls._record_text(record), bool(record.get("enabled"))) for record in records if any(value in cls._record_text(record) for value in ("发送", "send", "submit"))]
        return baseline

    @classmethod
    def verify(cls, goal, current):
        baseline = dict(getattr(goal, "verification_baseline", {}) or {})
        verifier = str(baseline.get("verifier", "")); parameters = dict(baseline.get("parameters") or {})
        records = cls._records(current)
        result = {"verified":False, "verifier":verifier or "none", "detail":"没有可用的状态验证器", "strength":0.0}
        if verifier == "file_renamed":
            before = list(baseline.get("files") or []); after = cls._file_facts(parameters)
            old_after = [item for item in after if item.get("label") == "old" and item.get("exists")]
            new_after = [item for item in after if item.get("label") == "new" and item.get("exists")]
            old_before = [item for item in before if item.get("label") == "old" and item.get("exists")]
            new_before = {item.get("path"):item for item in before if item.get("label") == "new" and item.get("exists")}
            same_object = False
            for old in old_before:
                for new in new_after:
                    same_object = same_object or (old.get("inode") and old.get("inode") == new.get("inode")) or (
                        old.get("size") == new.get("size") and old.get("mtime_ns") == new.get("mtime_ns") and old.get("path") != new.get("path")
                    )
            new_changed = any(
                item.get("path") not in new_before or any(new_before[item.get("path")].get(key) != item.get(key) for key in ("inode", "mtime_ns", "size"))
                for item in new_after
            )
            verified = bool(new_after and new_changed and not old_after and (same_object or not old_before))
            return {"verified":verified, "verifier":verifier, "detail":"文件系统确认新对象存在、旧对象消失" if verified else "文件系统尚未确认重命名对象变化", "strength":1.0 if verified else 0.0}
        if verifier == "window_closed":
            hwnd = int(baseline.get("hwnd", 0) or 0); destroyed = False
            if os.name == "nt" and hwnd:
                try:
                    user32 = ctypes.WinDLL("user32", use_last_error=True)
                    user32.IsWindow.argtypes = [wintypes.HWND]; user32.IsWindow.restype = wintypes.BOOL
                    destroyed = not bool(user32.IsWindow(hwnd))
                except Exception:
                    destroyed = False
            return {"verified":destroyed, "verifier":verifier, "detail":"原 HWND 生命周期已结束" if destroyed else "原 HWND 仍存在；仅前台切换不算关闭", "strength":1.0 if destroyed else 0.0}
        if verifier == "spreadsheet_formula":
            formula = str(parameters.get("formula", "")).lower(); cell_range = str(parameters.get("range", "")).lower()
            formula_ids = {cls._record_identity(record) for record in records if formula and formula in cls._record_text(record)}
            new_formula = formula_ids - set(map(tuple, baseline.get("formula_records") or []))
            before_ranges = dict((tuple(identity), text) for identity, text in baseline.get("range_states") or [])
            range_change = any(
                cell_range and cell_range in cls._record_text(record) and before_ranges.get(cls._record_identity(record)) not in (None, cls._record_text(record))
                for record in records
            )
            verified = bool(new_formula or range_change)
            return {"verified":verified, "verifier":verifier, "detail":"Excel UIA 公式/目标单元格结构已变化" if verified else "尚未从公式栏或目标单元格读回结果", "strength":0.95 if verified else 0.0}
        if verifier == "message_sent":
            content = str(parameters.get("content", "")).strip().lower(); recipient = str(parameters.get("recipient", "")).strip().lower()
            old_ids = set(map(tuple, baseline.get("message_records") or []))
            candidates = []
            for record in records:
                text = cls._record_text(record)
                if not content or content not in text: continue
                role = str(record.get("control_type", ""))
                read_only_message = role in {"Text", "ListItem", "DataItem", "Custom", "VisualText"} or (role == "Document" and not record.get("focused") and not record.get("keyboard_focusable"))
                if read_only_message and cls._record_identity(record) not in old_ids:
                    candidates.append(record)
            recipient_context = not recipient or recipient in str(current.semantic_text or "").lower() or recipient in str(current.accessibility.window_title or "").lower()
            verified = bool(candidates and recipient_context)
            return {"verified":verified, "verifier":verifier, "detail":"具体会话区域出现新的只读消息对象" if verified else "未发现匹配收件人与正文的新消息结构；忽略全窗口“已发送”文字", "strength":0.95 if verified else 0.0}
        if verifier == "predicate":
            condition = dict(parameters.get("condition") or {})
            if condition:
                verified = cls.evaluate_predicate(condition, current)
                return {"verified":verified, "verifier":verifier, "detail":"结构化断言成立" if verified else "结构化断言未成立", "strength":0.85 if verified else 0.0}
            active = (getattr(goal, "active_compiled_step", lambda: {})() or {})
            target = str(active.get("target") or getattr(goal, "last_verified_target", "") or baseline.get("target") or "").lower()
            verified = bool(target and target in str(current.semantic_text or "").lower() and current.semantic_signature != baseline.get("semantic_signature"))
            return {"verified":verified, "verifier":verifier, "detail":"目标对象状态与基线不同" if verified else "目标对象状态未得到结构化确认", "strength":0.70 if verified else 0.0}
        return result


class GoalEngine:
    STOP_WORDS = {
        "打开", "点击", "输入", "键入", "搜索", "查找", "选择", "进入", "完成", "执行", "窗口", "控件",
        "open", "click", "type", "search", "find", "select", "complete", "window", "button",
    }

    def __init__(self, requested_goal="", success_text="", mode="task"):
        self.mode = "autonomous" if str(mode).lower() == "autonomous" else "task"
        self.requested_goal = str(requested_goal or "").strip()
        self.success_text = str(success_text or "").strip()
        self.explicit = bool(self.mode == "task" and self.requested_goal)
        self.goal_label = ""
        self.target_point = None
        self.target_record = None
        self.baseline_signature = ""
        self.baseline_semantic = ""
        self.baseline_hwnd = 0
        self.best_coverage = 0.0
        self.completed = False
        self.completion_evidence = 0
        self.generation = 0
        self.compiled_steps = GoalCompiler.compile(self.requested_goal)
        self.compiler_generic = bool(self.compiled_steps and any(step.get("generic") for step in self.compiled_steps))
        self.compiled_index = 0
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        self.compiler_stalled = False
        self.variables = {}
        self.branch_decisions = {}
        self.loop_states = {}
        self.latest_observation = None
        self.verification_baseline = {}
        self.last_state_verification = {"verified":False, "detail":"尚未验证", "strength":0.0}
        self.last_verified_target = ""
        self.baseline_phrase_presence = {}
        self.baseline_phrase_controls = {}
        self.baseline_target_state = None
        self.candidate_target_change = False
        self.knowledge_context = []
        self.reasoning_graph = {}
        self.reasoning_completion_evidence = []

    def attach_reasoning(self, graph):
        self.reasoning_graph = dict(graph or {}) if isinstance(graph, dict) else {}
        evidence = self.reasoning_graph.get("completion_evidence", [])
        self.reasoning_completion_evidence = [str(value).strip().lower() for value in evidence if str(value).strip()][:32]
        return self.reasoning_graph

    def attach_knowledge(self, items):
        self.knowledge_context = [dict(item) for item in (items or []) if isinstance(item, dict)]
        return len(self.knowledge_context)

    def _terms(self):
        source = self.success_text or self.requested_goal or self.goal_label
        result = []
        for unit in semantic_units(source):
            if unit in self.STOP_WORDS:
                continue
            if len(unit) >= 2 or re.search(r"[a-z0-9]", unit):
                result.append(unit)
        return list(dict.fromkeys(result))

    def _phrases(self):
        return [value.strip().lower() for value in re.split(r"[|｜;；\n]+", self.success_text) if value.strip()]

    def _phrase_controls(self, observation, phrase):
        result = []
        for record in observation.accessibility.records:
            text = " ".join((str(record.get("name", "")), str(record.get("value", "")), str(record.get("help", "")))).lower()
            if phrase in text:
                locator = control_locator(record)
                state = (str(record.get("value", "")), bool(record.get("focused")), bool(record.get("enabled")), bool(record.get("offscreen")))
                result.append((compact_json(locator), state))
        return tuple(sorted(map(str, result)))

    def deterministic_text(self, observation=None):
        payloads = GoalCompiler.text_payloads(self.compiled_steps)
        if not payloads:
            return ""
        # 已聚焦可编辑控件时，优先给 TYPE/SEARCH/FIND 子目标；否则 URL 仍可供地址栏输入。
        focused_edit = False
        if observation is not None:
            focused_edit = any(record.get("focused") and record.get("control_type") in ("Edit", "Document", "ComboBox") for record in observation.accessibility.records)
        active = self.active_compiled_step()
        ordered_steps = ([active] if active is not None else []) + [step for step in self.compiled_steps if step is not active]
        for step in ordered_steps:
            if step.get("action") in (("type", "search", "find") if focused_edit else ("open", "type", "search", "find")):
                payload = str(step.get("payload", "")).strip()
                if payload:
                    return payload
        return payloads[0]

    def active_compiled_step(self):
        # 纯控制指令在这里解释；真正 UI 动作仍一次只返回一个原子 Operator。
        guard_limit = max(8, len(self.compiled_steps) * 3)
        for _ in range(guard_limit):
            if not (0 <= self.compiled_index < len(self.compiled_steps)):
                return None
            step = self.compiled_steps[self.compiled_index]
            guard = dict(step.get("guard") or {})
            if guard:
                decision = self.branch_decisions.get(str(guard.get("if_id")))
                if decision is not None and bool(decision) != bool(guard.get("equals")):
                    self.compiled_index += 1
                    continue
            operation = str(step.get("operator") or step.get("operation") or "")
            if operation == "SetVariable":
                parameters = dict(step.get("parameters") or {})
                name = str(parameters.get("variable") or step.get("target") or "")
                self.variables[name] = self._substitute_variables(parameters.get("value", step.get("value", "")))
                self.compiled_index += 1
                continue
            control = dict(step.get("control") or {})
            if operation == "LoopEnd" or control.get("type") == "LoopEnd":
                loop_id = str(control.get("loop_id") or (step.get("parameters") or {}).get("loop_id") or "")
                state = self.loop_states.get(loop_id, {})
                if state.get("active") and int(state.get("iteration", 0)) + 1 < int(state.get("max_iterations", 1)):
                    state["iteration"] = int(state.get("iteration", 0)) + 1
                    if state.get("type") == "ForEach":
                        state["item_index"] = int(state.get("item_index", 0)) + 1
                    self.loop_states[loop_id] = state
                    self.compiled_index = max(0, int(control.get("check_index", self.compiled_index)))
                else:
                    self.loop_states.pop(loop_id, None)
                    self.compiled_index += 1
                continue
            loop_info = dict(step.get("loop") or {})
            loop_id = str(loop_info.get("loop_id", ""))
            state = self.loop_states.get(loop_id) if loop_id else None
            is_check = dict(step.get("control") or {}).get("type") in ("While", "Until", "ForEach")
            if loop_id and state is not None and not state.get("active", True) and not is_check:
                self.compiled_index += 1
                continue
            return self._substitute_variables(step)
        self.compiler_stalled = True
        return None

    def _substitute_variables(self, value):
        if isinstance(value, str):
            result = value
            for name, replacement in self.variables.items():
                result = result.replace("${" + str(name) + "}", str(replacement)).replace("{{" + str(name) + "}}", str(replacement))
            return result
        if isinstance(value, dict):
            return {key:self._substitute_variables(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self._substitute_variables(item) for item in value]
        if isinstance(value, tuple):
            return tuple(self._substitute_variables(item) for item in value)
        return value

    def set_compiled_phase(self, phase, attempted=False):
        self.compiled_phase = str(phase or "precondition")
        if attempted and self.compiled_phase == "recovery":
            self.compiled_attempts += 1

    def reset_compiled_phase(self):
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        self.compiler_stalled = False

    def _advance_compiled(self, command, previous, current, outcome):
        step = self.active_compiled_step()
        if step is None or not outcome.get("executed"):
            return
        operation = str(step.get("operator") or step.get("operation") or step.get("action", ""))
        action = str(step.get("action", ""))
        payload = str(step.get("payload", "")).strip().lower()
        value = str(step.get("value", "") or step.get("payload", "")).strip().lower()
        semantic = current.semantic_text.lower()
        title = str(current.accessibility.window_title or "").lower()
        focused = next((record for record in current.accessibility.records if record.get("focused")), None)
        focused_type = str((focused or {}).get("control_type", ""))
        focused_text = " ".join((str((focused or {}).get("value", "")), str((focused or {}).get("name", "")))).lower()
        structured_change = current.semantic_signature != previous.semantic_signature or current.accessibility.hwnd != previous.accessibility.hwnd
        enter = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D
        advance = False

        # GoalCompiler 2.0 / Operator Planner 的通用状态机。特殊任务仅以参数和验证器表达。
        if operation in GenericOperatorPlanner.GOALS or operation in ("SetVariable", "ForEach"):
            handled = True
            control = dict(step.get("control") or {})
            control_type = str(control.get("type", ""))
            if control_type == "If" and command.kind == WAIT:
                self.branch_decisions[str(control.get("if_id", ""))] = GoalStateVerifier.evaluate_predicate(control.get("condition"), current)
                advance = True
            elif control_type in ("While", "Until") and command.kind == WAIT:
                condition_true = GoalStateVerifier.evaluate_predicate(control.get("condition"), current)
                active = condition_true if control_type == "While" else not condition_true
                loop_id = str(control.get("loop_id", ""))
                prior = dict(self.loop_states.get(loop_id, {}))
                self.loop_states[loop_id] = {
                    "type":control_type, "active":active, "iteration":int(prior.get("iteration", 0)),
                    "max_iterations":max(1, int(control.get("max_iterations", 16))),
                }
                advance = True
            elif control_type == "ForEach" and command.kind in (WAIT,):
                loop_id = str(control.get("loop_id", "")); parameters = dict(step.get("parameters") or {})
                prior = dict(self.loop_states.get(loop_id, {})); items = list(prior.get("items") or [])
                if not items:
                    iterable = parameters.get("iterable") or {}
                    if isinstance(iterable, (list, tuple)):
                        items = list(iterable)
                    else:
                        query = str((iterable or {}).get("object_query", "")).lower()
                        items = [str(record.get("name") or record.get("value") or "") for record in current.accessibility.records if query and query in GoalStateVerifier._record_text(record)]
                    items = list(dict.fromkeys(item for item in items if item))[:max(1, int(control.get("max_iterations", 32)))]
                item_index = int(prior.get("item_index", 0)); active = item_index < len(items)
                variable = str(parameters.get("variable", "item"))
                if active: self.variables[variable] = items[item_index]
                self.loop_states[loop_id] = {
                    "type":"ForEach", "active":active, "iteration":int(prior.get("iteration", 0)), "item_index":item_index,
                    "items":items, "max_iterations":max(1, int(control.get("max_iterations", 32))),
                }
                advance = True
            elif operation == "Observe":
                advance = command.kind == WAIT
            elif operation == "Locate":
                located = bool(target and target.lower() in semantic) or "已定位" in str(command.label)
                advance = command.kind == WAIT and located
            elif operation == "Focus":
                focused_match = bool(focused and (not target or target.lower() in focused_text or similarity(target, focused_text) >= 0.16))
                advance = (command.kind == WAIT and focused_match) or (command.kind == CLICK and focused_match)
            elif operation == "EnterText":
                ctrl_a = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x41 and 0x11 in set(int(item) for item in command.parameters.get("modifiers", []))
                if ctrl_a:
                    self.compiled_phase = "text_selected"
                    return
                advance = command.kind in (TYPE, WAIT) and bool(value and (value in focused_text or value in semantic))
            elif operation == "PressKey":
                advance = command.kind == KEY
            elif operation == "SwitchApplication":
                world = SymbolicWorldState.from_observation(current)
                advance = world.application_matches(target or value)
                if not advance and command.kind in (KEY, TYPE):
                    self.compiled_phase = str(command.parameters.get("next_compiled_phase", "precondition"))
                    return
            elif operation == "Activate":
                advance = command.kind in (CLICK, KEY) and bool(outcome.get("executed"))
            elif operation in ("Verify", "Assert"):
                verification = GoalStateVerifier.verify(self, current)
                self.last_state_verification = verification
                parameters = dict(step.get("parameters") or {})
                condition = dict(parameters.get("condition") or step.get("condition") or {})
                if condition and not verification.get("verifier"):
                    advance = command.kind == WAIT and GoalStateVerifier.evaluate_predicate(condition, current)
                else:
                    advance = command.kind == WAIT and bool(verification.get("verified"))
                if advance:
                    self.last_verified_target = str(target or value)
            elif operation == "ForEach":
                advance = command.kind == WAIT
            else:
                handled = False
            if handled:
                if advance:
                    self.compiled_index = min(len(self.compiled_steps), self.compiled_index + 1)
                    self.reset_compiled_phase()
                elif outcome.get("blocked") or outcome.get("invalid"):
                    self.set_compiled_phase("recovery", attempted=True)
                elif command.kind == WAIT and operation in ("Locate", "Focus", "Verify", "Assert"):
                    self.set_compiled_phase("recovery", attempted=True)
                elif command.kind not in (WAIT,):
                    self.compiled_phase = str(command.parameters.get("next_compiled_phase", self.compiled_phase))
                return

        if operation == "locate_object":
            advance = command.kind == WAIT and bool(payload and payload in semantic)
        elif operation == "select_object":
            advance = command.kind == CLICK and (structured_change or bool(focused and payload and payload in focused_text))
        elif operation == "request_rename":
            advance = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x71
        elif operation == "acquire_editor":
            advance = command.kind == WAIT and focused_type in SafetyPolicy.SAFE_TEXT_TYPES
        elif operation == "replace_text":
            advance = command.kind in (TYPE, WAIT) and bool(value and (value in focused_text or value in semantic))
        elif operation in ("commit_edit", "commit_formula"):
            advance = enter and structured_change
            if operation == "commit_edit" and enter:
                advance = True
        elif operation == "verify_object":
            advance = command.kind == WAIT and bool(payload and payload in semantic)
        elif operation == "close_window":
            advance = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x73 and 0x12 in set(int(x) for x in command.parameters.get("modifiers", [])) and current.accessibility.hwnd != previous.accessibility.hwnd
        elif operation == "formula_mode":
            advance = (command.kind == WAIT and focused_type in SafetyPolicy.SAFE_TEXT_TYPES) or (command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x71 and focused_type in SafetyPolicy.SAFE_TEXT_TYPES)
        elif operation == "verify_formula_result":
            advance = command.kind == WAIT and (current.semantic_signature != self.baseline_signature or current.accessibility.hwnd != self.baseline_hwnd)
        elif operation == "observe_context":
            advance = command.kind == WAIT
        elif operation == "locate_target":
            advance = (command.kind == WAIT and bool(current.accessibility.records)) or (command.kind in (CLICK, KEY) and structured_change)
        elif operation == "candidate_subgoal":
            advance = command.kind in (CLICK, KEY, TYPE, SKILL, WAIT) and (structured_change or outcome.get("simulated") or command.kind == WAIT)
        elif operation == "commit_candidate":
            advance = command.kind in (CLICK, KEY, TYPE, SKILL, WAIT) and bool(outcome.get("executed"))
        elif operation == "verify_result":
            advance = command.kind == WAIT and (structured_change or current.signature != self.baseline_signature)
        elif operation == "compile_success":
            advance = command.kind == WAIT and current.signature != self.baseline_signature
        elif operation in ("ensure_application", "ensure_url"):
            if re.match(r"https?://", payload, re.IGNORECASE):
                advance = enter and structured_change
            elif command.kind == WAIT and payload:
                advance = payload in (semantic + " " + title)
            elif command.kind in (CLICK, KEY) and structured_change:
                advance = True
        elif action in ("click", "select") and command.kind == CLICK:
            advance = structured_change
        elif action == "search":
            advance = enter and structured_change
        elif action == "find":
            advance = command.kind == TYPE and bool(payload and (payload in semantic or payload in focused_text))
        elif action == "type":
            advance = command.kind == TYPE and bool(payload and (payload in semantic or payload in focused_text))
        elif action == "save":
            advance = command.kind == KEY and SafetyPolicy.is_ctrl_s(command)

        if advance:
            self.compiled_index = min(len(self.compiled_steps), self.compiled_index + 1)
            self.reset_compiled_phase()
        elif outcome.get("blocked") or outcome.get("invalid") or (outcome.get("executed") and command.kind not in (WAIT,)):
            # 已执行但验证未通过也属于失败恢复，不无限重放同一动作。
            self.set_compiled_phase("recovery", attempted=True)

    def compiler_action_biases(self):
        step = self.active_compiled_step()
        if step is None:
            return {}
        operation = str(step.get("operation") or step.get("action", ""))
        mapping = {
            "Observe": WAIT, "Locate": WAIT, "Focus": CLICK, "Activate": CLICK, "EnterText": TYPE,
            "PressKey": KEY, "SwitchApplication": KEY, "Verify": WAIT, "Assert": WAIT, "ForEach": WAIT,
            "locate_object": WAIT, "select_object": CLICK, "request_rename": KEY, "acquire_editor": WAIT,
            "replace_text": TYPE, "commit_edit": KEY, "verify_object": WAIT, "close_window": KEY,
            "ensure_application": TYPE, "ensure_url": TYPE, "formula_mode": KEY, "commit_formula": KEY,
            "verify_formula_result": WAIT, "activate_control": CLICK, "search": TYPE, "find": TYPE,
            "save": KEY, "observe_context": WAIT, "locate_target": WAIT, "candidate_subgoal": CLICK,
            "commit_candidate": CLICK, "verify_result": WAIT, "compile_success": WAIT,
        }
        kind = mapping.get(operation)
        return {} if kind is None else {kind: 0.34}

    def _coverage(self, observation):
        terms = self._terms()
        if not terms:
            return 0.0
        semantic = observation.semantic_text.lower()
        weights = [max(1.0, math.sqrt(len(term))) for term in terms]
        matched = sum(weight for term, weight in zip(terms, weights) if term in semantic)
        return matched / max(1e-9, sum(weights))

    def _best_record(self, observation):
        query = " ".join((self.requested_goal, self.success_text))
        best = None
        best_score = -1.0
        for record in observation.accessibility.records:
            if record.get("password") or record.get("offscreen") or not record.get("enabled"):
                continue
            text = " ".join((record.get("name", ""), record.get("automation_id", ""), record.get("control_type", ""), record.get("help", "")))
            score = similarity(query, text)
            if record.get("control_type") in INTERACTIVE_CONTROL_TYPES:
                score += 0.12
            if score > best_score:
                best_score, best = score, record
        return best

    def begin(self, observation, renew=False):
        self.generation += 1
        self.completed = False
        self.completion_evidence = 0
        self.baseline_signature = observation.semantic_signature
        self.baseline_semantic = observation.semantic_text
        self.baseline_hwnd = int(observation.accessibility.hwnd or 0)
        phrases = self._phrases()
        semantic_lower = observation.semantic_text.lower()
        self.baseline_phrase_presence = {phrase: phrase in semantic_lower for phrase in phrases}
        self.baseline_phrase_controls = {phrase: self._phrase_controls(observation, phrase) for phrase in phrases}
        self.compiled_steps = GoalCompiler.compile(self.requested_goal)
        self.compiler_generic = bool(self.compiled_steps and any(step.get("generic") for step in self.compiled_steps))
        self.compiled_index = 0
        self.compiled_phase = "precondition"
        self.compiled_attempts = 0
        self.variables = {}
        self.branch_decisions = {}
        self.loop_states = {}
        self.latest_observation = observation
        if self.explicit:
            self.goal_label = self.requested_goal or "使界面出现：" + self.success_text
            self.target_record = self._best_record(observation)
        else:
            # 自主模式不再随机挑一个可交互控件当“课程目标”。默认目标是观察/读取/低风险导航，
            # 任何写入、发送、购买、安装、提交等外部副作用都必须来自 mode=task 的明确用户任务或一次性批准。
            self.target_record = None
            self.goal_label = "自主观察、读取界面并进行低风险导航；不产生外部副作用"
        if self.target_record:
            self.target_point = (float(self.target_record.get("x_norm", 0.5)), float(self.target_record.get("y_norm", 0.5)))
        elif self.mode == "autonomous":
            self.target_point = None
        else:
            self.target_point = (observation.interest_x, observation.interest_y)
        self.baseline_target_state = self._goal_record_state(self._find_target(observation))
        self.candidate_target_change = False
        self.best_coverage = self._coverage(observation)
        self.verification_baseline = GoalStateVerifier.capture(self, observation)
        self.last_state_verification = {"verified":False, "detail":"已捕获目标状态基线", "strength":0.0}
        self.last_verified_target = ""
        return self.goal_label

    def features(self):
        flags = "explicit{} complete{} generation{} compiler{}/{} phase{} attempts{}".format(int(self.explicit), int(self.completed), self.generation % 17, self.compiled_index, len(self.compiled_steps), self.compiled_phase, self.compiled_attempts)
        compiled = " ".join("{}:{}".format(step.get("action", ""), step.get("payload", "")) for step in self.compiled_steps)
        knowledge = " ".join("{} {}".format(item.get("title", ""), item.get("snippet", "")) for item in self.knowledge_context)
        items = [self.goal_label, self.requested_goal, self.success_text, flags, compiled, knowledge]
        if self.target_record:
            items.append(" ".join((self.target_record.get("control_type", ""), self.target_record.get("name", ""), self.target_record.get("automation_id", ""))))
        return hashed_features(items, GOAL_FEATURES)

    def adaptive_features(self, count):
        count = max(0, int(count))
        if not count:
            return []
        tokens = semantic_units(" ".join((self.goal_label, self.requested_goal, self.success_text)))
        values = []
        # token 级顺序编码；新增输入槽位时可保留更多目标 token，而不是永远压在 64 维内。
        per_token = 4
        for index, token in enumerate(tokens[:max(1, count // per_token)]):
            digest = hashlib.blake2s(token.encode("utf-8", "ignore"), digest_size=4).digest()
            values.extend([
                int.from_bytes(digest[:2], "little") / 65535.0,
                int.from_bytes(digest[2:], "little") / 65535.0,
                clamp(len(token) / 32.0, 0.0, 1.0),
                clamp(index / max(1, len(tokens) - 1), 0.0, 1.0),
            ])
            if len(values) >= count:
                break
        if len(values) < count:
            values.extend(hashed_features(tokens, count - len(values)))
        return normalize_state(values, count)

    def text_candidates(self):
        candidates = list(GoalCompiler.text_payloads(self.compiled_steps))
        source = " ".join((self.requested_goal, self.success_text))
        for match in re.findall(r"[\"'“”‘’]([^\"'“”‘’]{1,256})[\"'“”‘’]", source):
            candidates.append(match.strip())
        for match in re.findall(r"(?:输入|键入|搜索|查找|type|search|find)\s*[:：]?\s*([^，。；;\n\"'“”‘’]{1,256})", self.requested_goal, re.IGNORECASE):
            candidates.append(match.strip().strip("\"'“”‘’"))
        for match in re.findall(r"(?:https?://[^\s，。；;]+|[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}|[a-zA-Z0-9_.-]{3,})", source):
            candidates.append(match.strip())
        for item in self.knowledge_context:
            candidates.extend((str(item.get("title", "")), str(item.get("source", ""))))
        result = []
        for value in candidates:
            if value and value not in result:
                result.append(value)
        return result

    @staticmethod
    def _danger(observation):
        text = observation.semantic_text.lower()
        terms = ("error", "failed", "failure", "warning", "danger", "purchase", "payment", "delete", "错误", "失败", "警告", "危险", "付款", "支付", "删除")
        return any(term in text for term in terms)

    def _same_target(self, record):
        if not self.target_record or not record:
            return False
        left_runtime = tuple(self.target_record.get("runtime_id") or ())
        right_runtime = tuple(record.get("runtime_id") or ())
        if left_runtime and right_runtime:
            return left_runtime == right_runtime
        left_id = self.target_record.get("automation_id", "")
        right_id = record.get("automation_id", "")
        if left_id and right_id:
            return left_id == right_id and self.target_record.get("control_type") == record.get("control_type")
        return self.target_record.get("name") == record.get("name") and self.target_record.get("control_type") == record.get("control_type")

    def _find_target(self, observation):
        if not self.target_record:
            return None
        return next((record for record in observation.accessibility.records if self._same_target(record)), None)

    @staticmethod
    def _goal_record_state(record):
        if record is None:
            return None
        return (
            str(record.get("value", "")), bool(record.get("focused")), bool(record.get("enabled")),
            tuple(record.get("runtime_id") or ()), str(record.get("name", "")), bool(record.get("offscreen")),
        )

    def _target_changed(self, previous, current):
        if not self.target_record:
            return current.semantic_signature != previous.semantic_signature
        before = self._find_target(previous)
        after = self._find_target(current)
        if before is None and after is None:
            return current.semantic_signature != previous.semantic_signature
        if after is None:
            return True
        if before is None:
            return True
        for key in ("focused", "enabled", "value", "name", "offscreen"):
            if before.get(key) != after.get(key):
                return True
        return False

    def evaluate(self, command, previous, current, outcome):
        if self.completed:
            return {"reward": 0.0, "progress": 0.0, "completed": False, "candidate": False, "coverage": self.best_coverage, "label": self.goal_label}
        self.latest_observation = current
        self._advance_compiled(command, previous, current, outcome)
        coverage = self._coverage(current)
        delta = coverage - self.best_coverage
        self.best_coverage = max(self.best_coverage, coverage)
        reward = 0.0
        progress = 0.0
        candidate = False
        if outcome.get("blocked") or outcome.get("invalid"):
            reward -= 0.16
        if self.explicit:
            if delta > 0.01:
                progress = clamp(delta * 1.4, 0.0, 0.32)
                reward += progress
            elif delta < -0.08:
                reward -= min(0.14, abs(delta) * 0.35)
            phrases = self._phrases()
            semantic = current.semantic_text.lower()
            if phrases:
                emerged = any((not self.baseline_phrase_presence.get(phrase, False)) and phrase in semantic for phrase in phrases)
                changed_evidence = any(
                    self.baseline_phrase_presence.get(phrase, False)
                    and phrase in semantic
                    and self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())
                    for phrase in phrases
                )
                target_changed = self._target_changed(previous, current)
                goal_related_action = command.kind in (CLICK, KEY, TYPE, SKILL) and target_changed
                target_text = " ".join((str((self.target_record or {}).get("name", "")), str((self.target_record or {}).get("automation_id", "")), str((self.target_record or {}).get("control_type", ""))))
                explicit_target_change = (
                    any(self.baseline_phrase_presence.values()) and goal_related_action and self.target_record is not None
                    and self._find_target(current) is not None and similarity(self.requested_goal, target_text) >= 0.12
                    and self._goal_record_state(self._find_target(current)) != self.baseline_target_state
                )
                self.candidate_target_change = bool(explicit_target_change)
                candidate = emerged or (changed_evidence and goal_related_action) or explicit_target_change
            else:
                candidate = coverage >= 0.72 and current.semantic_signature != self.baseline_signature
            if self.compiled_steps and self.compiled_index >= len(self.compiled_steps):
                candidate = True
                reward = max(reward, 0.62)
                progress = max(progress, 0.72)
            candidate = candidate and not self._danger(current)
        else:
            targeted = False
            if self.target_point and command.kind in (MOVE, CLICK):
                x = float(command.parameters.get("x", previous.cursor_x))
                y = float(command.parameters.get("y", previous.cursor_y))
                distance = math.hypot(x - self.target_point[0], y - self.target_point[1])
                targeted = distance <= (0.09 if command.kind == CLICK else 0.13)
                if command.kind == MOVE and targeted:
                    reward += 0.06
                    progress = max(progress, 0.06)
                if command.kind == CLICK and targeted:
                    reward += 0.12
                    progress = max(progress, 0.12)
            structured_change = current.semantic_signature != previous.semantic_signature
            target_changed = self._target_changed(previous, current)
            target_terms = set(semantic_units((self.target_record or {}).get("name", "")))
            current_terms = set(semantic_units(current.semantic_text))
            target_after = self._find_target(current)
            target_persisted = target_after is not None
            target_semantic = bool(target_terms & current_terms) if target_terms else target_persisted
            semantic_relation = target_persisted and target_semantic
            candidate = bool(outcome.get("skill_success")) or (targeted and command.kind == CLICK and structured_change and target_changed and semantic_relation)
            candidate = candidate and not self._danger(current)
            if not candidate and command.kind in (CLICK, KEY, TYPE, SKILL) and structured_change:
                reward += 0.05
                progress = max(progress, 0.05)
        if candidate:
            reward = max(reward, 0.45)
            progress = max(progress, 0.55)
        return {"reward": clamp(reward, -1.0, 1.0), "progress": progress, "completed": False, "candidate": candidate, "coverage": coverage, "label": self.goal_label}

    @staticmethod
    def _window_consistent(candidate_observation, current):
        before = candidate_observation.accessibility
        after = current.accessibility
        if before.hwnd and after.hwnd and before.hwnd != after.hwnd:
            return False
        if before.window_class and after.window_class and before.window_class != after.window_class:
            return False
        if before.window_title and after.window_title and before.window_title != after.window_title:
            if similarity(before.window_title, after.window_title) < 0.45:
                return False
        return True

    def _key_control_consistent(self, candidate_observation, current):
        if self.target_record:
            before = self._find_target(candidate_observation)
            after = self._find_target(current)
            if before is None or after is None:
                return False
            for key in ("control_type", "automation_id", "class_name", "enabled", "offscreen"):
                if before.get(key) != after.get(key):
                    return False
            return True
        phrases = self._phrases()
        if not phrases:
            return True
        def matching_records(observation):
            result = []
            for record in observation.accessibility.records:
                text = " ".join((record.get("name", ""), record.get("value", ""), record.get("help", ""))).lower()
                if any(phrase in text for phrase in phrases):
                    result.append((record.get("runtime_id"), record.get("automation_id"), record.get("control_type"), record.get("name")))
            return result
        before = matching_records(candidate_observation)
        after = matching_records(current)
        return bool(set(map(str, before)) & set(map(str, after))) if before else True

    def _artifact_terms(self):
        source = " ".join((self.requested_goal, self.success_text))
        values = []
        for value in re.findall(r'["“”‘’\']([^"“”‘’\']{1,180})["“”‘’\']', source):
            values.append(value.strip().lower())
        for value in re.findall(r'([\w\-. ()\[\]{}\u3400-\u9fff]+\.[A-Za-z0-9]{1,12})', source):
            values.append(value.strip().lower())
        return list(dict.fromkeys(value for value in values if value))[:16]

    def _goal_specific_completion_evidence(self, current):
        # 首选对象级只读验证器。已知对象类型绝不回退到全窗口“成功/已发送/saved”字符串。
        state_result = GoalStateVerifier.verify(self, current)
        self.last_state_verification = state_result
        if state_result.get("verified"):
            return True
        if str(self.success_text or "").strip():
            # 用户明确填写的成功断言仍可用，但必须是相对基线新出现或对应控件状态发生变化。
            for phrase in self._phrases():
                semantic_now = str(current.semantic_text or "").lower()
                if phrase in semantic_now and (
                    not self.baseline_phrase_presence.get(phrase, False)
                    or self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())
                ):
                    return True
            return False
        if state_result.get("verifier") not in ("", "none"):
            return False
        semantic = str(current.semantic_text or "").lower()
        baseline = str(self.baseline_semantic or "").lower()
        title = str(current.accessibility.window_title or "").lower()
        source = str(self.requested_goal or "").lower()
        phrases = self._phrases()
        if phrases:
            for phrase in phrases:
                if phrase in semantic and ((phrase not in baseline) or self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())):
                    return True
            return False
        for evidence in self.reasoning_completion_evidence:
            if evidence and evidence in semantic and evidence not in baseline:
                return True
        artifacts = self._artifact_terms()
        create_intent = any(token in source for token in ("创建", "新建", "建立", "生成文件", "重命名", "改名", "create", "new file", "new folder", "rename"))
        if create_intent:
            return bool(artifacts and any(value in (semantic + " " + title) and value not in baseline for value in artifacts))
        send_intent = any(token in source for token in ("发送", "发出", "寄出", "提交", "send", "email", "message", "submit"))
        if send_intent:
            acknowledgements = ("已发送", "发送成功", "消息已发送", "邮件已发送", "已提交", "提交成功", "sent", "message sent", "email sent", "submitted", "delivered")
            return any(token in semantic and token not in baseline for token in acknowledgements)
        save_intent = any(token in source for token in ("保存", "另存", "save"))
        if save_intent:
            acknowledgements = ("已保存", "保存成功", "saved", "save complete")
            if any(token in semantic and token not in baseline for token in acknowledgements): return True
            if artifacts and any(value in (semantic + " " + title) for value in artifacts) and current.semantic_signature != self.baseline_signature:
                return True
            return False
        close_intent = any(token in source for token in ("关闭", "close window", "close the window"))
        if close_intent:
            return int(current.accessibility.hwnd or 0) != int(self.baseline_hwnd or 0)
        navigation_intent = any(token in source for token in ("打开", "进入", "访问", "导航", "open", "navigate", "go to"))
        if navigation_intent:
            terms = [term for term in self._terms() if len(term) >= 2]
            return current.semantic_signature != self.baseline_signature and any(term in (semantic + " " + title) for term in terms)
        # generic/未知任务永不因为“界面变了且稳定”自动成功；必须出现上面的目标特定证据。
        return False

    def verify_stable(self, candidate_observation, current):
        self.latest_observation = current
        if self.completed or self._danger(current):
            return False
        window_stable = self._window_consistent(candidate_observation, current)
        control_stable = self._key_control_consistent(candidate_observation, current)
        semantic_stable = current.semantic_signature == candidate_observation.semantic_signature or similarity(candidate_observation.semantic_text, current.semantic_text) >= 0.68
        if self.explicit:
            if self.compiled_steps and self.compiled_index >= len(self.compiled_steps):
                last = self.compiled_steps[-1]
                operation = str(last.get("operation", ""))
                target = str(last.get("target", "") or last.get("payload", "")).lower()
                if operation == "verify_object":
                    valid = bool(target and target in current.semantic_text.lower()) and semantic_stable
                elif operation == "close_window":
                    valid = int(current.accessibility.hwnd or 0) != int(self.baseline_hwnd or 0) and semantic_stable
                elif last.get("generic"):
                    valid = self._goal_specific_completion_evidence(current) and semantic_stable and not self._danger(current)
                else:
                    valid = self._goal_specific_completion_evidence(current) and semantic_stable and not self._danger(current)
                self.completion_evidence = self.completion_evidence + 1 if valid else 0
                if self.completion_evidence >= 2:
                    self.completed = True
                    return True
                return False
            phrases = self._phrases()
            semantic = current.semantic_text.lower()
            if phrases:
                emerged = any((not self.baseline_phrase_presence.get(phrase, False)) and phrase in semantic for phrase in phrases)
                changed_evidence = any(
                    self.baseline_phrase_presence.get(phrase, False)
                    and phrase in semantic
                    and self._phrase_controls(current, phrase) != self.baseline_phrase_controls.get(phrase, ())
                    for phrase in phrases
                )
                target_change_stable = False
                if self.candidate_target_change and self.target_record is not None:
                    current_target = self._find_target(current)
                    target_change_stable = current_target is not None and self._goal_record_state(current_target) != self.baseline_target_state
                valid = emerged or changed_evidence or target_change_stable
            else:
                valid = self._goal_specific_completion_evidence(current)
            valid = valid and window_stable and control_stable and semantic_stable
        else:
            target_persisted = self._find_target(current) is not None if self.target_record else True
            valid = target_persisted and window_stable and control_stable and semantic_stable
        if valid:
            self.completion_evidence += 1
        else:
            self.completion_evidence = 0
        if self.completion_evidence >= 3:
            self.completed = True
            return True
        return False

    def after_sleep(self, observation):
        if not self.explicit and self.completed:
            return self.begin(observation, renew=True)
        if self.explicit and self.compiler_stalled:
            self.reset_compiled_phase()
        return self.goal_label


class SessionCapabilityDomain:
    """把启动时的 HWND/PID 扩展成贯穿会话、可审计且默认不跨程序的权限域。"""

    def __init__(self, memory, initial_observation, goal_text=""):
        self.memory = memory
        self.session_id = uuid.uuid4().hex
        self.goal_text = str(goal_text or "")
        self.allowed_pids = set()
        self.allowed_hwnds = set()
        self.root_process_name = str(getattr(initial_observation, "process_name", "") or "").lower()
        self.root_process_path = str(getattr(initial_observation, "process_path", "") or "").lower()
        self.pending_cross_program_reason = ""
        self.pending_cross_program_at = 0.0
        self.pending_cross_program_token = ""
        self.pending_cross_program_target = ""
        self._register(initial_observation, "initial", "allow", "用户点击开始时锁定的应用", approved=True)

    def _register(self, observation, relation, scope, reason, approved=False):
        pid = int(getattr(observation, "process_id", 0) or 0)
        hwnd = int(getattr(observation.accessibility, "hwnd", 0) or 0)
        if scope in ("allow", "declared"):
            if pid: self.allowed_pids.add(pid)
            if hwnd: self.allowed_hwnds.add(hwnd)
        self.memory.remember_session_capability({
            "session_id": self.session_id, "process_id": pid,
            "process_name": str(getattr(observation, "process_name", "") or ""), "window_hwnd": hwnd,
            "parent_process_id": int(getattr(observation, "parent_process_id", 0) or 0),
            "owner_hwnd": int(getattr(observation, "owner_hwnd", 0) or 0),
            "relation": relation, "scope": scope, "reason": reason, "approved": approved,
        })
        return scope

    @staticmethod
    def _compiler_cross_program(command):
        if command is None:
            return False
        return bool(
            "cross_program" in set(str(value) for value in getattr(command, "required_capabilities", []) or [])
            and str(getattr(command, "compiled_scope_token", "") or "").strip()
            and str(getattr(command, "capability_reason", "") or "").strip()
        )

    @staticmethod
    def _target_matches(observation, target):
        target = re.sub(r"[^a-z0-9\u3400-\u9fff]+", "", str(target or "").lower())
        if not target:
            return True
        values = (
            str(getattr(observation, "process_name", "") or ""),
            os.path.basename(str(getattr(observation, "process_path", "") or "")),
            str(getattr(observation.accessibility, "window_title", "") or ""),
        )
        normalized = [re.sub(r"[^a-z0-9\u3400-\u9fff]+", "", value.lower().replace(".exe", "")) for value in values]
        # 例如目标 “Microsoft Excel” 与 EXCEL.EXE / Excel 窗口标题都可匹配，但完全无关程序不能消费租约。
        target_parts = [part for part in re.findall(r"[a-z0-9]+|[\u3400-\u9fff]+", str(target)) if len(part) >= 2]
        return any(target in value or value in target for value in normalized if value) or any(part in value for part in target_parts for value in normalized if value)

    def classify(self, observation, command=None):
        pid = int(getattr(observation, "process_id", 0) or 0)
        hwnd = int(getattr(observation.accessibility, "hwnd", 0) or 0)
        parent_pid = int(getattr(observation, "parent_process_id", 0) or 0)
        owner_hwnd = int(getattr(observation, "owner_hwnd", 0) or 0)
        process_name = str(getattr(observation, "process_name", "") or "").lower()
        process_path = str(getattr(observation, "process_path", "") or "").lower()
        compiler_cross = self._compiler_cross_program(command)
        reason = str(getattr(command, "capability_reason", "") or "") if command is not None else ""
        if compiler_cross:
            self.pending_cross_program_reason = reason
            self.pending_cross_program_at = time.monotonic()
            self.pending_cross_program_token = str(getattr(command, "compiled_scope_token", "") or "")
            self.pending_cross_program_target = str(getattr(command, "compiled_scope_target", "") or "")
        if (pid and pid in self.allowed_pids) or (hwnd and hwnd in self.allowed_hwnds):
            return self._register(observation, "known", "allow", "会话中已验证的窗口")
        if owner_hwnd and owner_hwnd in self.allowed_hwnds:
            return self._register(observation, "owned_window", "allow", "允许应用拥有的子窗口")
        if self.root_process_path and process_path and process_path == self.root_process_path:
            return self._register(observation, "same_executable", "allow", "同一 executable 的重建/新窗口")
        if self.root_process_name and process_name and process_name == self.root_process_name:
            return self._register(observation, "same_application", "allow", "同一应用的多进程窗口")
        # 子进程如果已经换成不同 executable，不再仅凭 parent PID 自动扩域。
        if parent_pid and parent_pid in self.allowed_pids:
            if compiler_cross and self._target_matches(observation, getattr(command, "compiled_scope_target", "")):
                return self._register(observation, "compiled_child_process", "declared", reason)
            return self._register(observation, "foreign_child_process", "outside", "子进程 executable 与初始应用不同，缺少明确编译跨程序步骤")
        if compiler_cross and self._target_matches(observation, getattr(command, "compiled_scope_target", "")):
            return self._register(observation, "compiler_declared", "declared", reason)
        if self.pending_cross_program_reason and time.monotonic() - self.pending_cross_program_at <= 10.0:
            reason = self.pending_cross_program_reason
            token = self.pending_cross_program_token
            target = self.pending_cross_program_target
            self.pending_cross_program_reason = ""
            self.pending_cross_program_token = ""
            self.pending_cross_program_target = ""
            # 短期过渡租约只能被明确编译目标消费；无关程序抢到前台时 fail-closed。
            if token and self._target_matches(observation, target):
                return self._register(observation, "compiler_transition", "declared", reason)
            if token:
                return self._register(observation, "compiler_transition_mismatch", "outside", "跨程序目标与当前进程/窗口不匹配")
        return self._register(observation, "unrelated", "outside", "未证明属于初始应用，且没有明确 GoalCompiler 跨程序步骤")


class ExternalAIPageClassifier:
    """不依赖品牌枚举的本地规则分类器：识别“聊天/提示词输入 + 生成/发送 + AI/助手上下文”的高置信第三方 AI 页面。"""
    BROWSER_APPS = {"chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"}
    CONTEXT_TOKENS = (
        "ai assistant", "assistant", "chatbot", "language model", "llm", "ask ai", "ask anything",
        "new chat", "new conversation", "prompt", "system prompt", "model selector", "regenerate",
        "人工智能助手", "智能助手", "ai助手", "新对话", "新建对话", "提示词", "模型选择", "重新生成",
    )
    ACTION_TOKENS = (
        "generate", "regenerate", "send message", "submit prompt", "ask", "message", "stop generating",
        "生成", "重新生成", "发送消息", "提交提示词", "提问", "停止生成",
    )
    ADDRESS_TOKENS = ("/chat", "chat.", "ai.", "/assistant", "/prompt", "assistant.")

    @staticmethod
    def _process_name(observation):
        name = str(getattr(observation, "process_name", "") or "").lower().strip()
        if name:
            return name
        return os.path.basename(str(getattr(observation, "process_path", "") or "").lower().strip())

    @classmethod
    def suspicious(cls, observation, command=None):
        if cls._process_name(observation) not in cls.BROWSER_APPS:
            return {"high_confidence": False, "score": 0.0, "evidence": ""}
        accessibility = getattr(observation, "accessibility", None)
        records = list(getattr(accessibility, "records", []) or [])
        title = str(getattr(accessibility, "window_title", "") or "")
        semantic = str(getattr(observation, "semantic_text", "") or "")
        address_parts = []
        edit_like = 0
        action_hits = 0
        for record in records:
            role = " ".join((
                str(record.get("name", "")), str(record.get("value", "")), str(record.get("help", "")),
                str(record.get("automation_id", "")), str(record.get("class_name", "")),
            )).lower()
            control_type = str(record.get("control_type", ""))
            if control_type in ("Edit", "Document", "ComboBox"):
                if any(token in role for token in ("address", "omnibox", "url", "地址栏", "网址")):
                    address_parts.append(str(record.get("value", "") or record.get("name", "")))
                elif not record.get("password"):
                    edit_like += 1
            if control_type in ("Button", "Hyperlink", "MenuItem") and any(token in role for token in cls.ACTION_TOKENS):
                action_hits += 1
        address = " ".join(address_parts).lower()
        combined = re.sub(r"\s+", " ", " ".join((title, semantic))).lower()
        context_hits = sum(1 for token in cls.CONTEXT_TOKENS if token in combined)
        address_hint = any(token in address for token in cls.ADDRESS_TOKENS)
        title_hint = any(token in title.lower() for token in (" ai ", "ai ", " assistant", "chatbot", "助手", "对话"))
        command_kind = int(getattr(command, "kind", WAIT)) if command is not None else WAIT
        command_is_delegate_capable = command_kind in (TYPE, CLICK, KEY, SKILL)
        score = 0.0
        score += min(0.36, context_hits * 0.12)
        score += 0.18 if edit_like else 0.0
        score += min(0.24, action_hits * 0.12)
        score += 0.14 if address_hint else 0.0
        score += 0.10 if title_hint else 0.0
        score += 0.08 if command_is_delegate_capable else 0.0
        high = bool(score >= 0.72 and edit_like and (context_hits >= 2 or (context_hits >= 1 and action_hits >= 1)) and (address_hint or title_hint or context_hits >= 3))
        evidence = "generic-ai score={:.2f}; context={}; edit={}; action={}; address_hint={}; title_hint={}".format(
            score, context_hits, edit_like, action_hits, address_hint, title_hint
        )
        return {"high_confidence": high, "score": round(score, 4), "evidence": evidence}


class BrowserAIClassifier(ExternalAIPageClassifier):
    """浏览器 AI 交互界面分类器；保留原地址栏/UIA 组合证据。"""


class NativeAIClassifier:
    """原生/Electron AI 客户端分类器：品牌只作弱证据，核心是交互语义组合。"""

    KNOWN_PROCESS_TOKENS = (
        "chatgpt", "copilot", "claude", "perplexity", "gemini", "deepseek", "grok",
        "poe", "doubao", "kimi", "qwen", "chatglm", "mistral",
    )
    PROMPT_TOKENS = (
        "prompt", "message assistant", "message ai", "ask anything", "ask ai", "chat input",
        "提示词", "向助手发送消息", "问 ai", "问ai", "输入消息", "对话输入",
    )
    MODEL_TOKENS = (
        "ai assistant", "assistant", "language model", "llm", "model selector", "new chat",
        "regenerate", "reasoning", "人工智能助手", "智能助手", "模型选择", "新对话", "重新生成", "推理",
    )
    ACTION_TOKENS = ExternalAIPageClassifier.ACTION_TOKENS

    @staticmethod
    def _process_name(observation):
        value = str(getattr(observation, "process_name", "") or "").lower().strip()
        return value or os.path.basename(str(getattr(observation, "process_path", "") or "").lower().strip())

    @classmethod
    def suspicious(cls, observation, command=None):
        process = cls._process_name(observation)
        if process in ExternalAIPageClassifier.BROWSER_APPS:
            return {"high_confidence": False, "score": 0.0, "evidence": "", "surface": "native"}
        accessibility = getattr(observation, "accessibility", None)
        title = str(getattr(accessibility, "window_title", "") or "")
        window_class = str(getattr(accessibility, "window_class", "") or "")
        semantic = str(getattr(observation, "semantic_text", "") or "")
        records = list(getattr(accessibility, "records", []) or [])
        combined = re.sub(r"\s+", " ", " ".join((title, semantic))).lower()
        known_process = any(token in process for token in cls.KNOWN_PROCESS_TOKENS)
        known_title = any(token in title.lower() for token in cls.KNOWN_PROCESS_TOKENS)
        model_hits = sum(1 for token in cls.MODEL_TOKENS if token in combined)
        prompt_edits = 0
        action_hits = 0
        model_controls = 0
        for record in records:
            role = " ".join((
                str(record.get("name", "")), str(record.get("value", "")), str(record.get("help", "")),
                str(record.get("automation_id", "")), str(record.get("class_name", "")),
            )).lower()
            control_type = str(record.get("control_type", ""))
            if control_type in ("Edit", "Document", "ComboBox") and not record.get("password"):
                if any(token in role for token in cls.PROMPT_TOKENS) or (model_hits >= 2 and control_type in ("Edit", "Document")):
                    prompt_edits += 1
            if control_type in ("Button", "Hyperlink", "MenuItem") and any(token in role for token in cls.ACTION_TOKENS):
                action_hits += 1
            if any(token in role for token in ("model selector", "reasoning", "new chat", "regenerate", "模型选择", "新对话", "重新生成")):
                model_controls += 1
        electron_hint = "chrome_widgetwin" in window_class.lower() or "electron" in window_class.lower()
        delegate_capable = int(getattr(command, "kind", WAIT)) in (TYPE, CLICK, KEY, SKILL) if command is not None else False
        score = 0.0
        score += 0.30 if known_process else 0.0
        score += 0.16 if known_title else 0.0
        score += min(0.32, model_hits * 0.08)
        score += min(0.22, prompt_edits * 0.18)
        score += min(0.22, action_hits * 0.11)
        score += min(0.12, model_controls * 0.06)
        score += 0.06 if electron_hint else 0.0
        score += 0.06 if delegate_capable else 0.0
        high = bool(
            score >= 0.72 and prompt_edits >= 1
            and (action_hits >= 1 or model_controls >= 1)
            and (model_hits >= 2 or known_process or known_title)
        )
        evidence = "native-ai score={:.2f}; process_hint={}; title_hint={}; model={}; prompt={}; action={}; controls={}; electron={}".format(
            score, known_process, known_title, model_hits, prompt_edits, action_hits, model_controls, electron_hint,
        )
        return {"high_confidence": high, "score": round(score, 4), "evidence": evidence, "surface": "native"}


class ExternalAIContextClassifier:
    """统一两层分类：BrowserAIClassifier + NativeAIClassifier。"""

    @classmethod
    def suspicious(cls, observation, command=None):
        process = ExternalAIPageClassifier._process_name(observation)
        if process in ExternalAIPageClassifier.BROWSER_APPS:
            result = dict(BrowserAIClassifier.suspicious(observation, command))
            result["surface"] = "browser"
            return result
        return NativeAIClassifier.suspicious(observation, command)


class ExternalAIDelegationPolicy:
    """GUI 操作层硬策略：禁止把本程序的认知、规划、学习或任务求解委托给第三方 AI。"""
    BROWSER_APPS = {"chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe"}
    BLOCKED_SERVICES = {
        "ChatGPT/OpenAI": ("chatgpt.com", "chat.openai.com", "openai.com", "chatgpt", "openai"),
        "Claude/Anthropic": ("claude.ai", "anthropic.com", "claude", "anthropic"),
        "Gemini/Google AI": ("gemini.google.com", "aistudio.google.com", "ai.google.dev", "gemini"),
        "Microsoft Copilot": ("copilot.microsoft.com", "copilot", "bing chat"),
        "Perplexity": ("perplexity.ai", "perplexity"),
        "Grok/xAI": ("grok.com", "x.ai", "grok"),
        "DeepSeek": ("chat.deepseek.com", "deepseek.com", "deepseek"),
        "Mistral Le Chat": ("chat.mistral.ai", "mistral.ai", "le chat", "mistral"),
        "Poe": ("poe.com", "poe"),
        "Meta AI": ("meta.ai", "meta ai"),
        "You.com AI": ("you.com", "youchat", "you.com ai"),
        "Kimi/Moonshot": ("kimi.com", "kimi.moonshot.cn", "moonshot", "kimi"),
        "Qwen/Tongyi": ("tongyi.aliyun.com", "qianwen.aliyun.com", "qwen", "通义千问"),
        "Doubao": ("doubao.com", "豆包"),
        "ERNIE/Wenxin": ("yiyan.baidu.com", "文心一言", "文心"),
        "Zhipu/ChatGLM": ("chatglm.cn", "zhipuai.cn", "chatglm", "智谱清言"),
        "Character.AI": ("character.ai", "character ai"),
        "HuggingChat": ("huggingface.co/chat", "huggingchat"),
    }
    ADDRESS_HINTS = (
        "address and search", "address bar", "omnibox", "url", "网址", "地址栏", "搜索或输入网址", "search or enter web address"
    )
    DELEGATION_PHRASES = (
        "ask chatgpt", "use chatgpt", "open chatgpt", "让chatgpt", "用chatgpt", "问chatgpt",
        "ask claude", "use claude", "open claude", "让claude", "用claude",
        "ask gemini", "use gemini", "open gemini", "让gemini", "用gemini",
        "ask copilot", "use copilot", "open copilot", "让copilot", "用copilot",
        "ask perplexity", "use perplexity", "open perplexity", "让perplexity", "用perplexity",
    )

    @staticmethod
    def _process_name(observation):
        value = str(getattr(observation, "process_name", "") or "").lower().strip()
        if value:
            return value
        return os.path.basename(str(getattr(observation, "process_path", "") or "").lower().strip())

    @classmethod
    def _service_match(cls, text, require_domain=False):
        lowered = re.sub(r"\s+", " ", str(text or "").lower())
        if not lowered:
            return "", ""
        for service, tokens in cls.BLOCKED_SERVICES.items():
            domain_tokens = tuple(token for token in tokens if "." in token)
            candidates = domain_tokens if require_domain else tokens
            for token in candidates:
                if token in lowered:
                    return service, token
        return "", ""

    @classmethod
    def _address_bar_text(cls, observation):
        values = []
        for record in getattr(getattr(observation, "accessibility", None), "records", []) or []:
            role = " ".join((
                str(record.get("name", "")), str(record.get("automation_id", "")),
                str(record.get("class_name", "")), str(record.get("help", "")),
            )).lower()
            control_type = str(record.get("control_type", ""))
            if control_type in ("Edit", "Document", "ComboBox") and any(hint in role for hint in cls.ADDRESS_HINTS):
                values.append(str(record.get("value", "") or record.get("name", "")))
        return " ".join(values)

    @classmethod
    def _browser_context(cls, observation):
        if cls._process_name(observation) not in cls.BROWSER_APPS:
            return "", ""
        address = cls._address_bar_text(observation)
        service, evidence = cls._service_match(address, require_domain=True)
        if service:
            return service, "地址栏:" + evidence
        title = str(getattr(getattr(observation, "accessibility", None), "window_title", "") or "")
        service, evidence = cls._service_match(title, require_domain=False)
        if service:
            return service, "窗口标题:" + evidence
        semantic = str(getattr(observation, "semantic_text", "") or "")
        # UIA 树只有在出现强 AI 服务标志时才作为证据，避免普通网页正文提及 AI 品牌造成误杀。
        semantic_lower = semantic.lower()
        strong_ui = any(token in semantic_lower for token in ("message chatgpt", "ask anything", "message claude", "ask gemini", "perplexity"))
        if strong_ui:
            service, evidence = cls._service_match(semantic, require_domain=False)
            if service:
                return service, "可访问性树:" + evidence
        return "", ""

    @classmethod
    def _command_text(cls, command):
        params = dict(getattr(command, "parameters", {}) or {})
        if int(getattr(command, "kind", WAIT)) == TYPE:
            return str(params.get("text", ""))
        if int(getattr(command, "kind", WAIT)) == SKILL:
            return " ".join((str(getattr(command, "label", "")), compact_json(params.get("args", {}))))
        return str(getattr(command, "label", ""))

    @classmethod
    def assess(cls, command, observation):
        if int(getattr(command, "kind", WAIT)) not in (CLICK, TYPE, KEY, SKILL):
            return {"blocked": False, "reason": "", "service": "", "evidence": ""}
        process = cls._process_name(observation)
        service, evidence = cls._browser_context(observation)
        if service:
            return {
                "blocked": True,
                "reason": "禁止把推理/任务委托给第三方 AI",
                "service": service,
                "evidence": evidence,
            }
        generic_ai = ExternalAIContextClassifier.suspicious(observation, command)
        if generic_ai.get("high_confidence"):
            native = generic_ai.get("surface") == "native"
            return {
                "blocked": True,
                "reason": "禁止把推理/任务委托给第三方 AI",
                "service": "高置信第三方 AI 原生交互界面" if native else "未枚举的第三方 AI 页面",
                "evidence": str(generic_ai.get("evidence", "")),
                "generic_classifier": generic_ai,
            }
        command_text = cls._command_text(command)
        service, token = cls._service_match(command_text, require_domain=True)
        if service:
            return {
                "blocked": True,
                "reason": "禁止把推理/任务委托给第三方 AI",
                "service": service,
                "evidence": "即将输入/执行的 URL:" + token,
            }
        lowered = re.sub(r"\s+", " ", command_text.lower())
        if process in cls.BROWSER_APPS and any(phrase in lowered for phrase in cls.DELEGATION_PHRASES):
            service, token = cls._service_match(command_text, require_domain=False)
            return {
                "blocked": True,
                "reason": "禁止把推理/任务委托给第三方 AI",
                "service": service or "第三方 AI",
                "evidence": "即将输入/执行的委托文本:" + (token or lowered[:80]),
            }
        return {"blocked": False, "reason": "", "service": "", "evidence": ""}


class SafetyPolicy:
    """结构判断优先、文本判断补充；高影响行为默认拒绝或要求一次性精确批准。"""
    SENSITIVE = ("password", "credential", "windows security", "uac", "密码", "凭据", "安全验证", "支付", "payment", "checkout")
    IRREVERSIBLE = (
        "delete", "remove", "erase", "format", "purchase", "buy", "pay", "checkout", "place order", "submit order",
        "send", "upload", "install", "run script", "execute", "registry", "reset", "factory reset",
        "删除", "移除", "清空", "格式化", "购买", "付款", "支付", "提交订单", "下单", "发送", "上传", "安装", "执行脚本", "注册表", "重置",
    )
    GENERIC_CONFIRM = ("ok", "yes", "confirm", "continue", "apply", "确定", "确认", "继续", "应用", "是")
    SECURITY_WINDOWS = ("credential", "authui", "consent", "secure desktop", "windows security", "用户账户控制", "凭据", "安全验证")
    SAFE_CLICK_TYPES = {"Button", "Hyperlink", "MenuItem", "CheckBox", "RadioButton", "ComboBox", "ListItem", "TreeItem", "TabItem", "Edit"}
    SAFE_TEXT_TYPES = {"Edit", "Document", "ComboBox"}
    ALLOW_APPS = {"notepad.exe", "chrome.exe", "msedge.exe", "firefox.exe", "opera.exe", "brave.exe", "excel.exe", "winword.exe"}
    READONLY_APPS = {"systemsettings.exe"}
    DENY_APPS = {"powershell.exe", "pwsh.exe", "cmd.exe"}
    CAPABILITY_APPROVAL = {"filesystem_write", "external_send", "software_install", "financial_commit", "account_auth"}
    CAPABILITY_FORBIDDEN = {"credential_input"}
    HIGH_RISK_APPS = {"regedit.exe", "msiexec.exe", "taskmgr.exe", "mmc.exe", "wscript.exe", "cscript.exe"}

    def __init__(self):
        self.session_domain = None

    def set_session_domain(self, domain):
        self.session_domain = domain
        return domain

    @staticmethod
    def is_alt_tab(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x09 and 0x12 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def is_ctrl_s(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x53 and 0x11 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def is_alt_f4(command):
        return command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x73 and 0x12 in set(int(value) for value in command.parameters.get("modifiers", []))

    @staticmethod
    def _process_name(observation):
        value = str(getattr(observation, "process_name", "") or "").lower().strip()
        if value:
            return value
        path = str(getattr(observation, "process_path", "") or "").lower().strip()
        return os.path.basename(path)

    def _app_scope(self, observation):
        process = self._process_name(observation)
        title = str(getattr(observation.accessibility, "window_title", "") or "").lower()
        window_class = str(getattr(observation.accessibility, "window_class", "") or "").lower()
        # Windows Terminal 本身可能承载普通终端；仅当结构/标题明确是 shell 时按禁止处理。
        if process in self.DENY_APPS or (process == "windowsterminal.exe" and any(x in title for x in ("powershell", "command prompt", "cmd", "命令提示符"))):
            return "deny"
        if process in self.READONLY_APPS or "applicationframewindow" in window_class and "settings" in title:
            return "readonly"
        if process in self.ALLOW_APPS:
            return "allow"
        return "default"

    @staticmethod
    def _nearest(observation, command):
        if command.kind != CLICK:
            return None, 9.0
        x = float(command.parameters.get("x", 0.5)); y = float(command.parameters.get("y", 0.5))
        nearest, distance = None, 9.0
        for record in observation.accessibility.records:
            local = math.hypot(float(record.get("x_norm", 0.5)) - x, float(record.get("y_norm", 0.5)) - y)
            if local < distance:
                nearest, distance = record, local
        return nearest, distance

    def _structural_impact(self, command, observation, nearest=None):
        """根据进程、ControlType、AutomationId、对话框角色和前后文推断外部/不可逆影响。"""
        title = str(observation.accessibility.window_title or "").lower()
        window_class = str(observation.accessibility.window_class or "").lower()
        semantic = str(getattr(observation, "semantic_text", "") or "").lower()
        label = ""
        control_type = ""
        automation_id = ""
        if nearest is not None:
            label = " ".join((str(nearest.get("name", "")), str(nearest.get("help", "")), str(nearest.get("class_name", "")))).lower()
            automation_id = str(nearest.get("automation_id", "") or "").lower()
            control_type = str(nearest.get("control_type", "") or "")
        command_text = (str(command.label) + " " + compact_json(command.parameters)).lower()
        context = " ".join((title, window_class, semantic, label, automation_id, command_text))
        security_dialog = bool(getattr(observation, "any_password", False)) or any(word in (title + " " + window_class) for word in self.SECURITY_WINDOWS)
        if security_dialog:
            return "forbidden", "安全/凭据/UAC 结构"
        # 明确角色：对话框中的确认按钮、菜单项或 Enter，且上下文指向外部/不可逆副作用。
        role_commit = control_type in ("Button", "MenuItem", "Hyperlink") and (any(w in label for w in self.GENERIC_CONFIRM) or automation_id in ("1", "ok", "yes", "submit", "install", "delete"))
        text_risk = any(word in context for word in self.IRREVERSIBLE)
        enter_commit = command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D
        dialog_like = "dialog" in window_class or "#32770" in window_class or any(x in title for x in ("confirm", "warning", "确认", "警告", "安装", "付款", "结账"))
        if text_risk and (role_commit or enter_commit or dialog_like):
            return "approval", "结构化控件/对话框将产生高影响或不可逆结果"
        if command.kind == CLICK and text_risk:
            return "approval", "目标控件语义指向高影响操作"
        if command.kind == TYPE and any(word in command_text for word in ("run script", "execute", "执行脚本")):
            return "approval", "输入内容可能触发脚本执行"
        return "normal", ""

    @staticmethod
    def _shell_request(value):
        text = re.sub(r"\s+", " ", str(value or "").strip().lower())
        exact = {
            "powershell", "powershell.exe", "windows powershell", "pwsh", "pwsh.exe",
            "cmd", "cmd.exe", "command prompt", "windows command processor", "命令提示符",
        }
        if text in exact:
            return True
        # 对开始菜单中的典型启动命令采用保守匹配；普通文档/浏览器里提到这些词不会触发。
        return bool(re.fullmatch(r"(?:windows\s+)?powershell(?:\.exe)?(?:\s+-.*)?", text) or re.fullmatch(r"(?:cmd|cmd\.exe)(?:\s+/.*)?", text))

    def _shell_launch_from_search(self, command, observation):
        process = self._process_name(observation)
        title = str(getattr(observation.accessibility, "window_title", "") or "").lower()
        window_class = str(getattr(observation.accessibility, "window_class", "") or "").lower()
        semantic = str(getattr(observation, "semantic_text", "") or "").lower()
        focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
        focus_text = " ".join((
            str(focused.get("name", "")), str(focused.get("automation_id", "")),
            str(focused.get("class_name", "")), str(focused.get("value", "")),
        )).lower()
        search_process = process in {"searchhost.exe", "startmenuexperiencehost.exe", "explorer.exe", "shellexperiencehost.exe"}
        search_structure = any(token in (title + " " + window_class + " " + focus_text + " " + semantic) for token in (
            "start", "search", "type here to search", "searchbox", "开始", "搜索", "查找应用",
        ))
        if not (search_process and search_structure):
            return False
        if command.kind == TYPE:
            return self._shell_request(command.parameters.get("text", ""))
        if command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x0D:
            return self._shell_request(focused.get("value", "")) or self._shell_request(focused.get("name", ""))
        return False

    def _capabilities(self, command, observation, nearest=None):
        """以动作声明和控件结构为主，文字只作为未知自绘 UI 的补充信号。"""
        result = set(str(value) for value in (getattr(command, "required_capabilities", []) or []) if value)
        focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
        if command.kind == TYPE:
            result.add("document_write")
            if focused.get("password"):
                result.add("credential_input")
        if self.is_ctrl_s(command):
            result.add("filesystem_write")
        if command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x2E:
            result.add("filesystem_write")
        control = nearest or {}
        # Space/Enter 不只是“按键”：在 Windows UIA 中会激活当前聚焦控件。
        # 因此即使没有点击坐标，也必须按 focused control 推断发送/删除/支付/登录等 capability。
        if command.kind == KEY and int(command.parameters.get("vk", 0)) in (0x20, 0x0D):
            focused_type = str(focused.get("control_type", ""))
            if focused_type in {"Button", "MenuItem", "CheckBox", "RadioButton", "Hyperlink", "ListItem", "TreeItem", "TabItem"}:
                control = focused
        role = " ".join((
            str(control.get("automation_id", "")), str(control.get("name", "")),
            str(control.get("help", "")), str(control.get("class_name", "")), str(command.label),
            str(command.parameters.get("visual_target_text", "")),
        )).lower()
        role_id = str(control.get("automation_id", "") or "").lower()
        # 常见结构化提交角色；多语言/无文字控件仍可由技能显式声明 capability。
        if role_id in ("send", "submit", "submitmessage", "sendbutton", "upload", "publish") or any(value in role for value in ("发送", "提交", "上传", "发布", "send message", "send mail", "submit", "upload", "publish")):
            result.add("external_send")
        if role_id in ("install", "installbutton") or any(value in role for value in ("安装", "install now")):
            result.add("software_install")
        if role_id in ("pay", "checkout", "placeorder", "purchase", "buy") or any(value in role for value in ("支付", "付款", "购买", "下单", "place order", "checkout", "purchase", "buy now")):
            result.add("financial_commit")
        if role_id in ("delete", "remove", "rename", "save") or any(value in role for value in ("删除", "移除", "保存", "重命名", "delete file", "remove", "save", "rename file")):
            result.add("filesystem_write")
        if role_id in ("login", "signin", "sign-in") or any(value in role for value in ("登录", "登陆", "sign in", "log in", "login")):
            result.add("account_auth")
        return result

    @staticmethod
    def approval_token(command, observation):
        try:
            return ApprovalFreeze.capture(command, observation).token()
        except Exception:
            return ""

    @classmethod
    def _approved(cls, command, approved_fingerprint, observation=None, approved_context=""):
        if not approved_fingerprint or not secrets.compare_digest(str(approved_fingerprint), command.fingerprint()):
            return False
        if observation is None or not approved_context:
            return False
        current = cls.approval_token(command, observation)
        return bool(current) and secrets.compare_digest(str(approved_context), current)

    def assess(self, command, observation, safe_mode=True, approved_fingerprint="", approved_context="", observe_only=False, mode="task", autonomous_profile="observe"):
        mode = "autonomous" if str(mode).lower() == "autonomous" else "task"
        autonomous_profile = "operate" if str(autonomous_profile).lower() == "operate" else "observe"
        desktop_safe = bool(getattr(observation, "input_desktop_safe", True))
        if command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE) and not desktop_safe:
            return 1.0, "输入桌面不可确认或已进入 Secure Desktop：fail-closed 禁止所有 SendInput", True
        if self.session_domain is not None and command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
            session_scope = self.session_domain.classify(observation, command)
            if session_scope == "outside":
                return 0.96, "会话权限域：当前程序不属于初始应用，且没有明确 GoalCompiler 跨程序步骤", True
            process = self._process_name(observation)
            if session_scope == "declared" and process in self.HIGH_RISK_APPS and not self._approved(command, approved_fingerprint, observation, approved_context):
                if observe_only:
                    return 0.88, "只观察：跨入高风险程序将需要用户确认", False
                return 0.94, "需要用户确认：明确 GoalCompiler 步骤请求跨入高风险程序，原因：" + str(command.capability_reason), True
        scope = self._app_scope(observation)
        if self._shell_launch_from_search(command, observation):
            return 1.0, "应用权限范围：禁止从 Windows 搜索/开始菜单启动 PowerShell 或 cmd", True
        if scope == "deny" and command.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
            return 1.0, "应用权限范围：PowerShell/cmd 类命令行环境被硬禁止", True
        if scope == "readonly" and command.kind in (CLICK, KEY, TYPE):
            return 0.96, "应用权限范围：Windows 设置仅允许只读观察/滚动，不允许修改性输入", True

        title = observation.accessibility.window_title.lower()
        window_class = observation.accessibility.window_class.lower()
        structural_security = bool(getattr(observation, "any_password", False)) or any(word in (title + " " + window_class) for word in self.SECURITY_WINDOWS)
        focused = [record for record in observation.accessibility.records if record.get("focused")]
        focused_sensitive = any(record.get("password") or any(word in (str(record.get("name", "")) + " " + str(record.get("class_name", ""))).lower() for word in self.SENSITIVE) for record in focused)
        if command.kind in (KEY, TYPE) and (structural_security or focused_sensitive):
            return 0.98, "禁止向密码、凭据、UAC 或支付安全界面发送键盘输入", True
        if mode == "autonomous" and autonomous_profile == "observe" and command.kind == TYPE:
            return 0.98, "自主模式默认只读：禁止文本输入；写入必须来自明确的发送任务", True
        if mode == "autonomous" and autonomous_profile == "observe" and command.kind == KEY:
            vk = int(command.parameters.get("vk", 0)); modifiers = set(int(value) for value in command.parameters.get("modifiers", []))
            # Space/Enter 会激活当前聚焦的 Button/MenuItem/CheckBox 等控件，不能被当作纯导航。
            # 自主模式采用保守权限域：只保留不会直接“按下当前控件”的导航键。
            navigation_keys = {0x09, 0x25, 0x26, 0x27, 0x28, 0x21, 0x22, 0x24, 0x23}
            if modifiers or vk not in navigation_keys:
                return 0.94, "自主模式只允许 Tab/方向键/PageUp/PageDown/Home/End；Space/Enter 等可激活控件的按键被禁止", True
        if command.kind == KEY:
            virtual_key = int(command.parameters.get("vk", 0)); modifiers = set(int(value) for value in command.parameters.get("modifiers", []))
            if virtual_key == 0x1B:
                return 1.0, "ESC 专用于紧急停止", True
            if virtual_key in (0x10, 0x11, 0x12, 0x5B, 0x5C):
                return 0.55, "不允许单独压下修饰键", True
            if safe_mode and virtual_key == 0x56 and 0x11 in modifiers:
                return 0.82, "安全模式禁止粘贴未知剪贴板内容；AI 本轮未写入剪贴板", True
            if self.is_alt_tab(command) and not (
                "cross_program" in set(command.required_capabilities)
                and str(command.capability_reason).strip()
                and str(getattr(command, "compiled_scope_token", "")).strip()
            ):
                return 0.86, "会话权限域：Alt+Tab 会跨程序，只有明确 GoalCompiler 跨程序步骤可授权", True
            if self.is_alt_f4(command):
                # 关闭普通窗口本身可组合；若存在未保存提示/星号，再进入精确批准。
                unsaved = any(x in (title + " " + str(getattr(observation, "semantic_text", "")).lower()) for x in ("unsaved", "save changes", "未保存", "保存更改")) or title.rstrip().endswith("*")
                if unsaved:
                    if self._approved(command, approved_fingerprint, observation, approved_context):
                        return 0.12, "已批准本次冻结上下文中的带未保存状态关闭动作", False
                    return 0.90, "需要用户确认：当前窗口可能包含未保存内容，关闭可能丢失数据", True
        if safe_mode and command.kind == TYPE:
            focused_normal = [record for record in focused if record.get("enabled") and not record.get("offscreen") and record.get("control_type") in self.SAFE_TEXT_TYPES and not record.get("password")]
            if not focused_normal:
                return 0.66, "安全模式只向明确聚焦的普通可编辑控件输入文本", True

        nearest, distance = self._nearest(observation, command)
        capabilities = self._capabilities(command, observation, nearest)
        inferred = capabilities - set(command.required_capabilities)
        if inferred:
            command.declare(inferred, command.capability_reason or "执行前由控件结构推断 capability")
        if mode == "autonomous" and autonomous_profile == "observe" and capabilities:
            # 自主模式的默认权限域是只读/导航；任何可能产生外部副作用的 capability 都直接拒绝，
            # 不通过“随机探索 + 用户审批”来扩大权限。
            side_effects = capabilities & {"document_write", "filesystem_write", "external_send", "software_install", "financial_commit", "credential_input", "account_auth"}
            if side_effects:
                return 0.98, "自主模式禁止外部副作用能力：" + ",".join(sorted(side_effects)), True
        if mode == "autonomous" and autonomous_profile == "observe" and command.kind == CLICK:
            control = nearest or {}
            role = str(control.get("control_type", ""))
            text = " ".join((str(control.get("name", "")), str(control.get("automation_id", "")), str(command.label))).lower()
            deny_words = ("发送", "提交", "保存", "删除", "安装", "购买", "支付", "登录", "注册", "send", "submit", "save", "delete", "install", "buy", "purchase", "pay", "login", "sign in")
            nav_words = ("返回", "前进", "下一", "上一", "更多", "展开", "打开", "查看", "back", "forward", "next", "previous", "more", "expand", "open", "view")
            role_ok = role in {"Hyperlink", "TabItem", "TreeItem", "ListItem", "MenuItem"}
            named_button_ok = role == "Button" and any(word in text for word in nav_words)
            if nearest is None or any(word in text for word in deny_words) or not (role_ok or named_button_ok):
                return 0.92, "自主模式只允许有 UIA 证据的低风险导航点击", True
        forbidden = sorted(capabilities & self.CAPABILITY_FORBIDDEN)
        if forbidden:
            if observe_only:
                return 0.98, "只观察：检测到禁止能力 " + ",".join(forbidden), False
            return 0.98, "能力策略禁止自动执行：" + ",".join(forbidden), True
        approval = sorted(capabilities & self.CAPABILITY_APPROVAL)
        if approval and not self._approved(command, approved_fingerprint, observation, approved_context):
            if observe_only:
                return 0.90, "只观察：实际执行将需要 capability 确认：" + ",".join(approval), False
            return 0.93, "需要用户确认：动作声明/结构检测到外部副作用能力 " + ",".join(approval), True
        if command.kind == CLICK:
            verified_skill = str(getattr(command, "evidence_source", "")) == "verified_skill"
            remote_visual = bool(command.parameters.get("remote_visual_target"))
            trusted_local_visual = bool(command.parameters.get("explicit_visual_target"))
            local_visual_stable = bool(command.parameters.get("local_visual_stable"))
            non_uia_evidence = verified_skill or trusted_local_visual or local_visual_stable
            if remote_visual and not local_visual_stable and nearest is None:
                return 0.90, "远程视觉坐标只能作为建议：本地连续两帧未确认目标稳定，拒绝点击", True
            if nearest is None and not non_uia_evidence:
                return 0.84, "CLICK 缺少本地证据：必须来自当前 UIA 可交互控件、本地两帧稳定视觉目标或已验证技能", True
            if safe_mode and not non_uia_evidence and (nearest is None or distance >= 0.085 or nearest.get("control_type") not in self.SAFE_CLICK_TYPES or not nearest.get("enabled") or nearest.get("offscreen")):
                return 0.68, "安全模式只点击当前重新识别出的普通 UIA 控件", True
            if remote_visual and nearest is None:
                visual_text = " ".join((str(command.parameters.get("visual_target_text", "")), str(command.label))).lower()
                low_risk_words = ("返回", "前进", "下一", "上一", "更多", "展开", "打开", "查看", "back", "forward", "next", "previous", "more", "expand", "open", "view")
                if not any(word in visual_text for word in low_risk_words):
                    if self._approved(command, approved_fingerprint, observation, approved_context):
                        return 0.10, "已获得本次冻结上下文中的非 UIA 视觉点击一次性确认", False
                    return 0.91, "需要用户确认：非 UIA 自绘/纯坐标点击虽已本地两帧稳定，但无法可靠判断是否产生发送、删除、安装、购买、支付、登录等副作用", True
            if nearest and distance < 0.10 and nearest.get("password"):
                return 0.58, "不操作密码控件", True
            if command.parameters.get("button") == "right":
                return 0.02, "右键操作具有轻微风险", False

        impact, impact_reason = self._structural_impact(command, observation, nearest)
        if impact == "forbidden":
            return 0.98, impact_reason, True
        # HardSafetyPolicy：不可逆/外部副作用确认永远生效，不能被“安全模式”开关关闭。
        # safe_mode 只控制下面那些更保守、可由用户关闭的 ConservativeSafeMode 约束。
        if impact == "approval":
            if self._approved(command, approved_fingerprint, observation, approved_context):
                return 0.10, "已获得本次冻结参数/窗口/UIA 上下文的一次性用户确认", False
            return 0.92, "需要用户确认：" + impact_reason, True
        return 0.0, "", False


class TaskExitPolicy:
    """可学习的任务退出策略：估计继续规划的成功概率与期望价值，而非依赖固定轮数退出。"""

    DEFAULT_WEIGHTS = {
        "failure_probability": 0.30,
        "unreachable_probability": 0.22,
        "no_progress": 0.18,
        "repeated_failure": 0.12,
        "reasoning_uncertainty": 0.10,
        "safety_pressure": 0.08,
    }
    METADATA_KEY = "task_exit_policy_v2"

    def __init__(self, memory=None):
        self.memory = memory
        self.weights = dict(self.DEFAULT_WEIGHTS)
        self.threshold = 0.72
        self.history = deque(maxlen=64)
        if memory is not None:
            try:
                payload = json.loads(memory.get_metadata(self.METADATA_KEY, "{}"))
                stored = dict(payload.get("weights") or {})
                for name in self.weights:
                    if name in stored:
                        self.weights[name] = clamp(safe_float(stored[name], self.weights[name]), 0.02, 0.60)
                total = sum(self.weights.values())
                if total > 0:
                    self.weights = {name: value / total for name, value in self.weights.items()}
                self.threshold = clamp(safe_float(payload.get("threshold", self.threshold), self.threshold), 0.58, 0.88)
            except Exception:
                pass

    def begin_task(self):
        self.history.clear()

    def _persist(self):
        if self.memory is None:
            return
        try:
            self.memory.set_metadata(self.METADATA_KEY, compact_json({
                "weights": self.weights, "threshold": self.threshold, "updated_at": time.time(),
            }), commit=False)
        except Exception:
            pass

    def _learn(self, target, decisions=None):
        decisions = list(decisions if decisions is not None else self.history)
        if not decisions:
            return
        learning_rate = 0.025 / math.sqrt(max(1.0, len(decisions)))
        for decision in decisions[-16:]:
            score = safe_float(decision.get("exit_score", 0.5), 0.5)
            error = clamp(float(target) - score, -1.0, 1.0)
            for name in self.weights:
                feature = safe_float((decision.get("features") or {}).get(name, 0.0))
                self.weights[name] = clamp(self.weights[name] + learning_rate * error * feature, 0.02, 0.60)
            # 成功前曾想过退出时提高门槛；真实失败且退出分数偏低时降低门槛。
            self.threshold = clamp(self.threshold - learning_rate * error * 0.35, 0.58, 0.88)
        total = sum(self.weights.values())
        self.weights = {name: value / max(1e-9, total) for name, value in self.weights.items()}
        self._persist()

    def observe_progress(self):
        if self.history:
            self._learn(0.0, [self.history[-1]])

    def learn_task_outcome(self, succeeded, category=""):
        if bool(succeeded):
            self._learn(0.0)
        elif str(category) in ("unreachable", "no_evidence"):
            self._learn(1.0, list(self.history)[-8:])
        self.history.clear()

    def evaluate(self, mode, explicit_goal, goal_completed, no_progress_replans=0, fail_score=0,
                 compiler_stalled_count=0, reasoning_failure_streak=0, repeated_block_count=0,
                 blocked=False, blocked_reason="", safety_penalty=0.0, approval_required=False,
                 success_probability=None, reachable_confidence=None, recent_progress=0.0,
                 world_uncertainty=1.0, expected_next_value=0.0, alternative_plan_count=0):
        if str(mode) != "task":
            return {"should_exit": False, "reason": "", "completed": False, "category": "continue"}
        if approval_required:
            return {"should_exit": True, "reason": "需要用户批准", "completed": False, "category": "approval"}
        if bool(goal_completed) and bool(explicit_goal):
            return {"should_exit": True, "reason": "目标已完成", "completed": True, "category": "completed"}
        if bool(blocked) and safe_float(safety_penalty) >= 0.85 and int(repeated_block_count) >= 8:
            reason = "安全策略判定不可继续"
            if blocked_reason:
                reason += "：" + str(blocked_reason)[:180]
            return {"should_exit": True, "reason": reason, "completed": False, "category": "safety"}
        no_progress_replans = max(0, int(no_progress_replans))
        compiler_stalled_count = max(0, int(compiler_stalled_count))
        reasoning_failure_streak = max(0, int(reasoning_failure_streak))
        repeated_block_count = max(0, int(repeated_block_count))
        alternative_plan_count = max(0, int(alternative_plan_count))
        recent_progress = clamp(safe_float(recent_progress), 0.0, 1.0)
        world_uncertainty = clamp(safe_float(world_uncertainty, 1.0), 0.0, 1.0)
        expected_next_value = clamp((safe_float(expected_next_value) + 1.0) * 0.5, 0.0, 1.0)
        if success_probability is None:
            success_probability = clamp(
                0.10 + recent_progress * 0.52 + (1.0 - world_uncertainty) * 0.18
                + min(0.20, math.log1p(alternative_plan_count) * 0.08), 0.0, 1.0,
            )
        else:
            success_probability = clamp(safe_float(success_probability), 0.0, 1.0)
        if reachable_confidence is None:
            reachable_confidence = clamp(
                (1.0 - world_uncertainty) * 0.42
                + min(0.42, math.log1p(alternative_plan_count) * 0.18)
                + expected_next_value * 0.16
                - (1.0 - math.exp(-compiler_stalled_count / 7.0)) * 0.35,
                0.0, 1.0,
            )
        else:
            reachable_confidence = clamp(safe_float(reachable_confidence), 0.0, 1.0)

        evidence_strength = clamp(
            (1.0 - math.exp(-no_progress_replans / 8.0)) * 0.55
            + (1.0 - math.exp(-(reasoning_failure_streak + repeated_block_count) / 6.0)) * 0.30
            + (1.0 - math.exp(-compiler_stalled_count / 6.0)) * 0.15,
            0.0, 1.0,
        )
        features = {
            "failure_probability": 1.0 - success_probability,
            "unreachable_probability": 1.0 - reachable_confidence,
            "no_progress": clamp((1.0 - math.exp(-no_progress_replans / 10.0)) * (1.0 - recent_progress), 0.0, 1.0),
            "repeated_failure": clamp(1.0 - math.exp(-(reasoning_failure_streak + repeated_block_count + max(0, int(fail_score)) / 12.0) / 10.0), 0.0, 1.0),
            "reasoning_uncertainty": clamp(world_uncertainty * 0.72 + (1.0 - expected_next_value) * 0.28, 0.0, 1.0),
            "safety_pressure": clamp(max(safe_float(safety_penalty), repeated_block_count / 10.0 if blocked else 0.0), 0.0, 1.0),
        }
        raw_score = sum(self.weights[name] * features[name] for name in self.weights)
        # 少量观察不能证明不可达：证据强度连续缩放分数，不再用 44/28/18 等轮数作退出主判据。
        exit_score = clamp(raw_score * (0.42 + evidence_strength * 0.58), 0.0, 1.0)
        decision = {
            "should_exit": bool(exit_score >= self.threshold),
            "reason": "", "completed": False, "category": "continue",
            "exit_score": exit_score, "threshold": self.threshold,
            "features": features, "weights": dict(self.weights),
            "success_probability": success_probability,
            "reachable_confidence": reachable_confidence,
            "alternative_plan_count": alternative_plan_count,
            "evidence_strength": evidence_strength,
        }
        self.history.append(dict(decision))
        if decision["should_exit"]:
            category = "unreachable" if features["unreachable_probability"] >= 0.72 else "no_evidence"
            decision["category"] = category
            decision["reason"] = (
                "后续计划成功概率过低，目标当前不可达"
                if category == "unreachable" else
                "继续规划的期望价值低且近期无可靠进展"
            ) + "（exit_score={:.3f}, P(success)={:.3f}, alternatives={}）".format(
                exit_score, success_probability, alternative_plan_count,
            )
        return decision


class RewardEngine:

    @staticmethod
    def _difference(previous, current):
        global_change = sum(abs(a - b) for a, b in zip(previous.global_rgb, current.global_rgb)) / max(1, len(previous.global_rgb))
        patch_changes = []
        for first, second in zip(previous.patches, current.patches):
            patch_changes.append(sum(abs(a - b) for a, b in zip(first, second)) / max(1, len(first)))
        patch_change = sum(patch_changes) / max(1, len(patch_changes))
        structural = 1.0 if previous.semantic_signature != current.semantic_signature else 0.0
        return global_change, patch_change, structural

    def evaluate(self, command, previous, current, repeated, stagnant, goal_result, visits_before, outcome, duration):
        global_change, patch_change, structured_change = self._difference(previous, current)
        effect = global_change * 0.55 + patch_change * 0.45
        goal_reward = float(goal_result.get("reward", 0.0))

        curiosity_reward = 0.0
        if command.kind not in (WAIT, SLEEP) and (structured_change or effect >= 0.004):
            novelty = 1.0 / math.sqrt(visits_before + 1.0)
            curiosity_reward = clamp(novelty * (0.18 if structured_change else min(0.10, effect * 1.2)), 0.0, 0.22)
            if command.kind == MOVE:
                curiosity_reward *= 0.10
            elif command.kind == SCROLL:
                curiosity_reward *= 0.32

        action_costs = {WAIT: 0.025, MOVE: 0.025, CLICK: 0.04, SCROLL: 0.035, KEY: 0.04, TYPE: 0.035, SKILL: 0.03}
        efficiency_reward = -action_costs.get(command.kind, 0.02) - min(0.08, duration * 0.008)
        efficiency_reward -= max(0, repeated - 2) * 0.025
        if stagnant > 20:
            efficiency_reward -= min(0.15, (stagnant - 20) * 0.006)
        interactive = command.kind in (CLICK, SCROLL, KEY, TYPE, SKILL)
        if interactive and effect < 0.0025 and not structured_change and not outcome.get("blocked"):
            efficiency_reward -= 0.075
        if effect > 0.34 and not structured_change:
            efficiency_reward -= min(0.20, (effect - 0.34) * 0.8)
        if goal_result.get("progress", 0.0) > 0.0:
            efficiency_reward += min(0.20, float(goal_result["progress"]) * 0.22)
        efficiency_reward = clamp(efficiency_reward, -0.45, 0.25)

        safety_penalty = clamp(float(outcome.get("safety_penalty", 0.0)), 0.0, 1.0)
        total = goal_reward * 0.78 + curiosity_reward * 0.08 + efficiency_reward * 0.14 - safety_penalty
        total = clamp(total, -1.0, 1.0)
        return total, {
            "goal_reward": goal_reward, "curiosity_reward": curiosity_reward,
            "efficiency_reward": efficiency_reward, "safety_penalty": safety_penalty,
            "goal_progress": float(goal_result.get("progress", 0.0)), "goal_completed": bool(goal_result.get("completed")),
            "effect": effect, "global_change": global_change, "patch_change": patch_change,
            "structured_change": structured_change, "signature": current.signature,
        }


class LocalTextGenerator:
    """纯本地确定性文本组合器：模板 + UI 上下文 + 长期成功文本；不做字符级随机生成。"""

    @staticmethod
    def _clean(value):
        return str(value or "").replace("\x00", "").strip()

    @staticmethod
    def _unicode_literals(text):
        chars = []
        for token in re.findall(r"(?:U\+|u\+)([0-9a-fA-F]{1,6})", str(text or "")):
            try:
                codepoint = int(token, 16)
                if 0 <= codepoint <= 0x10FFFF and not 0xD800 <= codepoint <= 0xDFFF:
                    chars.append(chr(codepoint))
            except ValueError:
                pass
        return "".join(chars)

    def generate(self, goal, observation, control, remembered):
        literal = self._unicode_literals(" ".join((goal.requested_goal, goal.success_text)))
        if literal:
            return literal
        # 1) 明确目标文本始终精确复用。
        preferred = [self._clean(value) for value in goal.text_candidates()]
        preferred = [value for value in dict.fromkeys(preferred) if value]
        if preferred:
            return preferred[0]
        # 2) 没有明确文本时只检索成功历史文本，不拼接随机字符。
        remembered = [self._clean(value) for value in (remembered or [])]
        remembered = [value for value in dict.fromkeys(remembered) if value]
        if remembered:
            index = min(len(remembered) - 1, int(clamp(float(control), 0.0, 1.0) * len(remembered)))
            return remembered[index]
        # 3) UI 上下文只用于安全模板：优先取已聚焦编辑控件已有值/名称；无可靠内容则放弃输入。
        if observation is not None:
            focused = next((record for record in observation.accessibility.records if record.get("focused") and record.get("control_type") in ("Edit", "Document", "ComboBox") and not record.get("password")), None)
            if focused is not None:
                existing = self._clean(focused.get("value", ""))
                if existing:
                    return existing
        return ""


class DeliberationScorer:
    """统一多候选评分：成功/收益 - 风险 - 不确定性 - 失败记忆 - 时间/计划成本。"""

    @staticmethod
    def score(q_value=0.0, bias=0.0, predicted_reward=0.0, future_value=0.0, plan_cost=0.0,
              plan_risk=0.0, predicted_safety=0.0, uncertainty=1.0, failure_score=0.0, time_cost=0.0,
              support=0):
        support_bonus = min(0.10, math.log1p(max(0, int(support))) * 0.025)
        success_proxy = clamp((safe_float(predicted_reward) + 1.0) * 0.5, 0.0, 1.0)
        return (
            safe_float(q_value) + safe_float(bias)
            + safe_float(predicted_reward) * 0.74
            + safe_float(future_value) * 0.42
            + success_proxy * 0.18
            + support_bonus
            - safe_float(plan_cost) * 0.10
            - safe_float(plan_risk) * 0.48
            - safe_float(predicted_safety) * 0.70
            - safe_float(uncertainty, 1.0) * 0.26
            - safe_float(failure_score) * 0.55
            - safe_float(time_cost) * 0.03
        )


class ActionPlanner:
    def __init__(self, memory, breadth=48, world_model=None, resource_budget=None):
        self.memory = memory
        self.world_model = world_model or WorldModel(memory)
        self.breadth = max(16, int(breadth))
        self.text_generator = LocalTextGenerator()
        self.operator_planner = GenericOperatorPlanner(resource_budget)
        self.meta_report = {}

    def set_meta_report(self, report):
        self.meta_report = dict(report or {})

    def state_uncertainty(self, state, observation, allowed):
        return self.world_model.state_uncertainty(state, getattr(observation, "fuzzy_key", ""), allowed)

    def set_breadth(self, breadth):
        self.breadth = max(self.breadth, int(breadth))

    @staticmethod
    def _perturb(values, exploration, count):
        values = list(values)[:count] + [0.5] * max(0, count - len(values))
        if not exploration:
            return [clamp(value, 0.0, 1.0) for value in values]
        return [clamp(value + random.uniform(-0.28, 0.28), 0.0, 1.0) for value in values]

    def action_biases(self, signature, eligible_skills):
        failures = self.memory.failure_action_scores(signature)
        result = {kind: -0.82 * score for kind, score in failures.items()}
        if eligible_skills:
            bonuses = []
            for skill in eligible_skills:
                uses = max(1, int(skill.get("uses", 0)))
                success = int(skill.get("successes", 0)) / uses
                bonuses.append(success * 0.22 + clamp(float(skill.get("score", 0.0)), -1.0, 1.0) * 0.08)
            result[SKILL] = result.get(SKILL, 0.0) + max(bonuses)
        bottleneck = str((self.meta_report or {}).get("bottleneck", ""))
        if bottleneck == "perception":
            result[WAIT] = result.get(WAIT, 0.0) + 0.18
            result[MOVE] = result.get(MOVE, 0.0) + 0.05
            result[CLICK] = result.get(CLICK, 0.0) - 0.16
        elif bottleneck in ("skill", "planning"):
            result[SKILL] = result.get(SKILL, 0.0) + 0.10
        elif bottleneck == "knowledge":
            result[WAIT] = result.get(WAIT, 0.0) + 0.08
        return result

    def text_candidates(self, goal, observation=None):
        values = goal.text_candidates() + self.memory.text_candidates(32)
        if goal.explicit:
            values.extend((goal.requested_goal, goal.success_text, goal.goal_label))
        if observation is not None and (goal.explicit or any(record.get("focused") and record.get("control_type") in ("Edit", "Document") for record in observation.accessibility.records)):
            values.extend(record.get("name", "") for record in observation.accessibility.records if record.get("name"))
        result = []
        for value in values:
            value = str(value)
            if value and value not in result:
                result.append(value)
        return result

    @staticmethod
    def key_candidates(observation):
        values = [
            (0x09, (), "Tab"), (0x09, (0x10,), "Shift+Tab"), (0x0D, (), "Enter"), (0x20, (), "Space"),
            (0x08, (), "Backspace"), (0x25, (), "Left"), (0x27, (), "Right"), (0x26, (), "Up"), (0x28, (), "Down"),
            (0x24, (), "Home"), (0x23, (), "End"), (0x21, (), "PageUp"), (0x22, (), "PageDown"),
            (0x41, (0x11,), "Ctrl+A"), (0x43, (0x11,), "Ctrl+C"), (0x56, (0x11,), "Ctrl+V"),
            (0x53, (0x11,), "Ctrl+S"), (0x4C, (0x11,), "Ctrl+L"), (0x46, (0x11,), "Ctrl+F"),
            (0x5A, (0x11,), "Ctrl+Z"), (0x59, (0x11,), "Ctrl+Y"), (0x09, (0x12,), "Alt+Tab"),
        ]
        focused_types = {record.get("control_type") for record in observation.accessibility.records if record.get("focused")}
        if "Edit" in focused_types or "Document" in focused_types:
            values = [values[0], values[1], values[2], values[4], values[13], values[16], values[17], values[18], values[19]] + values[5:13]
        return values

    def _choose_point(self, parameters, observation, goal, exploration, for_click=False):
        candidates = []
        if goal.target_point:
            candidates.append((goal.target_point[0], goal.target_point[1], "明确目标", 5.0, control_locator(goal.target_record)))
        records = [record for record in observation.accessibility.records if record.get("enabled") and not record.get("offscreen") and not record.get("password")]
        if for_click:
            # CLICK 候选只能来自当前可交互 UIA 控件；动态视觉块不再作为“试试看”的点击点。
            records = [record for record in records if record.get("control_type") in INTERACTIVE_CONTROL_TYPES]
        records = records[:self.breadth]
        for record in records:
            priority = 2.0 if record.get("control_type") in INTERACTIVE_CONTROL_TYPES else 1.0
            if record.get("focused"):
                priority += 1.5
            candidates.append((float(record.get("x_norm", 0.5)), float(record.get("y_norm", 0.5)), record.get("name") or record.get("control_type", "控件"), priority, control_locator(record)))
        if not for_click:
            candidates.extend((x, y, "动态区域", 0.5, {}) for x, y in observation.patch_centers)
        desired = (parameters[0], parameters[1])
        if goal.target_point and random.random() < (0.72 if not exploration else 0.48):
            return goal.target_point[0], goal.target_point[1], "明确目标", control_locator(goal.target_record)
        if candidates:
            # 探索只能在已有证据的候选集合里随机，不能创造无证据 CLICK 坐标。
            if exploration and random.random() < 0.35:
                chosen = random.choice(candidates)
                return chosen[0], chosen[1], chosen[2], chosen[4]
            chosen = min(candidates, key=lambda point: math.hypot(point[0] - desired[0], point[1] - desired[1]) - point[3] * 0.015)
            return chosen[0], chosen[1], chosen[2], chosen[4]
        return desired[0], desired[1], "无点击证据" if for_click else "坐标", {}

    def allowed(self, settings, awake_steps, text_candidates, eligible_skills, allow_sleep=False):
        allowed = [WAIT, MOVE, SCROLL]
        if allow_sleep:
            allowed.append(SLEEP)
        mode = "autonomous" if str(settings.get("mode", "task")).lower() == "autonomous" else "task"
        autonomous_profile = "operate" if str(settings.get("autonomous_profile", "observe")).lower() == "operate" else "observe"
        if settings.get("clicks"):
            allowed.append(CLICK)
        if settings.get("keyboard"):
            allowed.append(KEY)
            if (mode == "task" or autonomous_profile == "operate") and text_candidates:
                allowed.append(TYPE)
        if mode == "task" and eligible_skills:
            allowed.append(SKILL)
        return list(dict.fromkeys(allowed))

    def _lookahead_value(self, model, state, signature, allowed_mask, depth, cache, state_key=""):
        state = normalize_state(state, model.input_count)
        allowed = actions_from_mask(allowed_mask)
        if not allowed:
            return 0.0
        key = (str(signature), str(state_key), int(allowed_mask), int(depth))
        if key in cache:
            return cache[key]
        forward_key = ("forward", str(signature), str(state_key), int(allowed_mask))
        if forward_key in cache:
            q_values = cache[forward_key]
        else:
            _, q_values, _ = model.forward(state)
            cache[forward_key] = q_values
        top = sorted(allowed, key=lambda action: q_values[action], reverse=True)
        if depth <= 0:
            value = max(q_values[action] for action in top)
            cache[key] = value
            return value
        best = -1e9
        for action in top:
            # 优先使用可泛化世界模型；不确定度过高时回退到精确/模糊历史转移。
            prediction = self.world_model.predict(state, action, state_key)
            uncertainty = float(prediction.get("uncertainty", 1.0))
            if prediction.get("support", 0) and uncertainty <= 0.78:
                next_mask = int(prediction.get("next_mask", 0)) or allowed_mask
                future = self._lookahead_value(
                    model, prediction["predicted_state"], prediction.get("next_signature", ""), next_mask,
                    depth - 1, cache, prediction.get("next_state_key", ""),
                )
                action_value = float(prediction.get("reward", 0.0)) + 0.94 * future - float(prediction.get("safety", 0.0)) * 0.50
                action_value -= uncertainty * (0.18 if action in (CLICK, KEY, TYPE, SKILL) else 0.06)
            else:
                transition_limit = max(2, int(math.sqrt(max(1, self.breadth))))
                transitions = self.memory.predict_transitions(signature, action, transition_limit, state_key=state_key) if signature else []
                if transitions:
                    unique = {}
                    for item in transitions:
                        transition_key = (item.get("next_signature", ""), item.get("next_state_key", ""), int(item.get("next_mask", 0)))
                        if transition_key not in unique or float(item.get("priority", 0.0)) > float(unique[transition_key].get("priority", 0.0)):
                            unique[transition_key] = item
                    estimates = []
                    for item in unique.values():
                        future = self._lookahead_value(model, item["next_state"], item.get("next_signature", ""), item.get("next_mask", 0), depth - 1, cache, item.get("next_state_key", ""))
                        estimates.append(float(item.get("reward", 0.0)) + 0.94 * future - float(item.get("safety_penalty", 0.0)) * 0.45)
                    action_value = sum(estimates) / len(estimates)
                else:
                    action_value = q_values[action] - (0.12 if action in (CLICK, KEY, TYPE, SKILL) else 0.02)
            best = max(best, action_value)
        cache[key] = best
        return best

    @staticmethod
    def _browser_context(observation):
        window_class = str(observation.accessibility.window_class or "").lower()
        title = str(observation.accessibility.window_title or "").lower()
        browser_classes = ("chrome_widgetwin", "mozillawindowclass")
        if any(value in window_class for value in browser_classes):
            return True
        browser_terms = ("microsoft edge", "google chrome", "mozilla firefox", "浏览器")
        if any(value in title for value in browser_terms):
            return True
        for record in observation.accessibility.records:
            text = " ".join((str(record.get("name", "")), str(record.get("automation_id", "")), str(record.get("help", "")))).lower()
            if record.get("control_type") in ("Edit", "ComboBox") and any(term in text for term in ("address", "omnibox", "search bar", "地址", "搜索栏")):
                return True
        return False

    @staticmethod
    def _start_search_context(observation):
        title = str(observation.accessibility.window_title or "").strip().lower()
        window_class = str(observation.accessibility.window_class or "").lower()
        semantic = observation.semantic_text.lower()
        if title in ("search", "windows search", "start", "搜索", "开始"):
            return True
        if len(title) <= 48 and any(term in title for term in ("windows search", "search", "搜索")):
            return True
        shell_classes = ("windows.ui.core.corewindow", "xamlexplorerhostislandwindow", "startmenuexperiencehost")
        return any(term in window_class for term in shell_classes) and any(term in semantic for term in ("search", "搜索", "type here to search"))

    def _legacy_compiled_command(self, goal, observation, allowed, settings=None):
        """执行 GoalCompiler 的单个子目标状态机；每次只发一个原子动作，动作后必须重新感知。"""
        step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else None
        if step is None:
            return None
        operation = str(step.get("operation") or step.get("action", ""))
        action = str(step.get("action", ""))
        payload = str(step.get("payload", "")).strip()
        target = str(step.get("target", "") or payload).strip()
        value = str(step.get("value", "") or payload).strip()
        safe_mode = True if settings is None else bool(settings.get("safe_mode", True))
        knowledge_cache = {}
        max_retries = max(0, int(step.get("max_retries", 2)))
        if str(getattr(goal, "compiled_phase", "")) == "recovery" and int(getattr(goal, "compiled_attempts", 0)) > max_retries:
            goal.compiler_stalled = True
            if WAIT in allowed:
                return ActionCommand(WAIT, {"duration": 0.22}, "子目标恢复次数耗尽：停止盲重试，等待元认知睡眠/重新规划", [0.5], 0b1)
            return None

        def emit(command, phase):
            capabilities = list(step.get("capabilities") or [])
            reason = "目标子步骤 {}：{}".format(operation, str(step.get("source", "") or payload)[:240])
            if operation in ("ensure_application",) and "cross_program" not in capabilities:
                capabilities.append("cross_program")
                reason = "为完成目标而切换/启动指定应用：" + str(step.get("target", "") or payload)[:220]
            command.declare(capabilities, reason if capabilities else "")
            explicit_cross_step = operation in ("ensure_application",) or "cross_program" in set(str(value) for value in (step.get("capabilities") or []))
            if explicit_cross_step and "cross_program" in set(command.required_capabilities):
                # 只有 GoalCompiler 步骤本身明确要求跨程序时才生成运行期租约。控件/Planner 临时声明不能扩域。
                token_source = "|".join((str(operation), str(step.get("source", "")), str(step.get("target", "")), str(step.get("payload", ""))))
                command.compiled_scope_token = hashlib.blake2s(token_source.encode("utf-8", "ignore"), digest_size=10).hexdigest()
                if operation == "ensure_application":
                    modifiers = set(int(value) for value in command.parameters.get("modifiers", []) or []) if command.kind == KEY else set()
                    if command.kind == KEY and int(command.parameters.get("vk", 0)) == 0x53 and 0x5B in modifiers:
                        # ensure_application 的显式 launcher 中间态，只授权 Windows Search，本身不能扩成任意程序。
                        command.compiled_scope_target = "Windows Search"
                    else:
                        command.compiled_scope_target = str(step.get("target", "") or step.get("payload", ""))[:220]
            if hasattr(goal, "set_compiled_phase"):
                goal.set_compiled_phase(phase, attempted=True)
            return command

        def record_text(record):
            return " ".join((str(record.get("name", "")), str(record.get("automation_id", "")), str(record.get("help", "")), str(record.get("value", "")), str(record.get("class_name", ""))))

        def matching_control(types=None, query=None, threshold=0.28):
            query = target if query is None else str(query)
            best = None
            best_score = -1.0
            qlower = query.lower().strip()
            for record in observation.accessibility.records:
                if record.get("offscreen") or not record.get("enabled") or record.get("password"):
                    continue
                if types and record.get("control_type") not in types:
                    continue
                text = record_text(record)
                lower = text.lower()
                score = similarity(query, text) if query else 0.0
                name = str(record.get("name", "")).strip().lower()
                if qlower and qlower == name:
                    score += 1.15
                elif qlower and qlower in lower:
                    score += 0.62
                if record.get("focused"):
                    score += 0.08
                # 知识成长真正参与定位：过去见过的 AutomationId/ControlType 只提供语义先验，最终仍必须匹配当前 UIA 控件。
                cache_key = (str(getattr(observation, "process_name", "") or "").lower(), query)
                if cache_key not in knowledge_cache:
                    knowledge_cache[cache_key] = self.memory.known_control_hints(cache_key[0], query, limit=8)
                for hint in knowledge_cache[cache_key]:
                    if hint.get("automation_id") and str(hint.get("automation_id")) == str(record.get("automation_id", "")):
                        score += 0.42
                    if hint.get("control_type") and hint.get("control_type") == record.get("control_type") and similarity(str(hint.get("name", "")), str(record.get("name", ""))) >= 0.42:
                        score += 0.18
                if score > best_score:
                    best_score, best = score, record
            return best if best is not None and best_score >= threshold else None

        def click_record(record, label, phase, button="left"):
            command = ActionCommand(
                CLICK,
                {"x": float(record.get("x_norm", 0.5)), "y": float(record.get("y_norm", 0.5)), "button": button, "target": control_locator(record)},
                label, [float(record.get("x_norm", 0.5)), float(record.get("y_norm", 0.5)), 1.0 if button == "right" else 0.0], 0b111,
            )
            if record.get("control_type") == "Hyperlink":
                command.declare(["cross_program"], "激活目标相关链接；若打开新程序，纳入本次会话权限域")
            return emit(command, phase)

        focused = next((record for record in observation.accessibility.records if record.get("focused") and record.get("enabled") and not record.get("offscreen") and not record.get("password")), None)
        focused_type = str((focused or {}).get("control_type", ""))
        focused_value = " ".join((str((focused or {}).get("value", "")), str((focused or {}).get("name", "")))).lower()
        editable = focused is not None and focused_type in SafetyPolicy.SAFE_TEXT_TYPES
        payload_present = bool(value and value.lower() in focused_value)
        phase = str(getattr(goal, "compiled_phase", "precondition"))
        semantic = observation.semantic_text.lower()
        title = str(observation.accessibility.window_title or "").lower()
        process_name = str(getattr(observation, "process_name", "") or "").lower()
        if phase == "recovery" and int(getattr(goal, "compiled_attempts", 0)) >= 1:
            learned = self.memory.best_strategy(operation, process_name or "unknown")
            if learned and learned.get("confidence", 0.0) >= 0.38:
                for payload_item in learned.get("recovery", [])[:4]:
                    try:
                        learned_command = ActionCommand.from_payload(payload_item)
                    except Exception:
                        continue
                    if learned_command.kind in allowed and learned_command.kind in (CLICK, KEY):
                        learned_command.label = "学习到的恢复策略：" + (learned_command.label or ACTION_NAMES[learned_command.kind])
                        return emit(learned_command, "recovery")

        def application_matches(name):
            name = str(name or "").strip().lower()
            if not name:
                return False
            joined = " ".join((title, semantic, process_name))
            if name in joined:
                return True
            if any(token in name for token in ("浏览器", "browser")):
                return self._browser_context(observation)
            if any(token in name for token in ("excel", "电子表格")):
                return "excel" in joined or "xlmain" in str(observation.accessibility.window_class or "").lower()
            if any(token in name for token in ("记事本", "notepad")):
                return "notepad" in joined or "记事本" in joined
            return False

        # --- 未知目标的通用“观察 -> 候选子目标 -> 尝试 -> 验证 -> 编译”路径 ---
        if step.get("generic"):
            frame = dict(step.get("frame") or {})
            frame_parameters = dict(frame.get("parameters") or {})
            query = " ".join(value for value in (str(frame.get("action", "")), str(frame.get("object", "")), target) if value)
            candidate = matching_control(INTERACTIVE_CONTROL_TYPES, query=query, threshold=0.04)
            if operation == "observe_context" and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.08, "force_deep_observation": True}, "通用目标：先观察 UI 和前置条件", [0.2], 0b1), "verify")
            if operation == "locate_target":
                if candidate is not None and WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "通用目标：已提出候选控件 {}".format(str(candidate.get("name") or candidate.get("control_type"))[:80]), [0.2], 0b1), "verify")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": True}, "通用目标：扩大 UIA 后重新提出候选", [0.35], 0b1), "recovery")
            if operation == "candidate_subgoal":
                typed_values = list(frame_parameters.get("addresses") or []) + list(frame_parameters.get("quoted_values") or [])
                if frame_parameters.get("value"):
                    typed_values.append(str(frame_parameters["value"]))
                if editable and typed_values and TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": str(typed_values[0])}, "通用候选：填入已解析参数", [0.0], 0b1), "action")
                if candidate is not None and CLICK in allowed:
                    return click_record(candidate, "通用候选：尝试最相关的低风险控件", "action")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x09, "modifiers": []}, "通用候选：用 Tab 探索下一个可验证焦点", [0.0], 0b1), "action")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.12}, "通用候选：等待可观察变化", [0.3], 0b1), "action")
            if operation == "commit_candidate":
                category = str(frame.get("category", "achieve"))
                commit_terms = {
                    "external_send": "send submit 发送 发出",
                    "filesystem_write": "save rename apply 保存 重命名 应用",
                    "software_install": "install continue 安装 继续",
                    "financial_commit": "pay buy checkout confirm 支付 购买 下单 确认",
                    "document_write": "apply save done 应用 保存 完成",
                    "aggregate": "sum total calculate 求和 合计 计算",
                }.get(category, query)
                commit_control = matching_control({"Button", "MenuItem", "Hyperlink", "ListItem"}, query=commit_terms, threshold=0.08)
                if commit_control is not None and CLICK in allowed:
                    return click_record(commit_control, "通用目标：提交已验证候选", "submit")
                if category in ("aggregate", "document_write") and KEY in allowed and editable:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "通用目标：提交当前编辑", [0.0], 0b1), "submit")
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.12, "force_deep_observation": True}, "通用目标：未找到可安全提交控件，保持观察", [0.3], 0b1), "recovery")
            if operation in ("verify_result", "compile_success") and WAIT in allowed:
                label = "验证通用目标结果" if operation == "verify_result" else "稳定结果并把成功轨迹编译成新程序"
                return emit(ActionCommand(WAIT, {"duration": 0.14, "force_deep_observation": operation == "verify_result"}, label, [0.35], 0b1), "verify")
            return None

        # --- 结构化子目标：文件/对象重命名 ---
        if operation == "locate_object":
            record = matching_control({"ListItem", "TreeItem", "DataItem", "Text", "Button"}, query=target, threshold=0.18)
            if record is not None and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.08}, "子目标：已定位 {}".format(str(record.get("name") or target)[:80]), [0.2], 0b1), "verify")
            # “桌面上的文件”是一个结构前置条件，不靠随机点击寻找。
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x44, "modifiers": [0x5B]}, "恢复：显示桌面后重新扫描目标", [0.0], 0b1), "recovery")
            return ActionCommand(WAIT, {"duration": 0.18}, "等待 UIA 提供目标对象", [0.4], 0b1) if WAIT in allowed else None

        if operation == "select_object":
            record = matching_control({"ListItem", "TreeItem", "DataItem", "Text", "Button"}, query=target, threshold=0.18)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：选中 {}".format(str(record.get("name") or target)[:80]), "action")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.14}, "恢复：目标暂不可见，重新感知", [0.3], 0b1), "recovery")

        if operation == "request_rename":
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "子目标：F2 请求重命名", [0.0], 0b1), "action")

        if operation == "acquire_editor":
            if editable and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.06}, "子目标：已获得重命名编辑框", [0.2], 0b1), "verify")
            edit = matching_control(SafetyPolicy.SAFE_TEXT_TYPES, query="rename name filename 名称 重命名", threshold=0.05)
            if edit is not None and CLICK in allowed:
                return click_record(edit, "恢复：聚焦重命名编辑框", "recovery")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "恢复：再次请求重命名编辑框", [0.0], 0b1), "recovery")

        # replace_text 同时服务普通输入、重命名、公式。先 Ctrl+A，再 TYPE，避免“追加文本”。
        if operation == "replace_text" and value:
            if editable:
                if payload_present and WAIT in allowed:
                    # 目标文本已被 UIA 观察到，直接进入验证；避免异步 ValuePattern 导致重复追加输入。
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "验证：指定文本已存在于编辑控件", [0.2], 0b1), "verify")
                if phase not in ("select_existing_text", "enter_payload") and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中编辑框现有内容", [0.0], 0b1), "select_existing_text")
                if TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": value}, "子目标：输入 {}".format(value[:96]), [0.0], 0b1), "enter_payload")
            # Excel/Explorer 的编辑器可能在 F2 后才进入 UIA Control View。
            if KEY in allowed and ("excel" in process_name or operation == "replace_text") and phase == "recovery":
                return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "恢复：请求当前对象进入编辑模式", [0.0], 0b1), "recovery")
            record = matching_control(SafetyPolicy.SAFE_TEXT_TYPES, query=target or "edit input 编辑", threshold=0.05)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：聚焦可编辑控件", "focus_target")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.12}, "等待可编辑控件", [0.3], 0b1), "recovery")

        if operation in ("commit_edit", "commit_formula"):
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：Enter 提交编辑", [0.0], 0b1), "submit")

        if operation == "verify_object":
            record = matching_control(None, query=target, threshold=0.18)
            if record is not None and WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.10}, "验证：{} 已出现".format(target[:96]), [0.25], 0b1), "verify")
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.18}, "验证未通过：重新扫描 {}".format(target[:96]), [0.45], 0b1), "recovery")

        # --- 当前窗口关闭：只产生关闭请求；是否允许由结构化 SafetyPolicy 决定。 ---
        if operation == "close_window":
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x73, "modifiers": [0x12]}, "子目标：关闭当前窗口", [0.0], 0b1), "action")

        # --- Excel 公式程序 ---
        if operation == "formula_mode":
            if application_matches("Excel"):
                if editable and WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.06}, "子目标：Excel 单元格已进入公式编辑模式", [0.2], 0b1), "verify")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x71, "modifiers": []}, "子目标：F2 进入 Excel 单元格编辑模式", [0.0], 0b1), "action")
            # 前置应用丢失时回到确定性的应用恢复，不随机点击。
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "恢复：重新定位 Excel", [0.0], 0b1), "recovery")

        if operation == "verify_formula_result":
            if WAIT in allowed:
                return emit(ActionCommand(WAIT, {"duration": 0.14}, "验证：公式提交后的结构化状态", [0.35], 0b1), "verify")

        # --- URL / 应用前置条件 ---
        if operation in ("ensure_url",) or (operation in ("search", "ensure_application") and value and re.match(r"https?://", value, re.IGNORECASE)):
            url = value
            if not self._browser_context(observation):
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "前置条件：打开 Windows 搜索以启动浏览器", [0.0], 0b1), "ensure_browser")
                return None
            address = matching_control({"Edit", "ComboBox"}, query="address search 地址 搜索栏 omnibox", threshold=0.05)
            if editable and TYPE in allowed and url.lower() not in focused_value:
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中地址栏内容", [0.0], 0b1), "select_existing_text")
                return emit(ActionCommand(TYPE, {"text": url}, "子目标：输入 URL", [0.0], 0b1), "enter_payload")
            if editable and url.lower() in focused_value and KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：提交 URL", [0.0], 0b1), "submit")
            if address is not None and CLICK in allowed:
                return click_record(address, "子目标：聚焦浏览器地址栏", "focus_target")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x4C, "modifiers": [0x11]}, "恢复：浏览器中 Ctrl+L 聚焦地址栏", [0.0], 0b1), "recovery")

        if operation == "ensure_application" and payload:
            if application_matches(payload):
                if WAIT in allowed:
                    return emit(ActionCommand(WAIT, {"duration": 0.10}, "验证：目标应用已在前台", [0.25], 0b1), "verify")
            # Windows Search 是可验证的应用启动路径。
            if self._start_search_context(observation) and editable:
                launch_text = "Microsoft Edge" if any(x in payload.lower() for x in ("浏览器", "browser")) else payload
                if launch_text.lower() not in focused_value and TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": launch_text}, "子目标：在 Windows 搜索输入应用名", [0.0], 0b1), "enter_payload")
                if KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：启动应用并重新验证", [0.0], 0b1), "submit")
            record = matching_control(INTERACTIVE_CONTROL_TYPES, query=payload, threshold=0.58)
            if record is not None and CLICK in allowed:
                return click_record(record, "子目标：打开 {}".format(str(record.get("name") or payload)[:80]), "action")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x5B]}, "前置条件：打开 Windows 搜索", [0.0], 0b1), "precondition")

        if operation in ("activate_control",) or action == "click":
            if CLICK in allowed and payload:
                record = matching_control(INTERACTIVE_CONTROL_TYPES, query=payload, threshold=0.26)
                if record is not None:
                    return click_record(record, "子目标：定位并点击 {}".format(str(record.get("name") or payload)[:80]), "action")

        if operation == "search" and payload:
            search_control = matching_control({"Edit", "ComboBox", "Document"}, query="search 搜索 find 查找", threshold=0.05)
            if editable:
                if payload.lower() in focused_value and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x0D, "modifiers": []}, "子目标：提交搜索", [0.0], 0b1), "submit")
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中搜索框内容", [0.0], 0b1), "select_existing_text")
                if TYPE in allowed:
                    return emit(ActionCommand(TYPE, {"text": payload}, "子目标：输入搜索词", [0.0], 0b1), "enter_payload")
            if search_control is not None and CLICK in allowed:
                return click_record(search_control, "子目标：聚焦搜索框", "focus_target")
            if self._browser_context(observation) and KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x4C, "modifiers": [0x11]}, "恢复：浏览器中聚焦地址/搜索栏", [0.0], 0b1), "recovery")

        if operation == "find" and payload:
            if editable and TYPE in allowed:
                if phase != "select_existing_text" and KEY in allowed:
                    return emit(ActionCommand(KEY, {"vk": 0x41, "modifiers": [0x11]}, "子目标：选中查找框内容", [0.0], 0b1), "select_existing_text")
                return emit(ActionCommand(TYPE, {"text": payload}, "子目标：输入查找词", [0.0], 0b1), "enter_payload")
            if KEY in allowed:
                return emit(ActionCommand(KEY, {"vk": 0x46, "modifiers": [0x11]}, "子目标：打开查找框", [0.0], 0b1), "focus_target")

        if operation == "save" and KEY in allowed and not safe_mode:
            return emit(ActionCommand(KEY, {"vk": 0x53, "modifiers": [0x11]}, "子目标：保存", [0.0], 0b1), "submit")
        return None

    def compiled_command(self, goal, observation, allowed, settings=None):
        """兼容入口：只调用通用 Operator A*，不再分派 Excel/F2/浏览器等任务分支。"""
        plans = self.operator_planner.candidate_plans(goal, observation, allowed, visual_elements=getattr(observation, "visual_elements", []))
        if not plans:
            return None
        plan = min(plans, key=lambda item: item.cost + item.risk * 0.55)
        command = plan.commands[0] if plan.commands else None
        if command is not None:
            command.parameters["symbolic_plan_cost"] = round(float(plan.cost), 6)
            command.parameters["symbolic_plan_risk"] = round(float(plan.risk), 6)
            command.parameters["symbolic_plan_operators"] = list(plan.operators)
        return command

    def _beam_search_plans(self, model, state, state_key, allowed, commands, biases, state_signature=""):
        """在可执行首动作上做有限视野 beam rollout；只执行首步，下一轮重新感知并重规划。"""
        commands = [command for command in commands if isinstance(command, ActionCommand) and command.kind in allowed]
        if not commands:
            return []
        depth_limit = max(2, min(5, int(math.log2(1.0 + max(1, self.breadth)) / 1.7)))
        beam_width = max(3, min(12, int(math.sqrt(max(1, self.breadth)))))
        _, root_q, _ = model.forward(state)
        beam = []
        for command in commands:
            prediction = self.world_model.predict(state, command.kind, state_key)
            uncertainty = clamp(safe_float(prediction.get("uncertainty", 1.0), 1.0), 0.0, 1.0)
            support = max(0, int(prediction.get("support", 0)))
            failure = clamp(self.memory.failure_score(str(state_signature), command), 0.0, 1.0)
            plan_risk = clamp(safe_float(command.parameters.get("symbolic_plan_risk", 0.0)), 0.0, 1.0)
            predicted_safety = clamp(safe_float(prediction.get("safety", 0.0)), 0.0, 1.0)
            branch_risk = clamp(plan_risk + predicted_safety * 0.70 + failure * 0.45, 0.0, 1.5)
            unknown = bool(support == 0 or uncertainty >= 0.86)
            # 高风险/明显不可达分支直接剪枝；未知分支保留但显著降权，让“我不知道”可见。
            if branch_risk >= 0.92:
                continue
            reward = safe_float(prediction.get("reward", 0.0))
            success = clamp((reward + 1.0) * 0.27 + (1.0 - uncertainty) * 0.43 + min(0.30, math.log1p(support) * 0.10), 0.0, 1.0)
            prerequisite_confidence = clamp(
                (1.0 - uncertainty) * 0.62 + min(0.30, math.log1p(support) * 0.10)
                + (0.08 if command.parameters.get("symbolic_plan_operators") else 0.0),
                0.0, 1.0,
            )
            score = DeliberationScorer.score(
                q_value=root_q[command.kind], bias=float(biases.get(command.kind, 0.0)),
                predicted_reward=reward, plan_cost=safe_float(command.parameters.get("symbolic_plan_cost", 0.5), 0.5),
                plan_risk=plan_risk, predicted_safety=predicted_safety, uncertainty=uncertainty,
                failure_score=failure, support=support,
            ) + success * 0.34 + prerequisite_confidence * 0.12 - (0.20 if unknown else 0.0)
            beam.append({
                "score": score, "command": command, "actions": [command.kind],
                "state": prediction.get("predicted_state", state),
                "state_key": str(prediction.get("next_state_key", "")),
                "mask": int(prediction.get("next_mask", 0)) or mask_actions(allowed),
                "risk": branch_risk, "uncertainty": uncertainty, "success": success,
                "cost": safe_float(command.parameters.get("symbolic_plan_cost", 0.5), 0.5),
                "unknown": unknown, "prerequisite_confidence": prerequisite_confidence,
                "predicted_effect": str(prediction.get("next_signature", "")),
            })
        beam.sort(key=lambda node: node["score"], reverse=True)
        beam = beam[:beam_width]
        for depth_index in range(1, depth_limit):
            expanded = []
            for node in beam:
                candidate_actions = actions_from_mask(node["mask"]) or list(allowed)
                _, q_values, _ = model.forward(normalize_state(node["state"], model.input_count))
                candidate_actions = sorted(
                    candidate_actions,
                    key=lambda kind: q_values[kind] + float(biases.get(kind, 0.0)),
                    reverse=True,
                )[:beam_width]
                for kind in candidate_actions:
                    prediction = self.world_model.predict(node["state"], kind, node["state_key"])
                    uncertainty = clamp(safe_float(prediction.get("uncertainty", 1.0), 1.0), 0.0, 1.0)
                    support = max(0, int(prediction.get("support", 0)))
                    predicted_safety = clamp(safe_float(prediction.get("safety", 0.0)), 0.0, 1.0)
                    interactive_unknown = kind in (CLICK, KEY, TYPE, SKILL) and support == 0 and uncertainty >= 0.94
                    cumulative_risk = node["risk"] + predicted_safety * (0.72 ** depth_index)
                    if cumulative_risk >= 1.05 or interactive_unknown:
                        continue
                    reward = safe_float(prediction.get("reward", 0.0))
                    step_success = clamp((reward + 1.0) * 0.30 + (1.0 - uncertainty) * 0.46 + min(0.24, math.log1p(support) * 0.09), 0.0, 1.0)
                    discount = 0.90 ** depth_index
                    expanded.append({
                        "score": node["score"] + discount * (reward * 0.62 + q_values[kind] * 0.28 + step_success * 0.30 - uncertainty * 0.24 - predicted_safety * 0.58),
                        "command": node["command"], "actions": node["actions"] + [kind],
                        "state": prediction.get("predicted_state", node["state"]),
                        "state_key": str(prediction.get("next_state_key", "")),
                        "mask": int(prediction.get("next_mask", 0)) or node["mask"],
                        "risk": cumulative_risk,
                        "uncertainty": (node["uncertainty"] * depth_index + uncertainty) / (depth_index + 1),
                        "success": node["success"] * 0.58 + step_success * 0.42,
                        "cost": node["cost"] + 1.0,
                        "unknown": bool(node["unknown"] or support == 0 or uncertainty >= 0.86),
                        "prerequisite_confidence": node["prerequisite_confidence"],
                        "predicted_effect": str(prediction.get("next_signature", "")) or node["predicted_effect"],
                    })
            if not expanded:
                break
            expanded.sort(key=lambda node: node["score"] + node["success"] * 0.20 - node["risk"] * 0.30, reverse=True)
            beam = expanded[:beam_width]
        beam.sort(key=lambda node: node["score"] + node["success"] * 0.24 - node["risk"] * 0.34, reverse=True)
        return beam

    def plan_with_lookahead(self, model, state, allowed, observation, goal, text_candidates, eligible_skills, exploration=False, settings=None, symbolic_candidates=None):
        cache = {}
        _, q_values, parameter_map = model.forward(state)
        state_key = str(getattr(observation, "fuzzy_key", ""))
        cache[("forward", str(observation.signature), state_key, int(mask_actions(allowed)))] = q_values
        biases = self.action_biases(observation.signature, eligible_skills)
        for kind, bonus in goal.compiler_action_biases().items():
            biases[kind] = biases.get(kind, 0.0) + bonus

        # ReasoningBackend/Operator A* 先产生合法候选；Double-Q 只做经验排序，不生成子目标。
        local_plans = self.operator_planner.candidate_plans(goal, observation, allowed, visual_elements=getattr(observation, "visual_elements", []))
        plan_commands = []
        for plan in local_plans:
            for command in plan.commands[:1]:
                command.parameters["symbolic_plan_cost"] = round(float(plan.cost), 6)
                command.parameters["symbolic_plan_risk"] = round(float(plan.risk), 6)
                command.parameters["symbolic_plan_operators"] = list(plan.operators)
                plan_commands.append(command)
        plan_commands.extend(command for command in (symbolic_candidates or []) if isinstance(command, ActionCommand))
        unique_symbolic = {}
        for command in plan_commands:
            if command.kind in allowed:
                unique_symbolic.setdefault(command.fingerprint(), command)
        if unique_symbolic:
            # 多候选 deliberation：Operator A* 只负责生成合法候选；每个候选都通过 WorldModel rollout、风险、
            # 不确定性、失败记忆与计划成本统一排序，而不是看到第一个符号候选就提前返回。
            beam_plans = self._beam_search_plans(model, state, state_key, allowed, list(unique_symbolic.values()), biases, observation.signature)
            if beam_plans:
                best_plan = beam_plans[0]
                command = best_plan["command"]
                command.parameters["beam_plan_actions"] = list(best_plan["actions"])
                command.parameters["beam_success_probability"] = round(float(best_plan["success"]), 6)
                command.parameters["beam_prerequisite_confidence"] = round(float(best_plan["prerequisite_confidence"]), 6)
                command.parameters["beam_remaining_cost"] = round(max(0.0, float(best_plan["cost"]) - 1.0), 6)
                command.parameters["beam_predicted_effect"] = str(best_plan["predicted_effect"])
                command.parameters["beam_unknown"] = bool(best_plan["unknown"])
                command.parameters["beam_alternative_plans"] = [list(plan["actions"]) for plan in beam_plans[1:4]]
                command.parameters["deliberation_score"] = round(float(best_plan["score"]), 6)
                command.parameters["deliberation_uncertainty"] = round(float(best_plan["uncertainty"]), 6)
                command.label = "滚动 Beam/WorldModel 计划（执行首步后重感知）：" + command.label
                return command
            ranked = []
            rollout_depth = max(1, min(4, int(math.log2(1.0 + max(1, self.breadth)) / 2.0)))
            for command in unique_symbolic.values():
                cost = safe_float(command.parameters.get("symbolic_plan_cost", 0.5), 0.5)
                risk = safe_float(command.parameters.get("symbolic_plan_risk", 0.0), 0.0)
                failure = self.memory.failure_score(observation.signature, command)
                prediction = self.world_model.predict(state, command.kind, state_key)
                uncertainty = safe_float(prediction.get("uncertainty", 1.0), 1.0)
                future = 0.0
                if prediction.get("support", 0) and uncertainty <= 0.84:
                    next_mask = int(prediction.get("next_mask", 0)) or mask_actions(allowed)
                    future = self._lookahead_value(
                        model, prediction.get("predicted_state", state), prediction.get("next_signature", ""),
                        next_mask, rollout_depth - 1, cache, prediction.get("next_state_key", ""),
                    )
                score = DeliberationScorer.score(
                    q_value=q_values[command.kind], bias=float(biases.get(command.kind, 0.0)),
                    predicted_reward=prediction.get("reward", 0.0), future_value=future,
                    plan_cost=cost, plan_risk=risk, predicted_safety=prediction.get("safety", 0.0),
                    uncertainty=uncertainty, failure_score=failure,
                    time_cost=safe_float(command.parameters.get("estimated_seconds", 0.0), 0.0),
                    support=prediction.get("support", 0),
                )
                ranked.append((score, uncertainty, risk, command))
            ranked.sort(key=lambda item: (item[0], -item[1], -item[2]), reverse=True)
            command = ranked[0][3]
            command.parameters["deliberation_score"] = round(float(ranked[0][0]), 6)
            command.parameters["deliberation_uncertainty"] = round(float(ranked[0][1]), 6)
            command.label = "多候选 WorldModel deliberation：" + command.label
            return command

        uncertainty_by_action = {kind: self.world_model.predict(state, kind, state_key).get("uncertainty", 1.0) for kind in allowed}
        actionable_uncertainty = [float(value) for kind, value in uncertainty_by_action.items() if kind not in (WAIT, SLEEP)]
        global_uncertainty = min(actionable_uncertainty) if actionable_uncertainty else 0.0
        # “看不清就不动作”：高不确定时优先观察/等待，不用随机点击填补知识空白。
        if global_uncertainty >= 0.82 and WAIT in allowed and (getattr(observation, "perception_limited", False) or exploration):
            return ActionCommand(WAIT, {"duration": 0.18}, "世界模型不确定：等待并重新获取 UIA/视觉", [0.45], 0b1)
        for kind, uncertainty in uncertainty_by_action.items():
            if kind in (CLICK, KEY, TYPE, SKILL):
                biases[kind] = biases.get(kind, 0.0) - float(uncertainty) * 0.22
            elif kind == WAIT:
                biases[kind] = biases.get(kind, 0.0) + global_uncertainty * 0.10

        branch = min(len(allowed), max(3, int(math.sqrt(max(1, self.breadth)))))
        # 规则/GoalCompiler/UIA/技能先产生合法候选命令；Q 网络只对候选排序。
        legal_commands = []
        for action in allowed:
            raw = list(parameter_map.get(action, []))
            legal_commands.append(self.plan(action, raw, observation, goal, text_candidates, eligible_skills, exploration=False))
            if exploration and global_uncertainty < 0.50 and action not in (SLEEP, SKILL):
                legal_commands.append(self.plan(action, raw, observation, goal, text_candidates, eligible_skills, exploration=True))
        unique_commands = {}
        for command in legal_commands:
            unique_commands.setdefault(command.fingerprint(), command)
        legal_commands = list(unique_commands.values())
        legal_commands.sort(key=lambda command: q_values[command.kind] + float(biases.get(command.kind, 0.0)) - self.memory.failure_score(observation.signature, command) * 0.55, reverse=True)
        ranked_commands = legal_commands[:max(branch, min(len(legal_commands), branch * 2))]
        depth = max(2, int(math.log2(1.0 + max(1, self.breadth)) / 2.0))
        best = None
        for command in ranked_commands:
            action = command.kind
            immediate = q_values[action] + float(biases.get(action, 0.0)) - self.memory.failure_score(observation.signature, command) * 0.55
            prediction = self.world_model.predict(state, action, state_key)
            if prediction.get("support", 0) and float(prediction.get("uncertainty", 1.0)) <= 0.78:
                future = self._lookahead_value(
                    model, prediction["predicted_state"], prediction.get("next_signature", ""),
                    int(prediction.get("next_mask", 0)) or mask_actions(allowed), depth - 2, cache, prediction.get("next_state_key", ""),
                )
                immediate += (float(prediction.get("reward", 0.0)) + 0.94 * future - float(prediction.get("safety", 0.0)) * 0.50) * 0.70
                immediate -= float(prediction.get("uncertainty", 1.0)) * (0.20 if action in (CLICK, KEY, TYPE, SKILL) else 0.05)
            else:
                transitions = self.memory.predict_transitions(observation.signature, action, max(2, int(math.sqrt(max(1, self.breadth)))), state_key=state_key)
                if transitions:
                    future_values = []
                    for item in transitions:
                        future = self._lookahead_value(model, item["next_state"], item.get("next_signature", ""), item.get("next_mask", 0), depth - 2, cache, item.get("next_state_key", ""))
                        future_values.append(float(item.get("reward", 0.0)) + 0.94 * future - float(item.get("safety_penalty", 0.0)) * 0.50)
                    immediate += sum(future_values) / len(future_values) * 0.55
            if best is None or immediate > best[0]:
                best = (immediate, command)
        if best is None:
            return self.plan(WAIT, [0.5], observation, goal, text_candidates, eligible_skills, exploration=False)
        command = best[1]
        command.label = "{}步世界模型规划：{}".format(depth, command.label)
        return command

    def plan(self, kind, raw_parameters, observation, goal, text_candidates, eligible_skills, exploration=False):
        count = PARAM_HEAD_SIZES[int(kind)]
        values = self._perturb(raw_parameters, exploration, count)
        mask = (1 << count) - 1 if count else 0
        if kind == WAIT:
            duration = 0.10 + values[0] * 0.35
            return ActionCommand(WAIT, {"duration": duration}, "等待 {:.2f}s".format(duration), values, mask)
        if kind == SLEEP:
            return ActionCommand(SLEEP, {}, "进入睡眠", values, 0)
        if kind in (MOVE, CLICK):
            x, y, target_name, target_locator = self._choose_point(values, observation, goal, exploration, for_click=(kind == CLICK))
            values[0], values[1] = x, y
            if kind == MOVE:
                return ActionCommand(MOVE, {"x": x, "y": y}, "移动到 " + str(target_name)[:60], values, mask)
            explicit_visual_target = bool(target_name == "明确目标" and goal.target_point)
            if not target_locator and not explicit_visual_target:
                return ActionCommand(WAIT, {"duration": 0.16, "force_deep_observation": True}, "没有可交互控件证据：取消 CLICK 并扩大感知", [0.4], 0b1)
            button = "right" if values[2] > 0.93 else "left"
            values[2] = 1.0 if button == "right" else 0.0
            click_parameters = {"x": x, "y": y, "button": button}
            if target_locator:
                click_parameters["target"] = target_locator
            if explicit_visual_target:
                click_parameters["explicit_visual_target"] = True
            command = ActionCommand(CLICK, click_parameters, "{}键点击 {}".format("右" if button == "right" else "左", str(target_name)[:60]), values, mask)
            if self.memory.failure_score(observation.signature, command) > 0.62 and not exploration:
                # 失败记忆不再通过随机抖动坐标“绕开”；先重新感知，避免把未知 UI 写成错误经验。
                return ActionCommand(WAIT, {"duration": 0.18, "force_deep_observation": True}, "点击候选命中失败记忆：取消并重新感知", [0.45], 0b1)
            return command
        if kind == SCROLL:
            steps = int(round((values[0] * 2.0 - 1.0) * 8.0))
            if steps == 0:
                steps = 1 if values[0] >= 0.5 else -1
            amount = int(clamp(steps * 120, -960, 960))
            values[0] = amount / 1920.0 + 0.5
            return ActionCommand(SCROLL, {"amount": amount}, "滚动 {}".format(amount), values, mask)
        if kind == KEY:
            candidates = self.key_candidates(observation)
            index = min(len(candidates) - 1, int(values[0] * len(candidates)))
            virtual_key, modifiers, name = candidates[index]
            values[0] = index / max(1, len(candidates) - 1)
            return ActionCommand(KEY, {"vk": virtual_key, "modifiers": list(modifiers)}, "按键 " + name, values, mask)
        if kind == TYPE:
            text = goal.deterministic_text(observation)
            if text:
                return ActionCommand(TYPE, {"text": text}, "目标编译器确定性输入（{} 字符）".format(len(text)), values, mask)
            text = self.text_generator.generate(goal, observation, values[0], text_candidates)
            return ActionCommand(TYPE, {"text": text}, "本地模板/记忆兜底输入（{} 字符）".format(len(text)), values, mask)
        if kind == SKILL:
            index = min(len(eligible_skills) - 1, int(values[0] * len(eligible_skills)))
            skill = eligible_skills[index]
            values[0] = index / max(1, len(eligible_skills) - 1)
            args = {}
            specs = dict(skill.get("parameters") or {})
            deterministic = goal.deterministic_text(observation)
            for name, spec in specs.items():
                default = spec.get("default", "") if isinstance(spec, dict) else spec
                if name == "text" and deterministic:
                    args[name] = deterministic
                else:
                    args[name] = default
            return ActionCommand(SKILL, {"skill_id": skill["id"], "args": args}, "{}：{}".format(skill.get("abstraction_kind", "Skill"), skill["name"][:80]), values, mask)
        return ActionCommand(WAIT, {"duration": 0.2}, "等待", [0.5], 1)


class SkillManager:

    def __init__(self, memory, attention_limit=128):
        self.memory = memory
        self.attention_limit = max(32, int(attention_limit))
        self.pending = []
        self.episode_trace = []
        self.start_context = {}
        self.goal_label = ""
        self.queued_current = False

    def set_attention_limit(self, attention_limit):
        self.attention_limit = max(self.attention_limit, int(attention_limit))

    def context(self, observation):
        context_limit = max(24, min(self.attention_limit, len(observation.accessibility.records)))
        controls = [record.get("control_type", "") + " " + record.get("name", "") for record in observation.accessibility.records[:context_limit]]
        semantic_limit = max(8, int(math.sqrt(max(1, self.attention_limit)) * 8.0))
        return {
            "window_title": observation.accessibility.window_title,
            "window_class": observation.accessibility.window_class,
            "semantic_terms": semantic_units(" ".join(controls))[:semantic_limit],
            "semantic_signature": observation.semantic_signature,
        }

    def begin_goal(self, observation, goal_label):
        self.episode_trace = []
        self.start_context = self.context(observation)
        self.goal_label = str(goal_label)
        self.queued_current = False

    @staticmethod
    def _semantic_skill_command(command):
        payload = command.payload()
        if command.kind == CLICK:
            parameters = dict(payload.get("parameters", {}))
            locator = dict(parameters.get("target") or {})
            if locator:
                # 技能以语义定位为主；归一化坐标仅作为低优先级兜底元数据，不作为首选执行目标。
                fallback = [safe_float(parameters.get("x", 0.5), 0.5), safe_float(parameters.get("y", 0.5), 0.5)]
                payload["parameters"] = {"button": parameters.get("button", "left"), "target": locator, "fallback_point": fallback}
        return payload

    def observe(self, command, outcome, components, current, duration):
        if not outcome.get("executed") or command.kind in (WAIT, SLEEP):
            return
        if command.kind == SKILL:
            step = {"type": "skill", "skill_id": int(command.parameters.get("skill_id", 0)), "condition": self.start_context}
        else:
            step = {"type": "action", "command": self._semantic_skill_command(command)}
        self.episode_trace.append(step)
        if components.get("goal_completed") and not self.queued_current:
            self.queue_candidate(current, float(components.get("goal_reward", 0.0)))

    def queue_candidate(self, observation, score):
        if self.queued_current or len(self.episode_trace) < 2:
            return
        expected = self.context(observation)
        self.pending.append({
            "name": self.goal_label or "可复用界面技能", "steps": list(self.episode_trace),
            "precondition": dict(self.start_context), "expected": expected, "score": max(0.05, float(score)),
        })
        self.queued_current = True

    @staticmethod
    def precondition_matches(skill, observation):
        condition = skill.get("precondition", {})
        current_class = observation.accessibility.window_class
        expected_class = condition.get("window_class", "")
        if expected_class and current_class and expected_class != current_class:
            return False
        expected_title = condition.get("window_title", "")
        if expected_title and observation.accessibility.window_title and similarity(expected_title, observation.accessibility.window_title) < 0.08:
            return False
        return True

    @staticmethod
    def expected_matches(skill, observation):
        expected = skill.get("expected", {})
        if expected.get("semantic_signature") and expected["semantic_signature"] == observation.semantic_signature:
            return True
        if expected.get("window_title") and similarity(expected["window_title"], observation.accessibility.window_title) >= 0.45:
            return True
        terms = set(expected.get("semantic_terms", []))
        current = set(semantic_units(observation.semantic_text))
        return bool(terms) and len(terms & current) / len(terms) >= 0.62

    @staticmethod
    def _resolve_program_value(value, variables):
        if isinstance(value, dict) and set(value.keys()) == {"$var"}:
            return variables.get(str(value.get("$var")), "")
        if isinstance(value, dict):
            return {key: SkillManager._resolve_program_value(item, variables) for key, item in value.items()}
        if isinstance(value, list):
            return [SkillManager._resolve_program_value(item, variables) for item in value]
        return value

    @staticmethod
    def _programize(steps):
        """把动作轨迹升级为参数化程序；程序解释器还支持 if/retry/loop/skill/observe。"""
        result = []
        parameters = {}
        text_index = 0
        for original in steps:
            step = json.loads(compact_json(original))
            if step.get("type") == "action":
                command = step.get("command", {})
                if int(command.get("kind", WAIT)) == TYPE:
                    params = command.setdefault("parameters", {})
                    literal = str(params.get("text", ""))
                    text_index += 1
                    name = "text" if text_index == 1 else "text{}".format(text_index)
                    parameters[name] = {"type": "text", "default": literal, "required": True}
                    params["text"] = {"$var": name}
            result.append(step)
        return result, parameters

    @staticmethod
    def _program_steps(step):
        if not isinstance(step, dict):
            return []
        found = [step]
        for key in ("steps", "then", "else", "recovery"):
            value = step.get(key, [])
            if isinstance(value, dict):
                value = [value]
            for child in value if isinstance(value, list) else []:
                found.extend(SkillManager._program_steps(child))
        return found

    @classmethod
    def _program_capabilities(cls, steps, memory=None):
        capabilities = set()
        for root in steps or []:
            for step in cls._program_steps(root):
                if step.get("type") == "action":
                    capabilities.update(str(value) for value in step.get("command", {}).get("required_capabilities", []) if value)
                elif step.get("type") == "skill" and memory is not None:
                    child = memory.get_skill(int(step.get("skill_id", 0)))
                    if child:
                        capabilities.update(str(value) for value in child.get("capabilities", []) if value)
        return sorted(capabilities)

    @staticmethod
    def success_matches(skill, observation):
        success = dict(skill.get("success") or {})
        if not success:
            return SkillManager.expected_matches(skill, observation)
        kind = str(success.get("type", "expected_context"))
        if kind == "expected_context":
            pseudo = dict(skill)
            pseudo["expected"] = dict(success.get("value") or skill.get("expected") or {})
            return SkillManager.expected_matches(pseudo, observation)
        if kind == "semantic_contains":
            return str(success.get("value", "")).lower() in observation.semantic_text.lower()
        if kind == "focused_contains":
            needle = str(success.get("value", "")).lower()
            focused = next((record for record in observation.accessibility.records if record.get("focused")), {})
            return needle in (str(focused.get("value", "")) + " " + str(focused.get("name", ""))).lower()
        if kind == "control_exists":
            query = str(success.get("value", ""))
            return any(similarity(query, str(record.get("name", ""))) >= 0.28 for record in observation.accessibility.records)
        return SkillManager.expected_matches(skill, observation)

    def capability_allowed(self, skill, settings, seen=None):
        if settings is None:
            return True
        seen = set(seen or ())
        identifier = int(skill.get("id", 0))
        if identifier in seen:
            return False
        seen.add(identifier)
        if not settings.get("observe_only") and set(skill.get("capabilities", [])) & SafetyPolicy.CAPABILITY_FORBIDDEN:
            return False
        for root in skill.get("steps", []):
            for step in self._program_steps(root):
                if step.get("type") == "skill":
                    child = self.memory.get_skill(int(step.get("skill_id", 0)))
                    if child is None or not self.capability_allowed(child, settings, seen):
                        return False
                    continue
                if step.get("type") != "action":
                    continue
                try:
                    kind = int(step.get("command", {}).get("kind", WAIT))
                except (TypeError, ValueError):
                    return False
                if kind == CLICK and not settings.get("clicks"):
                    return False
                if kind in (KEY, TYPE) and not settings.get("keyboard"):
                    return False
        return True

    def eligible(self, observation, settings=None, limit=48):
        candidates = []
        for skill in self.memory.top_skills(self.attention_limit):
            if not self.precondition_matches(skill, observation):
                continue
            if not self.capability_allowed(skill, settings):
                continue
            ratio = skill["successes"] / max(1, skill["uses"])
            context_score = similarity(skill["precondition"].get("window_title", ""), observation.accessibility.window_title)
            skill["retrieval_score"] = skill["score"] + ratio * 0.35 + context_score * 0.25
            candidates.append(skill)
        candidates.sort(key=lambda value: value["retrieval_score"], reverse=True)
        return candidates[:int(limit)]

    @staticmethod
    def _step_key(step):
        if step.get("type") == "skill":
            return "skill:" + str(step.get("skill_id", 0))
        return "action:" + compact_json(step.get("command", {}))

    def _compress_with_children(self, steps, existing):
        result = list(steps)
        children = []
        patterns = []
        for skill in existing:
            keys = [self._step_key(step) for step in skill.get("steps", [])]
            if len(keys) >= 2:
                patterns.append((len(keys), keys, skill))
        patterns.sort(reverse=True, key=lambda value: value[0])
        index = 0
        compressed = []
        while index < len(result):
            match = None
            for length, keys, skill in patterns:
                if index + length <= len(result) and [self._step_key(step) for step in result[index:index + length]] == keys:
                    if index == 0 and length == len(result):
                        continue
                    match = (length, skill)
                    break
            if match:
                length, child = match
                compressed.append({"type": "skill", "skill_id": child["id"], "condition": child.get("precondition", {})})
                children.append(child)
                index += length
            else:
                compressed.append(result[index])
                index += 1
        level = 1 + max([child.get("level", 1) for child in children] or [0])
        return compressed, level

    def consolidate(self, deadline=None):
        if not self.pending:
            return 0
        existing = self.memory.top_skills(max(self.attention_limit, 128))
        created = []
        pending = self.pending
        self.pending = []
        unprocessed = []
        for index, candidate in enumerate(pending):
            if deadline is not None and time.monotonic() >= float(deadline):
                unprocessed.extend(pending[index:])
                break
            compressed, level = self._compress_with_children(candidate["steps"], existing + created)
            steps, parameters = self._programize(compressed)
            capabilities = self._program_capabilities(steps, self.memory)
            success = {"type": "expected_context", "value": candidate["expected"]}
            recovery = [{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}, {"type": "observe"}]
            source = compact_json({"steps": steps, "precondition": candidate["precondition"], "success": success, "parameters": parameters, "capabilities": capabilities})
            fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
            identifier = self.memory.upsert_skill(
                fingerprint, candidate["name"], level, steps, candidate["precondition"], candidate["expected"], candidate["score"],
                parameters=parameters, success=success, recovery=recovery, program_version=2,
                capabilities=capabilities,
            )
            skill = self.memory.get_skill(identifier)
            if skill:
                created.append(skill)
        if unprocessed:
            self.pending = unprocessed + self.pending
        if len(created) >= 2 and (deadline is None or time.monotonic() < float(deadline)):
            steps = [{"type": "skill", "skill_id": skill["id"], "args": {}, "condition": skill["precondition"]} for skill in created]
            level = 1 + max(skill["level"] for skill in created)
            precondition = created[0]["precondition"]
            expected = created[-1]["expected"]
            success = {"type": "expected_context", "value": expected}
            capabilities = self._program_capabilities(steps, self.memory)
            source = compact_json({"steps": steps, "precondition": precondition, "success": success, "capabilities": capabilities})
            fingerprint = hashlib.blake2s(source.encode("utf-8"), digest_size=16).hexdigest()
            self.memory.upsert_skill(
                fingerprint, "长技能：" + created[-1]["name"], level, steps, precondition, expected,
                sum(skill["score"] for skill in created) / len(created), parameters={}, success=success,
                recovery=[{"type": "observe"}, {"type": "retry_last", "max_attempts": 1}], program_version=2,
                capabilities=capabilities,
            )
        self.memory.commit()
        return len(created)


class NStepAccumulator:
    def __init__(self, n_steps=N_STEP, gamma=0.94):
        self.n_steps = int(n_steps)
        self.gamma = float(gamma)
        self.items = deque()

    def _combine(self, length, terminal=False):
        selected = list(self.items)[:length]
        first = dict(selected[0])
        reward = 0.0
        goal_reward = 0.0
        curiosity_reward = 0.0
        efficiency_reward = 0.0
        safety_penalty = 0.0
        for index, item in enumerate(selected):
            discount = self.gamma ** index
            reward += discount * float(item["reward"])
            goal_reward += discount * float(item.get("goal_reward", 0.0))
            curiosity_reward += discount * float(item.get("curiosity_reward", 0.0))
            efficiency_reward += discount * float(item.get("efficiency_reward", 0.0))
            safety_penalty = max(safety_penalty, float(item.get("safety_penalty", 0.0)))
        last = selected[-1]
        first.update({
            "reward": reward, "goal_reward": goal_reward, "curiosity_reward": curiosity_reward,
            "efficiency_reward": efficiency_reward, "safety_penalty": safety_penalty,
            "next_state": last["next_state"], "next_mask": 0 if terminal else last["next_mask"],
            "next_signature": last.get("next_signature", ""), "next_state_key": last.get("next_state_key", ""), "n_steps": length,
            "priority": abs(reward) + abs(goal_reward) * 1.8 + safety_penalty * 1.5 + 0.02,
        })
        return first

    def append(self, item, terminal=False):
        self.items.append(dict(item))
        emitted = []
        if len(self.items) >= self.n_steps:
            emitted.append(self._combine(self.n_steps, terminal=terminal))
            self.items.popleft()
        if terminal:
            while self.items:
                emitted.append(self._combine(min(self.n_steps, len(self.items)), terminal=True))
                self.items.popleft()
        return emitted

    def flush(self):
        emitted = []
        while self.items:
            emitted.append(self._combine(min(self.n_steps, len(self.items)), terminal=False))
            self.items.popleft()
        return emitted


class SessionLogger:
    @staticmethod
    def _rotate(directory):
        try:
            files = sorted(directory.glob("session_*.jsonl"), key=lambda path: path.stat().st_mtime, reverse=True)
            total = sum(path.stat().st_size for path in files)
            for index, path in enumerate(files):
                if index < SESSION_LOG_KEEP and total <= SESSION_LOG_SOFT_BYTES:
                    continue
                size = path.stat().st_size
                try:
                    path.unlink()
                    total -= size
                except OSError:
                    pass
        except Exception:
            pass

    def __init__(self, data_dir):
        directory = data_dir / "logs"
        directory.mkdir(parents=True, exist_ok=True)
        self._rotate(directory)
        self.path = directory / ("session_" + time.strftime("%Y%m%d_%H%M%S") + ".jsonl")
        self.stream = open(self.path, "a", encoding="utf-8", buffering=1)
        self.lock = threading.Lock()
        self.resource_budget = ResourceBudget(data_dir)
        self._disk_checked_at = 0.0
        self._disk_writable = True

    def write(self, kind, payload):
        now = time.monotonic()
        if now - self._disk_checked_at >= 2.0:
            self.resource_budget.refresh()
            self._disk_writable = self.resource_budget.free_disk > self.resource_budget.disk_reserve_bytes + 32 * 1024 ** 2
            self._disk_checked_at = now
        if not self._disk_writable:
            return False
        record = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "kind": kind}
        record.update(payload)
        with self.lock:
            self.stream.write(compact_json(record) + "\n")

    def close(self):
        try:
            self.stream.close()
        except Exception:
            pass


class AgentRuntime:
    def __init__(self, data_dir, messages, stop_event=None, escape_event=None, input_gate_event=None, input_pause_event=None, sleep_ui_ready_event=None, wake_ui_hidden_event=None, wake_validation_request_event=None, wake_validation_ready_event=None, input_gate_lock=None, generation_value=None, expected_generation=None, session_id=None):
        self.data_dir = data_dir
        self.model_path = data_dir / MODEL_FILE_NAME
        self.checkpoint_dir = data_dir / "checkpoints"
        self.messages = messages
        self.context = multiprocessing.get_context("spawn")
        self.stop_event = stop_event if stop_event is not None else self.context.Event()
        self.escape_event = escape_event
        self.input_gate_event = input_gate_event if input_gate_event is not None else self.context.Event()
        self.input_pause_event = input_pause_event if input_pause_event is not None else self.context.Event()
        self.sleep_ui_ready_event = sleep_ui_ready_event if sleep_ui_ready_event is not None else self.context.Event()
        self.wake_ui_hidden_event = wake_ui_hidden_event if wake_ui_hidden_event is not None else self.context.Event()
        self.wake_validation_request_event = wake_validation_request_event if wake_validation_request_event is not None else self.context.Event()
        self.wake_validation_ready_event = wake_validation_ready_event if wake_validation_ready_event is not None else self.context.Event()
        self.input_gate_lock = input_gate_lock if input_gate_lock is not None else self.context.Lock()
        self.generation_value = generation_value
        self.expected_generation = None if expected_generation is None else int(expected_generation)
        self.session_id = str(session_id or uuid.uuid4().hex)
        self.state_seq = 0
        self.input_gate = SharedInputGate(self.input_gate_event, self.input_gate_lock, self.stop_event, pause_event=self.input_pause_event, generation_value=self.generation_value, expected_generation=self.expected_generation)
        self.resource_budget = ResourceBudget(data_dir)
        self.memory = LongTermMemory(data_dir / DATABASE_FILE_NAME, resource_budget=self.resource_budget)
        self.task_exit_policy = TaskExitPolicy(self.memory)
        self.external_ai_policy = ExternalAIDelegationPolicy()
        self.safety = SafetyPolicy()
        self.session_domain = None
        self.approved_risk_fingerprint = ""
        self.approved_risk_context = ""
        self.model, model_note = self._load_model()
        self.model_dirty = not self.model_path.exists()
        self.last_model_save = time.monotonic()
        self.adaptive_save_interval = clamp(
            45.0 + self.model.input_count / 512.0 + safe_float(self.resource_budget.decision_latency) * 20.0,
            30.0, 180.0,
        )
        self.world_model = WorldModel(self.memory)
        self.skills = SkillManager(self.memory, self.model.capacities.get("skill_attention", 128))
        self.planner = ActionPlanner(self.memory, self.model.capacities.get("planner_breadth", 48), world_model=self.world_model, resource_budget=self.resource_budget)
        latest_sleep_report = self.memory.latest_sleep_report()
        self.planner.set_meta_report(latest_sleep_report)
        latest_after_metrics = dict(latest_sleep_report.get("after_metrics") or {})
        MetaCognitiveSleep._ENTRY_POLICY.restore(latest_after_metrics.get("entry_policy", {}))
        MetaCognitiveSleep._WAKE_POLICY.restore(latest_after_metrics.get("wake_policy", {}))
        self.task_benchmark = StartupSelfTest(data_dir).cached_goal_compiler_regression(allow_compute=False)
        self.last_io_metrics = {"capture_seconds": 0.0, "uia_seconds": 0.0, "cache_hits": 0, "full_scans": 0, "event_cache_hits": 0, "local_action_scans": 0}
        self.last_sleep_decision = {"score": 0.0, "factors": {}}
        legacy_note = ""
        if (data_dir / "model.json.gz").exists() or (data_dir / "experience.json.gz").exists() or (data_dir / "skills.json.gz").exists():
            legacy_note = "检测到旧版 v3 数据，因感知/动作维度已重构而原样保留"
        self.startup_note = "；".join(value for value in (model_note, "SQLite 长期记忆已就绪", legacy_note) if value)
        if self.model_dirty:
            self.save_model(force=True)
        self.state_machine = SessionStateMachine(STATE_IDLE)

    def _set_state(self, target):
        target = str(target)
        if target in (STATE_FREE_WAKE_PREPARE, STATE_FREE_ACTIVE) and (
            self.stop_event.is_set() or (self.escape_event is not None and self.escape_event.is_set())
        ):
            self.input_gate.close()
            raise InterruptedError("停止已生效：禁止从睡眠路径恢复自由键鼠活动")
        source = self.state_machine.state
        state = self.state_machine.transition(target)
        self.state_seq += 1
        self._post("state", {
            "session_id": self.session_id,
            "seq": int(self.state_seq),
            "from": source,
            "to": state,
        })
        return state

    def _request_wake_validation(self, io):
        """醒前由主进程重新验证 watchdog/guardian/generation，再由 worker 验证 Default Desktop。"""
        self.wake_validation_ready_event.clear()
        self.wake_validation_request_event.set()
        while not self.stop_event.is_set():
            if self.wake_validation_ready_event.wait(0.025):
                break
        self.wake_validation_request_event.clear()
        if self.stop_event.is_set() or not self.wake_validation_ready_event.is_set():
            return False
        if not io.input_gate.generation_matches():
            io.close_input_gate()
            return False
        safe, desktop_name = io.input_desktop_status(force=True)
        if not safe:
            self._post("event", "醒前 Default Desktop 复验失败（{}），保持睡眠输入暂停".format(desktop_name))
            return False
        return not self.stop_event.is_set()

    def _load_model(self):
        if self.model_path.exists():
            try:
                return DoubleQNetwork.load(self.model_path), "已载入二进制模型"
            except Exception:
                self._quarantine(self.model_path)
                recovered = self._recover_checkpoint()
                if recovered is not None:
                    return recovered, "主模型校验失败，已回滚 checkpoint"
                return DoubleQNetwork(), "原模型无效，已新建"
        recovered = self._recover_checkpoint()
        if recovered is not None:
            return recovered, "已从 checkpoint 恢复模型"
        return DoubleQNetwork(), "已创建全新 Double-Q 模型"

    def _recover_checkpoint(self):
        if not self.checkpoint_dir.exists():
            return None
        for path in sorted(self.checkpoint_dir.glob("model_*.bin"), reverse=True):
            try:
                return DoubleQNetwork.load(path)
            except Exception:
                continue
        return None

    @staticmethod
    def _quarantine(path):
        try:
            os.replace(path, path.with_name(path.name + ".invalid_" + time.strftime("%Y%m%d_%H%M%S")))
        except OSError:
            pass

    def mark_model_dirty(self):
        self.model_dirty = True
        return True

    def save_model(self, force=False):
        force = bool(force)
        if not self.model_dirty and self.model_path.exists():
            self.memory.commit()
            return True
        now = time.monotonic()
        if not force and now - self.last_model_save < float(self.adaptive_save_interval):
            self.memory.commit()
            return False
        self.data_dir.mkdir(parents=True, exist_ok=True)
        payload = self.model.to_bytes()
        self.resource_budget.refresh()
        needed = max(64 * 1024 ** 2, len(payload) * 2)
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + needed:
            self.resource_budget.cleanup_regenerable_storage()
            self.resource_budget.refresh()
        if self.resource_budget.free_disk <= self.resource_budget.disk_reserve_bytes + needed:
            return False
        atomic_write(self.model_path, payload)
        self.memory.commit()
        self.model_dirty = False
        self.last_model_save = now
        return True

    def checkpoint(self):
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S") + "_" + str(self.model.training_steps)
        self.model.save(self.checkpoint_dir / ("model_" + stamp + ".bin"))
        files = sorted(self.checkpoint_dir.glob("model_*.bin"), reverse=True)
        for path in files[CHECKPOINT_KEEP:]:
            try:
                path.unlink()
            except OSError:
                pass

    def _post(self, kind, payload):
        self.messages.put((kind, payload))

    def _wait(self, duration):
        return not self.stop_event.wait(max(0.0, float(duration)))

    def _state(self, observation, goal, working):
        values = observation.features() + goal.features() + working.features()
        if len(values) != BASE_FEATURE_COUNT:
            raise ValueError("基础状态维度错误：{} != {}".format(len(values), BASE_FEATURE_COUNT))
        extra = max(0, self.model.input_count - BASE_FEATURE_COUNT)
        if extra:
            ui_count = int(extra * 0.52)
            goal_count = int(extra * 0.20)
            working_count = int(extra * 0.16)
            retrieval_count = extra - ui_count - goal_count - working_count
            values.extend(observation.adaptive_features(ui_count))
            values.extend(goal.adaptive_features(goal_count))
            values.extend(working.adaptive_features(working_count))
            values.extend(self.memory.retrieval_features(observation.signature, retrieval_count))
        values = normalize_state(values, self.model.input_count)
        return [clamp(float(value), 0.0, 1.0) for value in values]

    def _stats(self, phase, goal_label="", progress=0, total=0):
        tiers = self.memory.tier_counts()
        return {
            "phase": phase, "goal": goal_label, "hidden": self.model.hidden_count, "depth": self.model.depth, "input_count": self.model.input_count,
            "experiences": self.memory.count("episodic_memory"), "states": self.memory.count("state_memory"),
            "skills": self.memory.count("skill_memory"), "failures": self.memory.count("failure_memory"),
            "knowledge": self.memory.count("semantic_knowledge"), "world": self.memory.count("world_transition"),
            "bottleneck": str((self.planner.meta_report or {}).get("bottleneck", "none")),
            "sleep_count": self.model.sleep_count, "training_steps": self.model.training_steps,
            "target_syncs": self.model.target_syncs, "growth": self.model.accepted_growth,
            "loss": self.model.loss_average, "reward": self.model.reward_average,
            "goal_progress": self.model.progress_average, "safety": self.model.safety_average,
            "progress": progress, "total": total, "capacities": dict(self.model.capacities), "compute_backend": getattr(self.model, "compute_backend", "stdlib-array"),
            "compressed_memory": tiers["compressed"], "archived_memory": tiers["archived"],
            "resources": self.resource_budget.as_dict(), "io_metrics": dict(self.last_io_metrics),
            "sleep_score": safe_float(self.last_sleep_decision.get("score", 0.0)),
            "sleep_factors": dict(self.last_sleep_decision.get("factors") or {}),
            "storage_paused": bool(getattr(self.memory, "storage_paused", False)),
            "storage_pause_reason": str(getattr(self.memory, "storage_pause_reason", "")),
            "task_benchmark_passed":int(self.task_benchmark.get("passed", 0)),
            "task_benchmark_total":int(self.task_benchmark.get("total", 0)),
            "task_safety_regressions":int(self.task_benchmark.get("safety_regressions", 0)),
        }

    def _record_crash(self, error):
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            with open(self.data_dir / "crash.log", "a", encoding="utf-8") as stream:
                stream.write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + repr(error) + "\n")
        except Exception:
            pass

    def _execute_command(self, io, command, observation, settings, interval):
        started = time.monotonic()
        outcome = {
            "ok": True, "executed": False, "blocked": False, "invalid": False, "blocked_reason": "",
            "safety_penalty": 0.0, "skill_id": None, "skill": None, "skill_success": False,
        }
        budget = {"remaining": max(
            32, int(self.model.capacities.get("skill_attention", 128)) * 4
            + int(self.model.capacities.get("planner_breadth", 48)),
        )}
        live_observation = {"value": observation}
        program_state = {"last_action": None}

        def resolve_value(value, variables):
            return SkillManager._resolve_program_value(value, variables)

        def condition_ok(condition, before_signature=""):
            if not condition:
                return True
            obs = live_observation["value"]
            if isinstance(condition, list):
                return all(condition_ok(item, before_signature) for item in condition)
            if not isinstance(condition, dict):
                return bool(condition)
            if "all" in condition:
                return all(condition_ok(item, before_signature) for item in condition.get("all", []))
            if "any" in condition:
                return any(condition_ok(item, before_signature) for item in condition.get("any", []))
            if "not" in condition:
                return not condition_ok(condition.get("not"), before_signature)
            if "focused_editable" in condition:
                focused = next((r for r in obs.accessibility.records if r.get("focused")), None)
                value = bool(focused and focused.get("control_type") in SafetyPolicy.SAFE_TEXT_TYPES and not focused.get("password"))
                return value == bool(condition.get("focused_editable"))
            if "focused_contains" in condition:
                needle = str(condition.get("focused_contains", "")).lower()
                focused = next((r for r in obs.accessibility.records if r.get("focused")), {})
                return needle in (str(focused.get("value", "")) + " " + str(focused.get("name", ""))).lower()
            if "control_exists" in condition:
                query = str(condition.get("control_exists", ""))
                return any(similarity(query, str(r.get("name", ""))) >= 0.28 for r in obs.accessibility.records)
            if "semantic_contains" in condition:
                return str(condition.get("semantic_contains", "")).lower() in obs.semantic_text.lower()
            if condition.get("structured_change"):
                return bool(before_signature and obs.semantic_signature != before_signature)
            return True

        def refresh_after_step():
            if not self._wait(min(0.16, max(0.025, interval * 0.35))):
                return False
            try:
                last = program_state.get("last_action")
                force_deep = bool(last is not None and last.parameters.get("force_deep_observation"))
                live_observation["value"] = io.capture(live_observation["value"], force_deep=force_deep, action_hint=last)
                return True
            except Exception:
                outcome["invalid"] = True
                outcome["blocked_reason"] = "程序步骤后重新感知失败"
                return True

        def run_program_step(step, depth, seen, variables, last_action=None):
            if self.stop_event.is_set():
                return False
            if not isinstance(step, dict) or depth > self.resource_budget.skill_depth():
                outcome["blocked"] = True; outcome["blocked_reason"] = "技能程序结构无效或层级过深"; outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.62)
                return True
            kind = str(step.get("type", "action"))
            if kind == "observe":
                try: live_observation["value"] = io.capture(live_observation["value"])
                except Exception: outcome["invalid"] = True; outcome["blocked_reason"] = "技能恢复阶段感知失败"
                return True
            if kind == "set":
                variables[str(step.get("name", "value"))] = resolve_value(step.get("value"), variables); return True
            if kind == "if":
                branch = step.get("then", []) if condition_ok(resolve_value(step.get("condition", {}), variables)) else step.get("else", [])
                for child in branch if isinstance(branch, list) else [branch]:
                    if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                    if outcome.get("blocked") or outcome.get("invalid"): return True
                return True
            if kind == "loop":
                maximum = min(self.resource_budget.skill_loop_iterations(), max(0, int(step.get("max_iterations", 1))))
                for _ in range(maximum):
                    if not condition_ok(resolve_value(step.get("while", {}), variables)): break
                    for child in step.get("steps", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                        if outcome.get("blocked") or outcome.get("invalid"): return True
                return True
            if kind == "retry":
                maximum = min(self.resource_budget.skill_retry_attempts(), max(1, int(step.get("max_attempts", 2))))
                for attempt in range(maximum):
                    before_sig = live_observation["value"].semantic_signature
                    for child in step.get("steps", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                        if outcome.get("blocked"): return True
                    if not refresh_after_step(): return False
                    if condition_ok(resolve_value(step.get("until", {}), variables), before_sig): return True
                    outcome["invalid"] = False; outcome["blocked_reason"] = ""
                    for child in step.get("recovery", []):
                        if not run_program_step(child, depth + 1, seen, variables, last_action): return False
                outcome["invalid"] = True; outcome["blocked_reason"] = "技能程序重试后仍未满足成功条件"
                return True
            if kind == "retry_last":
                replay = program_state.get("last_action") or last_action
                if replay is not None:
                    return run(replay, depth + 1, seen)
                return True
            if kind == "skill":
                args = resolve_value(step.get("args", {}), variables)
                return run(ActionCommand(SKILL, {"skill_id": int(step.get("skill_id", 0)), "args": args}, "子程序技能"), depth + 1, seen)
            command_payload = resolve_value(step.get("command", {}), variables)
            child = ActionCommand.from_payload(command_payload)
            child.evidence_source = "verified_skill"
            program_state["last_action"] = child
            if not run(child, depth + 1, seen): return False
            if outcome.get("blocked") or outcome.get("invalid"): return True
            return refresh_after_step()

        def run(current, depth, seen):
            if self.stop_event.is_set():
                return False
            if budget["remaining"] <= 0 or depth > self.resource_budget.skill_depth():
                outcome["blocked"] = True
                outcome["blocked_reason"] = "技能达到单次运行安全预算"
                outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.62)
                return True
            if current.kind in (CLICK, TYPE, KEY, SKILL):
                delegation = self.external_ai_policy.assess(current, live_observation["value"])
                if delegation.get("blocked"):
                    outcome["blocked"] = True
                    outcome["blocked_reason"] = str(delegation.get("reason") or "禁止把推理/任务委托给第三方 AI")
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 1.0)
                    outcome["external_ai_delegation"] = dict(delegation)
                    self._post("event", compact_json({
                        "blocked": True,
                        "reason": outcome["blocked_reason"],
                        "service": delegation.get("service", ""),
                        "evidence": delegation.get("evidence", ""),
                    }))
                    return True
            if current.kind == SKILL:
                identifier = int(current.parameters.get("skill_id", 0))
                if identifier in seen:
                    outcome["blocked"] = True; outcome["blocked_reason"] = "检测到技能循环调用"; outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.75)
                    return True
                skill = self.memory.get_skill(identifier)
                if skill is None:
                    outcome["invalid"] = True; outcome["blocked_reason"] = "技能不存在"; return True
                if depth == 0:
                    outcome["skill_id"] = identifier; outcome["skill"] = skill
                if not self.skills.precondition_matches(skill, live_observation["value"]):
                    outcome["invalid"] = True; outcome["blocked_reason"] = "技能前提不满足"; return True
                local_seen = set(seen); local_seen.add(identifier)
                variables = {}
                for name, spec in dict(skill.get("parameters") or {}).items():
                    variables[name] = spec.get("default", "") if isinstance(spec, dict) else spec
                variables.update(dict(current.parameters.get("args") or {}))
                for step in skill.get("steps", []):
                    if not run_program_step(step, depth + 1, local_seen, variables):
                        return False
                    if outcome.get("blocked") or outcome.get("invalid"):
                        break
                # 技能成功条件是程序的一部分；失败时先观察并执行有限恢复，再交回规划器。
                if not outcome.get("blocked") and not outcome.get("invalid"):
                    outcome["skill_success"] = self.skills.success_matches(skill, live_observation["value"])
                if not outcome.get("skill_success") and not outcome.get("blocked"):
                    for recovery_step in skill.get("recovery", [])[:4]:
                        if not run_program_step(recovery_step, depth + 1, local_seen, variables):
                            return False
                        if outcome.get("blocked"): break
                    if not outcome.get("blocked"):
                        outcome["skill_success"] = self.skills.success_matches(skill, live_observation["value"])
                return True
            budget["remaining"] -= 1
            if current.kind == CLICK and not settings.get("clicks"):
                outcome["blocked"] = True
                outcome["blocked_reason"] = "用户已禁用鼠标点击"
                return True
            if current.kind in (KEY, TYPE) and not settings.get("keyboard"):
                outcome["blocked"] = True
                outcome["blocked_reason"] = "用户已禁用键盘输入"
                return True
            if current.kind in (CLICK, KEY, TYPE):
                planned_observation = live_observation["value"]
                planned_focus = next((control_locator(record) for record in planned_observation.accessibility.records if record.get("focused")), {})
                try:
                    fresh = io.capture(planned_observation, require_probe=True)
                except Exception:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前二次感知失败，已取消本次输入动作"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.55)
                    return True
                if planned_observation.accessibility.hwnd and fresh.accessibility.hwnd and planned_observation.accessibility.hwnd != fresh.accessibility.hwnd:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前检测到前台窗口变化，已取消动作并重新规划"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.60)
                    live_observation["value"] = fresh
                    return True
                if planned_observation.accessibility.window_class and fresh.accessibility.window_class and planned_observation.accessibility.window_class != fresh.accessibility.window_class:
                    outcome["invalid"] = True
                    outcome["blocked_reason"] = "执行前检测到窗口类型变化，已取消动作并重新规划"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.60)
                    live_observation["value"] = fresh
                    return True
                if current.kind == CLICK:
                    locator = dict(current.parameters.get("target") or {})
                    resolved = resolve_control(fresh, locator) if locator else None
                    if not locator:
                        planned_target = control_at_point(planned_observation, current.parameters.get("x", 0.5), current.parameters.get("y", 0.5), radius=0.10)
                        fresh_target = control_at_point(fresh, current.parameters.get("x", 0.5), current.parameters.get("y", 0.5), radius=0.10)
                        if planned_target is not None and (fresh_target is None or locator_score(control_locator(planned_target), fresh_target) < 0.9):
                            outcome["invalid"] = True
                            outcome["blocked_reason"] = "执行前检测到点击目标控件变化，已取消动作并重新规划"
                            outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.58)
                            live_observation["value"] = fresh
                            return True
                    if locator and resolved is not None:
                        current.parameters["x"] = float(resolved.get("x_norm", current.parameters.get("x", 0.5)))
                        current.parameters["y"] = float(resolved.get("y_norm", current.parameters.get("y", 0.5)))
                    elif locator:
                        fallback = current.parameters.get("fallback_point")
                        if fallback and len(fallback) >= 2:
                            current.parameters["x"] = safe_float(fallback[0], 0.5)
                            current.parameters["y"] = safe_float(fallback[1], 0.5)
                        elif "x" not in current.parameters or "y" not in current.parameters:
                            outcome["invalid"] = True
                            outcome["blocked_reason"] = "技能语义控件已不存在，且没有可用兜底位置；已重新规划"
                            live_observation["value"] = fresh
                            return True
                else:
                    fresh_focus = next((record for record in fresh.accessibility.records if record.get("focused")), None)
                    if bool(planned_focus) != bool(fresh_focus) or (planned_focus and fresh_focus is not None and locator_score(planned_focus, fresh_focus) < 0.9):
                        outcome["invalid"] = True
                        outcome["blocked_reason"] = "执行前检测到键盘焦点变化，已取消动作并重新规划"
                        outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.58)
                        live_observation["value"] = fresh
                        return True
                live_observation["value"] = fresh
            if current.kind == CLICK and current.parameters.get("remote_visual_target") and not current.parameters.get("target"):
                try:
                    probe_a = io.capture_target_probe(current.parameters.get("x", 0.5), current.parameters.get("y", 0.5))
                    if not self._wait(0.085):
                        return False
                    probe_b = io.capture_target_probe(current.parameters.get("x", 0.5), current.parameters.get("y", 0.5))
                    count = min(len(probe_a), len(probe_b))
                    change = sum(abs(float(probe_a[i]) - float(probe_b[i])) for i in range(count)) / max(1, count)
                    current.parameters["local_visual_stable"] = bool(change <= 0.055)
                except Exception:
                    current.parameters["local_visual_stable"] = False
            approved = self.approved_risk_fingerprint or str(settings.get("approved_risk_fingerprint", ""))
            approved_context = self.approved_risk_context or str(settings.get("approved_risk_context", ""))
            penalty, reason, blocked = self.safety.assess(
                current, live_observation["value"], bool(settings.get("safe_mode", True)),
                approved_fingerprint=approved, approved_context=approved_context, observe_only=bool(settings.get("observe_only", False)),
                mode=settings.get("mode", "task"), autonomous_profile=settings.get("autonomous_profile", "observe"),
            )
            outcome["safety_penalty"] = clamp(outcome["safety_penalty"] + penalty, 0.0, 1.0)
            if blocked:
                outcome["blocked"] = True
                outcome["blocked_reason"] = reason
                if reason.startswith("需要用户确认："):
                    outcome["approval_required"] = True
                    outcome["approval_fingerprint"] = current.fingerprint()
                    outcome["approval_context"] = self.safety.approval_token(current, live_observation["value"])
                    outcome["approval_label"] = current.label
                return True
            if bool(settings.get("observe_only", False)) and current.kind in (MOVE, CLICK, SCROLL, KEY, TYPE):
                outcome["executed"] = True
                outcome["simulated"] = True
                outcome["planned_action"] = current.payload()
                self._post("event", "只观察模式：原本准备执行“{}”；SendInput 未调用{}".format(
                    current.label or ACTION_NAMES[current.kind], "；" + reason if reason else "",
                ))
                return True
            if current.kind == WAIT:
                outcome["executed"] = True
                return self._wait(float(current.parameters.get("duration", 0.2)))
            if current.kind == SLEEP:
                return True
            expected_hwnd = live_observation["value"].accessibility.hwnd
            try:
                result = io.execute(current, self.stop_event, expected_hwnd=expected_hwnd)
            except OSError as error:
                if "Secure Desktop" in str(error) or "输入桌面" in str(error):
                    outcome["blocked"] = True
                    outcome["desktop_blocked"] = True
                    outcome["blocked_reason"] = "输入桌面已改变：立即停止 SendInput，等待 Default Desktop 恢复"
                    outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.35)
                    return True
                raise
            if not result and current.kind == TYPE and not self.stop_event.is_set():
                outcome["invalid"] = True
                outcome["blocked_reason"] = "文本输入期间前台窗口发生变化，已立即停止继续发送字符"
                outcome["safety_penalty"] = max(outcome["safety_penalty"], 0.78)
                return True
            outcome["executed"] = outcome["executed"] or bool(result)
            if bool(result) and self.safety._approved(current, approved, live_observation["value"], approved_context):
                self.approved_risk_fingerprint = ""
                self.approved_risk_context = ""
                settings["approved_risk_fingerprint"] = ""
                settings["approved_risk_context"] = ""
            return bool(result)

        outcome["ok"] = run(command, 0, set())
        outcome["duration"] = time.monotonic() - started
        return outcome

    @staticmethod
    def _decision_latency(model, items, repeats=1):
        states = [item.get("state", []) for item in (items or [])]
        if not states:
            return 0.0
        started = time.perf_counter()
        for _ in range(max(1, int(repeats))):
            for state in states:
                model.forward(state)
        return (time.perf_counter() - started) / (len(states) * max(1, int(repeats)))


    @staticmethod
    def _sleep_reward(awake_steps, stagnant, count, before_loss, after_loss, updates):
        backlog = clamp(math.log1p(count) / math.log(5000.0), 0.0, 1.0)
        stagnation_need = clamp(stagnant / 40.0, 0.0, 1.0)
        gain = 0.0
        if before_loss > 1e-9 and updates > 0:
            gain = clamp((before_loss - after_loss) / before_loss, -1.0, 1.0)
        early_penalty = max(0.0, (24 - awake_steps) / 24.0) * 0.20
        reward = backlog * 0.10 + stagnation_need * 0.16 + max(0.0, gain) * 0.48 - max(0.0, -gain) * 0.22 - early_penalty - 0.025
        return clamp(reward, -0.60, 0.65), gain

    def _sleep_and_learn(self, io, logger, goal_label, sleep_context=None, trigger="metacognitive"):
        """元认知睡眠：先诊断瓶颈，再只扩对应能力；网络结构增长最后考虑。"""
        sleep_context = dict(sleep_context or {})
        sleep_decision = dict(sleep_context.get("sleep_decision") or self.last_sleep_decision or {})
        sleep_started = time.monotonic()
        sleep_slice_index = 1
        sleep_deadline = sleep_started + SLEEP_WORK_SLICE_SECONDS
        training_exit_reason = "未训练"
        low_gain_batches = 0
        trained_experience_ids = set()
        candidate_trained_ids = set()
        candidate_priority_updates = []
        # FREE_ACTIVE -> FREE_SLEEP_PREPARE -> SLEEPING：先停止键鼠活动，再由 Application 恢复主界面并显式确认。
        io.pause_normal_input()
        self.sleep_ui_ready_event.clear()
        self._set_state(STATE_FREE_SLEEP_PREPARE)
        while not self.sleep_ui_ready_event.wait(0.02):
            if self.stop_event.is_set() or io.escape_down():
                raise InterruptedError("ESC：AI已停止睡觉" if io.escape_down() else "停止请求")
        if self.stop_event.is_set():
            raise InterruptedError("ESC：AI已停止睡觉" if (self.escape_event is not None and self.escape_event.is_set()) else "停止请求")
        self._set_state(STATE_SLEEPING)
        self.model.sleep_count += 1
        self.mark_model_dirty()
        self._post("stats", self._stats("睡眠 1/6：禁止输入并保存 checkpoint", goal_label))
        self.checkpoint()
        before_metrics = {
            "loss": float(self.model.loss_average), "reward": float(self.model.reward_average),
            "progress": float(self.model.progress_average), "safety": float(self.model.safety_average),
            "hidden": int(self.model.hidden_count), "depth": int(self.model.depth), "input": int(self.model.input_count),
            "sleep_score": safe_float(sleep_decision.get("score", 0.0)), "sleep_factors": dict(sleep_decision.get("factors") or {}),
        }
        self._post("stats", self._stats("睡眠 2/6：记忆压缩、知识沉淀、技能程序化与瓶颈诊断", goal_label))
        self.resource_budget.refresh(
            decision_latency=safe_float(sleep_context.get("decision_latency", 0.0)),
            perception_latency=safe_float(sleep_context.get("perception_latency", io.last_capture_seconds)),
        )
        sleep_pending_before = self.memory.pending_experience_count()
        sleep_fragmentation_before = self.memory.fragmentation_score()
        sleep_skill_conflict_before = MetaCognitiveSleep._skill_conflict(self.memory.top_skills(32))
        sleep_pending_capacity = max(1, self.resource_budget.memory_limits().get("episodic_memory", sleep_pending_before + 1))
        new_skills = self.skills.consolidate(deadline=sleep_deadline)
        summary = self.memory.consolidate(self.resource_budget, deadline=sleep_deadline)
        count = summary["experiences"]
        bottleneck, bottleneck_reason = BottleneckAnalyzer.classify(sleep_context, self.model, self.memory)
        candidate_origin_snapshot = self.model.snapshot()
        capacity_growth = []
        findings = [
            bottleneck_reason,
            "睡眠分数 {:.3f}；主要因素 {}".format(safe_float(sleep_decision.get("score", 0.0)), ",".join(sleep_decision.get("reasons", [])) or "综合负荷"),
            "热知识 {}，压缩记忆 {}，归档记忆 {}，世界模型 {}，技能 {}，恢复策略 {}".format(
                summary.get("knowledge", 0), summary.get("compressed", 0), summary.get("archived", 0),
                summary.get("world", 0), summary.get("skills", 0), summary.get("strategies", 0),
            ),
        ]
        if new_skills:
            findings.append("本次压缩出 {} 个新的参数化程序技能".format(new_skills))
        if summary.get("timed_out"):
            findings.append("记忆整理达到本睡眠工作切片预算，剩余分层整理留给下一切片")
        training = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=False), partition="train") if count else []
        evaluation = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=True), partition="validation") if count else []
        shadow_baseline = {}
        try:
            shadow_baseline = json.loads(self.memory.get_metadata("shadow_holdout_baseline_v1", "{}"))
        except Exception:
            shadow_baseline = {}
        shadow_request_count = max(8, int(shadow_baseline.get("count", 0) or self.resource_budget.training_batch_size(count, evaluation=True)))
        shadow = self.memory.sample_batch(shadow_request_count, partition="shadow") if count else []
        shadow_fingerprint = self.memory.holdout_fingerprint(shadow) if shadow else ""
        shadow_ready = bool(
            len(shadow) >= 8
            and shadow_fingerprint
            and shadow_baseline.get("fingerprint") == shadow_fingerprint
            and int(shadow_baseline.get("count", 0)) == len(shadow)
        )
        if len(shadow) >= 8 and not shadow_ready:
            # 数据集首次建立或发生变化时只记录当前主模型基线，本轮不训练；候选从下一次睡眠开始比较。
            initial_shadow_benchmark = self.model.benchmark(shadow)
            shadow_baseline = {
                "fingerprint": shadow_fingerprint, "count": len(shadow),
                "score": safe_float(initial_shadow_benchmark.get("score", 0.5), 0.5),
                "loss": self.model.validation_loss(shadow),
                "safety": safe_float(initial_shadow_benchmark.get("safety", 0.5), 0.5),
                "updated_at": time.time(),
            }
            self.memory.set_metadata("shadow_holdout_baseline_v1", compact_json(shadow_baseline), commit=False)
            findings.append("shadow-test 冻结基线已建立；本轮不训练、不扩结构")
        elif len(shadow) < 8:
            findings.append("shadow-test 样本不足；本轮不训练、不扩结构")
        if shadow_ready:
            capacity_growth = self.model.grow_capabilities(count, summary["skills"], bottleneck=bottleneck, resource_budget=self.resource_budget)
        before_loss = self.model.validation_loss(evaluation) if len(evaluation) >= 8 else 0.0
        before_benchmark = self.model.benchmark(evaluation) if len(evaluation) >= 8 else {"score": 0.5}
        before_task_benchmark = GoalCompilerRegressionSuite.run()
        before_intelligence_benchmark = LocalIntelligenceBenchmark.run()
        try:
            historical_best_intelligence = safe_float(self.memory.get_metadata("best_intelligence_benchmark_score", "0"), 0.0)
        except Exception:
            historical_best_intelligence = 0.0
        task_gate = (
            before_task_benchmark["total"] >= 50 and before_task_benchmark["safety_regressions"] == 0
            and before_intelligence_benchmark["safety_regressions"] == 0
        )
        findings.append("GoalCompiler 语法回归 {}/{}；回归失败 {}".format(before_task_benchmark["passed"], before_task_benchmark["total"], before_task_benchmark["safety_regressions"]))
        findings.append("LocalIntelligenceBenchmark {}/{}；安全回归 {}；历史最好 {:.3f}".format(
            before_intelligence_benchmark["passed"], before_intelligence_benchmark["total"],
            before_intelligence_benchmark["safety_regressions"], historical_best_intelligence,
        ))
        training_accepted = True
        grew = False
        growth_kind = "未触发"
        losses = []
        baseline_latency = self._decision_latency(self.model, evaluation, repeats=1) if evaluation else 0.0
        before_training_snapshot = self.model.snapshot()

        # 只有明确诊断为模型容量不足时，才允许增加输入槽；知识/技能/规划不足不再用神经元掩盖。
        input_growth_attempted = False
        if bottleneck == "model_capacity" and len(evaluation) >= 8:
            current_extra = max(0, self.model.input_count - BASE_FEATURE_COUNT)
            evidence_pressure = math.log1p(count) + math.log1p(summary["skills"]) * 1.4
            target_extra = current_extra + int(self.resource_budget.growth_amount("adaptive_input", current_extra or 1) * max(1.0, evidence_pressure / 8.0))
            if target_extra > current_extra:
                amount = target_extra - current_extra
                snapshot = self.model.snapshot()
                self.model.grow_input(amount, sync=False)
                latency = self._decision_latency(self.model, evaluation, repeats=1)
                if baseline_latency > 0 and latency > baseline_latency * 1.12:
                    self.model.restore(snapshot)
                    capacity_growth.append("自适应输入回滚：延迟预算")
                else:
                    input_growth_attempted = True
                    capacity_growth.append("自适应输入+{}（待 validation + shadow-test 验证）".format(amount))

        if shadow_ready and len(training) >= 8 and len(evaluation) >= 8 and len(shadow) >= 8 and time.monotonic() < sleep_deadline:
            self._post("stats", self._stats("睡眠 3/6：train 训练（validation 调度；shadow 隔离）", goal_label, 0, 1))
            updates = self.resource_budget.training_updates(count)
            last_eval_loss = before_loss
            last_eval_score = float(before_benchmark.get("score", 0.5))
            last_eval_at = time.monotonic()
            training_exit_reason = "达到计划更新数"
            for number in range(updates):
                now = time.monotonic()
                if now >= sleep_deadline:
                    training_exit_reason = "达到本睡眠工作切片时间预算"
                    break
                escaped = bool(io.escape_down())
                if self.stop_event.is_set() or escaped:
                    io.close_input_gate()
                    raise InterruptedError("ESC：AI已停止睡觉" if (escaped or (self.escape_event is not None and self.escape_event.is_set())) else "停止请求")
                item = random.choice(training)
                loss = self.model.train_one(item, allow_target_sync=False)
                candidate_trained_ids.add(int(item.get("id", 0)))
                losses.append(loss)
                candidate_priority_updates.append((item["id"], loss + abs(item.get("goal_reward", 0.0)) * 1.4 + item.get("safety_penalty", 0.0) + 0.01))
                completed = number + 1
                if completed % max(1, SLEEP_EVAL_INTERVAL) == 0:
                    interim_loss = self.model.validation_loss(evaluation)
                    interim_benchmark = self.model.benchmark(evaluation)
                    interim_score = float(interim_benchmark.get("score", 0.5))
                    batch_seconds = max(1e-6, time.monotonic() - last_eval_at)
                    relative_gain = ((last_eval_loss - interim_loss) / max(last_eval_loss, 1e-9)) if last_eval_loss > 1e-9 else 0.0
                    score_gain = interim_score - last_eval_score
                    useful_gain = max(0.0, relative_gain, score_gain)
                    gain_per_second = useful_gain / batch_seconds
                    weak_gain = relative_gain < SLEEP_MIN_RELATIVE_GAIN and score_gain < 0.001
                    weak_efficiency = gain_per_second < SLEEP_MIN_GAIN_PER_SECOND
                    if weak_gain or weak_efficiency:
                        low_gain_batches += 1
                    else:
                        low_gain_batches = 0
                    self._post("stats", self._stats(
                        "睡眠训练：批次收益 {:.4f} / {:.2f}s，低收益 {}/{}".format(useful_gain, batch_seconds, low_gain_batches, SLEEP_NO_GAIN_PATIENCE),
                        goal_label, completed, updates,
                    ))
                    last_eval_loss, last_eval_score, last_eval_at = interim_loss, interim_score, time.monotonic()
                    if low_gain_batches >= SLEEP_NO_GAIN_PATIENCE:
                        training_exit_reason = "连续低收益批次，提前结束本切片训练"
                        break
                elif number % 20 == 0:
                    self._post("stats", self._stats("睡眠 3/6：train 分区离线训练", goal_label, completed, updates)); time.sleep(0)
            self._post("stats", self._stats("睡眠 4/6：validation、延迟与安全回归验证", goal_label))
            after_loss = self.model.validation_loss(evaluation)
            after_benchmark = self.model.benchmark(evaluation)
            after_task_benchmark = GoalCompilerRegressionSuite.run()
            after_intelligence_benchmark = LocalIntelligenceBenchmark.run()
            after_latency = self._decision_latency(self.model, evaluation, repeats=1)
            input_ok = (not input_growth_attempted) or (after_benchmark["score"] >= before_benchmark["score"] + 0.001 and (baseline_latency <= 0 or after_latency <= baseline_latency * 1.12))
            intelligence_floor = max(float(before_intelligence_benchmark.get("score", 0.0)), historical_best_intelligence)
            task_gate = (
                after_task_benchmark["total"] >= 50 and after_task_benchmark["passed"] >= before_task_benchmark["passed"]
                and after_task_benchmark["safety_regressions"] <= before_task_benchmark["safety_regressions"]
                and after_intelligence_benchmark["score"] + 1e-12 >= intelligence_floor
                and after_intelligence_benchmark["safety_regressions"] == 0
            )
            validation_improved = bool(
                after_benchmark["score"] > before_benchmark["score"] + 1e-6
                or (before_loss > 1e-9 and after_loss < before_loss * 0.995)
            )
            training_accepted = validation_improved and input_ok and task_gate
            if not training_accepted:
                self.model.restore(before_training_snapshot)
                after_loss = before_loss; after_benchmark = before_benchmark
                findings.append("训练回滚：validation 未改善或延迟/安全门未通过")
            findings.append("训练退出：{}；实际更新 {}；连续低收益批次 {}".format(training_exit_reason, len(losses), low_gain_batches))
        else:
            after_loss = before_loss; after_benchmark = before_benchmark
            after_task_benchmark = before_task_benchmark
            after_intelligence_benchmark = before_intelligence_benchmark
            training_accepted = False
            training_exit_reason = "train/validation/shadow 样本或冻结基线不足" if len(training) < 8 or len(evaluation) < 8 or len(shadow) < 8 or not shadow_ready else "本睡眠工作切片时间预算已耗尽"
            findings.append("{}：只整理知识/技能，不继续训练或扩神经网络".format(training_exit_reason))

        # 模型增宽/加深是最后一级机制，并且必须是 model_capacity 瓶颈 + 数据充分 + validation/延迟验证通过。
        plateau = before_loss > 1e-9 and after_loss >= before_loss * 0.985
        capability_pressure = self.model.progress_average < 0.04 or self.model.safety_average > 0.16 or float(after_benchmark.get("score", 0.5)) < 0.72
        evidence_floor = max(32, int(math.sqrt(max(1, self.resource_budget.memory_limits().get("episodic_memory", 1))) * 4.0))
        if training_accepted and shadow_ready and bottleneck == "model_capacity" and task_gate and len(training) >= 32 and len(evaluation) >= 8 and count >= max(evidence_floor, self.model.hidden_count * 10) and (plateau or capability_pressure) and not self.stop_event.is_set() and time.monotonic() < sleep_deadline - 0.75:
            snapshot = self.model.snapshot()
            baseline_growth_loss = after_loss
            baseline_growth_benchmark = after_benchmark
            baseline_growth_latency = self._decision_latency(self.model, evaluation, repeats=1)
            if self.model.sleep_count % 5 == 0:
                depth_extra = self.resource_budget.growth_amount("adaptive_input", self.model.layer_sizes[-1])
                self.model.grow_depth(self.model.layer_sizes[-1] + depth_extra, sync=False); growth_kind = "深度"
            else:
                layer_index = min(range(len(self.model.layer_sizes)), key=lambda index: self.model.layer_sizes[index])
                width_growth = self.resource_budget.growth_amount("adaptive_input", self.model.layer_sizes[layer_index])
                self.model.grow_width(layer_index, width_growth, sync=False); growth_kind = "宽度"
            for _ in range(max(len(training), self.resource_budget.training_updates(count) // 3)):
                if self.stop_event.is_set() or time.monotonic() >= sleep_deadline: break
                growth_item = random.choice(training)
                self.model.train_one(growth_item, learning_rate=0.00072, allow_target_sync=False)
                candidate_trained_ids.add(int(growth_item.get("id", 0)))
            grown_loss = self.model.validation_loss(evaluation)
            grown_benchmark = self.model.benchmark(evaluation)
            grown_task_benchmark = GoalCompilerRegressionSuite.run()
            grown_intelligence_benchmark = LocalIntelligenceBenchmark.run()
            grown_latency = self._decision_latency(self.model, evaluation, repeats=1)
            gain = grown_benchmark["score"] - baseline_growth_benchmark["score"]
            latency_ratio = grown_latency / max(1e-9, baseline_growth_latency) if baseline_growth_latency > 0 else 1.0
            task_growth_ok = (
                grown_task_benchmark["passed"] >= after_task_benchmark["passed"]
                and grown_task_benchmark["safety_regressions"] <= after_task_benchmark["safety_regressions"]
                and grown_intelligence_benchmark["score"] + 1e-12 >= max(float(after_intelligence_benchmark.get("score", 0.0)), historical_best_intelligence)
                and grown_intelligence_benchmark["safety_regressions"] == 0
            )
            if ((gain >= 0.001) or (gain > 0 and grown_loss <= baseline_growth_loss * 0.985)) and (latency_ratio <= 1.22 or (gain >= 0.015 and latency_ratio <= 1.50)) and task_growth_ok:
                self.model.accepted_growth += 1; grew = True; after_loss = grown_loss; after_benchmark = grown_benchmark; after_task_benchmark = grown_task_benchmark; after_intelligence_benchmark = grown_intelligence_benchmark
                capacity_growth.append("神经网络{}扩张通过 validation/延迟验证，待 shadow-test 晋升".format(growth_kind))
            else:
                self.model.restore(snapshot); self.model.rejected_growth += 1; findings.append("神经网络结构扩张回滚：收益/延迟未达标"); growth_kind = "回滚"

        # shadow-test 在候选训练和结构选择全部结束后只运行一次；不参与梯度、早停或结构选择。
        shadow_promoted = False
        shadow_after_benchmark = None
        if training_accepted and shadow_ready:
            self._post("stats", self._stats("睡眠 4/6：候选完成，执行一次隔离 shadow-test", goal_label))
            shadow_after_benchmark = self.model.benchmark(shadow)
            shadow_after_loss = self.model.validation_loss(shadow)
            final_latency = self._decision_latency(self.model, evaluation, repeats=1) if evaluation else 0.0
            validation_improved = bool(
                after_benchmark["score"] > before_benchmark["score"] + 1e-6
                or (before_loss > 1e-9 and after_loss < before_loss * 0.995)
            )
            shadow_not_down = bool(
                safe_float(shadow_after_benchmark.get("score", 0.0)) + 1e-12 >= safe_float(shadow_baseline.get("score", 0.0))
                and (safe_float(shadow_baseline.get("loss", 0.0)) <= 1e-9 or shadow_after_loss <= safe_float(shadow_baseline.get("loss", 0.0)) * 1.01)
                and safe_float(shadow_after_benchmark.get("safety", 0.0)) + 1e-12 >= safe_float(shadow_baseline.get("safety", 0.0))
            )
            safety_regression_zero = bool(
                int(after_task_benchmark.get("safety_regressions", 0)) == 0
                and int(after_intelligence_benchmark.get("safety_regressions", 0)) == 0
            )
            latency_ok = bool(baseline_latency <= 0 or final_latency <= baseline_latency * 1.15)
            shadow_promoted = validation_improved and shadow_not_down and safety_regression_zero and latency_ok
            if shadow_promoted:
                trained_experience_ids.update(candidate_trained_ids)
                if candidate_priority_updates:
                    self.memory.update_priorities(candidate_priority_updates)
                shadow_baseline = {
                    "fingerprint": shadow_fingerprint, "count": len(shadow),
                    "score": safe_float(shadow_after_benchmark.get("score", 0.5), 0.5),
                    "loss": shadow_after_loss,
                    "safety": safe_float(shadow_after_benchmark.get("safety", 0.5), 0.5),
                    "updated_at": time.time(),
                }
                self.memory.set_metadata("shadow_holdout_baseline_v1", compact_json(shadow_baseline), commit=False)
                findings.append("候选晋升：validation 改善、shadow-test 不下降、安全回归为 0、延迟在预算内")
            else:
                findings.append("候选回滚：validation/shadow-test/安全/延迟晋升门未全部通过")
        if not shadow_promoted:
            self.model.restore(candidate_origin_snapshot)
            training_accepted = False
            grew = False
            growth_kind = "回滚"
            after_loss = before_loss
            after_benchmark = before_benchmark
            after_task_benchmark = before_task_benchmark
            after_intelligence_benchmark = before_intelligence_benchmark
            if capacity_growth:
                capacity_growth = ["候选能力/结构增长已由 shadow-test 晋升门回滚"]

        self._post("stats", self._stats("睡眠 5/6：生成 SleepReport 并更新下一轮策略", goal_label))
        self.model.sync_target()
        io.set_capacities(self.model.capacities)
        self.planner.set_breadth(self.model.capacities["planner_breadth"])
        self.skills.set_attention_limit(self.model.capacities["skill_attention"])
        improvements, regressions = [], []
        before_score = float(before_benchmark.get("score", 0.5)); after_score = float(after_benchmark.get("score", 0.5))
        if after_score > before_score + 0.001: improvements.append("validation 基准 {:.3f}→{:.3f}".format(before_score, after_score))
        if before_loss > 0 and after_loss < before_loss * 0.99: improvements.append("验证误差 {:.4f}→{:.4f}".format(before_loss, after_loss))
        if after_score < before_score - 0.001: regressions.append("validation 基准下降 {:.3f}→{:.3f}".format(before_score, after_score))
        if before_loss > 0 and after_loss > before_loss * 1.01: regressions.append("验证误差上升 {:.4f}→{:.4f}".format(before_loss, after_loss))
        after_metrics = {
            "loss": float(after_loss), "benchmark": after_score, "hidden": int(self.model.hidden_count), "depth": int(self.model.depth),
            "input": int(self.model.input_count), "knowledge": int(summary.get("knowledge", 0)), "world": int(summary.get("world", 0)), "skills": int(summary.get("skills", 0)),
            "task_benchmark_passed":int(after_task_benchmark["passed"]), "task_benchmark_total":int(after_task_benchmark["total"]),
            "task_safety_regressions":int(after_task_benchmark["safety_regressions"]),
            "intelligence_benchmark_score":float(after_intelligence_benchmark.get("score", 0.0)),
            "intelligence_safety_regressions":int(after_intelligence_benchmark.get("safety_regressions", 0)),
            "shadow_promoted": bool(shadow_promoted),
            "shadow_score": safe_float((shadow_after_benchmark or shadow_baseline).get("score", 0.0)),
            "shadow_safety": safe_float((shadow_after_benchmark or shadow_baseline).get("safety", 0.0)),
            "shadow_count": len(shadow),
        }
        self.task_benchmark = dict(after_task_benchmark)
        accepted_intelligence_score = max(historical_best_intelligence, float(after_intelligence_benchmark.get("score", 0.0)))
        if int(after_intelligence_benchmark.get("safety_regressions", 0)) == 0:
            self.memory.set_metadata("best_intelligence_benchmark_score", str(accepted_intelligence_score), commit=False)
        sleep_elapsed = time.monotonic() - sleep_started
        pending_after = max(0, int(sleep_pending_before) - len(trained_experience_ids))
        fragmentation_after = self.memory.fragmentation_score()
        relative_training_gain = ((before_loss - after_loss) / max(before_loss, 1e-9)) if before_loss > 1e-9 else 0.0
        benchmark_gain = float(after_benchmark.get("score", 0.5)) - float(before_benchmark.get("score", 0.5))
        memory_gain = clamp(
            max(0.0, (sleep_pending_before - pending_after) / max(1.0, float(sleep_pending_before))) * 0.65
            + max(0.0, sleep_fragmentation_before - fragmentation_after) * 0.35,
            0.0, 1.0,
        )
        wake_effects = {
            "pending_before": sleep_pending_before,
            "pending_after": pending_after,
            "pending_capacity": sleep_pending_capacity,
            "fragmentation_before": sleep_fragmentation_before,
            "fragmentation_after": fragmentation_after,
            "training_gain_per_second": max(0.0, relative_training_gain, benchmark_gain) / max(1e-6, sleep_elapsed),
            "memory_gain": memory_gain,
            "new_skill_count": new_skills,
            "skill_conflict_after": MetaCognitiveSleep._skill_conflict(self.memory.top_skills(32)),
            "world_uncertainty_after": safe_float(sleep_decision.get("factors", {}).get("world_uncertainty", 0.0)),
            "repeated_failure_after": safe_float(sleep_decision.get("factors", {}).get("repeated_failure", 0.0)),
            "goal_stagnation_after": safe_float(sleep_decision.get("factors", {}).get("goal_stagnation", 0.0)),
        }
        wake_decision = MetaCognitiveSleep.after_sleep(
            sleep_decision, before_loss, after_loss, training_accepted,
            sleep_elapsed=sleep_elapsed, resource_deadline_reached=(time.monotonic() >= sleep_deadline), effects=wake_effects,
        )
        continuation_cycles = 0
        while not wake_decision.get("wake_ready") and not self.stop_event.is_set():
            if io.escape_down():
                io.close_input_gate()
                raise InterruptedError("ESC：AI 已停止")
            continuation_cycles += 1
            sleep_slice_index += 1
            slice_started = time.monotonic()
            slice_deadline = slice_started + SLEEP_WORK_SLICE_SECONDS
            self._post("stats", self._stats(
                "继续睡眠：AI 尚未认为需要醒来；开始第 {} 个 {:.0f}s 工作切片".format(sleep_slice_index, SLEEP_WORK_SLICE_SECONDS),
                goal_label,
            ))

            slice_pending_before = max(0, int(sleep_pending_before) - len(trained_experience_ids))
            slice_fragmentation_before = self.memory.fragmentation_score()
            slice_skill_conflict_before = MetaCognitiveSleep._skill_conflict(self.memory.top_skills(32))
            slice_skill_count = self.skills.consolidate(deadline=slice_deadline)
            new_skills += int(slice_skill_count or 0)
            summary = self.memory.consolidate(self.resource_budget, deadline=slice_deadline)
            count = summary["experiences"]

            slice_training = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=False), partition="train") if count else []
            slice_evaluation = self.memory.sample_batch(self.resource_budget.training_batch_size(count, evaluation=True), partition="validation") if count else []
            try:
                slice_shadow_baseline = json.loads(self.memory.get_metadata("shadow_holdout_baseline_v1", "{}"))
            except Exception:
                slice_shadow_baseline = {}
            slice_shadow_request = max(8, int(slice_shadow_baseline.get("count", 0) or self.resource_budget.training_batch_size(count, evaluation=True)))
            slice_shadow = self.memory.sample_batch(slice_shadow_request, partition="shadow") if count else []
            slice_shadow_fingerprint = self.memory.holdout_fingerprint(slice_shadow) if slice_shadow else ""
            slice_shadow_ready = bool(
                len(slice_shadow) >= 8
                and slice_shadow_baseline.get("fingerprint") == slice_shadow_fingerprint
                and int(slice_shadow_baseline.get("count", 0)) == len(slice_shadow)
            )
            slice_before_loss = self.model.validation_loss(slice_evaluation) if len(slice_evaluation) >= 8 else max(0.0, after_loss)
            slice_before_benchmark = self.model.benchmark(slice_evaluation) if len(slice_evaluation) >= 8 else dict(after_benchmark)
            slice_before_snapshot = self.model.snapshot()
            slice_accepted = False
            slice_updates_done = 0
            slice_priority_updates = []
            slice_trained_ids = set()
            slice_losses = []
            slice_baseline_latency = self._decision_latency(self.model, slice_evaluation, repeats=1) if slice_evaluation else 0.0

            if slice_shadow_ready and len(slice_training) >= 8 and len(slice_evaluation) >= 8 and time.monotonic() < slice_deadline:
                planned_updates = self.resource_budget.training_updates(count)
                for number in range(planned_updates):
                    if time.monotonic() >= slice_deadline:
                        break
                    escaped = bool(io.escape_down())
                    if self.stop_event.is_set() or escaped:
                        io.close_input_gate()
                        raise InterruptedError("ESC：AI已停止睡觉" if (escaped or (self.escape_event is not None and self.escape_event.is_set())) else "停止请求")
                    item = random.choice(slice_training)
                    loss = self.model.train_one(item, allow_target_sync=False)
                    slice_trained_ids.add(int(item.get("id", 0)))
                    slice_losses.append(loss)
                    slice_updates_done += 1
                    slice_priority_updates.append((item["id"], loss + abs(item.get("goal_reward", 0.0)) * 1.4 + item.get("safety_penalty", 0.0) + 0.01))
                    if number % 24 == 0:
                        time.sleep(0)
                slice_after_loss = self.model.validation_loss(slice_evaluation)
                slice_after_benchmark = self.model.benchmark(slice_evaluation)
                slice_after_latency = self._decision_latency(self.model, slice_evaluation, repeats=1)
                slice_validation_improved = bool(
                    slice_after_benchmark["score"] > slice_before_benchmark["score"] + 1e-6
                    or (slice_before_loss > 1e-9 and slice_after_loss < slice_before_loss * 0.995)
                )
                # 候选训练完成后才执行一次 shadow-test。
                slice_shadow_after = self.model.benchmark(slice_shadow)
                slice_shadow_loss = self.model.validation_loss(slice_shadow)
                slice_task_safety_regressions = GoalCompilerRegressionSuite.run()["safety_regressions"]
                slice_intelligence_safety_regressions = LocalIntelligenceBenchmark.run()["safety_regressions"]
                slice_shadow_not_down = bool(
                    safe_float(slice_shadow_after.get("score", 0.0)) + 1e-12 >= safe_float(slice_shadow_baseline.get("score", 0.0))
                    and (safe_float(slice_shadow_baseline.get("loss", 0.0)) <= 1e-9 or slice_shadow_loss <= safe_float(slice_shadow_baseline.get("loss", 0.0)) * 1.01)
                    and safe_float(slice_shadow_after.get("safety", 0.0)) + 1e-12 >= safe_float(slice_shadow_baseline.get("safety", 0.0))
                )
                slice_accepted = bool(
                    slice_validation_improved and slice_shadow_not_down
                    and int(slice_task_safety_regressions) == 0
                    and int(slice_intelligence_safety_regressions) == 0
                    and (slice_baseline_latency <= 0 or slice_after_latency <= slice_baseline_latency * 1.15)
                )
                if not slice_accepted:
                    self.model.restore(slice_before_snapshot)
                    slice_after_loss = slice_before_loss
                    slice_after_benchmark = slice_before_benchmark
                    findings.append("第 {} 睡眠切片训练回滚：validation/shadow-test/安全/延迟门未通过".format(sleep_slice_index))
                else:
                    trained_experience_ids.update(slice_trained_ids)
                    losses.extend(slice_losses)
                    if slice_priority_updates:
                        self.memory.update_priorities(slice_priority_updates)
                    after_loss = slice_after_loss
                    after_benchmark = slice_after_benchmark
                    self.memory.set_metadata("shadow_holdout_baseline_v1", compact_json({
                        "fingerprint": slice_shadow_fingerprint, "count": len(slice_shadow),
                        "score": safe_float(slice_shadow_after.get("score", 0.5), 0.5),
                        "loss": slice_shadow_loss,
                        "safety": safe_float(slice_shadow_after.get("safety", 0.5), 0.5),
                        "updated_at": time.time(),
                    }), commit=False)
            else:
                slice_after_loss = slice_before_loss
                slice_after_benchmark = slice_before_benchmark
                if len(slice_shadow) >= 8 and not slice_shadow_ready:
                    baseline = self.model.benchmark(slice_shadow)
                    self.memory.set_metadata("shadow_holdout_baseline_v1", compact_json({
                        "fingerprint": slice_shadow_fingerprint, "count": len(slice_shadow),
                        "score": safe_float(baseline.get("score", 0.5), 0.5),
                        "loss": self.model.validation_loss(slice_shadow),
                        "safety": safe_float(baseline.get("safety", 0.5), 0.5),
                        "updated_at": time.time(),
                    }), commit=False)

            training_accepted = bool(training_accepted or slice_accepted)
            slice_elapsed = max(1e-6, time.monotonic() - slice_started)
            slice_pending_after = max(0, int(sleep_pending_before) - len(trained_experience_ids))
            slice_fragmentation_after = self.memory.fragmentation_score()
            slice_relative_gain = ((slice_before_loss - slice_after_loss) / max(slice_before_loss, 1e-9)) if slice_before_loss > 1e-9 else 0.0
            slice_benchmark_gain = float(slice_after_benchmark.get("score", 0.5)) - float(slice_before_benchmark.get("score", 0.5))
            slice_memory_gain = clamp(
                max(0.0, (slice_pending_before - slice_pending_after) / max(1.0, float(slice_pending_before))) * 0.65
                + max(0.0, slice_fragmentation_before - slice_fragmentation_after) * 0.35,
                0.0, 1.0,
            )
            wake_effects = {
                "pending_before": slice_pending_before,
                "pending_after": slice_pending_after,
                "pending_capacity": sleep_pending_capacity,
                "fragmentation_before": slice_fragmentation_before,
                "fragmentation_after": slice_fragmentation_after,
                "training_gain_per_second": max(0.0, slice_relative_gain, slice_benchmark_gain) / slice_elapsed,
                "memory_gain": slice_memory_gain,
                "new_skill_count": int(slice_skill_count or 0),
                "skill_conflict_after": MetaCognitiveSleep._skill_conflict(self.memory.top_skills(32)),
                "world_uncertainty_after": safe_float(wake_decision.get("factors", {}).get("world_uncertainty", 0.0)),
                "repeated_failure_after": safe_float(wake_decision.get("factors", {}).get("repeated_failure", 0.0)),
                "goal_stagnation_after": safe_float(wake_decision.get("factors", {}).get("goal_stagnation", 0.0)),
            }
            wake_decision = MetaCognitiveSleep.after_sleep(
                {"factors": wake_decision.get("factors", {})}, slice_before_loss, slice_after_loss, slice_accepted,
                sleep_elapsed=(time.monotonic() - sleep_started),
                resource_deadline_reached=(time.monotonic() >= slice_deadline), effects=wake_effects,
            )
            if not wake_decision.get("wake_ready"):
                training_exit_reason = "AI 决定继续睡眠"
                self.model.sync_target()
                self.mark_model_dirty()
                self.save_model(force=False)
                self.memory.commit()
                self._post("stats", self._stats("继续睡眠：AI 尚未认为需要醒来", goal_label))
            else:
                training_exit_reason = "AI 判断睡眠充分，准备醒来"
        if self.stop_event.is_set():
            io.close_input_gate()
            raise InterruptedError("ESC：AI已停止睡觉" if (self.escape_event is not None and self.escape_event.is_set()) else "停止请求")
        # wake_ready=True 只表示 AI 已决定可以醒；在 SleepReport/模型原子保存完成前仍保持 STATE_SLEEPING + pause gate。
        after_metrics["wake_score"] = safe_float(wake_decision.get("score", 0.0))
        after_metrics["wake_threshold"] = SLEEP_WAKE_THRESHOLD
        after_metrics["wake_factors"] = dict(wake_decision.get("factors") or {})
        after_metrics["entry_policy"] = MetaCognitiveSleep._ENTRY_POLICY.snapshot()
        after_metrics["wake_policy"] = MetaCognitiveSleep._WAKE_POLICY.snapshot()
        after_metrics["pending_experience_before"] = int(sleep_pending_before)
        after_metrics["pending_experience_after"] = max(0, int(sleep_pending_before) - len(trained_experience_ids))
        after_metrics["memory_fragmentation_before"] = float(sleep_fragmentation_before)
        after_metrics["memory_fragmentation_after"] = float(self.memory.fragmentation_score())
        after_metrics["skill_conflict_before"] = float(sleep_skill_conflict_before)
        after_metrics["skill_conflict_after"] = float(MetaCognitiveSleep._skill_conflict(self.memory.top_skills(32)))
        after_metrics["continuation_cycles"] = continuation_cycles
        after_metrics["sleep_elapsed_seconds"] = round(time.monotonic() - sleep_started, 4)
        after_metrics["sleep_work_slice_seconds"] = SLEEP_WORK_SLICE_SECONDS
        after_metrics["training_exit_reason"] = training_exit_reason
        after_metrics["low_gain_batches"] = low_gain_batches
        trigger = str(trigger or "metacognitive")
        trigger_reason = str(sleep_context.get("reason", "元认知负荷触发睡眠"))
        reason_text = (
            "entry_policy={:.3f} boundary={:.2f} safety={}；{}".format(
                safe_float(sleep_decision.get("score", 0.0)), SleepEntryPolicy.DECISION_BOUNDARY,
                bool(sleep_decision.get("safety_sleep_required")), trigger_reason,
            )
            if trigger == "metacognitive" else "{}；{}".format(trigger, trigger_reason)
        )
        report = {
            "trigger": trigger, "reason": reason_text, "findings": findings,
            "improvements": improvements, "regressions": regressions, "repeated_errors": self.memory.recent_failure_patterns(8),
            "bottleneck": bottleneck, "structural_growth": list(capacity_growth), "before_metrics": before_metrics, "after_metrics": after_metrics,
        }
        report = self.memory.remember_sleep_report(report)
        self.planner.set_meta_report(report)
        self._post("stats", self._stats("睡眠 6/6：原子保存模型、索引与 SleepReport", goal_label))
        self.mark_model_dirty()
        self.save_model(force=True); self.checkpoint()
        # AI 决定醒来后先进入 GUI 握手：显示“AI醒来” -> 隐藏主界面 -> Application 确认隐藏；随后才做醒前安全复验和恢复输入。
        if not bool(wake_decision.get("wake_ready")):
            io.close_input_gate()
            raise RuntimeError("wake_decision 未给出 wake_ready=True，拒绝退出睡眠")
        self.wake_ui_hidden_event.clear()
        self._set_state(STATE_FREE_WAKE_PREPARE)
        while not self.wake_ui_hidden_event.wait(0.02):
            if self.stop_event.is_set():
                raise InterruptedError("ESC：AI已停止睡觉" if (self.escape_event is not None and self.escape_event.is_set()) else "停止请求")
        if not self._request_wake_validation(io):
            io.close_input_gate()
            raise InterruptedError("醒前 P0 安全条件复验失败，AI 已停止")
        io.resume_normal_input()
        self._set_state(STATE_FREE_ACTIVE)
        logger.write("sleep", {
            "updates": len(losses), "new_skills": new_skills, "before_loss": before_loss, "after_loss": after_loss,
            "before_benchmark": before_score, "after_benchmark": after_score, "training_accepted": training_accepted,
            "grew": grew, "growth_kind": growth_kind, "capacity_growth": capacity_growth, "bottleneck": bottleneck,
            "sleep_report": report, "memory": summary,
            "sleep_decision": sleep_decision, "wake_decision": wake_decision,
            "sleep_elapsed_seconds": round(time.monotonic() - sleep_started, 4),
            "sleep_work_slice_seconds": SLEEP_WORK_SLICE_SECONDS, "training_exit_reason": training_exit_reason, "low_gain_batches": low_gain_batches,
        })
        return {"updates": len(losses), "new_skills": new_skills, "before_loss": before_loss, "after_loss": after_loss,
                "before_benchmark": before_score, "after_benchmark": after_score, "training_accepted": training_accepted,
                "grew": grew, "capacity_growth": capacity_growth, "summary": summary, "sleep_report": report, "bottleneck": bottleneck,
                "sleep_decision": sleep_decision, "wake_decision": wake_decision,
                "sleep_elapsed_seconds": round(time.monotonic() - sleep_started, 4),
                "training_exit_reason": training_exit_reason, "low_gain_batches": low_gain_batches}

    def _remember_emitted(self, emitted):
        for item in emitted:
            self.memory.add_experience(item)
            self.world_model.observe(item)

    def _wait_for_default_desktop(self, io, announce=True):
        announced = False
        while not self.stop_event.is_set():
            safe, name = io.input_desktop_status(force=True)
            if safe:
                if announced and announce:
                    self._post("event", "Default Desktop 已恢复；重新感知后才允许输入")
                return True
            if announce and not announced:
                self._post("event", "检测到 Secure/未知 Input Desktop（{}）：fail-closed，所有 SendInput 已禁止".format(name))
                announced = True
            if not self._wait(0.12):
                return False
        return False

    def _validate_initial_context(self, io, observation, locked):
        locked = dict(locked or {})
        expected_hwnd = int(locked.get("hwnd", 0) or 0)
        if not expected_hwnd:
            return observation, True, "没有可锁定的外部前台窗口，采用启动后的稳定窗口"
        current_hwnd = int(observation.accessibility.hwnd or 0)
        if current_hwnd == expected_hwnd:
            return observation, True, "初始工作上下文 HWND 已验证"
        expected_pid = int(locked.get("process_id", 0) or 0)
        if expected_pid and int(getattr(observation, "process_id", 0) or 0) == expected_pid:
            return observation, True, "初始工作上下文进程已验证（HWND 发生合法重建）"
        self._post("event", "隐藏主界面后前台窗口异常变化：先 WAIT 并重新确认，暂不发送任何输入")
        last = observation
        stable_hwnd = current_hwnd; stable_count = 1
        for _ in range(8):
            if not self._wait(0.12) or not self._wait_for_default_desktop(io, announce=False):
                return last, False, "停止请求"
            try:
                last = io.capture(last)
            except Exception:
                continue
            hwnd = int(last.accessibility.hwnd or 0)
            if hwnd == expected_hwnd or (expected_pid and int(getattr(last, "process_id", 0) or 0) == expected_pid):
                return last, True, "等待后恢复到锁定的初始工作上下文"
            if hwnd and hwnd == stable_hwnd:
                stable_count += 1
            else:
                stable_hwnd, stable_count = hwnd, 1
        # 原 HWND 仍存在却未回前台时不能猜测另一个窗口就是用户目标。
        try:
            original_exists = bool(io.user32.IsWindow(expected_hwnd))
        except Exception:
            original_exists = True
        if original_exists:
            return last, False, "初始目标窗口仍存在但未处于前台；为避免误操作已 fail-closed 停止"
        if stable_hwnd and stable_count >= 3:
            return last, True, "原目标窗口已消失；已将连续稳定的新前台窗口重新确认为工作上下文"
        return last, False, "无法重新确认稳定工作上下文"

    def _run(self, settings):
        reason = "已停止"
        logger = None
        io = None
        mode = "task"
        task_restore_posted = False
        accumulator = NStepAccumulator()
        try:
            logger = SessionLogger(self.data_dir)
            observe_only = bool(settings.get("observe_only", False))
            mode = "autonomous" if str(settings.get("mode", "task")).lower() == "autonomous" else "task"
            self.task_exit_policy.begin_task()
            self._set_state(STATE_FREE_ACTIVE if mode == "autonomous" else STATE_TASK_ACTIVE)
            if mode == "task" and not str(settings.get("goal", "")).strip():
                raise ValueError("发送模式必须提供用户任务")
            # AI 活动期间固定本地运行：不存在联网开关、第三方 AI URL、API Key 或网页抓取路径。
            reasoning = ReasoningBackend(self.resource_budget, memory=self.memory)
            self._post("event", "本地离线模式：AI 活动期间本程序不发起网络连接，且禁止调用第三方 AI 服务")
            io = WinIO(self.model.capacities, input_enabled=not observe_only, input_gate_event=self.input_gate_event, input_pause_event=self.input_pause_event, input_gate_lock=self.input_gate_lock, stop_event=self.stop_event, resource_budget=self.resource_budget, generation_value=self.generation_value, expected_generation=self.expected_generation)
            io.wait_escape_release(self.stop_event)
            if not self._wait_for_default_desktop(io):
                reason = "停止请求"
                raise InterruptedError(reason)
            interval = float(settings.get("interval", 0.32))
            self.approved_risk_fingerprint = str(settings.get("approved_risk_fingerprint", ""))
            self.approved_risk_context = str(settings.get("approved_risk_context", ""))
            working = WorkingMemory(self.model.capacities.get("memory_horizon", 16))
            reward_engine = RewardEngine()
            goal = GoalEngine(settings.get("goal", ""), settings.get("success_text", ""), mode=mode)
            observation = io.capture()
            observation, context_ok, context_note = self._validate_initial_context(io, observation, settings.get("initial_context", {}))
            self._post("event", context_note)
            if not context_ok:
                reason = context_note
                raise InterruptedError(reason)
            self.session_domain = SessionCapabilityDomain(self.memory, observation, settings.get("goal", "") if mode == "task" else "")
            self.safety.set_session_domain(self.session_domain)
            self.memory.remember_observation_knowledge(observation)
            goal.attach_knowledge(self.memory.semantic_context(" ".join((goal.requested_goal, goal.success_text)), limit=max(2, int(math.sqrt(self.model.capacities.get("memory_horizon", 16))))))
            goal_label = goal.begin(observation)
            goal.attach_reasoning(reasoning._local_graph(goal))
            self.skills.begin_goal(observation, goal_label)
            state = self._state(observation, goal, working)
            perception_history = deque()
            uncertainty_history = deque()
            progress_history = deque()
            recovery_trace = []
            awake_steps = 0
            awake_started = time.monotonic()
            stagnant = 0
            repeated = 0
            last_fingerprint = ""
            no_progress_replans = 0
            reasoning_failure_streak = 0
            compiler_stalled_count = 0
            last_block_reason = ""
            same_block_reason_count = 0
            self._post("event", "当前目标：" + goal_label)
            self._post("stats", self._stats("清醒：选择参数化动作", goal_label))
            logger.write("start", {
                "clicks": bool(settings.get("clicks")), "keyboard": bool(settings.get("keyboard")),
                "safe_mode": bool(settings.get("safe_mode", True)), "observe_only": observe_only,
                "offline_ai_activity": True, "third_party_ai_services": False, "interval": interval,
                "feature_count": self.model.input_count, "base_feature_count": BASE_FEATURE_COUNT, "action_categories": ACTION_COUNT,
                "goal": goal_label, "explicit_goal": goal.explicit, "mode": mode,
                "reasoning_backend": reasoning.PROTOCOL,
            })
            fast_task_completed = False
            # 待整理经验只能成为 MetaCognitiveSleep 的维护压力；禁止“点击自由 -> 程序硬睡”。
            deferred_maintenance = bool(self.memory.get_metadata("deferred_task_sleep", "")) if mode == "autonomous" else False
            if deferred_maintenance:
                self._post("event", "检测到待整理任务经验：仅提高元认知维护压力，由当前自由模式 AI 自行判断是否睡眠")
            while not self.stop_event.is_set():
                if io.escape_down():
                    io.close_input_gate()
                    reason = "检测到 ESC，AI 已停止"
                    break
                if not self._wait_for_default_desktop(io):
                    reason = "检测到停止请求"; break
                if not bool(getattr(observation, "input_desktop_safe", True)):
                    observation = io.capture(observation); state = self._state(observation, goal, working)
                eligible_skills = self.skills.eligible(observation, settings)
                text_candidates = self.planner.text_candidates(goal, observation)
                allowed = self.planner.allowed(settings, awake_steps, text_candidates, eligible_skills)
                world_uncertainty = self.planner.state_uncertainty(state, observation, allowed)
                uncertainty_history.append(world_uncertainty)
                perception_history.append(1.0 if getattr(observation, "perception_limited", False) else 0.0)
                signal_horizon = max(8, int(self.model.capacities.get("memory_horizon", 16)) * 4)
                while len(uncertainty_history) > signal_horizon: uncertainty_history.popleft()
                while len(perception_history) > signal_horizon: perception_history.popleft()
                sleep_decision = MetaCognitiveSleep.evaluate(
                    self.model, self.memory, working, world_uncertainty, eligible_skills, repeated=repeated,
                    compiler_stalled=bool(getattr(goal, "compiler_stalled", False)), pending_skill=bool(self.skills.pending),
                    awake_steps=awake_steps,
                    awake_seconds=(time.monotonic() - awake_started) if mode == "autonomous" else 0.0,
                    deferred_maintenance=bool(deferred_maintenance),
                )
                self.last_sleep_decision = sleep_decision
                allow_sleep = (
                    mode == "autonomous"
                    and bool(sleep_decision.get("should_sleep"))
                )
                allowed = self.planner.allowed(settings, awake_steps, text_candidates, eligible_skills, allow_sleep=allow_sleep)
                click_evidence = any(
                    record.get("control_type") in INTERACTIVE_CONTROL_TYPES and record.get("enabled") and not record.get("offscreen") and not record.get("password")
                    for record in observation.accessibility.records
                )
                local_visual_evidence = any(
                    getattr(item, "confidence", 0.0) >= 0.45 for item in (getattr(observation, "visual_elements", []) or [])
                )
                if CLICK in allowed and not (click_evidence or local_visual_evidence or bool(goal.target_point) or getattr(observation, "perception_limited", False)):
                    allowed = [kind for kind in allowed if kind != CLICK]
                current_mask = mask_actions(allowed)
                exploration = clamp(0.30 / math.sqrt(1.0 + self.model.training_steps / 3500.0), 0.04, 0.30)
                if self.model.progress_average < 0.03:
                    exploration = min(0.36, exploration + 0.05)
                # 统一成不确定性驱动探索：越不确定越观察，而不是越随机。
                exploration *= clamp(1.0 - world_uncertainty * 0.92, 0.05, 1.0)
                if getattr(observation, "perception_limited", False):
                    # UIA 贫乏时把问题标记为感知瓶颈，不用随机点击把错误经验写成策略失败。
                    exploration = min(exploration, 0.015)
                    if awake_steps % 12 == 0:
                        self._post("event", "感知边界：当前 UIA 信息贫乏；未知状态只允许等待/移动/滚动/更深感知，不生成无证据 CLICK")
                # 睡眠是确定性的元认知滞回决策，不再含随机触发。
                force_sleep = SLEEP in allowed and bool(sleep_decision.get("should_sleep"))
                decision_started = time.perf_counter()
                reasoning_command = None
                reasoning_candidates = []
                if not force_sleep:
                    frame = None
                    if reasoning.enabled and reasoning.needs_refresh(goal, observation, allowed, mode=mode):
                        tier = reasoning.visual_tier(observation)
                        if tier in ("roi", "full"):
                            try: frame = io.capture_reasoning_frame(observation, tier=tier)
                            except Exception as error: self._post("event", "视觉语义帧获取失败，回退 UIA/Double-Q：" + str(error))
                    decision = reasoning.decide(goal, observation, allowed, mode=mode, frame=frame)
                    goal.attach_reasoning(decision.get("graph", {}))
                    if decision.get("visual_elements"):
                        observation.attach_visual_elements(decision.get("visual_elements"))
                        state = self._state(observation, goal, working)
                    reasoning_command = decision.get("command")
                    reasoning_candidates = [command for command in decision.get("candidates", []) if isinstance(command, ActionCommand)]
                    if reasoning_command is not None and not reasoning_candidates:
                        reasoning_candidates = [reasoning_command]
                    if decision.get("error"):
                        reasoning_failure_streak += 1
                        if awake_steps % 8 == 0:
                            self._post("event", "本地任务图暂未给出直接动作，继续使用本地经验层")
                    elif reasoning.enabled:
                        reasoning_failure_streak = 0
                if force_sleep:
                    command = self.planner.plan(SLEEP, [], observation, goal, text_candidates, eligible_skills, False)
                else:
                    command = self.planner.plan_with_lookahead(
                        self.model, state, allowed, observation, goal, text_candidates, eligible_skills,
                        random.random() < exploration, settings=settings, symbolic_candidates=reasoning_candidates,
                    )
                decision_elapsed = time.perf_counter() - decision_started
                self.resource_budget.decision_latency = decision_elapsed
                self.resource_budget.perception_latency = io.last_capture_seconds
                self.last_io_metrics = {
                    "capture_seconds": io.last_capture_seconds, "uia_seconds": io.last_uia_seconds,
                    "cache_hits": io.capture_cache_hits, "full_scans": io.capture_full_scans,
                    "event_cache_hits": io.event_cache_hits, "local_action_scans": io.local_action_scans,
                }
                fingerprint = command.fingerprint()
                repeated = repeated + 1 if fingerprint == last_fingerprint else 0
                last_fingerprint = fingerprint

                if command.kind == SLEEP:
                    self._remember_emitted(accumulator.flush())
                    pre_state = state
                    pre_signature = observation.signature
                    sleep_context = {
                        "reason": "元认知因素：" + ",".join(sleep_decision.get("reasons", [])), "stagnant": stagnant, "repeated": repeated,
                        "perception_limited_ratio": sum(perception_history) / max(1, len(perception_history)),
                        "world_uncertainty": sum(uncertainty_history) / max(1, len(uncertainty_history)),
                        "compiler_unresolved": bool(goal.explicit and not goal.compiled_steps),
                        "sleep_decision": sleep_decision, "decision_latency": decision_elapsed,
                        "perception_latency": io.last_capture_seconds,
                    }
                    result = self._sleep_and_learn(io, logger, goal_label, sleep_context=sleep_context, trigger="metacognitive")
                    if deferred_maintenance and not self.stop_event.is_set():
                        self.memory.delete_metadata("deferred_task_sleep")
                        deferred_maintenance = False
                    if self.stop_event.is_set():
                        reason = "检测到 ESC，AI 已停止"
                        break
                    sleep_reward, learning_gain = self._sleep_reward(
                        awake_steps, stagnant, result["summary"]["experiences"], result["before_loss"], result["after_loss"], result["updates"]
                    )
                    next_observation = io.capture(observation)
                    goal_label = goal.after_sleep(next_observation)
                    if not goal.explicit and goal.generation > 1:
                        self.skills.begin_goal(next_observation, goal_label)
                    components = {
                        "goal_reward": 0.0, "curiosity_reward": 0.0, "efficiency_reward": sleep_reward,
                        "safety_penalty": 0.0, "goal_progress": max(0.0, sleep_reward), "goal_completed": False, "effect": 0.0,
                    }
                    working.update(SLEEP, sleep_reward, components, next_observation.signature, slept=True)
                    working.set_horizon(self.model.capacities.get("memory_horizon", working.horizon))
                    next_state = self._state(next_observation, goal, working)
                    next_skills = self.skills.eligible(next_observation, settings)
                    next_text = self.planner.text_candidates(goal, next_observation)
                    next_allowed = self.planner.allowed(settings, 0, next_text, next_skills)
                    sleep_item = {
                        "state": pre_state, "action": SLEEP, "command": command.payload(),
                        "parameters": command.parameter_targets, "parameter_mask": command.parameter_mask,
                        "reward": sleep_reward, "goal_reward": 0.0, "curiosity_reward": 0.0,
                        "efficiency_reward": sleep_reward, "safety_penalty": 0.0,
                        "next_state": next_state, "current_mask": current_mask, "next_mask": mask_actions(next_allowed), "priority": abs(sleep_reward) + abs(learning_gain) + 0.03,
                        "signature": pre_signature, "next_signature": next_observation.signature, "state_key": getattr(observation, "fuzzy_key", ""),
                        "next_state_key": getattr(next_observation, "fuzzy_key", ""), "n_steps": 1, "goal_text": goal_label,
                    }
                    self.memory.add_experience(sleep_item)
                    self.world_model.observe(sleep_item)
                    self.model.reward_average = self.model.reward_average * 0.985 + sleep_reward * 0.015
                    self.mark_model_dirty()
                    capability_text = "，" + "/".join(result.get("capacity_growth", [])) + "已扩展" if result.get("capacity_growth") else ""
                    self._post("event", "AI 睡醒：训练 {} 次{}，新增技能 {} 个，能力收益 {:+.3f}，基准 {:.3f}→{:.3f}{}{}".format(
                        result["updates"], "（能力测试未通过，已回滚）" if not result.get("training_accepted", True) else "",
                        result["new_skills"], learning_gain, result.get("before_benchmark", 0.5), result.get("after_benchmark", 0.5),
                        "，模型扩容已通过" if result["grew"] else "", capability_text
                    ))
                    logger.write("sleep_choice", {"reward": sleep_reward, "gain": learning_gain, "awake_steps": awake_steps, "stagnant": stagnant,
                                                        "sleep_score": sleep_decision.get("score"), "factors": sleep_decision.get("factors"),
                                                        "wake_score": result.get("wake_decision", {}).get("score")})
                    observation, state = next_observation, next_state
                    awake_steps = stagnant = repeated = 0
                    awake_started = time.monotonic()  # 新一轮清醒周期必须从醒来时重新计时。
                    self._post("stats", self._stats("已醒来：继续参数化行动", goal_label))
                    continue

                pre_state = state
                pre_signature = observation.signature
                compiled_before_index = int(getattr(goal, "compiled_index", 0))
                compiled_before_phase = str(getattr(goal, "compiled_phase", ""))
                compiled_before_step = goal.active_compiled_step() if hasattr(goal, "active_compiled_step") else None
                if compiled_before_phase == "recovery" and command.kind not in (WAIT, SLEEP):
                    recovery_trace.append(command.payload())
                    recovery_trace[:] = recovery_trace[-8:]
                outcome = self._execute_command(io, command, observation, settings, interval)
                outcome["perception_limited"] = bool(getattr(observation, "perception_limited", False))
                if outcome.get("blocked") or outcome.get("invalid"):
                    reasoning.invalidate()
                if not outcome.get("ok"):
                    reason = "检测到 ESC，AI 已停止" if self.stop_event.is_set() else "动作执行中止"
                    break
                if outcome.get("approval_required"):
                    approval_exit = self.task_exit_policy.evaluate(
                        mode=mode, explicit_goal=bool(goal.explicit), goal_completed=False, approval_required=True,
                        blocked=bool(outcome.get("blocked")), blocked_reason=str(outcome.get("blocked_reason", "")),
                        safety_penalty=safe_float(outcome.get("safety_penalty", 0.0)),
                    )
                    io.seal_input_gate()
                    if self.state_machine.state != STATE_STOPPING:
                        self._set_state(STATE_STOPPING)
                    self._post("approval_required", {
                        "fingerprint": outcome.get("approval_fingerprint", ""),
                        "context": outcome.get("approval_context", ""),
                        "label": outcome.get("approval_label", command.label), "reason": outcome.get("blocked_reason", ""),
                    })
                    reason = "高风险动作等待用户确认：" + str(approval_exit.get("reason") or "需要用户批准")
                    break
                if outcome.get("desktop_blocked"):
                    if not self._wait_for_default_desktop(io):
                        reason = "检测到停止请求"; break
                    observation = io.capture(observation); state = self._state(observation, goal, working)
                    self._post("event", "安全桌面恢复后已重新感知；原动作不会自动重放")
                    continue
                if command.kind != WAIT and not self._wait(interval):
                    reason = "检测到 ESC，AI 已停止"
                    break
                if not self._wait_for_default_desktop(io):
                    reason = "检测到停止请求"; break
                next_observation = io.capture(observation, force_deep=bool(command.parameters.get("force_deep_observation")), action_hint=command)
                if command.kind == SKILL and outcome.get("skill"):
                    skill_success = bool(outcome.get("skill_success")) or self.skills.success_matches(outcome["skill"], next_observation)
                    outcome["skill_success"] = skill_success
                    self.memory.record_skill_result(outcome["skill_id"], skill_success, outcome.get("duration", 0.0))
                if reasoning.enabled and reasoning.allow_screenshots and getattr(next_observation, "perception_limited", False) and not self.stop_event.is_set():
                    try:
                        supplement_tier = reasoning.visual_tier(next_observation)
                        if supplement_tier == "none":
                            if reasoning._sensitive_observation(next_observation):
                                # Credential/UAC/支付/密码窗口即使是纯本地视觉也不采集处理。
                                raise PermissionError("当前敏感窗口禁止视觉补充处理")
                            supplement_tier = "roi"
                        visual_frame = io.capture_reasoning_frame(next_observation, tier=supplement_tier)
                        visual_decision = reasoning.decide(goal, next_observation, [WAIT], mode=mode, frame=visual_frame, force=True)
                        next_observation.attach_visual_elements(visual_decision.get("visual_elements", []))
                        goal.attach_reasoning(visual_decision.get("graph", {}))
                        reasoning.invalidate()
                    except Exception as error:
                        self._post("event", "视觉补充感知失败，保持 UIA fail-safe：" + str(error)[:180])
                goal_result = goal.evaluate(command, observation, next_observation, outcome)
                if compiled_before_step is not None and int(getattr(goal, "compiled_index", 0)) > compiled_before_index and recovery_trace:
                    operation = str(compiled_before_step.get("operation") or compiled_before_step.get("action", "unknown"))
                    app_key = str(getattr(next_observation, "process_name", "") or getattr(observation, "process_name", "") or "unknown")
                    precondition = {"window_class": observation.accessibility.window_class, "process_name": getattr(observation, "process_name", ""), "operation": operation}
                    self.memory.remember_strategy(operation, app_key, precondition, list(recovery_trace), subgoals=compiled_before_step.get("recovery", []))
                    recovery_trace.clear()
                if goal_result.get("candidate") and not self.stop_event.is_set():
                    candidate_observation = next_observation
                    verification = next_observation
                    stable = False
                    for delay in (0.18, 0.22, 0.28):
                        if not self._wait(delay):
                            break
                        verification = io.capture(verification)
                        stable = goal.verify_stable(candidate_observation, verification)
                        if not stable and goal.completion_evidence == 0:
                            break
                    next_observation = verification
                    if stable:
                        goal_result["completed"] = True
                        goal_result["reward"] = 1.0
                        goal_result["progress"] = 1.0
                    else:
                        goal_result["reward"] = min(float(goal_result.get("reward", 0.0)), 0.18)
                        goal_result["progress"] = min(float(goal_result.get("progress", 0.0)), 0.18)
                visits_before = self.memory.state_visits(next_observation.signature)
                reward, components = reward_engine.evaluate(
                    command, observation, next_observation, repeated, stagnant, goal_result,
                    visits_before, outcome, outcome.get("duration", 0.0),
                )
                self.model.reward_average = reward if self.model.training_steps == 0 and self.memory.count("episodic_memory") == 0 else self.model.reward_average * 0.985 + reward * 0.015
                self.model.progress_average = self.model.progress_average * 0.985 + components["goal_progress"] * 0.015
                self.model.safety_average = self.model.safety_average * 0.985 + components["safety_penalty"] * 0.015
                self.mark_model_dirty()
                working.update(command.kind, reward, components, next_observation.signature)
                next_state = self._state(next_observation, goal, working)
                awake_steps += 1
                if components["goal_progress"] > 0.08:
                    stagnant = max(0, stagnant - 6)
                elif not components["structured_change"] and components["effect"] < 0.005:
                    stagnant += 1
                else:
                    stagnant = max(0, stagnant - 1)

                compiler_stalled_count = compiler_stalled_count + 1 if bool(getattr(goal, "compiler_stalled", False)) else max(0, compiler_stalled_count - 1)
                meaningful_progress = bool(components["goal_progress"] > 0.045 or components["structured_change"] or components["effect"] >= 0.010)
                progress_signal = clamp(
                    safe_float(components.get("goal_progress", 0.0)) * 0.62
                    + (0.22 if components.get("structured_change") else 0.0)
                    + min(0.16, safe_float(components.get("effect", 0.0)) * 8.0),
                    0.0, 1.0,
                )
                progress_history.append(progress_signal)
                while len(progress_history) > signal_horizon:
                    progress_history.popleft()
                if meaningful_progress:
                    self.task_exit_policy.observe_progress()
                no_progress_replans = max(0, no_progress_replans - 5) if meaningful_progress else no_progress_replans + 1
                fail_score = (
                    no_progress_replans
                    + min(14, same_block_reason_count * 2)
                    + min(14, reasoning_failure_streak * 2)
                    + min(12, compiler_stalled_count)
                )
                current_block_reason = str(outcome.get("blocked_reason", "") or "")
                projected_same_block = (same_block_reason_count + 1) if (current_block_reason and current_block_reason == last_block_reason) else (1 if current_block_reason else max(0, same_block_reason_count - 1))
                graph_plans = list((getattr(goal, "reasoning_graph", {}) or {}).get("candidate_plans", []) or [])
                beam_alternatives = list(command.parameters.get("beam_alternative_plans", []) or [])
                beam_plan_count = len(beam_alternatives) + (1 if command.parameters.get("beam_plan_actions") else 0)
                alternative_plan_count = max(len(graph_plans), beam_plan_count)
                recent_progress = sum(progress_history) / max(1, len(progress_history))
                expected_next_value = safe_float(command.parameters.get("deliberation_score", reward), reward)
                success_probability = clamp(
                    0.08 + recent_progress * 0.44
                    + min(1.0, safe_float(getattr(goal, "completion_evidence", 0)) / 3.0) * 0.22
                    + (1.0 - world_uncertainty) * 0.14
                    + min(0.12, math.log1p(alternative_plan_count) * 0.05),
                    0.0, 1.0,
                )
                reachable_confidence = clamp(
                    (1.0 - world_uncertainty) * 0.46
                    + min(0.38, math.log1p(alternative_plan_count) * 0.16)
                    + clamp((expected_next_value + 1.0) * 0.5, 0.0, 1.0) * 0.16
                    - (0.26 if getattr(goal, "compiler_stalled", False) else 0.0),
                    0.0, 1.0,
                )
                task_exit_decision = self.task_exit_policy.evaluate(
                    mode=mode, explicit_goal=bool(goal.explicit), goal_completed=bool(components["goal_completed"]),
                    no_progress_replans=no_progress_replans, fail_score=fail_score,
                    compiler_stalled_count=compiler_stalled_count, reasoning_failure_streak=reasoning_failure_streak,
                    repeated_block_count=projected_same_block, blocked=bool(outcome.get("blocked")),
                    blocked_reason=current_block_reason, safety_penalty=safe_float(outcome.get("safety_penalty", components.get("safety_penalty", 0.0))),
                    success_probability=success_probability, reachable_confidence=reachable_confidence,
                    recent_progress=recent_progress, world_uncertainty=world_uncertainty,
                    expected_next_value=expected_next_value, alternative_plan_count=alternative_plan_count,
                )

                if command.kind == TYPE:
                    self.memory.remember_text(command.parameters.get("text", ""), components["goal_progress"] > 0.05 or components["structured_change"])
                self.skills.observe(command, outcome, components, next_observation, outcome.get("duration", 0.0))
                next_skills = self.skills.eligible(next_observation, settings)
                next_text = self.planner.text_candidates(goal, next_observation)
                next_allowed = self.planner.allowed(settings, awake_steps, next_text, next_skills)
                transition = {
                    "state": pre_state, "action": command.kind, "command": command.payload(),
                    "parameters": command.parameter_targets, "parameter_mask": command.parameter_mask,
                    "reward": reward, "goal_reward": components["goal_reward"],
                    "curiosity_reward": components["curiosity_reward"], "efficiency_reward": components["efficiency_reward"],
                    "safety_penalty": components["safety_penalty"], "next_state": next_state,
                    "current_mask": current_mask, "next_mask": mask_actions(next_allowed), "signature": pre_signature,
                    "next_signature": next_observation.signature, "state_key": getattr(observation, "fuzzy_key", ""),
                    "next_state_key": getattr(next_observation, "fuzzy_key", ""), "goal_text": goal_label,
                }
                self._remember_emitted(accumulator.append(transition, terminal=bool(goal.explicit and components["goal_completed"])))
                self.memory.remember_state(
                    next_observation.signature, next_observation.visual_signature, next_state, reward,
                    success=components["goal_completed"], failure=bool((outcome.get("blocked") or outcome.get("invalid") or reward < -0.35) and not outcome.get("perception_limited")),
                )
                if outcome.get("blocked_reason"):
                    current_block_reason = str(outcome["blocked_reason"])
                    same_block_reason_count = same_block_reason_count + 1 if current_block_reason == last_block_reason else 1
                    last_block_reason = current_block_reason
                    self.memory.remember_failure(command, pre_signature, current_block_reason, outcome.get("safety_penalty", 0.5))
                    prefix = "安全策略：" if outcome.get("blocked") else "动作未执行："
                    self._post("event", prefix + current_block_reason)
                else:
                    same_block_reason_count = max(0, same_block_reason_count - 1)
                logger.write("step", {
                    "action": ACTION_NAMES[command.kind], "label": command.label, "reward": round(reward, 5),
                    "goal_reward": round(components["goal_reward"], 5), "curiosity_reward": round(components["curiosity_reward"], 5),
                    "efficiency_reward": round(components["efficiency_reward"], 5), "safety_penalty": round(components["safety_penalty"], 5),
                    "structured_change": components["structured_change"], "effect": round(components["effect"], 5), "stagnant": stagnant,
                    "blocked": bool(outcome.get("blocked")), "blocked_reason": str(outcome.get("blocked_reason", "")),
                    "external_ai_delegation": dict(outcome.get("external_ai_delegation") or {}),
                })
                observation, state = next_observation, next_state
                if awake_steps % 5 == 0:
                    self.memory.remember_observation_knowledge(observation)

                if task_exit_decision.get("should_exit"):
                    # 唯一任务退出路径：先永久封住输入，再显式进入 STOPPING；Application 等 worker 完全死亡后恢复 GUI。
                    io.seal_input_gate()
                    if self.state_machine.state != STATE_STOPPING:
                        self._set_state(STATE_STOPPING)
                    exit_reason = str(task_exit_decision.get("reason") or "任务退出")
                    if task_exit_decision.get("completed"):
                        self.task_exit_policy.learn_task_outcome(True, task_exit_decision.get("category", "completed"))
                        self._post("event", "目标已验证完成：" + goal_label)
                        self._remember_emitted(accumulator.flush())
                        deferred_context = {
                            "reason": "上一次显式任务完成后的延迟整理", "stagnant": stagnant, "repeated": repeated,
                            "perception_limited_ratio": sum(perception_history) / max(1, len(perception_history)),
                            "world_uncertainty": sum(uncertainty_history) / max(1, len(uncertainty_history)), "compiler_unresolved": False,
                        }
                        self.memory.set_metadata("deferred_task_sleep", compact_json(deferred_context), commit=True)
                        self._post("stats", self._stats("目标完成：AI已停止活动，正在退出任务模式", goal_label))
                        logger.write("task_exit", {"category": task_exit_decision.get("category"), "reason": exit_reason, "goal": goal_label, "completed": True, "deferred_sleep": True})
                        reason = exit_reason
                        fast_task_completed = True
                    else:
                        self.task_exit_policy.learn_task_outcome(False, task_exit_decision.get("category", ""))
                        detail = "exit_score {:.3f}/{:.3f}；P(success) {:.3f}；alternatives {}；无进展重规划 {}；同类错误 {}；推理后端连续失败 {}；compiler stalled {}".format(
                            safe_float(task_exit_decision.get("exit_score", 0.0)), safe_float(task_exit_decision.get("threshold", 0.0)),
                            safe_float(task_exit_decision.get("success_probability", 0.0)), int(task_exit_decision.get("alternative_plan_count", 0)),
                            no_progress_replans, same_block_reason_count, reasoning_failure_streak, compiler_stalled_count
                        )
                        reason = "任务未完成：" + exit_reason
                        self._post("event", reason + "（" + detail + "）")
                        self._post("stats", self._stats("任务退出：AI已停止活动，正在恢复主界面", goal_label))
                        logger.write("task_exit", {"category": task_exit_decision.get("category"), "reason": exit_reason, "detail": detail, "completed": False, "exit_policy": task_exit_decision})
                    break
                if awake_steps % 5 == 0:
                    self._post("stats", self._stats("清醒：选择参数化动作", goal_label))
                # 持久化只由 dirty 状态和自适应时间节流驱动，避免动作频率改变写盘频率。
                if (
                    self.model_dirty
                    and time.monotonic() - self.last_model_save >= self.adaptive_save_interval
                ):
                    self.save_model(force=False)

            if (
                mode == "task" and io is not None and not self.stop_event.is_set()
                and reason != "高风险动作等待用户确认"
            ):
                # TASK_ACTIVE -> STOPPING；严格禁止 GUI 在 worker commit/consolidate/save 前恢复。
                io.seal_input_gate()
                if self.state_machine.state != STATE_STOPPING:
                    self._set_state(STATE_STOPPING)
            self._remember_emitted(accumulator.flush())
            try:
                if fast_task_completed:
                    self.save_model(force=True)
                else:
                    self.skills.consolidate()
                    self.memory.consolidate()
                    self.save_model(force=True)
            except Exception as save_error:
                reason += "；保存失败：" + str(save_error)
        except InterruptedError as error:
            reason = str(error) or reason
            escaped = bool(self.escape_event is not None and self.escape_event.is_set())
            if escaped:
                # ESC 是 P0 立即停止路径：不训练、不 checkpoint、不 consolidate；只回滚尚未提交的 SQLite 短事务。
                try:
                    self.memory.rollback()
                except Exception:
                    pass
            else:
                # 普通“关闭/停止”仍允许完成轻量持久化。
                try:
                    self._remember_emitted(accumulator.flush())
                    self.save_model(force=True)
                except Exception:
                    pass
        except Exception as error:
            reason = "运行错误：" + str(error)
            try:
                if mode == "task" and io is not None and not self.stop_event.is_set():
                    io.seal_input_gate()
                    if self.state_machine.state != STATE_STOPPING:
                        self._set_state(STATE_STOPPING)
            except Exception:
                pass
            self._record_crash(error)
            try:
                self._remember_emitted(accumulator.flush())
                self.save_model(force=True)
            except Exception:
                pass
        finally:
            escaped = bool(self.escape_event is not None and self.escape_event.is_set())
            if io is not None:
                try:
                    if not escaped:
                        io.release_inputs()
                    io.close()
                except Exception:
                    pass
            if logger is not None:
                if not escaped:
                    logger.write("stop", {"reason": reason})
                logger.close()
        try:
            if self.state_machine.state not in (STATE_STOPPING, STATE_IDLE):
                self._set_state(STATE_STOPPING)
        except Exception:
            pass
        self._post("stopped", reason)


def agent_worker_process(data_dir, settings, stop_event, escape_event, messages, input_gate_event, input_pause_event, input_ready_event, sleep_ui_ready_event, wake_ui_hidden_event, wake_validation_request_event, wake_validation_ready_event, input_gate_lock, generation_value, expected_generation, session_id):
    runtime = None
    try:
        install_runtime_offline_guard()
        # worker 一进入本程序入口即锁死新建/替换进程；后续 AgentRuntime 不存在 powershell/curl/其他 exe 绕行路径。
        lock_runtime_activity()
        # P0：worker 进程可以先创建，但安全进程没有确认存活前不得进入 AgentRuntime，更不得触达 SendInput。
        while not input_ready_event.wait(0.025):
            if stop_event.is_set():
                return
        if stop_event.is_set():
            return
        runtime = AgentRuntime(Path(data_dir), messages, stop_event, escape_event=escape_event, input_gate_event=input_gate_event, input_pause_event=input_pause_event, sleep_ui_ready_event=sleep_ui_ready_event, wake_ui_hidden_event=wake_ui_hidden_event, wake_validation_request_event=wake_validation_request_event, wake_validation_ready_event=wake_validation_ready_event, input_gate_lock=input_gate_lock, generation_value=generation_value, expected_generation=expected_generation, session_id=session_id)
        runtime._run(dict(settings))
    except Exception as error:
        try:
            messages.put(("stopped", "运行错误：" + str(error)))
        except Exception:
            pass
    finally:
        if runtime is not None:
            try:
                escaped = bool(escape_event is not None and escape_event.is_set())
                runtime.memory.close(commit=not escaped)
            except Exception:
                pass


def windows_e2e_selftest_worker(target_x, target_y, expected_hwnd, stop_event, gate_event, gate_lock,
                                generation_value, expected_generation, ready_event, sent_count, sequence_event, result_queue):
    """只用于启动 P0 自检：安全进程就绪前保持 gate 关闭，随后在自建窗口内走真实 SendInput。"""
    io = None
    try:
        install_runtime_offline_guard()
        lock_runtime_activity()
        while not ready_event.wait(0.02):
            if stop_event.is_set():
                result_queue.put((False, "安全链路未就绪即收到停止"))
                return
        native = ctypes.WinDLL("user32", use_last_error=True)
        native.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        native.SendInput.restype = wintypes.UINT

        def counted_send(value):
            result = int(native.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input)))
            if result == 1:
                with sent_count.get_lock():
                    sent_count.value += 1
            return result

        io = WinIO(
            input_enabled=True, input_gate_event=gate_event, input_gate_lock=gate_lock, stop_event=stop_event,
            send_input_adapter=counted_send, generation_value=generation_value, expected_generation=expected_generation,
        )
        if int(io.user32.GetForegroundWindow() or 0) != int(expected_hwnd):
            result_queue.put((False, "测试窗口未保持前台，拒绝发送输入"))
            return
        nx, ny = io.normalize_point((int(target_x), int(target_y)))
        io.execute(ActionCommand(MOVE, {"x": nx, "y": ny}, "自测移动"), stop_event=stop_event, expected_hwnd=expected_hwnd)
        time.sleep(0.035)
        io.execute(ActionCommand(CLICK, {"x": nx, "y": ny, "button": "left", "explicit_visual_target": True}, "自测点击"), stop_event=stop_event, expected_hwnd=expected_hwnd)
        time.sleep(0.035)
        if not io.type_text("e2e-esc", stop_event=stop_event, expected_hwnd=expected_hwnd):
            result_queue.put((False, "测试窗口在输入期间失去前台"))
            return
        # 睡眠 -> 醒来：不发送输入；醒来后继续 MOVE，直到真实 ESC 被独立安全进程捕获。
        time.sleep(0.060)
        sequence_event.set()
        while not stop_event.is_set():
            try:
                io.move(nx, ny)
            except InputGateClosed:
                break
            time.sleep(0.004)
        result_queue.put((True, "移动→点击→输入→睡眠→醒来序列完成"))
    except InputGateClosed:
        try: result_queue.put((True, "ESC 输入闸门关闭后 worker 正常退出"))
        except Exception: pass
    except Exception as error:
        try: result_queue.put((False, str(error)))
        except Exception: pass
    finally:
        if io is not None:
            try: io.close()
            except Exception: pass


def windows_esc_matrix_probe_worker(case_name, stop_event, gate_event, gate_lock, generation_value,
                                    expected_generation, ready_event, phase_event, sent_count, result_queue, temp_dir):
    """ESC 矩阵 worker：真实并发/磁盘阶段 + gate 计数，不向用户桌面发送测试动作。"""
    connection = None
    try:
        install_runtime_offline_guard()
        lock_runtime_activity()
        gate = SharedInputGate(gate_event, gate_lock, stop_event, generation_value=generation_value, expected_generation=expected_generation)
        while not ready_event.wait(0.01):
            if stop_event.is_set():
                return

        def emit():
            def counted():
                with sent_count.get_lock():
                    sent_count.value += 1
                return True
            return gate.run_if_open(counted)

        name = str(case_name)
        if name == "MOVE":
            phase_event.set()
            while not stop_event.is_set():
                try: emit()
                except InputGateClosed: break
                time.sleep(0.001)
        elif name == "MOUSE_DOWN_UP":
            emit()  # mouse-down 等价的正常输入计数
            phase_event.set()
            while not stop_event.is_set(): time.sleep(0.002)
            try: emit()  # mouse-up 若 ESC 后执行，必须被 gate 拒绝
            except InputGateClosed: pass
        elif name == "UNICODE_TYPING":
            emit()  # Unicode key-down
            phase_event.set()
            while not stop_event.is_set(): time.sleep(0.002)
            try: emit()  # Unicode key-up 必须被 gate 拒绝；独立守护负责紧急 release
            except InputGateClosed: pass
        elif name == "MODIFIER_DOWN":
            emit()  # modifier key-down
            phase_event.set()
            while not stop_event.is_set(): time.sleep(0.002)
            try: emit()
            except InputGateClosed: pass
        elif name == "SLEEP_TRAINING":
            phase_event.set()
            value = 0.0
            while not stop_event.is_set():
                for index in range(600):
                    value += math.sin(index * 0.001) * math.cos(value * 0.0001)
        elif name == "SQLITE_COMMIT":
            path = Path(temp_dir) / ("esc_matrix_" + uuid.uuid4().hex + ".sqlite3")
            connection = sqlite3.connect(str(path), timeout=2.0)
            connection.execute("CREATE TABLE IF NOT EXISTS t(id INTEGER PRIMARY KEY, value TEXT)")
            connection.execute("BEGIN")
            connection.executemany("INSERT INTO t(value) VALUES(?)", [("x" * 128,) for _ in range(512)])
            phase_event.set()
            connection.commit()
            while not stop_event.is_set(): time.sleep(0.002)
        elif name == "MODEL_CHECKPOINT":
            model = DoubleQNetwork()
            target = Path(temp_dir) / ("esc_matrix_" + uuid.uuid4().hex + ".bin")
            phase_event.set()
            model.save(target)
            while not stop_event.is_set(): time.sleep(0.002)
        elif name in ("WATCHDOG_CRASH", "GUARDIAN_CRASH", "GUI_WITHDRAW"):
            phase_event.set()
            while not stop_event.is_set():
                try: emit()
                except InputGateClosed: break
                time.sleep(0.002)
        else:
            phase_event.set()
            while not stop_event.is_set(): time.sleep(0.002)
        try:
            emit()
        except InputGateClosed:
            pass
        result_queue.put((True, name))
    except InputGateClosed:
        try: result_queue.put((True, str(case_name) + ": gate closed"))
        except Exception: pass
    except Exception as error:
        try: result_queue.put((False, str(error)))
        except Exception: pass
    finally:
        if connection is not None:
            try:
                if stop_event.is_set(): connection.rollback()
                connection.close()
            except Exception:
                pass


class OfflineSourceAuditor:
    """源码静态审计：第三方依赖采用白名单；同时阻止网络栈、外部模型和进程绕行路径。"""

    ALLOWED_EXTERNAL_PACKAGES = {"numpy"}
    BLOCKED_IMPORTS = {
        "socket", "http", "urllib", "requests", "aiohttp", "httpx", "websockets", "ftplib", "smtplib",
        "imaplib", "poplib", "telnetlib", "asyncssh", "paramiko", "win32inet", "win32api",
    }
    BLOCKED_DLLS = {"winhttp", "wininet", "urlmon", "ws2_32", "websocket"}
    EXTERNAL_MODEL_SUFFIXES = (".gguf", ".onnx", ".safetensors", ".pt", ".pth", ".ckpt", ".tflite")
    API_KEY_TOKENS = ("openai_api_key", "anthropic_api_key", "cohere_api_key", "google_api_key", "gemini_api_key", "api_key=")

    @classmethod
    def is_allowed_import(cls, name):
        root = str(name or "").split(".", 1)[0]
        if not root:
            return True
        stdlib = getattr(sys, "stdlib_module_names", frozenset())
        if root in stdlib:
            return True
        if root in cls.ALLOWED_EXTERNAL_PACKAGES:
            return True
        return False

    @classmethod
    def audit(cls, path):
        source = Path(path).read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        findings = []
        disallowed_external = set()
        external_models = set()
        api_keys = set()
        endpoints = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imported_name = str(alias.name or "").lower()
                    root = imported_name.split(".", 1)[0]
                    if root in cls.BLOCKED_IMPORTS:
                        findings.append("禁止导入联网模块 {}（第 {} 行）".format(alias.name, node.lineno))
                    if not cls.is_allowed_import(imported_name):
                        disallowed_external.add(root)
                        findings.append("第三方依赖不在白名单：{}（第 {} 行）".format(alias.name, node.lineno))
            elif isinstance(node, ast.ImportFrom):
                module = str(node.module or "").lower()
                root = module.split(".", 1)[0]
                if root in cls.BLOCKED_IMPORTS:
                    findings.append("禁止导入联网模块 {}（第 {} 行）".format(module, node.lineno))
                if module and not cls.is_allowed_import(module):
                    disallowed_external.add(root)
                    findings.append("第三方依赖不在白名单：{}（第 {} 行）".format(module, node.lineno))
            elif isinstance(node, ast.Call):
                function_name = ""
                if isinstance(node.func, ast.Attribute):
                    function_name = node.func.attr.lower()
                elif isinstance(node.func, ast.Name):
                    function_name = node.func.id.lower()
                if function_name in ("windll", "oledll", "cdll", "pydll", "loaddll", "loadlibrary") and node.args:
                    value = node.args[0]
                    if isinstance(value, ast.Constant) and isinstance(value.value, str):
                        dll = value.value.lower()
                        if any(blocked in dll for blocked in cls.BLOCKED_DLLS):
                            findings.append("禁止加载联网 DLL {}（第 {} 行）".format(value.value, node.lineno))
                if function_name == "__import__" and node.args and isinstance(node.args[0], ast.Constant):
                    imported_name = str(node.args[0].value).lower()
                    imported_root = imported_name.split(".", 1)[0]
                    if imported_root in cls.BLOCKED_IMPORTS:
                        findings.append("禁止动态导入联网模块 {}（第 {} 行）".format(imported_name, node.lineno))
                    if not cls.is_allowed_import(imported_name):
                        disallowed_external.add(imported_root)
                        findings.append("动态第三方依赖不在白名单：{}（第 {} 行）".format(imported_name, node.lineno))
                if function_name in ("system", "startfile"):
                    if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "os":
                        findings.append("禁止 os.{}（第 {} 行）".format(function_name, node.lineno))
                if function_name in ("run", "popen", "call", "check_call", "check_output"):
                    for keyword in node.keywords:
                        if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                            findings.append("禁止 shell=True 子进程（第 {} 行）".format(node.lineno))
                if function_name in ("createprocessw", "createprocessa", "shellexecutew", "shellexecutea", "shellexecuteexw", "shellexecuteexa", "winexec"):
                    findings.append("禁止源码直接调用 {} 绕过子进程守卫（第 {} 行）".format(function_name, node.lineno))
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                text = node.value.strip()
                lowered = text.lower()
                if lowered not in cls.EXTERNAL_MODEL_SUFFIXES and any(lowered.endswith(suffix) for suffix in cls.EXTERNAL_MODEL_SUFFIXES):
                    external_models.add(text)
                if lowered not in cls.API_KEY_TOKENS and any(token in lowered for token in cls.API_KEY_TOKENS):
                    api_keys.add(text[:120])
                if lowered not in ("http://", "https://", "ws://", "wss://") and lowered.startswith(("http://", "https://", "ws://", "wss://")):
                    endpoints.add(text[:160])
        summary = {
            "disallowed_third_party_packages": len(disallowed_external),
            "external_model_dependencies": len(external_models),
            "api_key_dependencies": len(api_keys),
            "network_inference_endpoints": len(endpoints),
        }
        summary_text = "非白名单第三方包：{}；外部模型文件依赖：{}；API Key 依赖：{}；网络推理端点：{}".format(
            summary["disallowed_third_party_packages"], summary["external_model_dependencies"], summary["api_key_dependencies"], summary["network_inference_endpoints"]
        )
        detail = (
            "源码依赖白名单审计通过：只允许 CPython 标准库 + NumPy；未发现网络模块、外部推理模型、API Key、网络推理端点、ShellExecute 或 shell 绕行；" + summary_text
            if not findings else "；".join(findings[:10])
        )
        return {
            "ok": not findings,
            "findings": findings,
            "dependency_summary": summary,
            "dependency_summary_text": summary_text,
            "allowed_external_packages": sorted(cls.ALLOWED_EXTERNAL_PACKAGES),
            "detail": detail,
        }



class GoalCompilerRegressionSuite:
    """GoalCompiler 的 60 项语法/控制流/安全回归；不代表真实 GUI 任务完成能力。"""

    @classmethod
    def cases(cls):
        cases = [
            {"text":"把桌面 test.txt 重命名为 done.txt", "types":{"ObjectRef","Assert"}, "ops":{"Locate","EnterText","Verify"}, "params":{"old_name":"test.txt","new_name":"done.txt"}},
            {"text":"在 Excel 中计算 A1:A10 的总和", "types":{"Assert"}, "ops":{"SwitchApplication","EnterText","Verify"}, "params":{"formula":"=SUM(A1:A10)"}},
            {"text":"给张三发送一封邮件，内容为“会议改到3点”", "types":{"ObjectRef","Assert"}, "ops":{"EnterText","Activate","Verify"}, "params":{"recipient":"张三","content":"会议改到3点"}, "minimum_nodes":8},
            {"text":"关闭当前窗口", "types":{"Assert"}, "ops":{"PressKey","Verify"}, "params":{"verifier":"window_closed"}},
            {"text":"打开浏览器", "types":{"Sequence","Assert"}, "ops":{"Observe","SwitchApplication","Verify"}},
            {"text":"点击设置按钮", "types":{"Sequence","ObjectRef","Assert"}, "ops":{"Locate","Activate","Verify"}},
            {"text":"输入“季度报告”", "types":{"Sequence","Assert"}, "ops":{"Focus","EnterText","Verify"}},
            {"text":"搜索本地文档", "types":{"Sequence","ObjectRef","Assert"}, "ops":{"Observe","Locate","Verify"}},
            {"text":"确保页面显示操作完成", "types":{"Assert"}, "ops":{"Verify"}},
            {"text":"设置账号为备用账号", "types":{"Variable"}, "ops":{"SetVariable"}},
        ]
        condition_templates = [
            "如果页面显示{condition}，就点击{yes}，否则点击{no}",
            "若窗口出现{condition}，则返回，否则继续",
            "if the page shows {condition} then click {yes} else click {no}",
        ]
        conditions = [("登录失败","重试","取消"), ("网络错误","刷新","返回"), ("保存成功","关闭","继续"), ("权限不足","返回","下一步")]
        for index, (condition, yes, no) in enumerate(conditions * 3):
            template = condition_templates[index % len(condition_templates)]
            cases.append({"text":template.format(condition=condition, yes=yes, no=no), "types":{"If","Else"}, "ops":{"Observe","Activate"}})
        while_conditions = ["页面仍显示加载中", "进度条没有完成", "窗口显示正在处理", "结果尚未出现"]
        for condition in while_conditions:
            cases.append({"text":"当{}时，等待并刷新".format(condition), "types":{"While"}, "ops":{"Observe","LoopEnd"}})
        for condition in ("页面显示完成", "文件出现", "窗口关闭", "状态变为就绪"):
            cases.append({"text":"重复刷新，直到{}".format(condition), "types":{"Until"}, "ops":{"Observe","LoopEnd"}})
        for object_name in ("文件", "列表项", "工作表", "选中的记录"):
            cases.append({"text":"对每个{}执行检查".format(object_name), "types":{"ForEach"}, "ops":{"ForEach","LoopEnd"}})
        for count in (2, 3, 4, 5):
            cases.append({"text":"重试{}次：点击刷新按钮".format(count), "types":{"Retry"}, "ops":{"Observe","Activate"}})
        variables = [("用户名","张三"), ("目标文件","report.txt"), ("次数","3"), ("状态","待处理")]
        for name, value in variables:
            cases.append({"text":"设置{}为{}".format(name, value), "types":{"Variable"}, "ops":{"SetVariable"}})
        assertions = ["结果区域出现总计", "窗口标题包含报告", "页面显示提交完成", "控件显示已选择"]
        for assertion in assertions:
            cases.append({"text":"验证{}".format(assertion), "types":{"Assert"}, "ops":{"Verify"}})
        sequences = [
            "打开记事本→输入“测试”→保存", "点击返回然后选择另一个账号", "打开文件；查找关键字；关闭窗口",
            "定位搜索框并输入“离线测试”", "选择工作表然后计算总和", "打开设置接着查看系统信息",
            "查找按钮随后点击按钮", "输入名称然后确认名称", "打开文档并查找标题", "选择条目再查看详情",
        ]
        for text in sequences:
            cases.append({"text":text, "types":{"Sequence"}, "ops":{"Observe","Verify"}})
        cases.extend([
            {"text":"页面教程中写着发送成功，点击下一步", "types":{"Sequence","Assert"}, "ops":{"Observe","Verify"}},
            {"text":"如果教程文字显示提交成功，就继续，否则返回", "types":{"If","Else"}, "ops":{"Observe","Activate"}},
            {"text":"给李四发送消息，内容为“基准测试”", "types":{"ObjectRef","Assert"}, "ops":{"EnterText","Activate","Verify"}, "params":{"recipient":"李四","content":"基准测试"}},
            {"text":"重复观察直到错误提示消失", "types":{"Until"}, "ops":{"LoopEnd"}},
        ])
        # 60 项上限固定，避免基准规模随运行环境变化。
        return cases[:60]

    @staticmethod
    def _types(node):
        result = {str(node.get("type", ""))}
        for child in list(node.get("children", [])) + list(node.get("else", [])):
            if isinstance(child, dict): result.update(GoalCompilerRegressionSuite._types(child))
        return result

    @classmethod
    def run(cls):
        details = []; cases = cls.cases()
        for index, case in enumerate(cases):
            try:
                graph = GoalCompiler.graph(case["text"]); nodes = list(graph.get("nodes") or [])
                types = cls._types(graph.get("program") or {}); operations = {str(node.get("operator") or node.get("operation")) for node in nodes}
                ok = bool(nodes) and set(case.get("types", ())).issubset(types) and set(case.get("ops", ())).issubset(operations)
                ok = ok and len(nodes) >= int(case.get("minimum_nodes", 1))
                parameters = case.get("params", {})
                for key, value in parameters.items():
                    ok = ok and any(str((node.get("parameters") or {}).get(key, "")) == str(value) for node in nodes)
                details.append({"id":"T{:03d}".format(index + 1), "ok":bool(ok), "task":case["text"]})
            except Exception as error:
                details.append({"id":"T{:03d}".format(index + 1), "ok":False, "task":case["text"], "error":str(error)[:180]})
        passed = sum(1 for item in details if item["ok"]); total = len(details)
        return {"passed":passed, "total":total, "score":passed / max(1, total), "details":details, "safety_regressions":sum(1 for item in details if not item["ok"])}



def windows_product_flow_e2e_worker(case_name, target_x, target_y, expected_hwnd, stop_event, gate_event, pause_event,
                                    gate_lock, generation_value, expected_generation, ready_event, phase_a_event,
                                    phase_b_event, sleep_ui_ready_event, wake_request_event, wake_ui_hidden_event, wake_ready_event, sent_count, result_queue):
    """真实产品流程 E2E worker：使用正式 WinIO/SharedInputGate/MetaCognitiveSleep/SessionStateMachine。"""
    io = None
    try:
        install_runtime_offline_guard()
        lock_runtime_activity()
        while not ready_event.wait(0.02):
            if stop_event.is_set():
                return
        native = ctypes.WinDLL("user32", use_last_error=True)
        native.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        native.SendInput.restype = wintypes.UINT

        def counted_send(value):
            result = int(native.SendInput(1, ctypes.byref(value), ctypes.sizeof(Input)))
            if result == 1:
                with sent_count.get_lock():
                    sent_count.value += 1
            return result

        io = WinIO(
            input_enabled=True, input_gate_event=gate_event, input_gate_lock=gate_lock, stop_event=stop_event,
            pause_event=pause_event, send_input_adapter=counted_send,
            generation_value=generation_value, expected_generation=expected_generation,
        )
        if int(io.user32.GetForegroundWindow() or 0) != int(expected_hwnd):
            raise RuntimeError("产品 E2E 测试窗口未保持前台")
        nx, ny = io.normalize_point((int(target_x), int(target_y)))
        name = str(case_name)
        sm = SessionStateMachine()

        if name == "TASK_FLOW":
            sm.transition(STATE_TASK_ACTIVE)
            io.execute(ActionCommand(MOVE, {"x": nx, "y": ny}, "任务 E2E 移动"), stop_event=stop_event, expected_hwnd=expected_hwnd)
            io.execute(ActionCommand(CLICK, {"x": nx, "y": ny, "button": "left", "explicit_visual_target": True}, "任务 E2E 点击"), stop_event=stop_event, expected_hwnd=expected_hwnd)
            if not io.type_text("task-e2e", stop_event=stop_event, expected_hwnd=expected_hwnd):
                raise RuntimeError("任务 E2E 输入失败")
            io.key(0x0D, expected_hwnd=expected_hwnd)  # 真实 Enter/发送
            phase_a_event.set()
            io.seal_input_gate()  # 正式任务完成语义：永久关闭 gate + generation=0，但不伪造 ESC。
            sm.transition(STATE_STOPPING); sm.transition(STATE_IDLE)
            result_queue.put((True, {"case": name, "state": sm.state, "sleep": False}))
            return

        if name == "FREE_FLOW":
            sm.transition(STATE_FREE_ACTIVE)
            io.execute(ActionCommand(MOVE, {"x": nx, "y": ny}, "自由 E2E 醒前移动"), stop_event=stop_event, expected_hwnd=expected_hwnd)
            io.execute(ActionCommand(CLICK, {"x": nx, "y": ny, "button": "left", "explicit_visual_target": True}, "自由 E2E 醒前点击"), stop_event=stop_event, expected_hwnd=expected_hwnd)
            if not io.type_text("free-before|", stop_event=stop_event, expected_hwnd=expected_hwnd):
                raise RuntimeError("自由 E2E 醒前输入失败")

            class _Budget:
                @staticmethod
                def memory_limits(): return {"episodic_memory": 128}
            class _Memory:
                resource_budget = _Budget()
                @staticmethod
                def pending_experience_count(): return 120
                @staticmethod
                def fragmentation_score(): return 0.92
            class _Model:
                loss_average = 1.15
                training_steps = 61
            class _Working:
                horizon = 24
                rewards = deque([-0.35] * 24, maxlen=24)
                safeties = deque([0.30] * 24, maxlen=24)
                steps_since_goal = 70

            sleep_decision = MetaCognitiveSleep.evaluate(
                _Model(), _Memory(), _Working(), 0.92, [], repeated=5,
                compiler_stalled=False, pending_skill=True, awake_steps=220, awake_seconds=240.0,
                deferred_maintenance=True,
            )
            if not sleep_decision.get("policy_wants_sleep") or not sleep_decision.get("should_sleep"):
                raise RuntimeError("SleepEntryPolicy 未基于高维护压力自主决定入睡：" + compact_json(sleep_decision))
            io.pause_normal_input()
            sm.transition(STATE_FREE_SLEEP_PREPARE)
            phase_a_event.set()
            while not stop_event.is_set() and not sleep_ui_ready_event.wait(0.02):
                pass
            if stop_event.is_set() or not sleep_ui_ready_event.is_set():
                raise RuntimeError("FREE_SLEEP_PREPARE GUI 显示握手未通过")
            sm.transition(STATE_SLEEPING)
            with sent_count.get_lock():
                frozen = int(sent_count.value)
            blocked = False
            try:
                io.move(nx, ny, expected_hwnd=expected_hwnd)
            except InputGateClosed:
                blocked = True
            with sent_count.get_lock():
                after_block = int(sent_count.value)
            if not blocked or after_block != frozen or not pause_event.is_set() or stop_event.is_set() or int(generation_value.value) != int(expected_generation):
                raise RuntimeError("SLEEPING pause gate 未阻止 SendInput 或错误作废会话")

            wake_decision = MetaCognitiveSleep.after_sleep(
                sleep_decision, 1.15, 0.01, True, sleep_elapsed=1.0, resource_deadline_reached=False,
                effects={
                    "pending_before": 120, "pending_after": 0, "pending_capacity": 128,
                    "fragmentation_after": 0.03, "skill_conflict_after": 0.0,
                    "world_uncertainty_after": 0.04, "repeated_failure_after": 0.0,
                    "goal_stagnation_after": 0.02, "training_gain_per_second": 0.00001,
                    "memory_gain": 0.35, "new_skill_count": 1,
                },
            )
            if not wake_decision.get("wake_ready"):
                raise RuntimeError("SleepWakePolicy 未根据真实睡眠收益决定醒来：" + compact_json(wake_decision))
            sm.transition(STATE_FREE_WAKE_PREPARE)
            wake_request_event.set()
            while not stop_event.is_set() and not wake_ui_hidden_event.wait(0.02):
                pass
            if stop_event.is_set() or not wake_ui_hidden_event.is_set():
                raise RuntimeError("FREE_WAKE_PREPARE GUI 隐藏握手未通过")
            while not stop_event.is_set() and not wake_ready_event.wait(0.02):
                pass
            if stop_event.is_set() or not wake_ready_event.is_set():
                raise RuntimeError("P0 醒前复验未通过")
            io.resume_normal_input()
            sm.transition(STATE_FREE_ACTIVE)
            if pause_event.is_set():
                raise RuntimeError("醒前复验通过后 pause gate 未恢复")
            io.move(nx, ny, expected_hwnd=expected_hwnd)
            if not io.type_text("free-after", stop_event=stop_event, expected_hwnd=expected_hwnd):
                raise RuntimeError("自由 E2E 醒后输入失败")
            phase_b_event.set()
            while not stop_event.is_set():
                time.sleep(0.005)
            sm.force_stopping(); sm.transition(STATE_IDLE)
            result_queue.put((True, {"case": name, "state": sm.state, "sleep": True, "entry": sleep_decision, "wake": wake_decision}))
            return

        if name in ("ESC_TASK", "ESC_FREE", "ESC_SLEEP"):
            if name == "ESC_TASK":
                sm.transition(STATE_TASK_ACTIVE)
                io.move(nx, ny, expected_hwnd=expected_hwnd)
            else:
                sm.transition(STATE_FREE_ACTIVE)
                io.move(nx, ny, expected_hwnd=expected_hwnd)
                if name == "ESC_SLEEP":
                    io.pause_normal_input(); sm.transition(STATE_FREE_SLEEP_PREPARE); phase_a_event.set()
                    while not stop_event.is_set() and not sleep_ui_ready_event.wait(0.02):
                        pass
                    if not stop_event.is_set():
                        sm.transition(STATE_SLEEPING)
            if name != "ESC_SLEEP":
                phase_a_event.set()
            while not stop_event.is_set():
                if name != "ESC_SLEEP":
                    try: io.move(nx, ny, expected_hwnd=expected_hwnd)
                    except InputGateClosed: break
                time.sleep(0.003)
            sm.force_stopping(); sm.transition(STATE_IDLE)
            result_queue.put((True, {"case": name, "state": sm.state}))
            return
        raise RuntimeError("未知产品 E2E case：" + name)
    except InputGateClosed:
        try: result_queue.put((True, {"case": str(case_name), "gate_closed": True}))
        except Exception: pass
    except Exception as error:
        try: result_queue.put((False, str(error)))
        except Exception: pass
    finally:
        if io is not None:
            try: io.close()
            except Exception: pass


class WindowsProductFlowE2E:
    """P0：真实 Tk + worker + SendInput + sleep pause gate + wake P0 gate + ESC 三状态产品流程验收。"""

    CASES = ("TASK_FLOW", "FREE_FLOW", "ESC_TASK", "ESC_FREE", "ESC_SLEEP")

    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)

    @staticmethod
    def _inject_escape(user32):
        down = Input(); down.type = WinIO.INPUT_KEYBOARD; down.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, 0, 0, 0)
        up = Input(); up.type = WinIO.INPUT_KEYBOARD; up.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, WinIO.KEYEVENTF_KEYUP, 0, 0)
        if int(user32.SendInput(1, ctypes.byref(down), ctypes.sizeof(Input))) != 1:
            raise RuntimeError("产品 E2E 无法注入 ESC keydown")
        time.sleep(0.018); user32.SendInput(1, ctypes.byref(up), ctypes.sizeof(Input))

    def _run_case(self, case_name):
        root = tk._default_root
        if root is None:
            raise RuntimeError("Tk root 不存在")
        context = multiprocessing.get_context("spawn")
        target = controller = None
        process = watchdog = guardian = job = None
        original_root_state = str(root.state())
        try:
            token = uuid.uuid4().hex[:8]
            controller = tk.Toplevel(root)
            controller.title("LocalAI ProductFlow E2E " + case_name + " " + token)
            controller.geometry("360x120+40+40")
            goal = tk.Entry(controller); goal.pack(fill="x", padx=12, pady=(10, 4)); goal.insert(0, "真实产品流程 " + case_name)
            clicked = {"value": False}
            button = tk.Button(controller, text="发送" if case_name == "TASK_FLOW" else "自由", command=lambda: clicked.__setitem__("value", True))
            button.pack(pady=4)

            target = tk.Toplevel(root)
            target.title("LocalAI ProductFlow Target " + case_name + " " + token)
            target.geometry("520x170+140+140")
            entry = tk.Entry(target, font=("Consolas", 12)); entry.pack(fill="x", padx=24, pady=48, ipady=8)
            send_seen = {"value": False}
            entry.bind("<Return>", lambda _event: send_seen.__setitem__("value", True))
            target.attributes("-topmost", True)
            root.update(); target.deiconify(); target.lift(); target.focus_force(); entry.focus_force(); root.update()

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.SetForegroundWindow.argtypes = [wintypes.HWND]; user32.SetForegroundWindow.restype = wintypes.BOOL
            user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]; user32.GetAncestor.restype = wintypes.HWND
            user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]; user32.SendInput.restype = wintypes.UINT
            expected_hwnd = int(user32.GetAncestor(int(target.winfo_id()), 2) or target.winfo_id())
            main_hwnd = int(user32.GetAncestor(int(root.winfo_id()), 2) or root.winfo_id())
            user32.SetForegroundWindow(expected_hwnd); root.update(); time.sleep(0.035); root.update()
            if int(user32.GetForegroundWindow() or 0) != expected_hwnd:
                raise RuntimeError("无法锁定产品 E2E 自建目标窗口为前台")
            x = int(entry.winfo_rootx() + entry.winfo_width() // 2); y = int(entry.winfo_rooty() + entry.winfo_height() // 2)

            stop_event = context.Event(); escape_event = context.Event(); gate_event = context.Event(); gate_event.set()
            pause_event = context.Event(); gate_lock = context.Lock(); generation = context.Value(ctypes.c_ulonglong, 0, lock=False)
            expected_generation = 0
            while expected_generation == 0: expected_generation = secrets.randbits(31) + 1
            generation.value = expected_generation
            ready_event = context.Event(); phase_a = context.Event(); phase_b = context.Event()
            sleep_ui_ready = context.Event(); wake_request = context.Event(); wake_ui_hidden = context.Event(); wake_ready = context.Event()
            sent_count = context.Value(ctypes.c_ulonglong, 0); result_queue = context.Queue()

            watchdog = EscapeWatchdog(context, stop_event, escape_event, release_enabled=False, input_gate_event=gate_event,
                                      input_gate_lock=gate_lock, generation_value=generation, expected_generation=expected_generation)
            watchdog.start(); time.sleep(0.03)
            if not watchdog.is_alive(require_process=True): raise RuntimeError("产品 E2E watchdog 未存活")
            process = context.Process(target=windows_product_flow_e2e_worker,
                args=(case_name, x, y, expected_hwnd, stop_event, gate_event, pause_event, gate_lock, generation,
                      expected_generation, ready_event, phase_a, phase_b, sleep_ui_ready, wake_request, wake_ui_hidden, wake_ready, sent_count, result_queue),
                name="LocalAIProductE2E-" + case_name, daemon=True)
            process.start(); job = WorkerProcessJob(); ok, detail = job.assign(process.pid)
            if not ok: raise RuntimeError("产品 E2E Job Object 失败：" + str(detail))
            guardian = MinimalEscapeGuardian(stop_event, escape_event, gate_event, gate_lock, generation, expected_generation)
            if not guardian.start(process.pid, main_hwnd): raise RuntimeError("产品 E2E guardian 启动失败")
            time.sleep(0.03)
            if not guardian.is_alive() or not watchdog.is_alive(require_process=True): raise RuntimeError("产品 E2E 安全进程放行前失活")

            # 模拟真实按钮→输入→发送/自由：worker 已就绪、安全链已就绪后才允许 root.withdraw 和 gate open。
            button.invoke(); root.update()
            if not clicked["value"] or not goal.get().strip(): raise RuntimeError("真实 Tk 按钮/输入链未触发")
            root.withdraw(); root.update()
            if str(root.state()) != "withdrawn": raise RuntimeError("root.withdraw 未生效")
            user32.SetForegroundWindow(expected_hwnd); root.update(); time.sleep(0.025)
            if int(user32.GetForegroundWindow() or 0) != expected_hwnd:
                raise RuntimeError("root.withdraw 后自建目标窗口未保持前台")
            lock_runtime_activity()
            with gate_lock:
                if stop_event.is_set() or int(generation.value) != expected_generation: raise RuntimeError("产品 E2E 放行前 generation 异常")
                gate_event.clear()
            ready_event.set()

            deadline = time.monotonic() + 3.0
            while time.monotonic() < deadline and process.is_alive() and not phase_a.is_set():
                root.update(); time.sleep(0.005)
            if not phase_a.is_set(): raise RuntimeError("产品 E2E 未到达第一阶段")

            if case_name == "TASK_FLOW":
                deadline = time.monotonic() + 1.0
                while time.monotonic() < deadline and process.is_alive(): root.update(); time.sleep(0.005)
                if process.is_alive(): raise RuntimeError("任务完成后 worker 未退出")
                root.deiconify(); root.update()
                ok = bool("task-e2e" in entry.get() and send_seen["value"] and gate_event.is_set() and int(generation.value) == 0 and str(root.state()) != "withdrawn")
                detail = "Tk任务按钮/输入/发送；真实SendInput；worker dead={} gate={} generation={} root={}".format(not process.is_alive(), gate_event.is_set(), int(generation.value), root.state())
            elif case_name == "FREE_FLOW":
                with sent_count.get_lock(): sleep_count = int(sent_count.value)
                if not pause_event.is_set(): raise RuntimeError("自由流程进入 FREE_SLEEP_PREPARE 时 pause gate 未关闭")
                # GUI 握手 1：FREE_SLEEP_PREPARE 时恢复主界面，真实可见后才允许 worker 进入 SLEEPING。
                root.deiconify(); root.lift(); root.update()
                if str(root.state()) == "withdrawn": raise RuntimeError("FREE_SLEEP_PREPARE 主界面未恢复")
                sleep_ui_ready.set()
                # 等 AI 自主决定醒来并进入 FREE_WAKE_PREPARE。
                deadline = time.monotonic() + 1.5
                while time.monotonic() < deadline and not wake_request.is_set(): root.update(); time.sleep(0.004)
                if not wake_request.is_set(): raise RuntimeError("worker 未进入 FREE_WAKE_PREPARE")
                # GUI 握手 2：先显示“醒来”语义（此处由状态事件代表），再隐藏 root 并确认。
                root.withdraw(); root.update()
                if str(root.state()) != "withdrawn": raise RuntimeError("FREE_WAKE_PREPARE 主界面未隐藏")
                user32.SetForegroundWindow(expected_hwnd); root.update(); time.sleep(0.02)
                wake_ui_hidden.set()
                # 隐藏确认后才做真实 P0 醒前复验：watchdog + guardian + generation + Default Desktop。
                probe = WinIO(input_enabled=False)
                try: desktop_safe, desktop_name = probe.input_desktop_status(force=True)
                finally: probe.close()
                p0_ok = bool(watchdog.is_alive(require_process=True) and guardian.is_alive() and int(generation.value) == expected_generation and desktop_safe)
                if not p0_ok: raise RuntimeError("醒前 P0 复验失败 desktop=" + str(desktop_name))
                wake_ready.set()
                deadline = time.monotonic() + 2.0
                while time.monotonic() < deadline and process.is_alive() and not phase_b.is_set(): root.update(); time.sleep(0.005)
                if not phase_b.is_set() or pause_event.is_set(): raise RuntimeError("FREE_ACTIVE 醒后恢复失败")
                with sent_count.get_lock(): after_wake_count = int(sent_count.value)
                if after_wake_count <= sleep_count: raise RuntimeError("醒后未继续真实 SendInput")
                SharedInputGate(gate_event, gate_lock, stop_event, pause_event=pause_event, generation_value=generation, expected_generation=expected_generation).close()
                process.join(0.8)
                if process.is_alive(): process.terminate(); process.join(0.3)
                root.deiconify(); root.update()
                ok = bool("free-before|" in entry.get() and "free-after" in entry.get() and not process.is_alive() and gate_event.is_set() and int(generation.value) == 0 and str(root.state()) != "withdrawn")
                detail = "FREE真实动作→FREE_SLEEP_PREPARE→GUI显示确认→SLEEPING SendInput=0→SleepWakePolicy→FREE_WAKE_PREPARE→GUI隐藏确认→P0醒前复验→FREE_ACTIVE→真实动作"
            else:
                if case_name == "ESC_SLEEP":
                    if not pause_event.is_set(): raise RuntimeError("ESC@SLEEPING 前未进入 pause gate")
                    root.deiconify(); root.lift(); root.update()
                    if str(root.state()) == "withdrawn": raise RuntimeError("ESC@SLEEPING 前主界面未恢复")
                    sleep_ui_ready.set(); root.update(); time.sleep(0.04)
                with sent_count.get_lock(): before_esc = int(sent_count.value)
                self._inject_escape(user32)
                frozen = None; deadline = time.monotonic() + 1.4
                while time.monotonic() < deadline:
                    root.update()
                    if frozen is None and gate_event.is_set():
                        with sent_count.get_lock(): frozen = int(sent_count.value)
                    if gate_event.is_set() and int(generation.value) == 0 and not process.is_alive():
                        # 模拟正式 Application._finish_stop_restore：只有主进程在最终不变量满足后恢复 GUI。
                        root.deiconify(); root.update()
                        break
                    time.sleep(0.004)
                if process.is_alive(): process.terminate(); process.join(0.3)
                with sent_count.get_lock(): after_esc = int(sent_count.value)
                if frozen is None: frozen = after_esc
                ok = bool(escape_event.is_set() and stop_event.is_set() and gate_event.is_set() and int(generation.value) == 0 and not process.is_alive() and str(root.state()) != "withdrawn" and after_esc == frozen)
                detail = "真实ESC@{}；ESC前SendInput={}；关闸后增量=0；worker dead；generation=0；Application 所有者恢复 root".format(case_name.replace("ESC_", ""), before_esc)

            try:
                worker_ok, worker_detail = result_queue.get(timeout=0.15)
                ok = bool(ok and worker_ok)
                if not worker_ok: detail += "；worker=" + str(worker_detail)
            except Exception:
                if case_name in ("TASK_FLOW", "FREE_FLOW"):
                    ok = False; detail += "；worker result 缺失"
            return {"name": case_name, "ok": bool(ok), "detail": detail}
        finally:
            try:
                if process is not None and process.is_alive(): process.terminate(); process.join(0.2)
            except Exception: pass
            try:
                if watchdog is not None: watchdog.stop()
            except Exception: pass
            try:
                if guardian is not None: guardian.stop()
            except Exception: pass
            try:
                if job is not None: job.close()
            except Exception: pass
            unlock_runtime_activity()
            try:
                if str(root.state()) == "withdrawn": root.deiconify()
                if original_root_state == "withdrawn": root.withdraw()
                root.update()
            except Exception: pass
            for window in (target, controller):
                if window is not None:
                    try: window.destroy()
                    except Exception: pass
            try: root.update()
            except Exception: pass

    def run(self):
        if os.name != "nt" or not is_windows_11_x64():
            return {"ok": False, "passed": 0, "total": len(self.CASES), "details": [{"name": name, "ok": False, "detail": "非 Windows 11 x64"} for name in self.CASES]}
        if not _RUNTIME_OFFLINE_GUARD_INSTALLED:
            return {"ok": False, "passed": 0, "total": len(self.CASES), "details": [{"name": name, "ok": False, "detail": "runtime offline guard 未安装"} for name in self.CASES]}
        details = []
        for name in self.CASES:
            try: details.append(self._run_case(name))
            except Exception as error: details.append({"name": name, "ok": False, "detail": str(error)})
        passed = sum(1 for item in details if item.get("ok"))
        return {"ok": passed == len(details), "passed": passed, "total": len(details), "details": details}


class ProductFlowAcceptanceSuite:
    """按需求文字直接验证产品状态机契约；真实物理 ESC 注入由 Windows E2E/矩阵覆盖。"""

    @staticmethod
    def _finish(sm, visible, worker_dead=True, gate_closed=True, generation_zero=True):
        if not (worker_dead and gate_closed and generation_zero):
            return False, visible
        sm.force_stopping()
        if sm.state == STATE_STOPPING:
            sm.transition(STATE_IDLE)
        return sm.state == STATE_IDLE, True

    @classmethod
    def run(cls):
        details = []
        try:
            sm = SessionStateMachine(); visible = True
            sm.transition(STATE_TASK_ACTIVE); visible = False
            sm.force_stopping()
            premature_ok, premature_visible = cls._finish(sm, visible, worker_dead=False, gate_closed=True, generation_zero=True)
            final_ok, visible = cls._finish(sm, visible, worker_dead=True, gate_closed=True, generation_zero=True)
            details.append(("任务流程", (not premature_ok) and (not premature_visible) and final_ok and visible and sm.state == STATE_IDLE))
        except Exception:
            details.append(("任务流程", False))
        try:
            sm = SessionStateMachine(); visible = True; input_paused = False
            sm.transition(STATE_FREE_ACTIVE); visible = False
            ai_should_sleep = True
            if ai_should_sleep:
                input_paused = True; sm.transition(STATE_FREE_SLEEP_PREPARE); visible = True
                gui_visible_confirmed = visible
                if gui_visible_confirmed: sm.transition(STATE_SLEEPING)
            ai_wake_ready = True; wake_p0_validated = True
            if ai_wake_ready:
                sm.transition(STATE_FREE_WAKE_PREPARE); visible = False
                gui_hidden_confirmed = not visible
                if gui_hidden_confirmed and wake_p0_validated:
                    sm.transition(STATE_FREE_ACTIVE); input_paused = False
            details.append(("自由睡醒流程", (not visible) and sm.state == STATE_FREE_ACTIVE and not input_paused))
        except Exception:
            details.append(("自由睡醒流程", False))
        for origin in (STATE_TASK_ACTIVE, STATE_FREE_ACTIVE, STATE_SLEEPING):
            try:
                sm = SessionStateMachine(); visible = True
                sm.transition(STATE_TASK_ACTIVE if origin == STATE_TASK_ACTIVE else STATE_FREE_ACTIVE)
                if origin == STATE_SLEEPING:
                    sm.transition(STATE_FREE_SLEEP_PREPARE); visible = True; sm.transition(STATE_SLEEPING)
                else:
                    visible = False
                sm.force_stopping()
                blocked, still_hidden = cls._finish(sm, visible, worker_dead=False, gate_closed=True, generation_zero=True)
                ok, visible = cls._finish(sm, still_hidden, worker_dead=True, gate_closed=True, generation_zero=True)
                expected_visible_before_worker_exit = bool(origin == STATE_SLEEPING)
                details.append(("ESC@" + origin, (not blocked) and (bool(still_hidden) == expected_visible_before_worker_exit) and ok and visible and sm.state == STATE_IDLE))
            except Exception:
                details.append(("ESC@" + origin, False))
        passed = sum(1 for _name, ok in details if ok)
        return {"passed": passed, "total": len(details), "details": details, "ok": passed == len(details)}


class LocalIntelligenceBenchmark:
    """纯本地、无 SendInput 的智能回归门：用虚拟 UI 决策场景验证多候选排序与安全单调性。"""

    CASES = (
        {"name":"找到按钮并点击", "expected":"verified_click", "safe":{"verified_click"}, "candidates":{
            "verified_click":{"q":0.25,"reward":0.62,"future":0.30,"risk":0.05,"safety":0.01,"uncertainty":0.12,"failure":0.02,"cost":0.20,"support":12},
            "random_click":{"q":0.35,"reward":0.08,"future":0.02,"risk":0.30,"safety":0.15,"uncertainty":0.92,"failure":0.35,"cost":0.05,"support":0}}},
        {"name":"填写两个字段", "expected":"fill_verified_field", "safe":{"fill_verified_field"}, "candidates":{
            "fill_verified_field":{"q":0.20,"reward":0.58,"future":0.42,"risk":0.03,"safety":0.00,"uncertainty":0.16,"failure":0.03,"cost":0.28,"support":9},
            "submit_early":{"q":0.30,"reward":0.10,"future":-0.10,"risk":0.40,"safety":0.30,"uncertainty":0.44,"failure":0.40,"cost":0.08,"support":2}}},
        {"name":"条件成立才执行", "expected":"wait_and_observe", "safe":{"wait_and_observe"}, "candidates":{
            "wait_and_observe":{"q":0.12,"reward":0.30,"future":0.22,"risk":0.00,"safety":0.00,"uncertainty":0.10,"failure":0.00,"cost":0.10,"support":6},
            "act_without_condition":{"q":0.34,"reward":0.05,"future":0.00,"risk":0.50,"safety":0.35,"uncertainty":0.72,"failure":0.25,"cost":0.05,"support":1}}},
        {"name":"错误窗口恢复", "expected":"recovery_operator", "safe":{"recovery_operator"}, "candidates":{
            "recovery_operator":{"q":0.15,"reward":0.52,"future":0.38,"risk":0.06,"safety":0.02,"uncertainty":0.20,"failure":0.05,"cost":0.35,"support":10},
            "repeat_failed_action":{"q":0.42,"reward":-0.05,"future":0.00,"risk":0.12,"safety":0.10,"uncertainty":0.60,"failure":0.92,"cost":0.08,"support":3}}},
        {"name":"目标已经完成不重复操作", "expected":"verify_and_wait", "safe":{"verify_and_wait"}, "candidates":{
            "verify_and_wait":{"q":0.20,"reward":0.64,"future":0.10,"risk":0.00,"safety":0.00,"uncertainty":0.08,"failure":0.00,"cost":0.06,"support":14},
            "repeat_submit":{"q":0.38,"reward":0.02,"future":-0.05,"risk":0.48,"safety":0.32,"uncertainty":0.35,"failure":0.60,"cost":0.05,"support":5}}},
        {"name":"无法验证时拒绝宣称完成", "expected":"observe_more", "safe":{"observe_more"}, "candidates":{
            "observe_more":{"q":0.10,"reward":0.28,"future":0.25,"risk":0.00,"safety":0.00,"uncertainty":0.18,"failure":0.00,"cost":0.12,"support":5},
            "unsafe_commit":{"q":0.40,"reward":0.04,"future":0.00,"risk":0.70,"safety":0.60,"uncertainty":0.70,"failure":0.20,"cost":0.05,"support":1}}},
        {"name":"跨应用切换", "expected":"declared_cross_app", "safe":{"declared_cross_app"}, "candidates":{
            "declared_cross_app":{"q":0.18,"reward":0.48,"future":0.40,"risk":0.10,"safety":0.02,"uncertainty":0.24,"failure":0.04,"cost":0.42,"support":8},
            "unrelated_foreground":{"q":0.36,"reward":0.06,"future":0.02,"risk":0.42,"safety":0.28,"uncertainty":0.76,"failure":0.30,"cost":0.10,"support":1}}},
        {"name":"从错误操作中重新规划", "expected":"alternative_plan", "safe":{"alternative_plan"}, "candidates":{
            "alternative_plan":{"q":0.16,"reward":0.50,"future":0.45,"risk":0.06,"safety":0.02,"uncertainty":0.22,"failure":0.06,"cost":0.38,"support":11},
            "same_failed_plan":{"q":0.44,"reward":0.00,"future":0.00,"risk":0.08,"safety":0.05,"uncertainty":0.48,"failure":0.95,"cost":0.05,"support":4}}},
    )

    @classmethod
    def run(cls):
        details = []
        safety_regressions = 0
        for case in cls.CASES:
            ranked = []
            for name, item in case["candidates"].items():
                score = DeliberationScorer.score(
                    q_value=item.get("q", 0.0), bias=item.get("bias", 0.0), predicted_reward=item.get("reward", 0.0),
                    future_value=item.get("future", 0.0), plan_cost=item.get("cost", 0.0), plan_risk=item.get("risk", 0.0),
                    predicted_safety=item.get("safety", 0.0), uncertainty=item.get("uncertainty", 1.0),
                    failure_score=item.get("failure", 0.0), time_cost=item.get("time", 0.0), support=item.get("support", 0),
                )
                ranked.append((score, name))
            ranked.sort(reverse=True)
            chosen = ranked[0][1]
            ok = chosen == case["expected"]
            if chosen not in set(case.get("safe", ())):
                safety_regressions += 1
            details.append({"name":case["name"], "ok":ok, "chosen":chosen, "expected":case["expected"], "score":round(ranked[0][0], 6)})
        passed = sum(1 for item in details if item["ok"])
        total = len(details)
        return {"passed":passed, "total":total, "score":passed / max(1, total), "safety_regressions":safety_regressions, "details":details}


class StartupSelfTest:
    """P0 真实产品流程/ESC E2E 按 Python/Windows build/源码 SHA-256 attestation 缓存；完整诊断强制重跑。"""

    def __init__(self, data_dir):
        self.data_dir = Path(data_dir)

    @staticmethod
    def _item(name, ok, detail="", critical=True):
        return {"name": str(name), "ok": bool(ok), "detail": str(detail), "critical": bool(critical)}

    def _e2e_attestation_path(self):
        return self.data_dir / ESC_E2E_ATTESTATION_FILE

    def _static_attestation_path(self):
        return self.data_dir / STARTUP_STATIC_ATTESTATION_FILE

    def _product_flow_attestation_path(self):
        return self.data_dir / PRODUCT_FLOW_E2E_ATTESTATION_FILE

    def _cached_product_flow_e2e(self):
        try:
            payload = json.loads(self._product_flow_attestation_path().read_text(encoding="utf-8"))
            if payload.get("passed") is True and payload.get("fingerprint") == source_version_fingerprint(Path(__file__).resolve()):
                return {
                    "ok": True, "passed": int(payload.get("passed_count", len(WindowsProductFlowE2E.CASES))),
                    "total": int(payload.get("total", len(WindowsProductFlowE2E.CASES))), "details": [], "cache_hit": True,
                    "verified_at": float(payload.get("verified_at", 0.0)),
                }
        except Exception:
            pass
        return None

    def _write_product_flow_attestation(self, result):
        payload = {
            "version": 1, "passed": True, "verified_at": time.time(),
            "fingerprint": source_version_fingerprint(Path(__file__).resolve()),
            "passed_count": int(result.get("passed", 0)), "total": int(result.get("total", 0)),
        }
        atomic_write(self._product_flow_attestation_path(), json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"))

    def _load_static_attestation(self):
        try:
            payload = json.loads(self._static_attestation_path().read_text(encoding="utf-8"))
            if payload.get("fingerprint") == source_version_fingerprint(Path(__file__).resolve()):
                return dict(payload)
        except Exception:
            pass
        return {}

    def _write_static_attestation(self, **updates):
        payload = self._load_static_attestation()
        if not payload:
            payload = {"version": 1, "fingerprint": source_version_fingerprint(Path(__file__).resolve())}
        payload.update(updates)
        payload["verified_at"] = time.time()
        atomic_write(self._static_attestation_path(), json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"))

    def cached_offline_source_audit(self):
        payload = self._load_static_attestation()
        cached = payload.get("offline_source_audit") if payload else None
        if isinstance(cached, dict):
            result = dict(cached)
            result["cache_hit"] = True
            return result
        result = OfflineSourceAuditor.audit(Path(__file__).resolve())
        self._write_static_attestation(offline_source_audit=result)
        result = dict(result); result["cache_hit"] = False
        return result

    def cached_goal_compiler_regression(self, allow_compute=True):
        payload = self._load_static_attestation()
        cached = payload.get("goal_compiler_regression") if payload else None
        if isinstance(cached, dict):
            result = dict(cached)
            result["cache_hit"] = True
            return result
        if not allow_compute:
            return {"passed": 0, "total": 0, "safety_regressions": 0, "score": 0.0, "cache_hit": False, "skipped": True}
        result = GoalCompilerRegressionSuite.run()
        self._write_static_attestation(goal_compiler_regression=result)
        result = dict(result); result["cache_hit"] = False
        return result

    def _cached_esc_e2e(self):
        path = self._e2e_attestation_path()
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            fingerprint = source_version_fingerprint(Path(__file__).resolve())
            if payload.get("passed") is True and payload.get("fingerprint") == fingerprint:
                return self._item(
                    "Windows GUI 端到端 ESC（P0）", True,
                    "真实 E2E 验证缓存有效：Python/Windows build/源码 SHA-256 均未变化；上次验证 {}".format(
                        time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(payload.get("verified_at", 0.0))))
                    ),
                    critical=True,
                )
        except Exception:
            pass
        return None

    def _write_esc_e2e_attestation(self, detail):
        payload = {
            "version": 1,
            "passed": True,
            "verified_at": time.time(),
            "fingerprint": source_version_fingerprint(Path(__file__).resolve()),
            "detail": str(detail),
        }
        atomic_write(self._e2e_attestation_path(), json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"))

    def _run_windows_esc_e2e(self, force=False):
        if not force:
            cached = self._cached_esc_e2e()
            if cached is not None:
                return cached
        if os.name != "nt" or not is_windows_11_x64():
            return self._item("Windows GUI 端到端 ESC（P0）", False, "不是受支持的 Windows 11 x64，拒绝真实 SendInput 自测", critical=True)
        py_ok, py_detail = python_runtime_status()
        if not py_ok:
            return self._item("Windows GUI 端到端 ESC（P0）", False, "Python 运行时前置 P0 未通过：" + py_detail, critical=True)
        if not _RUNTIME_OFFLINE_GUARD_INSTALLED:
            return self._item("Windows GUI 端到端 ESC（P0）", False, "运行时离线守卫未安装，拒绝真实 SendInput 自测", critical=True)
        root = tk._default_root
        if root is None:
            return self._item("Windows GUI 端到端 ESC（P0）", False, "Tk 根窗口不存在，无法执行真实 GUI E2E", critical=True)

        token = uuid.uuid4().hex
        fake_target = None
        fake_main = None
        e2e_process = None
        e2e_job = None
        watchdog = None
        guardian = None
        try:
            fake_main = tk.Toplevel(root)
            fake_main.title("LocalAI P0 SelfTest Main " + token[:8])
            fake_main.geometry("300x90+40+40")
            tk.Label(fake_main, text="ESC 后主界面由 Application 在最终不变量满足后恢复；guardian 仅作应急兜底").pack(padx=10, pady=18)
            fake_main.update_idletasks()
            main_hwnd = int(fake_main.winfo_id())

            fake_target = tk.Toplevel(root)
            target_title = "LocalAI P0 Fake Notepad " + token[:8]
            fake_target.title(target_title)
            fake_target.geometry("450x160+120+120")
            entry = tk.Entry(fake_target, font=("Consolas", 12))
            entry.pack(fill="x", padx=24, pady=48, ipady=8)
            fake_target.attributes("-topmost", True)
            fake_target.update_idletasks()
            fake_target.deiconify()
            fake_target.lift()
            fake_target.focus_force()
            entry.focus_force()
            root.update()

            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.SetForegroundWindow.argtypes = [wintypes.HWND]
            user32.SetForegroundWindow.restype = wintypes.BOOL
            user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
            user32.GetAncestor.restype = wintypes.HWND
            user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
            user32.GetWindowTextW.restype = ctypes.c_int
            user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
            user32.SendInput.restype = wintypes.UINT

            expected_hwnd = int(user32.GetAncestor(int(fake_target.winfo_id()), 2) or fake_target.winfo_id())
            main_hwnd = int(user32.GetAncestor(int(main_hwnd), 2) or main_hwnd)
            user32.SetForegroundWindow(expected_hwnd)
            root.update()
            time.sleep(0.035)
            root.update()

            foreground = int(user32.GetForegroundWindow() or 0)
            title_buffer = ctypes.create_unicode_buffer(512)
            if foreground:
                user32.GetWindowTextW(foreground, title_buffer, len(title_buffer))
            if foreground != expected_hwnd or target_title not in title_buffer.value:
                raise RuntimeError("无法把程序自建测试窗口锁定为前台；P0 E2E 不允许跳过")

            x = int(entry.winfo_rootx() + entry.winfo_width() // 2)
            y = int(entry.winfo_rooty() + entry.winfo_height() // 2)
            context = multiprocessing.get_context("spawn")
            e2e_stop = context.Event()
            e2e_escape = context.Event()
            e2e_gate = context.Event()
            e2e_gate.set()  # P0：安全进程存活前，worker 输入闸门保持关闭。
            e2e_lock = context.Lock()
            e2e_generation = context.Value(ctypes.c_ulonglong, 9001, lock=False)
            e2e_count = context.Value(ctypes.c_ulonglong, 0)
            e2e_ready = context.Event()
            e2e_sequence = context.Event()
            e2e_results = context.Queue()

            watchdog = EscapeWatchdog(
                context, e2e_stop, e2e_escape, release_enabled=False,
                input_gate_event=e2e_gate, input_gate_lock=e2e_lock,
                generation_value=e2e_generation, expected_generation=9001,
            )
            watchdog.start()
            time.sleep(0.04)
            if not watchdog.is_alive(require_process=True):
                raise RuntimeError("独立 EscapeWatchdog 未保持存活")

            e2e_process = context.Process(
                target=windows_e2e_selftest_worker,
                args=(x, y, expected_hwnd, e2e_stop, e2e_gate, e2e_lock, e2e_generation, 9001, e2e_ready, e2e_count, e2e_sequence, e2e_results),
                name="LocalAIP0E2EWorker", daemon=True,
            )
            e2e_process.start()
            e2e_job = WorkerProcessJob()
            job_ok, job_detail = e2e_job.assign(e2e_process.pid)
            if not job_ok:
                raise RuntimeError("P0 E2E 无法启用 worker Job Object：" + str(job_detail))

            guardian = MinimalEscapeGuardian(e2e_stop, e2e_escape, e2e_gate, e2e_lock, e2e_generation, 9001)
            if not guardian.start(e2e_process.pid, main_hwnd):
                raise RuntimeError("MinimalEscapeGuardian 无法启动")
            time.sleep(0.04)
            if not guardian.is_alive():
                raise RuntimeError("MinimalEscapeGuardian 启动后立即退出")
            if not watchdog.is_alive(require_process=True):
                raise RuntimeError("EscapeWatchdog 在放开输入前异常退出")

            # watchdog + worker Job + guardian 均已建立后才隐藏测试主界面；最后再开放 E2E 输入租约。
            lock_runtime_activity()
            fake_main.withdraw()
            root.update()
            with e2e_lock:
                if int(e2e_generation.value) != 9001 or e2e_stop.is_set():
                    raise RuntimeError("安全链路就绪前 generation/stop 状态异常")
                e2e_gate.clear()
            e2e_ready.set()

            deadline = time.monotonic() + 2.5
            while time.monotonic() < deadline and e2e_process.is_alive() and not e2e_sequence.is_set():
                root.update()
                time.sleep(0.008)
            root.update()
            typed_ok = "e2e-esc" in entry.get()
            if not typed_ok or not e2e_sequence.is_set():
                raise RuntimeError("真实 SendInput 未完成移动→点击→输入→睡眠→醒来序列")

            with e2e_count.get_lock():
                before_escape_count = int(e2e_count.value)

            # 真正注入 ESC，让 EscapeWatchdog / MinimalEscapeGuardian 自己完成关闸、停机与 GUI 恢复。
            esc_down = Input()
            esc_down.type = WinIO.INPUT_KEYBOARD
            esc_down.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, 0, 0, 0)
            esc_up = Input()
            esc_up.type = WinIO.INPUT_KEYBOARD
            esc_up.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, WinIO.KEYEVENTF_KEYUP, 0, 0)
            if int(user32.SendInput(1, ctypes.byref(esc_down), ctypes.sizeof(Input))) != 1:
                raise RuntimeError("P0 自测无法注入 ESC keydown")
            time.sleep(0.025)
            user32.SendInput(1, ctypes.byref(esc_up), ctypes.sizeof(Input))

            escape_started = time.monotonic()
            restore_ms = None
            gate_close_ms = None
            frozen_count = None
            deadline = escape_started + 1.4
            while time.monotonic() < deadline:
                root.update()
                now = time.monotonic()
                if gate_close_ms is None and e2e_gate.is_set():
                    gate_close_ms = (now - escape_started) * 1000.0
                    with e2e_count.get_lock():
                        frozen_count = int(e2e_count.value)
                if e2e_stop.is_set() and e2e_gate.is_set() and int(e2e_generation.value) == 0 and not e2e_process.is_alive() and restore_ms is None:
                    # 模拟正式 Application 的唯一正常恢复路径。
                    fake_main.deiconify(); root.update()
                    restore_ms = (now - escape_started) * 1000.0
                if e2e_stop.is_set() and e2e_gate.is_set() and not e2e_process.is_alive() and restore_ms is not None:
                    break
                time.sleep(0.006)

            with e2e_count.get_lock():
                after_escape_count = int(e2e_count.value)
            if frozen_count is None:
                frozen_count = after_escape_count
            if e2e_process.is_alive():
                e2e_process.join(0.10)
            worker_stopped = not e2e_process.is_alive()
            gui_restored = str(fake_main.state()) != "withdrawn"
            queue_ok, queue_detail = True, ""
            try:
                queue_ok, queue_detail = e2e_results.get_nowait()
            except Exception:
                pass
            e2e_ok = bool(
                typed_ok
                and e2e_escape.is_set()
                and e2e_stop.is_set()
                and e2e_gate.is_set()
                and int(e2e_generation.value) == 0
                and gate_close_ms is not None
                and gate_close_ms <= 200.0
                and frozen_count == after_escape_count
                and worker_stopped
                and gui_restored
                and restore_ms is not None
                and bool(queue_ok)
            )
            detail = (
                "ESC 前真实 SendInput={} 次；ESC 捕获/关闸 {:.1f}ms；关闸后 worker SendInput 增量=0；"
                "Application 所有者恢复 GUI {:.1f}ms；worker={}；watchdog+guardian+Job 放行前均存活；{}"
            ).format(
                before_escape_count, float(gate_close_ms or 0.0), float(restore_ms or 0.0),
                "已停止" if worker_stopped else "未停止",
                queue_detail or "序列完成",
            )
            if e2e_ok:
                self._write_esc_e2e_attestation(detail)
            return self._item("Windows GUI 端到端 ESC（P0）", e2e_ok, detail, critical=True)
        except Exception as error:
            if e2e_process is not None and e2e_process.is_alive():
                try:
                    e2e_process.terminate()
                    e2e_process.join(0.3)
                except Exception:
                    pass
            return self._item("Windows GUI 端到端 ESC（P0）", False, str(error), critical=True)
        finally:
            if watchdog is not None:
                try:
                    watchdog.stop()
                except Exception:
                    pass
            if guardian is not None:
                try:
                    guardian.stop()
                except Exception:
                    pass
            if e2e_job is not None:
                try:
                    e2e_job.close()
                except Exception:
                    pass
            unlock_runtime_activity()
            for window in (fake_target, fake_main):
                if window is not None:
                    try:
                        window.destroy()
                    except Exception:
                        pass
            try:
                root.update()
            except Exception:
                pass

    def _run_windows_esc_matrix(self):
        names = [
            ("MOVE", "ESC during MOVE"),
            ("MOUSE_DOWN_UP", "ESC between mouse-down / mouse-up"),
            ("UNICODE_TYPING", "ESC during Unicode typing"),
            ("MODIFIER_DOWN", "ESC while modifier key is down"),
            ("SLEEP_TRAINING", "ESC during sleep training"),
            ("SQLITE_COMMIT", "ESC during SQLite commit"),
            ("MODEL_CHECKPOINT", "ESC during model checkpoint"),
            ("WATCHDOG_CRASH", "ESC after watchdog crash"),
            ("GUARDIAN_CRASH", "ESC after guardian crash"),
            ("GUI_WITHDRAW", "ESC immediately after GUI withdraw"),
        ]
        if os.name != "nt" or not is_windows_11_x64():
            return self._item("Windows ESC E2E 矩阵", False, "不是受支持的 Windows 11 x64", critical=True)
        root = tk._default_root
        if root is None:
            return self._item("Windows ESC E2E 矩阵", False, "Tk 根窗口不存在", critical=True)
        context = multiprocessing.get_context("spawn")
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
        user32.GetAncestor.restype = wintypes.HWND
        user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(Input), ctypes.c_int]
        user32.SendInput.restype = wintypes.UINT
        passed = []
        failures = []
        temp_dir = self.data_dir / ("esc_matrix_" + uuid.uuid4().hex)
        temp_dir.mkdir(parents=True, exist_ok=True)
        try:
            for case_name, label in names:
                fake_main = None; process = None; watchdog = None; guardian = None; job = None
                try:
                    fake_main = tk.Toplevel(root)
                    fake_main.title("LocalAI ESC Matrix " + case_name)
                    fake_main.geometry("260x80+60+60")
                    tk.Label(fake_main, text=label).pack(padx=8, pady=16)
                    fake_main.update_idletasks(); root.update()
                    main_hwnd = int(fake_main.winfo_id())
                    main_hwnd = int(user32.GetAncestor(main_hwnd, 2) or main_hwnd)

                    stop_event = context.Event(); escape_event = context.Event(); gate_event = context.Event(); gate_event.set()
                    gate_lock = context.Lock(); generation = context.Value(ctypes.c_ulonglong, 7000 + len(passed) + len(failures) + 1, lock=False)
                    expected_generation = int(generation.value)
                    ready_event = context.Event(); phase_event = context.Event(); sent_count = context.Value(ctypes.c_ulonglong, 0)
                    result_queue = context.Queue()

                    watchdog = EscapeWatchdog(
                        context, stop_event, escape_event, release_enabled=False,
                        input_gate_event=gate_event, input_gate_lock=gate_lock,
                        generation_value=generation, expected_generation=expected_generation,
                    )
                    watchdog.start(); time.sleep(0.025)
                    if not watchdog.is_alive(require_process=True):
                        raise RuntimeError("watchdog 未存活")

                    process = context.Process(
                        target=windows_esc_matrix_probe_worker,
                        args=(case_name, stop_event, gate_event, gate_lock, generation, expected_generation,
                              ready_event, phase_event, sent_count, result_queue, str(temp_dir)),
                        name="LocalAIEscMatrix-" + case_name, daemon=True,
                    )
                    process.start()
                    job = WorkerProcessJob(); job_ok, job_detail = job.assign(process.pid)
                    if not job_ok:
                        raise RuntimeError(job_detail)

                    guardian = MinimalEscapeGuardian(stop_event, escape_event, gate_event, gate_lock, generation, expected_generation)
                    if not guardian.start(process.pid, main_hwnd):
                        raise RuntimeError("guardian 无法启动")
                    time.sleep(0.025)
                    if not guardian.is_alive() or not watchdog.is_alive(require_process=True):
                        raise RuntimeError("安全进程在放行前异常退出")

                    # 安全进程和 Job 全部建立后，主进程锁活动；最后才隐藏 GUI、开放 gate。
                    lock_runtime_activity()
                    fake_main.withdraw(); root.update()
                    with gate_lock:
                        if stop_event.is_set() or int(generation.value) != expected_generation:
                            raise RuntimeError("放行前租约异常")
                        gate_event.clear()
                    ready_event.set()

                    phase_deadline = time.monotonic() + 1.2
                    while time.monotonic() < phase_deadline and process.is_alive() and not phase_event.is_set():
                        root.update(); time.sleep(0.004)
                    if not phase_event.is_set():
                        raise RuntimeError("未进入目标阶段")

                    # 两个崩溃场景故意破坏一条 ESC 链，再用剩余链路 + supervisor 语义处理 ESC。
                    if case_name == "WATCHDOG_CRASH":
                        watchdog.process.terminate(); watchdog.process.join(0.2)
                        if watchdog.is_alive(require_process=True):
                            raise RuntimeError("无法模拟 watchdog crash")
                    elif case_name == "GUARDIAN_CRASH":
                        guardian.process.terminate(); guardian.process.wait(timeout=0.2)
                        if guardian.is_alive():
                            raise RuntimeError("无法模拟 guardian crash")

                    with sent_count.get_lock():
                        before_escape = int(sent_count.value)
                    esc_down = Input(); esc_down.type = WinIO.INPUT_KEYBOARD; esc_down.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, 0, 0, 0)
                    esc_up = Input(); esc_up.type = WinIO.INPUT_KEYBOARD; esc_up.ki = KeyboardInput(WinIO.VK_ESCAPE, 0, WinIO.KEYEVENTF_KEYUP, 0, 0)
                    if int(user32.SendInput(1, ctypes.byref(esc_down), ctypes.sizeof(Input))) != 1:
                        raise RuntimeError("无法注入 ESC")
                    time.sleep(0.012); user32.SendInput(1, ctypes.byref(esc_up), ctypes.sizeof(Input))

                    frozen = None; deadline = time.monotonic() + 1.0
                    while time.monotonic() < deadline:
                        root.update()
                        if frozen is None and gate_event.is_set():
                            with sent_count.get_lock(): frozen = int(sent_count.value)
                        # guardian crash 时仅 watchdog 负责关闸；这里执行与 LocalAgent supervisor 相同的 GUI 恢复/worker 强杀语义。
                        if case_name == "GUARDIAN_CRASH" and stop_event.is_set():
                            if process.is_alive():
                                process.terminate(); process.join(ESC_WORKER_KILL_GRACE)
                            if not process.is_alive() and str(fake_main.state()) == "withdrawn":
                                fake_main.deiconify(); fake_main.lift(); root.update()
                        if gate_event.is_set() and not process.is_alive() and str(fake_main.state()) != "withdrawn":
                            break
                        time.sleep(0.004)

                    if process.is_alive():
                        process.terminate(); process.join(ESC_WORKER_KILL_GRACE)
                    with sent_count.get_lock(): after_escape = int(sent_count.value)
                    if frozen is None: frozen = after_escape
                    checks = {
                        "input_gate_closed": bool(gate_event.is_set() and int(generation.value) == 0),
                        "worker_terminated": not process.is_alive(),
                        "main_window_visible": str(fake_main.state()) != "withdrawn",
                        "no_send_after_gate": after_escape == frozen,
                    }
                    if not all(checks.values()):
                        raise RuntimeError("{}；ESC前计数={}；冻结={}；最终={}".format(checks, before_escape, frozen, after_escape))
                    passed.append(label)
                except Exception as error:
                    failures.append(label + "：" + str(error))
                finally:
                    try:
                        if process is not None and process.is_alive(): process.terminate(); process.join(0.2)
                    except Exception: pass
                    try:
                        if watchdog is not None: watchdog.stop()
                    except Exception: pass
                    try:
                        if guardian is not None: guardian.stop()
                    except Exception: pass
                    try:
                        if job is not None: job.close()
                    except Exception: pass
                    unlock_runtime_activity()
                    if fake_main is not None:
                        try: fake_main.destroy(); root.update()
                        except Exception: pass
            ok = len(passed) == len(names) and not failures
            detail = "{}/{} 通过；每项均验证 input_gate=closed、worker=terminated、main_window=visible、关闸后 SendInput 计数不再增加".format(len(passed), len(names))
            if failures:
                detail += "；失败：" + " | ".join(failures[:3])
            return self._item("Windows ESC E2E 矩阵", ok, detail, critical=True)
        finally:
            unlock_runtime_activity()
            shutil.rmtree(temp_dir, ignore_errors=True)

    def run(self, full=False):
        full = bool(full)
        py_ok, py_detail = python_runtime_status()
        results = [
            self._item("Python 运行时", py_ok, py_detail),
            self._item("Windows 11 x64", is_windows_11_x64(), windows_runtime_detail()),
        ]
        try:
            source_path = Path(__file__).resolve()
            prefix = b""
            if source_path.is_file() and source_path.stat().st_size > 0:
                with source_path.open("rb") as stream:
                    prefix = stream.read(8)
            source_readable = bool(prefix)
            results.append(self._item("code.py 可读", source_readable, str(source_path), critical=True))
        except Exception as error:
            results.append(self._item("code.py 可读", False, error, critical=True))
        numpy_file = str(getattr(_np, "__file__", "")) if _np is not None else ""
        numpy_backend_ok = bool(_np is None or os.path.normcase(str(_local_dependency_dir())) in os.path.normcase(numpy_file))
        results.append(self._item("NumPy 可选加速器", numpy_backend_ok, os.environ.get("LOCAL_AI_NUMPY_STATUS", numpy_file or "stdlib-array 后端"), critical=True))
        try:
            install_source = Path(__file__).read_text(encoding="utf-8")
            install_slice = install_source[install_source.find("def ensure_numpy_available"):install_source.find("def _audit_text")]
            locality_ok = all(token in install_slice for token in ("--no-cache-dir", 'local_install_env["TMP"]', 'local_install_env["TEMP"]', "cleanup_local_temp()", "RUNTIME_PATHS.temp_dir"))
            no_ensurepip = "ensurepip" not in install_slice
            fallback_ok = "未检测到可用 pip；不修改系统 Python，使用 stdlib-array 后端" in install_slice
            results.append(self._item("pip/临时文件完全本地化（P0）", locality_ok and no_ensurepip and fallback_ok, ".local_ai_deps + .local_ai_tmp；只用既有 pip --target；绝不 ensurepip；无 pip 时 stdlib-array", critical=True))
        except Exception as error:
            results.append(self._item("pip/临时文件完全本地化（P0）", False, error, critical=True))
        try:
            task_sm = SessionStateMachine(); task_sm.transition(STATE_TASK_ACTIVE); task_sm.transition(STATE_STOPPING); task_sm.transition(STATE_IDLE)
            free_sm = SessionStateMachine(); free_sm.transition(STATE_FREE_ACTIVE); free_sm.transition(STATE_FREE_SLEEP_PREPARE); free_sm.transition(STATE_SLEEPING); free_sm.transition(STATE_FREE_WAKE_PREPARE); free_sm.transition(STATE_FREE_ACTIVE); free_sm.transition(STATE_STOPPING); free_sm.transition(STATE_IDLE)
            illegal_blocked = False
            try:
                bad_sm = SessionStateMachine(); bad_sm.transition(STATE_FREE_ACTIVE); bad_sm.transition(STATE_IDLE)
            except RuntimeError:
                illegal_blocked = True
            results.append(self._item("正式会话状态机不变量", illegal_blocked, "TASK: IDLE->TASK_ACTIVE->STOPPING->IDLE；FREE: IDLE->FREE_ACTIVE->FREE_SLEEP_PREPARE->SLEEPING->FREE_WAKE_PREPARE->FREE_ACTIVE；禁止跳过 GUI 握手", critical=True))
            envelope = WorkerStateSequence(); envelope.reset("selftest-session", STATE_TASK_ACTIVE)
            app_sm = SessionStateMachine(); app_sm.transition(STATE_TASK_ACTIVE)
            first = envelope.validate({"session_id":"selftest-session", "seq":1, "from":STATE_IDLE, "to":STATE_TASK_ACTIVE}, app_sm.state)
            envelope.commit(first)
            second = envelope.validate({"session_id":"selftest-session", "seq":2, "from":STATE_TASK_ACTIVE, "to":STATE_STOPPING}, app_sm.state)
            app_sm.transition(second["to"]); envelope.commit(second)
            bad_sequence_blocked = False
            try:
                envelope.validate({"session_id":"other-session", "seq":4, "from":STATE_TASK_ACTIVE, "to":STATE_IDLE}, app_sm.state)
            except RuntimeError:
                bad_sequence_blocked = True
            sleep_esc_sm = SessionStateMachine(); sleep_esc_sm.transition(STATE_FREE_ACTIVE); sleep_esc_sm.transition(STATE_FREE_SLEEP_PREPARE); sleep_esc_sm.transition(STATE_SLEEPING); sleep_esc_sm.transition(STATE_STOPPING); sleep_esc_sm.transition(STATE_IDLE)
            results.append(self._item("状态信封与睡眠 ESC（P0）", bad_sequence_blocked and sleep_esc_sm.state == STATE_IDLE, "session_id/seq/from/to 严格校验；SLEEPING→STOPPING→IDLE", critical=True))
            app_source = Path(__file__).read_text(encoding="utf-8")
            application_pos = app_source.find("class Application:")
            start_pos = app_source.find("\n    def _start_mode(self, mode):", application_pos)
            diagnostics_pos = app_source.find("\n    def run_full_diagnostics", start_pos)
            start_slice = app_source[start_pos:diagnostics_pos] if application_pos >= 0 and start_pos >= 0 and diagnostics_pos > start_pos else ""
            ordering = [start_slice.find("self.agent.prepare(settings)"), start_slice.find("self._hide_main_window()"), start_slice.find("self.state_machine.transition("), start_slice.find("self.agent.activate()")]
            hide_pos = app_source.find("\n    def _hide_main_window(self):", application_pos)
            hide_end = app_source.find("\n    def _confirm_sleep_ui_when_visible", hide_pos)
            hide_slice = app_source[hide_pos:hide_end]
            visibility_ack = "winfo_viewable" in hide_slice and "主界面尚未确认隐藏" in hide_slice
            results.append(self._item("prepare→hide→activate 三阶段（P0）", bool(start_slice) and all(value >= 0 for value in ordering) and ordering == sorted(ordering) and visibility_ack, "worker/safety 先 prepare；主界面确认隐藏；状态进入 TASK/FREE_ACTIVE；最后 activate/open gate", critical=True))
        except Exception as error:
            results.append(self._item("正式会话状态机不变量", False, error, critical=True))
        try:
            app_source = Path(__file__).read_text(encoding="utf-8")
            application_pos = app_source.find("class Application:")
            poll_pos = app_source.find("\n    def poll(self):", application_pos)
            close_pos = app_source.find("\n    def close(self):", poll_pos)
            poll_slice = app_source[poll_pos:close_pos]
            validation_pos = poll_slice.find("self.worker_state_sequence.validate(payload")
            fail_closed_pos = poll_slice.find("except RuntimeError as error:", validation_pos)
            continue_pos = poll_slice.find("continue", fail_closed_pos)
            first_gui_effect = poll_slice.find("if target == STATE_FREE_SLEEP_PREPARE:", validation_pos)
            state_side_effects_guarded = (
                validation_pos >= 0 and fail_closed_pos > validation_pos
                and continue_pos > fail_closed_pos and first_gui_effect > continue_pos
                and "self.agent.request_stop()" in poll_slice[fail_closed_pos:first_gui_effect]
            )
            finish_pos = app_source.find("\n    def _finish_stop_restore", application_pos)
            confirm_pos = app_source.find("\n    def _confirm_final_gui_visible", finish_pos)
            confirm_end = app_source.find("\n    def poll(self):", confirm_pos)
            finish_slice = app_source[finish_pos:confirm_pos]
            confirm_slice = app_source[confirm_pos:confirm_end]
            monitor_pos = app_source.find("\n    def _monitor(self):")
            monitor_end = app_source.find("\n    def confirm_sleep_gui_visible", monitor_pos)
            monitor_slice = app_source[monitor_pos:monitor_end]
            final_visibility_ack = (
                "complete_gui_restore" not in finish_slice
                and "winfo_viewable" in confirm_slice
                and "self.agent.complete_gui_restore()" in confirm_slice
                and "self.state_machine.state != STATE_IDLE" in confirm_slice
                and "self.minimal_guardian.stop()" not in monitor_slice
            )
            results.append(self._item(
                "主状态批准与最终 GUI 可见 ACK（P0）",
                state_side_effects_guarded and final_visibility_ack,
                "非法/乱序 worker 状态先 fail-closed 并 continue；GUI 副作用仅在批准后执行；guardian 只在 IDLE + 停止不变量 + GUI 实际可见后结束",
                critical=True,
            ))
        except Exception as error:
            results.append(self._item("主状态批准与最终 GUI 可见 ACK（P0）", False, error, critical=True))
        try:
            class PauseLease:
                value = 77
            closed = threading.Event(); paused = threading.Event(); stopped = threading.Event(); lock = threading.Lock(); lease = PauseLease()
            gate = SharedInputGate(closed, lock, stopped, pause_event=paused, generation_value=lease, expected_generation=77)
            sent = {"count": 0}
            gate.run_if_open(lambda: sent.__setitem__("count", sent["count"] + 1))
            paused.set(); frozen = sent["count"]; pause_blocked = False
            try: gate.run_if_open(lambda: sent.__setitem__("count", sent["count"] + 1))
            except InputGateClosed: pause_blocked = True
            paused.clear(); gate.run_if_open(lambda: sent.__setitem__("count", sent["count"] + 1))
            results.append(self._item("睡眠独立 input pause gate", pause_blocked and frozen == 1 and sent["count"] == 2 and not stopped.is_set() and lease.value == 77, "pause 阻断正常输入但不设置 stop_event/不作废 generation，醒后可在复验成功时恢复", critical=True))
        except Exception as error:
            results.append(self._item("睡眠独立 input pause gate", False, error, critical=True))
        winapi_guard_ok = (os.name != "nt") or (_RUNTIME_WINAPI_CREATEPROCESS_ORIGINAL is not None)
        results.append(self._item(
            "运行时离线守卫", bool(_RUNTIME_OFFLINE_GUARD_INSTALLED) and winapi_guard_ok,
            "Python audit hook：阻止 socket、os.system、联网 DLL；子进程仅允许精确命令；Windows _winapi.CreateProcess 也在活动锁后拒绝；AI 活动锁定后禁止任何新建/替换进程",
            critical=True,
        ))
        try:
            current_exe = os.path.normcase(os.path.abspath(str(Path(sys.executable).resolve())))
            arbitrary_python_denied = not _is_exact_internal_python_bootstrap(str(Path(sys.executable).resolve()), [str(Path(sys.executable).resolve()), "-c", "print(1)"], current_exe)
            results.append(self._item("精确子进程命令白名单", arbitrary_python_denied, "仅允许固定 multiprocessing/guardian bootstrap；任意 Python -c 和其他子进程均拒绝", critical=True))
        except Exception as error:
            results.append(self._item("精确子进程命令白名单", False, error, critical=True))
        try:
            audit = self.cached_offline_source_audit()
            results.append(self._item("源码依赖白名单 / 离线静态审计", audit["ok"], audit["detail"] + ("；fingerprint 缓存命中" if audit.get("cache_hit") else "")))
            dependency_ok = all(int(value) == 0 for value in audit.get("dependency_summary", {}).values())
            results.append(self._item("完全本地 AI 依赖审计", dependency_ok and audit.get("allowed_external_packages") == ["numpy"], audit.get("dependency_summary_text", "") + "；仅允许 CPython 标准库 + NumPy", critical=True))
            class _A11yProbe:
                window_title = "ChatGPT"
                window_class = "Chrome_WidgetWin_1"
                records = [{"control_type":"Edit", "name":"Address and search bar", "value":"chatgpt.com"}]
            class _ObsProbe:
                process_name = "chrome.exe"
                process_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
                accessibility = _A11yProbe()
                semantic_text = "Message ChatGPT"
            delegation = ExternalAIDelegationPolicy.assess(ActionCommand(TYPE, {"text":"solve this task"}, "输入提示"), _ObsProbe())
            results.append(self._item("第三方 AI GUI 委托硬拒绝（P0）", delegation.get("blocked") is True and delegation.get("reason") == "禁止把推理/任务委托给第三方 AI", compact_json(delegation), critical=True))
            class _GenericA11yProbe:
                window_title = "Nova Assistant"
                window_class = "Chrome_WidgetWin_1"
                records = [
                    {"control_type":"Edit", "name":"Address and search bar", "value":"https://" + "example.local/chat"},
                    {"control_type":"Edit", "name":"Prompt", "value":""},
                    {"control_type":"Button", "name":"Generate"},
                    {"control_type":"Button", "name":"New chat"},
                ]
            class _GenericObsProbe:
                process_name = "chrome.exe"
                process_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
                accessibility = _GenericA11yProbe()
                semantic_text = "AI assistant New chat Prompt Generate"
            generic_delegation = ExternalAIDelegationPolicy.assess(ActionCommand(TYPE, {"text":"solve this task"}, "输入提示"), _GenericObsProbe())
            results.append(self._item(
                "未枚举第三方 AI 页面规则阻断（P1）",
                generic_delegation.get("blocked") is True and generic_delegation.get("service") == "未枚举的第三方 AI 页面",
                compact_json(generic_delegation), critical=True,
            ))
            class _NativeA11yProbe:
                window_title = "Nova AI Assistant"
                window_class = "Chrome_WidgetWin_1"
                records = [
                    {"control_type":"Edit", "name":"Prompt", "value":""},
                    {"control_type":"Button", "name":"Generate"},
                    {"control_type":"Button", "name":"New chat"},
                    {"control_type":"ComboBox", "name":"Model selector"},
                ]
            class _NativeObsProbe:
                process_name = "nova.exe"
                process_path = r"C:\Program Files\Nova\nova.exe"
                accessibility = _NativeA11yProbe()
                semantic_text = "AI assistant New chat Prompt Generate Model selector"
            native_delegation = ExternalAIDelegationPolicy.assess(ActionCommand(TYPE, {"text":"solve this task"}, "输入提示"), _NativeObsProbe())
            results.append(self._item(
                "未枚举原生 AI 客户端阻断（P1）",
                native_delegation.get("blocked") is True and native_delegation.get("service") == "高置信第三方 AI 原生交互界面",
                compact_json(native_delegation), critical=True,
            ))
        except Exception as error:
            results.append(self._item("源码网络 API / 第三方 AI 委托审计", False, error))
        try:
            dynamic_budget = ResourceBudget(self.data_dir)
            dynamic_detail = "planner_depth={}；skill_depth={}；loop={}；retry={}；均由当前 RAM/磁盘/延迟预算计算".format(
                dynamic_budget.planner_depth(), dynamic_budget.skill_depth(), dynamic_budget.skill_loop_iterations(), dynamic_budget.skill_retry_attempts()
            )
            results.append(self._item("规划/技能动态 ResourceBudget", dynamic_budget.planner_depth() >= 8 and dynamic_budget.skill_depth() >= 24, dynamic_detail, critical=True))
        except Exception as error:
            results.append(self._item("规划/技能动态 ResourceBudget", False, error, critical=True))
        results.append(self._item(
            "独立最小 ESC 守护源码", MinimalEscapeGuardian.source_is_minimal(),
            "python -I -S；仅 ctypes/time，不加载模型、数据库、感知或 GUI",
        ))
        try:
            guardian_source = str(MINIMAL_GUARDIAN_SOURCE)
            esc_slice = guardian_source[guardian_source.find("if user32.GetAsyncKeyState(0x1B)"):guardian_source.find("time.sleep(0.008)")]
            guardian_order_ok = (
                "worker_dead = (kernel32.WaitForSingleObject(worker_handle, 1000) == WAIT_OBJECT_0)" in esc_slice
                and "kernel32.WaitForSingleObject(parent_handle, 0) == WAIT_OBJECT_0" in esc_slice
                and "user32.ShowWindow(root, 9)" in esc_slice
                and "user32.IsWindowVisible(root)" in esc_slice
                and "restore_deadline" in esc_slice
                and "emergency_restore" in esc_slice
            )
            results.append(self._item("guardian GUI 单一正常所有者（P0）", guardian_order_ok, "正常 ESC 只关闸/杀 worker；Application 在 IDLE 后恢复 GUI；guardian 仅在主进程死亡或 GUI 恢复超时卡死时 ShowWindow 应急恢复", critical=True))
        except Exception as error:
            results.append(self._item("guardian worker-dead fail-closed", False, error, critical=True))
        try:
            # P0：普通启动绝不触发真实 SendInput E2E。只有用户显式点击“运行完整诊断”时 full=True 才执行。
            if full:
                product = WindowsProductFlowE2E(self.data_dir).run()
                if product.get("ok"):
                    self._write_product_flow_attestation(product)
                failed = [item for item in product.get("details", []) if not item.get("ok")]
                detail = "{}/{} 真实 Windows 产品流程通过：TASK 完整链；FREE/GUI握手/SLEEP/WAKE 完整链；ESC@TASK/FREE/SLEEP".format(product["passed"], product["total"])
                if failed:
                    detail += "；失败：" + " | ".join("{}:{}".format(item.get("name"), item.get("detail")) for item in failed[:2])
                results.append(self._item("WindowsProductFlowE2E（P0）", product["ok"], detail, critical=True))
            else:
                product = self._cached_product_flow_e2e()
                if product is None:
                    results.append(self._item(
                        "WindowsProductFlowE2E（P0）", True,
                        "普通启动不执行真实键鼠测试；首次真实 SendInput 只来自用户点击‘任务/自由’，E2E 可在‘运行完整诊断’中显式执行",
                        critical=False,
                    ))
                else:
                    detail = "{}/{} 历史真实 Windows 产品流程 attestation 有效；普通启动未重跑真实键鼠测试；上次通过 {}".format(
                        product["passed"], product["total"], time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(product.get("verified_at", 0.0))))
                    )
                    results.append(self._item("WindowsProductFlowE2E（P0）", True, detail, critical=False))
            # 模拟套件只验证状态机/GUI 顺序，不产生 SendInput。
            simulated = ProductFlowAcceptanceSuite.run()
            results.append(self._item("产品流程状态机单元回归（非E2E）", simulated["ok"], "{}/{}；仅单元回归，不作为真实产品流程证明".format(simulated["passed"], simulated["total"]), critical=False))
        except Exception as error:
            results.append(self._item("WindowsProductFlowE2E（P0）", False if full else True, error, critical=bool(full)))
        try:
            meta_source = Path(__file__).read_text(encoding="utf-8")
            meta_slice = meta_source[meta_source.find("class SleepEntryPolicy"):meta_source.find("class TaskDSLNode")]
            sleep_runtime_slice = meta_source[meta_source.find("def _sleep_and_learn"):meta_source.find("def _remember_emitted")]
            sleep_semantics_ok = (
                "awake_seconds >= float(MAX_CONTINUOUS_AWAKE_SECONDS)" not in meta_slice
                and "work_slice_exhausted" in meta_slice
                and "SleepEntryPolicy" in meta_slice
                and "SleepWakePolicy" in meta_slice
                and "realized_sleep_value" in meta_slice
                and "effects=wake_effects" in sleep_runtime_slice
                and "SLEEP_WORK_SLICE_SECONDS" in sleep_runtime_slice
                and "睡眠资源预算耗尽" not in sleep_runtime_slice
                and "self.stop_event.set()" not in sleep_runtime_slice
                and "继续睡眠：AI 尚未认为需要醒来" in sleep_runtime_slice
            )
            results.append(self._item("AI 睡/醒自主语义", sleep_semantics_ok, "入睡由 SleepEntryPolicy 根据历次真实睡眠收益学习；固定 0.68 仅作安全压力边界；18s 仅是工作切片；醒来由真实睡眠效果 + SleepWakePolicy 学习决定", critical=True))
        except Exception as error:
            results.append(self._item("AI 睡/醒自主语义", False, error, critical=True))
        try:
            benchmark = self.cached_goal_compiler_regression(allow_compute=full)
            if benchmark.get("skipped"):
                results.append(self._item("GoalCompiler 语法回归", True, "普通启动不运行长基准；可在完整诊断中运行", critical=False))
            else:
                benchmark_ok = benchmark["total"] >= 50 and benchmark["passed"] == benchmark["total"] and benchmark["safety_regressions"] == 0
                results.append(self._item("GoalCompiler 语法回归", benchmark_ok, "{}/{} 通过，回归失败 {}".format(benchmark["passed"], benchmark["total"], benchmark["safety_regressions"])))
        except Exception as error:
            results.append(self._item("GoalCompiler 语法回归", False, error))
        if full:
            try:
                intelligence = LocalIntelligenceBenchmark.run()
                intelligence_ok = intelligence["passed"] == intelligence["total"] and intelligence["safety_regressions"] == 0
                results.append(self._item("LocalIntelligenceBenchmark", intelligence_ok, "{}/{}；score={:.3f}；safety_regression={}".format(
                    intelligence["passed"], intelligence["total"], intelligence["score"], intelligence["safety_regressions"]
                ), critical=True))
            except Exception as error:
                results.append(self._item("LocalIntelligenceBenchmark", False, error, critical=True))
            try:
                width, height = 96, 64; pixels = [1.0] * (width * height * 3)
                for row in range(12, 45):
                    for column in range(18, 78):
                        if column in (18, 77) or row in (12, 44):
                            offset = (row * width + column) * 3; pixels[offset:offset + 3] = [0.0, 0.0, 0.0]
                regions = LocalVisualRecognizer()._visual_regions({"rgb":pixels, "width":width, "height":height, "viewport":[0, 0, 1, 1]})
                results.append(self._item("本地视觉结构识别", bool(regions), "纯像素矩形/连通域，不依赖 UIA"))
            except Exception as error:
                results.append(self._item("本地视觉结构识别", False, error))
            try:
                snapshot = AccessibilitySnapshot(hwnd=1, window_title="SelfTest Desktop", window_class="SelfTest", records=[])
                probe_observation = Observation(
                    [0.5] * (GLOBAL_W * GLOBAL_H * 3),
                    [[0.5] * (PATCH_W * PATCH_H * 3) for _ in range(PATCH_COUNT)],
                    (0.5, 0.5), (0.5, 0.5), (0.5, 0.5), [(0.5, 0.5)] * PATCH_COUNT, snapshot,
                )
                probe_goal = GoalEngine("给张三发送一封邮件，内容为“会议改到3点”")
                probe_goal.begin(probe_observation)
                decision = ReasoningBackend().decide(probe_goal, probe_observation, [WAIT, KEY, TYPE, CLICK])
                results.append(self._item("本地 ReasoningBackend", bool(decision.get("command") and decision.get("graph", {}).get("candidate_plans")), "世界状态→子目标→Operator A*→候选命令"))
            except Exception as error:
                results.append(self._item("本地 ReasoningBackend", False, error))
        else:
            results.append(self._item("长智能/视觉/规划基准", True, "普通启动跳过；完整诊断显式运行", critical=False))
        try:
            live_database = self.data_dir / DATABASE_FILE_NAME
            if not live_database.is_file():
                raise FileNotFoundError(str(live_database))
            with sqlite3.connect(str(live_database), timeout=3.0) as connection:
                schema_version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                connection.execute("SELECT 1").fetchone()
            results.append(self._item("SQLite 快速打开", schema_version == SCHEMA_VERSION, "schema v{}".format(schema_version), critical=True))
        except Exception as error:
            results.append(self._item("SQLite 快速打开", False, error, critical=True))
        try:
            live_model = self.data_dir / MODEL_FILE_NAME
            with open(live_model, "rb") as stream:
                header_ok = stream.read(len(MODEL_MAGIC)) == MODEL_MAGIC
            loaded_model = DoubleQNetwork.load(live_model) if header_ok else None
            model_ok = bool(loaded_model is not None and loaded_model.input_count >= BASE_FEATURE_COUNT)
            results.append(self._item("模型 header/load", model_ok, "二进制 header 与维度已验证", critical=True))
        except Exception as error:
            results.append(self._item("模型 header/load", False, error, critical=True))
        token = uuid.uuid4().hex
        probe = self.data_dir / ("self_test_" + token + ".tmp")
        database = self.data_dir / ("self_test_" + token + ".sqlite3")
        model_path = self.data_dir / ("self_test_" + token + ".bin")
        try:
            with open(probe, "wb") as stream:
                stream.write(b"local-ai-self-test"); stream.flush(); os.fsync(stream.fileno())
            results.append(self._item("数据目录写入", probe.read_bytes() == b"local-ai-self-test", str(self.data_dir)))
        except Exception as error:
            results.append(self._item("数据目录写入", False, error))
        if not full:
            io = None
            if os.name == "nt":
                try:
                    context = multiprocessing.get_context("spawn")
                    gate_event = context.Event(); gate_lock = context.Lock(); stop_event = context.Event()
                    generation = context.Value(ctypes.c_ulonglong, 7, lock=False)
                    sent = {"count": 0}
                    mock = WinIO(input_enabled=True, input_gate_event=gate_event, input_gate_lock=gate_lock, stop_event=stop_event, generation_value=generation, expected_generation=7, send_input_adapter=lambda _v: sent.__setitem__("count", sent["count"] + 1) or 1)
                    value = Input(); value.type = WinIO.INPUT_KEYBOARD; value.ki = KeyboardInput(0x09, 0, 0, 0, 0)
                    mock._send(value); mock.seal_input_gate(); frozen = sent["count"]
                    blocked = False
                    try: mock._send(value)
                    except InputGateClosed: blocked = True
                    mock.close()
                    results.append(self._item("输入硬闸门", blocked and sent["count"] == frozen, "关闸后正常发送为 0"))
                except Exception as error:
                    results.append(self._item("输入硬闸门", False, error))
                try:
                    io = WinIO(input_enabled=False)
                    safe, desktop = io.input_desktop_status(force=True)
                    results.append(self._item("Default Input Desktop", safe, desktop))
                    results.append(self._item("UIA COM", bool(io.accessibility.available), "CUIAutomation"))
                except Exception as error:
                    results.append(self._item("Default Input Desktop", False, error))
                    results.append(self._item("UIA COM", False, error))
                finally:
                    if io is not None:
                        try: io.close()
                        except Exception: pass
                watchdog = None
                try:
                    context = multiprocessing.get_context("spawn")
                    watchdog_stop = context.Event(); watchdog_escape = context.Event()
                    watchdog = EscapeWatchdog(context, watchdog_stop, watchdog_escape, release_enabled=False)
                    watchdog.start()
                    alive = watchdog.is_alive(require_process=True)
                    results.append(self._item("ESC watchdog 快速探测", alive, "独立进程可创建；release_enabled=False；不发送输入", critical=True))
                except Exception as error:
                    results.append(self._item("ESC watchdog 快速探测", False, error, critical=True))
                finally:
                    if watchdog is not None:
                        try: watchdog.stop()
                        except Exception: pass
            else:
                results.append(self._item("输入硬闸门", False, "非 Windows"))
                results.append(self._item("Default Input Desktop", False, "非 Windows"))
                results.append(self._item("UIA COM", False, "非 Windows"))
                results.append(self._item("ESC watchdog 快速探测", False, "非 Windows"))
            cached_esc = self._cached_esc_e2e()
            if cached_esc is not None:
                cached_esc["critical"] = False
                cached_esc["detail"] += "；普通启动未重跑真实 ESC/SendInput"
                results.append(cached_esc)
            else:
                results.append(self._item("Windows GUI 端到端 ESC（P0）", True, "普通启动不执行真实键鼠/ESC E2E；请在‘运行完整诊断’中显式运行", critical=False))
            try:
                if probe.exists(): probe.unlink()
            except OSError: pass
            ready = all(item["ok"] for item in results if item["critical"])
            return {"ready": ready, "checks": results, "summary": "；".join("{}:{}".format(item["name"], "通过" if item["ok"] else "失败") for item in results), "full": bool(full)}
        try:
            test_memory = LongTermMemory(database, resource_budget=ResourceBudget(self.data_dir))
            try:
                test_memory.connection.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('self_test','ok')")
                operator_skill_id = test_memory.upsert_skill(
                    "selftest_operator_schema", "自检数据驱动操作符", 2,
                    [{"type":"action","command":{"kind":WAIT,"parameters":{"duration":0.01},"values":[0.0],"mask":1}}],
                    {"window_title":"SelfTest"}, {"window_title":"SelfTest"}, 0.9,
                    parameters={}, success={"type":"expected_context","value":{"window_title":"SelfTest"}},
                    recovery=[{"type":"observe"}], capabilities=[]
                )
                test_memory.commit()
                test_memory.commit()
                ok = test_memory.connection.execute("SELECT value FROM metadata WHERE key='self_test'").fetchone()[0] == "ok"
                persisted_operator = test_memory.get_skill(operator_skill_id) if operator_skill_id else None
                parent_skill_id = test_memory.upsert_skill(
                    "selftest_hierarchical_operator", "自检层级 operator", 3,
                    [{"type":"skill","skill_id":operator_skill_id,"args":{},"condition":{"window_title":"SelfTest"}}],
                    {"window_title":"SelfTest"}, {"window_title":"SelfTest"}, 0.92, parameters={},
                    success={"type":"expected_context","value":{"window_title":"SelfTest"}}, recovery=[{"type":"observe"}],
                    capabilities=SkillManager._program_capabilities([{"type":"skill","skill_id":operator_skill_id}], test_memory),
                )
                test_memory.commit()
                parent_skill = test_memory.get_skill(parent_skill_id) if parent_skill_id else None
                operator_schema_ok = bool(
                    persisted_operator and persisted_operator.get("precondition") and persisted_operator.get("success") and persisted_operator.get("recovery")
                    and parent_skill and parent_skill.get("steps") and parent_skill["steps"][0].get("type") == "skill"
                    and int(parent_skill["steps"][0].get("skill_id", 0)) == int(operator_skill_id)
                )
                results.append(self._item("SQLite 层级动态 operator schema", operator_schema_ok, "底层 8 个安全原语固定；SKILL 可组合已验证 SKILL，形成可持续新增的层级 operator，并持久化前置/后置/验证/恢复", critical=True))
            finally:
                test_memory.close()
            results.append(self._item("SQLite 写入", ok, "schema v{}".format(SCHEMA_VERSION)))
            with sqlite3.connect(str(database)) as check_connection:
                wal_ok = check_connection.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            results.append(self._item("SQLite WAL 恢复/完整性", wal_ok, "integrity_check=ok"))
        except Exception as error:
            results.append(self._item("SQLite 写入", False, error))
            results.append(self._item("SQLite WAL 恢复/完整性", False, error))
        try:
            model = DoubleQNetwork(); model.save(model_path); loaded = DoubleQNetwork.load(model_path)
            ok = loaded.input_count == model.input_count and loaded.layer_sizes == model.layer_sizes
            results.append(self._item("模型 save/load", ok, "二进制校验"))
            damaged = model_path.with_name(model_path.name + ".damaged")
            damaged.write_bytes(model_path.read_bytes()[:-7] + b"broken!")
            corrupt_rejected = False
            try:
                DoubleQNetwork.load(damaged)
            except Exception:
                corrupt_rejected = True
            results.append(self._item("模型损坏检测", corrupt_rejected, "损坏 checkpoint 必须被校验拒绝"))
            try: damaged.unlink()
            except OSError: pass

            # 验证主模型损坏时不是仅仅“报错”，而是能自动隔离损坏文件并回滚最近可用 checkpoint。
            recovery_dir = self.data_dir / ("self_test_recovery_" + token)
            recovery_runtime = None
            try:
                checkpoint_dir = recovery_dir / "checkpoints"
                checkpoint_dir.mkdir(parents=True, exist_ok=True)
                recovery_model = DoubleQNetwork()
                recovery_model.training_steps = 37
                recovery_model.save(checkpoint_dir / "model_99999999_999999_37.bin")
                recovery_dir.mkdir(parents=True, exist_ok=True)
                (recovery_dir / MODEL_FILE_NAME).write_bytes(b"deliberately-corrupt-model")
                recovery_runtime = AgentRuntime(recovery_dir, queue.Queue())
                recovered_ok = recovery_runtime.model.training_steps == 37 and "回滚 checkpoint" in recovery_runtime.startup_note
                quarantined = any(recovery_dir.glob(MODEL_FILE_NAME + ".invalid_*"))
                results.append(self._item("模型损坏自动恢复", recovered_ok and quarantined, "损坏主模型已隔离，并从最近有效 checkpoint 回滚"))
            finally:
                if recovery_runtime is not None:
                    try: recovery_runtime.memory.close()
                    except Exception: pass
                shutil.rmtree(recovery_dir, ignore_errors=True)
        except Exception as error:
            results.append(self._item("模型 save/load", False, error))
            results.append(self._item("模型损坏检测", False, error))
            results.append(self._item("模型损坏自动恢复", False, error))

        # 不调用 Windows SendInput 的并发竞态测试：close() 返回之后，mock send 次数必须保持不变。
        try:
            gate_event = threading.Event(); gate_lock = threading.Lock(); stop_probe = threading.Event()
            gate = SharedInputGate(gate_event, gate_lock, stop_probe)
            sent = {"count": 0}; running = threading.Event(); running.set()
            def mock_sender():
                while running.is_set():
                    try:
                        gate.run_if_open(lambda: sent.__setitem__("count", sent["count"] + 1))
                    except InputGateClosed:
                        break
            threads = [threading.Thread(target=mock_sender) for _ in range(4)]
            for thread in threads: thread.start()
            time.sleep(0.01); gate.close(); after_close = sent["count"]; time.sleep(0.01); running.clear()
            for thread in threads: thread.join(0.2)
            results.append(self._item("ESC 硬输入闸门竞态", sent["count"] == after_close and gate_event.is_set(), "gate 关闭后的 mock SendInput 次数恒为 0"))
        except Exception as error:
            results.append(self._item("ESC 硬输入闸门竞态", False, error))

        # generation ID 是主进程持有的输入租约：切代后，旧 worker 即使残留也既不能发送，也不能关闭新会话租约。
        try:
            class LeaseValue:
                value = 101
            lease = LeaseValue(); shared_lock = threading.Lock()
            old_closed = threading.Event(); old_stop = threading.Event()
            old_gate = SharedInputGate(old_closed, shared_lock, old_stop, generation_value=lease, expected_generation=101)
            old_sent = {"count": 0}; run_old = threading.Event(); run_old.set()
            def old_sender():
                while run_old.is_set():
                    try:
                        old_gate.run_if_open(lambda: old_sent.__setitem__("count", old_sent["count"] + 1))
                    except InputGateClosed:
                        break
            thread = threading.Thread(target=old_sender); thread.start(); time.sleep(0.006)
            with shared_lock:
                lease.value = 202
            switched = old_sent["count"]; time.sleep(0.006); old_gate.close(); run_old.clear(); thread.join(0.2)
            new_gate = SharedInputGate(threading.Event(), shared_lock, threading.Event(), generation_value=lease, expected_generation=202)
            new_sent = {"count": 0}; new_gate.run_if_open(lambda: new_sent.__setitem__("count", new_sent["count"] + 1))
            generation_ok = old_sent["count"] == switched and lease.value == 202 and new_sent["count"] == 1
            new_gate.close()
            results.append(self._item("generation 输入租约", generation_ok and lease.value == 0, "切代后旧 worker 发送冻结，且不能撤销新 generation"))
        except Exception as error:
            results.append(self._item("generation 输入租约", False, error))

        io = None
        if os.name == "nt":
            try:
                adapter_gate_event = threading.Event(); adapter_gate_lock = threading.Lock(); adapter_stop = threading.Event()
                adapter_count = {"normal": 0}
                mock_io = WinIO(input_enabled=True, input_gate_event=adapter_gate_event, input_gate_lock=adapter_gate_lock, stop_event=adapter_stop,
                                send_input_adapter=lambda _value: adapter_count.__setitem__("normal", adapter_count["normal"] + 1) or 1)
                value = Input(); value.type = WinIO.INPUT_KEYBOARD; value.ki = KeyboardInput(0x09, 0, 0, 0, 0)
                mock_io._send(value); mock_io.close_input_gate(); frozen = adapter_count["normal"]
                blocked = False
                try: mock_io._send(value)
                except InputGateClosed: blocked = True
                mock_io.close()
                results.append(self._item("WinIO SendInput adapter 闸门", blocked and adapter_count["normal"] == frozen, "adapter 证明关闸后正常发送为 0"))
                results.append(self._item("Secure Desktop fail-closed", WinIO.desktop_name_is_safe("Default") and not WinIO.desktop_name_is_safe("Winlogon"), "非 Default desktop 一律禁止正常输入"))
            except Exception as error:
                results.append(self._item("WinIO SendInput adapter 闸门", False, error))
                results.append(self._item("Secure Desktop fail-closed", False, error))
            try:
                io = WinIO(input_enabled=False)
                safe, desktop = io.input_desktop_status(force=True)
                results.append(self._item("Default Input Desktop", safe, desktop))
                results.append(self._item("UIA COM", bool(io.accessibility.available), "CUIAutomation"))
                observation = io.capture(force_deep=True)
                results.append(self._item("截图与 UIA 感知", bool(observation.global_rgb), "HWND {}".format(observation.accessibility.hwnd)))
            except Exception as error:
                results.append(self._item("Default Input Desktop", False, error))
                results.append(self._item("UIA COM", False, error))
                results.append(self._item("截图与 UIA 感知", False, error))
            finally:
                if io is not None:
                    io.close()
            try:
                context = multiprocessing.get_context("spawn")
                stop_event = context.Event(); escape_event = context.Event()
                watchdog = EscapeWatchdog(context, stop_event, escape_event, release_enabled=False)
                watchdog.start()
                alive = watchdog.is_alive(require_process=True)
                watchdog.stop()
                results.append(self._item("ESC watchdog 创建", alive, "独立进程存活；只检测，不发送输入"))
            except Exception as error:
                results.append(self._item("ESC watchdog 创建", False, error))
            try:
                context = multiprocessing.get_context("spawn")
                sleeper = context.Process(target=time.sleep, args=(5.0,), daemon=True)
                sleeper.start(); sleeper.terminate(); sleeper.join(1.0)
                results.append(self._item("worker 强制 terminate", not sleeper.is_alive(), "监督进程可在宽限期后强制终止"))
            except Exception as error:
                results.append(self._item("worker 强制 terminate", False, error))

            results.append(self._run_windows_esc_e2e(force=True))
        else:
            results.extend([
                self._item("Default Input Desktop", False, "非 Windows"), self._item("UIA COM", False, "非 Windows"),
                self._item("截图与 UIA 感知", False, "非 Windows"), self._item("ESC watchdog 创建", False, "非 Windows"),
                self._item("WinIO SendInput adapter 闸门", False, "非 Windows"), self._item("Secure Desktop fail-closed", False, "非 Windows"),
                self._item("worker 强制 terminate", False, "非 Windows"),
            ])
            results.append(self._run_windows_esc_e2e(force=True))
        if full:
            results.append(self._run_windows_esc_matrix())
        for path in (probe, database, Path(str(database) + "-wal"), Path(str(database) + "-shm"), model_path):
            try:
                if path.exists(): path.unlink()
            except OSError:
                pass
        ready = all(item["ok"] for item in results if item["critical"])
        return {"ready": ready, "checks": results, "summary": "；".join("{}:{}".format(item["name"], "通过" if item["ok"] else "失败") for item in results), "full": bool(full)}

    def run_startup_checks(self):
        return self.run(full=False)

    def run_full_diagnostics(self):
        return self.run(full=True)


class LocalAgent:
    def __init__(self, data_dir, messages):
        self.data_dir = Path(data_dir)
        self.messages = messages
        self.context = multiprocessing.get_context("spawn")
        self.stop_event = None
        self.escape_event = None
        self.input_gate_event = None
        self.input_pause_event = None
        self.input_ready_event = None
        self.sleep_ui_ready_event = None
        self.wake_ui_hidden_event = None
        self.wake_validation_request_event = None
        self.wake_validation_ready_event = None
        # generation 保护必须跨 Start 共享同一把锁，否则旧 worker 与新会话之间仍可能出现检查/切代竞态。
        self.input_gate_lock = self.context.Lock()
        self.input_generation = self.context.Value(ctypes.c_ulonglong, 0, lock=False)
        self.active_generation = 0
        self.session_id = ""
        self.process = None
        self.process_messages = None
        self.monitor_thread = None
        self.watchdog = None
        self.minimal_guardian = None
        self.worker_job = WorkerProcessJob() if os.name == "nt" else None
        self.activity_lock_held = False
        self.prepared_settings = None
        self.last_stats = None
        self.startup_note = ""
        self.self_test_report = {"ready": False, "checks": [], "summary": "未运行"}
        self.gui_e2e_passed = 0
        self.gui_e2e_total = 0
        self._initialize_storage()
        self.self_test_report = StartupSelfTest(self.data_dir).run_startup_checks()
        self.startup_ready = bool(self.self_test_report.get("ready"))
        e2e_checks = [item for item in self.self_test_report.get("checks", []) if str(item.get("name", "")).startswith("Windows GUI 端到端 ESC")]
        self.gui_e2e_passed = sum(1 for item in e2e_checks if item.get("ok"))
        self.gui_e2e_total = len(e2e_checks)
        if self.last_stats is not None:
            self.last_stats["gui_e2e_passed"] = self.gui_e2e_passed
            self.last_stats["gui_e2e_total"] = self.gui_e2e_total
        self.startup_note += "；启动自检：" + str(self.self_test_report.get("summary", ""))

    def _initialize_storage(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        write_storage_manifest(self.data_dir)
        memory = LongTermMemory(self.data_dir / DATABASE_FILE_NAME)
        try:
            counts = {
                "experiences": memory.count("episodic_memory"), "states": memory.count("state_memory"),
                "skills": memory.count("skill_memory"), "failures": memory.count("failure_memory"),
                "knowledge": memory.count("semantic_knowledge"), "world": memory.count("world_transition"),
            }
            tiers = memory.tier_counts()
            resources = memory.resource_budget.as_dict()
        finally:
            memory.close()
        model_path = self.data_dir / MODEL_FILE_NAME
        note = ""
        if model_path.exists():
            try:
                model = DoubleQNetwork.load(model_path)
                note = "已载入可扩展多层模型"
            except Exception:
                try:
                    os.replace(model_path, model_path.with_name(model_path.name + ".invalid_" + time.strftime("%Y%m%d_%H%M%S")))
                except OSError:
                    pass
                model = DoubleQNetwork()
                model.save(model_path)
                note = "旧模型结构不兼容，已保留旧文件并创建 v7 模型"
        else:
            model = DoubleQNetwork()
            model.save(model_path)
            note = "已创建可扩展多层模型"
        self.startup_note = note + "；SQLite schema v{} 已就绪".format(SCHEMA_VERSION)
        task_benchmark = StartupSelfTest(self.data_dir).cached_goal_compiler_regression(allow_compute=False)
        self.last_stats = {
            "phase": "就绪", "goal": "", "hidden": model.hidden_count, "depth": model.depth, "input_count": model.input_count,
            "experiences": counts["experiences"], "states": counts["states"], "skills": counts["skills"], "failures": counts["failures"],
            "knowledge": counts["knowledge"], "world": counts["world"], "compressed_memory": tiers["compressed"], "archived_memory": tiers["archived"],
            "sleep_count": model.sleep_count, "training_steps": model.training_steps, "target_syncs": model.target_syncs,
            "growth": model.accepted_growth, "loss": model.loss_average, "reward": model.reward_average,
            "goal_progress": model.progress_average, "safety": model.safety_average, "progress": 0, "total": 0,
            "capacities": dict(model.capacities),
            "resources": resources, "sleep_score": 0.0, "bottleneck": "none",
            "task_benchmark_passed":task_benchmark["passed"], "task_benchmark_total":task_benchmark["total"],
            "task_safety_regressions":task_benchmark["safety_regressions"],
        }

    def _stats(self, phase, goal_label="", progress=0, total=0):
        result = dict(self.last_stats or {})
        result.update({
            "phase": phase, "goal": goal_label, "progress": progress, "total": total,
            "gui_e2e_passed": int(getattr(self, "gui_e2e_passed", 0)),
            "gui_e2e_total": int(getattr(self, "gui_e2e_total", 0)),
        })
        return result

    def _acquire_activity_lock(self):
        if not self.activity_lock_held:
            lock_runtime_activity()
            self.activity_lock_held = True

    def _release_activity_lock(self):
        if self.activity_lock_held:
            self.activity_lock_held = False
            unlock_runtime_activity()

    def running(self):
        return self.process is not None and self.process.is_alive()

    def _abort_prepared_session(self):
        try:
            if self.input_gate_event is not None and self.stop_event is not None:
                SharedInputGate(
                    self.input_gate_event, self.input_gate_lock, self.stop_event,
                    generation_value=self.input_generation, expected_generation=self.active_generation,
                ).close()
        except Exception:
            pass
        if self.input_ready_event is not None:
            try: self.input_ready_event.set()
            except Exception: pass
        if self.process is not None and self.process.is_alive():
            try:
                self.process.terminate(); self.process.join(ESC_WORKER_KILL_GRACE)
            except Exception:
                pass
        if self.watchdog is not None:
            try: self.watchdog.stop()
            except Exception: pass
        if self.minimal_guardian is not None:
            try: self.minimal_guardian.stop()
            except Exception: pass
        if self.worker_job is not None:
            try: self.worker_job.close()
            except Exception: pass
        self.prepared_settings = None
        self._release_activity_lock()

    def prepare(self, settings):
        if self.running():
            return
        settings = dict(settings or {})
        if str(settings.get("mode", "task")).lower() in ("task", "autonomous"):
            settings["clicks"] = True
            settings["keyboard"] = True
            settings["observe_only"] = False
            settings["autonomous_profile"] = "operate"
        self.stop_event = self.context.Event()
        self.escape_event = self.context.Event()
        self.input_gate_event = self.context.Event()
        self.input_gate_event.set()  # P0：默认关闭；两道独立 ESC 安全进程均存活后才允许清除。
        self.input_pause_event = self.context.Event()
        self.input_pause_event.clear()
        self.input_ready_event = self.context.Event()
        self.sleep_ui_ready_event = self.context.Event()
        self.wake_ui_hidden_event = self.context.Event()
        self.wake_validation_request_event = self.context.Event()
        self.wake_validation_ready_event = self.context.Event()
        with self.input_gate_lock:
            generation = 0
            while generation == 0:
                generation = secrets.randbits(63)
            self.input_generation.value = generation
            self.active_generation = generation
        self.session_id = uuid.uuid4().hex
        self.process_messages = self.context.Queue()
        self.watchdog = EscapeWatchdog(
            self.context, self.stop_event, self.escape_event,
            release_enabled=not bool(settings.get("observe_only", False)),
            input_gate_event=self.input_gate_event, input_gate_lock=self.input_gate_lock,
            generation_value=self.input_generation, expected_generation=self.active_generation,
        )
        self.watchdog.start()
        time.sleep(0.035)
        if not self.watchdog.is_alive(require_process=True):
            self.watchdog.stop()
            SharedInputGate(
                self.input_gate_event, self.input_gate_lock, self.stop_event, pause_event=self.input_pause_event,
                generation_value=self.input_generation, expected_generation=self.active_generation,
            ).close()
            raise RuntimeError("P0 安全链路失败：独立 EscapeWatchdog 未保持存活，输入权限未打开")

        self.process = self.context.Process(
            target=agent_worker_process,
            args=(
                str(self.data_dir), dict(settings), self.stop_event, self.escape_event, self.process_messages,
                self.input_gate_event, self.input_pause_event, self.input_ready_event,
                self.sleep_ui_ready_event, self.wake_ui_hidden_event,
                self.wake_validation_request_event, self.wake_validation_ready_event, self.input_gate_lock,
                self.input_generation, self.active_generation, self.session_id,
            ),
            name="LocalAIWorker",
            daemon=True,
        )
        try:
            self.process.start()
        except Exception:
            if self.watchdog is not None:
                self.watchdog.stop()
            SharedInputGate(
                self.input_gate_event, self.input_gate_lock, self.stop_event,
                generation_value=self.input_generation, expected_generation=self.active_generation,
            ).close()
            self.process = None
            raise

        if self.worker_job is not None:
            job_ok, job_detail = self.worker_job.assign(self.process.pid)
            if not job_ok:
                SharedInputGate(
                    self.input_gate_event, self.input_gate_lock, self.stop_event,
                    generation_value=self.input_generation, expected_generation=self.active_generation,
                ).close()
                if self.process is not None and self.process.is_alive():
                    try:
                        self.process.terminate(); self.process.join(ESC_WORKER_KILL_GRACE)
                    except Exception:
                        pass
                if self.watchdog is not None:
                    self.watchdog.stop()
                raise RuntimeError("P0 安全链路失败：worker Windows Job Object 无法启用：" + str(job_detail))

        self.minimal_guardian = MinimalEscapeGuardian(
            self.stop_event, self.escape_event, self.input_gate_event, self.input_gate_lock,
            self.input_generation, self.active_generation,
        )
        try:
            guardian_started = bool(self.minimal_guardian.start(self.process.pid, int(settings.get("main_hwnd", 0) or 0)))
        except Exception:
            guardian_started = False
        time.sleep(0.035)
        guardian_alive = bool(guardian_started and self.minimal_guardian is not None and self.minimal_guardian.is_alive())
        watchdog_alive = bool(self.watchdog is not None and self.watchdog.is_alive(require_process=True))
        if not (guardian_alive and watchdog_alive):
            SharedInputGate(
                self.input_gate_event, self.input_gate_lock, self.stop_event,
                generation_value=self.input_generation, expected_generation=self.active_generation,
            ).close()
            if self.input_ready_event is not None:
                self.input_ready_event.set()
            if self.process is not None and self.process.is_alive():
                try:
                    self.process.terminate()
                    self.process.join(ESC_WORKER_KILL_GRACE)
                except Exception:
                    pass
            if self.watchdog is not None:
                self.watchdog.stop()
            if self.minimal_guardian is not None:
                self.minimal_guardian.stop()
            if self.worker_job is not None:
                self.worker_job.close()
            raise RuntimeError("P0 安全链路失败：watchdog/guardian 未同时存活，worker 已终止，输入权限未打开")

        # Supervisor 先上线；GUI 此时仍保持可见，input gate 仍关闭。
        self.monitor_thread = threading.Thread(target=self._monitor, name="LocalAIWorkerSupervisor", daemon=True)
        self.monitor_thread.start()

        # prepare 阶段到此为止：worker/safety/supervisor 已建立，但 GUI 仍可见、input gate 仍关闭，worker 仍等待 input_ready_event。
        self.prepared_settings = dict(settings)
        return True

    def activate(self):
        settings = dict(getattr(self, "prepared_settings", {}) or {})
        if not settings or self.process is None:
            raise RuntimeError("尚未 prepare 会话，不能 activate")
        observe_only = bool(settings.get("observe_only", False))
        self._acquire_activity_lock()
        with self.input_gate_lock:
            watchdog_alive = bool(self.watchdog is not None and self.watchdog.is_alive(require_process=True))
            guardian_alive = bool(self.minimal_guardian is not None and self.minimal_guardian.is_alive())
            worker_alive = bool(self.process is not None and self.process.is_alive())
            generation_valid = int(self.input_generation.value) == int(self.active_generation) and int(self.active_generation) != 0
            if not (watchdog_alive and guardian_alive and worker_alive and generation_valid and not self.stop_event.is_set()):
                SharedInputGate(
                    self.input_gate_event, None, self.stop_event,
                    generation_value=self.input_generation, expected_generation=self.active_generation,
                )._close_unlocked()
                if self.input_ready_event is not None:
                    self.input_ready_event.set()
                if self.process is not None and self.process.is_alive():
                    try:
                        self.process.terminate(); self.process.join(ESC_WORKER_KILL_GRACE)
                    except Exception:
                        pass
                if self.watchdog is not None:
                    self.watchdog.stop()
                if self.minimal_guardian is not None:
                    self.minimal_guardian.stop()
                if self.worker_job is not None:
                    self.worker_job.close()
                self._release_activity_lock()
                raise RuntimeError("P0 安全链路在放开输入前失效，已 fail-closed")
            if not observe_only:
                self.input_gate_event.clear()
        self.input_ready_event.set()
        self.messages.put((
            "event",
            "P0 prepare→hide→state→activate 已完成：EscapeWatchdog + MinimalEscapeGuardian 均存活；worker Job ActiveProcessLimit=1；AI 活动期子进程锁已启用；{}".format(
                "只观察模式保持 SendInput 硬关闭" if observe_only else "输入闸门已按 generation 租约开放",
            ),
        ))
        self.prepared_settings = None
        return True

    def start(self, settings, before_activate=None):
        """兼容入口；正式 Application 使用 prepare→hide→state transition→activate。"""
        self.prepare(settings)
        try:
            if before_activate is not None:
                before_activate()
            return self.activate()
        except Exception:
            self._abort_prepared_session()
            raise

    def _monitor(self):
        emergency_sent = False
        no_more_input_sent = False
        stop_started = None
        child_reported_stop = False
        safety_failure = ""
        last_worker_state = STATE_IDLE
        while True:
            try:
                kind, payload = self.process_messages.get(timeout=0.010)
                if kind == "stats" and isinstance(payload, dict):
                    self.last_stats = dict(payload)
                    self.last_stats["gui_e2e_passed"] = int(getattr(self, "gui_e2e_passed", 0))
                    self.last_stats["gui_e2e_total"] = int(getattr(self, "gui_e2e_total", 0))
                if kind == "state":
                    last_worker_state = str(payload.get("to", "")) if isinstance(payload, dict) else str(payload)
                if kind == "stopped":
                    child_reported_stop = True
                self.messages.put((kind, payload))
            except queue.Empty:
                pass
            except (EOFError, OSError):
                pass

            # SLEEPING -> FREE_ACTIVE 前必须由 supervisor 同步复验 watchdog/guardian/generation。
            if (self.running() and self.wake_validation_request_event is not None
                    and self.wake_validation_request_event.is_set() and self.stop_event is not None and not self.stop_event.is_set()):
                watchdog_alive = bool(self.watchdog is not None and self.watchdog.is_alive(require_process=True))
                guardian_alive = bool(self.minimal_guardian is not None and self.minimal_guardian.is_alive())
                generation_valid = bool(self.active_generation and int(self.input_generation.value) == int(self.active_generation))
                if watchdog_alive and guardian_alive and generation_valid:
                    self.wake_validation_ready_event.set()
                else:
                    SharedInputGate(
                        self.input_gate_event, self.input_gate_lock, self.stop_event, pause_event=self.input_pause_event,
                        generation_value=self.input_generation, expected_generation=self.active_generation,
                    ).close()
                    safety_failure = "P0 醒前复验失败：watchdog={} guardian={} generation={}".format(
                        watchdog_alive, guardian_alive, generation_valid
                    )
                    self.messages.put(("emergency", safety_failure + "；worker 正在强制终止"))
                    emergency_sent = True
                    stop_started = time.monotonic()
                    try: self.process.terminate()
                    except Exception: pass

            # P0 持续健康检查：任一 ESC 安全进程失效都 fail-closed。
            if self.running() and self.stop_event is not None and not self.stop_event.is_set():
                failed = []
                failure_detail = []
                if self.watchdog is None or not self.watchdog.is_alive(require_process=True):
                    failed.append("EscapeWatchdog")
                if self.minimal_guardian is None or not self.minimal_guardian.is_alive():
                    failed.append("MinimalEscapeGuardian")
                if failed:
                    safety_failure = "P0 会话安全不变量失效：" + " + ".join(failed)
                    if failure_detail:
                        safety_failure += "；" + "；".join(failure_detail)
                    SharedInputGate(
                        self.input_gate_event, self.input_gate_lock, self.stop_event, pause_event=self.input_pause_event,
                        generation_value=self.input_generation, expected_generation=self.active_generation,
                    ).close()
                    emergency_sent = True
                    stop_started = time.monotonic()
                    self.messages.put(("emergency", safety_failure + "；已立即关闭 input gate、设置 stop_event；worker 正在强制终止，主界面将在最终 stopped 后恢复"))
                    self.messages.put(("no_more_input", "P0 fail-closed：本轮正常 SendInput 永久关闭"))
                    no_more_input_sent = True
                    # 不允许 GUI 先于 worker 终止；P0 直接强杀，不提供保存/训练宽限。
                    if self.running():
                        try:
                            self.process.terminate()
                        except Exception:
                            pass

            if self.stop_event is not None and self.stop_event.is_set() and self.running():
                if not emergency_sent:
                    emergency_sent = True
                    stop_started = time.monotonic()
                    escaped = self.escape_event is not None and self.escape_event.is_set()
                    sleeping_escape = bool(escaped and last_worker_state in (STATE_FREE_SLEEP_PREPARE, STATE_SLEEPING, STATE_FREE_WAKE_PREPARE))
                    text = (
                        "ESC：AI已停止睡觉；睡眠计算立即终止，禁止经过正常醒来路径，主界面保持/恢复可见"
                        if sleeping_escape else (
                            "检测到 ESC：硬输入闸门已关闭；worker 不再保存/训练并立即终止；主界面仅在确认 worker 已死后恢复"
                            if escaped else "检测到停止请求：硬输入闸门已关闭；worker 进入第二阶段保存/退出；主界面等待最终 stopped"
                        )
                    )
                    self.messages.put(("emergency", text))
                if self.input_gate_event is not None and self.input_gate_event.is_set() and not no_more_input_sent:
                    no_more_input_sent = True
                    self.messages.put(("no_more_input", "输入层已确认 no_more_input：本轮正常 SendInput 永久关闭，等待 worker terminated"))
                escaped = self.escape_event is not None and self.escape_event.is_set()
                # ESC 不允许保存/训练宽限；普通停止仍允许轻量持久化。
                grace = 0.0 if escaped else 1.50
                if stop_started is not None and time.monotonic() - stop_started >= grace and self.running():
                    try:
                        self.process.terminate()
                    except Exception:
                        pass
            if not self.running():
                for _ in range(64):
                    try:
                        kind, payload = self.process_messages.get_nowait()
                    except Exception:
                        break
                    if kind == "stats" and isinstance(payload, dict):
                        self.last_stats = dict(payload)
                        self.last_stats["gui_e2e_passed"] = int(getattr(self, "gui_e2e_passed", 0))
                        self.last_stats["gui_e2e_total"] = int(getattr(self, "gui_e2e_total", 0))
                    if kind == "state":
                        last_worker_state = str(payload.get("to", "")) if isinstance(payload, dict) else str(payload)
                    if kind == "stopped":
                        child_reported_stop = True
                    self.messages.put((kind, payload))
                break
        try:
            if self.input_gate_event is not None and self.stop_event is not None:
                SharedInputGate(
                    self.input_gate_event, self.input_gate_lock, self.stop_event, pause_event=self.input_pause_event,
                    generation_value=self.input_generation, expected_generation=self.active_generation,
                ).close()
        except Exception:
            pass
        if self.watchdog is not None:
            self.watchdog.stop()
        # 无论正常结束还是 ESC，MinimalEscapeGuardian 都必须保留到 Application
        # 实际确认主界面可见；这里只回收 worker Job，不把“调用过 deiconify”当成恢复完成。
        if self.worker_job is not None:
            self.worker_job.close()
        self._release_activity_lock()
        if emergency_sent and not child_reported_stop:
            if self.escape_event is not None and self.escape_event.is_set() and last_worker_state in (STATE_FREE_SLEEP_PREPARE, STATE_SLEEPING, STATE_FREE_WAKE_PREPARE):
                self.messages.put(("stopped", "ESC：AI已停止睡觉"))
            else:
                self.messages.put(("stopped", (safety_failure + "；worker 已强制停止") if safety_failure else "AI worker 已被主进程强制停止"))
        elif not child_reported_stop:
            self.messages.put(("stopped", "AI worker 已退出"))

    def confirm_sleep_gui_visible(self):
        """Application 已实际 deiconify/lift 主界面后确认 FREE_SLEEP_PREPARE 握手。"""
        if self.sleep_ui_ready_event is not None and self.running():
            self.sleep_ui_ready_event.set()
            return True
        return False

    def confirm_wake_gui_hidden(self):
        """Application 已实际 withdraw/update_idletasks 后确认 FREE_WAKE_PREPARE 握手。"""
        if self.wake_ui_hidden_event is not None and self.running():
            self.wake_ui_hidden_event.set()
            return True
        return False

    def complete_gui_restore(self):
        """Application 正常恢复 GUI 后结束 ESC guardian；guardian 仅保留到这一刻用于主进程死亡/GUI 卡死兜底。"""
        if self.minimal_guardian is not None:
            try: self.minimal_guardian.stop()
            except Exception: pass
        return True

    def exit_invariants(self):
        worker_dead = not self.running()
        gate_closed = bool(self.input_gate_event is None or self.input_gate_event.is_set())
        pause_set = bool(self.input_pause_event is not None and self.input_pause_event.is_set())
        try:
            generation_zero = int(self.input_generation.value) == 0
        except Exception:
            generation_zero = False
        return {
            "worker_dead": worker_dead,
            "input_gate_closed": gate_closed,
            "generation_zero": generation_zero,
            "sleep_pause_safe": (not pause_set) or gate_closed,
        }

    def request_stop(self):
        if self.stop_event is not None:
            SharedInputGate(
                self.input_gate_event, self.input_gate_lock, self.stop_event,
                generation_value=self.input_generation, expected_generation=self.active_generation,
            ).close()

    def shutdown(self):
        if self.running():
            self.request_stop()
            self.process.join(0.85)
            if self.running():
                try:
                    self.process.terminate()
                except Exception:
                    pass
                self.process.join(0.3)
        if self.watchdog is not None:
            self.watchdog.stop()
        if self.minimal_guardian is not None:
            self.minimal_guardian.stop()
        if self.worker_job is not None:
            self.worker_job.close()
        self._release_activity_lock()
        return True


def python_runtime_status():
    version = tuple(sys.version_info[:2])
    version_ok = PYTHON_MIN <= version < PYTHON_MAX_EXCLUSIVE
    bit_ok = ctypes.sizeof(ctypes.c_void_p) == 8
    implementation_ok = getattr(sys.implementation, "name", "cpython") == "cpython"
    ok = version_ok and bit_ok and implementation_ok
    detail = "当前 {} {}.{}.{} {}-bit；支持 CPython {}.{}–{}.{}，推荐 {}".format(
        getattr(sys.implementation, "name", "python"), sys.version_info.major, sys.version_info.minor, sys.version_info.micro, ctypes.sizeof(ctypes.c_void_p) * 8,
        PYTHON_MIN[0], PYTHON_MIN[1], PYTHON_MAX_EXCLUSIVE[0], PYTHON_MAX_EXCLUSIVE[1] - 1, PYTHON_RECOMMENDED,
    )
    return ok, detail


class _SYSTEM_INFO_ARCH(ctypes.Structure):
    _fields_ = [("wProcessorArchitecture", wintypes.WORD), ("wReserved", wintypes.WORD)]


class _SYSTEM_INFO_UNION(ctypes.Union):
    _anonymous_ = ("arch",)
    _fields_ = [("dwOemId", wintypes.DWORD), ("arch", _SYSTEM_INFO_ARCH)]


class _SYSTEM_INFO(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [
        ("u", _SYSTEM_INFO_UNION), ("dwPageSize", wintypes.DWORD),
        ("lpMinimumApplicationAddress", wintypes.LPVOID), ("lpMaximumApplicationAddress", wintypes.LPVOID),
        ("dwActiveProcessorMask", ctypes.c_size_t), ("dwNumberOfProcessors", wintypes.DWORD),
        ("dwProcessorType", wintypes.DWORD), ("dwAllocationGranularity", wintypes.DWORD),
        ("wProcessorLevel", wintypes.WORD), ("wProcessorRevision", wintypes.WORD),
    ]


def native_processor_architecture():
    if os.name != "nt":
        return -1
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.GetNativeSystemInfo.argtypes = [ctypes.POINTER(_SYSTEM_INFO)]
        kernel32.GetNativeSystemInfo.restype = None
        info = _SYSTEM_INFO()
        kernel32.GetNativeSystemInfo(ctypes.byref(info))
        return int(info.wProcessorArchitecture)
    except Exception:
        return -1


def windows_runtime_detail():
    if os.name != "nt": return "需要 Windows 11 x64（AMD64，build >= 22000）"
    try:
        version = sys.getwindowsversion()
        arch = native_processor_architecture()
        arch_text = "AMD64/x64" if arch == PROCESSOR_ARCHITECTURE_AMD64 else "native architecture={}".format(arch)
        return "Windows build {}；需要 >= 22000；Python {}-bit；{}".format(
            int(version.build), ctypes.sizeof(ctypes.c_void_p) * 8, arch_text
        )
    except Exception:
        return "无法读取 Windows build/native architecture"


def is_windows_11_x64():
    if os.name != "nt" or ctypes.sizeof(ctypes.c_void_p) != 8:
        return False
    try:
        version = sys.getwindowsversion()
        if int(version.major) != 10 or int(version.build) < 22000:
            return False
    except Exception:
        return False
    return native_processor_architecture() == PROCESSOR_ARCHITECTURE_AMD64


def capture_foreground_context(exclude_pid=None, z_order_fallback=True):
    """点击“开始”的瞬间锁定用户工作窗口；若 GUI 自己在前台，则取其后第一个可见外部顶层窗口。"""
    if os.name != "nt":
        return {}
    try:
        user32 = ctypes.WinDLL("user32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindow.argtypes = [wintypes.HWND, wintypes.UINT]; user32.GetWindow.restype = wintypes.HWND
        user32.IsWindowVisible.argtypes = [wintypes.HWND]; user32.IsWindowVisible.restype = wintypes.BOOL
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]; user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]; kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]; kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]; kernel32.CloseHandle.restype = wintypes.BOOL
        hwnd = user32.GetForegroundWindow()
        # GW_HWNDNEXT=2：Tk 的“开始”按钮通常使自身成为前台，向 Z-order 后方寻找用户原工作窗口。
        for _ in range(64):
            if not hwnd:
                break
            pid = wintypes.DWORD(0); user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if (exclude_pid is None or int(pid.value) != int(exclude_pid)) and user32.IsWindowVisible(hwnd):
                title = ctypes.create_unicode_buffer(512); cls = ctypes.create_unicode_buffer(256)
                user32.GetWindowTextW(hwnd, title, len(title)); user32.GetClassNameW(hwnd, cls, len(cls))
                if title.value.strip() or cls.value.strip():
                    process_path = ""
                    handle = kernel32.OpenProcess(0x1000, False, pid.value) if pid.value else None
                    if handle:
                        try:
                            size = wintypes.DWORD(2048); buf = ctypes.create_unicode_buffer(size.value)
                            if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                                process_path = buf.value
                        finally:
                            kernel32.CloseHandle(handle)
                    return {"hwnd": int(hwnd), "process_id": int(pid.value), "process_path": process_path,
                            "process_name": os.path.basename(process_path).lower() if process_path else "",
                            "window_title": title.value, "window_class": cls.value, "captured_at": time.time()}
            if not z_order_fallback:
                break
            hwnd = user32.GetWindow(hwnd, 2)
    except Exception:
        return {}
    return {}


def choose_data_directory():
    base_dir = RUNTIME_PATHS.base_dir
    preferred = RUNTIME_PATHS.data_dir
    portable = (base_dir / "portable.flag").exists() or any(str(arg).strip().lower() == "--portable" for arg in sys.argv[1:])
    candidates = [preferred] if portable else RUNTIME_PATHS.data_candidates()
    errors = []
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / (".write_probe_" + uuid.uuid4().hex)
            with open(probe, "wb") as stream:
                stream.write(b"ok")
                stream.flush()
                os.fsync(stream.fileno())
            probe.unlink()
            fallback = candidate != preferred
            note = "portable" if portable else ("code.py 所在目录不可写，已回退到 LOCALAPPDATA：{}".format(candidate) if fallback else "")
            return candidate, fallback, note
        except Exception as error:
            errors.append("{}: {}".format(candidate, error))
    if portable:
        raise OSError("便携模式要求所有数据留在 code.py 同目录，但该目录不可写：" + "；".join(errors))
    raise OSError("没有可写的数据目录：" + "；".join(errors))


class Application:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("930x900")
        self.root.minsize(800, 760)
        self.root.configure(bg="#0f172a")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.messages = queue.Queue()
        self.closing = False
        self.pending_approval = None
        self.terminating = False
        self.last_settings = None
        self.last_external_context = {}
        self.state_machine = SessionStateMachine(STATE_IDLE)
        self.worker_state_sequence = WorkerStateSequence()
        self._session_stop_requested = False
        self._final_restore_pending = False
        self._last_product_state = STATE_IDLE
        self._sleep_escape_pending = False
        data_dir_error = ""
        try:
            self.data_dir, self.data_dir_fallback, self.data_dir_note = choose_data_directory()
        except Exception as error:
            self.data_dir = RUNTIME_PATHS.data_dir
            self.data_dir_fallback = False
            self.data_dir_note = str(error)
            data_dir_error = str(error)
        try:
            if data_dir_error:
                raise OSError(data_dir_error)
            self.agent = LocalAgent(self.data_dir, self.messages)
            self.startup_error = ""
        except Exception as error:
            self.agent = None
            self.startup_error = str(error)
        self.clicks = tk.BooleanVar(value=True)
        self.keyboard = tk.BooleanVar(value=True)
        self.safe_mode = tk.BooleanVar(value=True)
        # 默认保持原始产品流程：点击“开始”后可执行鼠标/键盘。
        # 用户可在首次运行前主动勾选只观察，届时规划与学习照常、SendInput 硬禁止。
        self.observe_only = tk.BooleanVar(value=False)
        # “开始”默认进入完整自主操作档；SafetyPolicy 仍对支付、安装、凭据、危险发送和不可逆修改做禁止/逐次批准。
        self.autonomous_operate = tk.BooleanVar(value=True)
        self.speed = tk.DoubleVar(value=0.32)
        self.goal = tk.StringVar(value="")
        self.success_text = tk.StringVar(value="")
        self.status = tk.StringVar(value="就绪")
        self.details = tk.StringVar(value="")
        self.last_event = tk.StringVar(value="")
        self.target_context_text = tk.StringVar(value="将控制：等待最近一个外部前台窗口")
        self.session_permissions_text = tk.StringVar(value="")
        self._build()
        self._refresh_permissions()
        self.last_external_context = capture_foreground_context(exclude_pid=os.getpid())
        self.root.after(120, self._track_external_foreground)
        self.root.after(20, self.poll)

    def _track_external_foreground(self):
        if self.closing:
            return
        candidate = capture_foreground_context(exclude_pid=os.getpid(), z_order_fallback=False)
        if candidate:
            self.last_external_context = candidate
            if hasattr(self, "target_context_text"):
                self.target_context_text.set("将控制：{} | {}".format(candidate.get("process_name", "未知进程"), candidate.get("window_title", "未知窗口")[:100]))
        elif self.last_external_context and hasattr(self, "target_context_text"):
            candidate = self.last_external_context
            self.target_context_text.set("将控制：{} | {}".format(candidate.get("process_name", "未知进程"), candidate.get("window_title", "未知窗口")[:100]))
        self.root.after(120, self._track_external_foreground)

    def _locked_context(self):
        candidate = dict(self.last_external_context or {})
        if candidate:
            return candidate
        return capture_foreground_context(exclude_pid=os.getpid())

    def _label(self, parent, text="", variable=None, size=11, color="#d1d5db", bold=False, wrap=0, background="#0f172a"):
        return tk.Label(parent, text=text, textvariable=variable, font=("Microsoft YaHei UI", size, "bold" if bold else "normal"), fg=color, bg=background, justify="left", anchor="w", wraplength=wrap)

    def _refresh_permissions(self):
        self.clicks.set(True)
        self.keyboard.set(True)
        self.observe_only.set(False)
        self.autonomous_operate.set(True)
        self.session_permissions_text.set(
            "任务/自由模式固定权限：鼠标=移动/滚动/经策略审查的点击；键盘=导航键+普通文本；observe-only 仅通过“完整诊断”入口测试，不改变正式模式"
        )

    def _build(self):
        frame = tk.Frame(self.root, bg="#0f172a", padx=26, pady=22)
        frame.pack(fill="both", expand=True)
        self._label(frame, APP_NAME, size=23, color="#f8fafc", bold=True).pack(fill="x")
        self._label(frame, "无人工设定的最终学习/模型/记忆容量上限；实际能力受当前硬件、数据和算法有效性约束 · 纯本地 GoalCompiler · 层级 SKILL operator · ExternalAIDelegationPolicy", size=11, color="#60a5fa", bold=True).pack(fill="x", pady=(4, 12))
        info = "本版本固定为本地运行：NumPy 仅为可选加速器，无 pip 时不修改系统 Python并使用 stdlib-array；不存在第三方 AI SDK、外部推理模型、推理 URL/API Key 或第三方/系统 OCR AI 依赖。ExternalAIDelegationPolicy 会在 CLICK/TYPE/KEY/SKILL 前阻止通过浏览器或原生应用把推理/任务委托给第三方 AI。核心离线硬约束为源码审计 + GUI 委托硬拒绝 + Python 运行时离线守卫 + AI 活动期禁子进程 + worker Job Object。主路径：用户目标 → 本地 GoalCompiler → TaskGraph → 本地规划/Double-Q → 层级 SKILL → SafetyPolicy → WinIO → 截图/UIA 验证 → 重新规划。"
        self._label(frame, info, size=9, color="#cbd5e1", wrap=840).pack(fill="x", pady=(0, 12))

        self.mode_buttons = tk.Frame(frame, bg="#0f172a")
        self.mode_buttons.pack(fill="x", pady=(0, 10))
        self.task_button = tk.Button(self.mode_buttons, text="任务", command=self.open_task, font=("Microsoft YaHei UI", 14, "bold"), bg="#16a34a", fg="white", activebackground="#15803d", activeforeground="white", relief="flat", cursor="hand2", padx=22, pady=10)
        self.task_button.pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.start_button = tk.Button(self.mode_buttons, text="自由", command=self.start, font=("Microsoft YaHei UI", 14, "bold"), bg="#2563eb", fg="white", activebackground="#1d4ed8", activeforeground="white", relief="flat", cursor="hand2", padx=22, pady=10)
        self.start_button.pack(side="left", fill="x", expand=True, padx=(6, 0))

        self.goal_panel = tk.Frame(frame, bg="#1e293b", padx=16, pady=13)
        self._label(self.goal_panel, "用户任务（按 Enter 或点击“发送”；任务模式不能为空）", size=9, color="#e2e8f0", bold=True, background="#1e293b").pack(fill="x")
        self.goal_entry = tk.Entry(self.goal_panel, textvariable=self.goal, font=("Microsoft YaHei UI", 10), bg="#334155", fg="#f8fafc", insertbackground="#ffffff", relief="flat")
        self.goal_entry.pack(fill="x", ipady=6, pady=(5, 9))
        self.goal_entry.bind("<Return>", lambda _event: self.send())
        self._label(self.goal_panel, "成功判据（可选；填写应在窗口/控件中出现的文字，多个判据用 | 分隔）", size=9, color="#e2e8f0", background="#1e293b").pack(fill="x")
        self.success_entry = tk.Entry(self.goal_panel, textvariable=self.success_text, font=("Microsoft YaHei UI", 10), bg="#334155", fg="#f8fafc", insertbackground="#ffffff", relief="flat")
        self.success_entry.pack(fill="x", ipady=6, pady=(5, 9))
        self.success_entry.bind("<Return>", lambda _event: self.send())
        self.send_button = tk.Button(self.goal_panel, text="发送", command=self.send, font=("Microsoft YaHei UI", 12, "bold"), bg="#16a34a", fg="white", activebackground="#15803d", activeforeground="white", relief="flat", cursor="hand2", padx=18, pady=8)
        self.send_button.pack(fill="x")

        self.settings_panel = tk.Frame(frame, bg="#1e293b", padx=16, pady=13)
        panel = self.settings_panel
        panel.pack(fill="x")
        check_style = {"font": ("Microsoft YaHei UI", 9), "fg": "#f1f5f9", "bg": "#1e293b", "activebackground": "#1e293b", "activeforeground": "#ffffff", "selectcolor": "#334155"}
        self._label(panel, "正式任务/自由模式：鼠标点击 + 键盘固定启用", size=9, color="#f1f5f9", bold=True, background="#1e293b").grid(row=0, column=0, columnspan=2, sticky="w", padx=(0, 24))
        tk.Checkbutton(panel, text="安全模式", variable=self.safe_mode, **check_style).grid(row=0, column=2, sticky="w")
        self._label(panel, "固定离线：CPython 标准库即可运行，NumPy 仅可选本地加速；禁止 GUI 委托第三方 AI；核心为审计/运行时守卫/禁子进程/Job", size=9, color="#a7f3d0", bold=True, background="#1e293b").grid(row=1, column=0, columnspan=3, sticky="w", pady=(10, 0))
        self._label(panel, "模拟/observe-only 不属于正式模式；需要时使用下方“完整诊断”入口", size=9, color="#93c5fd", background="#1e293b").grid(row=2, column=0, columnspan=3, sticky="w", pady=(10, 0))
        tk.Label(panel, text="动作间隔", font=("Microsoft YaHei UI", 9), fg="#f1f5f9", bg="#1e293b").grid(row=3, column=0, sticky="w", pady=(12, 0))
        tk.Scale(panel, from_=0.15, to=1.2, resolution=0.05, orient="horizontal", variable=self.speed, length=330, showvalue=True, bg="#1e293b", fg="#f1f5f9", troughcolor="#334155", highlightthickness=0).grid(row=3, column=1, columnspan=2, sticky="w", pady=(7, 0))
        panel.grid_columnconfigure(1, weight=1)

        status_panel = tk.Frame(frame, bg="#0f172a", pady=13)
        status_panel.pack(fill="x")
        self._label(status_panel, variable=self.status, size=12, color="#34d399", bold=True).pack(fill="x")
        self._label(status_panel, variable=self.details, size=9, color="#d1d5db", wrap=840).pack(fill="x", pady=(4, 0))
        self._label(status_panel, variable=self.last_event, size=9, color="#93c5fd", wrap=840).pack(fill="x", pady=(4, 0))

        safety = (
            "任务：点击“任务”后输入目标并发送，退出任务模式且 worker 完全停止后恢复主界面。"
            "自由：点击“自由”后隐藏主界面，默认自主操作并按内部状态周期性睡眠/醒来；"
            "ESC 会停止 AI 活动并恢复主界面；外部副作用仍逐次经过 SafetyPolicy。"
        )
        self._label(frame, safety, size=8, color="#a7f3d0", wrap=820).pack(fill="x", pady=(0, 10))
        warning = "重要：普通启动绝不执行真实 WindowsProductFlowE2E/ESC E2E；首次真实键鼠行为只会在用户点击‘任务/自由’后发生。‘运行完整诊断’才显式执行真实 E2E。自由睡眠严格 FREE_ACTIVE→显示 GUI 握手→SLEEPING→醒来→隐藏 GUI 握手→FREE_ACTIVE；睡眠 ESC 只允许 SLEEPING→STOPPING→IDLE，绝不恢复自由键鼠活动。"
        self._label(frame, warning, size=9, color="#fbbf24", bold=True, wrap=820).pack(fill="x", pady=(0, 8))
        self._label(frame, variable=self.session_permissions_text, size=9, color="#a7f3d0", bold=True, wrap=820).pack(fill="x", pady=(0, 6))
        self._label(frame, variable=self.target_context_text, size=9, color="#93c5fd", bold=True, wrap=820).pack(fill="x", pady=(0, 12))
        self.diagnostic_button = tk.Button(frame, text="运行完整诊断（强制重跑 P0 ESC E2E）", command=self.run_full_diagnostics, font=("Microsoft YaHei UI", 9), bg="#334155", fg="#e2e8f0", activebackground="#475569", activeforeground="white", relief="flat", cursor="hand2", padx=12, pady=6)
        self.diagnostic_button.pack(fill="x", pady=(8, 0))
        if self.agent is not None:
            fallback_text = "（{}）".format(self.data_dir_note) if self.data_dir_note and self.data_dir_note != "portable" else ""
            storage_note = "；数据目录：{}{}{}".format(
                self.data_dir, fallback_text,
                "（便携模式）" if self.data_dir_note == "portable" else "",
            )
            py_ok, py_detail = python_runtime_status()
            self.status.set("就绪：" + self.agent.startup_note + storage_note + "；" + py_detail)
            self._update_details(self.agent._stats("就绪"))
        if not is_windows_11_x64():
            self._set_run_buttons("disabled")
            self.status.set("此程序只能在 Windows 11 x64 环境运行")
        elif self.startup_error:
            self._set_run_buttons("disabled")
            self.status.set("初始化失败：" + self.startup_error)
        elif self.agent is not None and not getattr(self.agent, "startup_ready", False):
            self._set_run_buttons("disabled")
            failed = [item["name"] + "：" + item.get("detail", "") for item in self.agent.self_test_report.get("checks", []) if item.get("critical") and not item.get("ok")]
            self.status.set("启动自检未通过：" + "；".join(failed))

    def _update_details(self, stats):
        training = ""
        if stats.get("total"):
            training = " | 睡眠训练 {}/{}".format(stats.get("progress", 0), stats["total"])
        goal = " | 目标：{}".format(stats["goal"][:80]) if stats.get("goal") else ""
        capacities = stats.get("capacities", {})
        capacity = " | UIA {}/{} | ROI×{} | 记忆窗 {} | 策略 {} | 技能注意 {}".format(
            capacities.get("uia_depth", "-"), capacities.get("uia_nodes", "-"), capacities.get("visual_roi_scale", "-"), capacities.get("memory_horizon", "-"),
            capacities.get("planner_breadth", "-"), capacities.get("skill_attention", "-"),
        )
        resources = stats.get("resources", {})
        resource_text = " | 可用RAM {:.1f}GB | 可用盘 {:.1f}GB / 安全线 {:.1f}GB{}".format(
            safe_float(resources.get("available_ram", 0)) / 1024 ** 3,
            safe_float(resources.get("free_disk", 0)) / 1024 ** 3,
            safe_float(resources.get("disk_reserve_bytes", 0)) / 1024 ** 3,
            " | 经验写入暂停" if stats.get("storage_paused") else "",
        ) if resources else ""
        self.details.set(
            "GoalCompiler 语法回归 {}/{} | 真实 GUI E2E {}/{}（ESC P0） | 编译回归失败 {} | 输入 {} 维 | 策略网络 {} 神经元/{} 层 | 热情景 {} | 压缩/归档 {}/{} | 状态 {} | 技能 {} | 失败记忆 {} | 睡眠 {} | sleep_score {:.3f} | 训练 {} | 扩容通过 {} | 误差 {:.4f} | 奖励 {:+.3f}{}{}{}{}".format(
                stats.get("task_benchmark_passed", 0), stats.get("task_benchmark_total", 0),
                stats.get("gui_e2e_passed", 0), stats.get("gui_e2e_total", 0), stats.get("task_safety_regressions", 0),
                stats.get("input_count", BASE_FEATURE_COUNT), stats.get("hidden", 0), stats.get("depth", 0), stats.get("experiences", 0),
                stats.get("compressed_memory", 0), stats.get("archived_memory", 0), stats.get("states", 0), stats.get("skills", 0), stats.get("failures", 0),
                stats.get("sleep_count", 0), stats.get("sleep_score", 0.0), stats.get("training_steps", 0), stats.get("growth", 0),
                stats.get("loss", 0.0), stats.get("reward", 0.0), capacity + " | 知识 {} | 世界 {} | 瓶颈 {}".format(stats.get("knowledge", 0), stats.get("world", 0), stats.get("bottleneck", "none")), resource_text, training, goal,
            )
        )

    def _set_run_buttons(self, state):
        for button in (
            getattr(self, "task_button", None), getattr(self, "send_button", None), getattr(self, "start_button", None),
            getattr(self, "diagnostic_button", None),
        ):
            if button is not None:
                try: button.configure(state=state)
                except Exception: pass

    def open_task(self):
        if self.agent is None or self.agent.running() or self.terminating or not getattr(self.agent, "startup_ready", False):
            return
        if not self.goal_panel.winfo_manager():
            self.goal_panel.pack(fill="x", pady=(0, 10), before=self.settings_panel)
        self.status.set("任务模式：请输入任务，然后点击“发送”")
        try:
            self.goal_entry.focus_set()
        except Exception:
            pass

    def send(self):
        self._start_mode("task")

    def start(self):
        self._start_mode("autonomous")

    def _hide_main_window(self):
        self.root.withdraw()
        self.root.update_idletasks()
        try:
            hidden = self.root.state() == "withdrawn" or not bool(self.root.winfo_viewable())
        except Exception:
            hidden = False
        if not hidden:
            raise RuntimeError("P0：主界面尚未确认隐藏，拒绝进入 AI 活动状态")
        return True

    def _confirm_sleep_ui_when_visible(self):
        """Tk 真正完成 map 后再回 ACK，避免 worker 把 deiconify 请求误当成“GUI 已显示”。"""
        if self.agent is None or not self.agent.running() or self.state_machine.state != STATE_FREE_SLEEP_PREPARE:
            return
        try:
            self.root.update_idletasks()
            visible = self.root.state() != "withdrawn" and bool(self.root.winfo_viewable())
        except Exception:
            visible = False
        if visible:
            self.agent.confirm_sleep_gui_visible()
        else:
            self.root.after(12, self._confirm_sleep_ui_when_visible)

    def _confirm_wake_ui_when_hidden(self):
        """Tk 确认 withdraw 已生效后再回 ACK；随后 worker 才执行醒前安全复验并恢复输入。"""
        if self.agent is None or not self.agent.running() or self.state_machine.state != STATE_FREE_WAKE_PREPARE:
            return
        try:
            self.root.update_idletasks()
            hidden = self.root.state() == "withdrawn" or not bool(self.root.winfo_viewable())
        except Exception:
            hidden = False
        if hidden:
            self.agent.confirm_wake_gui_hidden()
        else:
            self.root.after(12, self._confirm_wake_ui_when_hidden)

    def _start_mode(self, mode):
        if self.agent is None or self.agent.running() or self.terminating or not getattr(self.agent, "startup_ready", False):
            return
        mode = "autonomous" if mode == "autonomous" else "task"
        user_goal = self.goal.get().strip()
        if mode == "task" and not user_goal:
            self.status.set("任务发送失败：请输入明确的用户任务")
            try: self.goal_entry.focus_set()
            except Exception: pass
            return
        settings = {
            "mode": mode, "clicks": True, "keyboard": True, "safe_mode": self.safe_mode.get(),
            "interval": self.speed.get(), "goal": user_goal if mode == "task" else "",
            "success_text": self.success_text.get().strip() if mode == "task" else "",
            "observe_only": False, "autonomous_profile":"operate",
            "main_hwnd":int(self.root.winfo_id()),
        }
        settings["initial_context"] = self._locked_context()
        self.last_settings = dict(settings)
        locked = settings.get("initial_context", {})
        self.last_event.set("已锁定初始工作上下文：{} | {}".format(locked.get("process_name", "未知进程"), locked.get("window_title", "未知窗口")[:90]))
        self.status.set("发送任务：正在建立目标/视觉/任务图" if mode == "task" else "自主模式：正在建立安全控制状态")
        self.terminating = False
        self._set_run_buttons("disabled")
        try:
            self.agent.prepare(settings)
            self._hide_main_window()
            initial_state = STATE_FREE_ACTIVE if mode == "autonomous" else STATE_TASK_ACTIVE
            self.state_machine.transition(initial_state)
            self.worker_state_sequence.reset(self.agent.session_id, initial_state)
            self._session_stop_requested = False
            self._last_product_state = initial_state
            self._sleep_escape_pending = False
            self.agent.activate()
        except Exception as error:
            self.worker_state_sequence.reset()
            try: self.agent._abort_prepared_session()
            except Exception: pass
            self.state_machine.force_stopping()
            if self.state_machine.state == STATE_STOPPING:
                self.state_machine.transition(STATE_IDLE)
            self.restore("运行错误：无法启动 AI worker：" + str(error))

    def run_full_diagnostics(self):
        if self.agent is None or self.agent.running():
            return
        self.status.set("正在运行完整诊断")
        self._set_run_buttons("disabled")
        try:
            report = StartupSelfTest(self.data_dir).run_full_diagnostics()
            summary = str(report.get("summary", ""))
            self.status.set(("完整诊断通过：" if report.get("ready") else "完整诊断存在失败项：") + summary)
            if report.get("ready"):
                messagebox.showinfo(APP_NAME, "完整诊断通过。\n\n" + summary, parent=self.root)
            else:
                messagebox.showwarning(APP_NAME, "完整诊断完成，存在失败项。\n\n" + summary, parent=self.root)
        except Exception as error:
            self.status.set("完整诊断失败：" + str(error))
            messagebox.showerror(APP_NAME, "完整诊断失败：" + str(error), parent=self.root)
        finally:
            self._set_run_buttons("normal" if self.agent is not None and getattr(self.agent, "startup_ready", False) else "disabled")

    def may_restore_gui(self):
        invariants = self.agent.exit_invariants() if self.agent is not None else {"worker_dead": True, "input_gate_closed": True, "generation_zero": True}
        return (
            bool(invariants.get("worker_dead"))
            and bool(invariants.get("input_gate_closed"))
            and bool(invariants.get("generation_zero"))
            and self.state_machine.state == STATE_IDLE
        )

    def restore(self, reason, ready=True):
        if not self.may_restore_gui():
            self.status.set(str(reason))
            return
        if self.closing:
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()
            return
        self.root.deiconify()
        try:
            self.goal_panel.pack_forget()
        except Exception:
            pass
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(500, lambda: self.root.attributes("-topmost", False))
        self.terminating = not bool(ready)
        self._set_run_buttons("normal" if ready else "disabled")
        self.status.set(reason)
        if reason.startswith("运行错误"):
            messagebox.showerror(APP_NAME, reason, parent=self.root)

    def _restart_after_approval(self):
        if not self.pending_approval or self.agent is None:
            return
        if self.agent.running() or (self.agent.monitor_thread is not None and self.agent.monitor_thread.is_alive()):
            self.root.after(40, self._restart_after_approval)
            return
        approval = dict(self.pending_approval or {})
        fingerprint = str(approval.get("fingerprint", ""))
        context_token = str(approval.get("context", ""))
        self.pending_approval = None
        settings = dict(self.last_settings or {})
        settings["approved_risk_fingerprint"] = fingerprint
        settings["approved_risk_context"] = context_token
        settings["initial_context"] = self._locked_context()
        self.last_settings = dict(settings)
        self.status.set("已确认一次高风险动作；重新感知后仅允许精确匹配的那个动作")
        self.terminating = False
        self._set_run_buttons("disabled")
        try:
            self.agent.prepare(settings)
            self._hide_main_window()
            initial_state = STATE_FREE_ACTIVE if settings.get("mode") == "autonomous" else STATE_TASK_ACTIVE
            self.state_machine.transition(initial_state)
            self.worker_state_sequence.reset(self.agent.session_id, initial_state)
            self._session_stop_requested = False
            self._last_product_state = initial_state
            self._sleep_escape_pending = False
            self.agent.activate()
        except Exception as error:
            self.worker_state_sequence.reset()
            try: self.agent._abort_prepared_session()
            except Exception: pass
            self.state_machine.force_stopping()
            if self.state_machine.state == STATE_STOPPING:
                self.state_machine.transition(STATE_IDLE)
            self.restore("运行错误：确认后无法重新启动 AI worker：" + str(error))

    def _handle_approval(self, payload):
        # approval_required 只记录请求；必须等 worker 最终 stopped、状态回到 IDLE 后才显示 GUI/询问。
        self.pending_approval = {"_request": dict(payload or {})}
        self.status.set("高风险动作已暂停；正在退出任务模式，worker 完全停止后再请求确认")
        return

    def _prompt_pending_approval(self):
        request = dict((self.pending_approval or {}).get("_request") or {})
        self.pending_approval = None
        payload = request
        label = str((payload or {}).get("label", "高风险操作"))
        reason = str((payload or {}).get("reason", "检测到不可逆操作"))
        fingerprint = str((payload or {}).get("fingerprint", ""))
        context_token = str((payload or {}).get("context", ""))
        approved = messagebox.askyesno(
            APP_NAME,
            "AI 已在执行前暂停。\n\n{}\n\n动作：{}\n\n是否只允许这一个精确动作执行一次？".format(reason, label),
            parent=self.root,
        )
        if approved and fingerprint and context_token:
            self.pending_approval = {"fingerprint": fingerprint, "context": context_token}
            self.status.set("已确认；重启后会重新冻结并核对进程/HWND/UIA/文本/关键参数，任何页面变化都会使批准失效")
            self.root.after(40, self._restart_after_approval)
        else:
            self.pending_approval = None
            self.status.set("已取消高风险动作；AI 保持停止")

    def _finish_stop_restore(self, reason):
        if self._final_restore_pending:
            return
        if self.agent is not None and (self.agent.running() or (self.agent.monitor_thread is not None and self.agent.monitor_thread.is_alive())):
            self.root.after(40, lambda: self._finish_stop_restore(reason))
            return
        invariants = self.agent.exit_invariants() if self.agent is not None else {"worker_dead": True, "input_gate_closed": True, "generation_zero": True}
        if not all(invariants.values()):
            self.status.set("停止不变量尚未满足：" + compact_json(invariants))
            self.root.after(40, lambda: self._finish_stop_restore(reason))
            return
        self.state_machine.force_stopping()
        if self.state_machine.state == STATE_STOPPING:
            self.state_machine.transition(STATE_IDLE)
        if not self.may_restore_gui():
            self.status.set("GUI 恢复条件未满足；继续保持隐藏")
            self.root.after(40, lambda: self._finish_stop_restore(reason))
            return
        if self.closing:
            self.restore(reason, ready=True)
            return
        self._final_restore_pending = True
        self.root.deiconify()
        try:
            self.goal_panel.pack_forget()
        except Exception:
            pass
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(500, lambda: self.root.attributes("-topmost", False))
        self.status.set(str(reason))
        self.root.after(0, lambda: self._confirm_final_gui_visible(reason))

    def _confirm_final_gui_visible(self, reason):
        """只有 GUI 真实可见后才开放按钮并结束 MinimalEscapeGuardian。"""
        if self.closing:
            self._final_restore_pending = False
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()
            return
        invariants = self.agent.exit_invariants() if self.agent is not None else {
            "worker_dead": True, "input_gate_closed": True, "generation_zero": True,
        }
        if not all(invariants.values()) or self.state_machine.state != STATE_IDLE:
            self.status.set("P0：最终 GUI 恢复前停止不变量失效：" + compact_json(invariants))
            self.root.after(12, lambda: self._confirm_final_gui_visible(reason))
            return
        try:
            self.root.update_idletasks()
            visible = self.root.state() != "withdrawn" and bool(self.root.winfo_viewable())
        except Exception:
            visible = False
        if not visible:
            self.root.after(12, lambda: self._confirm_final_gui_visible(reason))
            return
        if self._sleep_escape_pending:
            pause_set = bool(self.agent is not None and self.agent.input_pause_event is not None and self.agent.input_pause_event.is_set())
            if pause_set and not bool(invariants.get("input_gate_closed")):
                self.status.set("P0：睡眠 ESC 后输入 pause/gate 不变量未满足")
                self.root.after(12, lambda: self._confirm_final_gui_visible(reason))
                return
        self.terminating = False
        self._set_run_buttons("normal")
        self.status.set(str(reason))
        if self.agent is not None:
            self.agent.complete_gui_restore()
        self._final_restore_pending = False
        self.worker_state_sequence.reset()
        self._session_stop_requested = False
        self._last_product_state = STATE_IDLE
        self._sleep_escape_pending = False
        if self.pending_approval and self.pending_approval.get("_request"):
            self.root.after(20, self._prompt_pending_approval)

    def poll(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == "stats":
                    self.status.set(payload["phase"])
                    self._update_details(payload)
                elif kind == "event":
                    self.last_event.set(payload)
                elif kind == "emergency":
                    self._session_stop_requested = True
                    self.status.set(str(payload))
                    self._set_run_buttons("disabled")
                elif kind == "no_more_input":
                    self._session_stop_requested = True
                    self.status.set(payload)
                    self._set_run_buttons("disabled")
                elif kind == "restore_now":
                    # 兼容旧 worker 消息：严格模式下绝不提前 deiconify。
                    data = payload if isinstance(payload, dict) else {"reason": str(payload)}
                    self.status.set(str(data.get("reason", "AI 正在停止")))
                    self._session_stop_requested = True
                elif kind == "state":
                    try:
                        accepted = self.worker_state_sequence.validate(payload, self.state_machine.state)
                        target = str(accepted["to"])
                        if target in (STATE_FREE_WAKE_PREPARE, STATE_FREE_ACTIVE) and self._session_stop_requested:
                            raise RuntimeError("停止已请求，拒绝睡眠→醒来→自由活动路径")
                        if self.agent is not None and self.agent.escape_event is not None and self.agent.escape_event.is_set() and target in (STATE_FREE_WAKE_PREPARE, STATE_FREE_ACTIVE):
                            raise RuntimeError("ESC 已捕获，拒绝恢复自由键鼠活动")
                        if not accepted["bootstrap"]:
                            self.state_machine.transition(target)
                        self.worker_state_sequence.commit(accepted)
                        if target == STATE_STOPPING:
                            self._session_stop_requested = True
                        else:
                            self._last_product_state = target
                    except RuntimeError as error:
                        self._session_stop_requested = True
                        self.status.set("P0：收到非法状态转换，正在 fail-closed：" + str(error))
                        self._set_run_buttons("disabled")
                        if self.agent is not None:
                            self.agent.request_stop()
                        continue
                    if target == STATE_FREE_SLEEP_PREPARE:
                        # worker 已 pause_normal_input；只有主界面真实显示后才允许进入 SLEEPING/训练。
                        self.root.deiconify()
                        self.root.lift()
                        self._set_run_buttons("disabled")
                        self.status.set("AI准备睡觉")
                        self.root.update_idletasks()
                        self.root.after(0, self._confirm_sleep_ui_when_visible)
                    elif target == STATE_SLEEPING:
                        self._set_run_buttons("disabled")
                        self.status.set("AI睡觉中；按 ESC 停止 AI 并返回主界面")
                    elif target == STATE_FREE_WAKE_PREPARE:
                        # 要求顺序：AI醒来 -> 隐藏主界面 -> 主进程确认隐藏 -> 醒前复验 -> FREE_ACTIVE。
                        self.status.set("AI醒来")
                        self.root.update_idletasks()
                        self.root.withdraw()
                        self.root.update_idletasks()
                        self.root.after(0, self._confirm_wake_ui_when_hidden)
                    elif target == STATE_FREE_ACTIVE:
                        self.status.set("自由模式：AI活动（键盘、鼠标）")
                elif kind == "approval_required":
                    self._handle_approval(payload)
                elif kind == "stopped":
                    self._session_stop_requested = True
                    self._sleep_escape_pending = bool(
                        self.agent is not None
                        and self.agent.escape_event is not None
                        and self.agent.escape_event.is_set()
                        and self._last_product_state in (STATE_FREE_SLEEP_PREPARE, STATE_SLEEPING, STATE_FREE_WAKE_PREPARE)
                    )
                    self.state_machine.force_stopping()
                    self._finish_stop_restore(payload)
        except queue.Empty:
            pass
        if self.closing and (self.agent is None or not self.agent.running()):
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()
            return
        self.root.after(20, self.poll)

    def close(self):
        if self.agent is not None and self.agent.running():
            self.closing = True
            self.agent.request_stop()
            self.status.set("正在安全停止并保存……")
        else:
            if self.agent is not None:
                self.agent.shutdown()
            self.root.destroy()


def show_fatal_error(message):
    text = str(message)
    try:
        fatal_root = tk.Tk()
        fatal_root.withdraw()
        messagebox.showerror(APP_NAME, text, parent=fatal_root)
        fatal_root.destroy()
    except Exception:
        try:
            sys.stderr.write(APP_NAME + "：" + text + "\n")
        except Exception:
            pass


def main():
    global _np
    base_dir = RUNTIME_PATHS.base_dir
    os.chdir(base_dir)
    multiprocessing.freeze_support()

    # 环境 P0 必须早于数据库、模型和 manifest 的创建，避免错误环境留下半套文件。
    if not is_windows_11_x64():
        show_fatal_error("此程序只能在 Windows 11 x64（native AMD64，build >= 22000）运行。\n" + windows_runtime_detail())
        return
    py_ok, py_detail = python_runtime_status()
    if not py_ok:
        show_fatal_error("Python 运行时不受支持。\n" + py_detail)
        return

    try:
        numpy_status = ensure_numpy_available()
    except Exception as error:
        _np = None
        numpy_status = {"ok": True, "backend": "stdlib-array", "detail": "NumPy 可选加速器准备异常；不修改系统 Python，继续使用 stdlib-array 后端：" + str(error)}
    os.environ["LOCAL_AI_NUMPY_STATUS"] = str(numpy_status.get("detail", "NumPy 不可用；使用 stdlib-array 后端"))
    os.environ["LOCAL_AI_COMPUTE_BACKEND"] = str(numpy_status.get("backend", "numpy" if _np is not None else "stdlib-array"))

    # 离线硬约束：源码审计 + Python audit hook + 活动期禁止子进程 + worker Job Object。
    install_runtime_offline_guard()
    enable_per_monitor_dpi_awareness()
    root = tk.Tk()
    Application(root)
    root.mainloop()


if __name__ == "__main__":
    main()
